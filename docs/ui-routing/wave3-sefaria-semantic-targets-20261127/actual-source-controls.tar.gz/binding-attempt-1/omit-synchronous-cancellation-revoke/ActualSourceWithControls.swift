import Foundation
import Observation
import Synchronization

// Explicit platform/domain boundary for compiling the COMPLETE real RN binding.
// Foundation/Observation/Swift concurrency, runtime, RPC actor, one-way latches,
// lease, ticket, source membership and binding methods remain actual source.
// UIKit rendering, Combine, backend/Store data and Core receipt issuance are NOT
// implemented or qualified here. Geometry and JS have separate source controls.
enum BackendID: String { case sefariaEmbedded, otzaria }
enum BackendCapability { case catalog, reading }
@MainActor final class AnyCancellable {
    let cancellation: () -> Void
    init(_ cancellation: @escaping () -> Void) { self.cancellation = cancellation }
    isolated deinit { cancellation() }
}
@MainActor final class BoundaryBackendPublisher {
    private var listeners: [UUID: (Int) -> Void] = [:]
    func sink(_ receive: @escaping (Int) -> Void) -> AnyCancellable {
        let id = UUID(); listeners[id] = receive
        return AnyCancellable { [weak self] in self?.listeners.removeValue(forKey: id) }
    }
    func send() { for callback in Array(listeners.values) { callback(0) } }
}
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    let objectWillChange = BoundaryBackendPublisher()
    var activeBackendID = BackendID.sefariaEmbedded { willSet { objectWillChange.send() } }
    var generation: UInt64 = 1 { willSet { objectWillChange.send() } }
    var isTransitioning = false { willSet { objectWillChange.send() } }
    var activeCapabilities: Set<BackendCapability> = [.catalog, .reading]
}
@MainActor @Observable final class BoundaryMappingSource { var event = 0 }
struct StudyWorkspaceMappingObservation {
    enum Coverage { case workspaceStoreOnly, liveNativeSetters }
    let source: BoundaryMappingSource
    let epoch: Int
    let owner: ObjectIdentifier
    let scene: String
    let coverage: Coverage
}
@MainActor final class iOSNavigationManager {}
@MainActor @Observable final class BoundaryWorkspaceStore {
    var loadError: String?
    let source = BoundaryMappingSource()
    func mappingObservation(scene: String) -> StudyWorkspaceMappingObservation? {
        .init(source: source, epoch: source.event, owner: ObjectIdentifier(self), scene: scene, coverage: .workspaceStoreOnly)
    }
}
@MainActor @Observable final class StudyWorkspaceNavigationAdapter {
    let sceneID: String
    let manager: iOSNavigationManager
    let store = BoundaryWorkspaceStore()
    let source = BoundaryMappingSource()
    var attached = true; var isSwitching = false; var errorMessage: String?
    init(sceneID: String, manager: iOSNavigationManager) { self.sceneID = sceneID; self.manager = manager }
    func mappingOwnershipObservation() -> StudyWorkspaceMappingObservation? {
        .init(source: source, epoch: source.event, owner: ObjectIdentifier(manager), scene: sceneID, coverage: .liveNativeSetters)
    }
}
struct UIStableID: Equatable, Sendable { let rawValue: String; init?(rawValue: String) { if rawValue.isEmpty { return nil }; self.rawValue = rawValue } }
struct UIDestinationID: Equatable, Sendable { let rawValue: String; init?(rawValue: String) { if rawValue.isEmpty { return nil }; self.rawValue = rawValue } }
struct UIRouteError: Error { enum Status { case unavailable, staleState }; let status: Status; let code: String; init(_ status: Status, _ code: String) { self.status = status; self.code = code } }
struct UISceneReceipt {
    struct Route {
        struct Presentation { enum Kind { case sheet, currentTab }; let kind: Kind }
        let requestId: UUID; let destination: UIDestinationID; let presentation: Presentation
        let content: Int?; let focus: Int?
    }
    let requestId: UUID; let sceneID: UIStableID; let route: Route
}
@MainActor final class SefariaExpoLifecycleAdapter {
    static let shared = SefariaExpoLifecycleAdapter()
    var canCreateVisibleSurface = true
}
@MainActor final class OtzariaFileLogger { static let shared = OtzariaFileLogger(); func log(_ text: String) {} }
@MainActor final class UIView { var bounds = CGRect(x: 0, y: 0, width: 600, height: 800) }
@MainActor protocol SefariaEmbeddedNativeSurfaceObserver: AnyObject {
    func surfaceWillAttach(_ controller: SefariaEmbeddedNativeSurfaceController) throws
    func surfaceDidChange(_ controller: SefariaEmbeddedNativeSurfaceController)
    func surfaceWillDisappear(_ controller: SefariaEmbeddedNativeSurfaceController)
    func surfaceDidDetach(_ controller: SefariaEmbeddedNativeSurfaceController)
    func surfaceDidFail(_ controller: SefariaEmbeddedNativeSurfaceController, error: any Error)
}
@MainActor final class SefariaEmbeddedNativeSurfaceController {
    struct Evidence { var mounted = true; var appeared = true; var visible = true; var transitioning = false }
    struct SemanticEvidence { let originalViews: [ObjectIdentifier] }
    let identity: SefariaEmbeddedSurfaceIdentity
    let token = UUID()
    var reactView: UIView? = UIView()
    var state = Evidence()
    var semanticVisible = true
    var observedTarget: SefariaEmbeddedSemanticTarget?
    var originalSemanticView = UIView()
    weak var observer: (any SefariaEmbeddedNativeSurfaceObserver)?
    var observing: (() -> Void)?
    init(identity: SefariaEmbeddedSurfaceIdentity) { self.identity = identity }
    func evidence() -> Evidence? { state }
    func semanticEvidence(target: SefariaEmbeddedSemanticTarget, language: String) -> SemanticEvidence? {
        guard state.visible, semanticVisible, target.originalVisibleTexts(language: language) != nil else { return nil }
        return .init(originalViews: [ObjectIdentifier(originalSemanticView)])
    }
    func observeSemanticTarget(_ target: SefariaEmbeddedSemanticTarget, language: String) {
        observedTarget = target; observing?(); observer?.surfaceDidChange(self)
    }
    func stopSemanticObservation() { observedTarget = nil }
    func detach() { state.visible = false; observer?.surfaceDidDetach(self); observer = nil }
}

//
//  SefariaRPCModels.swift
//  Maktabah
//
//  Downstream-owned strongly typed RPC models for native <-> JS communication
//  with the embedded Sefaria-Mobile runtime.
//  Uses explicit JSON strings (paramsJson, resultJson, payloadJson) at the boundary
//  to guarantee zero Base64 / binary encoding ambiguity across Swift and JavaScript.
//

import Foundation

struct SefariaRPCEnvelope: Codable, Sendable, Equatable {
    let protocolVersion: String
    let requestID: String
    let method: String
    let paramsJson: String?
    let backendID: String
    let sessionGeneration: UInt64
    let timeoutMs: Int

    init(
        protocolVersion: String = "1.0",
        requestID: String = UUID().uuidString,
        method: String,
        paramsJson: String? = nil,
        backendID: String = "sefariaEmbedded",
        sessionGeneration: UInt64 = 0,
        timeoutMs: Int = 15000
    ) {
        self.protocolVersion = protocolVersion
        self.requestID = requestID
        self.method = method
        self.paramsJson = paramsJson
        self.backendID = backendID
        self.sessionGeneration = sessionGeneration
        self.timeoutMs = timeoutMs
    }

    init<T: Encodable>(
        protocolVersion: String = "1.0",
        requestID: String = UUID().uuidString,
        method: String,
        params: T,
        backendID: String = "sefariaEmbedded",
        sessionGeneration: UInt64 = 0,
        timeoutMs: Int = 15000
    ) throws {
        let data = try JSONEncoder().encode(params)
        let jsonStr = String(data: data, encoding: .utf8)
        self.init(
            protocolVersion: protocolVersion,
            requestID: requestID,
            method: method,
            paramsJson: jsonStr,
            backendID: backendID,
            sessionGeneration: sessionGeneration,
            timeoutMs: timeoutMs
        )
    }
}

struct SefariaRPCResponse: Codable, Sendable, Equatable {
    let protocolVersion: String
    let requestID: String
    let status: String // "success" or "error"
    let resultJson: String?
    let error: SefariaRPCError?
    let sessionGeneration: UInt64
    let backendID: String?

    var isSuccess: Bool {
        status == "success"
    }

    init(
        protocolVersion: String = "1.0",
        requestID: String,
        status: String,
        resultJson: String? = nil,
        error: SefariaRPCError? = nil,
        sessionGeneration: UInt64 = 0,
        backendID: String? = "sefariaEmbedded"
    ) {
        self.protocolVersion = protocolVersion
        self.requestID = requestID
        self.status = status
        self.resultJson = resultJson
        self.error = error
        self.sessionGeneration = sessionGeneration
        self.backendID = backendID
    }

    func decodeResult<T: Decodable>(_ type: T.Type) throws -> T {
        guard let resultJson = resultJson,
              let data = resultJson.data(using: .utf8) else {
            throw SefariaRPCError(
                code: "EMPTY_RESULT",
                message: "RPC response contained no result JSON payload for decoding \(T.self)"
            )
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
}

struct SefariaRPCError: Codable, Sendable, Equatable, LocalizedError {
    let code: String
    let message: String
    let retryable: Bool
    let details: String?

    var errorDescription: String? {
        "[\(code)] \(message)"
    }

    init(
        code: String,
        message: String,
        retryable: Bool = false,
        details: String? = nil
    ) {
        self.code = code
        self.message = message
        self.retryable = retryable
        self.details = details
    }
}

struct SefariaRPCEvent: Codable, Sendable, Equatable {
    let event: String
    let sequence: UInt64
    let backendID: String
    let payloadJson: String?

    init(
        event: String,
        sequence: UInt64,
        backendID: String = "sefariaEmbedded",
        payloadJson: String? = nil
    ) {
        self.event = event
        self.sequence = sequence
        self.backendID = backendID
        self.payloadJson = payloadJson
    }

    func decodePayload<T: Decodable>(_ type: T.Type) throws -> T {
        guard let payloadJson = payloadJson,
              let data = payloadJson.data(using: .utf8) else {
            throw SefariaRPCError(
                code: "EMPTY_PAYLOAD",
                message: "Event '\(event)' contained no payload JSON for decoding \(T.self)"
            )
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
}

import Observation
import Synchronization

/// Passive publication from an ORIGINAL MainActor setter. There is no value,
/// observer callback, authority, reset or rearm here. All retained records are
/// invalidated before that setter continues; the JS thread only sees the
/// existing thread-safe one-way latch and never calls back to this owner.
@MainActor
public final class NativeComponentSourcePublication {
    private struct Retained { weak var value: NativeComponentSourceObservation? }
    private var retained: [Retained] = []

    public init() {}

    fileprivate func register(_ observation: NativeComponentSourceObservation) {
        retained.removeAll { $0.value == nil }
        guard !retained.contains(where: { $0.value === observation }) else { return }
        retained.append(.init(value: observation))
    }

    public func invalidateRetainedSources() {
        let original = retained
        retained.removeAll(keepingCapacity: true)
        // invalidate() only takes its own Boolean lock. It cannot execute an
        // arbitrary observer or reenter the ORIGINAL setter/counter.
        for item in original { item.value?.invalidate() }
    }
}

/// A one-shot cancellation witness over ORIGINAL observable source reads.
/// Restoring the same values cannot restore a captured request. This is not a
/// source cache or an authority; the original identity/generation checks remain.
public final class NativeComponentSourceObservation: Sendable {
    private let invalidated = Mutex(false)

    @MainActor
    public init(publications: [NativeComponentSourcePublication] = [], read: @MainActor () -> Void) {
        // Registration precedes every original getter. A source publication
        // reentering a read therefore retires this exact observation too.
        for publication in publications { publication.register(self) }
        withObservationTracking {
            read()
        } onChange: { [weak self] in
            // Observation fires at willSet. Do not enqueue a Task: a complete
            // A -> B -> A edit can happen before a MainActor task resumes.
            self?.invalidate()
        }
    }

    /// Original non-Observation publishers may revoke this same latch. There is
    /// deliberately no reset, rearm or setter that can make a request live again.
    public func invalidate() {
        invalidated.withLock { $0 = true }
    }

    public func validate() throws {
        guard !invalidated.withLock({ $0 }) else {
            throw UIRouteError(.staleState, "native_component_source_changed")
        }
    }

    /// A source-locked final Boolean claim for the private RN handoff. The only
    /// application caller nests fixed one-way source latches and consumes its
    /// fixed ticket; it does not run UIKit, JS, actor work or a user callback.
    /// There is deliberately no reset or observation refresh in this operation.
    public func claimIfCurrent(_ claim: () -> Bool) -> Bool {
        invalidated.withLock { retired in
            guard !retired else { return false }
            return claim()
        }
    }
}

@MainActor final class MaktabahNativeComponentSourceObservation {
    nonisolated private let observation: NativeComponentSourceObservation
    private let coordinator: BackendCoordinator
    private let backend: BackendID
    private let generation: UInt64
    private let backendChanges: AnyCancellable

    init(publications: [NativeComponentSourcePublication] = [], read: @MainActor () -> Void) {
        let coordinator = BackendCoordinator.shared
        let observation = NativeComponentSourceObservation(publications: publications, read: read)
        self.coordinator = coordinator
        self.observation = observation
        backend = coordinator.activeBackendID
        generation = coordinator.generation
        backendChanges = coordinator.objectWillChange.sink { _ in
            observation.invalidate()
        }
    }

    func validate() throws {
        try observation.validate()
        guard BackendCoordinator.shared === coordinator, !coordinator.isTransitioning,
              coordinator.activeBackendID == backend, coordinator.generation == generation else {
            throw UIRouteError(.staleState, "native_component_backend_changed")
        }
    }

    /// The exact pre-await latch, including its ORIGINAL backend publisher.
    /// Returning it neither captures a new source nor grants an operation.
    nonisolated var retainedClaimObservation: NativeComponentSourceObservation { observation }
    nonisolated func invalidate() { observation.invalidate() }
}
import Foundation
import Observation

@MainActor protocol MaktabahNativeWorkspaceOwnerObserver: AnyObject {
    func workspaceOwnerWillChange()
}

/// Canonical storage for the lifecycle's actual workspace reference. The
/// owner-file proposal replaces its old @State reference, rather than copying
/// that reference into a second selection/permission model.
@MainActor @Observable final class MaktabahNativeWorkspaceOwner {
    @ObservationIgnored let nativePublication = NativeComponentSourcePublication()
    private var workspace: StudyWorkspaceNavigationAdapter?
    @ObservationIgnored private var changing = false
    @ObservationIgnored private weak var observer: (any MaktabahNativeWorkspaceOwnerObserver)?
    @ObservationIgnored private var token: UUID?
    var current: StudyWorkspaceNavigationAdapter? { changing ? nil : workspace }
    var isPublishing: Bool { changing }
    #if os(iOS)
    /// Only the exact original scene host installs this weak forwarding link.
    /// Outer original presentation modifiers can carry that same session across
    /// their UIHostingController boundary without looking up a global window.
    private(set) weak var nativeRoutingSession: MaktabahNativeSceneSession?

    func attachNativeRoutingSession(_ session: MaktabahNativeSceneSession) throws {
        guard session.mounted, session.usesWorkspaceOwner(self),
              current?.sceneID == session.sceneID.rawValue,
              nativeRoutingSession == nil || nativeRoutingSession === session
                || nativeRoutingSession?.mounted == false else {
            throw WorkspaceOwnerError.nativeRoutingOwnerMismatch
        }
        nativeRoutingSession = session
    }
    func detachNativeRoutingSession(_ session: MaktabahNativeSceneSession) {
        guard nativeRoutingSession === session else { return }
        nativeRoutingSession = nil
    }
    #endif

    func replace(with next: StudyWorkspaceNavigationAdapter?) throws {
        guard !changing else { throw WorkspaceOwnerError.reentrantPublication }
        guard workspace !== next else { return }
        nativePublication.invalidateRetainedSources()
        changing = true
        // Binding reads fail closed before the reference assignment itself.
        observer?.workspaceOwnerWillChange()
        workspace = next
        changing = false
    }
    func observe(_ observer: any MaktabahNativeWorkspaceOwnerObserver) throws -> UUID {
        guard self.observer == nil else { throw WorkspaceOwnerError.observerAlreadyInstalled }
        let token = UUID(); self.token = token; self.observer = observer
        return token
    }
    func cancelObservation(_ token: UUID) {
        guard self.token == token else { return }
        self.token = nil; observer = nil
    }
    isolated deinit {
        nativePublication.invalidateRetainedSources()
        observer?.workspaceOwnerWillChange()
    }
    enum WorkspaceOwnerError: Error { case reentrantPublication, observerAlreadyInstalled, nativeRoutingOwnerMismatch }
}

/// Actual mount and refresh both use this fixed weak source. Neither closure
/// captures an old adapter strongly. Legacy v1 may read a weak legacy reference;
/// that path is explicitly ineligible for future public binding.
@MainActor final class MaktabahNativeWorkspaceProjectionSource {
    private weak var owner: MaktabahNativeWorkspaceOwner?
    private weak var legacy: StudyWorkspaceNavigationAdapter?
    private let authoritative: Bool
    var isAuthoritative: Bool { authoritative }
    init(owner: MaktabahNativeWorkspaceOwner?, legacyWorkspace: StudyWorkspaceNavigationAdapter?) {
        self.owner = owner; legacy = legacyWorkspace; authoritative = owner != nil
    }
    /// The same original owner supplies only a passive publication latch.
    /// Legacy or currently publishing sources cannot issue a new observation.
    func originalPublication() throws -> NativeComponentSourcePublication {
        guard authoritative, let owner, !owner.isPublishing else {
            throw MaktabahNativeWorkspaceOwner.WorkspaceOwnerError.reentrantPublication
        }
        return owner.nativePublication
    }
    func read() throws -> StudyWorkspaceNavigationAdapter? {
        guard authoritative else { return legacy }
        guard let owner, !owner.isPublishing else { throw MaktabahNativeWorkspaceOwner.WorkspaceOwnerError.reentrantPublication }
        return owner.current
    }
    func uses(_ candidate: MaktabahNativeWorkspaceOwner) -> Bool { authoritative && owner === candidate }
    func projection<Value>(_ make: @escaping @MainActor (StudyWorkspaceNavigationAdapter?) throws -> Value) -> @MainActor () throws -> Value {
        { [self] in try make(read()) }
    }
}

//
//  SefariaJSRPCBridge.swift
//  Maktabah
//
//  Downstream-owned asynchronous RPC bridge between Swift and Sefaria-Mobile JS runtime.
//  Enforces single-resume continuations, actor-owned timeout handling, zero leaks,
//  generation guards, and event listener dispatching.
//

import Foundation

protocol SefariaJSTransport: AnyObject, Sendable {
    func sendToJS(jsonString: String) async throws
}

/// A synchronous, source-owned observation of the same RPC lifecycle fields.
/// The revision also changes for repeated listener/ready lifecycle publications.
struct SefariaEmbeddedSurfaceRuntimeObservation: Sendable, Equatable {
    fileprivate(set) var epoch: UInt64 = 1
    fileprivate(set) var revision: UInt64 = 0
    fileprivate(set) var ready = false
    fileprivate(set) var listeners = false
    fileprivate(set) var transport = false
    fileprivate(set) var resourceMutation = false
    fileprivate(set) var transitioning = false
    fileprivate(set) var exhausted = false
    var canPresent: Bool { ready && listeners && transport && !resourceMutation && !transitioning && !exhausted }
}

/// The RPC actor owns its readiness fields. The original native module also
/// begins invalidation boundaries synchronously, BEFORE queueing actor updates.
/// The same recursive lock covers native commit/report and these publications.
/// No actor call or suspension is permitted in that native critical section.
fileprivate final class SefariaRPCSessionEpoch: @unchecked Sendable {
    private let lock = NSRecursiveLock()
    private var state = SefariaEmbeddedSurfaceRuntimeObservation()
    private var transitionDepth: UInt64 = 0
    func read() -> UInt64 { surface().epoch }
    func surface() -> SefariaEmbeddedSurfaceRuntimeObservation {
        lock.lock(); defer { lock.unlock() }; return state
    }
    func update(_ change: (inout SefariaEmbeddedSurfaceRuntimeObservation) -> Void) {
        lock.lock(); defer { lock.unlock() }
        change(&state)
        if state.revision == .max { state.exhausted = true } else { state.revision += 1 }
    }
    func write(_ value: UInt64) { update { $0.epoch = value } }
    // The public bump operation is also called directly by RuntimeManager.reset.
    // Nested callers keep the OUTERMOST lifecycle boundary closed. No callback
    // or continuation is invoked while this short state-publication lock is held.
    func beginTransition() {
        lock.lock(); defer { lock.unlock() }
        if transitionDepth == .max { state.exhausted = true }
        else { transitionDepth += 1 }
        update { $0.transitioning = true }
    }
    func endTransition() {
        lock.lock(); defer { lock.unlock() }
        guard transitionDepth > 0 else {
            update { $0.exhausted = true }; return
        }
        transitionDepth -= 1
        update { $0.transitioning = transitionDepth > 0 }
    }
    func retainSurface() throws -> SefariaEmbeddedSurfaceRuntimeToken {
        lock.lock(); defer { lock.unlock() }
        guard state.canPresent else { throw unavailable() }
        return .init(authority: self, observation: state)
    }
    func validate(_ expected: SefariaEmbeddedSurfaceRuntimeObservation) throws {
        lock.lock(); defer { lock.unlock() }
        guard state == expected, state.canPresent else { throw unavailable() }
    }
    @MainActor func withSurface<T>(_ expected: SefariaEmbeddedSurfaceRuntimeObservation,
                                  operation: @MainActor () throws -> T) throws -> T {
        lock.lock(); defer { lock.unlock() }
        guard state == expected, state.canPresent else { throw unavailable() }
        let value = try operation()
        guard state == expected, state.canPresent else { throw unavailable() }
        return value
    }
    /// Closed native Boolean handoff only. Its fixed caller acquires source
    /// latches and a ticket; no actor hop, JS, UIKit or user callback runs here.
    func claimSurface(_ expected: SefariaEmbeddedSurfaceRuntimeObservation,
                      claim: () -> Bool) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard state == expected, state.canPresent else { return false }
        return claim()
    }
    private func unavailable() -> SefariaRPCError {
        .init(code: "SURFACE_RUNTIME_CHANGED", message: "The original Sefaria runtime is not available for this retained surface.")
    }
}

/// This token cannot be decoded from public navigation input or rearmed after a
/// lifecycle change. It retains the bridge's authority, not a MainActor cache.
final class SefariaEmbeddedSurfaceRuntimeToken: @unchecked Sendable {
    fileprivate let authority: SefariaRPCSessionEpoch
    let observation: SefariaEmbeddedSurfaceRuntimeObservation
    fileprivate init(authority: SefariaRPCSessionEpoch, observation: SefariaEmbeddedSurfaceRuntimeObservation) {
        self.authority = authority; self.observation = observation
    }
    func validate() throws { try authority.validate(observation) }
    @MainActor func withValidRuntime<T>(_ operation: @MainActor () throws -> T) throws -> T {
        try authority.withSurface(observation, operation: operation)
    }
    func claimIfCurrent(_ claim: () -> Bool) -> Bool {
        authority.claimSurface(observation, claim: claim)
    }
}

/// One exact source-owned native lifecycle boundary. Queueing an actor update
/// never leaves a window in which its already-started native mutation can borrow
/// an earlier ready state. Nested/out-of-order boundaries stay closed until all
/// finish. Dropping an unfinished lease does NOT manufacture completion.
final class SefariaEmbeddedSurfaceRuntimeTransition: @unchecked Sendable {
    private let authority: SefariaRPCSessionEpoch
    private let completionLock = NSLock()
    private var finished = false
    fileprivate init(authority: SefariaRPCSessionEpoch) {
        self.authority = authority
        authority.beginTransition()
    }
    func finish() {
        completionLock.lock()
        guard !finished else { completionLock.unlock(); return }
        finished = true
        completionLock.unlock()
        authority.endTransition()
    }
}

/// Exact metadata for the original diagnostic RPC only. These values neither
/// authorize navigation nor alter normal RPC cancellation or response handling.
struct SefariaLateReplyDiagnosticToken: Sendable, Equatable {
    fileprivate let id: UUID
    let nonce: String
    let originalEpoch: UInt64
    let delayMs: Int
    let timeoutMs: Int
}

struct SefariaLateReplyDiagnosticEvidence: Codable, Sendable, Equatable {
    let requestID: String
    let nonce: String
    let originalEpoch: UInt64
    let currentEpoch: UInt64
    let jsReceived: Bool
    let originalCancellation: Bool
    let disposition: String
}

actor SefariaJSRPCBridge {
    static let shared = SefariaJSRPCBridge()

    private struct InFlightRequest {
        let continuation: CheckedContinuation<SefariaRPCResponse, any Error>
        let generation: UInt64
        let timeoutTask: Task<Void, Never>
    }

    private var transport: (any SefariaJSTransport)? {
        didSet { epochAuthority.update { $0.transport = transport != nil } }
    }
    private var inFlightRequests: [String: InFlightRequest] = [:]
    private var eventListeners: [String: [@Sendable (SefariaRPCEvent) -> Void]] = [:]

    private(set) var isReady: Bool {
        get { epochAuthority.surface().ready }
        set { epochAuthority.update { $0.ready = newValue } }
    }
    private(set) var hasActiveListeners: Bool {
        get { epochAuthority.surface().listeners }
        set { epochAuthority.update { $0.listeners = newValue } }
    }
    private nonisolated let epochAuthority = SefariaRPCSessionEpoch()
    private(set) var sessionEpoch: UInt64 {
        get { epochAuthority.read() }
        set { epochAuthority.write(newValue) }
    }
    nonisolated var currentSessionEpoch: UInt64 { epochAuthority.read() }
    private var resourceMutationInProgress: Bool {
        get { epochAuthority.surface().resourceMutation }
        set { epochAuthority.update { $0.resourceMutation = newValue } }
    }
    nonisolated var currentSurfaceRuntimeObservation: SefariaEmbeddedSurfaceRuntimeObservation {
        epochAuthority.surface()
    }
    nonisolated func retainSurfaceRuntime() throws -> SefariaEmbeddedSurfaceRuntimeToken {
        try epochAuthority.retainSurface()
    }
    nonisolated func beginSurfaceLifecycleTransition() -> SefariaEmbeddedSurfaceRuntimeTransition {
        .init(authority: epochAuthority)
    }

    var resourcesAreStable: Bool { !resourceMutationInProgress }

    var hasTransport: Bool {
        return transport != nil
    }

    var isTransportReady: Bool {
        return isReady && transport != nil && hasActiveListeners
    }

    private init() {}

    func setSessionEpoch(_ epoch: UInt64) {
        guard epoch != sessionEpoch else { return }
        epochAuthority.beginTransition()
        defer { epochAuthority.endTransition() }
        cancelAll(reason: "Session epoch changed")
        isReady = false
        self.sessionEpoch = epoch
    }

    func bumpSessionEpoch() -> UInt64 {
        epochAuthority.beginTransition()
        defer { epochAuthority.endTransition() }
        cancelAll(reason: "Session epoch changed")
        sessionEpoch &+= 1
        return sessionEpoch
    }

    func setTransport(_ transport: (any SefariaJSTransport)?) {
        if let current = self.transport, let transport, current === transport { return }
        epochAuthority.beginTransition()
        defer { epochAuthority.endTransition() }
        // A replacement host must repeat its handshake. Old requests and
        // readiness cannot be carried across two Hermes instances.
        _ = bumpSessionEpoch()
        isReady = false
        hasActiveListeners = false
        self.transport = transport
        if transport == nil {
            self.isReady = false
            self.hasActiveListeners = false
            cancelAll(reason: "Transport detached")
        }
    }

    func clearTransportIfMatches(_ transport: any SefariaJSTransport) {
        if let current = self.transport, (current as AnyObject) === (transport as AnyObject) {
            epochAuthority.beginTransition()
            defer { epochAuthority.endTransition() }
            NSLog("[SefariaJSRPCBridge] clearTransportIfMatches: clearing transport")
            self.transport = nil
            _ = bumpSessionEpoch()
            self.isReady = false
            self.hasActiveListeners = false
            cancelAll(reason: "Transport invalidated")
        }
    }

    func notifyListenersActive(_ active: Bool) {
        NSLog("[SefariaJSRPCBridge] notifyListenersActive: %d", active)
        self.hasActiveListeners = active
    }

    /// Awaits validated readiness from the Sefaria Hermes runtime with generation and listener checks.
    func waitForReady(timeoutSeconds: Double = 30.0, expectedGeneration: UInt64? = nil) async throws {
        if isTransportReady {
            if let expected = expectedGeneration, sessionEpoch != expected {
                // Not matching expected generation, continue waiting below
            } else {
                NSLog("[SefariaJSRPCBridge] waitForReady: already ready with active transport and listeners")
                return
            }
        }

        NSLog("[SefariaJSRPCBridge] waitForReady: awaiting ready event (timeout: %.1fs)...", timeoutSeconds)
        let deadline = Date().addingTimeInterval(timeoutSeconds)
        while Date() < deadline {
            if isReady && transport != nil && hasActiveListeners {
                if let expected = expectedGeneration, sessionEpoch != expected {
                    // Waiting for matching epoch
                } else {
                    NSLog("[SefariaJSRPCBridge] waitForReady: successfully became ready!")
                    return
                }
            }
            try await Task.sleep(nanoseconds: 100_000_000)
        }

        if isReady && transport != nil && hasActiveListeners {
            if let expected = expectedGeneration, sessionEpoch != expected {
                // Mismatch
            } else {
                return
            }
        }

        let state = "isReady=\(isReady), transport=\(transport != nil), hasListeners=\(hasActiveListeners), sessionEpoch=\(sessionEpoch)"
        NSLog("[SefariaJSRPCBridge] waitForReady FAILED: %@", state)
        throw SefariaRPCError(
            code: "READY_TIMEOUT",
            message: "Timed out waiting for Sefaria JS runtime 'ready' event after \(timeoutSeconds)s (\(state))",
            retryable: true
        )
    }

    private func notifyReady() {
        NSLog("[SefariaJSRPCBridge] notifyReady: Hermes runtime ready event received!")
        isReady = true
    }

    /// Dispatches an RPC call to the Sefaria runtime with bounded timeout, generation tracking,
    /// and cancellation-safe continuation management.
    func call(
        method: String,
        paramsJson: String? = nil,
        generation: UInt64? = nil,
        timeoutMs: Int = 15000
    ) async throws -> SefariaRPCResponse {
        try Task.checkCancellation()
        // Invalidate read snapshots at both boundaries of a resource mutation.
        // Read-only action discovery never initiates one of these operations.
        let mutatesResources = ["downloads.install", "downloads.remove", "updates.download"].contains(method)
        if mutatesResources {
            guard !resourceMutationInProgress else {
                throw SefariaRPCError(code: "RESOURCE_BUSY", message: "Another resource operation is active", retryable: true)
            }
            if let generation, generation != sessionEpoch {
                throw SefariaRPCError(code: "STALE_GENERATION", message: "RPC session changed", retryable: true)
            }
            epochAuthority.beginTransition()
            _ = bumpSessionEpoch()
            resourceMutationInProgress = true
            epochAuthority.endTransition()
        }
        defer {
            if mutatesResources {
                epochAuthority.beginTransition()
                resourceMutationInProgress = false
                _ = bumpSessionEpoch()
                epochAuthority.endTransition()
            }
        }
        let requestID = UUID().uuidString
        let effectiveGeneration = mutatesResources ? sessionEpoch : generation ?? sessionEpoch
        guard effectiveGeneration == sessionEpoch else {
            throw SefariaRPCError(code: "STALE_GENERATION", message: "RPC session changed", retryable: true)
        }
        guard timeoutMs > 0, timeoutMs <= 600_000 else {
            throw SefariaRPCError(code: "INVALID_TIMEOUT", message: "RPC timeout is outside supported bounds")
        }
        let envelope = SefariaRPCEnvelope(
            protocolVersion: "1.0",
            requestID: requestID,
            method: method,
            paramsJson: paramsJson,
            backendID: BackendID.sefariaEmbedded.rawValue,
            sessionGeneration: effectiveGeneration,
            timeoutMs: timeoutMs
        )

        guard let transport = self.transport else {
            throw SefariaRPCError(
                code: "TRANSPORT_UNAVAILABLE",
                message: "React Native transport bridge is not initialized or ready.",
                retryable: true
            )
        }

        let encoder = JSONEncoder()
        guard let data = try? encoder.encode(envelope),
              let jsonString = String(data: data, encoding: .utf8) else {
            throw SefariaRPCError(
                code: "ENVELOPE_ENCODING_FAILED",
                message: "Failed to encode RPC envelope for method '\(method)'"
            )
        }

        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                self.registerInFlight(
                    requestID: requestID,
                    continuation: continuation,
                    generation: effectiveGeneration,
                    timeoutMs: timeoutMs,
                    method: method
                )
                self.observeLateReplyDispatch(envelope)
                Task {
                    do {
                        guard self.inFlightRequests[requestID] != nil,
                              self.sessionEpoch == effectiveGeneration else { return }
                        try await transport.sendToJS(jsonString: jsonString)
                    } catch {
                        self.failInFlight(requestID: requestID, error: error)
                    }
                }
            }
        } onCancel: {
            Task {
                await self.cancelInFlight(requestID: requestID)
            }
        }
    }

    private func registerInFlight(
        requestID: String,
        continuation: CheckedContinuation<SefariaRPCResponse, any Error>,
        generation: UInt64,
        timeoutMs: Int,
        method: String
    ) {
        let timeoutTask = Task { [weak self, requestID, method, timeoutMs] in
            try? await Task.sleep(nanoseconds: UInt64(timeoutMs) * 1_000_000)
            await self?.handleTimeout(requestID: requestID, method: method, timeoutMs: timeoutMs)
        }
        inFlightRequests[requestID] = InFlightRequest(
            continuation: continuation,
            generation: generation,
            timeoutTask: timeoutTask
        )
    }

    private func handleTimeout(requestID: String, method: String, timeoutMs: Int) {
        guard let req = inFlightRequests.removeValue(forKey: requestID) else { return }
        req.continuation.resume(throwing: SefariaRPCError(
            code: "TIMEOUT",
            message: "RPC call to '\(method)' timed out after \(timeoutMs)ms",
            retryable: true
        ))
    }

    func handleIncomingResponse(jsonString: String) {
        guard let data = jsonString.data(using: .utf8),
              let response = try? JSONDecoder().decode(SefariaRPCResponse.self, from: data) else {
            return
        }

        guard let req = inFlightRequests.removeValue(forKey: response.requestID) else {
            // Late response after timeout or stale request - safely ignored
            observeLateReplyResponse(response, wasInFlight: false)
            return
        }
        observeLateReplyResponse(response, wasInFlight: true)
        req.timeoutTask.cancel()

        // Validate protocol version
        if response.protocolVersion != "1.0" {
            req.continuation.resume(throwing: SefariaRPCError(
                code: "PROTOCOL_VERSION_MISMATCH",
                message: "Response protocol version '\(response.protocolVersion)' is incompatible with expected '1.0'",
                retryable: false
            ))
            return
        }

        // Validate backend ID if specified in response
        if let backendID = response.backendID, !backendID.isEmpty, backendID != BackendID.sefariaEmbedded.rawValue {
            req.continuation.resume(throwing: SefariaRPCError(
                code: "BACKEND_MISMATCH",
                message: "Response backend '\(backendID)' does not match expected '\(BackendID.sefariaEmbedded.rawValue)'",
                retryable: false
            ))
            return
        }

        // Strict generation validation: response must match in-flight generation (no zero-bypass)
        if response.sessionGeneration != req.generation || req.generation != sessionEpoch {
            req.continuation.resume(throwing: SefariaRPCError(
                code: "STALE_GENERATION",
                message: "Response generation \(response.sessionGeneration) does not match in-flight generation \(req.generation)",
                retryable: false
            ))
            return
        }

        req.continuation.resume(returning: response)
    }

    private func failInFlight(requestID: String, error: any Error) {
        guard let req = inFlightRequests.removeValue(forKey: requestID) else { return }
        req.timeoutTask.cancel()
        req.continuation.resume(throwing: error)
    }

    private func cancelInFlight(requestID: String) {
        guard let req = inFlightRequests.removeValue(forKey: requestID) else { return }
        req.timeoutTask.cancel()
        req.continuation.resume(throwing: CancellationError())
    }

    /// Cancels all pending in-flight requests (e.g. during a backend switch or runtime reset).
    func cancelAll(reason: String = "Session invalidated") {
        for (requestID, req) in inFlightRequests {
            observeLateReplyCancellation(requestID: requestID, generation: req.generation, reason: reason)
            req.timeoutTask.cancel()
            req.continuation.resume(throwing: SefariaRPCError(code: "CANCELLED", message: reason, retryable: false))
        }
        inFlightRequests.removeAll()
    }

    func cancelAllInFlight() {
        cancelAll(reason: "Backend invalidated")
    }

    // MARK: - Bounded real-transport diagnostic observation

    private struct LateReplyWireProof: Decodable {
        let contract: String
        let requestID: String
        let nonce: String
        let sessionGeneration: UInt64
        let delayMs: Int
    }
    private struct LateReplyParameters: Decodable {
        struct Options: Decodable {
            let contract: String
            let nonce: String
            let delayMs: Int
        }
        let lateReplyDiagnostic: Options
    }
    private struct LateReplyResult: Decodable {
        let lateReplyDiagnostic: LateReplyWireProof
    }
    private final class LateReplyObservation {
        let token: SefariaLateReplyDiagnosticToken
        let transport: any SefariaJSTransport
        let deadline: ContinuousClock.Instant
        var requestID: String?
        var jsReceived = false
        var originalCancellation = false
        var discarded: SefariaLateReplyDiagnosticEvidence?
        var failure: SefariaRPCError?
        init(token: SefariaLateReplyDiagnosticToken, transport: any SefariaJSTransport) {
            self.token = token
            self.transport = transport
            self.deadline = ContinuousClock.now.advanced(by: .milliseconds(token.timeoutMs))
        }
    }
    private var lateReplyObservation: LateReplyObservation?

    func beginLateReplyDiagnostic(nonce: UUID, delayMs: Int, timeoutMs: Int) throws -> SefariaLateReplyDiagnosticToken {
        guard lateReplyObservation == nil, isTransportReady, resourcesAreStable,
              currentSurfaceRuntimeObservation.canPresent,
              let transport, sessionEpoch > 0, sessionEpoch < 9_007_199_254_740_991,
              (1...3_000).contains(delayMs), timeoutMs > delayMs, timeoutMs <= 10_000 else {
            throw lateReplyFailure("DIAGNOSTIC_UNAVAILABLE")
        }
        let token = SefariaLateReplyDiagnosticToken(id: UUID(), nonce: nonce.uuidString,
            originalEpoch: sessionEpoch, delayMs: delayMs, timeoutMs: timeoutMs)
        lateReplyObservation = LateReplyObservation(token: token, transport: transport)
        return token
    }

    func endLateReplyDiagnostic(_ token: SefariaLateReplyDiagnosticToken) {
        guard lateReplyObservation?.token == token else { return }
        lateReplyObservation = nil
    }

    func waitForLateReplyJSReceipt(_ token: SefariaLateReplyDiagnosticToken) async throws {
        while true {
            try Task.checkCancellation()
            let observation = try lateReplyState(token)
            if observation.jsReceived { return }
            // This only waits for an actual JS event recorded by the original
            // actor; elapsed time is never a received/discarded acknowledgement.
            try await Task.sleep(for: .milliseconds(10))
        }
    }

    func validateLateReplyBeforeReset(_ token: SefariaLateReplyDiagnosticToken) throws {
        let observation = try lateReplyState(token)
        guard sessionEpoch == token.originalEpoch, observation.jsReceived,
              !observation.originalCancellation, observation.discarded == nil,
              let requestID = observation.requestID,
              inFlightRequests[requestID]?.generation == token.originalEpoch else {
            throw lateReplyFailure("DIAGNOSTIC_NOT_IN_FLIGHT")
        }
    }

    func validateLateReplyAfterReset(_ token: SefariaLateReplyDiagnosticToken) throws {
        let observation = try lateReplyState(token)
        guard sessionEpoch == token.originalEpoch + 1, observation.jsReceived,
              observation.originalCancellation, let requestID = observation.requestID,
              inFlightRequests[requestID] == nil else {
            throw lateReplyFailure("DIAGNOSTIC_RESET_NOT_OBSERVED")
        }
    }

    func waitForDiscardedLateReply(_ token: SefariaLateReplyDiagnosticToken) async throws -> SefariaLateReplyDiagnosticEvidence {
        while true {
            try Task.checkCancellation()
            try validateLateReplyAfterReset(token)
            if let evidence = try lateReplyState(token).discarded { return evidence }
            try await Task.sleep(for: .milliseconds(10))
        }
    }

    func validateLateReplyCompletion(_ token: SefariaLateReplyDiagnosticToken,
                                     evidence: SefariaLateReplyDiagnosticEvidence) throws {
        try validateLateReplyAfterReset(token)
        guard try lateReplyState(token).discarded == evidence else {
            throw lateReplyFailure("DIAGNOSTIC_RECEIPT_CHANGED")
        }
    }

    private func lateReplyState(_ token: SefariaLateReplyDiagnosticToken) throws -> LateReplyObservation {
        guard let observation = lateReplyObservation, observation.token == token else {
            throw lateReplyFailure("DIAGNOSTIC_RETIRED")
        }
        if let failure = observation.failure { throw failure }
        guard ContinuousClock.now < observation.deadline else {
            throw lateReplyFailure("DIAGNOSTIC_DEADLINE_EXCEEDED")
        }
        guard let transport, transport === observation.transport, isTransportReady,
              resourcesAreStable else {
            throw lateReplyFailure("DIAGNOSTIC_TRANSPORT_CHANGED")
        }
        return observation
    }

    private func lateReplyFailure(_ code: String) -> SefariaRPCError {
        .init(code: code, message: "The original delayed RPC proof is incomplete or changed.")
    }

    private func failLateReply(_ observation: LateReplyObservation, _ code: String) {
        // A diagnostic observation never cancels/resumes or admits an RPC.
        if observation.failure == nil { observation.failure = lateReplyFailure(code) }
    }

    private func observeLateReplyDispatch(_ envelope: SefariaRPCEnvelope) {
        guard envelope.method == "diagnostic.echo", let observation = lateReplyObservation,
              let params = envelope.paramsJson?.data(using: .utf8),
              let options = try? JSONDecoder().decode(LateReplyParameters.self, from: params).lateReplyDiagnostic else { return }
        guard observation.requestID == nil, options.contract == "chavrusa.diagnostic.late-reply.v1",
              options.nonce == observation.token.nonce, options.delayMs == observation.token.delayMs,
              envelope.sessionGeneration == observation.token.originalEpoch,
              envelope.timeoutMs == observation.token.timeoutMs,
              (try? lateReplyState(observation.token)) != nil else {
            failLateReply(observation, "DIAGNOSTIC_DISPATCH_MISMATCH"); return
        }
        observation.requestID = envelope.requestID
    }

    private func observeLateReplyStarted(_ event: SefariaRPCEvent) {
        guard event.event == "diagnostic.echo.started", let observation = lateReplyObservation else { return }
        guard event.backendID == BackendID.sefariaEmbedded.rawValue,
              let json = event.payloadJson, json.utf8.count <= 1_024,
              let proof = try? JSONDecoder().decode(LateReplyWireProof.self, from: Data(json.utf8)),
              proof.contract == "chavrusa.diagnostic.late-reply.v1",
              proof.requestID == observation.requestID, proof.nonce == observation.token.nonce,
              proof.sessionGeneration == observation.token.originalEpoch,
              proof.delayMs == observation.token.delayMs, !observation.jsReceived,
              !observation.originalCancellation, sessionEpoch == observation.token.originalEpoch,
              inFlightRequests[proof.requestID]?.generation == observation.token.originalEpoch,
              (try? lateReplyState(observation.token)) != nil else {
            failLateReply(observation, "DIAGNOSTIC_JS_RECEIPT_MISMATCH"); return
        }
        observation.jsReceived = true
    }

    private func observeLateReplyCancellation(requestID: String, generation: UInt64, reason: String) {
        guard let observation = lateReplyObservation, observation.requestID == requestID else { return }
        guard observation.jsReceived, !observation.originalCancellation, observation.discarded == nil,
              reason == "Session epoch changed", generation == observation.token.originalEpoch,
              sessionEpoch == observation.token.originalEpoch else {
            failLateReply(observation, "DIAGNOSTIC_CANCELLATION_MISMATCH"); return
        }
        observation.originalCancellation = true
    }

    private func observeLateReplyResponse(_ response: SefariaRPCResponse, wasInFlight: Bool) {
        guard let observation = lateReplyObservation, response.requestID == observation.requestID else { return }
        guard !wasInFlight, observation.jsReceived, observation.originalCancellation,
              observation.discarded == nil, response.protocolVersion == "1.0",
              response.backendID == BackendID.sefariaEmbedded.rawValue, response.isSuccess, response.error == nil,
              response.sessionGeneration == observation.token.originalEpoch,
              sessionEpoch == observation.token.originalEpoch + 1,
              let json = response.resultJson, json.utf8.count <= 2_048,
              let proof = try? JSONDecoder().decode(LateReplyResult.self, from: Data(json.utf8)).lateReplyDiagnostic,
              proof.contract == "chavrusa.diagnostic.late-reply.v1",
              proof.requestID == response.requestID, proof.nonce == observation.token.nonce,
              proof.sessionGeneration == response.sessionGeneration, proof.delayMs == observation.token.delayMs,
              (try? lateReplyState(observation.token)) != nil else {
            failLateReply(observation, "DIAGNOSTIC_LATE_DISPOSITION_MISMATCH"); return
        }
        observation.discarded = .init(requestID: response.requestID, nonce: observation.token.nonce,
            originalEpoch: response.sessionGeneration, currentEpoch: sessionEpoch,
            jsReceived: true, originalCancellation: true, disposition: "discarded_no_in_flight_request")
    }

    // MARK: - Event Subscriptions

    func addEventListener(for eventName: String, listener: @escaping @Sendable (SefariaRPCEvent) -> Void) {
        var listeners = eventListeners[eventName] ?? []
        listeners.append(listener)
        eventListeners[eventName] = listeners
    }

    func handleIncomingEvent(jsonString: String) {
        NSLog("[SefariaJSRPCBridge] handleIncomingEvent: %@", jsonString)
        guard let data = jsonString.data(using: .utf8),
              let event = try? JSONDecoder().decode(SefariaRPCEvent.self, from: data) else {
            return
        }

        observeLateReplyStarted(event)
        if event.event == "ready" {
            notifyReady()
        } else if event.event == "bootstrapError" {
            NSLog("[SefariaJSRPCBridge] bootstrapError received: %@", event.payloadJson ?? "")
            isReady = false
        }

        if let listeners = eventListeners[event.event] {
            for listener in listeners {
                listener(event)
            }
        }
    }
}

import Foundation

/// A native mount identity, never a public content locator or a JS navigation command.
struct SefariaEmbeddedSurfaceIdentity: Identifiable, Equatable, Sendable {
    let id: UUID
    let mountID: UUID
    let sceneID: String
    let epoch: UInt64

    var properties: [String: Any] {
        ["surfaceID": id.uuidString, "mountID": mountID.uuidString,
         "sceneID": sceneID, "epoch": epoch]
    }
    var valid: Bool {
        !sceneID.isEmpty && sceneID.count <= 256 && epoch > 0 && epoch <= 9_007_199_254_740_991
    }
}

/// Returned only after a real original ReaderApp instance completed its own init
/// and the React Native layout callback supplied nonzero original geometry.
struct SefariaEmbeddedSurfaceProof: Codable, Equatable, Sendable {
    struct Layout: Codable, Equatable, Sendable {
        let width: Double
        let height: Double
        let revision: UInt64
    }
    let contract: String
    let component: String
    let upstreamSHA: String
    let surfaceID: UUID
    let mountID: UUID
    let sceneID: String
    let epoch: UInt64
    let nonce: UUID
    let layout: Layout

    func matches(_ identity: SefariaEmbeddedSurfaceIdentity, nonce expectedNonce: UUID) -> Bool {
        identity.valid && contract == "chavrusa.original-rn-surface.v1" && component == "ReaderApp"
            && upstreamSHA == "2fd173a5a3bd32d94a9ba1222e4e32a37f6bd23c"
            && surfaceID == identity.id && mountID == identity.mountID
            && sceneID == identity.sceneID && epoch == identity.epoch && nonce == expectedNonce
            && layout.revision > 0 && layout.width.isFinite && layout.height.isFinite
            && layout.width > 0 && layout.height > 0
    }
}

/// Produced from the actual canonical receipt and the same still-visible native
/// host. Allocation, a headless handshake or a cached proof cannot construct it.
struct SefariaEmbeddedSurfaceAcceptanceEvidence: Codable, Sendable {
    let nativeReceiptID: UUID
    let nativeSceneID: String
    let nativeHostToken: UUID
    let runtimeRevision: UInt64
    let originalSurface: SefariaEmbeddedSurfaceProof
}

/// Original ReaderApp has process-wide tracker registrations. Keep at most one
/// visible original instance and never transfer it across scenes. Headless RPC
/// is independent and is neither claimed nor moved by this lease.
@MainActor final class SefariaEmbeddedSurfaceLease {
    static let shared = SefariaEmbeddedSurfaceLease()
    struct Lease: Equatable {
        let ownerID: UUID
        let identity: SefariaEmbeddedSurfaceIdentity
        let revision: UInt64
    }
    struct Snapshot: Equatable {
        let revision: UInt64
        let lease: Lease?
        let exhausted: Bool
    }
    private var revision: UInt64 = 0
    private var lease: Lease?
    private var exhausted = false
    var snapshot: Snapshot { .init(revision: revision, lease: lease, exhausted: exhausted) }

    func acquire(ownerID: UUID, identity: SefariaEmbeddedSurfaceIdentity,
                 expected: Snapshot) throws -> Lease {
        guard identity.valid, snapshot == expected, !exhausted, lease == nil, revision < .max else {
            throw SefariaRPCError(code: "SURFACE_LEASE_UNAVAILABLE", message: "The original Sefaria surface is unavailable.")
        }
        revision += 1
        let value = Lease(ownerID: ownerID, identity: identity, revision: revision)
        lease = value
        return value
    }
    func owns(_ value: Lease) -> Bool { !exhausted && lease == value }
    func release(_ value: Lease) {
        guard lease == value else { return }
        lease = nil
        if revision == .max { exhausted = true } else { revision += 1 }
    }
}

import Foundation

/// Fixed navigation destinations over the pinned ORIGINAL ReaderApp. These are
/// not selectors, text locators, queries, scripts or an independent executor.
enum SefariaEmbeddedSemanticTarget: String, Codable, CaseIterable, Sendable {
    case library, topics, learningSchedules, dedication

    var destinationID: String { "native.sefariaEmbedded." + rawValue }
    var isPublicNavigation: Bool { self != .dedication }
    var originalMenu: String {
        switch self {
        case .library: "navigation"
        case .topics: "topic toc"
        case .learningSchedules: "learning schedules"
        case .dedication: "dedication"
        }
    }
    var originalHeaderKey: String {
        switch self {
        case .library: "nav.browse_the_library"
        case .topics: "topics.explore_by_topic"
        case .learningSchedules: "learning_schedules.learning_schedules"
        case .dedication: "about.app_for_ios_and_android"
        }
    }
    /// Read-only witness text from the exact 2fd173a5 original en/he JSON. It is
    /// never rendered by this adapter. The schedules title is also in Library,
    /// so its original page-only description is mandatory as a second witness.
    func originalVisibleTexts(language: String) -> [String]? {
        guard language == "english" || language == "hebrew" else { return nil }
        let hebrew = language == "hebrew"
        switch self {
        case .library: return [hebrew ? "עיון בספריה" : "Browse the Library"]
        case .topics: return [hebrew ? "חיפוש לפי נושאים" : "Explore by Topic"]
        case .learningSchedules:
            return hebrew ? ["לוח לימוד יומי", "מימי קדם חולקה התורה לקטעי קריאה שבועיים שנועדו לסיום הספר כולו במשך תקופת זמן של שנה. בעקבות המנהג הזה התפתחו לאורך השנים סדרי לימוד תקופתיים רבים נוספים, ובעזרתם יכולות קהילות וקבוצות של לומדים ללמוד יחד טקסטים שלמים."]
                : ["Learning Schedules", "Since biblical times, the Torah has been divided into sections which are read each week on a set yearly calendar. Following this practice, many other calendars have been created to help communities of learners work through specific texts together."]
        case .dedication: return [hebrew ? "האפליקציה של ספריא עבור אנדרואיד ו-iOS" : "Sefaria App for iOS and Android"]
        }
    }
}

/// Private native-to-JS handoff identity. Public routing never decodes this type.
struct SefariaEmbeddedSemanticClaim: Codable, Equatable, Sendable {
    let ticketID: UUID
    let requestID: UUID
    let surfaceID: UUID
    let mountID: UUID
    let sceneID: String
    let epoch: UInt64
    let target: SefariaEmbeddedSemanticTarget
    let nonce: UUID

    static let fieldNames: Set<String> = ["ticketID", "requestID", "surfaceID", "mountID", "sceneID", "epoch", "target", "nonce"]
}

/// This record can only be created during the original Core apply. The claim
/// is the linearization point of its one original JS method invocation. No
/// callback, actor hop, I/O or JS execution is performed inside these locks.
final class SefariaEmbeddedSemanticTicket: @unchecked Sendable {
    let claim: SefariaEmbeddedSemanticClaim
    let deadlineUptimeNanoseconds: UInt64
    private let runtime: SefariaEmbeddedSurfaceRuntimeToken
    private let rootSource: NativeComponentSourceObservation
    private let originalSource: NativeComponentSourceObservation
    private let lock = NSLock()
    private var hostToken: UUID?
    private var claimed = false
    private var revoked = false

    init(requestID: UUID, identity: SefariaEmbeddedSurfaceIdentity,
         target: SefariaEmbeddedSemanticTarget, deadlineUptimeNanoseconds: UInt64,
         runtime: SefariaEmbeddedSurfaceRuntimeToken,
         rootSource: NativeComponentSourceObservation,
         originalSource: NativeComponentSourceObservation) throws {
        guard identity.valid, identity.epoch == runtime.observation.epoch,
              rootSource !== originalSource,
              deadlineUptimeNanoseconds > DispatchTime.now().uptimeNanoseconds else {
            throw SefariaRPCError(code: "SEMANTIC_HANDOFF_INVALID", message: "The original navigation admission is unavailable.")
        }
        claim = .init(ticketID: UUID(), requestID: requestID, surfaceID: identity.id,
            mountID: identity.mountID, sceneID: identity.sceneID, epoch: identity.epoch,
            target: target, nonce: UUID())
        self.deadlineUptimeNanoseconds = deadlineUptimeNanoseconds
        self.runtime = runtime; self.rootSource = rootSource; self.originalSource = originalSource
    }

    /// Caller already holds/revalidates the original MainActor source and Core
    /// admission. Only its exact first native host may arm this existing ticket.
    /// This method cannot create/renew a ticket, source or deadline.
    func arm(originalHostToken: UUID) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard !revoked, !claimed, hostToken == nil,
              DispatchTime.now().uptimeNanoseconds < deadlineUptimeNanoseconds else { return false }
        hostToken = originalHostToken
        return true
    }

    /// Lock order is fixed: runtime -> parent latch -> original/backend latch
    /// -> ticket. Publication/revocation acquires one latch only and never calls
    /// back into this path. There is no external/JS/user callback in this chain.
    fileprivate func consume(_ actual: SefariaEmbeddedSemanticClaim) -> Bool {
        guard actual == claim else { return false }
        return runtime.claimIfCurrent {
            rootSource.claimIfCurrent {
                originalSource.claimIfCurrent {
                    lock.lock(); defer { lock.unlock() }
                    guard !revoked, !claimed, hostToken != nil,
                          DispatchTime.now().uptimeNanoseconds < deadlineUptimeNanoseconds else { return false }
                    claimed = true
                    return true
                }
            }
        }
    }

    /// Cancellation invokes this synchronously, before queued MainActor cleanup.
    /// If the claim already won, keep that fact: original React work may commit.
    func revoke() {
        lock.lock(); defer { lock.unlock() }; revoked = true
    }
    var wasClaimed: Bool {
        lock.lock(); defer { lock.unlock() }; return claimed
    }
    var isArmed: Bool {
        lock.lock(); defer { lock.unlock() }; return hostToken != nil
    }
    var canSupportEvidence: Bool {
        lock.lock(); defer { lock.unlock() }; return claimed && !revoked && hostToken != nil
    }
    func matchesOriginalHost(_ token: UUID) -> Bool {
        lock.lock(); defer { lock.unlock() }; return hostToken == token
    }
}

/// Only the existing native module's closed synchronous export consumes records.
/// The registry lock is released before the source locks; retirement cannot form
/// a reverse lock edge. No public method creates a ticket from a JSON payload.
final class SefariaEmbeddedSemanticHandoffs: @unchecked Sendable {
    static let shared = SefariaEmbeddedSemanticHandoffs()
    private let lock = NSLock()
    private var tickets: [UUID: SefariaEmbeddedSemanticTicket] = [:]

    func register(_ ticket: SefariaEmbeddedSemanticTicket) throws {
        lock.lock(); defer { lock.unlock() }
        guard tickets[ticket.claim.ticketID] == nil else {
            throw SefariaRPCError(code: "SEMANTIC_HANDOFF_DUPLICATE", message: "The original navigation admission is already registered.")
        }
        tickets[ticket.claim.ticketID] = ticket
    }
    func remove(_ ticket: SefariaEmbeddedSemanticTicket, revoke: Bool) {
        if revoke { ticket.revoke() }
        lock.lock(); defer { lock.unlock() }
        if tickets[ticket.claim.ticketID] === ticket { tickets.removeValue(forKey: ticket.claim.ticketID) }
    }
    func claim(_ json: String) -> Bool {
        guard let data = json.data(using: .utf8), data.count <= 4096,
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              Set(object.keys) == SefariaEmbeddedSemanticClaim.fieldNames,
              let actual = try? JSONDecoder().decode(SefariaEmbeddedSemanticClaim.self, from: data) else { return false }
        lock.lock()
        let ticket = tickets[actual.ticketID]
        lock.unlock()
        return ticket?.consume(actual) == true
    }
}

/// Selected ORIGINAL state is observed on an actual JS frame after the original
/// method. It is only one part of acceptance: the real original native text and
/// geometry witness, retained source and canonical receipt remain mandatory.
struct SefariaEmbeddedSemanticProof: Codable, Equatable, Sendable {
    let contract: String
    let claim: SefariaEmbeddedSemanticClaim
    let originalSurface: SefariaEmbeddedSurfaceProof
    let originalMenu: String
    let originalHeaderKey: String
    let interfaceLanguage: String
    let originalRootSelection: Bool
    let originalInstanceRetained: Bool
    let observedAfterOriginalCall: Bool

    func matches(_ ticket: SefariaEmbeddedSemanticTicket, identity: SefariaEmbeddedSurfaceIdentity) -> Bool {
        contract == "chavrusa.original-rn-target.v1" && claim == ticket.claim
            && ticket.canSupportEvidence
            && originalSurface.matches(identity, nonce: claim.nonce)
            && originalMenu == claim.target.originalMenu
            && originalHeaderKey == claim.target.originalHeaderKey
            && claim.target.originalVisibleTexts(language: interfaceLanguage) != nil
            && originalRootSelection && originalInstanceRetained && observedAfterOriginalCall
    }
}

struct SefariaEmbeddedSemanticAcceptanceEvidence: Codable, Sendable {
    let nativeReceiptID: UUID
    let nativeSceneID: String
    let nativeHostToken: UUID
    let runtimeRevision: UInt64
    let actualOriginalViewCount: Int
    let originalTarget: SefariaEmbeddedSemanticProof
}

@MainActor @Observable
final class MaktabahNativeSefariaSurfaceBinding: SefariaEmbeddedNativeSurfaceObserver {
    static let destination = UIDestinationID(rawValue: "native.sefariaEmbedded")!
    static func semanticTarget(for destination: UIDestinationID) -> SefariaEmbeddedSemanticTarget? {
        SefariaEmbeddedSemanticTarget.allCases.first { $0.destinationID == destination.rawValue }
    }
    static func accepts(_ destination: UIDestinationID) -> Bool {
        destination == Self.destination || semanticTarget(for: destination) != nil
    }
    struct PresentationFacets {
        let requested: Bool
        let mounted: Bool
        let visible: Bool
        let transitioning: Bool
        let ready: Bool
    }
    let sceneID: UIStableID
    private(set) var presentation: SefariaEmbeddedSurfaceIdentity?
    private(set) var renderRevision: UInt64 = 0
    @ObservationIgnored private let ownerID = UUID()
    @ObservationIgnored private weak var manager: iOSNavigationManager?
    @ObservationIgnored private let workspaceSource: MaktabahNativeWorkspaceProjectionSource
    @ObservationIgnored private var sources: [UUID: SourceEntry] = [:]
    @ObservationIgnored private var pending: Pending?
    @ObservationIgnored private var lease: SefariaEmbeddedSurfaceLease.Lease?
    @ObservationIgnored private weak var host: SefariaEmbeddedNativeSurfaceController?
    @ObservationIgnored private var presentationRevision: UInt64 = 0
    @ObservationIgnored private var presentationCreator: (requestID: UUID, identity: UUID)?
    @ObservationIgnored private var retired = false
    @ObservationIgnored private var readinessRequestID: UUID?
    @ObservationIgnored private var hostWaiter: Waiter?
    @ObservationIgnored private var invalidationWaiter: Waiter?
    @ObservationIgnored private var semanticWaiter: Waiter?
    @ObservationIgnored private var proof: ObservedProof?
    @ObservationIgnored private var completed: Completed?
    @ObservationIgnored private var changed: @MainActor () -> Void = {}
    @ObservationIgnored private var invalidated: @MainActor () -> Void = {}

    @MainActor private final class OriginalSourceProof {
        let runtime: SefariaEmbeddedSurfaceRuntimeToken
        private let observation: MaktabahNativeComponentSourceObservation
        private let source: MaktabahNativeWorkspaceProjectionSource
        private weak var workspace: StudyWorkspaceNavigationAdapter?
        private weak var manager: iOSNavigationManager?
        private let sceneID: String
        private let stored: StudyWorkspaceMappingObservation
        private let native: StudyWorkspaceMappingObservation
        private var valid = true

        static func inspect(sceneID: String, manager: iOSNavigationManager,
                            source: MaktabahNativeWorkspaceProjectionSource) throws
            -> (StudyWorkspaceNavigationAdapter, StudyWorkspaceMappingObservation, StudyWorkspaceMappingObservation) {
            guard source.isAuthoritative, let workspace = try source.read(),
                  workspace.sceneID == sceneID, workspace.attached, !workspace.isSwitching,
                  workspace.errorMessage == nil, workspace.store.loadError == nil,
                  !BackendCoordinator.shared.isTransitioning,
                  BackendCoordinator.shared.activeBackendID == .sefariaEmbedded,
                  BackendCoordinator.shared.activeCapabilities.contains(.catalog),
                  BackendCoordinator.shared.activeCapabilities.contains(.reading),
                  let stored = workspace.store.mappingObservation(scene: sceneID),
                  let native = workspace.mappingOwnershipObservation(),
                  stored.owner == ObjectIdentifier(workspace.store), stored.scene == sceneID,
                  native.owner == ObjectIdentifier(manager), native.scene == sceneID,
                  case .workspaceStoreOnly = stored.coverage,
                  case .liveNativeSetters = native.coverage else {
                throw UIRouteError(.unavailable, "native_sefaria_original_source_unavailable")
            }
            return (workspace, stored, native)
        }
        init(sceneID: String, manager: iOSNavigationManager,
             source: MaktabahNativeWorkspaceProjectionSource) throws {
            let publication = try source.originalPublication()
            var inspected: (StudyWorkspaceNavigationAdapter, StudyWorkspaceMappingObservation, StudyWorkspaceMappingObservation)?
            var inspectionError: (any Error)?
            // Register with the ORIGINAL owner before the first source getter.
            // The latch also precedes its prepublication/deinit callbacks.
            let captured = MaktabahNativeComponentSourceObservation(publications: [publication]) {
                do {
                    let current = try Self.inspect(sceneID: sceneID, manager: manager, source: source)
                    inspected = current
                    _ = current.0.attached; _ = current.0.isSwitching
                    _ = current.0.errorMessage; _ = current.0.store.loadError
                    _ = current.1.source.event; _ = current.2.source.event
                } catch { inspectionError = error }
            }
            if let inspectionError { throw inspectionError }
            guard let (workspace, stored, native) = inspected else {
                throw UIRouteError(.unavailable, "native_sefaria_original_source_unavailable")
            }
            try captured.validate()
            runtime = try SefariaJSRPCBridge.shared.retainSurfaceRuntime()
            self.workspace = workspace; self.manager = manager; self.source = source
            self.sceneID = sceneID; self.stored = stored; self.native = native
            observation = captured
        }
        var claimObservation: NativeComponentSourceObservation { observation.retainedClaimObservation }
        func invalidate() { valid = false; observation.invalidate() }
        func validate() throws {
            try runtime.validate(); try observation.validate()
            guard valid, let workspace, let manager, try source.read() === workspace else {
                throw UIRouteError(.staleState, "native_sefaria_original_source_changed")
            }
            let (actual, storedNow, nativeNow) = try Self.inspect(sceneID: sceneID, manager: manager, source: source)
            guard actual === workspace, storedNow.source === stored.source, storedNow.epoch == stored.epoch,
                  storedNow.owner == stored.owner, nativeNow.source === native.source,
                  nativeNow.epoch == native.epoch, nativeNow.owner == native.owner else {
                throw UIRouteError(.staleState, "native_sefaria_original_mapping_changed")
            }
        }
    }
    @MainActor private final class SourceEntry {
        let original: OriginalSourceProof
        let target: SefariaEmbeddedSemanticTarget?
        let parentClaimObservation: NativeComponentSourceObservation?
        let capturedLease: SefariaEmbeddedSurfaceLease.Snapshot
        var expectedRevision: UInt64
        var expectedPresentation: SefariaEmbeddedSurfaceIdentity?
        var expectedHost: UUID?
        var authorizedLease: SefariaEmbeddedSurfaceLease.Lease?
        init(original: OriginalSourceProof, capturedLease: SefariaEmbeddedSurfaceLease.Snapshot,
             revision: UInt64, presentation: SefariaEmbeddedSurfaceIdentity?, host: UUID?,
             lease: SefariaEmbeddedSurfaceLease.Lease?, target: SefariaEmbeddedSemanticTarget? = nil,
             parentClaimObservation: NativeComponentSourceObservation? = nil) {
            self.original = original; self.capturedLease = capturedLease; expectedRevision = revision
            self.target = target; self.parentClaimObservation = parentClaimObservation
            expectedPresentation = presentation; expectedHost = host; authorizedLease = lease
        }
    }
    private struct Pending {
        let token = UUID()
        let requestID: UUID
        let validate: @MainActor () throws -> Void
        var applied = false
        var openedNewSurface = false
        var deadlineUptimeNanoseconds: UInt64 = 0
        var semanticTicket: SefariaEmbeddedSemanticTicket? = nil
    }
    private struct RetainedRequest: Sendable {
        let requestID: UUID
        let pendingToken: UUID
        let source: SourceEntry
    }
    private struct ObservedProof {
        let requestID: UUID
        let nonce: UUID
        let value: SefariaEmbeddedSurfaceProof
        let hostToken: UUID
        let source: SourceEntry
        var semantic: SefariaEmbeddedSemanticProof? = nil
        var semanticTicket: SefariaEmbeddedSemanticTicket? = nil
    }
    private struct Completed {
        let observed: ObservedProof
        let identity: SefariaEmbeddedSurfaceIdentity
    }
    private struct Waiter {
        let request: RetainedRequest
        let token: UUID
        let continuation: CheckedContinuation<Void, any Error>
    }

    init(sceneID: UIStableID, manager: iOSNavigationManager,
         workspaceSource: MaktabahNativeWorkspaceProjectionSource) {
        self.sceneID = sceneID; self.manager = manager; self.workspaceSource = workspaceSource
    }
    func install(changed: @escaping @MainActor () -> Void, invalidated: @escaping @MainActor () -> Void) {
        self.changed = changed; self.invalidated = invalidated
    }
    func owns(_ workspace: StudyWorkspaceNavigationAdapter, manager: iOSNavigationManager) -> Bool {
        !retired && self.manager === manager && workspace.sceneID == sceneID.rawValue
            && (try? workspaceSource.read()) === workspace
    }
    var isAvailable: Bool {
        guard !retired, let manager, SefariaExpoLifecycleAdapter.shared.canCreateVisibleSurface,
              SefariaJSRPCBridge.shared.currentSurfaceRuntimeObservation.canPresent,
              (try? OriginalSourceProof.inspect(sceneID: sceneID.rawValue, manager: manager,
                                                source: workspaceSource)) != nil else { return false }
        let global = SefariaEmbeddedSurfaceLease.shared.snapshot
        guard !global.exhausted else { return false }
        if let identity = presentation {
            guard identity.epoch == SefariaJSRPCBridge.shared.currentSessionEpoch,
                  let lease, global.lease == lease, lease.identity == identity else { return false }
            if let pending, isContinuingAppliedRequest(requestID: pending.requestID) { return true }
            return host?.evidence()?.visible == true
        }
        return host == nil && lease == nil && global.lease == nil
    }
    var presentationFacets: PresentationFacets {
        let actual = host?.evidence()
        let ready = hasCurrentVisibleProof()
        return .init(requested: presentation != nil, mounted: actual?.mounted == true,
                     visible: actual?.visible == true, transitioning: actual?.transitioning == true,
                     ready: ready)
    }
    func retainSource(requestID: UUID, target: SefariaEmbeddedSemanticTarget? = nil,
                      parentClaimObservation: NativeComponentSourceObservation? = nil) throws {
        guard sources[requestID] == nil, pending == nil, isAvailable, let manager else {
            throw UIRouteError(.unavailable, "native_sefaria_surface_unavailable")
        }
        guard (target == nil) == (parentClaimObservation == nil) else {
            throw UIRouteError(.staleState, "native_sefaria_semantic_parent_missing")
        }
        let original = try OriginalSourceProof(sceneID: sceneID.rawValue, manager: manager, source: workspaceSource)
        let entry = SourceEntry(original: original, capturedLease: SefariaEmbeddedSurfaceLease.shared.snapshot,
            revision: presentationRevision, presentation: presentation, host: host?.token, lease: lease,
            target: target, parentClaimObservation: parentClaimObservation)
        try validate(entry)
        sources[requestID] = entry
    }
    func validateSource(requestID: UUID, target: SefariaEmbeddedSemanticTarget? = nil) throws {
        guard let entry = sources[requestID], entry.target == target else { throw UIRouteError(.staleState, "native_sefaria_source_not_retained") }
        try validate(entry)
    }
    private func validate(_ entry: SourceEntry) throws {
        try entry.original.validate()
        guard !retired, presentationRevision == entry.expectedRevision,
              presentation == entry.expectedPresentation, host?.token == entry.expectedHost else {
            throw UIRouteError(.staleState, "native_sefaria_surface_owner_changed")
        }
        if let authorized = entry.authorizedLease {
            guard lease == authorized, SefariaEmbeddedSurfaceLease.shared.owns(authorized) else {
                throw UIRouteError(.staleState, "native_sefaria_surface_lease_changed")
            }
        } else {
            guard lease == nil, SefariaEmbeddedSurfaceLease.shared.snapshot == entry.capturedLease else {
                throw UIRouteError(.staleState, "native_sefaria_surface_lease_changed")
            }
        }
    }
    func releaseSource(requestID: UUID) {
        guard let entry = sources.removeValue(forKey: requestID) else { return }
        // Only the exact completed receipt may retain its proof after the outer
        // public operation releases its map membership. An early/reentrant
        // release revokes the active operation and joins its normal cleanup.
        let retainsCompleted = pending == nil && completed?.observed.source === entry
        if !retainsCompleted { entry.original.invalidate() }
        if pending?.requestID == requestID { finish(requestID: requestID, completed: false) }
    }
    func begin(requestID: UUID, target: SefariaEmbeddedSemanticTarget? = nil,
               deadlineUptimeNanoseconds: UInt64 = 0,
               validate: @escaping @MainActor () throws -> Void) throws {
        guard pending == nil, let entry = sources[requestID] else {
            throw UIRouteError(.unavailable, "native_sefaria_surface_busy")
        }
        guard entry.target == target,
              target == nil || deadlineUptimeNanoseconds > DispatchTime.now().uptimeNanoseconds else {
            throw UIRouteError(.staleState, "native_sefaria_semantic_admission_changed")
        }
        try self.validate(entry); try validate()
        guard pending == nil, sources[requestID] === entry else {
            throw UIRouteError(.staleState, "native_sefaria_observation_changed")
        }
        try self.validate(entry)
        completed = nil
        pending = .init(requestID: requestID, validate: validate,
                        deadlineUptimeNanoseconds: deadlineUptimeNanoseconds)
    }
    /// Read-only: it never invokes the Session validator and cannot recursively
    /// make an unrelated transition look like this command's authorized mount.
    func isContinuingAppliedRequest(requestID: UUID) -> Bool {
        guard let pending, pending.requestID == requestID, pending.applied,
              let entry = sources[requestID], presentation != nil,
              entry.expectedPresentation == presentation else { return false }
        return (try? validate(entry)) != nil
    }
    private func withSource<T>(requestID: UUID, operation: @MainActor (SourceEntry) throws -> T) throws -> T {
        try withSource(request: retainedRequest(requestID), operation: operation)
    }
    private func retainedRequest(_ requestID: UUID) throws -> RetainedRequest {
        guard let entry = sources[requestID], let pending, pending.requestID == requestID else {
            throw UIRouteError(.staleState, "native_sefaria_observation_changed")
        }
        return .init(requestID: requestID, pendingToken: pending.token, source: entry)
    }
    private func validateMembership(_ request: RetainedRequest) throws {
        guard sources[request.requestID] === request.source,
              pending?.requestID == request.requestID, pending?.token == request.pendingToken else {
            throw UIRouteError(.staleState, "native_sefaria_observation_changed")
        }
    }
    private func withSource<T>(request: RetainedRequest, operation: @MainActor (SourceEntry) throws -> T) throws -> T {
        try validateMembership(request)
        let entry = request.source
        return try entry.original.runtime.withValidRuntime {
            try validateMembership(request); try validate(entry)
            guard let validateAdmission = pending?.validate else {
                throw UIRouteError(.staleState, "native_sefaria_observation_changed")
            }
            try validateAdmission()
            try validateMembership(request); try validate(entry)
            let value = try operation(entry)
            try validateMembership(request); try validate(entry)
            try validateAdmission()
            try validateMembership(request); try validate(entry)
            return value
        }
    }
    func apply(requestID: UUID) throws {
        try withSource(requestID: requestID) { entry in
            guard pending?.applied == false else { throw UIRouteError(.staleState, "native_sefaria_already_applied") }
            if presentation == nil {
                guard presentationRevision < .max else { throw UIRouteError(.unavailable, "native_sefaria_lifetime_exhausted") }
                let identity = SefariaEmbeddedSurfaceIdentity(id: UUID(), mountID: UUID(), sceneID: sceneID.rawValue,
                                                              epoch: entry.original.runtime.observation.epoch)
                let acquired = try SefariaEmbeddedSurfaceLease.shared.acquire(ownerID: ownerID, identity: identity,
                                                                             expected: entry.capturedLease)
                lease = acquired; entry.authorizedLease = acquired
                // Declare this one publication before SwiftUI observes it. No
                // source latch, backend epoch or original mapping is rearmed.
                presentationRevision += 1; entry.expectedRevision = presentationRevision
                entry.expectedPresentation = identity
                pending?.applied = true; pending?.openedNewSurface = true
                presentationCreator = (requestID, identity.id)
                presentation = identity
            } else { pending?.applied = true }
            if let target = entry.target {
                guard let identity = presentation, let parent = entry.parentClaimObservation,
                      let deadline = pending?.deadlineUptimeNanoseconds else {
                    throw UIRouteError(.staleState, "native_sefaria_semantic_admission_changed")
                }
                let ticket = try SefariaEmbeddedSemanticTicket(requestID: requestID, identity: identity,
                    target: target, deadlineUptimeNanoseconds: deadline, runtime: entry.original.runtime,
                    rootSource: parent, originalSource: entry.original.claimObservation)
                try SefariaEmbeddedSemanticHandoffs.shared.register(ticket)
                pending?.semanticTicket = ticket
            }
            proof = nil
        }
        signalChange(); resumeHostWaiterIfVisible()
    }
    /// Shared Session uses this only for the actual synchronous native report.
    /// The source lock stays held through that callback; no await is accepted.
    func withValidatedSurface<T>(requestID: UUID, _ operation: @MainActor () throws -> T) throws -> T {
        try withSource(requestID: requestID) { _ in
            guard pending?.applied == true, let proof, proof.requestID == requestID,
                  hasCurrentVisibleProof() else { throw UIRouteError(.unavailable, "native_sefaria_original_surface_not_visible") }
            return try operation()
        }
    }
    func finish(requestID: UUID, completed didComplete: Bool) {
        guard let pending, pending.requestID == requestID else { return }
        cancelWaiters(requestID: requestID)
        if didComplete, let proof, sources[requestID] === proof.source,
           proof.requestID == requestID, let presentation,
           hasCurrentVisibleProof(), (try? validate(proof.source)) != nil {
            completed = .init(observed: proof, identity: presentation)
        } else { completed = nil }
        if let ticket = pending.semanticTicket {
            SefariaEmbeddedSemanticHandoffs.shared.remove(ticket, revoke: completed == nil)
        }
        host?.stopSemanticObservation()
        self.pending = nil
        if completed == nil && pending.openedNewSurface, let identity = presentation { dismiss(identity: identity.id) }
    }
    func dismiss(identity: UUID) {
        guard presentation?.id == identity else { return }
        invalidateSources(); advancePresentationRevision(); presentationCreator = nil; presentation = nil
        if host == nil { releaseLease() }
        signalChange()
    }
    /// Diagnostic cleanup may run after cancellation or failed fresh evidence.
    /// Only the exact cold creator can dismiss its own still-current identity;
    /// warm/pre-apply/foreign requests never acquire this cleanup ownership.
    func dismissNewSurface(requestID: UUID) {
        guard let creator = presentationCreator, creator.requestID == requestID,
              presentation?.id == creator.identity else { return }
        dismiss(identity: creator.identity)
    }
    func retire() {
        guard !retired else { return }
        retired = true; invalidateSources(); presentationCreator = nil; presentation = nil
        if host == nil { releaseLease() }
        signalChange()
    }
    func unmount() {
        retire(); host?.detach(); host = nil; releaseLease()
        sources.removeAll(); pending = nil; completed = nil; proof = nil
        changed = {}; invalidated = {}
    }

    func surfaceWillAttach(_ controller: SefariaEmbeddedNativeSurfaceController) throws {
        guard let pending, pending.applied, pending.openedNewSurface, host == nil,
              presentation == controller.identity, let entry = sources[pending.requestID], entry.expectedHost == nil else {
            throw UIRouteError(.staleState, "native_sefaria_first_mount_not_owned")
        }
        try withSource(requestID: pending.requestID) { entry in
            entry.expectedHost = controller.token; host = controller
        }
    }
    func surfaceDidChange(_ controller: SefariaEmbeddedNativeSurfaceController) {
        guard host === controller, presentation == controller.identity else { return }
        if let ticket = pending?.semanticTicket, ticket.isArmed, controller.evidence()?.visible != true {
            ticket.revoke()
        }
        signalChange(); resumeHostWaiterIfVisible(); resumeSemanticWaiterIfVisible()
    }
    func surfaceWillDisappear(_ controller: SefariaEmbeddedNativeSurfaceController) {
        guard host === controller else { return }
        invalidateSources(); signalChange()
    }
    func surfaceDidDetach(_ controller: SefariaEmbeddedNativeSurfaceController) {
        guard host === controller else { return }
        invalidateSources(); host = nil; releaseLease(); advancePresentationRevision()
        if presentation == controller.identity { presentationCreator = nil; presentation = nil }
        signalChange()
    }
    func surfaceDidFail(_ controller: SefariaEmbeddedNativeSurfaceController, error: any Error) {
        guard host === controller || presentation == controller.identity else { return }
        OtzariaFileLogger.shared.log("[SefariaVisibleSurface] failed=\((error as? SefariaRPCError)?.code ?? (error as? UIRouteError)?.code ?? "native_surface_failed")")
        invalidateSources(); signalChange()
    }
    /// Await inside the Session's EXISTING structured observation/deadline task.
    /// No detached probe can outlive admission or publish after cancellation.
    func awaitOriginalSurface(requestID: UUID) async throws {
        guard readinessRequestID == nil, pending?.requestID == requestID, pending?.applied == true else {
            throw UIRouteError(.unavailable, "native_sefaria_readiness_busy")
        }
        let request = try retainedRequest(requestID)
        readinessRequestID = requestID
        defer {
            if readinessRequestID == requestID { readinessRequestID = nil }
            withExtendedLifetime(request.source) {}
        }
        try await waitForVisibleHost(request: request)
        try Task.checkCancellation()
        guard let identity = presentation, let controller = host, controller.identity == identity else {
            throw UIRouteError(.staleState, "native_sefaria_host_changed")
        }
        let nonce = UUID(), token = controller.token
        try withSource(request: request) { _ in }
        // Encoding and the actor RPC are outside the synchronous source lock.
        let params: [String: String] = ["surfaceID": identity.id.uuidString, "mountID": identity.mountID.uuidString,
            "sceneID": identity.sceneID, "nonce": nonce.uuidString]
        let json = String(decoding: try JSONEncoder().encode(params), as: UTF8.self)
        let response = try await withThrowingTaskGroup(of: SefariaRPCResponse.self) { group in
            group.addTask {
                try await SefariaJSRPCBridge.shared.call(method: "surface.awaitVisible", paramsJson: json,
                    generation: identity.epoch, timeoutMs: 5000)
            }
            group.addTask { [weak self] in
                guard let self else { throw CancellationError() }
                try await self.waitForInvalidation(request: request)
                throw CancellationError()
            }
            defer { group.cancelAll() }
            guard let result = try await group.next() else { throw CancellationError() }
            return result
        }
        try Task.checkCancellation()
        guard response.isSuccess else {
            throw response.error ?? SefariaRPCError(code: "SURFACE_PROOF_FAILED", message: "The original surface did not become ready.")
        }
        let observed = try response.decodeResult(SefariaEmbeddedSurfaceProof.self)
        try withSource(request: request) { entry in
            guard host === controller, controller.token == token, controller.identity == identity,
                  presentation == identity, observed.matches(identity, nonce: nonce),
                  proofFitsOriginalView(observed, controller: controller) else {
                throw UIRouteError(.staleState, "native_sefaria_visible_proof_changed")
            }
            proof = .init(requestID: requestID, nonce: nonce, value: observed, hostToken: token, source: entry)
        }
        if request.source.target != nil {
            try await awaitOriginalSemanticTarget(request: request, identity: identity, controller: controller)
        }
        signalChange()
    }

    private func awaitOriginalSemanticTarget(request: RetainedRequest, identity: SefariaEmbeddedSurfaceIdentity,
                                             controller: SefariaEmbeddedNativeSurfaceController) async throws {
        guard let ticket = pending?.semanticTicket, ticket.claim.requestID == request.requestID,
              request.source.target == ticket.claim.target else {
            throw UIRouteError(.staleState, "native_sefaria_semantic_ticket_missing")
        }
        try await withTaskCancellationHandler {
            try Task.checkCancellation()
            try withSource(request: request) { _ in
                guard host === controller, controller.evidence()?.visible == true,
                      ticket.arm(originalHostToken: controller.token) else {
                    throw UIRouteError(.staleState, "native_sefaria_semantic_ticket_not_owned")
                }
            }
            let json = String(decoding: try JSONEncoder().encode(ticket.claim), as: UTF8.self)
            let response = try await withThrowingTaskGroup(of: SefariaRPCResponse.self) { group in
                group.addTask {
                    try await SefariaJSRPCBridge.shared.call(method: "surface.navigateOriginal", paramsJson: json,
                        generation: identity.epoch, timeoutMs: 5000)
                }
                group.addTask { [weak self] in
                    guard let self else { throw CancellationError() }
                    try await self.waitForInvalidation(request: request)
                    throw CancellationError()
                }
                defer { group.cancelAll() }
                guard let result = try await group.next() else { throw CancellationError() }
                return result
            }
            try Task.checkCancellation()
            guard response.isSuccess else {
                throw response.error ?? SefariaRPCError(code: "SEMANTIC_PROOF_FAILED", message: "The original destination was not revealed.")
            }
            let observed = try response.decodeResult(SefariaEmbeddedSemanticProof.self)
            try withSource(request: request) { entry in
                guard host === controller, presentation == identity,
                      ticket.matchesOriginalHost(controller.token), observed.matches(ticket, identity: identity),
                      proofFitsOriginalView(observed.originalSurface, controller: controller) else {
                    throw UIRouteError(.staleState, "native_sefaria_semantic_proof_changed")
                }
                proof = .init(requestID: request.requestID, nonce: ticket.claim.nonce,
                    value: observed.originalSurface, hostToken: controller.token, source: entry,
                    semantic: observed, semanticTicket: ticket)
            }
            // The JS selected state is not a UIKit acknowledgement. Observe the
            // actual original views until they really appear, under this same
            // command/deadline; source/cancellation still revokes the ticket.
            controller.observeSemanticTarget(ticket.claim.target, language: observed.interfaceLanguage)
            defer { controller.stopSemanticObservation() }
            try await waitForVisibleSemanticTarget(request: request)
            try Task.checkCancellation()
            try withSource(request: request) { _ in
                guard hasCurrentVisibleProof() else {
                    throw UIRouteError(.unavailable, "native_sefaria_original_target_not_visible")
                }
            }
        } onCancel: {
            // This cannot wait for the MainActor. A queued JS call has to see
            // revocation before it can consume its one original method ticket.
            // Counterfactual: removed only synchronous cancellation revocation.
        }
    }

    private func waitForVisibleSemanticTarget(request: RetainedRequest) async throws {
        try withSource(request: request) { _ in }
        if hasCurrentVisibleProof() { return }
        let token = UUID(), requestID = request.requestID
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, any Error>) in
                guard semanticWaiter == nil else { continuation.resume(throwing: UIRouteError(.unavailable, "native_sefaria_semantic_wait_busy")); return }
                semanticWaiter = .init(request: request, token: token, continuation: continuation)
                if Task.isCancelled { cancelSemanticWaiter(requestID: requestID, token: token) }
                else { resumeSemanticWaiterIfVisible() }
            }
        } onCancel: { [weak self] in
            Task { @MainActor in self?.cancelSemanticWaiter(requestID: requestID, token: token) }
        }
    }
    private func resumeSemanticWaiterIfVisible() {
        guard let waiter = semanticWaiter else { return }
        do {
            try withSource(request: waiter.request) { _ in }
            guard pending?.semanticTicket?.canSupportEvidence == true else { throw CancellationError() }
            guard hasCurrentVisibleProof() else { return }
            semanticWaiter = nil; waiter.continuation.resume()
        } catch { semanticWaiter = nil; waiter.continuation.resume(throwing: error) }
    }
    private func cancelSemanticWaiter(requestID: UUID, token: UUID) {
        guard let waiter = semanticWaiter, waiter.request.requestID == requestID, waiter.token == token else { return }
        semanticWaiter = nil; waiter.continuation.resume(throwing: CancellationError())
    }
    private func waitForVisibleHost(request: RetainedRequest) async throws {
        let requestID = request.requestID
        try withSource(request: request) { _ in }
        if host?.evidence()?.visible == true { return }
        let token = UUID()
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, any Error>) in
                guard hostWaiter == nil else { continuation.resume(throwing: UIRouteError(.unavailable, "native_sefaria_mount_busy")); return }
                hostWaiter = .init(request: request, token: token, continuation: continuation)
                if Task.isCancelled { cancelHostWaiter(requestID: requestID, token: token) }
                else { resumeHostWaiterIfVisible() }
            }
        } onCancel: { [weak self] in
            Task { @MainActor in self?.cancelHostWaiter(requestID: requestID, token: token) }
        }
    }
    private func waitForInvalidation(request: RetainedRequest) async throws {
        let requestID = request.requestID
        try withSource(request: request) { _ in }
        let token = UUID()
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, any Error>) in
                guard invalidationWaiter == nil else { continuation.resume(throwing: UIRouteError(.unavailable, "native_sefaria_invalidation_busy")); return }
                invalidationWaiter = .init(request: request, token: token, continuation: continuation)
                if Task.isCancelled { cancelInvalidationWaiter(requestID: requestID, token: token) }
            }
        } onCancel: { [weak self] in
            Task { @MainActor in self?.cancelInvalidationWaiter(requestID: requestID, token: token) }
        }
    }
    private func resumeHostWaiterIfVisible() {
        guard let waiter = hostWaiter else { return }
        do {
            try withSource(request: waiter.request) { _ in }
            guard host?.evidence()?.visible == true else { return }
            hostWaiter = nil; waiter.continuation.resume()
        } catch { hostWaiter = nil; waiter.continuation.resume(throwing: error) }
    }
    private func cancelHostWaiter(requestID: UUID, token: UUID) {
        guard let waiter = hostWaiter, waiter.request.requestID == requestID, waiter.token == token else { return }
        hostWaiter = nil; waiter.continuation.resume(throwing: CancellationError())
    }
    private func cancelInvalidationWaiter(requestID: UUID, token: UUID) {
        guard let waiter = invalidationWaiter, waiter.request.requestID == requestID, waiter.token == token else { return }
        invalidationWaiter = nil; waiter.continuation.resume(throwing: CancellationError())
    }
    private func cancelWaiters(requestID: UUID) {
        if let waiter = hostWaiter { cancelHostWaiter(requestID: requestID, token: waiter.token) }
        if let waiter = invalidationWaiter { cancelInvalidationWaiter(requestID: requestID, token: waiter.token) }
        if let waiter = semanticWaiter { cancelSemanticWaiter(requestID: requestID, token: waiter.token) }
    }

    func acceptanceEvidence(for receipt: UISceneReceipt) throws -> SefariaEmbeddedSurfaceAcceptanceEvidence {
        guard pending == nil, let completed, receipt.requestId == completed.observed.requestID,
              completed.observed.source.target == nil,
              receipt.route.requestId == receipt.requestId, receipt.sceneID == sceneID,
              receipt.route.destination == Self.destination, receipt.route.presentation.kind == .sheet,
              receipt.route.content == nil, receipt.route.focus == nil,
              presentation == completed.identity else {
            throw UIRouteError(.staleState, "native_sefaria_receipt_not_owned")
        }
        return try completed.observed.source.original.runtime.withValidRuntime {
            try validate(completed.observed.source)
            guard hasCurrentVisibleProof(), host?.token == completed.observed.hostToken else {
                throw UIRouteError(.unavailable, "native_sefaria_receipt_no_longer_visible")
            }
            return .init(nativeReceiptID: receipt.requestId, nativeSceneID: sceneID.rawValue,
                nativeHostToken: completed.observed.hostToken,
                runtimeRevision: completed.observed.source.original.runtime.observation.revision,
                originalSurface: completed.observed.value)
        }
    }
    private func proofFitsOriginalView(_ value: SefariaEmbeddedSurfaceProof,
                                      controller: SefariaEmbeddedNativeSurfaceController) -> Bool {
        guard controller.evidence()?.visible == true, let original = controller.reactView else { return false }
        return abs(value.layout.width - Double(original.bounds.width)) <= 1
            && abs(value.layout.height - Double(original.bounds.height)) <= 1
    }
    private func hasCurrentVisibleProof() -> Bool {
        guard !retired, let proof, let identity = presentation, let controller = host,
              controller.token == proof.hostToken, controller.identity == identity,
              proof.value.matches(identity, nonce: proof.nonce),
              (try? validate(proof.source)) != nil else { return false }
        if let pending, !pending.applied || proof.requestID != pending.requestID { return false }
        guard proofFitsOriginalView(proof.value, controller: controller) else { return false }
        if let target = proof.source.target {
            guard let semantic = proof.semantic, let ticket = proof.semanticTicket,
                  semantic.claim.target == target, semantic.matches(ticket, identity: identity),
                  ticket.matchesOriginalHost(controller.token),
                  controller.semanticEvidence(target: target, language: semantic.interfaceLanguage) != nil else { return false }
        } else if proof.semantic != nil || proof.semanticTicket != nil { return false }
        return true
    }
    var observedDestination: UIDestinationID? {
        guard hasCurrentVisibleProof(), let proof else { return nil }
        return proof.source.target.flatMap { UIDestinationID(rawValue: $0.destinationID) } ?? Self.destination
    }
    func semanticAcceptanceEvidence(for receipt: UISceneReceipt) throws -> SefariaEmbeddedSemanticAcceptanceEvidence {
        guard pending == nil, let completed, let target = completed.observed.source.target,
              let semantic = completed.observed.semantic,
              receipt.requestId == completed.observed.requestID, receipt.route.requestId == receipt.requestId,
              receipt.sceneID == sceneID, receipt.route.destination.rawValue == target.destinationID,
              receipt.route.presentation.kind == .sheet, receipt.route.content == nil, receipt.route.focus == nil,
              presentation == completed.identity else {
            throw UIRouteError(.staleState, "native_sefaria_semantic_receipt_not_owned")
        }
        return try completed.observed.source.original.runtime.withValidRuntime {
            try validate(completed.observed.source)
            guard hasCurrentVisibleProof(), let controller = host,
                  controller.token == completed.observed.hostToken,
                  let actual = controller.semanticEvidence(target: target, language: semantic.interfaceLanguage) else {
                throw UIRouteError(.unavailable, "native_sefaria_semantic_receipt_no_longer_visible")
            }
            return .init(nativeReceiptID: receipt.requestId, nativeSceneID: sceneID.rawValue,
                nativeHostToken: controller.token,
                runtimeRevision: completed.observed.source.original.runtime.observation.revision,
                actualOriginalViewCount: actual.originalViews.count, originalTarget: semantic)
        }
    }
    private func invalidateSources() {
        if let ticket = pending?.semanticTicket { SefariaEmbeddedSemanticHandoffs.shared.remove(ticket, revoke: true) }
        host?.stopSemanticObservation()
        if let waiter = hostWaiter { hostWaiter = nil; waiter.continuation.resume(throwing: CancellationError()) }
        if let waiter = invalidationWaiter { invalidationWaiter = nil; waiter.continuation.resume(throwing: CancellationError()) }
        if let waiter = semanticWaiter { semanticWaiter = nil; waiter.continuation.resume(throwing: CancellationError()) }
        for source in sources.values { source.original.invalidate() }
        proof?.source.original.invalidate(); completed?.observed.source.original.invalidate()
        proof = nil; completed = nil; invalidated()
    }
    private func advancePresentationRevision() {
        if presentationRevision == .max { retired = true } else { presentationRevision += 1 }
    }
    private func releaseLease() {
        if let lease { SefariaEmbeddedSurfaceLease.shared.release(lease) }
        lease = nil
    }
    private func signalChange() {
        if renderRevision < .max { renderRevision += 1 } else { retired = true }
        changed()
    }
}
// Complete production binding + actual RPC actor controls. Transport replies,
// domain state, UIKit evidence and canonical-receipt inputs are declared shells.
@MainActor private final class BindingControlTransport: SefariaJSTransport {
    var holdBeforeClaim = false; var holdAfterClaim = false; var omitClaim = false
    var wrongTarget = false; var calls = 0
    var originalRootCalls = 0
    var capturedClaim: SefariaEmbeddedSemanticClaim?
    private var navigationArrived = false; private var claimCompleted = false; private var deliveryCompleted = false
    private var navigationWaiter: CheckedContinuation<Void, Never>?
    private var claimWaiter: CheckedContinuation<Void, Never>?
    private var deliveryWaiter: CheckedContinuation<Void, Never>?
    private var releaseWaiter: CheckedContinuation<Void, Never>?
    func waitForNavigation() async { if !navigationArrived { await withCheckedContinuation { navigationWaiter = $0 } } }
    func waitForClaim() async { if !claimCompleted { await withCheckedContinuation { claimWaiter = $0 } } }
    func waitForDelivery() async { if !deliveryCompleted { await withCheckedContinuation { deliveryWaiter = $0 } } }
    func release() { releaseWaiter?.resume(); releaseWaiter = nil }
    nonisolated func sendToJS(jsonString: String) async throws { try await receive(jsonString) }
    private func receive(_ json: String) async throws {
        let request = try JSONDecoder().decode(SefariaRPCEnvelope.self, from: Data(json.utf8))
        var result: String
        if request.method == "surface.awaitVisible" {
            originalRootCalls += 1
            let p = try JSONDecoder().decode([String: String].self, from: Data(request.paramsJson!.utf8))
            let proof = surface(surface: UUID(uuidString: p["surfaceID"]!)!, mount: UUID(uuidString: p["mountID"]!)!,
                                scene: p["sceneID"]!, epoch: request.sessionGeneration, nonce: UUID(uuidString: p["nonce"]!)!)
            result = String(decoding: try JSONEncoder().encode(proof), as: UTF8.self)
        } else if request.method == "surface.navigateOriginal" {
            let claim = try JSONDecoder().decode(SefariaEmbeddedSemanticClaim.self, from: Data(request.paramsJson!.utf8))
            capturedClaim = claim; navigationArrived = true; navigationWaiter?.resume(); navigationWaiter = nil
            if holdBeforeClaim { await withCheckedContinuation { releaseWaiter = $0 } }
            let claimed = !omitClaim && SefariaEmbeddedSemanticHandoffs.shared.claim(request.paramsJson!)
            if claimed { calls += 1 }
            claimCompleted = true; claimWaiter?.resume(); claimWaiter = nil
            if holdAfterClaim { await withCheckedContinuation { releaseWaiter = $0 } }
            let proof = SefariaEmbeddedSemanticProof(contract: "chavrusa.original-rn-target.v1", claim: claim,
                originalSurface: surface(surface: claim.surfaceID, mount: claim.mountID, scene: claim.sceneID,
                    epoch: claim.epoch, nonce: claim.nonce), originalMenu: wrongTarget ? "dedication" : claim.target.originalMenu,
                originalHeaderKey: claim.target.originalHeaderKey, interfaceLanguage: "english", originalRootSelection: true,
                originalInstanceRetained: true, observedAfterOriginalCall: true)
            result = String(decoding: try JSONEncoder().encode(proof), as: UTF8.self)
        } else { throw SefariaRPCError(code: "CONTROL_UNEXPECTED_METHOD", message: request.method) }
        let response = SefariaRPCResponse(requestID: request.requestID, status: "success", resultJson: result,
                                         sessionGeneration: request.sessionGeneration)
        await SefariaJSRPCBridge.shared.handleIncomingResponse(jsonString: String(decoding: try JSONEncoder().encode(response), as: UTF8.self))
        if request.method == "surface.navigateOriginal" {
            deliveryCompleted = true; deliveryWaiter?.resume(); deliveryWaiter = nil
        }
    }
    private func surface(surface: UUID, mount: UUID, scene: String, epoch: UInt64, nonce: UUID) -> SefariaEmbeddedSurfaceProof {
        .init(contract: "chavrusa.original-rn-surface.v1", component: "ReaderApp", upstreamSHA: "2fd173a5a3bd32d94a9ba1222e4e32a37f6bd23c",
              surfaceID: surface, mountID: mount, sceneID: scene, epoch: epoch, nonce: nonce,
              layout: .init(width: 600, height: 800, revision: 1))
    }
}
@MainActor private final class BindingFixture {
    let sceneID = UIStableID(rawValue: "original-scene")!
    let manager = iOSNavigationManager(), owner = MaktabahNativeWorkspaceOwner()
    let workspace: StudyWorkspaceNavigationAdapter
    let binding: MaktabahNativeSefariaSurfaceBinding
    var host: SefariaEmbeddedNativeSurfaceController?
    let transport = BindingControlTransport()
    var parent = NativeComponentSourceObservation {}
    init() throws {
        workspace = StudyWorkspaceNavigationAdapter(sceneID: sceneID.rawValue, manager: manager)
        try owner.replace(with: workspace)
        binding = MaktabahNativeSefariaSurfaceBinding(sceneID: sceneID, manager: manager,
            workspaceSource: MaktabahNativeWorkspaceProjectionSource(owner: owner, legacyWorkspace: nil))
    }
    func ready() async throws {
        let bridge = SefariaJSRPCBridge.shared
        await bridge.setTransport(transport); await bridge.notifyListenersActive(true)
        let event = SefariaRPCEvent(event: "ready", sequence: 1)
        await bridge.handleIncomingEvent(jsonString: String(decoding: try JSONEncoder().encode(event), as: UTF8.self))
    }
    func start(target: SefariaEmbeddedSemanticTarget? = .library, validate: @escaping @MainActor () throws -> Void = {}) throws -> (UUID, Task<Void, any Error>) {
        let request = UUID()
        parent = NativeComponentSourceObservation {}
        try binding.retainSource(requestID: request, target: target, parentClaimObservation: target == nil ? nil : parent)
        try binding.begin(requestID: request, target: target,
            deadlineUptimeNanoseconds: DispatchTime.now().uptimeNanoseconds + 10_000_000_000, validate: validate)
        try binding.apply(requestID: request)
        if host == nil {
            let actual = SefariaEmbeddedNativeSurfaceController(identity: binding.presentation!)
            actual.observer = binding; try binding.surfaceWillAttach(actual); host = actual
            binding.surfaceDidChange(actual)
        }
        return (request, Task { try await self.binding.awaitOriginalSurface(requestID: request) })
    }
    func receipt(_ request: UUID, target: SefariaEmbeddedSemanticTarget? = .library) -> UISceneReceipt {
        let destination = target.map { UIDestinationID(rawValue: $0.destinationID)! } ?? MaktabahNativeSefariaSurfaceBinding.destination
        return .init(requestId: request, sceneID: sceneID, route: .init(requestId: request, destination: destination,
            presentation: .init(kind: .sheet), content: nil, focus: nil))
    }
    func cleanup(_ request: UUID) { binding.finish(requestID: request, completed: false); binding.releaseSource(requestID: request); binding.unmount() }
}
private struct BindingFailure: Error { let detail: String }
@main private struct BindingControls {
    @MainActor static func main() async throws {
        var results: [[String: Any]] = []
        func expect(_ condition: @autoclosure () -> Bool, _ detail: String) throws { if !condition() { throw BindingFailure(detail: detail) } }
        func refused(_ task: Task<Void, any Error>) async -> Bool { do { try await task.value; return false } catch { return true } }
        func test(_ name: String, _ body: () async throws -> Void) async {
            do { try await body(); results.append(["name": name, "passed": true]) }
            catch { results.append(["name": name, "passed": false, "error": String(describing: error)]) }
        }
        await test("unchanged root target performs only original read-only RPC") {
            let f = try BindingFixture(); try await f.ready(); let (id, task) = try f.start(target: nil)
            defer { f.cleanup(id) }; try await task.value
            f.binding.finish(requestID: id, completed: true); f.binding.releaseSource(requestID: id)
            let actual = try f.binding.acceptanceEvidence(for: f.receipt(id, target: nil))
            try expect(actual.nativeReceiptID == id && f.transport.originalRootCalls == 1 && f.transport.calls == 0,
                       "root path mutated semantic state or lost original proof")
        }
        await test("semantic request requires actual claim and same-source visible proof") {
            let f = try BindingFixture(); try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; try await task.value
            f.binding.finish(requestID: id, completed: true); f.binding.releaseSource(requestID: id)
            let actual = try f.binding.semanticAcceptanceEvidence(for: f.receipt(id))
            try expect(actual.nativeReceiptID == id && actual.originalTarget.claim.requestID == id
                && f.transport.calls == 1 && f.binding.observedDestination?.rawValue == "native.sefariaEmbedded.library",
                "semantic reply did not retain original claim/proof")
        }
        await test("echoed selected state without native claim is refused") {
            let f = try BindingFixture(); f.transport.omitClaim = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; let denied = await refused(task)
            try expect(denied && f.transport.calls == 0 && !f.binding.presentationFacets.ready, "unclaimed reply became evidence")
        }
        await test("wrong original selected state after claim is truthful failure") {
            let f = try BindingFixture(); f.transport.wrongTarget = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; let denied = await refused(task)
            try expect(denied && f.transport.calls == 1 && !f.binding.presentationFacets.ready, "wrong result became success or erased effect")
        }
        await test("actual cancellation before queued JS claim yields zero late effects") {
            let f = try BindingFixture(); f.transport.holdBeforeClaim = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; await f.transport.waitForNavigation(); task.cancel()
            let denied = await refused(task)
            f.transport.release(); await f.transport.waitForDelivery()
            try expect(denied && f.transport.calls == 0 && !f.binding.presentationFacets.ready,
                       "late JS claim survived real Task cancellation")
        }
        await test("actual cancellation after claim preserves possible effect without receipt") {
            let f = try BindingFixture(); f.transport.holdAfterClaim = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; await f.transport.waitForClaim(); task.cancel()
            let denied = await refused(task)
            f.transport.release(); await f.transport.waitForDelivery()
            try expect(denied && f.transport.calls == 1 && !f.binding.presentationFacets.ready, "claimed cancellation became success/rollback")
        }
        await test("actual original workspace replacement rejects queued JS effect") {
            let f = try BindingFixture(); f.transport.holdBeforeClaim = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; await f.transport.waitForNavigation()
            try f.owner.replace(with: StudyWorkspaceNavigationAdapter(sceneID: f.sceneID.rawValue, manager: f.manager))
            f.transport.release(); let denied = await refused(task)
            try expect(denied && f.transport.calls == 0, "old workspace invoked original method")
        }
        await test("real one-shot backend publisher rejects ABA before JS claim") {
            let f = try BindingFixture(); f.transport.holdBeforeClaim = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; await f.transport.waitForNavigation()
            BackendCoordinator.shared.isTransitioning = true; BackendCoordinator.shared.isTransitioning = false
            f.transport.release(); let denied = await refused(task)
            try expect(denied && f.transport.calls == 0, "backend transition revived source")
        }
        await test("early source membership release rejects queued JS effect") {
            let f = try BindingFixture(); f.transport.holdBeforeClaim = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; await f.transport.waitForNavigation(); f.binding.releaseSource(requestID: id)
            f.transport.release(); let denied = await refused(task)
            try expect(denied && f.transport.calls == 0, "released membership performed a late effect")
        }
        await test("original host detach rejects queued JS effect") {
            let f = try BindingFixture(); f.transport.holdBeforeClaim = true; try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; await f.transport.waitForNavigation(); f.host!.detach()
            f.transport.release(); let denied = await refused(task)
            try expect(denied && f.transport.calls == 0, "detached original host retained claim")
        }
        await test("JS selected-state proof waits for independent actual target evidence") {
            let f = try BindingFixture(); try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; f.host!.semanticVisible = false
            let reached = AsyncStream<Void>.makeStream()
            f.host!.observing = { reached.continuation.yield(); reached.continuation.finish() }
            for await _ in reached.stream { break }
            try expect(f.transport.calls == 1 && !f.binding.presentationFacets.ready, "JS proof alone became ready")
            f.host!.semanticVisible = true; f.binding.surfaceDidChange(f.host!); try await task.value
            try expect(f.binding.presentationFacets.ready, "actual original visible publication did not resolve retained waiter")
        }
        await test("completed semantic evidence rejects later original mapping ABA") {
            let f = try BindingFixture(); try await f.ready(); let (id, task) = try f.start()
            defer { f.cleanup(id) }; try await task.value; f.binding.finish(requestID: id, completed: true); f.binding.releaseSource(requestID: id)
            _ = try f.binding.semanticAcceptanceEvidence(for: f.receipt(id))
            f.workspace.source.event += 1; f.workspace.source.event -= 1
            var rejected = false; do { _ = try f.binding.semanticAcceptanceEvidence(for: f.receipt(id)) } catch { rejected = true }
            try expect(rejected && f.binding.observedDestination == nil, "completed receipt revived after original mapping ABA")
        }
        await test("exact warm original host can reveal another finite target") {
            let f = try BindingFixture(); try await f.ready(); let (rootID, rootTask) = try f.start(target: nil)
            try await rootTask.value; f.binding.finish(requestID: rootID, completed: true); f.binding.releaseSource(requestID: rootID)
            let originalHost = f.host!, identity = f.binding.presentation
            let (id, task) = try f.start(target: .topics); defer { f.cleanup(id) }; try await task.value
            f.binding.finish(requestID: id, completed: true); f.binding.releaseSource(requestID: id)
            let actual = try f.binding.semanticAcceptanceEvidence(for: f.receipt(id, target: .topics))
            try expect(f.host === originalHost && f.binding.presentation == identity && actual.originalTarget.claim.target == .topics,
                       "warm finite target replaced original host or receipt source")
        }
        let failed = results.filter { $0["passed"] as? Bool != true }.count
        let data = try JSONSerialization.data(withJSONObject: ["scope": "Complete actual RN binding/runtime/RPC actor/lease/ticket over explicit domain/Combine/UIKit/Core-receipt inputs; SDK/native NOT_RUN",
            "passed": results.count - failed, "failed": failed, "results": results], options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: data, as: UTF8.self)); if failed > 0 { exit(1) }
    }
}
