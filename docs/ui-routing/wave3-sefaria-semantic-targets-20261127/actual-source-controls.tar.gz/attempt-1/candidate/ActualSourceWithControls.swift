import Foundation
import Observation
import Synchronization


private enum UIRouteErrorCode { case staleState }
private struct UIRouteError: Error {
    let code: UIRouteErrorCode; let detail: String
    init(_ code: UIRouteErrorCode, _ detail: String) { self.code = code; self.detail = detail }
}

struct SefariaRPCError: Codable, Sendable, Equatable, LocalizedError {
    let code: String
    let message: String
    let retryable: Bool
    let details: String?

    var errorDescription: String? {
        "[\(code)] \(message)"
    }

    init(
        code: String,
        message: String,
        retryable: Bool = false,
        details: String? = nil
    ) {
        self.code = code
        self.message = message
        self.retryable = retryable
        self.details = details
    }
}

import Observation
import Synchronization

/// A one-shot cancellation witness over ORIGINAL observable source reads.
/// Restoring the same values cannot restore a captured request. This is not a
/// source cache or an authority; the original identity/generation checks remain.
public final class NativeComponentSourceObservation: Sendable {
    private let invalidated = Mutex(false)

    @MainActor
    public init(read: @MainActor () -> Void) {
        withObservationTracking {
            read()
        } onChange: { [weak self] in
            // Observation fires at willSet. Do not enqueue a Task: a complete
            // A -> B -> A edit can happen before a MainActor task resumes.
            self?.invalidate()
        }
    }

    /// Original non-Observation publishers may revoke this same latch. There is
    /// deliberately no reset, rearm or setter that can make a request live again.
    public func invalidate() {
        invalidated.withLock { $0 = true }
    }

    public func validate() throws {
        guard !invalidated.withLock({ $0 }) else {
            throw UIRouteError(.staleState, "native_component_source_changed")
        }
    }

    /// A source-locked final Boolean claim for the private RN handoff. The only
    /// application caller nests fixed one-way source latches and consumes its
    /// fixed ticket; it does not run UIKit, JS, actor work or a user callback.
    /// There is deliberately no reset or observation refresh in this operation.
    public func claimIfCurrent(_ claim: () -> Bool) -> Bool {
        invalidated.withLock { retired in
            guard !retired else { return false }
            return claim()
        }
    }
}

//
//  SefariaJSRPCBridge.swift
//  Maktabah
//
//  Downstream-owned asynchronous RPC bridge between Swift and Sefaria-Mobile JS runtime.
//  Enforces single-resume continuations, actor-owned timeout handling, zero leaks,
//  generation guards, and event listener dispatching.
//

import Foundation

protocol SefariaJSTransport: AnyObject, Sendable {
    func sendToJS(jsonString: String) async throws
}

/// A synchronous, source-owned observation of the same RPC lifecycle fields.
/// The revision also changes for repeated listener/ready lifecycle publications.
struct SefariaEmbeddedSurfaceRuntimeObservation: Sendable, Equatable {
    fileprivate(set) var epoch: UInt64 = 1
    fileprivate(set) var revision: UInt64 = 0
    fileprivate(set) var ready = false
    fileprivate(set) var listeners = false
    fileprivate(set) var transport = false
    fileprivate(set) var resourceMutation = false
    fileprivate(set) var transitioning = false
    fileprivate(set) var exhausted = false
    var canPresent: Bool { ready && listeners && transport && !resourceMutation && !transitioning && !exhausted }
}

/// The RPC actor owns its readiness fields. The original native module also
/// begins invalidation boundaries synchronously, BEFORE queueing actor updates.
/// The same recursive lock covers native commit/report and these publications.
/// No actor call or suspension is permitted in that native critical section.
fileprivate final class SefariaRPCSessionEpoch: @unchecked Sendable {
    private let lock = NSRecursiveLock()
    private var state = SefariaEmbeddedSurfaceRuntimeObservation()
    private var transitionDepth: UInt64 = 0
    func read() -> UInt64 { surface().epoch }
    func surface() -> SefariaEmbeddedSurfaceRuntimeObservation {
        lock.lock(); defer { lock.unlock() }; return state
    }
    func update(_ change: (inout SefariaEmbeddedSurfaceRuntimeObservation) -> Void) {
        lock.lock(); defer { lock.unlock() }
        change(&state)
        if state.revision == .max { state.exhausted = true } else { state.revision += 1 }
    }
    func write(_ value: UInt64) { update { $0.epoch = value } }
    // The public bump operation is also called directly by RuntimeManager.reset.
    // Nested callers keep the OUTERMOST lifecycle boundary closed. No callback
    // or continuation is invoked while this short state-publication lock is held.
    func beginTransition() {
        lock.lock(); defer { lock.unlock() }
        if transitionDepth == .max { state.exhausted = true }
        else { transitionDepth += 1 }
        update { $0.transitioning = true }
    }
    func endTransition() {
        lock.lock(); defer { lock.unlock() }
        guard transitionDepth > 0 else {
            update { $0.exhausted = true }; return
        }
        transitionDepth -= 1
        update { $0.transitioning = transitionDepth > 0 }
    }
    func retainSurface() throws -> SefariaEmbeddedSurfaceRuntimeToken {
        lock.lock(); defer { lock.unlock() }
        guard state.canPresent else { throw unavailable() }
        return .init(authority: self, observation: state)
    }
    func validate(_ expected: SefariaEmbeddedSurfaceRuntimeObservation) throws {
        lock.lock(); defer { lock.unlock() }
        guard state == expected, state.canPresent else { throw unavailable() }
    }
    @MainActor func withSurface<T>(_ expected: SefariaEmbeddedSurfaceRuntimeObservation,
                                  operation: @MainActor () throws -> T) throws -> T {
        lock.lock(); defer { lock.unlock() }
        guard state == expected, state.canPresent else { throw unavailable() }
        let value = try operation()
        guard state == expected, state.canPresent else { throw unavailable() }
        return value
    }
    /// Closed native Boolean handoff only. Its fixed caller acquires source
    /// latches and a ticket; no actor hop, JS, UIKit or user callback runs here.
    func claimSurface(_ expected: SefariaEmbeddedSurfaceRuntimeObservation,
                      claim: () -> Bool) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard state == expected, state.canPresent else { return false }
        return claim()
    }
    private func unavailable() -> SefariaRPCError {
        .init(code: "SURFACE_RUNTIME_CHANGED", message: "The original Sefaria runtime is not available for this retained surface.")
    }
}

/// This token cannot be decoded from public navigation input or rearmed after a
/// lifecycle change. It retains the bridge's authority, not a MainActor cache.
final class SefariaEmbeddedSurfaceRuntimeToken: @unchecked Sendable {
    fileprivate let authority: SefariaRPCSessionEpoch
    let observation: SefariaEmbeddedSurfaceRuntimeObservation
    fileprivate init(authority: SefariaRPCSessionEpoch, observation: SefariaEmbeddedSurfaceRuntimeObservation) {
        self.authority = authority; self.observation = observation
    }
    func validate() throws { try authority.validate(observation) }
    @MainActor func withValidRuntime<T>(_ operation: @MainActor () throws -> T) throws -> T {
        try authority.withSurface(observation, operation: operation)
    }
    func claimIfCurrent(_ claim: () -> Bool) -> Bool {
        authority.claimSurface(observation, claim: claim)
    }
}

/// One exact source-owned native lifecycle boundary. Queueing an actor update
/// never leaves a window in which its already-started native mutation can borrow
/// an earlier ready state. Nested/out-of-order boundaries stay closed until all
/// finish. Dropping an unfinished lease does NOT manufacture completion.
final class SefariaEmbeddedSurfaceRuntimeTransition: @unchecked Sendable {
    private let authority: SefariaRPCSessionEpoch
    private let completionLock = NSLock()
    private var finished = false
    fileprivate init(authority: SefariaRPCSessionEpoch) {
        self.authority = authority
        authority.beginTransition()
    }
    func finish() {
        completionLock.lock()
        guard !finished else { completionLock.unlock(); return }
        finished = true
        completionLock.unlock()
        authority.endTransition()
    }
}

/// Exact metadata for the original diagnostic RPC only. These values neither
/// authorize navigation nor alter normal RPC cancellation or response handling.
struct SefariaLateReplyDiagnosticToken: Sendable, Equatable {
    fileprivate let id: UUID
    let nonce: String
    let originalEpoch: UInt64
    let delayMs: Int
    let timeoutMs: Int
}

struct SefariaLateReplyDiagnosticEvidence: Codable, Sendable, Equatable {
    let requestID: String
    let nonce: String
    let originalEpoch: UInt64
    let currentEpoch: UInt64
    let jsReceived: Bool
    let originalCancellation: Bool
    let disposition: String
}


import Foundation

/// A native mount identity, never a public content locator or a JS navigation command.
struct SefariaEmbeddedSurfaceIdentity: Identifiable, Equatable, Sendable {
    let id: UUID
    let mountID: UUID
    let sceneID: String
    let epoch: UInt64

    var properties: [String: Any] {
        ["surfaceID": id.uuidString, "mountID": mountID.uuidString,
         "sceneID": sceneID, "epoch": epoch]
    }
    var valid: Bool {
        !sceneID.isEmpty && sceneID.count <= 256 && epoch > 0 && epoch <= 9_007_199_254_740_991
    }
}

/// Returned only after a real original ReaderApp instance completed its own init
/// and the React Native layout callback supplied nonzero original geometry.
struct SefariaEmbeddedSurfaceProof: Codable, Equatable, Sendable {
    struct Layout: Codable, Equatable, Sendable {
        let width: Double
        let height: Double
        let revision: UInt64
    }
    let contract: String
    let component: String
    let upstreamSHA: String
    let surfaceID: UUID
    let mountID: UUID
    let sceneID: String
    let epoch: UInt64
    let nonce: UUID
    let layout: Layout

    func matches(_ identity: SefariaEmbeddedSurfaceIdentity, nonce expectedNonce: UUID) -> Bool {
        identity.valid && contract == "chavrusa.original-rn-surface.v1" && component == "ReaderApp"
            && upstreamSHA == "2fd173a5a3bd32d94a9ba1222e4e32a37f6bd23c"
            && surfaceID == identity.id && mountID == identity.mountID
            && sceneID == identity.sceneID && epoch == identity.epoch && nonce == expectedNonce
            && layout.revision > 0 && layout.width.isFinite && layout.height.isFinite
            && layout.width > 0 && layout.height > 0
    }
}

/// Produced from the actual canonical receipt and the same still-visible native
/// host. Allocation, a headless handshake or a cached proof cannot construct it.
struct SefariaEmbeddedSurfaceAcceptanceEvidence: Codable, Sendable {
    let nativeReceiptID: UUID
    let nativeSceneID: String
    let nativeHostToken: UUID
    let runtimeRevision: UInt64
    let originalSurface: SefariaEmbeddedSurfaceProof
}

/// Original ReaderApp has process-wide tracker registrations. Keep at most one
/// visible original instance and never transfer it across scenes. Headless RPC
/// is independent and is neither claimed nor moved by this lease.
@MainActor final class SefariaEmbeddedSurfaceLease {
    static let shared = SefariaEmbeddedSurfaceLease()
    struct Lease: Equatable {
        let ownerID: UUID
        let identity: SefariaEmbeddedSurfaceIdentity
        let revision: UInt64
    }
    struct Snapshot: Equatable {
        let revision: UInt64
        let lease: Lease?
        let exhausted: Bool
    }
    private var revision: UInt64 = 0
    private var lease: Lease?
    private var exhausted = false
    var snapshot: Snapshot { .init(revision: revision, lease: lease, exhausted: exhausted) }

    func acquire(ownerID: UUID, identity: SefariaEmbeddedSurfaceIdentity,
                 expected: Snapshot) throws -> Lease {
        guard identity.valid, snapshot == expected, !exhausted, lease == nil, revision < .max else {
            throw SefariaRPCError(code: "SURFACE_LEASE_UNAVAILABLE", message: "The original Sefaria surface is unavailable.")
        }
        revision += 1
        let value = Lease(ownerID: ownerID, identity: identity, revision: revision)
        lease = value
        return value
    }
    func owns(_ value: Lease) -> Bool { !exhausted && lease == value }
    func release(_ value: Lease) {
        guard lease == value else { return }
        lease = nil
        if revision == .max { exhausted = true } else { revision += 1 }
    }
}

import Foundation

/// Fixed navigation destinations over the pinned ORIGINAL ReaderApp. These are
/// not selectors, text locators, queries, scripts or an independent executor.
enum SefariaEmbeddedSemanticTarget: String, Codable, CaseIterable, Sendable {
    case library, topics, learningSchedules, dedication

    var destinationID: String { "native.sefariaEmbedded." + rawValue }
    var isPublicNavigation: Bool { self != .dedication }
    var originalMenu: String {
        switch self {
        case .library: "navigation"
        case .topics: "topic toc"
        case .learningSchedules: "learning schedules"
        case .dedication: "dedication"
        }
    }
    var originalHeaderKey: String {
        switch self {
        case .library: "nav.browse_the_library"
        case .topics: "topics.explore_by_topic"
        case .learningSchedules: "learning_schedules.learning_schedules"
        case .dedication: "about.app_for_ios_and_android"
        }
    }
    /// Read-only witness text from the exact 2fd173a5 original en/he JSON. It is
    /// never rendered by this adapter. The schedules title is also in Library,
    /// so its original page-only description is mandatory as a second witness.
    func originalVisibleTexts(language: String) -> [String]? {
        guard language == "english" || language == "hebrew" else { return nil }
        let hebrew = language == "hebrew"
        switch self {
        case .library: return [hebrew ? "עיון בספריה" : "Browse the Library"]
        case .topics: return [hebrew ? "חיפוש לפי נושאים" : "Explore by Topic"]
        case .learningSchedules:
            return hebrew ? ["לוח לימוד יומי", "מימי קדם חולקה התורה לקטעי קריאה שבועיים שנועדו לסיום הספר כולו במשך תקופת זמן של שנה. בעקבות המנהג הזה התפתחו לאורך השנים סדרי לימוד תקופתיים רבים נוספים, ובעזרתם יכולות קהילות וקבוצות של לומדים ללמוד יחד טקסטים שלמים."]
                : ["Learning Schedules", "Since biblical times, the Torah has been divided into sections which are read each week on a set yearly calendar. Following this practice, many other calendars have been created to help communities of learners work through specific texts together."]
        case .dedication: return [hebrew ? "האפליקציה של ספריא עבור אנדרואיד ו-iOS" : "Sefaria App for iOS and Android"]
        }
    }
}

/// Private native-to-JS handoff identity. Public routing never decodes this type.
struct SefariaEmbeddedSemanticClaim: Codable, Equatable, Sendable {
    let ticketID: UUID
    let requestID: UUID
    let surfaceID: UUID
    let mountID: UUID
    let sceneID: String
    let epoch: UInt64
    let target: SefariaEmbeddedSemanticTarget
    let nonce: UUID

    static let fieldNames: Set<String> = ["ticketID", "requestID", "surfaceID", "mountID", "sceneID", "epoch", "target", "nonce"]
}

/// This record can only be created during the original Core apply. The claim
/// is the linearization point of its one original JS method invocation. No
/// callback, actor hop, I/O or JS execution is performed inside these locks.
final class SefariaEmbeddedSemanticTicket: @unchecked Sendable {
    let claim: SefariaEmbeddedSemanticClaim
    let deadlineUptimeNanoseconds: UInt64
    private let runtime: SefariaEmbeddedSurfaceRuntimeToken
    private let rootSource: NativeComponentSourceObservation
    private let originalSource: NativeComponentSourceObservation
    private let lock = NSLock()
    private var hostToken: UUID?
    private var claimed = false
    private var revoked = false

    init(requestID: UUID, identity: SefariaEmbeddedSurfaceIdentity,
         target: SefariaEmbeddedSemanticTarget, deadlineUptimeNanoseconds: UInt64,
         runtime: SefariaEmbeddedSurfaceRuntimeToken,
         rootSource: NativeComponentSourceObservation,
         originalSource: NativeComponentSourceObservation) throws {
        guard identity.valid, identity.epoch == runtime.observation.epoch,
              rootSource !== originalSource,
              deadlineUptimeNanoseconds > DispatchTime.now().uptimeNanoseconds else {
            throw SefariaRPCError(code: "SEMANTIC_HANDOFF_INVALID", message: "The original navigation admission is unavailable.")
        }
        claim = .init(ticketID: UUID(), requestID: requestID, surfaceID: identity.id,
            mountID: identity.mountID, sceneID: identity.sceneID, epoch: identity.epoch,
            target: target, nonce: UUID())
        self.deadlineUptimeNanoseconds = deadlineUptimeNanoseconds
        self.runtime = runtime; self.rootSource = rootSource; self.originalSource = originalSource
    }

    /// Caller already holds/revalidates the original MainActor source and Core
    /// admission. Only its exact first native host may arm this existing ticket.
    /// This method cannot create/renew a ticket, source or deadline.
    func arm(originalHostToken: UUID) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard !revoked, !claimed, hostToken == nil,
              DispatchTime.now().uptimeNanoseconds < deadlineUptimeNanoseconds else { return false }
        hostToken = originalHostToken
        return true
    }

    /// Lock order is fixed: runtime -> parent latch -> original/backend latch
    /// -> ticket. Publication/revocation acquires one latch only and never calls
    /// back into this path. There is no external/JS/user callback in this chain.
    fileprivate func consume(_ actual: SefariaEmbeddedSemanticClaim) -> Bool {
        guard actual == claim else { return false }
        return runtime.claimIfCurrent {
            rootSource.claimIfCurrent {
                originalSource.claimIfCurrent {
                    lock.lock(); defer { lock.unlock() }
                    guard !revoked, !claimed, hostToken != nil,
                          DispatchTime.now().uptimeNanoseconds < deadlineUptimeNanoseconds else { return false }
                    claimed = true
                    return true
                }
            }
        }
    }

    /// Cancellation invokes this synchronously, before queued MainActor cleanup.
    /// If the claim already won, keep that fact: original React work may commit.
    func revoke() {
        lock.lock(); defer { lock.unlock() }; revoked = true
    }
    var wasClaimed: Bool {
        lock.lock(); defer { lock.unlock() }; return claimed
    }
    var isArmed: Bool {
        lock.lock(); defer { lock.unlock() }; return hostToken != nil
    }
    var canSupportEvidence: Bool {
        lock.lock(); defer { lock.unlock() }; return claimed && !revoked && hostToken != nil
    }
    func matchesOriginalHost(_ token: UUID) -> Bool {
        lock.lock(); defer { lock.unlock() }; return hostToken == token
    }
}

/// Only the existing native module's closed synchronous export consumes records.
/// The registry lock is released before the source locks; retirement cannot form
/// a reverse lock edge. No public method creates a ticket from a JSON payload.
final class SefariaEmbeddedSemanticHandoffs: @unchecked Sendable {
    static let shared = SefariaEmbeddedSemanticHandoffs()
    private let lock = NSLock()
    private var tickets: [UUID: SefariaEmbeddedSemanticTicket] = [:]

    func register(_ ticket: SefariaEmbeddedSemanticTicket) throws {
        lock.lock(); defer { lock.unlock() }
        guard tickets[ticket.claim.ticketID] == nil else {
            throw SefariaRPCError(code: "SEMANTIC_HANDOFF_DUPLICATE", message: "The original navigation admission is already registered.")
        }
        tickets[ticket.claim.ticketID] = ticket
    }
    func remove(_ ticket: SefariaEmbeddedSemanticTicket, revoke: Bool) {
        if revoke { ticket.revoke() }
        lock.lock(); defer { lock.unlock() }
        if tickets[ticket.claim.ticketID] === ticket { tickets.removeValue(forKey: ticket.claim.ticketID) }
    }
    func claim(_ json: String) -> Bool {
        guard let data = json.data(using: .utf8), data.count <= 4096,
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              Set(object.keys) == SefariaEmbeddedSemanticClaim.fieldNames,
              let actual = try? JSONDecoder().decode(SefariaEmbeddedSemanticClaim.self, from: data) else { return false }
        lock.lock()
        let ticket = tickets[actual.ticketID]
        lock.unlock()
        return ticket?.consume(actual) == true
    }
}

/// Selected ORIGINAL state is observed on an actual JS frame after the original
/// method. It is only one part of acceptance: the real original native text and
/// geometry witness, retained source and canonical receipt remain mandatory.
struct SefariaEmbeddedSemanticProof: Codable, Equatable, Sendable {
    let contract: String
    let claim: SefariaEmbeddedSemanticClaim
    let originalSurface: SefariaEmbeddedSurfaceProof
    let originalMenu: String
    let originalHeaderKey: String
    let interfaceLanguage: String
    let originalRootSelection: Bool
    let originalInstanceRetained: Bool
    let observedAfterOriginalCall: Bool

    func matches(_ ticket: SefariaEmbeddedSemanticTicket, identity: SefariaEmbeddedSurfaceIdentity) -> Bool {
        contract == "chavrusa.original-rn-target.v1" && claim == ticket.claim
            && ticket.canSupportEvidence
            && originalSurface.matches(identity, nonce: claim.nonce)
            && originalMenu == claim.target.originalMenu
            && originalHeaderKey == claim.target.originalHeaderKey
            && claim.target.originalVisibleTexts(language: interfaceLanguage) != nil
            && originalRootSelection && originalInstanceRetained && observedAfterOriginalCall
    }
}

struct SefariaEmbeddedSemanticAcceptanceEvidence: Codable, Sendable {
    let nativeReceiptID: UUID
    let nativeSceneID: String
    let nativeHostToken: UUID
    let runtimeRevision: UInt64
    let actualOriginalViewCount: Int
    let originalTarget: SefariaEmbeddedSemanticProof
}

// Appended to exact original production types by the source-only runner.
// Observation/Foundation/locks/runtime/ticket code are real; UIKit/Core grant
// issuance/React execution are outside this executable and never claimed.
import Dispatch

@Observable @MainActor private final class SemanticOriginalState {
    var selection = 0
    var backendGeneration = 1
}
@MainActor private final class SemanticFixture {
    let original = SemanticOriginalState()
    let authority = SefariaRPCSessionEpoch()
    let root: NativeComponentSourceObservation
    let feature: NativeComponentSourceObservation
    let runtime: SefariaEmbeddedSurfaceRuntimeToken
    let ticket: SefariaEmbeddedSemanticTicket
    let registry = SefariaEmbeddedSemanticHandoffs()
    let identity: SefariaEmbeddedSurfaceIdentity
    let host = UUID()
    var json: String { get throws { String(decoding: try JSONEncoder().encode(ticket.claim), as: UTF8.self) } }
    init(arm: Bool = true, target: SefariaEmbeddedSemanticTarget = .library) throws {
        let original = self.original
        root = NativeComponentSourceObservation { _ = original.selection }
        feature = NativeComponentSourceObservation { _ = original.backendGeneration }
        authority.update { $0.ready = true; $0.listeners = true; $0.transport = true }
        runtime = try authority.retainSurface()
        identity = .init(id: UUID(), mountID: UUID(), sceneID: "original-native-scene", epoch: runtime.observation.epoch)
        ticket = try .init(requestID: UUID(), identity: identity, target: target,
            deadlineUptimeNanoseconds: DispatchTime.now().uptimeNanoseconds + 20_000_000_000,
            runtime: runtime, rootSource: root, originalSource: feature)
        try registry.register(ticket)
        if arm { precondition(ticket.arm(originalHostToken: host)) }
    }
}
private final class SemanticCount: Sendable { let value = Mutex(0) }
private final class SemanticBoolean: Sendable { let value = Mutex<Bool?>(nil) }
private struct SemanticControlError: Error { let message: String }
private struct SemanticControlResult: Codable { let name: String; let passed: Bool; let error: String? }
private struct SemanticControlReport: Codable {
    let scope: String; let passed: Int; let failed: Int; let results: [SemanticControlResult]
}
@main private struct SemanticHandoffControls {
    @MainActor private static var results: [SemanticControlResult] = []
    private static func expect(_ condition: @autoclosure () -> Bool, _ message: String) throws {
        guard condition() else { throw SemanticControlError(message: message) }
    }
    @MainActor private static func test(_ name: String, _ body: @MainActor () throws -> Void) {
        do { try body(); results.append(.init(name: name, passed: true, error: nil)) }
        catch { results.append(.init(name: name, passed: false, error: String(describing: error))) }
    }
    @MainActor private static func altered(_ fixture: SemanticFixture, _ key: String, _ value: Any) throws -> String {
        let data = try JSONEncoder().encode(fixture.ticket.claim)
        var object = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        object[key] = value
        return String(decoding: try JSONSerialization.data(withJSONObject: object), as: UTF8.self)
    }
    @MainActor static func main() {
        test("one exact armed ticket consumes once") {
            let f = try SemanticFixture(), json = try f.json
            try expect(f.registry.claim(json), "actual admitted claim rejected")
            try expect(!f.registry.claim(json), "same ticket executed twice")
            try expect(f.ticket.wasClaimed && f.ticket.canSupportEvidence, "claim state lost")
        }
        test("unarmed cold host cannot claim") {
            let f = try SemanticFixture(arm: false), json = try f.json
            try expect(!f.registry.claim(json), "claim preceded actual original host")
            try expect(f.ticket.arm(originalHostToken: f.host), "first host failed")
            try expect(f.registry.claim(json), "same original first host could not consume")
        }
        test("armed host cannot be replaced or rearmed") {
            let f = try SemanticFixture()
            try expect(!f.ticket.arm(originalHostToken: UUID()), "foreign host rearmed ticket")
            try expect(f.ticket.matchesOriginalHost(f.host), "original host changed")
        }
        test("cancellation before queued claim has zero consumption") {
            let f = try SemanticFixture(), json = try f.json; f.ticket.revoke()
            try expect(!f.registry.claim(json) && !f.ticket.wasClaimed, "cancelled queued effect consumed")
        }
        test("cancellation before cold host cannot later arm") {
            let f = try SemanticFixture(arm: false); f.ticket.revoke()
            try expect(!f.ticket.arm(originalHostToken: f.host), "cancelled ticket rearmed")
        }
        test("after-claim cancellation retains possible effect and rejects evidence") {
            let f = try SemanticFixture(), json = try f.json
            try expect(f.registry.claim(json), "initial claim failed"); f.ticket.revoke()
            try expect(f.ticket.wasClaimed, "committed-effect history erased")
            try expect(!f.ticket.canSupportEvidence && !f.registry.claim(json), "cancelled effect became receipt/replay")
        }
        test("original parent observation catches real equal write") {
            let f = try SemanticFixture(), json = try f.json; f.original.selection = 0
            try expect(!f.registry.claim(json), "original equal publication was accepted")
        }
        test("original parent observation catches real A B A") {
            let f = try SemanticFixture(), json = try f.json; f.original.selection = 1; f.original.selection = 0
            try expect(!f.registry.claim(json), "original parent ABA borrowed old source")
        }
        test("original backend/feature observation catches real A B A") {
            let f = try SemanticFixture(), json = try f.json; f.original.backendGeneration = 2; f.original.backendGeneration = 1
            try expect(!f.registry.claim(json), "backend ABA borrowed old source")
        }
        test("manual original publisher invalidation is synchronous") {
            let f = try SemanticFixture(), json = try f.json; f.feature.invalidate()
            try expect(!f.registry.claim(json), "manual publisher invalidation was delayed")
        }
        test("runtime publication with unchanged values retires retained token") {
            let f = try SemanticFixture(), json = try f.json; f.authority.update { $0.ready = true }
            try expect(!f.registry.claim(json), "runtime revision was ignored")
        }
        test("runtime ready A B A cannot restore ticket") {
            let f = try SemanticFixture(), json = try f.json
            f.authority.update { $0.ready = false }; f.authority.update { $0.ready = true }
            try expect(!f.registry.claim(json), "runtime ABA accepted")
        }
        test("native transition begins before actor update and blocks claim") {
            let f = try SemanticFixture(), json = try f.json; f.authority.beginTransition()
            try expect(!f.registry.claim(json), "queued runtime transition left claim open")
            f.authority.endTransition(); try expect(!f.registry.claim(json), "ended transition rearmed old ticket")
        }
        test("releasing exact source membership before claim refuses") {
            let f = try SemanticFixture(), json = try f.json; f.registry.remove(f.ticket, revoke: true)
            try expect(!f.registry.claim(json) && !f.ticket.wasClaimed, "released request consumed")
        }
        test("completed ticket membership removal preserves historical claim only") {
            let f = try SemanticFixture(), json = try f.json
            try expect(f.registry.claim(json), "claim failed"); f.registry.remove(f.ticket, revoke: false)
            try expect(!f.registry.claim(json) && f.ticket.wasClaimed, "completed record recreated authority")
        }
        test("duplicate native registry registration is rejected") {
            let f = try SemanticFixture(); var refused = false
            do { try f.registry.register(f.ticket) } catch { refused = true }
            try expect(refused, "duplicate ticket replaced owner")
        }
        for (key, value) in [("ticketID", UUID().uuidString), ("requestID", UUID().uuidString),
                             ("surfaceID", UUID().uuidString), ("mountID", UUID().uuidString),
                             ("nonce", UUID().uuidString), ("sceneID", "foreign-scene"),
                             ("target", "topics")] {
            test("exact private " + key + " rejects replacement") {
                let f = try SemanticFixture(), json = try altered(f, key, value)
                try expect(!f.registry.claim(json) && !f.ticket.wasClaimed, "changed " + key + " consumed")
            }
        }
        test("wrong runtime epoch refuses") {
            let f = try SemanticFixture(), json = try altered(f, "epoch", 999)
            try expect(!f.registry.claim(json), "wrong epoch consumed")
        }
        test("extra command field is rejected before lookup") {
            let f = try SemanticFixture(), json = try altered(f, "script", "arbitrary()")
            try expect(!f.registry.claim(json), "extra executable field accepted")
        }
        test("missing or mistyped ticket is rejected") {
            let f = try SemanticFixture()
            try expect(!f.registry.claim("{}"), "empty request accepted")
            let json = try altered(f, "ticketID", 17)
            try expect(!f.registry.claim(json), "mistyped ticket accepted")
        }
        test("one source latch cannot be nested into itself") {
            let f = try SemanticFixture(); var refused = false
            do {
                _ = try SefariaEmbeddedSemanticTicket(requestID: UUID(), identity: f.identity, target: .topics,
                    deadlineUptimeNanoseconds: .max, runtime: f.runtime, rootSource: f.root, originalSource: f.root)
            } catch { refused = true }
            try expect(refused, "same nonrecursive latch could be reacquired")
        }
        test("expired original admission cannot create a ticket") {
            let f = try SemanticFixture(); var refused = false
            do {
                _ = try SefariaEmbeddedSemanticTicket(requestID: UUID(), identity: f.identity, target: .topics,
                    deadlineUptimeNanoseconds: 1, runtime: f.runtime, rootSource: f.root, originalSource: f.feature)
            } catch { refused = true }
            try expect(refused, "expired admission minted an effect")
        }
        test("foreign retained runtime cannot be paired with identity") {
            let f = try SemanticFixture(); var refused = false
            let identity = SefariaEmbeddedSurfaceIdentity(id: UUID(), mountID: UUID(), sceneID: "scene", epoch: 999)
            do {
                _ = try SefariaEmbeddedSemanticTicket(requestID: UUID(), identity: identity, target: .topics,
                    deadlineUptimeNanoseconds: .max, runtime: f.runtime, rootSource: f.root, originalSource: f.feature)
            } catch { refused = true }
            try expect(refused, "wrong runtime identity was admitted")
        }
        test("JS-thread claim completes while MainActor is blocked") {
            let f = try SemanticFixture(), json = try f.json, registry = f.registry
            let result = SemanticBoolean(), done = DispatchSemaphore(value: 0)
            DispatchQueue.global().async { result.value.withLock { $0 = registry.claim(json) }; done.signal() }
            try expect(done.wait(timeout: .now() + 2) == .success, "claim required MainActor callback")
            try expect(result.value.withLock { $0 } == true, "closed off-main claim failed")
        }
        test("concurrent reentry consumes one original effect") {
            let f = try SemanticFixture(), json = try f.json, registry = f.registry
            let successes = SemanticCount()
            DispatchQueue.concurrentPerform(iterations: 32) { _ in
                if registry.claim(json) { successes.value.withLock { $0 += 1 } }
            }
            try expect(successes.value.withLock { $0 } == 1, "parallel callbacks consumed more than once")
        }
        test("simultaneous cancel and claim has one truthful linearization") {
            for _ in 0..<32 {
                let f = try SemanticFixture(), json = try f.json, registry = f.registry, ticket = f.ticket
                let successes = SemanticCount()
                DispatchQueue.concurrentPerform(iterations: 2) { index in
                    if index == 0 { ticket.revoke() }
                    else if registry.claim(json) { successes.value.withLock { $0 += 1 } }
                }
                let calls = successes.value.withLock { $0 }
                try expect((calls == 0 || calls == 1) && ticket.wasClaimed == (calls == 1), "effect history disagrees with claim")
                try expect(!ticket.canSupportEvidence, "post-cancel effect became successful evidence")
                try expect(!registry.claim(json), "cancel/claim race created another effect")
            }
        }
        test("finite target labels preserve original schedules disambiguation") {
            try expect(SefariaEmbeddedSemanticTarget.allCases.count == 4, "unexpected new target")
            try expect(!SefariaEmbeddedSemanticTarget.dedication.isPublicNavigation, "dedication became public")
            for language in ["english", "hebrew"] {
                try expect(SefariaEmbeddedSemanticTarget.learningSchedules.originalVisibleTexts(language: language)?.count == 2,
                           "Library preview title could masquerade as schedules")
            }
            try expect(SefariaEmbeddedSemanticTarget.topics.originalVisibleTexts(language: "unknown") == nil,
                       "unverified language witness accepted")
        }
        let report = SemanticControlReport(scope: "actual original Observation/runtime/Swift ticket source; UIKit/Core/JS boundaries, no app/native claim",
            passed: results.filter(\.passed).count, failed: results.filter { !$0.passed }.count, results: results)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        print(String(decoding: try! encoder.encode(report), as: UTF8.self))
        if report.failed > 0 { exit(1) }
    }
}
