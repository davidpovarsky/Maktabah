import Foundation
enum SefariaEmbeddedSemanticTarget: String, Codable, CaseIterable, Sendable {
    case library, topics, learningSchedules, dedication

    var destinationID: String { "native.sefariaEmbedded." + rawValue }
    var isPublicNavigation: Bool { self != .dedication }
    var originalMenu: String {
        switch self {
        case .library: "navigation"
        case .topics: "topic toc"
        case .learningSchedules: "learning schedules"
        case .dedication: "dedication"
        }
    }
    var originalHeaderKey: String {
        switch self {
        case .library: "nav.browse_the_library"
        case .topics: "topics.explore_by_topic"
        case .learningSchedules: "learning_schedules.learning_schedules"
        case .dedication: "about.app_for_ios_and_android"
        }
    }
    /// Read-only witness text from the exact 2fd173a5 original en/he JSON. It is
    /// never rendered by this adapter. The schedules title is also in Library,
    /// so its original page-only description is mandatory as a second witness.
    func originalVisibleTexts(language: String) -> [String]? {
        guard language == "english" || language == "hebrew" else { return nil }
        let hebrew = language == "hebrew"
        switch self {
        case .library: return [hebrew ? "עיון בספריה" : "Browse the Library"]
        case .topics: return [hebrew ? "חיפוש לפי נושאים" : "Explore by Topic"]
        case .learningSchedules:
            return hebrew ? ["לוח לימוד יומי", "מימי קדם חולקה התורה לקטעי קריאה שבועיים שנועדו לסיום הספר כולו במשך תקופת זמן של שנה. בעקבות המנהג הזה התפתחו לאורך השנים סדרי לימוד תקופתיים רבים נוספים, ובעזרתם יכולות קהילות וקבוצות של לומדים ללמוד יחד טקסטים שלמים."]
                : ["Learning Schedules", "Since biblical times, the Torah has been divided into sections which are read each week on a set yearly calendar. Following this practice, many other calendars have been created to help communities of learners work through specific texts together."]
        case .dedication: return [hebrew ? "האפליקציה של ספריא עבור אנדרואיד ו-iOS" : "Sefaria App for iOS and Android"]
        }
    }
}
struct SefariaEmbeddedSurfaceIdentity: Identifiable, Equatable, Sendable {
    let id: UUID
    let mountID: UUID
    let sceneID: String
    let epoch: UInt64

    var properties: [String: Any] {
        ["surfaceID": id.uuidString, "mountID": mountID.uuidString,
         "sceneID": sceneID, "epoch": epoch]
    }
    var valid: Bool {
        !sceneID.isEmpty && sceneID.count <= 256 && epoch > 0 && epoch <= 9_007_199_254_740_991
    }
}
// UIKit geometry/tree/hit-testing are EXPLICIT boundary inputs. The three
// original evidence methods and exact four target labels are compiled verbatim.
// This executable cannot establish UIKit/RN rendering or native acceptance.
struct UIEdgeInsets { var top: CGFloat = 0; var left: CGFloat = 0; var bottom: CGFloat = 0; var right: CGFloat = 0 }
extension CGRect {
    func inset(by value: UIEdgeInsets) -> CGRect {
        CGRect(x: minX + value.left, y: minY + value.top,
               width: width - value.left - value.right, height: height - value.top - value.bottom)
    }
}
@MainActor class UIView {
    weak var superview: UIView?
    var subviews: [UIView] = []
    var frame = CGRect(x: 0, y: 0, width: 100, height: 40)
    var bounds = CGRect(x: 0, y: 0, width: 100, height: 40)
    var isHidden = false; var alpha: CGFloat = 1; var clipsToBounds = false
    var isAccessibilityElement = false; var accessibilityLabel: String?
    var window: UIWindow? { self as? UIWindow ?? superview?.window }
    func addSubview(_ child: UIView) {
        child.superview?.subviews.removeAll { $0 === child }
        child.superview = self; subviews.append(child)
    }
    func isDescendant(of other: UIView) -> Bool {
        var current: UIView? = self
        while let item = current { if item === other { return true }; current = item.superview }
        return false
    }
    private var absoluteOrigin: CGPoint {
        var current: UIView? = self, x: CGFloat = 0, y: CGFloat = 0
        while let item = current, !(item is UIWindow) {
            x += item.frame.minX - item.bounds.minX; y += item.frame.minY - item.bounds.minY
            current = item.superview
        }
        return CGPoint(x: x, y: y)
    }
    func convert(_ rect: CGRect, to target: UIView) -> CGRect {
        let here = absoluteOrigin, there = target.absoluteOrigin
        return rect.offsetBy(dx: here.x - there.x, dy: here.y - there.y)
    }
}
@MainActor final class UILabel: UIView { var text: String? }
@MainActor final class UITextView: UIView { var text = "" }
@MainActor final class UIScrollView: UIView {
    var isDragging = false; var isDecelerating = false
    var adjustedContentInset = UIEdgeInsets()
}
@MainActor final class UIWindowScene {
    enum ActivationState { case foregroundActive, background }
    final class Session { var persistentIdentifier = "original-scene" }
    var session = Session(); var activationState = ActivationState.foregroundActive
}
@MainActor final class UIWindow: UIView {
    var isKeyWindow = true; var windowScene: UIWindowScene? = UIWindowScene()
    var rootViewController: UIViewController?
    var forcedHit: UIView?
    func hitTest(_ point: CGPoint, with event: Int?) -> UIView? {
        if let forcedHit { return forcedHit }
        func deepest(_ view: UIView) -> UIView? {
            guard !view.isHidden, view.alpha > 0.01,
                  view.convert(view.bounds, to: self).contains(point) else { return nil }
            for child in view.subviews.reversed() { if let hit = deepest(child) { return hit } }
            return view
        }
        return deepest(self)
    }
}
@MainActor class UIViewController {
    var viewIfLoaded: UIView?
    var view: UIView { viewIfLoaded! }
    var parent: UIViewController?
    var presentedViewController: UIViewController?
    var isBeingPresented = false; var isBeingDismissed = false
    var transitionCoordinator: Int?
}
// Host mount flags below are explicit original-lifecycle boundary inputs. They
// never manufacture an app acknowledgement, appearance callback or RN view.
@MainActor final class SefariaEmbeddedNativeSurfaceController: UIViewController {
    
    let identity: SefariaEmbeddedSurfaceIdentity
    let token = UUID()
    var reactView: UIView?
    var appeared = true; var attached = true; var detached = false
    init(identity: SefariaEmbeddedSurfaceIdentity) { self.identity = identity }
        func evidence() -> Evidence? {
        guard !detached, let original = reactView, let container = viewIfLoaded,
              original.superview === container, let window = container.window,
              original.window === window, let scene = window.windowScene else { return nil }
        let rect = original.convert(original.bounds, to: window)
        let area = rect.width * rect.height
        var visibleRect = rect.intersection(window.bounds)
        var visible = appeared && attached && window.isKeyWindow && !window.isHidden
            && scene.activationState == .foregroundActive && !rect.isEmpty
            && area.isFinite && area > 0 && scene.session.persistentIdentifier == identity.sceneID
        var alpha: CGFloat = 1
        var ancestor: UIView? = original
        while let item = ancestor {
            visible = visible && !item.isHidden; alpha *= item.alpha
            if item.clipsToBounds { visibleRect = visibleRect.intersection(item.convert(item.bounds, to: window)) }
            ancestor = item.superview
        }
        var transitioning = false
        var controller: UIViewController? = self
        while let item = controller {
            transitioning = transitioning || item.isBeingPresented || item.isBeingDismissed || item.transitionCoordinator != nil
            controller = item.parent
        }
        var top = window.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        if let top {
            if top !== window.rootViewController && !original.isDescendant(of: top.view) { visible = false }
            transitioning = transitioning || top.isBeingPresented || top.isBeingDismissed || top.transitionCoordinator != nil
        } else { visible = false }
        visible = visible && !transitioning && alpha >= 0.95 && !visibleRect.isNull
            && visibleRect.width * visibleRect.height >= area * 0.98
        return .init(sceneID: scene.session.persistentIdentifier, window: ObjectIdentifier(window), frame: rect,
                     mounted: attached, appeared: appeared, visible: visible, transitioning: transitioning)
    }
    func semanticEvidence(target: SefariaEmbeddedSemanticTarget, language: String) -> SemanticEvidence? {
        guard evidence()?.visible == true, let original = reactView, let window = original.window,
              let expected = target.originalVisibleTexts(language: language), !expected.isEmpty else { return nil }
        var remaining = [original], originals: [UIView] = []
        while let view = remaining.popLast() {
            guard originals.count < 8192 else { return nil }
            originals.append(view); remaining.append(contentsOf: view.subviews)
        }
        var witnesses: [UIView] = [], frames: [CGRect] = []
        for text in expected {
            let matches = originals.filter { view in
                guard view.window === window else { return false }
                if let label = view as? UILabel, label.text == text { return true }
                if let textView = view as? UITextView, textView.text == text { return true }
                return view.isAccessibilityElement && view.accessibilityLabel == text
            }
            // Some original renderers expose an AX wrapper and its own UIKit
            // text child. They describe one original view, not two siblings.
            let leaves = matches.filter { outer in
                !matches.contains { inner in inner !== outer && inner.isDescendant(of: outer) }
            }
            guard leaves.count == 1, let actual = leaves.first,
                  let rect = visibleOriginalText(actual, in: original, window: window) else { return nil }
            witnesses.append(actual); frames.append(rect)
        }
        guard Set(witnesses.map(ObjectIdentifier.init)).count == expected.count else { return nil }
        return .init(target: target, language: language, hostToken: token,
            originalViews: witnesses.map(ObjectIdentifier.init), frames: frames)
    }
    private func visibleOriginalText(_ text: UIView, in original: UIView, window: UIWindow) -> CGRect? {
        guard text.isDescendant(of: original), text.window === window else { return nil }
        let rect = text.convert(text.bounds, to: window), area = text.bounds.width * text.bounds.height
        guard !rect.isEmpty, area.isFinite, area > 0 else { return nil }
        var clipped = rect.intersection(window.bounds), alpha: CGFloat = 1
        var ancestor: UIView? = text
        while let view = ancestor {
            guard !view.isHidden else { return nil }
            alpha *= view.alpha
            if view.clipsToBounds { clipped = clipped.intersection(view.convert(view.bounds, to: window)) }
            if let scroll = view as? UIScrollView {
                guard !scroll.isDragging, !scroll.isDecelerating else { return nil }
                clipped = clipped.intersection(scroll.convert(scroll.bounds.inset(by: scroll.adjustedContentInset), to: window))
            }
            ancestor = view.superview
        }
        guard alpha >= 0.95, !clipped.isNull, clipped.width * clipped.height >= rect.width * rect.height * 0.98 else { return nil }
        let inset = min(1, min(rect.width, rect.height) / 4)
        let samples = [CGPoint(x: rect.midX, y: rect.midY),
            CGPoint(x: rect.minX + inset, y: rect.minY + inset), CGPoint(x: rect.maxX - inset, y: rect.minY + inset),
            CGPoint(x: rect.minX + inset, y: rect.maxY - inset), CGPoint(x: rect.maxX - inset, y: rect.maxY - inset)]
        for point in samples {
            guard let hit = window.hitTest(point, with: nil),
                  hit === text || hit.isDescendant(of: text) || text.isDescendant(of: hit) else { return nil }
        }
        return rect
    }
}
@MainActor private final class GeometryFixture {
    let window = UIWindow(), container = UIView(), original = UIView()
    let controller: SefariaEmbeddedNativeSurfaceController
    var labels: [UILabel] = []
    init(_ target: SefariaEmbeddedSemanticTarget = .library, language: String = "english") {
        controller = SefariaEmbeddedNativeSurfaceController(identity: .init(id: UUID(), mountID: UUID(), sceneID: "original-scene", epoch: 1))
        window.bounds = CGRect(x: 0, y: 0, width: 600, height: 800)
        window.frame = window.bounds
        container.frame = window.bounds; container.bounds = window.bounds
        original.frame = window.bounds; original.bounds = window.bounds
        window.addSubview(container); container.addSubview(original)
        controller.viewIfLoaded = container; controller.reactView = original
        window.rootViewController = controller
        for (index, text) in target.originalVisibleTexts(language: language)!.enumerated() {
            let label = UILabel(); label.text = text
            label.frame = CGRect(x: 20, y: 50 + 100 * index, width: 500, height: 60)
            label.bounds = CGRect(x: 0, y: 0, width: 500, height: 60)
            original.addSubview(label); labels.append(label)
        }
    }
    func visible(_ target: SefariaEmbeddedSemanticTarget = .library, _ language: String = "english") -> Bool {
        controller.semanticEvidence(target: target, language: language) != nil
    }
}
@main private struct SemanticGeometryControls {
    @MainActor static func main() throws {
        var results: [[String: Any]] = []
        func test(_ name: String, _ body: () -> Bool) { results.append(["name": name, "passed": body()]) }
        for target in SefariaEmbeddedSemanticTarget.allCases {
            for language in ["english", "hebrew"] {
                test("actual original \(target.rawValue) \(language) text and geometry") {
                    let f = GeometryFixture(target, language: language)
                    let result = f.controller.semanticEvidence(target: target, language: language)
                    return result?.hostToken == f.controller.token && result?.target == target
                        && result?.originalViews == f.labels.map(ObjectIdentifier.init)
                }
            }
        }
        test("original schedules title alone does not prove page") {
            let f = GeometryFixture(.learningSchedules); f.labels[1].text = "Library preview"
            return !f.visible(.learningSchedules)
        }
        test("original Topics loading does not prove topic table") {
            let f = GeometryFixture(.topics); f.labels[0].text = "Loading…"
            return !f.visible(.topics)
        }
        test("unknown language is not inferred") { !GeometryFixture().visible(.library, "unknown") }
        test("two original siblings with same title refuse ambiguity") {
            let f = GeometryFixture(), other = UILabel(); other.text = f.labels[0].text
            other.frame = f.labels[0].frame.offsetBy(dx: 0, dy: 100); other.bounds = f.labels[0].bounds
            f.original.addSubview(other); return !f.visible()
        }
        test("original AX wrapper plus its text child is one witness") {
            let f = GeometryFixture(), wrapper = UIView()
            wrapper.frame = f.labels[0].frame; wrapper.bounds = f.labels[0].bounds
            wrapper.isAccessibilityElement = true; wrapper.accessibilityLabel = f.labels[0].text
            f.original.addSubview(wrapper); wrapper.addSubview(f.labels[0]); f.labels[0].frame.origin = .zero
            return f.visible()
        }
        test("actual original AX text without UILabel is supported") {
            let f = GeometryFixture(); f.labels[0].text = nil
            f.labels[0].isAccessibilityElement = true; f.labels[0].accessibilityLabel = "Browse the Library"
            return f.visible()
        }
        test("hidden text refuses") { let f = GeometryFixture(); f.labels[0].isHidden = true; return !f.visible() }
        test("faded ancestor refuses") { let f = GeometryFixture(); f.original.alpha = 0.9; return !f.visible() }
        test("partially clipped original text refuses") {
            let f = GeometryFixture(); f.original.clipsToBounds = true
            f.labels[0].frame.origin.x = 580; return !f.visible()
        }
        test("original scroll safe-area clipping refuses") {
            let f = GeometryFixture(), scroll = UIScrollView()
            scroll.frame = f.original.frame; scroll.bounds = f.original.bounds
            scroll.adjustedContentInset.top = 100
            f.original.addSubview(scroll); scroll.addSubview(f.labels[0]); return !f.visible()
        }
        test("original scroll drag refuses") {
            let f = GeometryFixture(), scroll = UIScrollView(); scroll.frame = f.original.frame; scroll.bounds = f.original.bounds
            f.original.addSubview(scroll); scroll.addSubview(f.labels[0]); scroll.isDragging = true; return !f.visible()
        }
        test("original scroll deceleration refuses") {
            let f = GeometryFixture(), scroll = UIScrollView(); scroll.frame = f.original.frame; scroll.bounds = f.original.bounds
            f.original.addSubview(scroll); scroll.addSubview(f.labels[0]); scroll.isDecelerating = true; return !f.visible()
        }
        test("occluding sibling hit-test refuses") {
            let f = GeometryFixture(), cover = UIView(); f.container.addSubview(cover); f.window.forcedHit = cover
            return !f.visible()
        }
        test("actual original text child hit-test is allowed") {
            let f = GeometryFixture(), child = UIView(); f.labels[0].addSubview(child); f.window.forcedHit = child
            return f.visible()
        }
        test("wrong actual scene refuses") {
            let f = GeometryFixture(); f.window.windowScene!.session.persistentIdentifier = "other-scene"; return !f.visible()
        }
        test("background actual scene refuses") {
            let f = GeometryFixture(); f.window.windowScene!.activationState = .background; return !f.visible()
        }
        test("non-key window refuses") { let f = GeometryFixture(); f.window.isKeyWindow = false; return !f.visible() }
        test("unappeared host refuses") { let f = GeometryFixture(); f.controller.appeared = false; return !f.visible() }
        test("detached host refuses") { let f = GeometryFixture(); f.controller.detached = true; return !f.visible() }
        test("original presentation transition refuses") {
            let f = GeometryFixture(); f.controller.isBeingPresented = true; return !f.visible()
        }
        test("foreign top modal refuses") {
            let f = GeometryFixture(), modal = UIViewController(), view = UIView()
            modal.viewIfLoaded = view; f.window.addSubview(view); f.controller.presentedViewController = modal
            return !f.visible()
        }
        test("no exact original title refuses") { let f = GeometryFixture(); f.labels[0].text = "Other library"; return !f.visible() }
        test("zero area text refuses") { let f = GeometryFixture(); f.labels[0].bounds.size = .zero; return !f.visible() }
        test("bounded original subtree fails closed") {
            let f = GeometryFixture(); for _ in 0..<8192 { f.original.addSubview(UIView()) }; return !f.visible()
        }
        let failed = results.filter { $0["passed"] as? Bool != true }.count
        let data = try JSONSerialization.data(withJSONObject: ["scope": "Verbatim original evidence methods; explicit UIKit geometry/tree/hit-test boundary, native NOT_RUN",
            "passed": results.count - failed, "failed": failed, "results": results], options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: data, as: UTF8.self)); if failed > 0 { exit(1) }
    }
}
