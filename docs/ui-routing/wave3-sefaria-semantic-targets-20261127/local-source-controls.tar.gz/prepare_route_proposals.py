from pathlib import Path
r=Path(__file__).parent; prefix=Path('Source/ChavrusaText/UIRoutingHost/Integration')
def load(name): return (r/'shared-baseline'/prefix/name).read_text()
def save(name,s): (r/'shared-proposal'/prefix/name).write_text(s)
def replace(s,a,b):
 assert s.count(a)==1,(s.count(a),a[:100]); return s.replace(a,b,1)
s=load('MaktabahNativePublicBindingAdapter.swift')
s=replace(s,'case "native.sefariaEmbedded": return readySefariaSurface','case "native.sefariaEmbedded", "native.sefariaEmbedded.library", "native.sefariaEmbedded.topics",\n             "native.sefariaEmbedded.learningSchedules": return readySefariaSurface')
s=replace(s,'destination != MaktabahNativeSefariaSurfaceBinding.destination,','!MaktabahNativeSefariaSurfaceBinding.accepts(destination),')
s=replace(s,'case ("native.sefariaEmbedded", .sheet, false): return .sefariaEmbedded','case ("native.sefariaEmbedded", .sheet, false), ("native.sefariaEmbedded.library", .sheet, false),\n             ("native.sefariaEmbedded.topics", .sheet, false), ("native.sefariaEmbedded.learningSchedules", .sheet, false): return .sefariaEmbedded')
save('MaktabahNativePublicBindingAdapter.swift',s)
s=load('MaktabahNativeSceneProjection.swift')
s=replace(s,'            guard actual.requested, actual.mounted, actual.visible, actual.ready,\n                  !actual.transitioning else { return nil }','            guard actual.requested, actual.mounted, actual.visible, actual.ready,\n                  !actual.transitioning, let destination = binding.observedDestination else { return nil }')
s=replace(s,'return .init(destination: MaktabahNativeSefariaSurfaceBinding.destination,','return .init(destination: destination,')
save('MaktabahNativeSceneProjection.swift',s)
s=load('MaktabahNativeRoutingComposition.swift')
needle='''            .init(id: id("native.reader.inspector"), title: "Study Tools".localized, implementation: .implemented,'''
new='''            .init(id: id("native.sefariaEmbedded.library"), title: workspaceText("Sefaria Library", "ספריית ספריא"),
                  implementation: .implemented, supportedBackends: [.sefariaEmbedded], presentations: [.sheet],
                  publicNavigationV2: .init(rules: [.init(presentation: .sheet)])),
            .init(id: id("native.sefariaEmbedded.topics"), title: workspaceText("Sefaria Topics", "נושאים בספריא"),
                  implementation: .implemented, supportedBackends: [.sefariaEmbedded], presentations: [.sheet],
                  publicNavigationV2: .init(rules: [.init(presentation: .sheet)])),
            .init(id: id("native.sefariaEmbedded.learningSchedules"), title: workspaceText("Sefaria Learning Schedules", "לוח הלימוד של ספריא"),
                  implementation: .implemented, supportedBackends: [.sefariaEmbedded], presentations: [.sheet],
                  publicNavigationV2: .init(rules: [.init(presentation: .sheet)])),
            // Original inventory: guide-only semantic target. No public v1/v2
            // URL policy, system entity or current Hanlin public-URL exposure.
            .init(id: id("native.sefariaEmbedded.dedication"), title: workspaceText("Sefaria Dedication", "הקדשת ספריא"),
                  implementation: .implemented, supportedBackends: [.sefariaEmbedded], presentations: [.sheet]),
'''+needle
s=replace(s,needle,new)
s=replace(s,'    func open(destination: NativeIntentService.Destination) async throws -> UISceneAcknowledgement {\n        guard let entry', '''    func open(destination: NativeIntentService.Destination) async throws -> UISceneAcknowledgement {
        guard MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: destination.destination)?.isPublicNavigation != false else {
            throw UIRouteError(.notSupported, "native_sefaria_guide_only")
        }
        guard let entry''')
old='destination.destination == MaktabahNativeSefariaSurfaceBinding.destination';assert s.count(old)==2
s=s.replace(old,'MaktabahNativeSefariaSurfaceBinding.accepts(destination.destination)')
# Keep the existing public binder unavailable for dedication. The Guide gets
# one typed internal branch below, using the same original Core/orchestrator.
s=replace(s,'            return try await open(public: intent, sceneID: sceneID, managerID: managerID,\n                                  expectedSnapshot: before.backendSnapshot, origin: .guide, until: deadline)', '''            if MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: intent.destination) == .dedication {
                guard intent.presentation == .sheet, intent.content == nil, intent.component == nil,
                      intent.backend == nil || intent.backend == before.backendSnapshot.backend else {
                    throw UIRouteError(.notSupported, "native_sefaria_guide_shape_invalid")
                }
                return try await openOriginalSefariaGuide(sceneID: sceneID, managerID: managerID,
                    expectedSnapshot: before.backendSnapshot, until: deadline)
            }
            return try await open(public: intent, sceneID: sceneID, managerID: managerID,
                                  expectedSnapshot: before.backendSnapshot, origin: .guide, until: deadline)''')
anchor='    /// Public content uses the original current Reader or R\'s exact new-tab\n'
helper='''    /// The finite original dedication target is deliberately absent from all
    /// public URL policies/entities. This private Guide continuation retains its
    /// parent BEFORE the first await and uses the existing canonical Core commit.
    private func openOriginalSefariaGuide(sceneID: UIStableID, managerID: ObjectIdentifier,
        expectedSnapshot: ActionBackendSnapshot, until end: UInt64) async throws -> UISceneAcknowledgement {
        try Task.checkCancellation()
        guard let entry = scenes[sceneID], entry.managerID == managerID,
              entry.session.foreground, contexts[sceneID] == nil,
              expectedSnapshot.backend == .sefariaEmbedded,
              try backend.currentBackendSnapshot() == expectedSnapshot,
              SystemActionClock().now() < end else {
            throw UIRouteError(.unavailable, "native_sefaria_guide_source_unavailable")
        }
        let destination = UIDestinationID(rawValue: SefariaEmbeddedSemanticTarget.dedication.destinationID)!
        let invocation = ActionPortInvocation(requestId: UUID(), snapshot: expectedSnapshot,
                                               deadlineUptimeNanoseconds: end)
        try entry.session.retainParentSource(destination: destination, requestID: invocation.requestId)
        defer { entry.session.releaseParentSource(destination: destination, requestID: invocation.requestId) }
        let context = context(sceneID: sceneID, origin: .guide, snapshot: expectedSnapshot)
        try issue(context, sceneID: sceneID)
        defer { finish(context, sceneID: sceneID) }
        let scene = try await directory.currentScene(sceneID: sceneID, context: context, invocation: invocation)
        guard scenes[sceneID]?.session === entry.session, entry.managerID == managerID else {
            throw UIRouteError(.staleState, "native_sefaria_guide_owner_changed")
        }
        let route = try entry.session.prepareOriginalSefariaGuide(invocation: invocation, scene: scene)
        let command = try UISceneCommand(route: registry.validate(route), invocation: invocation, scene: scene)
        let result = try await orchestrator.commit(command, context: context)
        record(result)
        return result
    }

'''
s=replace(s,anchor,helper+anchor)
s=replace(s,'values += descriptors.map { .init(backend: snapshot.backend, destination: $0.id, title: $0.title + " — " + windowLabel, sceneID: id) }', '''values += descriptors.filter {
                MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: $0.id)?.isPublicNavigation != false
            }.map { .init(backend: snapshot.backend, destination: $0.id, title: $0.title + " — " + windowLabel, sceneID: id) }''')
s=replace(s,'                && !descriptor.mutatesUserData && !descriptor.allowsPrivateState {','                && !descriptor.mutatesUserData && !descriptor.allowsPrivateState\n                && MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: descriptor.id)?.isPublicNavigation != false {')
save('MaktabahNativeRoutingComposition.swift',s)
# This Session proposal already contains the closed source/window fences.
p=r/'shared-proposal'/prefix/'MaktabahNativeSceneSession.swift';s=p.read_text()
anchor='    func prepare(destination: UIDestinationID, invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {\n'
helper='''    /// Only the private original Guide branch calls this finite preparation.
    /// It creates no grant; the existing Core/orchestrator owns the same commit.
    func prepareOriginalSefariaGuide(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        let destination = UIDestinationID(rawValue: SefariaEmbeddedSemanticTarget.dedication.destinationID)!
        guard scene.sceneID == sceneID, invocation.snapshot.backend == .sefariaEmbedded,
              scene.backendSnapshot == invocation.snapshot, isRootAvailable(destination),
              isPresentationReady(for: destination) else {
            throw UIRouteError(.unavailable, "native_sefaria_guide_unavailable")
        }
        try validateParentSource(destination: destination, requestID: invocation.requestId)
        let identity = try project().identity(workspacePresentation: workspacePresentation,
            sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding)
        return RouteSpec(requestId: invocation.requestId, destination: destination, backend: invocation.snapshot.backend,
            presentation: .init(kind: .sheet),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision), expectedBackendSnapshot: invocation.snapshot)
    }

'''
s=replace(s,anchor,helper+anchor);p.write_text(s)
print('Exact four shared route proposals prepared; dedication stays private Guide only.')
