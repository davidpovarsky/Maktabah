from pathlib import Path
r=Path(__file__).parent
p=Path('Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift')
s=(r/'shared-baseline'/p).read_text()
def once(a,b):
 global s
 assert s.count(a)==1,(s.count(a),a[:120]);s=s.replace(a,b,1)
once('@MainActor final class MaktabahNativeWindowSource {','@MainActor @Observable final class MaktabahNativeWindowSource {')
once('    @discardableResult\n    func observe(_ window:', '''    /// Read only ORIGINAL window-owner fields into a one-shot source latch.
    /// Observation retires it synchronously before a source/window write; the
    /// existing observe/retain/readiness bodies and UIKit ownership are intact.
    func trackOriginalPublication() {
        _ = source; _ = window; _ = observationRevision
    }

    @discardableResult
    func observe(_ window:''')
once('    private let observation: NativeComponentSourceObservation\n    private let managerID:', '    private let observation: NativeComponentSourceObservation\n    private let originalWindow: MaktabahNativeWindowObservation?\n    private let managerID:')
once('         workspace: MaktabahNativeWorkspacePresentationBinding,\n         readForeignPresentations:', '         workspace: MaktabahNativeWorkspacePresentationBinding,\n         originalWindow: MaktabahNativeWindowObservation? = nil,\n         readForeignPresentations:')
once('        let manager = bindings.manager\n        observation = NativeComponentSourceObservation {', '        let manager = bindings.manager\n        self.originalWindow = originalWindow\n        observation = NativeComponentSourceObservation {\n            _ = bindings.rootPublications?.selectionRevision; _ = bindings.rootPublications?.settingsRevision\n            _ = manager.nativeModePresentationRevision; _ = manager.selectedBookPresentationRevision')
once('        try observation.validate()\n        let manager = bindings.manager\n', '        try observation.validate()\n        _ = try originalWindow?.validate()\n        let manager = bindings.manager\n')
once('    func invalidate() { observation.invalidate() }\n}', '''    var claimObservation: NativeComponentSourceObservation { observation }
    func invalidate() { observation.invalidate() }
}''')
once('            throw UIRouteError(.staleState, "native_sefaria_original_root_changed")\n        }\n    }', '            throw UIRouteError(.staleState, "native_sefaria_original_root_changed")\n        }\n        try observation.validate()\n        _ = try originalWindow?.validate()\n    }')
# Every fixed RN semantic target uses the same original parent lifecycle.
old='destination == MaktabahNativeSefariaSurfaceBinding.destination'
assert s.count(old)==5,s.count(old)
s=s.replace(old,'MaktabahNativeSefariaSurfaceBinding.accepts(destination)')
once('            let root = try MaktabahNativeSefariaRootSource(bindings: bindings, workspace: workspacePresentation) { [weak self] in', '''            let target = MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: destination)
            let originalWindow = try target.map { _ in try retainOriginalWindowObservation() }
            let originalWindowSource = windowSource
            let root = try MaktabahNativeSefariaRootSource(bindings: bindings, workspace: workspacePresentation,
                originalWindow: originalWindow) { [weak self] in''')
once('                _ = mounted; _ = foreground; _ = studyChatPresentationID\n                // The original note editor', '                _ = mounted; _ = foreground; _ = studyChatPresentationID\n                if target != nil { originalWindowSource?.trackOriginalPublication() }\n                // The original note editor')
once('            try original.retainSource(requestID: requestID)\n            do { try root.validate', '            try original.retainSource(requestID: requestID, target: target,\n                parentClaimObservation: target == nil ? nil : root.claimObservation)\n            do { try root.validate')
once('            try original.validateSource(requestID: requestID)\n            guard sefariaRootSources', '            try original.validateSource(requestID: requestID,\n                target: MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: destination))\n            guard sefariaRootSources')
once('        if windowSource !== source {\n            if let revision = windowSourceRevision', '''        if windowSource !== source {
            // Retire the old exact owner before publishing its replacement;
            // the queued native-to-JS handoff cannot borrow the old window.
            sefariaRootSources.values.forEach { $0.invalidate() }
            completedSefariaRootSource?.invalidate()
            if let revision = windowSourceRevision''')
once('let sefaria = value.route.route.destination == MaktabahNativeSefariaSurfaceBinding.destination','let sefaria = MaktabahNativeSefariaSurfaceBinding.accepts(value.route.route.destination)')
once('try sefariaSurfaceBinding.begin(requestID: value.invocation.requestId, validate: parentValidation)', '''try sefariaSurfaceBinding.begin(requestID: value.invocation.requestId,
                    target: MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: value.route.route.destination),
                    deadlineUptimeNanoseconds: value.invocation.deadlineUptimeNanoseconds, validate: parentValidation)''')
# The switches remain a closed finite literal set, not a prefix match.
assert s.count('case "native.sefariaEmbedded":')==2
s=s.replace('case "native.sefariaEmbedded":','case "native.sefariaEmbedded", "native.sefariaEmbedded.library", "native.sefariaEmbedded.topics",\n             "native.sefariaEmbedded.learningSchedules", "native.sefariaEmbedded.dedication":')
old='command.route.route.destination == MaktabahNativeSefariaSurfaceBinding.destination';assert s.count(old)==2
s=s.replace(old,'MaktabahNativeSefariaSurfaceBinding.accepts(command.route.route.destination)')
once('evidence.surface.destination == MaktabahNativeSefariaSurfaceBinding.destination,','MaktabahNativeSefariaSurfaceBinding.accepts(evidence.surface.destination),')
once('guard route.destination != MaktabahNativeSefariaSurfaceBinding.destination,','guard !MaktabahNativeSefariaSurfaceBinding.accepts(route.destination),')
once('guard destination != MaktabahNativeSefariaSurfaceBinding.destination else {','guard !MaktabahNativeSefariaSurfaceBinding.accepts(destination) else {')
once('            // The sole Core-authorized commit publishes only this original RN\n            // sheet. Root selection, Reader, query and Settings stay untouched.', '''            // The sole Core-authorized commit opens the original RN sheet.
            // A semantic target additionally retains its exact private one-use
            // handoff; Maktabah's root/Reader/Settings remain untouched.''')
(r/'shared-proposal'/p).write_text(s)
