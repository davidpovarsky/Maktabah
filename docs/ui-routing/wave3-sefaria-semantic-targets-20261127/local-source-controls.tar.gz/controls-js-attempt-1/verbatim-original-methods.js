  modifyHistory = ({ dir, ...args }) => {
    /**
     * dir is either "back" or "forward"
     * ...args are either the arguments for TabHistory.back() or TabHistory.forward(), depending on the value of `dir`
     */
    const func = this.tabHistory[dir];
    return func({ tab: this.state.footerTab, ...args });
  };
  openMenu = (menu, via, pushHistory=true) => {
    if (!!menu && pushHistory && !SKIP_MENUS.includes(this.state.menuOpen)) {
      if (!this.state.menuOpen && !!this.state.data) {
        // text column. remove related data
        this.state.relatedBySectionRef = {};
      }
      this.modifyHistory({ dir: "forward", state: this.state });
    }
    // openLogin/openRegister are handed straight to onPress in places, so `via`
    // can arrive as a press event rather than a source name. Only a non-empty
    // string counts as a source.
    const source = (typeof via === 'string' && via) ? via : null;
    this.setState({menuOpen: menu, menuOpenSource: source});
    if (source) {
      trackEvent("OpenMenu", {menu, via});
    }
  };
  openNav = () => {
      this.clearAllSearchFilters('text');
      this.setState({
        loaded: true,
        searchQuery: "",
        navigationCategories: [],
        textSearchState: new SearchState({type: 'text'}),
        textListVisible: false,
        connectionsMode: null,
        dictLookup: null,
      });
      this.openMenu("navigation");
  };
  openTopicToc = (pushHistory) => {
    this.setState({navigationTopic: null});
    this.openMenu('topic toc', null, pushHistory);
  };
  clearAllSearchFilters = type => {
    const searchState = this._getSearchState(type);
    for (let filterNode of searchState.availableFilters) {
      filterNode.setUnselected(true);
    }
    this.reapplySearchFilters(type);
  };
  reapplySearchFilters = type => {
    const searchState = this._getSearchState(type);
    const searchStateName = this._getSearchStateName(type);
    this.setState({
      [searchStateName]: searchState.update(
        Sefaria.search.getAppliedSearchFilters(searchState.availableFilters)
      )
    });
  }
  _getSearchStateName = type => ( `${type}SearchState` );
  _getSearchState = type => ( this.state[this._getSearchStateName(type)] );