"""Seal the reviewed source proposals; never changes an application checkout."""
from pathlib import Path
import base64
import difflib
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "source-capsule"
OUT.mkdir(exist_ok=True)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    path.write_bytes(raw)
    return {"path": name, "bytes": len(raw), "sha256": sha(raw)}


rows = []
snapshots = {}
for proposed in sorted((ROOT / "shared-proposal").rglob("*.swift")):
    name = proposed.relative_to(ROOT / "shared-proposal").as_posix()
    baseline = ROOT / "shared-baseline" / name
    if not baseline.is_file():
        baseline = ROOT / "baseline" / name
    before, after = baseline.read_bytes(), proposed.read_bytes()
    assert before != after, name
    patch = "".join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                      "a/" + name, "b/" + name)).encode()
    patch_name = "shared-proposals/" + proposed.stem + ".patch"
    proof = write(patch_name, patch)
    rows.append({"path": name, "before": {"bytes": len(before), "sha256": sha(before)},
                 "after": {"bytes": len(after), "sha256": sha(after)}, "patch": proof,
                 "application": "ROOT_OWNED_EXACT_HUNKS_ONLY_NOT_APPLIED_BY_THIS_LANE"})
    snapshots[name] = {"before": base64.b64encode(before).decode(), "after": base64.b64encode(after).decode()}
assert len(rows) == 10
write("SHARED_PROPOSALS.json", {"base": "37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be",
    "current_root_session_has_later_group_hunks": True, "full_file_replacement_authorized": False,
    "owned_product_source": "d4e25c0cf5581427d6742ade1d4d1e0f3ddaa1a3", "rows": rows,
    "unchanged_bodies": ["original root and window nonobservable metadata classes",
        "ignored currentMode revision and original setter body/order",
        "original Guide validator names/order and all its prior guards"],
    "not_covered": ["new Annotations original State publication facet requested after d4e seal",
        "integrated app SDK compile", "Guide execution", "React bridge ABI", "native UI"]})
write("shared-proposals/exact-source-pairs.json.gz", gzip.compress(
    (json.dumps(snapshots, sort_keys=True, separators=(",", ":")) + "\n").encode(), mtime=0))
for name in ("CONTRACT_PROPOSAL.md", "ORIGINAL_45_CLASSIFICATION.json", "BASE_INPUTS.json",
             "ADDITIONAL_BASE_INPUTS.json", "UPSTREAM_INPUTS.json", "I18N_SOURCE_INPUTS.json",
             "PINNED_ORIGINAL_45_SOURCE.json.gz"):
    write("provenance/" + name, (ROOT / name).read_bytes())

write("PEER_REVIEWS.json", {"scope": "SOURCE_ONLY_NO_PEER_RERUN_OR_NATIVE_CLAIM", "reviews": [
    {"reviewer": "/root/navigation_fix", "scope": "closed claim and cancellation call sites",
     "pins": ["cd342245b2d7983bff2e05ea6500d097543531e64a4a73d369ba696537f3bb83",
              "f33216f75a32f46e220613b31e828d7f024cc8c5312b3d4df0da61dc606f5db3"],
     "finding": "No demonstrated blocker in fixed runtime/root/backend/ticket lock order, registry removal and consumed-ticket completion seam; not full JS/UIKit/shared integration."},
    {"reviewer": "/root/navigation_fix", "scope": "final four passive publication source proposals",
     "pins": ["24ff00ddfc80351456bda7270ecb7a5bb48e2029fa9991721e3aa1d8d3a35e3f",
              "7e752dde2a43cf4625e12149dd9bc7b3fb383f0fdfdb529cd380bfa456f60532",
              "f1c0a83426240ee40fc73f3aee5cd123129560bacf3cab1a6af2d3aa8f51b63a",
              "ccb03fccc09f49f6591f8fa7d1635fce02e73b045217bb222d2ef671d5fea83c"],
     "finding": "No demonstrated blocker: register before getters, clear weak batch before fixed Boolean invalidation, preserve ignored counter and existing same-owner/foreign-detach semantics."},
    {"reviewer": "/root/navigation_fix", "scope": "Workspace prepublication and deinit source seam",
     "pins": ["1606d28d5ada936eb071bc8ed01c0452db7e2b45e0ee9ee30b25da862de5ebf8",
              "67b734f8c1a5e2a28b95a5ee7a23625f565a23eee06449b41cd7834f47c47eaf",
              "ba40fc67d860a5530259a77a515e3f9980250ffcd3fff87beb85a79c15364e53"],
     "finding": "No demonstrated blocker in invalidation before publishing/observer/deinit and register-before-inspect with validation afterward. Same-object early return unchanged."},
    {"reviewer": "/root/ui_acceptance", "scope": "apply, structured await, finish and release",
     "pins": ["ba40fc67d860a5530259a77a515e3f9980250ffcd3fff87beb85a79c15364e53"],
     "finding": "No additional demonstrated blocker. RetainedRequest rejoins source map and Pending token, semantic ticket arms only after host evidence, synchronous cancellation revocation precedes MainActor cleanup, child groups cancel and join. Completed proof cannot rearm. Original root-only target-nil branch retains separate host proof. Not all shared Session/JS/geometry paths."}
]})
write("RESULT.json", {"source_commit": "d4e25c0cf5581427d6742ade1d4d1e0f3ddaa1a3",
    "source_tree": "fecd5475208cc75f3ba8683045b513b7c4a747fd",
    "vendor_tree": "2fb868bdbe5d2d52735e857a24933918ff658cef",
    "scope": "SOURCE_ONLY_ORIGINAL_BODY_AND_EXPLICIT_BOUNDARY_CONTROLS",
    "source_results": {"final_claim_and_publication": [50, 0], "workspace_original_baseline": [2, 2],
        "workspace_candidate": [4, 0], "native_geometry_algorithm_with_platform_boundary": [32, 0],
        "complete_binding_and_rpc_with_platform_boundaries": [13, 0], "actual_js_method_bodies": [36, 0],
        "unchanged_original_js_root_controls": [24, 0]},
    "counterfactual_results": {"omit_source_claim_latch": [34, 16], "omit_runtime_guard": [47, 3],
        "observable_root_counter": [49, 1], "observable_window_counter": [49, 1], "observable_mode_counter": [49, 1],
        "omit_closed_publication": [40, 10], "omit_geometry_uniqueness": [31, 1],
        "omit_synchronous_cancel_revoke": [12, 1], "omit_js_native_claim": [24, 12]},
    "sdk_typecheck": "NOT_RUN", "native_ui": "NOT_RUN", "metro": "NOT_RUN", "root_admission": "NOT_FROZEN",
    "required_followups": ["root exact shared hunk intake and original PBX membership for new Swift file",
        "Annotations original local-State closed publication facet",
        "strict chained Vendor contract on actual root intake ancestry", "fresh original Metro and app SDK build",
        "additive original-system native selectors for the four finite target routes",
        "real EN/HE iPad/iPhone visible-state and cancellation acceptance"]})
print(json.dumps({"directory": str(OUT), "shared_files": len(rows),
    "files": len([p for p in OUT.rglob('*') if p.is_file()])}))
