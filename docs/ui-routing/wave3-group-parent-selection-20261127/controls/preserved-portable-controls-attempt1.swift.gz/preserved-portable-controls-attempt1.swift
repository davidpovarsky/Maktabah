import Foundation
@testable import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

// Actual original Core/UIRouting/Host modules; ONLY runtime authorities,
// native window/layout and feature effects below are explicit test boundaries.
// These controls are not an app build or UIKit/native acceptance.
final class ControlClock: ActionClock, @unchecked Sendable {
    private let lock = NSLock()
    private var value: UInt64 = 100
    func now() -> UInt64 { lock.withLock { value } }
    func expire() { lock.withLock { value = 5_000_000_100 } }
    func sleep(until deadline: UInt64) async throws { try await Task.sleep(nanoseconds: 60_000_000_000) }
}

@main struct GroupParentPortableControls {
    @MainActor static var rows: [[String: Any]] = []
    @MainActor static func record(_ name: String, _ pass: Bool, _ facts: [String: Any] = [:]) {
        rows.append(["name": name, "pass": pass, "facts": facts])
    }
    static func acknowledged(_ value: UISceneAcknowledgement) -> Bool { if case .acknowledged = value { return true }; return false }
    static func uncertain(_ value: UISceneAcknowledgement) -> Bool {
        switch value { case .failed(let f), .staleState(let f), .unavailable(let f): return f.code == "native_effect_uncertain"; default: return false }
    }
    @MainActor static func execute() async throws {
        let profile = UIStableID(rawValue: "profile.A")!, group = UIStableID(rawValue: "group.A")!
        let empty = UIOriginalParentSelectionKind.workspaceSelection(profileID: profile, workspaceID: group, activeTabID: nil)
        for mode in ["group", "empty_group", "old_reader_tab", "old_single"] {
            let f: Fixture
            switch mode {
            case "empty_group": f = try await .make(kind: empty, tab: nil)
            case "old_reader_tab": f = try await .make(kind: .readerTab, destination: "native.reader.tab")
            case "old_single": f = try await .make(kind: nil, destination: "native.settings", tab: nil)
            default: f = try await .make()
            }
            let result = try await f.run()
            let effects = mode == "old_single" ? f.driver.singles == 1 && f.driver.parents == 0 && f.driver.selections == 0
                : f.driver.singles == 0 && f.driver.parents == 1 && f.driver.selections == 1
            record(mode + "_same_original_preparation", acknowledged(result) && effects && f.driver.ends == 1,
                   ["result": String(describing: result), "parents": f.driver.parents, "terminal": f.driver.selections])
            if mode != "old_single" {
                let replay = try await f.run()
                record(mode + "_replay_cannot_select", !acknowledged(replay) && f.driver.parents == 1 && f.driver.selections == 1)
            }
        }
        for mismatch in ["old_reader_nil", "group_wrong_profile", "group_wrong_workspace", "group_wrong_tab", "empty_with_tab", "group_borrows_reader", "reader_borrows_group", "group_borrows_root"] {
            let f: Fixture
            switch mismatch {
            case "old_reader_nil": f = try await .make(kind: .readerTab, destination: "native.reader.tab", tab: nil)
            case "group_wrong_profile": f = try await .make(profile: "profile.foreign")
            case "group_wrong_workspace": f = try await .make(group: "group.foreign")
            case "group_wrong_tab": f = try await .make(tab: nil)
            case "empty_with_tab": f = try await .make(kind: empty)
            case "group_borrows_reader": f = try await .make(destination: "native.reader.tab")
            case "reader_borrows_group": f = try await .make(kind: .readerTab)
            default: f = try await .make(kind: empty, destination: "native.library", tab: nil)
            }
            let result = try await f.run()
            record(mismatch + "_refused_before_parent", !acknowledged(result) && f.driver.parents == 0 && f.driver.selections == 0 && f.driver.singles == 0,
                   ["result": String(describing: result)])
        }
        for change in ["host", "witness", "backend", "authority_ABA", "driver", "deadline"] {
            let f = try await Fixture.make()
            f.driver.afterParentWait = {
                switch change {
                case "host": f.driver.parentValid = false
                case "witness": f.driver.onParentCheck = { _ in f.driver.witness = UUID() }
                case "backend": f.source.value = .init(backend: .otzaria, generation: 2)
                case "authority_ABA": try f.authority.invalidate(f.lease)
                case "driver": f.orchestrator.unregister(f.driver)
                default: f.clock.expire()
                }
            }
            let result = try await f.run()
            record(change + "_after_parent_is_uncertain_without_terminal", uncertain(result) && f.driver.parents == 1 && f.driver.selections == 0 && f.driver.ends == 1,
                   ["result": String(describing: result)])
        }
        do {
            let f = try await Fixture.make(); var fired = false
            f.driver.onParentCheck = { count in
                if count == 2 { f.source.onBackend = { if !fired { fired = true; f.driver.parentValid = false; f.source.onBackend = nil } } }
            }
            let result = try await f.run()
            record("same_parent_rechecked_after_core_callback", fired && uncertain(result) && f.driver.parents == 1 && f.driver.selections == 0)
        }
        do {
            let f = try await Fixture.make(); f.driver.wrongFinal = true
            let result = try await f.run()
            record("parent_or_foreign_root_cannot_ack_group", uncertain(result) && f.driver.parents == 1 && f.driver.selections == 1)
        }
        do {
            let f = try await Fixture.make(); f.driver.afterSelection = { try f.authority.invalidate(f.lease) }
            let result = try await f.run()
            record("post_terminal_revocation_retains_effect_uncertainty", uncertain(result) && f.driver.selections == 1)
        }
        do {
            let f = try await Fixture.make()
            let (events, signal) = AsyncStream<Void>.makeStream(bufferingPolicy: .bufferingNewest(1))
            f.driver.waitForParent = { signal.yield(()); try await Task.sleep(nanoseconds: 60_000_000_000) }
            let task = Task { defer { signal.finish() }; return try await f.run() }
            var iterator = events.makeAsyncIterator(); _ = await iterator.next(); task.cancel()
            let result = try await task.value; signal.finish()
            record("same_structured_wait_cancellation_drains", uncertain(result) && f.driver.parents == 1 && f.driver.selections == 0 && f.driver.ends == 1)
        }
    }
    @MainActor static func main() async {
        do { try await execute() } catch { record("unexpected_harness_error", false, ["error": String(describing: error)]) }
        let failed = rows.filter { !($0["pass"] as! Bool) }.count
        print(String(data: try! JSONSerialization.data(withJSONObject: ["rows": rows, "pass": rows.count - failed, "fail": failed,
            "scope": "Actual original Core/UIRouting/Host. Explicit source/native/geometry substitutes; no app, UIKit, or native acceptance."], options: [.sortedKeys]), encoding: .utf8)!)
        if failed != 0 { exit(1) }
    }
}

@MainActor final class Source: ActionNavigationAuthority, ActionSynchronousBackendStatePort {
    var context = ActionExecutionContext(subjectID: "source-control", origin: .inApp,
        allowedBackends: [.otzaria], scopes: [.navigation, .discovery], foregroundSceneID: "scene.A")
    var value = ActionBackendSnapshot(backend: .otzaria, generation: 1)
    var lifetime = UUID(), revision: UInt64 = 1, active = true
    var onBackend: (@MainActor () -> Void)?
    var onNative: (@MainActor () -> Void)?
    func currentBackendSnapshot() throws -> ActionBackendSnapshot { onBackend?(); return value }
    func snapshot() async throws -> ActionBackendSnapshot { value }
    func report(for backend: ActionBackendID) async throws -> ActionBackendReport { .init(id: backend, operations: [:]) }
    func assess(action: String, arguments: ActionObject, invocation: ActionPortInvocation) async throws -> ActionCapabilityAssessment {
        .init(registered: true, supported: true, availableNow: true)
    }
    func navigationState(sceneID: String) throws -> ActionNavigationState {
        onNative?()
        return .init(context: context, sceneID: "scene.A", lifetimeID: lifetime, authorityRevision: revision, active: active)
    }
    func preparation(clock: ControlClock) throws -> (ActionNavigationPreparation, ActionPortInvocation) {
        let invocation = ActionPortInvocation(requestId: UUID(), snapshot: value, deadlineUptimeNanoseconds: 5_000_000_100)
        return (try .init(authority: self, backendAuthority: self, invocation: invocation, sceneID: "scene.A",
                          context: context, destination: nil, clock: clock), invocation)
    }
}
struct Ports: ActionResolverPort, ActionSearchPort {
    func resolveWork(_ query: ActionResolveWorkQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionWorkRef> { .notFound }
    func resolveReference(_ query: ActionResolveReferenceQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionTextRef> { .notFound }
    func validateDestination(_ destination: ActionReaderDestination, invocation: ActionPortInvocation) async throws -> ActionReaderDestination { throw ActionPortError.notSupported }
    func search(_ query: ActionSearchQuery, invocation: ActionPortInvocation) async throws -> ActionSearchPage { throw ActionPortError.notSupported }
}

@MainActor final class Driver: NativeParentSelectionSceneDriver {
    let sceneID = UIStableID(rawValue: "scene.A")!
    let backend: Source
    var command: UISceneCommand?
    var parents = 0, selections = 0, singles = 0, ends = 0, parentChecks = 0
    var witness = UUID(), activation = UUID(), parentValid = true, wrongFinal = false
    var kind: UIOriginalParentSelectionKind?
    var afterParent: (@MainActor () throws -> Void)?
    var afterParentWait: (@MainActor () throws -> Void)?
    var onParentCheck: (@MainActor (Int) -> Void)?
    var afterSelection: (@MainActor () throws -> Void)?
    var waitForParent: (@MainActor () async throws -> Void)?
    init(backend: Source) { self.backend = backend }
    var surface: NativeSurfaceState {
        if let command, selections + singles > 0 {
            let route = command.route.route
            return .init(destination: wrongFinal ? .init(rawValue: "native.history")! : route.destination,
                presentation: route.presentation, content: nil, state: route.state, focus: nil)
        }
        return .init(destination: .init(rawValue: parents > 0 ? "native.library" : "native.history")!,
            presentation: .init(kind: .currentTab), content: nil, state: .init(), focus: nil)
    }
    var observation: NativeSceneDirectory.Observation {
        .init(isForeground: true, isMounted: true,
              visibleRoute: parents + selections + singles > 0 ? command.map { surface.observedRoute(for: $0, backend: backend.value) } : nil,
              surface: surface)
    }
    func validateSurface(_ command: UISceneCommand) throws {}
    func beginObservation(_ command: UISceneCommand) throws { self.command = command }
    func apply(_ command: UISceneCommand) throws { singles += 1 }
    func waitUntilVisible(_ command: UISceneCommand) async throws -> NativeSurfaceState { surface }
    func endObservation(requestID: UUID) { ends += 1; command = nil }
    func originalParentSelectionKind(for command: UISceneCommand) throws -> UIOriginalParentSelectionKind? { kind }
    func applyOriginalParent(_ command: UISceneCommand) throws { parents += 1; try afterParent?() }
    func waitUntilOriginalParentReady(_ command: UISceneCommand) async throws -> NativeOriginalParentObservation {
        try await waitForParent?()
        try afterParentWait?()
        return .init(requestID: command.invocation.requestId, sceneID: sceneID,
                     activationID: activation, witnessID: witness, presentationRevision: 1)
    }
    func validateOriginalParent(_ observation: NativeOriginalParentObservation, for command: UISceneCommand) throws {
        parentChecks += 1; onParentCheck?(parentChecks)
        guard parentValid, observation.requestID == command.invocation.requestId,
              observation.sceneID == sceneID, observation.witnessID == witness,
              observation.activationID == activation else { throw UIRouteError(.staleState, "test_original_parent_changed") }
    }
    func applyOriginalSelection(_ command: UISceneCommand) throws { selections += 1; try afterSelection?() }
}

@MainActor struct Fixture {
    let source: Source, driver: Driver, clock: ControlClock
    let authority: NativeNavigationAuthority, lease: NativeNavigationAuthority.Lease
    let directory: NativeSceneDirectory, orchestrator: NativeSceneNavigationOrchestrator
    let command: UISceneCommand
    static func make(kind: UIOriginalParentSelectionKind? = .workspaceSelection(profileID: .init(rawValue: "profile.A")!, workspaceID: .init(rawValue: "group.A")!, activeTabID: .init(rawValue: "tab.A")!),
                     destination: String = "native.workspace.selection", tab: String? = "tab.A",
                     profile: String = "profile.A", group: String = "group.A") async throws -> Fixture {
        let source = Source(), clock = ControlClock(), driver = Driver(backend: source)
        driver.kind = kind
        let authority = try NativeNavigationAuthority(), lease = try authority.mount(sceneID: driver.sceneID, foreground: true)
        let directory = try NativeSceneDirectory(authority: source, clock: clock)
        _ = try directory.mount(sceneID: driver.sceneID, observe: { driver.observation }, validateLifetime: { _ in })
        let core = try ActionExecutor(state: source, resolver: Ports(), search: Ports(), clock: clock, navigationAuthority: authority)
        let orchestrator = try NativeSceneNavigationOrchestrator(core: core, backend: source, authority: authority, directory: directory, clock: clock)
        try orchestrator.register(driver)
        let invocation = ActionPortInvocation(requestId: UUID(), snapshot: source.value, deadlineUptimeNanoseconds: 5_000_000_100)
        let scene = try await directory.currentScene(sceneID: driver.sceneID, context: source.context, invocation: invocation)
        let descriptor = UIDestinationDescriptor(id: .init(rawValue: destination)!,
            title: "EXPLICIT SYNTHETIC native boundary", implementation: .implemented, supportedBackends: [.otzaria],
            presentations: [.currentTab], requiredCoreActions: [])
        let registry = try UIDestinationRegistry(descriptors: [descriptor])
        let route = RouteSpec(requestId: invocation.requestId, destination: descriptor.id, backend: .otzaria,
            presentation: .init(kind: .currentTab, tabID: tab.flatMap(UIStableID.init(rawValue:))),
            state: .init(workspaceID: .init(rawValue: group)!, profileID: .init(rawValue: profile)!),
            scene: .init(kind: .specific, sceneID: driver.sceneID, expectedRevision: scene.revision))
        let command = try UISceneCommand(route: registry.validate(route), invocation: invocation, scene: scene)
        return .init(source: source, driver: driver, clock: clock, authority: authority, lease: lease,
                     directory: directory, orchestrator: orchestrator, command: command)
    }
    func run() async throws -> UISceneAcknowledgement { try await orchestrator.commit(command, context: source.context) }
}

