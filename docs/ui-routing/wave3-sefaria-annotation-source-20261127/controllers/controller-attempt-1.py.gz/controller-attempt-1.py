from pathlib import Path
import os,json,hashlib,gzip,base64,subprocess,time
diag=Path('/mnt/development/projects/diagnostics/otzaria-wave3-rn-semantic-source-controls-20261127')
out=diag/'annotation-root-attempt-1';out.mkdir(exist_ok=False)
raw=Path('/var/lib/sentinelx/uploads/rn-annotation-root-controls-924e1557.json.gz').read_bytes()
assert len(raw)==246868 and hashlib.sha256(raw).hexdigest()=='924e15576350403ce16c6118fc6d5305804ace50c871d273282808ac09ac0805'
for name,b64 in json.loads(gzip.decompress(raw)).items():
 p=Path(name);assert not p.is_absolute() and '..' not in p.parts
 p=out/'transferred'/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(b64,validate=True))
subprocess.run(['chown','-R','ubuntu:ubuntu',str(out)],check=True)
assert os.statvfs(diag).f_bavail*os.statvfs(diag).f_frsize>687865856+100*1024**2
cache=diag/'module-cache';assert cache.is_dir()
swift='/home/ubuntu/.local/share/swiftly/toolchains/6.4.3/usr/bin/swiftc';assert Path(swift).is_file()
results=[]
for name in ('original-baseline','candidate','omit-annotation-publication-registration'):
 folder=out/name;folder.mkdir();src=out/'transferred/prepared-controls'/(name+'.swift')
 argv=[swift,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',str(cache),str(src),'-o',str(folder/'controls')]
 start=time.time();c=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 (folder/'compile.stdout').write_bytes(c.stdout);(folder/'compile.stderr').write_bytes(c.stderr)
 row={'name':name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'compile_argv':argv,'compile_exit':c.returncode,'seconds':time.time()-start}
 if c.returncode==0:
  r=subprocess.run([str(folder/'controls')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
  (folder/'run.stdout.json').write_bytes(r.stdout);(folder/'run.stderr').write_bytes(r.stderr)
  v=json.loads(r.stdout);row.update(run_exit=r.returncode,passed=v['passed'],failed=v['failed'],executable_sha256=hashlib.sha256((folder/'controls').read_bytes()).hexdigest())
 results.append(row);(out/'RESULT.json').write_text(json.dumps({'scope':'ACTUAL_COMPLETE_RN_ROOT_SOURCE_AND_ANNOTATION_FACET_WITH_DECLARED_BOUNDARIES','results':results,'sdk':'NOT_RUN','native':'NOT_RUN'},indent=2)+'\n')
 if c.returncode:break
print(json.dumps({'path':str(out),'results':results,'result_sha256':hashlib.sha256((out/'RESULT.json').read_bytes()).hexdigest()}))
