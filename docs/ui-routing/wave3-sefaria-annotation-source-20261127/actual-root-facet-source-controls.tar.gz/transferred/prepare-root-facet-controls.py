from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
RN = ROOT.parent
SHARED = RN / "shared-proposal"
NAME = "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift"
NAV = RN.parent / "annotations-selection-analysis/proposal"
inputs = {
    "oldSession": ROOT / "baseline" / NAME,
    "newSession": ROOT / "proposal" / NAME,
    "annotationSession": NAV / "shared/candidate" / NAME,
    "annotationMethods": NAV / "ANNOTATION_MODAL_SESSION_METHODS.swift",
    "rootPublication": SHARED / "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSearchEntry.swift",
    "observation": SHARED / "Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/NativeComponentSourceObservation.swift",
    "boundary": ROOT / "RootFacetBoundary.swift", "controls": ROOT / "RootFacetControls.swift",
    "generator": Path(__file__).resolve(),
}
texts = {key: path.read_text() for key, path in inputs.items()}
assert hashlib.sha256(texts["annotationSession"].encode()).hexdigest() == "6a260e9ec1347a33feee74c30a48fb700f051716d1e992d02adfe78a5b85d686"
for key in ("oldSession", "newSession"):
    value = texts[key]
    texts[key] = value[value.index('@MainActor private final class MaktabahNativeSefariaRootSource {'):value.index('/// One instance per actual UIKit session.')]
root_publication = texts["rootPublication"]
root_publication = root_publication[root_publication.index('@MainActor\nfinal class MaktabahNativeRootPublicationSource'):root_publication.index('/// Expected publications')]
actual_methods = texts["annotationMethods"]
assert actual_methods in texts["annotationSession"]
fields = [line for line in texts["annotationSession"].splitlines(True)
          if any(needle in line for needle in ('@ObservationIgnored let originalAnnotationPresentationPublication',
                '@ObservationIgnored private var annotationPresentationOwner:',
                '@ObservationIgnored private var annotationPresentationBlocked:',
                '@ObservationIgnored private var annotationPresentationPublicationRevision:'))]
assert len(fields) == 4
annotation = ('@MainActor @Observable final class AnnotationSessionFixture {\n'
    '    var mounted = true\n'
    '    @ObservationIgnored var annotationSelectionBinding: AnnotationBindingBoundary?\n'
    + ''.join(fields) + actual_methods + '}\n')
observation = texts["observation"]
assert observation.count('import OtzariaUIRouting\n') == 1
observation = observation.replace('import OtzariaUIRouting\n', '')
out = ROOT / "prepared-controls"
out.mkdir(exist_ok=False)
old_call = '        try MaktabahNativeSefariaRootSource(bindings: bindings, workspace: workspace, readForeignPresentations: {})'
new_call = '''        try MaktabahNativeSefariaRootSource(bindings: bindings, workspace: workspace,
            annotationPublication: session.originalAnnotationPresentationPublication,
            retainAnnotationObservation: { [session] in try session.retainOriginalAnnotationPresentationObservation() },
            readForeignPresentations: {})'''
report = {"scope": "ACTUAL_COMPLETE_ROOT_SOURCE_AND_ANNOTATION_FACET_NOT_APP_OR_NATIVE",
    "inputs": [{"name": key, "path": str(path), "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for key, path in inputs.items()],
    "extraction": {"oldRootSourceSHA256": hashlib.sha256(texts["oldSession"].encode()).hexdigest(),
        "newRootSourceSHA256": hashlib.sha256(texts["newSession"].encode()).hexdigest(),
        "actualAnnotationMethodsSHA256": hashlib.sha256(actual_methods.encode()).hexdigest(),
        "actualRootPublicationSHA256": hashlib.sha256(root_publication.encode()).hexdigest()},
    "boundaries": ["SwiftUI Binding/Transaction and application domain values", "UIKit window readiness",
        "Original List setter before-write publication shape; its actual setter is separately tested by Nav",
        "No Core authority, original UI renderer, React bridge or native run"], "variants": []}
for name, root_source, call in (("original-baseline", texts["oldSession"], old_call),
                               ("candidate", texts["newSession"], new_call),
                               ("omit-annotation-publication-registration", texts["newSession"], new_call)):
    if name == "omit-annotation-publication-registration":
        before = 'manager.nativeModePresentationPublication, windowPublication, annotationPublication]'
        assert root_source.count(before) == 1
        root_source = root_source.replace(before, 'manager.nativeModePresentationPublication, windowPublication]')
    controls = texts["controls"].replace('__ACTUAL_ROOT_CONSTRUCTOR_CALL__', call)
    raw = '\n'.join(['import Foundation\nimport Observation\nimport Synchronization\n',
        texts["boundary"], observation, root_publication, annotation, root_source, controls]).encode()
    path = out / (name + '.swift'); path.write_bytes(raw)
    report["variants"].append({"name": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
captured = out / 'source-inputs'; captured.mkdir()
for key, path in inputs.items():
    (captured / (key + path.suffix)).write_bytes(path.read_bytes())
(out / 'INPUTS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
