@MainActor private final class RootFacetFixture {
    let manager = iOSNavigationManager()
    let state = OriginalStateBoundary()
    let publication = MaktabahNativeRootPublicationSource()
    let workspace = MaktabahNativeWorkspacePresentationBinding()
    let session = AnnotationSessionFixture()
    let owner = UUID()
    var bindings: MaktabahNativeSceneBindings {
        .init(manager: manager, rootPublications: publication,
            selectedTab: publication.selectionBinding(Binding(get: { self.state.tab }, set: { self.state.tab = $0; _ = $1 })),
            showSettings: publication.settingsBinding(Binding(get: { self.state.settings }, set: { self.state.settings = $0; _ = $1 })))
    }
    init() { attach(owner) }
    func attach(_ token: UUID) {
        session.observeAnnotationPresentation(owner: token) { [state] in
            state.duringGetter?()
            return state.annotationBlocked
        }
    }
    func capture() throws -> MaktabahNativeSefariaRootSource {
__ACTUAL_ROOT_CONSTRUCTOR_CALL__
    }
    func originalStateWrite(_ value: Bool, token: UUID? = nil) {
        // The actual original List setter is independently covered in the Nav
        // packet. This boundary preserves its specified before-write ordering.
        session.originalAnnotationPresentationWillChange(owner: token ?? owner)
        state.annotationBlocked = value
    }
}

@main private struct RootFacetControls {
    @MainActor static func main() async {
        var rows: [[String: Any]] = []
        func record(_ name: String, _ result: Bool) { rows.append(["name": name, "passed": result]) }
        func refused(_ action: () throws -> Void) -> Bool { do { try action(); return false } catch { return true } }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("stable original annotation owner permits fixed source claim", claim)
        } catch { record("stable original annotation owner permits fixed source claim", false) }
        do {
            let f = RootFacetFixture(); f.originalStateWrite(true)
            record("existing original annotation modal refuses capture", refused { _ = try f.capture() })
        }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.originalStateWrite(true); f.originalStateWrite(false)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("original edit open-close ABA cannot authorize off-main claim", !claim)
        } catch { record("original edit open-close ABA cannot authorize off-main claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.originalStateWrite(false)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("equal original modal publication cancels retained claim", !claim)
        } catch { record("equal original modal publication cancels retained claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.attach(UUID()); f.attach(f.owner)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("original annotation owner ABA cancels retained claim", !claim)
        } catch { record("original annotation owner ABA cancels retained claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.session.originalAnnotationPresentationWillChange(owner: UUID())
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("foreign original owner cannot revoke this source", claim)
        } catch { record("foreign original owner cannot revoke this source", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.session.removeAnnotationPresentation(owner: f.owner)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("original owner removal cancels retained claim", !claim)
        } catch { record("original owner removal cancels retained claim", false) }
        do {
            let f = RootFacetFixture()
            f.state.duringGetter = { [weak f] in
                guard let f else { return }; f.state.duringGetter = nil
                f.originalStateWrite(true); f.originalStateWrite(false)
            }
            record("getter reentry during capture cannot escape registered publication", refused { _ = try f.capture() })
        }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.state.duringGetter = { [weak f] in
                guard let f else { return }; f.state.duringGetter = nil
                f.originalStateWrite(true); f.originalStateWrite(false)
            }
            let rejected = refused { try source.validate(f.bindings, workspace: f.workspace) }
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("getter reentry during later validation retires same off-main claim", rejected && !claim)
        } catch { record("getter reentry during later validation retires same off-main claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture()
            f.originalStateWrite(true); f.originalStateWrite(false)
            record("same retained original validator rejects completed modal ABA", refused { try source.validate(f.bindings, workspace: f.workspace) })
        } catch { record("same retained original validator rejects completed modal ABA", false) }
        let failed = rows.filter { $0["passed"] as? Bool == false }.count
        let output: [String: Any] = ["passed": rows.count - failed, "failed": failed, "controls": rows,
            "scope": "ACTUAL_RN_ROOT_SOURCE_AND_ANNOTATION_FACET_WITH_DECLARED_PLATFORM_DOMAIN_BOUNDARIES"]
        print(String(data: try! JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys]), encoding: .utf8)!)
        exit(failed == 0 ? 0 : 1)
    }
}
