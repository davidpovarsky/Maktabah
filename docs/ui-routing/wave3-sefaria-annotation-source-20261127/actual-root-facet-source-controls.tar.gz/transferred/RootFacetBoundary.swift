// Explicit domain/SwiftUI/UIKit boundary. The complete real RN RootSource,
// actual root publication wrapper, real passive latch/publication and exact
// Annotation Session facet are compiled separately and unchanged below.
// No Core grant, UIKit window, native route, rendering or JS invocation is tested.
enum AppMode { case viewer, annotations }
enum iOSTab { case viewer, annotations
    var canonical: Self { self }
    var appMode: AppMode { self == .viewer ? .viewer : .annotations }
}
struct Transaction {}
@MainActor struct Binding<Value> {
    let get: @MainActor () -> Value
    let set: @MainActor (Value, Transaction) -> Void
    init(get: @escaping @MainActor () -> Value, set: @escaping @MainActor (Value, Transaction) -> Void) {
        self.get = get; self.set = set
    }
    var wrappedValue: Value { get { get() } nonmutating set { set(newValue, Transaction()) } }
    func transaction(_ value: Transaction) -> Self { self }
}
struct UIRouteError: Error { enum Code { case staleState, unavailable }; let code: Code; let detail: String
    init(_ code: Code, _ detail: String) { self.code = code; self.detail = detail }
}
@MainActor final class BooksData {}
@MainActor @Observable final class ReaderBoundary { var isPopoverPresented = false }
@MainActor @Observable final class iOSNavigationManager {
    @ObservationIgnored let nativeModePresentationPublication = NativeComponentSourcePublication()
    @ObservationIgnored var nativeModePresentationRevision: UInt64? = 0
    @ObservationIgnored var selectedBookPresentationRevision: UInt64? = 0
    var currentMode = AppMode.annotations
    var selectedBook: BooksData?
    var selectedBookPresentationMode: AppMode?
    var selectedBookForInfo: BooksData?
    var showingTabsList = false
    var activeReaderViewModel: ReaderBoundary?
}
@MainActor @Observable final class DonationManager {
    static let shared = DonationManager(); var showDonationSheet = false
}
@MainActor @Observable final class OverviewBoundary { var blocksRouting = false }
@MainActor final class SidebarBoundary { let overview = OverviewBoundary() }
@MainActor @Observable final class MaktabahNativeWorkspacePresentationBinding { var originalStateRevision: UInt64? = 0 }
@MainActor final class MaktabahNativeWindowObservation { func validate() throws -> Bool { true } }
@MainActor struct MaktabahNativeSceneBindings {
    let manager: iOSNavigationManager
    let rootPublications: MaktabahNativeRootPublicationSource?
    let selectedTab: Binding<iOSTab>
    let showSettings: Binding<Bool>
    var sidebar: SidebarBoundary?
    var isPresentationReady = true
}
@MainActor final class AnnotationBindingBoundary {
    func retire() {}
    func originalModalWillChange(owner: UUID) {}
}
@MainActor final class OriginalStateBoundary {
    var tab = iOSTab.annotations
    var settings = false
    var annotationBlocked = false
    var duringGetter: (() -> Void)?
}
