import Foundation
import Observation
import Synchronization

// Explicit domain/SwiftUI/UIKit boundary. The complete real RN RootSource,
// actual root publication wrapper, real passive latch/publication and exact
// Annotation Session facet are compiled separately and unchanged below.
// No Core grant, UIKit window, native route, rendering or JS invocation is tested.
enum AppMode { case viewer, annotations }
enum iOSTab { case viewer, annotations
    var canonical: Self { self }
    var appMode: AppMode { self == .viewer ? .viewer : .annotations }
}
struct Transaction {}
@MainActor struct Binding<Value> {
    let get: @MainActor () -> Value
    let set: @MainActor (Value, Transaction) -> Void
    init(get: @escaping @MainActor () -> Value, set: @escaping @MainActor (Value, Transaction) -> Void) {
        self.get = get; self.set = set
    }
    var wrappedValue: Value { get { get() } nonmutating set { set(newValue, Transaction()) } }
    func transaction(_ value: Transaction) -> Self { self }
}
struct UIRouteError: Error { enum Code { case staleState, unavailable }; let code: Code; let detail: String
    init(_ code: Code, _ detail: String) { self.code = code; self.detail = detail }
}
@MainActor final class BooksData {}
@MainActor @Observable final class ReaderBoundary { var isPopoverPresented = false }
@MainActor @Observable final class iOSNavigationManager {
    @ObservationIgnored let nativeModePresentationPublication = NativeComponentSourcePublication()
    @ObservationIgnored var nativeModePresentationRevision: UInt64? = 0
    @ObservationIgnored var selectedBookPresentationRevision: UInt64? = 0
    var currentMode = AppMode.annotations
    var selectedBook: BooksData?
    var selectedBookPresentationMode: AppMode?
    var selectedBookForInfo: BooksData?
    var showingTabsList = false
    var activeReaderViewModel: ReaderBoundary?
}
@MainActor @Observable final class DonationManager {
    static let shared = DonationManager(); var showDonationSheet = false
}
@MainActor @Observable final class OverviewBoundary { var blocksRouting = false }
@MainActor final class SidebarBoundary { let overview = OverviewBoundary() }
@MainActor @Observable final class MaktabahNativeWorkspacePresentationBinding { var originalStateRevision: UInt64? = 0 }
@MainActor final class MaktabahNativeWindowObservation { func validate() throws -> Bool { true } }
@MainActor struct MaktabahNativeSceneBindings {
    let manager: iOSNavigationManager
    let rootPublications: MaktabahNativeRootPublicationSource?
    let selectedTab: Binding<iOSTab>
    let showSettings: Binding<Bool>
    var sidebar: SidebarBoundary?
    var isPresentationReady = true
}
@MainActor final class AnnotationBindingBoundary {
    func retire() {}
    func originalModalWillChange(owner: UUID) {}
}
@MainActor final class OriginalStateBoundary {
    var tab = iOSTab.annotations
    var settings = false
    var annotationBlocked = false
    var duringGetter: (() -> Void)?
}

import Observation
import Synchronization

/// Passive publication from an ORIGINAL MainActor setter. There is no value,
/// observer callback, authority, reset or rearm here. All retained records are
/// invalidated before that setter continues; the JS thread only sees the
/// existing thread-safe one-way latch and never calls back to this owner.
@MainActor
public final class NativeComponentSourcePublication {
    private struct Retained { weak var value: NativeComponentSourceObservation? }
    private var retained: [Retained] = []

    public init() {}

    fileprivate func register(_ observation: NativeComponentSourceObservation) {
        retained.removeAll { $0.value == nil }
        guard !retained.contains(where: { $0.value === observation }) else { return }
        retained.append(.init(value: observation))
    }

    public func invalidateRetainedSources() {
        let original = retained
        retained.removeAll(keepingCapacity: true)
        // invalidate() only takes its own Boolean lock. It cannot execute an
        // arbitrary observer or reenter the ORIGINAL setter/counter.
        for item in original { item.value?.invalidate() }
    }
}

/// A one-shot cancellation witness over ORIGINAL observable source reads.
/// Restoring the same values cannot restore a captured request. This is not a
/// source cache or an authority; the original identity/generation checks remain.
public final class NativeComponentSourceObservation: Sendable {
    private let invalidated = Mutex(false)

    @MainActor
    public init(publications: [NativeComponentSourcePublication] = [], read: @MainActor () -> Void) {
        // Registration precedes every original getter. A source publication
        // reentering a read therefore retires this exact observation too.
        for publication in publications { publication.register(self) }
        withObservationTracking {
            read()
        } onChange: { [weak self] in
            // Observation fires at willSet. Do not enqueue a Task: a complete
            // A -> B -> A edit can happen before a MainActor task resumes.
            self?.invalidate()
        }
    }

    /// Original non-Observation publishers may revoke this same latch. There is
    /// deliberately no reset, rearm or setter that can make a request live again.
    public func invalidate() {
        invalidated.withLock { $0 = true }
    }

    public func validate() throws {
        guard !invalidated.withLock({ $0 }) else {
            throw UIRouteError(.staleState, "native_component_source_changed")
        }
    }

    /// A source-locked final Boolean claim for the private RN handoff. The only
    /// application caller nests fixed one-way source latches and consumes its
    /// fixed ticket; it does not run UIKit, JS, actor work or a user callback.
    /// There is deliberately no reset or observation refresh in this operation.
    public func claimIfCurrent(_ claim: () -> Bool) -> Bool {
        invalidated.withLock { retired in
            guard !retired else { return false }
            return claim()
        }
    }
}

@MainActor
final class MaktabahNativeRootPublicationSource {
    let nativePublication = NativeComponentSourcePublication()
    private(set) var selectionRevision: UInt64? = 0
    private(set) var settingsRevision: UInt64? = 0

    func selectionBinding(_ original: Binding<iOSTab>) -> Binding<iOSTab> {
        Binding(get: { original.wrappedValue }, set: { [self] value, transaction in
            nativePublication.invalidateRetainedSources()
            selectionRevision = Self.advanced(selectionRevision)
            original.transaction(transaction).wrappedValue = value
        })
    }
    func settingsBinding(_ original: Binding<Bool>) -> Binding<Bool> {
        Binding(get: { original.wrappedValue }, set: { [self] value, transaction in
            nativePublication.invalidateRetainedSources()
            settingsRevision = Self.advanced(settingsRevision)
            original.transaction(transaction).wrappedValue = value
        })
    }
    private static func advanced(_ revision: UInt64?) -> UInt64? {
        guard let revision, revision < .max else { return nil }
        return revision + 1
    }
}


@MainActor @Observable final class AnnotationSessionFixture {
    var mounted = true
    @ObservationIgnored var annotationSelectionBinding: AnnotationBindingBoundary?
    @ObservationIgnored let originalAnnotationPresentationPublication = NativeComponentSourcePublication()
    @ObservationIgnored private var annotationPresentationOwner: UUID?
    @ObservationIgnored private var annotationPresentationBlocked: (@MainActor () -> Bool)?
    @ObservationIgnored private var annotationPresentationPublicationRevision: UInt64? = 0
    /// The original list's existing modal State owner, not a second UI model.
    /// Equal modal writes and owner A-B-A all invalidate retained sources.
    func observeAnnotationPresentation(owner: UUID, isBlocked: @escaping @MainActor () -> Bool) {
        guard mounted else { return }
        if annotationPresentationOwner != owner {
            advanceOriginalAnnotationPresentationPublication()
            annotationPresentationOwner = owner; annotationPresentationBlocked = isBlocked
            annotationSelectionBinding?.retire()
        } else { annotationPresentationBlocked = isBlocked }
    }
    func originalAnnotationPresentationWillChange(owner: UUID) {
        guard mounted, annotationPresentationOwner == owner else { return }
        advanceOriginalAnnotationPresentationPublication()
        annotationSelectionBinding?.originalModalWillChange(owner: owner)
    }
    func removeAnnotationPresentation(owner: UUID) {
        guard annotationPresentationOwner == owner else { return }
        advanceOriginalAnnotationPresentationPublication()
        let revision = annotationPresentationPublicationRevision
        annotationSelectionBinding?.retire()
        // The original list can be covered by its own editor/import/export
        // presentation. Preserve its blocker until that actual owner clears it.
        guard annotationPresentationBlocked?() != true,
              annotationPresentationOwner == owner,
              annotationPresentationPublicationRevision == revision else { return }
        annotationPresentationOwner = nil; annotationPresentationBlocked = nil
    }
    private func advanceOriginalAnnotationPresentationPublication() {
        // Fixed weak one-way latches only. No user/State callback runs under a
        // source lock; RN claims can be refused before the original setter.
        originalAnnotationPresentationPublication.invalidateRetainedSources()
        guard let revision = annotationPresentationPublicationRevision, revision < .max else {
            annotationPresentationPublicationRevision = nil
            return
        }
        annotationPresentationPublicationRevision = revision + 1
    }
    private var hasOriginalAnnotationPresentation: Bool {
        guard let revision = annotationPresentationPublicationRevision else { return true }
        let owner = annotationPresentationOwner
        let blocked = annotationPresentationBlocked?() == true
        return blocked || annotationPresentationPublicationRevision != revision || annotationPresentationOwner != owner
    }
    /// Retain before foreground activation. The caller must register the fixed
    /// originalAnnotationPresentationPublication BEFORE this first getter if it
    /// needs a synchronous off-MainActor claim (RN); this closure is no grant.
    func retainOriginalAnnotationPresentationObservation() throws -> @MainActor () throws -> Void {
        guard mounted, let revision = annotationPresentationPublicationRevision else {
            throw UIRouteError(.unavailable, "original_annotation_presentation_unavailable")
        }
        let owner = annotationPresentationOwner
        let validate: @MainActor () throws -> Void = { [weak self] in
            guard let self, self.mounted,
                  self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  self.annotationPresentationBlocked?() != true else {
                throw UIRouteError(.staleState, "original_annotation_presentation_changed")
            }
            // The original blocker is a getter callback. It may publish a new
            // owner/state; final equality alone cannot restore that source.
            guard self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner else {
                throw UIRouteError(.staleState, "original_annotation_presentation_changed")
            }
        }
        try validate()
        return validate
    }

}

@MainActor private final class MaktabahNativeSefariaRootSource {
    private let observation: NativeComponentSourceObservation
    private let originalWindow: MaktabahNativeWindowObservation?
    private let managerID: ObjectIdentifier
    private let root: MaktabahNativeRootPublicationSource
    private weak var workspacePresentation: MaktabahNativeWorkspacePresentationBinding?
    private let workspaceRevision: UInt64
    private let selectionRevision: UInt64
    private let settingsRevision: UInt64
    private let modeRevision: UInt64
    private let bookRevision: UInt64
    private let tab: iOSTab
    private let mode: AppMode
    private let bookID: ObjectIdentifier?
    private let bookMode: AppMode?

    static func isAvailable(_ bindings: MaktabahNativeSceneBindings,
                            workspace: MaktabahNativeWorkspacePresentationBinding?) -> Bool {
        bindings.rootPublications?.selectionRevision != nil
            && bindings.rootPublications?.settingsRevision != nil
            && bindings.manager.nativeModePresentationRevision != nil
            && bindings.manager.selectedBookPresentationRevision != nil
            && workspace?.originalStateRevision != nil
            && bindings.selectedTab.wrappedValue == bindings.selectedTab.wrappedValue.canonical
            && bindings.manager.currentMode == bindings.selectedTab.wrappedValue.appMode
            && !bindings.showSettings.wrappedValue && bindings.isPresentationReady
    }

    init(bindings: MaktabahNativeSceneBindings,
         workspace: MaktabahNativeWorkspacePresentationBinding,
         originalWindow: MaktabahNativeWindowObservation? = nil,
         windowPublication: NativeComponentSourcePublication? = nil,
         readForeignPresentations: @MainActor () -> Void) throws {
        let manager = bindings.manager
        self.originalWindow = originalWindow
        let publications = [bindings.rootPublications?.nativePublication,
            manager.nativeModePresentationPublication, windowPublication].compactMap { $0 }
        observation = NativeComponentSourceObservation(publications: publications) {
            _ = bindings.rootPublications?.selectionRevision; _ = bindings.rootPublications?.settingsRevision
            _ = manager.nativeModePresentationRevision; _ = manager.selectedBookPresentationRevision
            _ = manager.currentMode; _ = manager.selectedBook; _ = manager.selectedBookPresentationMode
            _ = manager.selectedBookForInfo; _ = manager.showingTabsList
            _ = manager.activeReaderViewModel?.isPopoverPresented
            _ = DonationManager.shared.showDonationSheet
            _ = bindings.sidebar?.overview.blocksRouting
            _ = workspace.originalStateRevision
            readForeignPresentations()
        }
        guard Self.isAvailable(bindings, workspace: workspace),
              let root = bindings.rootPublications,
              let selection = root.selectionRevision, let settings = root.settingsRevision,
              let mode = manager.nativeModePresentationRevision,
              let book = manager.selectedBookPresentationRevision,
              let workspaceRevision = workspace.originalStateRevision else {
            throw UIRouteError(.unavailable, "native_sefaria_original_root_unavailable")
        }
        self.root = root; managerID = ObjectIdentifier(manager)
        workspacePresentation = workspace; self.workspaceRevision = workspaceRevision
        selectionRevision = selection; settingsRevision = settings
        modeRevision = mode; bookRevision = book
        tab = bindings.selectedTab.wrappedValue; self.mode = manager.currentMode
        bookID = manager.selectedBook.map(ObjectIdentifier.init)
        bookMode = manager.selectedBookPresentationMode
        try validate(bindings, workspace: workspace)
    }

    func validate(_ bindings: MaktabahNativeSceneBindings,
                  workspace: MaktabahNativeWorkspacePresentationBinding?) throws {
        try observation.validate()
        _ = try originalWindow?.validate()
        let manager = bindings.manager
        guard ObjectIdentifier(manager) == managerID, bindings.rootPublications === root,
              let workspace, workspacePresentation === workspace,
              workspace.originalStateRevision == workspaceRevision,
              root.selectionRevision == selectionRevision, root.settingsRevision == settingsRevision,
              manager.nativeModePresentationRevision == modeRevision,
              manager.selectedBookPresentationRevision == bookRevision,
              bindings.selectedTab.wrappedValue == tab, manager.currentMode == mode,
              manager.selectedBook.map(ObjectIdentifier.init) == bookID,
              manager.selectedBookPresentationMode == bookMode,
              !bindings.showSettings.wrappedValue, bindings.isPresentationReady else {
            throw UIRouteError(.staleState, "native_sefaria_original_root_changed")
        }
        try observation.validate()
        _ = try originalWindow?.validate()
    }
    var claimObservation: NativeComponentSourceObservation { observation }
    func invalidate() { observation.invalidate() }
}


@MainActor private final class RootFacetFixture {
    let manager = iOSNavigationManager()
    let state = OriginalStateBoundary()
    let publication = MaktabahNativeRootPublicationSource()
    let workspace = MaktabahNativeWorkspacePresentationBinding()
    let session = AnnotationSessionFixture()
    let owner = UUID()
    var bindings: MaktabahNativeSceneBindings {
        .init(manager: manager, rootPublications: publication,
            selectedTab: publication.selectionBinding(Binding(get: { self.state.tab }, set: { self.state.tab = $0; _ = $1 })),
            showSettings: publication.settingsBinding(Binding(get: { self.state.settings }, set: { self.state.settings = $0; _ = $1 })))
    }
    init() { attach(owner) }
    func attach(_ token: UUID) {
        session.observeAnnotationPresentation(owner: token) { [state] in
            state.duringGetter?()
            return state.annotationBlocked
        }
    }
    func capture() throws -> MaktabahNativeSefariaRootSource {
        try MaktabahNativeSefariaRootSource(bindings: bindings, workspace: workspace, readForeignPresentations: {})
    }
    func originalStateWrite(_ value: Bool, token: UUID? = nil) {
        // The actual original List setter is independently covered in the Nav
        // packet. This boundary preserves its specified before-write ordering.
        session.originalAnnotationPresentationWillChange(owner: token ?? owner)
        state.annotationBlocked = value
    }
}

@main private struct RootFacetControls {
    @MainActor static func main() async {
        var rows: [[String: Any]] = []
        func record(_ name: String, _ result: Bool) { rows.append(["name": name, "passed": result]) }
        func refused(_ action: () throws -> Void) -> Bool { do { try action(); return false } catch { return true } }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("stable original annotation owner permits fixed source claim", claim)
        } catch { record("stable original annotation owner permits fixed source claim", false) }
        do {
            let f = RootFacetFixture(); f.originalStateWrite(true)
            record("existing original annotation modal refuses capture", refused { _ = try f.capture() })
        }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.originalStateWrite(true); f.originalStateWrite(false)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("original edit open-close ABA cannot authorize off-main claim", !claim)
        } catch { record("original edit open-close ABA cannot authorize off-main claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.originalStateWrite(false)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("equal original modal publication cancels retained claim", !claim)
        } catch { record("equal original modal publication cancels retained claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.attach(UUID()); f.attach(f.owner)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("original annotation owner ABA cancels retained claim", !claim)
        } catch { record("original annotation owner ABA cancels retained claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.session.originalAnnotationPresentationWillChange(owner: UUID())
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("foreign original owner cannot revoke this source", claim)
        } catch { record("foreign original owner cannot revoke this source", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.session.removeAnnotationPresentation(owner: f.owner)
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("original owner removal cancels retained claim", !claim)
        } catch { record("original owner removal cancels retained claim", false) }
        do {
            let f = RootFacetFixture()
            f.state.duringGetter = { [weak f] in
                guard let f else { return }; f.state.duringGetter = nil
                f.originalStateWrite(true); f.originalStateWrite(false)
            }
            record("getter reentry during capture cannot escape registered publication", refused { _ = try f.capture() })
        }
        do {
            let f = RootFacetFixture(); let source = try f.capture(); let latch = source.claimObservation
            f.state.duringGetter = { [weak f] in
                guard let f else { return }; f.state.duringGetter = nil
                f.originalStateWrite(true); f.originalStateWrite(false)
            }
            let rejected = refused { try source.validate(f.bindings, workspace: f.workspace) }
            let claim = await Task.detached { latch.claimIfCurrent { true } }.value
            record("getter reentry during later validation retires same off-main claim", rejected && !claim)
        } catch { record("getter reentry during later validation retires same off-main claim", false) }
        do {
            let f = RootFacetFixture(); let source = try f.capture()
            f.originalStateWrite(true); f.originalStateWrite(false)
            record("same retained original validator rejects completed modal ABA", refused { try source.validate(f.bindings, workspace: f.workspace) })
        } catch { record("same retained original validator rejects completed modal ABA", false) }
        let failed = rows.filter { $0["passed"] as? Bool == false }.count
        let output: [String: Any] = ["passed": rows.count - failed, "failed": failed, "controls": rows,
            "scope": "ACTUAL_RN_ROOT_SOURCE_AND_ANNOTATION_FACET_WITH_DECLARED_PLATFORM_DOMAIN_BOUNDARIES"]
        print(String(data: try! JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys]), encoding: .utf8)!)
        exit(failed == 0 ? 0 : 1)
    }
}
