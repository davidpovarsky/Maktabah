import Foundation
import Observation

// Only the Apple native manager/book/view-model shell is doubled. The runner
// inserts the complete exact producer block from the actual downstream adapter.
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    var activeBackendID: BackendID = .otzaria
    var generation: UInt64 = 0
    var beforeNextCommit: (() throws -> Void)?
    func commitCheckedAsync(_ backend: BackendID, beforeCommit: () throws -> Void = {}, publish: () -> Void = {}) async throws {
        await Task.yield()
        let hook = beforeNextCommit
        beforeNextCommit = nil
        try hook?()
        try beforeCommit()
        activeBackendID = backend
        publish()
    }
}
enum BackendTransitionError: Error { case transitionSuperseded }
@MainActor final class ChavrusaTextTargetBackendBookResolver {
    static let shared = ChavrusaTextTargetBackendBookResolver()
    func withTargetCatalog<T>(in backend: BackendID, operation: () async throws -> T) async throws -> T {
        await Task.yield()
        return try await operation()
    }
    func resolveBook(id: Int, backendLocator: String?, title: String?, in backend: BackendID) throws -> MappingFixtureBook {
        .init(id, key: backendLocator ?? "fixture", backend: backend)
    }
}
@MainActor final class MappingFixtureBook {
    let id: Int
    var backendLocator: TextLocator?
    init(_ id: Int, key: String, backend: BackendID = .otzaria) {
        self.id = id
        backendLocator = .init(backend: backend, workKey: key, position: .legacyLine(0))
    }
}
@MainActor final class MappingFixtureReader {
    var saveCalls = 0
    var closeCalls = 0
    var annotationEvent: Int?
    var searchEvent: Int?
    var currentContentId: Int?
    var beforeSave: (() -> Void)?
    init(book: MappingFixtureBook? = nil) {}
    func saveCurrentState() { saveCalls += 1; let callback = beforeSave; beforeSave = nil; callback?() }
    func closeReaderInspector() { closeCalls += 1 }
    var renderRevision = 0
    var contentText = ""
    var needsScrollRestore = false
    var loadCalls = 0
    func loadBackendContent(_ locator: TextLocator) { loadCalls += 1 }
    func loadInitialContent(initialContentId: Int?) { loadCalls += 1 }
    func loadTOC(book: MappingFixtureBook) { loadCalls += 1 }
}

@MainActor @Observable final class iOSNavigationManager {
    struct ReaderTab: Identifiable, Equatable {
        let id: UUID
        let book: MappingFixtureBook
        var initialContentId: Int?
        var viewModel: MappingFixtureReader
        static func == (lhs: ReaderTab, rhs: ReaderTab) -> Bool { lhs.id == rhs.id }
    }
    @ObservationIgnored let installed: Bool
    var selectedBook: MappingFixtureBook?
    var selectedContentId: Int?
    @ObservationIgnored var beforeSelectionPublication: (() -> Void)?
    var persistCalls = 0
    var openTabs: [ReaderTab] = [] {
        willSet { if installed { StudyWorkspaceNavigationAdapter.nativeMappingTabsWillChange(self, to: newValue) } }
        didSet { if installed { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) } }
    }
    var activeTabId: UUID? {
        willSet {
            if installed { StudyWorkspaceNavigationAdapter.nativeMappingSelectionWillChange(self, to: newValue) }
            let callback = beforeSelectionPublication; beforeSelectionPublication = nil; callback?()
        }
        didSet { if installed { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) } }
    }
    init(installed: Bool) {
        self.installed = installed
        if installed { StudyWorkspaceNavigationAdapter.nativeMappingOwnerInitialized(self) }
    }
    isolated deinit {
        if installed { StudyWorkspaceNavigationAdapter.nativeMappingOwnerWillDeinitialize(self) }
    }
    func selectTab(id: UUID) {
        guard activeTabId != id else { return }
        if let activeId = activeTabId, let currentTab = openTabs.first(where: { $0.id == activeId }) {
            currentTab.viewModel.saveCurrentState()
            if activeId != id { currentTab.viewModel.closeReaderInspector() }
        }
        activeTabId = id
        if let nextTab = openTabs.first(where: { $0.id == id }) {
            nextTab.viewModel.annotationEvent = nil
            nextTab.viewModel.searchEvent = nil
            nextTab.viewModel.needsScrollRestore = true
            selectedBook = nextTab.book
            selectedContentId = nextTab.viewModel.currentContentId
        }
        persistCurrentSession(immediate: false)
    }
    func closeTab(id: UUID) {
        openTabs.removeAll { $0.id == id }
        if activeTabId == id { activeTabId = openTabs.first?.id }
    }
    func persistCurrentSession(immediate: Bool) { persistCalls += 1 }
}

@MainActor @Observable final class StudyWorkspaceNavigationAdapter {
    let sceneID: String
    let store: StudyWorkspaceStore
    private(set) var attached = false
    private var liveGroupID: UUID?
    private var liveBackend: BackendID?
    private(set) var isSwitching = false
    var errorMessage: String?
    private var cache: [UUID: [BackendID: [iOSNavigationManager.ReaderTab]]] = [:]
    var selection: StudySceneSelection? { store.snapshot?.scenes[sceneID] }
    var group: StudyTabGroup? { store.selectedGroup(scene: sceneID) }
    init(sceneID: String, store: StudyWorkspaceStore) { self.sceneID = sceneID; self.store = store }
    func fixtureConnect(_ manager: iOSNavigationManager, groupID: UUID, backend: BackendID = .otzaria) {
        bindMappingOwner(manager)
        attached = true
        setMappingLiveContext(groupID: groupID, backend: backend, manager: manager)
    }
    

    /// Unavailable until the exact native initialization/setter/lifetime hooks
    /// are installed. Store-only checkpoints never imply native coverage.
    let mappingOwnershipSource = StudyWorkspaceMappingSource(available: false)
    @ObservationIgnored private weak var mappingManager: iOSNavigationManager?
    @ObservationIgnored private var mappingOwnerID: ObjectIdentifier?
    @ObservationIgnored private var mappingSubscription: StudyWorkspaceMappingSubscription?
    @ObservationIgnored private var readerReservation: StudyWorkspaceNativeReaderReservation?
    @ObservationIgnored private var reservedCheckpoint: StudyWorkspaceNativeReaderReservation?
    @ObservationIgnored private var tabSelectionReservation: StudyWorkspaceNativeTabSelectionReservation?
    @ObservationIgnored private var tabSelectionCheckpoint: StudyWorkspaceNativeTabSelectionReservation?
    private final class WeakMappingAdapter {
        weak var value: StudyWorkspaceNavigationAdapter?
        init(_ value: StudyWorkspaceNavigationAdapter) { self.value = value }
    }
    private final class WeakMappingManager {
        weak var value: iOSNavigationManager?
        init(_ value: iOSNavigationManager) { self.value = value }
    }
    private static var mappingAdapters: [ObjectIdentifier: WeakMappingAdapter] = [:]
    private static var mappingHookOwners: [ObjectIdentifier: WeakMappingManager] = [:]

    isolated deinit {
        mappingSubscription?.cancel()
        mappingOwnershipSource.retire()
        Self.mappingAdapters.removeValue(forKey: ObjectIdentifier(self))
    }

    func mappingOwnershipObservation() -> StudyWorkspaceMappingObservation? {
        guard readerReservation?.policy.isPublishing != true, tabSelectionReservation?.policy.isPublishing != true,
              let manager = mappingManager, let epoch = mappingOwnershipSource.event.epoch,
              let projection = currentMappingProjection(manager) else { return nil }
        return .init(source: mappingOwnershipSource, owner: ObjectIdentifier(manager), scene: sceneID, epoch: epoch,
            coverage: .liveNativeSetters, projection: projection)
    }

    private func bindMappingOwner(_ manager: iOSNavigationManager) {
        guard mappingManager == nil else { return }
        mappingManager = manager
        mappingOwnerID = ObjectIdentifier(manager)
        Self.mappingAdapters = Self.mappingAdapters.filter { $0.value.value != nil }
        Self.mappingAdapters[ObjectIdentifier(self)] = .init(self)
        mappingSubscription = store.mappingSource(scene: sceneID).subscribe(owner: self) { adapter, event in
            if (event.reasons.contains(.ownerLifetime) || event.reasons.contains(.epochExhausted)) && event.phase == .unavailable {
                adapter.tabSelectionReservation?.policy.invalidate()
                adapter.mappingOwnershipSource.retire()
            } else if let checkpoint = adapter.tabSelectionCheckpoint,
                      checkpoint === adapter.tabSelectionReservation {
                guard checkpoint.policy.observesOwnedStorePublication(event) else {
                    adapter.mappingOwnershipSource.beginChange([.readerReservation])
                    adapter.finishMappingPublication()
                    return
                }
                if event.phase == .available { adapter.finishMappingPublication() }
            } else if event.phase == .changing {
                // Only the exact already committed native reservation's own
                // normal checkpoint preserves this native owner epoch.
                if let checkpoint = adapter.reservedCheckpoint,
                   checkpoint === adapter.readerReservation,
                   checkpoint.policy.phase == .committed,
                   checkpoint.policy.epoch == adapter.mappingOwnershipSource.event.epoch { return }
                adapter.readerReservation?.policy.invalidate()
                adapter.tabSelectionReservation?.policy.invalidate()
                adapter.mappingOwnershipSource.beginChange(event.reasons)
            } else {
                adapter.finishMappingPublication()
            }
        }
    }

    private func currentMappingProjection(_ manager: iOSNavigationManager) -> StudyWorkspaceMappingProjection? {
        mappingProjection(manager, tabs: manager.openTabs, activeID: manager.activeTabId,
            groupID: liveGroupID, backend: liveBackend)
    }

    private func mappingProjection(_ manager: iOSNavigationManager, tabs: [iOSNavigationManager.ReaderTab],
                                   activeID: UUID?, groupID: UUID?, backend: BackendID?) -> StudyWorkspaceMappingProjection? {
        guard attached, mappingManager === manager,
              Self.mappingHookOwners[ObjectIdentifier(manager)]?.value === manager,
              store.mappingSource(scene: sceneID).mappingRevision != nil,
              backend == BackendCoordinator.shared.activeBackendID else { return nil }
        return StudyWorkspaceMappingPolicy.native(
            workspace: StudyWorkspaceMappingPolicy.workspace(store.snapshot, scene: sceneID),
            groupID: groupID, backend: backend, tabs: mappingTabs(tabs), activeID: activeID)
    }

    private func mappingTabs(_ tabs: [iOSNavigationManager.ReaderTab]) -> [StudyWorkspaceNativeMappingTab] {
        tabs.map { tab in
            StudyWorkspaceNativeMappingTab(id: tab.id, target: .init(
                backend: tab.book.backendLocator?.backend ?? BackendCoordinator.shared.activeBackendID,
                bookID: tab.book.id, workKey: tab.book.backendLocator?.workKey,
                readerOwner: ObjectIdentifier(tab.viewModel)))
        }
    }

    private func setMappingLiveContext(groupID: UUID, backend: BackendID, manager: iOSNavigationManager) {
        let before = currentMappingProjection(manager)
        let after = mappingProjection(manager, tabs: manager.openTabs, activeID: manager.activeTabId,
            groupID: groupID, backend: backend)
        mappingOwnershipSource.beginChange(StudyWorkspaceMappingPolicy.changes(from: before, to: after))
        liveGroupID = groupID
        liveBackend = backend
        finishMappingPublication()
    }

    private func finishMappingPublication() {
        mappingOwnershipSource.finishChange(available: mappingManager.flatMap(currentMappingProjection) != nil)
    }

    /// These entry points have no effect without a registered actual adapter.
    /// The companion exact upstream patch remains UNAPPLIED in R's worktree.
    static func nativeMappingOwnerInitialized(_ manager: iOSNavigationManager) {
        mappingHookOwners = mappingHookOwners.filter { $0.value.value != nil }
        mappingHookOwners[ObjectIdentifier(manager)] = .init(manager)
    }

    /// Saved group documents remain authoritative; only obsolete in-memory
    /// reader instances are discarded after a managed Otzaria snapshot update.
    static func managedLibraryDidUpdate(_ manager: iOSNavigationManager) {
        withMappingAdapters(manager) { adapter in
            for id in Array(adapter.cache.keys) {
                adapter.cache[id]?.removeValue(forKey: .otzaria)
            }
            adapter.synchronize(manager)
        }
    }

    static func nativeMappingOwnerWillDeinitialize(_ manager: iOSNavigationManager) {
        for adapter in mappingAdapters.values.compactMap(\.value) where adapter.mappingOwnerID == ObjectIdentifier(manager) {
            adapter.mappingOwnershipSource.retire()
            adapter.mappingSubscription?.cancel()
        }
        mappingHookOwners.removeValue(forKey: ObjectIdentifier(manager))
    }

    private static func withMappingAdapters(_ manager: iOSNavigationManager, _ update: (StudyWorkspaceNavigationAdapter) -> Void) {
        mappingAdapters = mappingAdapters.filter { $0.value.value != nil }
        for adapter in mappingAdapters.values.compactMap(\.value) where adapter.mappingManager === manager { update(adapter) }
    }

    static func nativeMappingTabsWillChange(_ manager: iOSNavigationManager, to tabs: [iOSNavigationManager.ReaderTab]) {
        withMappingAdapters(manager) { adapter in
            let before = adapter.currentMappingProjection(manager)
            let after = adapter.mappingProjection(manager, tabs: tabs, activeID: manager.activeTabId,
                groupID: adapter.liveGroupID, backend: adapter.liveBackend)
            let reasons = StudyWorkspaceMappingPolicy.changes(from: before, to: after)
                .union(StudyWorkspaceMappingPolicy.nativeTargetChanges(from: adapter.mappingTabs(manager.openTabs), to: adapter.mappingTabs(tabs)))
            if let reservation = adapter.tabSelectionReservation {
                // Existing-tab selection owns no array publication, even an
                // equal-value setter or a reentrant replacement with the same IDs.
                reservation.policy.invalidate()
                adapter.mappingOwnershipSource.beginChange(reasons.union([.tabMembership]))
                return
            }
            guard !reasons.isEmpty else { return }
            if let reservation = adapter.readerReservation,
               reservation.policy.permitsTabsPublication(from: before, to: after) { return }
            adapter.mappingOwnershipSource.beginChange(reasons)
        }
    }

    static func nativeMappingSelectionWillChange(_ manager: iOSNavigationManager, to activeID: UUID?) {
        withMappingAdapters(manager) { adapter in
            let before = adapter.currentMappingProjection(manager)
            let after = adapter.mappingProjection(manager, tabs: manager.openTabs, activeID: activeID,
                groupID: adapter.liveGroupID, backend: adapter.liveBackend)
            var reasons = StudyWorkspaceMappingPolicy.changes(from: before, to: after)
            if manager.activeTabId != activeID { reasons.insert(.selection) }
            if let reservation = adapter.tabSelectionReservation {
                guard reservation.policy.permitsSelectionPublication(from: before, to: after) else {
                    adapter.mappingOwnershipSource.beginChange(reasons.union([.selection]))
                    return
                }
                return
            }
            guard !reasons.isEmpty else { return }
            if let reservation = adapter.readerReservation,
               reservation.policy.permitsSelectionPublication(from: before, to: after) { return }
            adapter.mappingOwnershipSource.beginChange(reasons)
        }
    }

    static func nativeMappingDidChange(_ manager: iOSNavigationManager) {
        withMappingAdapters(manager) { adapter in
            if let reservation = adapter.tabSelectionReservation, reservation.policy.isPublishing,
               !reservation.policy.didPublishSelection(actual: adapter.currentMappingProjection(manager)) {
                adapter.mappingOwnershipSource.beginChange([.readerReservation])
            }
            if let reservation = adapter.readerReservation, reservation.policy.isPublishing,
               !reservation.policy.didPublish(actual: adapter.currentMappingProjection(manager)) {
                adapter.mappingOwnershipSource.beginChange([.readerReservation])
            }
            adapter.finishMappingPublication()
        }
    }

    // MARK: Original native reader ownership

    /// Reserves an original ReaderTab/ReaderViewModel before Core admission.
    /// This does not load, select, persist or authorize content.
    func reserveNativeReader(requestID: UUID, book: BooksData, destination: LibraryReaderDestination,
                             manager: iOSNavigationManager) throws -> StudyWorkspaceNativeReaderReservation {
        guard attached, !isSwitching, mappingManager === manager, readerReservation == nil, tabSelectionReservation == nil,
              mappingOwnershipObservation() != nil,
              book.backendLocator?.backend == destination.sectionLocator.backend,
              book.backendLocator?.workKey == destination.sectionLocator.workKey,
              destination.sectionLocator.backend == BackendCoordinator.shared.activeBackendID else {
            throw StudyWorkspaceError.invalidMembership
        }
        let tab = iOSNavigationManager.ReaderTab(id: UUID(), book: book,
            initialContentId: LegacyIdentityRegistry.shared.id(for: destination.sectionLocator),
            viewModel: ReaderViewModel(book: book))
        // A reservation changes the native mapping contract, so invalidate
        // any prior context before the caller can admit this request.
        mappingOwnershipSource.beginChange([.readerReservation])
        finishMappingPublication()
        guard let actual = mappingOwnershipObservation(),
              let saved = StudyWorkspaceMappingPolicy.workspace(store.snapshot, scene: sceneID),
              let target = mappingTabs([tab]).first else { throw StudyWorkspaceError.invalidMembership }
        let policy = try StudyWorkspaceReaderReservation(requestID: requestID, observation: actual,
            workspace: saved, target: target)
        let reservation = StudyWorkspaceNativeReaderReservation(policy: policy, tab: tab)
        readerReservation = reservation
        return reservation
    }

    func reservedNativeReader(requestID: UUID) throws -> StudyWorkspaceNativeReaderReservation {
        guard let reservation = readerReservation, reservation.policy.requestID == requestID else {
            throw StudyWorkspaceError.invalidMembership
        }
        try validateNativeReader(reservation)
        return reservation
    }

    func validateNativeReader(_ reservation: StudyWorkspaceNativeReaderReservation) throws {
        guard attached, !isSwitching, readerReservation === reservation,
              let actual = mappingOwnershipObservation(), reservation.policy.matches(actual) else {
            throw StudyWorkspaceError.invalidMembership
        }
    }

    func applyNativeReader(_ reservation: StudyWorkspaceNativeReaderReservation, operation: () throws -> Void) throws {
        try validateNativeReader(reservation)
        guard let before = mappingOwnershipObservation() else { throw StudyWorkspaceError.invalidMembership }
        do {
            try reservation.policy.beginApply(before)
            try operation()
            guard let actual = mappingOwnershipObservation() else { throw StudyWorkspaceError.invalidMembership }
            try reservation.policy.finishApply(actual)
        } catch {
            reservation.policy.invalidate()
            mappingOwnershipSource.beginChange([.readerReservation])
            finishMappingPublication()
            throw error
        }
    }

    func hasCommittedNativeReader(tabID: UUID) -> Bool {
        guard let reservation = readerReservation, reservation.tab.id == tabID,
              reservation.policy.phase == .committed,
              let actual = mappingOwnershipObservation() else { return false }
        return reservation.policy.matches(actual)
    }

    func releaseNativeReader(_ reservation: StudyWorkspaceNativeReaderReservation) {
        guard readerReservation === reservation else { return }
        reservation.policy.release()
        readerReservation = nil
        // Never remove a tab or undo user state, including a partially applied
        // command. The original orchestrator records uncertain native effects.
        mappingOwnershipSource.beginChange([.readerReservation])
        finishMappingPublication()
    }

    // MARK: Existing original Reader-tab selection

    func reserveNativeTabSelection(requestID: UUID, tabID: UUID,
                                   manager: iOSNavigationManager) throws -> StudyWorkspaceNativeTabSelectionReservation {
        let targets = manager.openTabs.filter { $0.id == tabID }
        guard attached, !isSwitching, mappingManager === manager,
              readerReservation == nil, tabSelectionReservation == nil,
              targets.count == 1, let tab = targets.first,
              tab.book.backendLocator?.backend == BackendCoordinator.shared.activeBackendID,
              mappingOwnershipObservation() != nil else { throw StudyWorkspaceError.invalidMembership }
        // Retire prior requests before admitting the new, existing-tab contract.
        mappingOwnershipSource.beginChange([.readerReservation])
        finishMappingPublication()
        guard let native = mappingOwnershipObservation(), let saved = store.mappingObservation(scene: sceneID) else {
            throw StudyWorkspaceError.invalidMembership
        }
        let policy = try StudyWorkspaceTabSelectionReservation(requestID: requestID,
            observation: native, workspace: saved, targetID: tabID)
        let reservation = StudyWorkspaceNativeTabSelectionReservation(policy: policy, tab: tab)
        tabSelectionReservation = reservation
        return reservation
    }

    func validateNativeTabSelection(_ reservation: StudyWorkspaceNativeTabSelectionReservation) throws {
        guard attached, !isSwitching, tabSelectionReservation === reservation,
              let manager = mappingManager, let native = mappingOwnershipObservation(),
              let saved = store.mappingObservation(scene: sceneID),
              reservation.policy.matches(native, workspace: saved) else { throw StudyWorkspaceError.invalidMembership }
        let tabs = manager.openTabs.filter { $0.id == reservation.tab.id }
        guard tabs.count == 1, let tab = tabs.first, tab.book === reservation.tab.book,
              tab.viewModel === reservation.tab.viewModel else { throw StudyWorkspaceError.invalidMembership }
    }

    func applyNativeTabSelection(_ reservation: StudyWorkspaceNativeTabSelectionReservation,
                                 operation: () throws -> Void) throws {
        try validateNativeTabSelection(reservation)
        guard let manager = mappingManager, let native = mappingOwnershipObservation(),
              let saved = store.mappingObservation(scene: sceneID) else { throw StudyWorkspaceError.invalidMembership }
        do {
            try reservation.policy.beginApply(native, workspace: saved)
            // The caller invokes only the original manager.selectTab action.
            // Its real willSet/didSet consumes the exact one-shot allowance.
            try operation()
            try persistProjection(manager.openTabs, activeID: manager.activeTabId,
                groupID: reservation.policy.original.groupID, backend: reservation.policy.target.target.backend)
            guard let actual = mappingOwnershipObservation(), let persisted = store.mappingObservation(scene: sceneID) else {
                throw StudyWorkspaceError.invalidMembership
            }
            try reservation.policy.finishApply(actual, workspace: persisted)
        } catch {
            reservation.policy.invalidate()
            mappingOwnershipSource.beginChange([.readerReservation])
            finishMappingPublication()
            throw error
        }
    }

    func releaseNativeTabSelection(_ reservation: StudyWorkspaceNativeTabSelectionReservation) {
        guard tabSelectionReservation === reservation else { return }
        reservation.policy.release()
        tabSelectionReservation = nil
        // No tab closure, rollback, new admission or source-observation rearm.
        mappingOwnershipSource.beginChange([.readerReservation])
        finishMappingPublication()
    }

    
    private func persistProjection(_ tabs: [iOSNavigationManager.ReaderTab], activeID: UUID?, groupID: UUID, backend: BackendID) throws {
        guard let saved = store.snapshot?.groups.first(where: { $0.id == groupID }) else { throw StudyWorkspaceError.invalidMembership }
        let merged = StudyWorkspaceProjectionPolicy.merging(live: capture(tabs, backend: backend), into: saved.tabs, backend: backend)
        let before = StudyWorkspaceMappingPolicy.workspace(store.snapshot, scene: sceneID)
        let native = mappingOwnershipObservation()
        let savedObservation = store.mappingObservation(scene: sceneID)
        var tabCheckpointCompleted = false
        defer {
            reservedCheckpoint = nil
            if let checkpoint = tabSelectionCheckpoint, !tabCheckpointCompleted {
                checkpoint.policy.invalidate()
                mappingOwnershipSource.beginChange([.readerReservation])
                finishMappingPublication()
            }
            tabSelectionCheckpoint = nil
        }
        try store.transaction { value in
            guard let index = value.groups.firstIndex(where: { $0.id == groupID }) else { throw StudyWorkspaceError.invalidMembership }
            value.groups[index].tabs = merged
            value.groups[index].activeTabID = (activeID ?? saved.activeTabID).flatMap { id in merged.contains { $0.id == id } ? id : nil }
            if var scene = value.scenes[sceneID] {
                var activeIDs = scene.activeTabIDsByGroup ?? [:]
                if let activeID, merged.contains(where: { $0.id == activeID }) { activeIDs[groupID] = activeID }
                else if merged.isEmpty { activeIDs.removeValue(forKey: groupID) }
                scene.activeTabIDsByGroup = activeIDs
                value.scenes[sceneID] = scene
                value.lastActiveSceneID = sceneID
            }
            if let reservation = readerReservation, let native,
               reservation.policy.permitsCheckpoint(from: before,
                   to: StudyWorkspaceMappingPolicy.workspace(value, scene: sceneID), actual: native) {
                reservedCheckpoint = reservation
            }
            if let reservation = tabSelectionReservation, reservation.policy.phase == .selected,
               let native, let savedObservation {
                try reservation.policy.beginCheckpoint(native: native, workspace: savedObservation,
                    candidate: StudyWorkspaceMappingPolicy.workspace(value, scene: sceneID))
                tabSelectionCheckpoint = reservation
            }
        }
        if let checkpoint = tabSelectionCheckpoint {
            guard let manager = mappingManager, let saved = store.mappingObservation(scene: sceneID) else {
                throw StudyWorkspaceError.invalidMembership
            }
            try checkpoint.policy.finishCheckpoint(nativeProjection: currentMappingProjection(manager), workspace: saved)
            tabCheckpointCompleted = true
        }
        cache[groupID, default: [:]][backend] = tabs
    }
    func synchronize(_ manager: iOSNavigationManager) {
        guard let liveGroupID, let liveBackend else { return }
        try? persistProjection(manager.openTabs, activeID: manager.activeTabId, groupID: liveGroupID, backend: liveBackend)
    }

    private func capture(_ tabs: [iOSNavigationManager.ReaderTab], backend: BackendID) -> [ReaderDocumentTab] {
        tabs.map { .init(backend: backend, session: .init(id: $0.id, bookId: $0.book.id,
            backendLocator: $0.book.backendLocator, contentId: $0.initialContentId, locator: $0.book.backendLocator)) }
    }
    private func matches(_ tab: iOSNavigationManager.ReaderTab, _ document: ReaderDocumentTab) -> Bool {
        tab.id == document.id && tab.book.id == document.session.bookId && tab.book.backendLocator?.workKey == document.session.backendLocator?.workKey
    }
    private func hydrate(_ document: ReaderDocumentTab) throws -> iOSNavigationManager.ReaderTab {
        .init(id: document.id, book: .init(document.session.bookId, key: document.session.backendLocator?.workKey ?? "fixture", backend: document.backend),
            initialContentId: document.session.contentId, viewModel: .init())
    }
}


typealias BooksData = MappingFixtureBook
typealias ReaderViewModel = MappingFixtureReader
@MainActor final class LegacyIdentityRegistry {
    static let shared = LegacyIdentityRegistry()
    func id(for locator: TextLocator) -> Int { 0 }
}
@MainActor final class StudyWorkspaceNativeReaderReservation {
    let policy: StudyWorkspaceReaderReservation
    let tab: iOSNavigationManager.ReaderTab
    init(policy: StudyWorkspaceReaderReservation, tab: iOSNavigationManager.ReaderTab) {
        self.policy = policy; self.tab = tab
    }
}


/// Original existing objects, retained only for their single source-bound
/// selection. No replacement Book/ReaderViewModel or copied reader state.
@MainActor final class StudyWorkspaceNativeTabSelectionReservation {
    let policy: StudyWorkspaceTabSelectionReservation
    let tab: iOSNavigationManager.ReaderTab
    init(policy: StudyWorkspaceTabSelectionReservation, tab: iOSNavigationManager.ReaderTab) {
        self.policy = policy; self.tab = tab
    }
}
