import Foundation

struct StudyProfile: Codable, Equatable, Identifiable, Sendable {
    var id: UUID
    var name: String
    var symbol: String
    var order: Int
    /// Absent in existing v1 sidecars; nil keeps the original system appearance.
    var color: StudyProfileColor? = nil
}

/// Stable semantic choices, independent of SwiftUI and device color encoding.
enum StudyProfileColor: String, Codable, CaseIterable, Sendable {
    case blue, teal, green, orange, red, purple
}

struct ReaderDocumentTab: Codable, Equatable, Identifiable, Sendable {
    var id: UUID { session.id }
    var backend: BackendID
    var session: iOSReaderTabSession

    func reidentified() -> ReaderDocumentTab {
        let s = session
        return .init(backend: backend, session: .init(
            id: UUID(), bookId: s.bookId, bookTitle: s.bookTitle, backendLocator: s.backendLocator,
            contentId: s.contentId, locator: s.locator, page: s.page, part: s.part, scrollPosition: s.scrollPosition,
            selectedRange: s.selectedRange, expandedNodeIDs: s.expandedNodeIDs, sidebarScrollPosition: s.sidebarScrollPosition,
            isSidebarCollapsed: s.isSidebarCollapsed, searchText: s.searchText, searchModeRaw: s.searchModeRaw,
            nearDistance: s.nearDistance, highlightTerms: s.highlightTerms))
    }
}

struct StudyTabGroup: Codable, Equatable, Identifiable, Sendable {
    var id: UUID
    var profileID: UUID
    var name: String
    var order: Int
    var tabs: [ReaderDocumentTab]
    var activeTabID: UUID?
}

enum StudyWorkspaceProjectionPolicy {
    static func activeDocumentID(in group: StudyTabGroup, selection: StudySceneSelection?) -> UUID? {
        let requested = selection?.activeTabIDsByGroup?[group.id] ?? group.activeTabID
        return group.tabs.first(where: { $0.id == requested })?.id ?? group.tabs.first?.id
    }

    /// Replace the live backend's slots in order without moving foreign-source
    /// documents to the front whenever a reading checkpoint is saved.
    static func merging(live: [ReaderDocumentTab], into saved: [ReaderDocumentTab], backend: BackendID) -> [ReaderDocumentTab] {
        let liveIDs = Set(live.map(\.id))
        var next = 0
        var result: [ReaderDocumentTab] = []
        for document in saved {
            if document.backend != backend {
                result.append(document)
            } else if liveIDs.contains(document.id), live.indices.contains(next) {
                result.append(live[next])
                next += 1
            }
        }
        result.append(contentsOf: live.dropFirst(next))
        return result
    }

    static func backend(restoring committedBackend: BackendID?, requestedID: UUID?, documents: [ReaderDocumentTab], fallback: BackendID) -> BackendID {
        // Startup respects the canonical backend owner's committed source.
        // An explicit group/document selection may request another source.
        committedBackend ?? documents.first(where: { $0.id == requestedID })?.backend ?? documents.first?.backend ?? fallback
    }
}

struct StudySceneSelection: Codable, Equatable, Sendable {
    var profileID: UUID
    var groupID: UUID
    var activeTabIDsByGroup: [UUID: UUID]? = nil
}

struct StudyWorkspaceSnapshot: Codable, Equatable, Sendable {
    static let currentVersion = 1
    var version = currentVersion
    var revision: UInt64 = 0
    var migratedLegacySession = false
    var profiles: [StudyProfile] = []
    var groups: [StudyTabGroup] = []
    var scenes: [String: StudySceneSelection] = [:]
    /// Startup fallback for a newly created/restored system scene; an exact
    /// existing scene selection always wins. Optional for existing v1 files.
    var lastActiveSceneID: String? = nil

    func validate() throws {
        guard version == Self.currentVersion else { throw StudyWorkspaceError.unsupportedVersion }
        guard lastActiveSceneID.map({ scenes[$0] != nil }) ?? true else { throw StudyWorkspaceError.invalidMembership }
        guard !profiles.isEmpty, !groups.isEmpty,
              Set(profiles.map(\.id)).count == profiles.count,
              Set(groups.map(\.id)).count == groups.count else { throw StudyWorkspaceError.invalidMembership }
        let profileIDs = Set(profiles.map(\.id))
        guard profiles.allSatisfy({ profile in
            !profile.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && groups.contains(where: { $0.profileID == profile.id })
        }), groups.allSatisfy({ !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) else {
            throw StudyWorkspaceError.invalidMembership
        }
        let allTabIDs = groups.flatMap { $0.tabs.map(\.id) }
        guard Set(allTabIDs).count == allTabIDs.count else { throw StudyWorkspaceError.invalidMembership }
        for group in groups {
            guard profileIDs.contains(group.profileID),
                  Set(group.tabs.map(\.id)).count == group.tabs.count,
                  group.activeTabID.map({ id in group.tabs.contains { $0.id == id } }) ?? true
            else { throw StudyWorkspaceError.invalidMembership }
            for tab in group.tabs {
                guard tab.session.backendLocator.map({ $0.backend == tab.backend }) ?? true,
                      tab.session.locator.map({ $0.backend == tab.backend }) ?? true else { throw StudyWorkspaceError.backendMismatch }
            }
        }
        for selection in scenes.values {
            guard groups.contains(where: { $0.id == selection.groupID && $0.profileID == selection.profileID })
            else { throw StudyWorkspaceError.invalidMembership }
        }
    }
}

enum StudyWorkspaceError: Error, LocalizedError {
    case unsupportedVersion, invalidMembership, unavailableBook, backendMismatch, groupNotEmpty, lastProfile, lastGroup
    var errorDescription: String? {
        let localized = StudyWorkspaceText(locale: .current)
        return switch self {
        case .unsupportedVersion: localized("This study workspace version is unsupported. Your data has been preserved.", "גרסת קובץ סביבת הלימוד אינה נתמכת. הנתונים נשמרו.")
        case .invalidMembership: localized("The study workspace could not be read. Your existing data has been preserved.", "לא ניתן לקרוא את סביבת הלימוד. הנתונים הקיימים נשמרו.")
        case .unavailableBook: localized("A book in this group is currently unavailable. Your current tab group has been preserved.", "ספר בקבוצה אינו זמין כעת. קבוצת הכרטיסיות הנוכחית נשמרה.")
        case .backendMismatch: localized("Switch to the matching library source before opening this group.", "יש לעבור למקור הספרייה המתאים לפני פתיחת קבוצה זו.")
        case .groupNotEmpty: localized("This group contains tabs.", "הקבוצה מכילה כרטיסיות.")
        case .lastProfile: localized("Keep at least one profile.", "יש להשאיר לפחות פרופיל אחד.")
        case .lastGroup: localized("Keep at least one tab group in this profile.", "יש להשאיר לפחות קבוצת כרטיסיות אחת בפרופיל.")
        }
    }
}

/// Bilingual labels shared by the study workspace and its native controls.
struct StudyWorkspaceText {
    private let prefersHebrew: Bool

    init(locale: Locale) {
        prefersHebrew = locale.language.languageCode?.identifier == "he"
    }

    func callAsFunction(_ english: String, _ hebrew: String) -> String {
        prefersHebrew ? hebrew : english
    }
}
