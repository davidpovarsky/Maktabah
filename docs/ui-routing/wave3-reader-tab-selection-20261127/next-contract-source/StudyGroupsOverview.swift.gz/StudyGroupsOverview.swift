import SwiftUI
import UIKit

struct StudyGroupsOverview: View {
    @Bindable var workspace: StudyWorkspaceNavigationAdapter
    let manager: iOSNavigationManager
    let onOpenLibrary: () -> Void
    let onClose: () -> Void
    @Environment(\.locale) private var locale
    @Environment(\.maktabahNativeRoutingSession) private var routingSession
    @State private var showsNamePrompt = false
    @State private var name = ""
    @State private var copiesCurrent = false
    @State private var renamesCurrent = false
    @State private var confirmsDelete = false
    @State private var showsProfiles = false
    @State private var presentationViewID = UUID()
    @AppStorage("chavrusa.study-tabs.layout") private var tabSwitcherLayoutRaw = ReaderTabSwitcherLayout.grid.rawValue

    private var localized: StudyWorkspaceText { StudyWorkspaceText(locale: locale) }

    private var tabSwitcherLayout: ReaderTabSwitcherLayout {
        ReaderTabSwitcherLayout(rawValue: tabSwitcherLayoutRaw) ?? .grid
    }

    private var componentOwner: MaktabahNativeComponentOwner? {
        routingSession?.componentOwner(for: MaktabahNativeWorkspacePresentationBinding.Parent.overview.destination)
    }

    private var blocksOriginalPresentation: Bool {
        showsNamePrompt || confirmsDelete || workspace.isSwitching || workspace.errorMessage != nil
    }

    private func originalBinding<Value: Equatable>(_ value: Binding<Value>,
        change: MaktabahNativeWorkspacePresentationBinding.OriginalChange = .draft) -> Binding<Value> {
        maktabahWorkspaceOriginalBinding(value, binding: routingSession?.workspacePresentation,
            host: .overview, stateOwnerID: presentationViewID, change: change)
    }

    var body: some View {
        NavigationStack {
            TabSwitcherPageHost(
                documents: (workspace.group?.tabs ?? []).map {
                    ReaderTabSwitcherDocument(id: $0.id, title: $0.session.bookTitle ?? localized("Book", "ספר"), subtitle: $0.backend.displayName)
                },
                selectedID: workspace.activeDocumentID,
                layoutMode: tabSwitcherLayout,
                onSelect: openDocument,
                onClose: closeDocument,
                onReorder: { document, index in
                    workspace.reorderDocument(document.id, to: index, manager: manager)
                },
                contextMenu: contextMenu
            )
            .maktabahWorkspaceOverviewComponent(tabSwitcherLayout == .grid ? .grid : .list,
                                                workspace: workspace, manager: manager)
            .overlay {
                if workspace.group?.tabs.isEmpty != false {
                    ContentUnavailableView {
                        Label(localized("No tabs in this group", "אין כרטיסיות בקבוצה"), systemImage: "book.closed")
                    } actions: {
                        Button(localized("Open a book from the library", "פתח ספר מהספרייה")) { onClose(); onOpenLibrary() }
                    }
                }
            }
            .navigationTitle(localized("All Tabs", "כל הכרטיסיות"))
            .safeAreaInset(edge: .top) {
                ScrollableGroupsHost(groups: workspace.groups, selectedID: workspace.selection?.groupID, isEnabled: !workspace.isSwitching) { id in
                    Task {
                        do { try await workspace.switchGroup(to: id, manager: manager) }
                        catch { workspace.errorMessage = error.localizedDescription }
                    }
                }
                .frame(maxWidth: 640)
                .frame(height: 49)
                .frame(maxWidth: .infinity)
                .padding(.horizontal)
                .maktabahWorkspaceOverviewComponent(.groups, workspace: workspace, manager: manager)
            }
            .toolbar {
                if !MaktabahApp.isIpad {
                    ToolbarItem(placement: .secondaryAction) {
                        StudyProfileMenu(workspace: workspace, manager: manager, compact: true) { originalBinding($showsProfiles, change: .profiles).wrappedValue = true }
                            .maktabahWorkspaceOverviewComponent(.profileMenu, workspace: workspace, manager: manager)
                    }
                    .readerSourceGlassBackground()
                }
                ToolbarItem(placement: .confirmationAction) { Button(localized("Done", "סיום")) { onClose() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        originalBinding($tabSwitcherLayoutRaw, change: .layout).wrappedValue = tabSwitcherLayout == .grid
                            ? ReaderTabSwitcherLayout.list.rawValue
                            : ReaderTabSwitcherLayout.grid.rawValue
                    } label: {
                        Label(
                            tabSwitcherLayout == .grid ? localized("List view", "תצוגת רשימה") : localized("Grid view", "תצוגת רשת"),
                            systemImage: tabSwitcherLayout == .grid ? "list.bullet" : "square.grid.2x2"
                        )
                    }
                    .accessibilityIdentifier("study-tabs-layout-toggle")
                    .maktabahWorkspaceOverviewComponent(.layout, workspace: workspace, manager: manager)
                }
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Button(localized("New empty group", "קבוצה ריקה"), systemImage: "plus") { prompt(copy: false) }
                        Button(localized("New group from current tabs", "קבוצה מהכרטיסיות הנוכחיות"), systemImage: "square.on.square") { prompt(copy: true) }
                        Button(localized("Rename group", "שינוי שם הקבוצה"), systemImage: "pencil") {
                            originalBinding($renamesCurrent).wrappedValue = true; originalBinding($name).wrappedValue = workspace.group?.name ?? ""; originalBinding($showsNamePrompt).wrappedValue = true
                        }
                        Button(localized("Delete group", "מחיקת קבוצה"), systemImage: "trash", role: .destructive) { originalBinding($confirmsDelete).wrappedValue = true }
                    } label: { Label(localized("Tab Groups", "קבוצות כרטיסיות"), systemImage: "ellipsis.circle") }
                    .accessibilityLabel(localized("Tab group actions", "פעולות בקבוצת הכרטיסיות"))
                    .accessibilityIdentifier("study-group-actions-menu")
                    .maktabahWorkspaceOverviewComponent(.actions, workspace: workspace, manager: manager)
                }
            }
            .alert(localized("Tab group name", "שם קבוצת הכרטיסיות"), isPresented: originalBinding($showsNamePrompt)) {
                TextField(localized("Name", "שם"), text: originalBinding($name))
                Button(localized("Save", "שמירה")) {
                    let value = name.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !value.isEmpty else { return }
                    if renamesCurrent, let id = workspace.group?.id {
                        do { try workspace.store.renameGroup(id, name: value) }
                        catch { workspace.errorMessage = error.localizedDescription }
                    } else { Task { await workspace.createGroup(name: value, fromCurrent: copiesCurrent, manager: manager) } }
                }
                Button(localized("Cancel", "ביטול"), role: .cancel) {}
            }
            .confirmationDialog(localized("Delete this group and its tabs?", "למחוק את הקבוצה והכרטיסיות שלה?"), isPresented: originalBinding($confirmsDelete), titleVisibility: .visible) {
                Button(localized("Delete group", "מחיקת קבוצה"), role: .destructive) {
                    guard let old = workspace.group?.id, let replacement = workspace.groups.first(where: { $0.id != old }) else {
                        workspace.errorMessage = StudyWorkspaceError.lastGroup.localizedDescription; return
                    }
                    Task {
                        do {
                            try await workspace.switchGroup(to: replacement.id, manager: manager)
                            try workspace.store.deleteGroup(old)
                        } catch { workspace.errorMessage = error.localizedDescription }
                    }
                }
            }
        }
        .modifier(MaktabahNativeComponentContainer(owner: componentOwner,
            blocked: { blocksOriginalPresentation || showsProfiles }, reveal: { _ in }))
        .modifier(MaktabahNativeWorkspaceOriginalHost(
            binding: routingSession?.workspacePresentation, kind: .overview, stateOwnerID: presentationViewID,
            workspace: workspace, manager: manager,
            profilesPresented: { showsProfiles },
            presentProfiles: { if !MaktabahApp.isIpad { originalBinding($showsProfiles, change: .profiles).wrappedValue = true } },
            blocked: { blocksOriginalPresentation }))
        .background { MaktabahNativeRoutingWitness(kind: .workspaceOverview) }
        .themeTint()
        .onAppear { workspace.synchronize(manager) }
        .sheet(isPresented: originalBinding($showsProfiles, change: .profiles)) {
            StudyProfileManagementView(workspace: workspace, manager: manager)
                .environment(\.maktabahNativeRoutingSession, routingSession)
        }
        .alert(localized("Unable to change the study workspace", "לא ניתן לשנות את סביבת הלימוד"), isPresented: Binding(
            get: { workspace.errorMessage != nil }, set: { if !$0 { workspace.errorMessage = nil } })) {
            Button(localized("OK", "אישור")) { workspace.errorMessage = nil }
        } message: { Text(workspace.errorMessage ?? "") }
        .accessibilityIdentifier("study-groups-overview")
    }

    private func prompt(copy: Bool) {
        originalBinding($renamesCurrent).wrappedValue = false
        originalBinding($copiesCurrent).wrappedValue = copy
        originalBinding($name).wrappedValue = ""
        originalBinding($showsNamePrompt).wrappedValue = true
    }

    private func openDocument(_ document: ReaderTabSwitcherDocument) {
        // Like returning to the browser's already-selected tab: no navigation
        // or restoration should run just to uncover its existing view.
        if workspace.activeDocumentID == document.id {
            onClose()
            return
        }
        Task {
            do {
                guard let group = workspace.group else { return }
                try await workspace.switchGroup(to: group.id, documentID: document.id, manager: manager)
                onClose()
            } catch {
                workspace.errorMessage = error.localizedDescription
            }
        }
    }

    private func closeDocument(_ document: ReaderTabSwitcherDocument) {
        if manager.openTabs.contains(where: { $0.id == document.id }) {
            manager.closeTab(id: document.id)
            workspace.synchronize(manager)
        } else if let group = workspace.group {
            do {
                let remaining = group.tabs.filter { $0.id != document.id }
                try workspace.store.saveTabs(
                    remaining,
                    activeID: group.activeTabID == document.id ? remaining.first?.id : group.activeTabID,
                    groupID: group.id
                )
            } catch {
                workspace.errorMessage = error.localizedDescription
            }
        }
    }

    private func contextMenu(_ document: ReaderTabSwitcherDocument) -> UIMenu? {
        let targets = (workspace.store.snapshot?.groups ?? []).filter { $0.id != workspace.group?.id }
        let move = UIMenu(
            title: localized("Move to Group", "העברה לקבוצה"),
            image: UIImage(systemName: "arrow.right.square"),
            children: targets.map { target in
                UIAction(title: target.name) { _ in
                    workspace.moveTab(document.id, to: target.id, copy: false, manager: manager)
                }
            }
        )
        let copy = UIMenu(
            title: localized("Copy to Group", "העתקה לקבוצה"),
            image: UIImage(systemName: "square.on.square"),
            children: targets.map { target in
                UIAction(title: target.name) { _ in
                    workspace.moveTab(document.id, to: target.id, copy: true, manager: manager)
                }
            }
        )
        let close = UIAction(title: localized("Close Tab", "סגירת כרטיסייה"), image: UIImage(systemName: "xmark"), attributes: .destructive) { _ in
            closeDocument(document)
        }
        return UIMenu(children: targets.isEmpty ? [close] : [move, copy, close])
    }
}
