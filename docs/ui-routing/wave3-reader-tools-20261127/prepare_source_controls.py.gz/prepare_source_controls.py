from pathlib import Path
import hashlib,json
R=Path(__file__).parent
O=R/'controls/source-inputs';O.mkdir(exist_ok=True)
rows=[];pins={}
def sha(b):return hashlib.sha256(b).hexdigest()
def put(name,text,source,kind):
 b=text if isinstance(text,bytes)else text.encode();(O/name).write_bytes(b)
 rows.append({'path':name,'bytes':len(b),'sha256':sha(b),'source':source,'kind':kind})
def original(path,local):
 b=Path(local).read_bytes();pins[path]=sha(b);return b.decode()
def method(text,marker):
 assert text.count(marker)==1,marker
 start=text.index(marker);end=text.index('\n    }\n',start)+len('\n    }\n')
 return text[start:end]
modelpath='Source/LibraryBackend/LibraryBackendModels.swift'
model=original(modelpath,'root-history-reader-implementation/reference/'+modelpath)
put('ActualLibraryIdentityTypes.swift',model.split('/// A navigable unit within a work, supplied by the backend provider.')[0],modelpath,'unchanged original prefix')
mode=model[model.index('enum LibraryReaderTextMode:'):model.index('\nenum LibraryPresentationPolicy')]
put('ActualReaderTextMode.swift','import Foundation\n'+mode,modelpath,'unchanged original enum')
bridgepath='Source/Otzaria/Actions/Integration/ActionAppIdentityBridge.swift'
bridge=original(bridgepath,'root-history-current-24cd/source/'+bridgepath)
put('ActualActionAppIdentityBridge.swift',bridge.split('struct ActionAppCatalogSnapshot: Sendable {')[0],bridgepath,'unchanged original identity bridge')
anchorpath='Source/Otzaria/Reading/OtzariaLineAnchor.swift'
put('ActualOtzariaLineAnchor.swift',original(anchorpath,R/'baseline'/anchorpath),anchorpath,'unchanged full original value type')
componentpath='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeComponentBinding.swift'
component=original(componentpath,'rn-inner-semantics/baseline/'+componentpath)
start=component.index('@MainActor final class MaktabahNativeComponentSourceObservation {')
end=component.index('/// A passive view',start)
put('ActualBackendPublicationObservation.swift','import Foundation\nimport OtzariaUIRouting\nimport ChavrusaUIRoutingHost\n'+component[start:end],componentpath,'unchanged original class; Combine boundary declared')
bindingpath='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneBindings.swift'
oldbindings=original(bindingpath,R/'baseline'/bindingpath)
bindings=(R/'candidate'/bindingpath).read_text()
start=bindings.index('@MainActor final class MaktabahNativeInspectorBinding {')
end=bindings.index('// END NATIVE INSPECTOR OWNER BINDING',start)
inspector=bindings[start:end];assert inspector in oldbindings
put('ActualInspectorBinding.swift','import Foundation\nimport OtzariaUIRouting\n'+inspector,bindingpath,'unchanged original full Inspector class')
start=bindings.index('@MainActor final class MaktabahNativeNoteEditorOwner {')
end=bindings.index('/// Retain a proven original paragraph',start)
editor=bindings[start:end];assert editor in oldbindings
put('ActualNoteEditorOwner.swift','import Foundation\nimport OtzariaActionCore\n'+editor,bindingpath,'unchanged original full editor owner; UIKit/SwiftUI identity types declared')
start=bindings.index('@MainActor final class MaktabahNativeNoteDraftBinding {')
end=bindings.index('    #if DEBUG\n    func sourceDiagnostic()',start)
put('ActualNoteDraftPreparation.swift','import Foundation\nimport OtzariaActionCore\nimport OtzariaUIRouting\n'+bindings[start:end]+'}\n',bindingpath,'exact candidate fields, source selection, preparation, validation and apply; UIKit final geometry remains unexecuted')
readerpath='Source/Features/Reader/ViewModel/ReaderViewModel.swift'
reader=original(readerpath,'profile-group-continuation-assessment/source/'+readerpath)
getters=method(reader,'    var currentReaderTextMode: LibraryReaderTextMode {')+'\n'+method(reader,'    var selectedSegmentRange: NSRange? {')
sessionpath='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
original(sessionpath,'wave3-all-original-entry-wiring/candidate/'+sessionpath)
session=(R/'candidate'/sessionpath).read_text()
names=['    private func advanceReaderToolEditorPublication() {','    func attachNoteEditor(',
       '    func originalNoteEditorStateWillChange(', '    func detachNoteEditor(',
       '    func captureReaderToolSource(']
methods='\n'.join(method(session,name)for name in names)
boundary=(R/'controls/ReaderToolSourceBoundary.swift').read_text()
assert boundary.count('    // ACTUAL_READER_COMPUTED_SELECTION is replaced by byte-exact original getters.')==1
boundary=boundary.replace('    // ACTUAL_READER_COMPUTED_SELECTION is replaced by byte-exact original getters.',getters)
boundary=boundary.replace('    // ACTUAL_SESSION_SOURCE_METHODS is replaced by byte-exact candidate bodies.',methods)
put('ExplicitSourceBoundary.swift',boundary,[readerpath,sessionpath],'declared domain/renderer/window/Combine/SwiftUI shells, exact named production method bodies')
sourcepath='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeReaderToolSource.swift'
for label,path in [('initial',R/'controls/preserved-initial/MaktabahNativeReaderToolSource.swift'),('candidate',R/'candidate'/sourcepath)]:
 b=path.read_bytes();assert b.startswith(b'#if os(iOS)\n')and b.rstrip().endswith(b'#endif')
 enabled=b[len(b'#if os(iOS)\n'):].rstrip()[:-len(b'#endif')]
 put(label+'-ReaderToolSource.swift',enabled,sourcepath,'exact complete '+label+' source body; only outer platform guard enabled')
put('ReaderToolSourceControls.swift',(R/'controls/ReaderToolSourceControls.swift').read_bytes(),'controls/ReaderToolSourceControls.swift','control assertions; no product code')
(R/'controls/SOURCE_EXTRACT.json').write_text(json.dumps({'pins':pins,'files':rows,'sourceScope':'Actual named production bodies, original identities/selection/Inspector/editor owner, explicit renderer/window/SwiftUI/Combine/domain shells; no app/Core/UI execution'},indent=2)+'\n')
print(json.dumps({'files':len(rows),'originalPins':pins,'candidateSourceSHA256':sha((R/'candidate'/sourcepath).read_bytes()),'candidateSourceBytes':(R/'candidate'/sourcepath).stat().st_size},indent=2))
