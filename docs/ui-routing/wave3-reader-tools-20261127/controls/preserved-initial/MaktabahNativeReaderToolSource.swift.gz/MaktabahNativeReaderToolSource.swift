#if os(iOS)
import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

/// A single original scene/source captured before catalog awaits. This owns no
/// navigation grant or view. Its one handoff occurs at the existing Core sink,
/// immediately before the original Reader/draft reservation.
@MainActor final class MaktabahNativeReaderToolSource {
    let start: NativeReaderToolIntentService.Start
    let sceneID: UIStableID
    private let readSource: @MainActor () throws -> Void
    private let selection: MaktabahNativeReaderToolSelection?
    private enum Phase { case retained, handedOff, released }
    private var phase = Phase.retained

    init(start: NativeReaderToolIntentService.Start, sceneID: UIStableID,
         selection: MaktabahNativeReaderToolSelection?, validate: @escaping @MainActor () throws -> Void) throws {
        self.start = start; self.sceneID = sceneID; self.selection = selection; readSource = validate
        try self.validate()
    }
    var isHandedOff: Bool { if case .handedOff = phase { return true }; return false }
    func validate() throws {
        try Task.checkCancellation()
        guard case .retained = phase,
              DispatchTime.now().uptimeNanoseconds < start.invocation.deadlineUptimeNanoseconds else {
            throw UIRouteError(.staleState, "reader_tool_original_source_retired")
        }
        try readSource()
        try selection?.validate()
        try Task.checkCancellation()
        guard case .retained = phase,
              DispatchTime.now().uptimeNanoseconds < start.invocation.deadlineUptimeNanoseconds else {
            throw UIRouteError(.staleState, "reader_tool_original_source_retired")
        }
    }
    func handOff(_ invocation: ActionPortInvocation) throws {
        guard invocation.requestId == start.invocation.requestId,
              invocation.snapshot == start.invocation.snapshot,
              invocation.deadlineUptimeNanoseconds <= start.invocation.deadlineUptimeNanoseconds,
              DispatchTime.now().uptimeNanoseconds < invocation.deadlineUptimeNanoseconds else {
            throw UIRouteError(.staleState, "reader_tool_original_request_changed")
        }
        try validate()
        phase = .handedOff
    }
    /// The original note binding keeps this same selection fence during its
    /// own Core/presentation awaits. Presenting its unsaved editor is permitted;
    /// changing the underlying Reader/selection is permanently refused.
    func validateSelection() throws {
        guard case .handedOff = phase else {
            throw UIRouteError(.staleState, "reader_tool_original_source_retired")
        }
        try Task.checkCancellation()
        guard DispatchTime.now().uptimeNanoseconds < start.invocation.deadlineUptimeNanoseconds else {
            throw UIRouteError(.unavailable, "deadline_exceeded")
        }
        try selection?.validate()
    }
    func release() { phase = .released }
}

/// Source identity is obtained only from the original renderer-owned selection.
/// The one-way original Observation guard prevents A→B→A from renewing it.
/// No Annotation is constructed until the existing Core preparation callback.
@MainActor final class MaktabahNativeReaderToolSelection {
    private let manager: iOSNavigationManager
    private let owner: MaktabahNativeNoteEditorOwner
    private let reader: ReaderViewModel
    private let inspector: MaktabahNativeInspectorBinding
    private let observation: MaktabahNativeComponentSourceObservation
    private let range: NSRange
    private let source: String

    init(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner, locator: ActionTextRef) throws {
        let (reader, selected, range, text) = try MaktabahNativeNoteDraftBinding.sourceSelection(manager: manager, owner: owner)
        guard try ActionAppIdentityBridge.actionRef(selected) == locator else {
            throw UIRouteError(.staleState, "reader_tool_original_selection_changed")
        }
        self.manager = manager; self.owner = owner; self.reader = reader
        inspector = try MaktabahNativeInspectorBinding(manager: manager)
        self.range = range; source = text
        observation = MaktabahNativeComponentSourceObservation {
            _ = manager.openTabs; _ = manager.activeTabId; _ = manager.currentMode
            _ = manager.selectedBook; _ = manager.selectedContentId
            _ = reader.state; _ = reader.currentDestination; _ = reader.currentContentId
            _ = reader.currentReaderTextMode; _ = reader.contentText
            _ = reader.backendSection; _ = reader.backendRenderModel
            _ = reader.selectedSegmentLocator; _ = reader.selectedSegmentRange
            _ = reader.otzariaSelectedLineAnchor; _ = reader.readerState.selectedRange
        }
        try validate()
    }
    func validate() throws {
        try observation.validate()
        try inspector.validate()
        guard owner.reader === reader,
              MaktabahNativeInspectorBinding.currentReader(in: manager) === reader,
              reader.selectedSegmentRange == range,
              reader.contentText.utf8.elementsEqual(source.utf8) else {
            throw UIRouteError(.staleState, "reader_tool_original_selection_changed")
        }
        try observation.validate()
    }
}
#endif
