import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

@main struct SourceControls {
    @MainActor static func main() async {
        var cases: [[String: Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            do { try await body(); cases.append(["name": name, "pass": true]) }
            catch { cases.append(["name": name, "pass": false, "error": String(describing: error)]) }
        }
        await run("original source capture makes no Annotation or selection effect") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            try source.validate()
            try insist(f.reader.factoryCalls == 0 && f.annotation.value == nil && !source.isHandedOff, "read-only source capture")
            try sourceRefuses { try source.validateSelection() }
        }
        await run("background source can be retained but original visible draft gate remains") {
            let f = SourceFixture(), start = try await f.start(); f.reader.textVisible = false
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            try source.handOff(start.invocation)
            try sourceRefuses {
                _ = try MaktabahNativeNoteDraftBinding(manager: f.manager, owner: f.session.noteEditorOwner!,
                    request: .init(locator: start.locator), sceneID: f.session.sceneID, sourceFence: { try source.validateSelection() })
            }
            try insist(f.reader.factoryCalls == 0 && f.annotation.value == nil, "hidden Reader does not construct or present draft")
        }
        await run("one original factory and original unsaved editor after source handoff") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            try source.handOff(start.invocation)
            let bound = try MaktabahNativeNoteDraftBinding(manager: f.manager, owner: f.session.noteEditorOwner!,
                request: .init(locator: start.locator, proposedText: "טיוטה\noriginal"), sceneID: f.session.sceneID,
                sourceFence: { try source.validateSelection() })
            try insist(f.reader.factoryCalls == 1 && f.annotation.value == nil, "factory only, before original present")
            // Exact original will-change hook runs before its sheet State write.
            f.session.originalNoteEditorStateWillChange(id: f.editorID, reader: f.reader)
            try bound.apply(); try bound.validate()
            try insist(f.annotation.value?.id == nil && f.annotation.value?.note == "טיוטה\noriginal"
                && f.annotation.value?.backendLocator == f.locator, "original editor contains unsaved exact proposal")
            try sourceRefuses { try source.handOff(start.invocation) }
            try insist(f.reader.factoryCalls == 1, "no second factory or save")
        }
        await run("selected paragraph ABA remains retired through original draft validation") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            try source.handOff(start.invocation)
            let bound = try MaktabahNativeNoteDraftBinding(manager: f.manager, owner: f.session.noteEditorOwner!,
                request: .init(locator: start.locator), sceneID: f.session.sceneID, sourceFence: { try source.validateSelection() })
            let anchor = f.reader.otzariaSelectedLineAnchor
            f.reader.otzariaSelectedLineAnchor = nil; f.reader.otzariaSelectedLineAnchor = anchor
            try sourceRefuses { try bound.validate() }
            try insist(f.annotation.value == nil, "changed original selection did not present")
        }
        for changed in ["text", "destination", "range", "loading", "backend"] {
            await run("original selection source cannot revive after \(changed) ABA") {
                let f = SourceFixture(), start = try await f.start()
                let source = try f.session.captureReaderToolSource(start, validateOwner: {})
                switch changed {
                case "text": let old = f.reader.contentText; f.reader.contentText = "foreign"; f.reader.contentText = old
                case "destination": let old = f.reader.currentDestination; f.reader.currentDestination = nil; f.reader.currentDestination = old
                case "range": let old = f.reader.readerState.selectedRange; f.reader.readerState.selectedRange = nil; f.reader.readerState.selectedRange = old
                case "loading": f.reader.state = .loading; f.reader.state = .loaded
                default: BackendCoordinator.shared.objectWillChange.send()
                }
                try sourceRefuses { try source.handOff(start.invocation) }
                try insist(f.reader.factoryCalls == 0, "source retired before factory")
            }
        }
        await run("retained source is tied to original full record and owner Reader") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            f.session.noteEditorOwner!.reader = ReaderViewModel()
            try sourceRefuses { try source.handOff(start.invocation) }
        }
        await run("original editor equal setter publication invalidates captured metadata") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            f.session.originalNoteEditorStateWillChange(id: f.editorID, reader: f.reader)
            try sourceRefuses { try source.handOff(start.invocation) }
            try insist(f.annotation.value == nil && f.reader.factoryCalls == 0, "equal external write retires before factory")
        }
        await run("idle same-owner registration does not invent a publication") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            f.session.attachNoteEditor(id: f.editorID, reader: f.reader, annotation: .init(box: f.annotation), presentationID: { [f] in f.publication })
            try source.validate()
        }
        await run("detach and same-reader reattach cannot renew original editor source") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            f.session.detachNoteEditor(id: f.editorID)
            f.session.attachNoteEditor(id: f.editorID, reader: f.reader, annotation: .init(box: f.annotation), presentationID: { [f] in f.publication })
            try sourceRefuses { try source.handOff(start.invocation) }
        }
        await run("editor publication overflow retires retained and future source") {
            let f = SourceFixture(), start = try await f.start(); f.session.controlSeedEditorRevision(UInt64.max)
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            f.session.originalNoteEditorStateWillChange(id: f.editorID, reader: f.reader)
            try sourceRefuses { try source.validate() }
            try sourceRefuses { _ = try f.session.captureReaderToolSource(start, validateOwner: {}) }
        }
        await run("original source window boundary remains retained across awaits") {
            let f = SourceFixture(), start = try await f.start()
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            f.session.windowRevision += 1
            try sourceRefuses { try source.handOff(start.invocation) }
        }
        await run("reentrant source read cannot steal the current handoff") {
            let f = SourceFixture(), start = try await f.start(draft: false)
            var source: MaktabahNativeReaderToolSource?
            var enter = false, nested = false, callbackRunning = false
            source = try MaktabahNativeReaderToolSource(start: start, sceneID: f.session.sceneID, selection: nil) {
                if enter && !callbackRunning {
                    callbackRunning = true
                    do { try source!.handOff(start.invocation); nested = true } catch {}
                    callbackRunning = false
                }
            }
            enter = true
            try source!.handOff(start.invocation)
            try insist(!nested && source!.isHandedOff, "only the original outer source handoff succeeds")
        }
        await run("a failed source check permanently retires the same capsule") {
            let f = SourceFixture(), start = try await f.start(draft: false)
            var live = true
            let source = try MaktabahNativeReaderToolSource(start: start, sceneID: f.session.sceneID, selection: nil) {
                guard live else { throw ActionPortError.staleState }
            }
            live = false; try sourceRefuses { try source.validate() }; live = true
            try sourceRefuses { try source.handOff(start.invocation) }
        }
        await run("release inside original read cannot be overwritten") {
            let f = SourceFixture(), start = try await f.start(draft: false)
            var source: MaktabahNativeReaderToolSource?, retire = false
            source = try MaktabahNativeReaderToolSource(start: start, sceneID: f.session.sceneID, selection: nil) {
                if retire { source?.release() }
            }
            retire = true; try sourceRefuses { try source!.handOff(start.invocation) }
            retire = false; try sourceRefuses { try source!.validate() }
            try insist(!source!.isHandedOff, "release stays terminal")
        }
        await run("different Core request and renewed deadline cannot claim source") {
            let f = SourceFixture(), start = try await f.start(draft: false)
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            let wrongID = ActionPortInvocation(requestId: UUID(), snapshot: start.invocation.snapshot,
                deadlineUptimeNanoseconds: start.invocation.deadlineUptimeNanoseconds)
            let renewed = ActionPortInvocation(requestId: start.invocation.requestId, snapshot: start.invocation.snapshot,
                deadlineUptimeNanoseconds: start.invocation.deadlineUptimeNanoseconds + 1)
            try sourceRefuses { try source.handOff(wrongID) }; try sourceRefuses { try source.handOff(renewed) }
            try source.handOff(start.invocation)
        }
        await run("real task cancellation prevents original handoff") {
            let f = SourceFixture(), start = try await f.start(draft: false)
            let source = try f.session.captureReaderToolSource(start, validateOwner: {})
            let task = Task { @MainActor in try source.handOff(start.invocation) }; task.cancel()
            do { try await task.value; throw SourceCheckFailure(message: "cancelled handoff succeeded") }
            catch is CancellationError {}
            try insist(!source.isHandedOff, "no handoff after cancellation")
        }
        let failed = cases.filter { ($0["pass"] as? Bool) != true }.count
        let report: [String: Any] = ["scope": "Actual original Inspector/editor/selection and new tool source/Session bodies; original identity values and portable observation; explicit domain/renderer/window/SwiftUI/Combine boundaries", "cases": cases,
            "passed": cases.count - failed, "failed": failed, "nativeRuns": 0, "AppleSDK": "NOT_RUN", "CoreExecution": "NOT_RUN"]
        print(String(decoding: try! JSONSerialization.data(withJSONObject: report, options: [.sortedKeys]), as: UTF8.self))
        if failed != 0 { exit(1) }
    }
}
