import base64,gzip,hashlib,json,os,pathlib,signal,subprocess,time,traceback
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
PARENT=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-reader-tools-controls-20261127-attempt1')
OWN=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-reader-tools-source-controls-20261127-attempt1')
CORE=ROOT/'.git/search-continuation-integrated-controls-20261127/output'
HOST=PARENT/'output'
SWIFTC=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.run(['git','-C',str(ROOT),*a],capture_output=True,check=True).stdout
def free(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize
def size():return sum(p.stat().st_blocks*512 for p in OWN.rglob('*')if p.is_file())
def dump(name,value):(OWN/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
steps=[]
def run(name,argv,allowed=(0,),timeout=120):
 assert free(OWN)>2147483648 and free(ROOT)>1342177280 and size()<268435456
 step={'name':name,'argv':list(map(str,argv)),'startedEpoch':time.time()};steps.append(step)
 with (OWN/(name+'.stdout')).open('wb')as out,(OWN/(name+'.stderr')).open('wb')as err:
  p=subprocess.Popen(list(map(str,argv)),stdout=out,stderr=err,env={**os.environ,'TMPDIR':str(OWN/'tmp')},start_new_session=True)
  step['pid']=p.pid;step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21]
  until=time.time()+timeout
  while p.poll()is None:
   if time.time()>until or free(OWN)<2147483648 or free(ROOT)<1342177280 or size()>268435456:
    step['interrupted']='owned deadline/capacity guard';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
  step['exit']=p.returncode
 step['finishedEpoch']=time.time()
 step['logs']={s:{'bytes':(OWN/(name+s)).stat().st_size,'sha256':sha((OWN/(name+s)).read_bytes())}for s in ['.stdout','.stderr']}
 dump('STATUS.json',{'steps':steps})
 if p.returncode not in allowed:raise RuntimeError(name+' failed, exit '+str(p.returncode))
OWN.mkdir(exist_ok=False)
for name in ['inputs','output','tmp','module-cache']:(OWN/name).mkdir()
try:
 assert git('rev-parse','HEAD:Source').decode().strip()=='7afa76212dec72644917e6aaff3257ca56a14ccf'
 assert sha(SWIFTC.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 assert sha((PARENT/'RESULT.json').read_bytes())=='d4f8657dc9be063ba46fdfd1babd0c983378534e89cbcf8419cd86e49ba7e6ea'
 good=PARENT.with_name(PARENT.name.replace('attempt1','attempt2'))/'RESULT.json'
 assert sha(good.read_bytes())=='1d2ffbeea73ad3e59f3ef00474692c05d82594b65e5118d5e0f50ebdbbb7bcd1'
 prior=json.loads(good.read_text());assert prior['verdict']['passed']==30 and prior['verdict']['failed']==0
 raw=gzip.decompress(base64.b64decode(PAYLOAD_B64));assert sha(raw)==PAYLOAD_SHA
 payload=json.loads(raw);files=[]
 for row in payload['files']:
  b=base64.b64decode(row['base64']);assert len(b)==row['bytes']and sha(b)==row['sha256']
  p=OWN/'inputs'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  files.append({k:v for k,v in row.items()if k!='base64'})
 for path,pin in payload['originalPins'].items():assert sha(git('show','HEAD:'+path))==pin,path
 # Original Core sources and the retained successful module inputs are rejoined.
 previous_inputs=json.loads((PARENT/'INPUTS.json').read_text())
 for row in previous_inputs['coreSourcesRejoined']:assert sha(git('show','HEAD:'+row['path']))==row['sha256']
 for row in previous_inputs['files']:
  if row['kind']=='unchanged actual UIRouting source' or row['kind']=='unchanged actual Host dependency':
   assert sha(git('show','HEAD:'+row['path']))==row['sha256']
 service='Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/NativeReaderToolIntentService.swift'
 assert (OWN/'inputs/candidate'/service).read_bytes()==(PARENT/'inputs'/service).read_bytes()
 products=[]
 for directory,names in [(CORE,['OtzariaActionCore.swiftmodule','libOtzariaActionCore.so']),
                         (HOST,['OtzariaUIRouting.swiftmodule','libOtzariaUIRouting.so','ChavrusaUIRoutingHost.swiftmodule','libChavrusaUIRoutingHost.so'])]:
  for name in names:
   p=directory/name;b=p.read_bytes();products.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'use':'readonly successful actual portable product'})
 dump('INPUTS.json',{'sourceTree':git('rev-parse','HEAD:Source').decode().strip(),'files':files,
  'originalPins':payload['originalPins'],'sourceExtract':payload['sourceExtract'],'products':products,
  'boundaries':'Original source bodies with explicit domain/renderer/window/Combine/SwiftUI/annotation-factory shells; full app files syntax only'})
 common=[p for p in (OWN/'inputs/source-inputs').glob('*.swift')if not p.name.startswith(('initial-','candidate-'))]
 flags=[SWIFTC,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',OWN/'module-cache',
  '-I',CORE,'-L',CORE,'-lOtzariaActionCore','-I',HOST,'-L',HOST,'-lOtzariaUIRouting','-lChavrusaUIRoutingHost',
  '-Xlinker','-rpath','-Xlinker',CORE,'-Xlinker','-rpath','-Xlinker',HOST]
 for version in ['initial','candidate']:
  run('compile-'+version,flags+common+[OWN/'inputs/source-inputs'/(version+'-ReaderToolSource.swift'),'-o',OWN/'output'/version])
  run('run-'+version,[OWN/'output'/version],allowed=(0,1)if version=='initial'else(0,))
 initial=json.loads((OWN/'run-initial.stdout').read_text());candidate=json.loads((OWN/'run-candidate.stdout').read_text())
 assert candidate['failed']==0
 expected=['reentrant source read cannot steal the current handoff','a failed source check permanently retires the same capsule']
 before={c['name']:c['pass']for c in initial['cases']};assert all(before[n]is False for n in expected)
 parse_files=[OWN/'inputs'/r['path']for r in files if r['path'].startswith('candidate/')and r['path'].endswith('.swift')]
 for debug in [False,True]:
  for i,p in enumerate(parse_files):
   run('parse-'+('debug'if debug else'release')+'-'+str(i),[SWIFTC,'-frontend','-parse','-target','arm64-apple-ios27.0-simulator']+(['-D','DEBUG']if debug else[])+[p],timeout=30)
 dump('RESULT.json',{'status':'PASSED_ACTUAL_SOURCE_WITH_DECLARED_BOUNDARIES_AND_APP_SYNTAX_ONLY','steps':steps,
  'initial':initial,'candidate':candidate,'expectedCounterexamples':expected,'nativeRuns':0,'AppleSDK':'NOT_RUN','CoreExecution':'NOT_RUN',
  'ownedAllocatedBytes':size(),'rootFree':free(ROOT),'dataFree':free(OWN)})
except BaseException as e:
 dump('RESULT.json',{'status':'FAILED','steps':steps,'error':repr(e),'traceback':traceback.format_exc(),'nativeRuns':0,'AppleSDK':'NOT_RUN','ownedAllocatedBytes':size()});raise
finally:
 p=OWN/'RESULT.json'
 if p.exists():
  r=json.loads(p.read_text());print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'status':r.get('status'),
   'steps':[{'name':s['name'],'exit':s.get('exit')}for s in steps],'candidate':{k:r.get('candidate',{}).get(k)for k in ['passed','failed']},
   'initial':{k:r.get('initial',{}).get(k)for k in ['passed','failed']}}))
