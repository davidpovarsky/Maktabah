import Foundation
import Observation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

// Explicit platform/domain boundary: no UIKit, SwiftUI, SQL, real renderer,
// system scene or annotation persistence runs here. Production source classes,
// selection validator, inspector, editor owner and source methods are extracted
// byte-exactly and compiled as separate inputs, along with original value types.
final class AnyCancellable: @unchecked Sendable {
    private let cancel: @Sendable () -> Void
    init(_ cancel: @escaping @Sendable () -> Void) { self.cancel = cancel }
    deinit { cancel() }
}
final class FixturePublisher: @unchecked Sendable {
    private let lock = NSLock()
    private var callbacks: [UUID: @Sendable (Int) -> Void] = [:]
    func sink(_ callback: @escaping @Sendable (Int) -> Void) -> AnyCancellable {
        let id = UUID(); lock.lock(); callbacks[id] = callback; lock.unlock()
        return AnyCancellable { [weak self] in
            guard let self else { return }; self.lock.lock(); self.callbacks.removeValue(forKey: id); self.lock.unlock()
        }
    }
    func send() {
        lock.lock(); let current = Array(callbacks.values); lock.unlock()
        current.forEach { $0(0) }
    }
}
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    let objectWillChange = FixturePublisher()
    var activeBackendID = BackendID.otzaria
    var generation: UInt64 = 17
    var isTransitioning = false
}
@MainActor final class FixtureBox<Value> {
    var value: Value
    init(_ value: Value) { self.value = value }
}
@MainActor struct Binding<Value> {
    let box: FixtureBox<Value>
    var wrappedValue: Value { get { box.value } nonmutating set { box.value = newValue } }
}
@MainActor final class UITextView {}
struct UIColor { init?(named: String) {} ; static let systemYellow = UIColor(named: "fixture")! }
struct Annotation: Equatable {
    var id: Int?
    var context: String
    var backendLocator: TextLocator?
    var note: String?
}
enum FixtureAnnotationMode { case highlight }
final class BooksData {
    let id: Int
    let backendLocator: TextLocator?
    init(id: Int, backendLocator: TextLocator) { self.id = id; self.backendLocator = backendLocator }
}
struct FixtureSection: Equatable { var locator: TextLocator }
struct FixtureSegment: Equatable { let visualRange: NSRange }
struct FixtureRenderModel: Equatable {
    var mode: LibraryReaderTextMode
    var segments: [TextLocator: NSRange]
    func renderedSegment(for locator: TextLocator?) -> FixtureSegment? {
        guard let locator, let value = segments[locator] else { return nil }
        return .init(visualRange: value)
    }
}
@MainActor @Observable final class FixtureReaderState { var selectedRange: NSRange? }
@MainActor @Observable final class TextViewState {
    static let shared = TextViewState()
    var readerTextMode = LibraryReaderTextMode.source
}
@MainActor @Observable final class ReaderViewModel {
    enum State { case loading, loaded }
    var currentBook: BooksData?
    var state = State.loaded
    var currentDestination: LibraryReaderDestination?
    var currentContentId = 36
    var contentText = "אבגדה Original selected source"
    var readerState = FixtureReaderState()
    var backendSection: FixtureSection?
    var backendRenderModel: FixtureRenderModel?
    var selectedSegmentLocator: TextLocator?
    var otzariaSelectedLineAnchor: OtzariaLineAnchor?
    var readerInspectorVisible = false
    @ObservationIgnored var textVisible = true
    @ObservationIgnored var factoryCalls = 0
    var isNativeReaderTextVisible: ((String, NSRange?) -> Bool)?
    // ACTUAL_READER_COMPUTED_SELECTION is replaced by byte-exact original getters.
    func makeAnnotationDraft(in range: NSRange, mode: FixtureAnnotationMode, sourceText: String, color: UIColor) throws -> Annotation {
        factoryCalls += 1
        let part = try ActionNoteDraftSelection.validate(.init(locator: ActionAppIdentityBridge.actionRef(selectedSegmentLocator!)),
            observedLocator: ActionAppIdentityBridge.actionRef(selectedSegmentLocator!), sourceText: sourceText, originalRange: range)
        return .init(id: nil, context: part, backendLocator: nil, note: nil)
    }
}
@MainActor @Observable final class iOSNavigationManager {
    enum Mode { case viewer, search }
    struct Tab { let id: UUID; let book: BooksData; let viewModel: ReaderViewModel }
    var currentMode = Mode.viewer
    var openTabs: [Tab] = []
    var activeTabId: UUID?
    var selectedBook: BooksData?
    var selectedContentId: Int? = 36
}
@MainActor final class FixtureRetirable {
    var count = 0
    func revoke() { count += 1 }
    func invalidate() { count += 1 }
    func retire() { count += 1 }
    func originalForeignStateWillChange() { count += 1 }
}
@MainActor final class MaktabahNativeSceneSession {
    struct Bindings { let manager: iOSNavigationManager }
    let bindings: Bindings
    let sceneID = UIStableID(rawValue: "original-window")!
    var mounted = true
    var noteEditorOwner: MaktabahNativeNoteEditorOwner?
    var noteDraftBinding: MaktabahNativeNoteDraftBinding?
    private var readerToolEditorPublicationRevision: UInt64? = 0
    let presentation = FixtureRetirable()
    var readerTabBinding: FixtureRetirable?, workspaceSelectionBinding: FixtureRetirable?
    var searchContinuationOwner: FixtureRetirable?, publicSearchContinuationCatalog: FixtureRetirable?
    var sefariaRootSources: [UUID: FixtureRetirable] = [:]
    var completedSefariaRootSource: FixtureRetirable?
    var historyRecordBinding: FixtureRetirable?, savedResultsBinding: FixtureRetirable?
    var retainedSefariaSurface = false
    var windowRevision: UInt64 = 0
    var nativeStateChanges = 0
    init(manager: iOSNavigationManager) { bindings = .init(manager: manager) }
    func nativeStateChanged() throws { nativeStateChanges += 1 }
    // Original History window capture is an explicit separately-qualified
    // boundary here, not a fabricated UIKit/window implementation.
    func captureHistoryReaderWindow() throws -> @MainActor () throws -> Void {
        let revision = windowRevision
        return { [unowned self] in
            guard self.mounted, self.windowRevision == revision else { throw ActionPortError.staleState }
        }
    }
    func controlSeedEditorRevision(_ value: UInt64?) { readerToolEditorPublicationRevision = value }
    // ACTUAL_SESSION_SOURCE_METHODS is replaced by byte-exact candidate bodies.
}

struct SourceCheckFailure: Error { let message: String }
struct CapturedOriginalStart: Error {}
@MainActor func insist(_ condition: @autoclosure () -> Bool, _ message: String) throws {
    if !condition() { throw SourceCheckFailure(message: message) }
}
@MainActor func sourceRefuses(_ body: () throws -> Void) throws {
    do { try body() }
    catch is SourceCheckFailure { throw SourceCheckFailure(message: "failed assertion inside refusal") }
    catch { return }
    throw SourceCheckFailure(message: "expected refusal")
}
@MainActor final class SourceFixture {
    let manager = iOSNavigationManager()
    let reader = ReaderViewModel()
    let annotation = FixtureBox<Annotation?>(nil)
    let editorID = UUID()
    let publication = UUID()
    let locator = TextLocator(backend: .otzaria, workKey: "book:42", position: .legacyLine(37))
    let session: MaktabahNativeSceneSession
    init() {
        BackendCoordinator.shared.objectWillChange.send()
        BackendCoordinator.shared.activeBackendID = .otzaria; BackendCoordinator.shared.generation = 17
        BackendCoordinator.shared.isTransitioning = false
        let section = TextLocator(backend: .otzaria, workKey: "book:42", position: .legacyLine(36))
        let book = BooksData(id: 42, backendLocator: section), id = UUID()
        reader.currentBook = book; reader.currentDestination = .init(sectionLocator: section, focusLocator: locator)
        reader.backendSection = .init(locator: section); reader.selectedSegmentLocator = locator
        reader.otzariaSelectedLineAnchor = .init(id: 37, bookId: 42, lineIndex: 37, heRef: nil,
            text: "אבגד", range: NSRange(location: 0, length: 4))
        reader.readerState.selectedRange = NSRange(location: 0, length: 4)
        reader.isNativeReaderTextVisible = { [weak reader] _, _ in reader?.textVisible == true }
        manager.openTabs = [.init(id: id, book: book, viewModel: reader)]
        manager.activeTabId = id; manager.selectedBook = book
        session = .init(manager: manager)
        session.attachNoteEditor(id: editorID, reader: reader, annotation: .init(box: annotation), presentationID: { [publication] in publication })
    }
    func start(draft: Bool = true) async throws -> NativeReaderToolIntentService.Start {
        let work = try NativeReaderIntentService.Work(reference: .init(backend: .otzaria, workKey: "book:42"), title: "fixture").id
        let place = try NativeReaderIntentService.Location(reference: ActionAppIdentityBridge.actionRef(locator), title: "fixture").id
        var captured: NativeReaderToolIntentService.Start?
        let service = NativeReaderToolIntentService(snapshot: { .init(backend: .otzaria, generation: 17) }, execute: { _ in
            throw SourceCheckFailure(message: "source fixture must stop before metadata")
        }, retain: { value in captured = value; throw CapturedOriginalStart() })
        do {
            if draft { _ = try await service.prepareDraft(workIdentifier: work, locationIdentifier: place,
                windowIdentifier: "fixture-window", proposedText: "proposed") }
            else { _ = try await service.openCommentary(workIdentifier: work, locationIdentifier: place,
                commentaryWorkIdentifier: work, windowIdentifier: "fixture-window") }
        } catch is CapturedOriginalStart {}
        guard let captured else { throw SourceCheckFailure(message: "original service start missing") }
        return captured
    }
}
