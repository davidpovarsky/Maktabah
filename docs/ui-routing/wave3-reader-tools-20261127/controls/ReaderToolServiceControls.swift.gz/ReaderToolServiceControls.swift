import Foundation
import OtzariaActionCore
import OtzariaUIRouting
@testable import ChavrusaUIRoutingHost

// Execute the complete production services and original Core/UIRouting values.
// Metadata responses, native effects, the app-owned source witness and time are
// explicit boundaries. This is neither an Apple SDK nor a native UI test.
struct CheckFailure: Error { let message: String }
@MainActor func require(_ value: @autoclosure () -> Bool, _ message: String) throws {
    if !value() { throw CheckFailure(message: message) }
}
@MainActor func refuses(_ operation: () async throws -> Void) async throws {
    do { try await operation() }
    catch is CheckFailure { throw CheckFailure(message: "assertion inside refusal") }
    catch { return }
    throw CheckFailure(message: "expected refusal")
}

@MainActor final class Fixture {
    typealias Service = NativeReaderToolIntentService
    let work: ActionWorkRef
    let commentary: ActionWorkRef
    let location: ActionTextRef
    var snapshot: ActionBackendSnapshot
    var ticks: UInt64 = 100
    var mode = "ok"
    var sourceLive = true
    var retained = 0, released = 0, executions = 0, checks = 0
    var metadataRequests: [ActionRequest] = []
    var afterMetadata: (() -> Void)?
    var afterEffect: (() -> Void)?
    var lease: Service.RetainedWindow?
    var actual: Service.Execution?
    var last: Service.Request?
    var reentryRefused = false

    init(backend: ActionBackendID = .otzaria) {
        snapshot = .init(backend: backend, generation: 17)
        work = .init(backend: backend, workKey: backend == .otzaria ? "book:42" : "Genesis")
        commentary = .init(backend: backend, workKey: backend == .otzaria ? "book:43" : "Rashi on Genesis")
        location = .init(backend: backend, workKey: work.workKey,
            position: backend == .otzaria ? .legacyLine(37) : .canonicalRef("Genesis 1:3"))
    }
    func identifiers() throws -> (String, String, String) {
        (try NativeReaderIntentService.Work(reference: work, title: "בראשית").id,
         try NativeReaderIntentService.Location(reference: location, title: "Original selected passage").id,
         try NativeReaderIntentService.Work(reference: commentary, title: "Original commentary").id)
    }
    func metadata(_ request: ActionRequest) async throws -> NativeReaderIntentService.CoreObservation {
        metadataRequests.append(request)
        let original = snapshot
        var data: ActionObject = [:]
        var status: ActionStatus = .completed
        var error: ActionFailure?
        if request.action == "catalog.resolveWork" {
            let ref = try request.arguments["workRef"]!.decoded(as: ActionWorkRef.self)
            data["workRef"] = try .encoded(mode == "replaced-commentary"
                ? ActionWorkRef(backend: ref.backend, workKey: "foreign-commentary") : ref)
            if mode == "missing-commentary" { status = .failed; error = .init(code: "not_found", message: "fixture") }
        } else if request.action == "catalog.resolveReference" {
            let ref = mode == "replaced-location"
                ? ActionTextRef(backend: location.backend, workKey: location.workKey, position: .legacyLine(99)) : location
            data["locator"] = try .encoded(ref)
        } else { throw CheckFailure(message: "noncatalog metadata action") }
        if mode == "advancing-clock" { ticks += 1_000_000_000 }
        afterMetadata?()
        return .init(result: .init(request: request, status: status, data: data, error: error,
            backend: original.backend, backendGeneration: original.generation), snapshot: original)
    }
    func service() -> Service {
        Service(snapshot: { self.snapshot }, execute: { try await self.metadata($0) }, retain: { start in
            self.retained += 1
            let owner = Service.RetainedWindow(sceneID: UIStableID(rawValue: "original-window")!, validate: {
                self.checks += 1
                guard self.sourceLive else { throw UIRouteError(.staleState, "original_source_retired") }
            }, execute: { request in
                self.executions += 1; self.last = request
                let value = try self.execution(request); self.actual = value
                if self.mode == "reentrant-execution" {
                    do { _ = try await self.lease!.perform(request) }
                    catch { self.reentryRefused = true }
                }
                if self.mode == "released-during-effect" { self.lease!.release() }
                self.afterEffect?()
                if self.mode == "throw-after-effect" {
                    throw Service.Failure(execution: value, underlying: UIRouteError(.staleState, "actual_late_refusal"))
                }
                return value
            }, release: { self.released += 1 })
            self.lease = owner
            return owner
        }, now: { self.ticks })
    }
    func execution(_ input: Service.Request) throws -> Service.Execution {
        let start = input.start, invocation = start.invocation
        let isDraft: Bool
        switch start.operation { case .commentary: isDraft = false; case .noteDraft: isDraft = true }
        let section = ActionTextRef(backend: commentary.backend, workKey: commentary.workKey,
            position: commentary.backend == .otzaria ? .legacyLine(87) : .canonicalRef("Rashi on Genesis 1:3:1"))
        let focus = mode == "foreign-focus"
            ? ActionTextRef(backend: section.backend, workKey: "foreign-work", position: section.position) : section
        let destination = ActionReaderDestination(sectionLocator: section, focusLocator: focus, presentationMode: .newTab)
        let scene = UIStableID(rawValue: "original-window")!
        let coreReceipt = ActionUIReceipt(requestId: invocation.requestId, snapshot: invocation.snapshot,
            sceneID: scene.rawValue, destination: destination)
        let route = RouteSpec(requestId: invocation.requestId,
            destination: UIDestinationID(rawValue: isDraft ? "native.reader.noteDraft" : "native.reader")!,
            backend: invocation.snapshot.backend, content: isDraft ? nil : destination,
            presentation: .init(kind: isDraft ? .sheet : .newTab),
            scene: .init(kind: .specific, sceneID: scene, expectedRevision: 10),
            expectedBackendSnapshot: invocation.snapshot)
        let receipt = UISceneReceipt(requestId: invocation.requestId, route: route, backendSnapshot: invocation.snapshot,
            sceneID: mode == "foreign-scene" ? UIStableID(rawValue: "other-window")! : scene,
            basedOnSceneRevision: 10, appliedSceneRevision: 11, coreReceipt: isDraft ? nil : coreReceipt)
        var args = try input.arguments()
        if mode == "changed-proposal" { args["proposedText"] = .string("foreign proposal") }
        let request = ActionRequest(requestId: invocation.requestId, action: start.operation.action, arguments: args,
            expectedBackend: invocation.snapshot.backend, expectedGeneration: invocation.snapshot.generation,
            requestedPresentation: .foreground, deadlineMs: Int((invocation.deadlineUptimeNanoseconds - ticks) / 1_000_000))
        let data: ActionObject = isDraft
            ? ["locator": try .encoded(start.locator), "saved": .bool(mode == "saved-note")]
            : ["destination": try .encoded(destination), "locator": try .encoded(focus)]
        let result = ActionResult(request: request, status: mode == "core-refusal" ? .staleState : .completed, data: data,
            error: mode == "core-refusal" ? .init(code: "original_core_refusal", message: "fixture") : nil,
            backend: invocation.snapshot.backend, backendGeneration: invocation.snapshot.generation,
            effects: ["explicit-native-boundary"])
        return .init(request: request, result: result, nativeReceipt: mode == "missing-native" ? nil : receipt)
    }
    func open(_ service: Service, draft: Bool = false, proposal: String? = "טיוטה — original proposal") async throws -> Service.Execution {
        let (book, passage, commentary) = try identifiers()
        if draft { return try await service.prepareDraft(workIdentifier: book, locationIdentifier: passage,
            windowIdentifier: "explicit-window-entity", proposedText: proposal) }
        return try await service.openCommentary(workIdentifier: book, locationIdentifier: passage,
            commentaryWorkIdentifier: commentary, windowIdentifier: "explicit-window-entity")
    }
}

@main struct Controls {
    @MainActor static func main() async {
        var cases: [[String: Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            do { try await body(); cases.append(["name": name, "pass": true]) }
            catch { cases.append(["name": name, "pass": false, "error": String(describing: error)]) }
        }
        for backend in ActionBackendID.allCases {
            for draft in [false, true] {
                await run("explicit \(backend.rawValue) \(draft ? "draft" : "commentary") over original entity codec and resolution") {
                    let f = Fixture(backend: backend), service = f.service(), value = try await f.open(service, draft: draft)
                    try require(value.result == f.actual?.result && value.nativeReceipt == f.actual?.nativeReceipt, "actual original return retained")
                    try require(f.retained == 1 && f.executions == 1 && f.released == 1, "one source and one original effect")
                    try require(f.metadataRequests.map(\.action) == (draft ? ["catalog.resolveReference"] : ["catalog.resolveWork", "catalog.resolveReference"]), "only original catalog resolution before finite action")
                    try require(f.last?.start.invocation.deadlineUptimeNanoseconds == 5_000_000_100, "one nonrenewed deadline")
                }
            }
        }
        for proposal in [nil, "", " ", "הצעה 🕎\noriginal"] as [String?] {
            await run("original optional draft proposal preserved: \(String(describing: proposal))") {
                let f = Fixture(), value = try await f.open(f.service(), draft: true, proposal: proposal)
                try require(value.request.arguments["proposedText"] == proposal.map(ActionJSON.string), "nil/blank/proposal not normalized or saved")
            }
        }
        for mode in ["missing-commentary", "replaced-commentary", "replaced-location"] {
            await run("cached source metadata must re-resolve exactly: \(mode)") {
                let f = Fixture(); f.mode = mode
                try await refuses { _ = try await f.open(f.service()) }
                try require(f.executions == 0 && f.released == 1, "no native call after stale catalog")
            }
        }
        await run("source retained before first catalog call and revoked during metadata") {
            let f = Fixture(); f.afterMetadata = { f.sourceLive = false }
            try await refuses { _ = try await f.open(f.service()) }
            try require(f.retained == 1 && f.metadataRequests.count == 1 && f.executions == 0 && f.released == 1, "original captured source cannot be replaced after await")
        }
        await run("generation changes during metadata refuse before native") {
            let f = Fixture(); f.afterMetadata = { f.snapshot = .init(backend: .otzaria, generation: 18) }
            try await refuses { _ = try await f.open(f.service()) }
            try require(f.executions == 0 && f.released == 1, "stale metadata refused")
        }
        await run("original metadata and native effects share decreasing remaining budget") {
            let f = Fixture(); f.mode = "advancing-clock"
            let value = try await f.open(f.service())
            try require(f.metadataRequests.map(\.deadlineMs) == [5000, 4000] && value.request.deadlineMs == 3000, "no deadline renewal")
        }
        for mode in ["foreign-focus", "foreign-scene", "changed-proposal", "saved-note", "missing-native", "core-refusal", "throw-after-effect", "released-during-effect"] {
            await run("partial or unqualified actual execution retained: \(mode)") {
                let f = Fixture(); f.mode = mode
                do { _ = try await f.open(f.service(), draft: mode == "changed-proposal" || mode == "saved-note"); throw CheckFailure(message: "unexpected success") }
                catch let failure as Fixture.Service.Failure {
                    try require(failure.execution.result == f.actual?.result && failure.execution.nativeReceipt == f.actual?.nativeReceipt,
                        "observed effect not discarded or promoted to success")
                    try require(f.executions == 1 && f.released == 1, "only one original effect/cleanup")
                }
            }
        }
        await run("source lease rejects nested execution and remains consumed after return") {
            let f = Fixture(); f.mode = "reentrant-execution"
            _ = try await f.open(f.service())
            try require(f.reentryRefused && f.executions == 1, "no reentrant native invocation")
            try await refuses { _ = try await f.lease!.perform(f.last!) }
            try require(f.executions == 1 && f.released == 1, "one-way consumed source")
        }
        for late in ["deadline", "generation"] {
            await run("late \(late) refuses with original effect preserved") {
                let f = Fixture()
                f.afterEffect = {
                    if late == "deadline" { f.ticks = 5_000_000_100 }
                    else { f.snapshot = .init(backend: .otzaria, generation: 18) }
                }
                do { _ = try await f.open(f.service()); throw CheckFailure(message: "late success") }
                catch let failure as Fixture.Service.Failure {
                    try require(f.executions == 1 && failure.execution.result == f.actual?.result, "original partial return preserved")
                }
            }
        }
        await run("malformed identity backend mismatch proposal bound and overflow precede source capture") {
            let f = Fixture(), service = f.service(), (book, passage, commentary) = try f.identifiers()
            try await refuses { _ = try await service.openCommentary(workIdentifier: book + "=", locationIdentifier: passage, commentaryWorkIdentifier: commentary, windowIdentifier: "window") }
            let other = try NativeReaderIntentService.Work(reference: .init(backend: .sefaria, workKey: "foreign"), title: "foreign").id
            try await refuses { _ = try await service.openCommentary(workIdentifier: book, locationIdentifier: passage, commentaryWorkIdentifier: other, windowIdentifier: "window") }
            try await refuses { _ = try await f.open(service, draft: true, proposal: String(repeating: "א", count: 10_001)) }
            f.ticks = UInt64.max
            try await refuses { _ = try await f.open(service) }
            try require(f.retained == 0 && f.metadataRequests.isEmpty && f.executions == 0, "invalid input has no app source/effect")
        }
        await run("real task cancellation precedes source capture") {
            let f = Fixture(), service = f.service()
            let task = Task { @MainActor in try await f.open(service) }; task.cancel()
            try await refuses { _ = try await task.value }
            try require(f.retained == 0 && f.metadataRequests.isEmpty && f.executions == 0, "cancelled before discovery")
        }
        await run("original combined intent still rejects incomplete commentary draft") {
            let f = Fixture(), (book, passage, commentary) = try f.identifiers()
            let original = NativeReaderIntentService(execute: { try await f.metadata($0) }, navigate: { _ in
                throw CheckFailure(message: "original combined contract must refuse before navigation")
            })
            try await refuses { _ = try await original.open(workIdentifier: book, locationIdentifier: passage,
                windowIdentifier: "window", newTab: true, commentaryWorkIdentifier: commentary) }
            try await refuses { _ = try await original.open(workIdentifier: book, locationIdentifier: passage,
                windowIdentifier: "window", newTab: true, proposedText: "unpaired") }
            try require(f.metadataRequests.isEmpty, "original combined validator unchanged")
        }
        let failed = cases.filter { ($0["pass"] as? Bool) != true }.count
        let report: [String: Any] = ["scope": "Actual new ReaderTool and unchanged original Reader services; real Core/UIRouting value contracts; explicit app source, metadata, clock and native effect boundaries", "cases": cases,
            "passed": cases.count - failed, "failed": failed, "nativeRuns": 0, "AppleSDK": "NOT_RUN", "CoreExecution": "NOT_RUN"]
        print(String(decoding: try! JSONSerialization.data(withJSONObject: report, options: [.sortedKeys]), as: UTF8.self))
        if failed != 0 { exit(1) }
    }
}
