import base64,gzip,hashlib,json,os,pathlib,signal,subprocess,time,traceback
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
OWN=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-reader-tools-utf8-controls-20261127-attempt2')
CORE=ROOT/'.git/search-continuation-integrated-controls-20261127/output'
GROUP=pathlib.Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-profile-group-controls-20261127/group-parent-portable-attempt-2')
UI=GROUP/'output'
SWIFTC=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.run(['git','-C',str(ROOT),*a],capture_output=True,check=True).stdout
def free(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize
def size():return sum(p.stat().st_blocks*512 for p in OWN.rglob('*')if p.is_file())
def dump(name,value):(OWN/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
steps=[]
def run(name,argv,allowed=(0,),timeout=120):
 assert free(OWN)>2147483648 and free(ROOT)>1342177280 and size()<134217728
 step={'name':name,'argv':list(map(str,argv)),'startedEpoch':time.time()};steps.append(step)
 with (OWN/(name+'.stdout')).open('wb')as out,(OWN/(name+'.stderr')).open('wb')as err:
  p=subprocess.Popen(list(map(str,argv)),stdout=out,stderr=err,env={**os.environ,'TMPDIR':str(OWN/'tmp')},start_new_session=True)
  step['pid']=p.pid;step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21]
  until=time.time()+timeout
  while p.poll()is None:
   if time.time()>until or free(OWN)<2147483648 or free(ROOT)<1342177280 or size()>134217728:
    step['interrupted']='owned deadline/capacity guard';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
  step['exit']=p.returncode
 step['finishedEpoch']=time.time()
 step['logs']={s:{'bytes':(OWN/(name+s)).stat().st_size,'sha256':sha((OWN/(name+s)).read_bytes())}for s in ['.stdout','.stderr']}
 dump('STATUS.json',{'steps':steps})
 if p.returncode not in allowed:raise RuntimeError(name+' failed, exit '+str(p.returncode))
OWN.mkdir(exist_ok=False)
for name in ['inputs','output','tmp','module-cache']:(OWN/name).mkdir()
try:
 assert git('rev-parse','HEAD:Source').decode().strip()=='498e7336fc23589995da698d3f72a92e766e29eb'
 assert sha(SWIFTC.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 assert sha((GROUP/'RESULT.json').read_bytes())=='cd2f66ece6dde9b7254d5fcc234953183ee4143a82b0fc7f8192d81ea9dfc0b3'
 prior=json.loads((GROUP/'RESULT.json').read_text())
 rejoined=[]
 for row in prior['packageInputs']:
  if row['path'].startswith('Source/Otzaria/UIRouting/'):
   assert sha(git('show','HEAD:'+row['path']))==row['sha256'];rejoined.append(row)
 for row in prior['coreSourceJoins']:assert sha(git('show','HEAD:'+row['path']))==row['sha256']
 products=[]
 for path,digest in [(CORE/'OtzariaActionCore.swiftmodule','c45482e0c872e1378e9048b9f1b9fef473b0a9b8973ef0e17ee9e2df22a24103'),
  (CORE/'libOtzariaActionCore.so','f7a7d43d27b341f53a32b5205306c6bcec69c7a05b1f381d6e2239d5803d049a'),
  (UI/'OtzariaUIRouting.swiftmodule','c1d4819746c789c960acbed15bfbc14c960743559f466ff562228629a748d020'),
  (UI/'libOtzariaUIRouting.so','0cccbb6281efdec9961c74d6b53f7725bd310e46ba223d9d197ea7617ad70037')]:
  b=path.read_bytes();assert sha(b)==digest;products.append({'path':str(path),'bytes':len(b),'sha256':digest})
 raw=gzip.decompress(base64.b64decode(PAYLOAD_B64));assert sha(raw)==PAYLOAD_SHA
 payload=json.loads(raw);files=[]
 for row in payload['files']:
  b=base64.b64decode(row['base64']);assert len(b)==row['bytes']and sha(b)==row['sha256']
  p=OWN/'inputs'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  files.append({k:v for k,v in row.items()if k!='base64'})
 dump('INPUTS.json',{'files':files,'sourceExtract':payload['sourceExtract'],'currentUIRoutingSourcesRejoined':rejoined,
  'coreSourcesRejoined':prior['coreSourceJoins'],'products':products,
  'UIReuseScope':'Actual UI compile successful in Group attempt1, exact products copied in attempt2; its later fixture failure preserved.25/25 executed in boundaries-attempt1; no rerun.',
  'boundaries':'Actual complete service, four original Host dependencies and Core byte-exact draft text equality; explicit metadata/native/time boundaries.'})
 hostRoot='Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/'
 originalInputs=json.loads(pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-reader-tools-controls-20261127-attempt1/INPUTS.json').read_text())
 host=[]
 for name in ['NativeIntentService.swift','NativeIntentOutcome.swift','NativeComponentSourceObservation.swift','NativeReaderIntentService.swift']:
  path=hostRoot+name;row=next(x for x in originalInputs['files']if x['path']==path)
  b=git('show','HEAD:'+path);assert sha(b)==row['sha256']
  p=OWN/'inputs'/name;p.write_bytes(b);host.append(p)
 flags=[SWIFTC,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',OWN/'module-cache',
  '-I',CORE,'-L',CORE,'-lOtzariaActionCore','-I',UI,'-L',UI,'-lOtzariaUIRouting',
  '-Xlinker','-rpath','-Xlinker',CORE,'-Xlinker','-rpath','-Xlinker',UI]
 for label in ['initial','candidate']:
  output=OWN/'output'/label;output.mkdir()
  if label=='initial':
   previous=OWN.with_name(OWN.name.replace('attempt2','attempt1'))
   assert sha((previous/'RESULT.json').read_bytes())=='f91b6d843aa9b08601c6c7a3d46b80eb29305bd920dd5349635055af2348d972'
   oldResult=json.loads((previous/'RESULT.json').read_text());assert oldResult['steps'][0]['exit']==0
   for p in host:assert p.read_bytes()==(previous/'inputs'/p.name).read_bytes()
   assert (OWN/'inputs/initial-NativeReaderToolIntentService.swift').read_bytes()==(previous/'inputs/initial-NativeReaderToolIntentService.swift').read_bytes()
   module=previous/'output/initial'
   dump('INITIAL_PRODUCT_REUSE.json',{'previousResultSHA256':sha((previous/'RESULT.json').read_bytes()),
    'products':[{'path':str(module/n),'sha256':sha((module/n).read_bytes()),'bytes':(module/n).stat().st_size}for n in ['ChavrusaUIRoutingHost.swiftmodule','libChavrusaUIRoutingHost.so']],
    'reason':'Successful actual initial service compile reused; first fixture selected a different same-name Host module earlier in its -I/-L search order. Raw failure preserved.'})
  else:
   module=output
   run('compile-service-'+label,flags+['-enable-testing','-emit-module','-emit-library','-module-name','ChavrusaUIRoutingHost',
    '-emit-module-path',output/'ChavrusaUIRoutingHost.swiftmodule','-o',output/'libChavrusaUIRoutingHost.so']+host+[OWN/'inputs'/(label+'-NativeReaderToolIntentService.swift')])
  run('compile-controls-'+label,[SWIFTC,'-I',module,'-L',module,'-Xlinker','-rpath','-Xlinker',module]+flags[1:]+['-lChavrusaUIRoutingHost',
   OWN/'inputs/ReaderToolUTF8Controls.swift','-o',output/'controls'])
  run('run-'+label,[output/'controls'],allowed=(0,1)if label=='initial'else(0,))
 initial=json.loads((OWN/'run-initial.stdout').read_text());candidate=json.loads((OWN/'run-candidate.stdout').read_text())
 assert candidate['passed']==6 and candidate['failed']==0
 assert initial['passed']==4 and initial['failed']==2
 dump('RESULT.json',{'status':'PASS_ACTUAL_SERVICE_UTF8_PROPOSAL_WITH_DECLARED_BOUNDARIES','steps':steps,'initial':initial,'candidate':candidate,
  'nativeRuns':0,'AppleSDK':'NOT_RUN','CoreExecution':'NOT_RUN','ownedAllocatedBytes':size(),'rootFree':free(ROOT),'dataFree':free(OWN)})
except BaseException as e:
 dump('RESULT.json',{'status':'FAILED','steps':steps,'error':repr(e),'traceback':traceback.format_exc(),'nativeRuns':0,'AppleSDK':'NOT_RUN','ownedAllocatedBytes':size()});raise
finally:
 p=OWN/'RESULT.json'
 if p.exists():
  r=json.loads(p.read_text());print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'status':r.get('status'),
   'steps':[{'name':s['name'],'exit':s.get('exit')}for s in steps],'candidate':{k:r.get('candidate',{}).get(k)for k in ['passed','failed']},
   'initial':{k:r.get('initial',{}).get(k)for k in ['passed','failed']}}))
