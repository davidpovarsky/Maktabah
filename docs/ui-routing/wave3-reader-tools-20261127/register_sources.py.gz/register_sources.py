from pathlib import Path
import hashlib,json,re,runpy
R=Path(__file__).parent;OUT=R/'candidate';BASE=Path('wave3-all-original-entry-wiring/candidate')
sha=lambda b:hashlib.sha256(b).hexdigest()
parser=runpy.run_path('search-continuation-integration/ui-baseline/verify_source_registration.py')
path='Maktabah.xcodeproj/project.pbxproj';original=(BASE/path).read_bytes()
assert sha(original)=='3e860ef6e643061f0cddd086441fc604f122763e76f2a1217e949f607bc8c557'
before,duplicates=parser['parse'](original.decode());objects=before['objects'];phases=parser['target_sources'](before)
source='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeReaderToolSource.swift'
relative=source.removeprefix('Source/ChavrusaText/');name=Path(source).name
ref=sha(('wave3-reader-tools-ref:'+relative).encode())[:24].upper()
build=sha(('wave3-reader-tools-build:Maktabah-iOS:'+relative).encode())[:24].upper()
assert ref not in objects and build not in objects
assert not any(x.get('isa')=='PBXFileReference'and x.get('path')in[source,relative]for x in objects.values())
text=original.decode();insertions=[]
def insert(offset,value):
 global text
 text=text[:offset]+value+text[offset:];insertions.append({'offset':offset,'text':value})
insert(text.index('/* End PBXBuildFile section */'),'\t\t'+build+' /* '+name+' in Sources */ = {isa = PBXBuildFile; fileRef = '+ref+' /* '+name+' */; };\n')
insert(text.index('/* End PBXFileReference section */'),'\t\t'+ref+' /* '+name+' */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = "'+relative+'"; sourceTree = "<group>"; };\n')
group='CFEE00000000000000000001'
updates=[(group,'children','\t\t\t\t'+ref+' /* '+name+' */,\n'),(phases['Maktabah-iOS'][0],'files','\t\t\t\t'+build+' /* '+name+' in Sources */,\n')]
for object_id,field,value in updates:
 start=re.search(r'(?m)^\t\t'+object_id+r' /\*[^*]+\*/ = \{\n',text).start()
 anchor='\t\t\t'+field+' = (\n';insert(text.index(anchor,start)+len(anchor),value)
after,after_duplicates=parser['parse'](text);new=after['objects']
assert duplicates==after_duplicates
assert {k for k in objects if objects[k]!=new[k]}=={x[0]for x in updates}
assert set(new)-set(objects)=={ref,build}
for object_id,field,_ in updates:
 assert {k:v for k,v in objects[object_id].items()if k!=field}=={k:v for k,v in new[object_id].items()if k!=field}
 assert [x for x in new[object_id][field]if x in objects[object_id][field]]==objects[object_id][field]
assert new[group]['children'].count(ref)==1
assert [k for k,(_,members)in parser['target_sources'](after).items()if build in members]==['Maktabah-iOS']
inverse=text
for x in reversed(insertions):
 assert inverse[x['offset']:x['offset']+len(x['text'])]==x['text']
 inverse=inverse[:x['offset']]+inverse[x['offset']+len(x['text']):]
assert inverse.encode()==original
p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
rows=[{'path':path,'beforeSHA256':sha(original),'afterSHA256':sha(text.encode()),'afterBytes':len(text.encode()),'inverseExact':True}]
keys={
 'Open commentary at a passage':'פתיחת פירוש על קטע',
 'Choose a source passage, a commentary book and an existing Maktabah window. Open the original commentary reader in a new tab.':'בחרו קטע מקור, ספר פירוש וחלון קיים של אוצריא. הפירוש ייפתח בקורא המקורי בטאב חדש.',
 'Commentary book':'ספר פירוש',
 'Prepare an unsaved note for a selected passage':'הכנת טיוטת הערה לקטע שנבחר',
 'Choose the exact passage already selected in the original reader and its Maktabah window. Open an unsaved draft in the original note editor for review.':'בחרו את הקטע המדויק שכבר מסומן בקורא המקורי ואת החלון שלו באוצריא. טיוטה שלא נשמרה תיפתח לעיון בעורך ההערות המקורי.',
 'Selected passage':'הקטע שנבחר',
 'Unsaved note proposal':'הצעה לטיוטת הערה',
}
path='Source/Localizable.xcstrings';original=(BASE/path).read_bytes()
assert sha(original)=='9fe897f96bec395994c5c8759b5328a2a9eb7d0a9a950e820c299c9e0ad26bf2'
old=json.loads(original);added={};reused=[]
for key,he in keys.items():
 if key in old['strings']:
  assert old['strings'][key]['localizations']['he']['stringUnit']['value'];reused.append(key);continue
 added[key]={'localizations':{'en':{'stringUnit':{'state':'translated','value':key}},'he':{'stringUnit':{'state':'translated','value':he}}}}
anchor='  "strings": {\n';text=original.decode();assert text.count(anchor)==1
block='\n'.join('  '+l for l in json.dumps(added,ensure_ascii=False,indent=2)[2:-2].splitlines())+',\n'
candidate=text.replace(anchor,anchor+block,1);parsed=json.loads(candidate)
assert {k:v for k,v in parsed['strings'].items()if k not in added}==old['strings']
assert candidate.replace(anchor+block,anchor,1).encode()==original
(OUT/path).write_text(candidate)
rows.append({'path':path,'beforeSHA256':sha(original),'afterSHA256':sha(candidate.encode()),'afterBytes':len(candidate.encode()),'addedKeys':list(added),'reusedKeys':reused,'inverseExact':True})
shortcuts=(BASE/'Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift').read_bytes()
assert shortcuts.count(b'AppShortcut(intent:')==10
proof={'schema':'otzaria.wave3.reader-tools-registration.v1','files':rows,'newAppSource':source,'target':'Maktabah-iOS',
 'newPBXObjects':[ref,build],'projectInsertions':insertions,'SwiftPMAutoSources':['NativeReaderToolIntentService.swift','NativeReaderToolIntents.swift'],
 'curatedShortcutCount':10,'curatedShortcutSourceSHA256':sha(shortcuts),'originalObjectsOrderingAndCatalogEntriesPreserved':True,
 'AppIntentsMetadataAndSummaryExtraction':'Requires actual Apple SDK extraction; NOT_RUN','native':'NOT_RUN'}
(R/'REGISTRATION.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':rows,'newAppFiles':1,'newPBXObjects':2,'curatedShortcutCount':10},ensure_ascii=False))
