import Foundation
import OtzariaActionCore
import OtzariaUIRouting
@testable import ChavrusaUIRoutingHost

// Execute the complete production services and original Core/UIRouting values.
// Metadata responses, native effects, the app-owned source witness and time are
// explicit boundaries. This is neither an Apple SDK nor a native UI test.
struct CheckFailure: Error { let message: String }
@MainActor func require(_ value: @autoclosure () -> Bool, _ message: String) throws {
    if !value() { throw CheckFailure(message: message) }
}
@MainActor func refuses(_ operation: () async throws -> Void) async throws {
    do { try await operation() }
    catch is CheckFailure { throw CheckFailure(message: "assertion inside refusal") }
    catch { return }
    throw CheckFailure(message: "expected refusal")
}

@MainActor final class Fixture {
    typealias Service = NativeReaderToolIntentService
    let work: ActionWorkRef
    let commentary: ActionWorkRef
    let location: ActionTextRef
    var snapshot: ActionBackendSnapshot
    var ticks: UInt64 = 100
    var mode = "ok"
    var sourceLive = true
    var retained = 0, released = 0, executions = 0, checks = 0
    var metadataRequests: [ActionRequest] = []
    var afterMetadata: (() -> Void)?
    var afterEffect: (() -> Void)?
    var lease: Service.RetainedWindow?
    var actual: Service.Execution?
    var last: Service.Request?
    var reentryRefused = false

    init(backend: ActionBackendID = .otzaria) {
        snapshot = .init(backend: backend, generation: 17)
        work = .init(backend: backend, workKey: backend == .otzaria ? "book:42" : "Genesis")
        commentary = .init(backend: backend, workKey: backend == .otzaria ? "book:43" : "Rashi on Genesis")
        location = .init(backend: backend, workKey: work.workKey,
            position: backend == .otzaria ? .legacyLine(37) : .canonicalRef("Genesis 1:3"))
    }
    func identifiers() throws -> (String, String, String) {
        (try NativeReaderIntentService.Work(reference: work, title: "בראשית").id,
         try NativeReaderIntentService.Location(reference: location, title: "Original selected passage").id,
         try NativeReaderIntentService.Work(reference: commentary, title: "Original commentary").id)
    }
    func metadata(_ request: ActionRequest) async throws -> NativeReaderIntentService.CoreObservation {
        metadataRequests.append(request)
        let original = snapshot
        var data: ActionObject = [:]
        var status: ActionStatus = .completed
        var error: ActionFailure?
        if request.action == "catalog.resolveWork" {
            let ref = try request.arguments["workRef"]!.decoded(as: ActionWorkRef.self)
            data["workRef"] = try .encoded(mode == "replaced-commentary"
                ? ActionWorkRef(backend: ref.backend, workKey: "foreign-commentary") : ref)
            if mode == "missing-commentary" { status = .failed; error = .init(code: "not_found", message: "fixture") }
        } else if request.action == "catalog.resolveReference" {
            let ref = mode == "replaced-location"
                ? ActionTextRef(backend: location.backend, workKey: location.workKey, position: .legacyLine(99)) : location
            data["locator"] = try .encoded(ref)
        } else { throw CheckFailure(message: "noncatalog metadata action") }
        if mode == "advancing-clock" { ticks += 1_000_000_000 }
        afterMetadata?()
        return .init(result: .init(request: request, status: status, data: data, error: error,
            backend: original.backend, backendGeneration: original.generation), snapshot: original)
    }
    func service() -> Service {
        Service(snapshot: { self.snapshot }, execute: { try await self.metadata($0) }, retain: { start in
            self.retained += 1
            let owner = Service.RetainedWindow(sceneID: UIStableID(rawValue: "original-window")!, validate: {
                self.checks += 1
                guard self.sourceLive else { throw UIRouteError(.staleState, "original_source_retired") }
            }, execute: { request in
                self.executions += 1; self.last = request
                let value = try self.execution(request); self.actual = value
                if self.mode == "reentrant-execution" {
                    do { _ = try await self.lease!.perform(request) }
                    catch { self.reentryRefused = true }
                }
                if self.mode == "released-during-effect" { self.lease!.release() }
                self.afterEffect?()
                if self.mode == "throw-after-effect" {
                    throw Service.Failure(execution: value, underlying: UIRouteError(.staleState, "actual_late_refusal"))
                }
                return value
            }, release: { self.released += 1 })
            self.lease = owner
            return owner
        }, now: { self.ticks })
    }
    func execution(_ input: Service.Request) throws -> Service.Execution {
        let start = input.start, invocation = start.invocation
        let isDraft: Bool
        switch start.operation { case .commentary: isDraft = false; case .noteDraft: isDraft = true }
        let section = ActionTextRef(backend: commentary.backend, workKey: commentary.workKey,
            position: commentary.backend == .otzaria ? .legacyLine(87) : .canonicalRef("Rashi on Genesis 1:3:1"))
        let focus = mode == "foreign-focus"
            ? ActionTextRef(backend: section.backend, workKey: "foreign-work", position: section.position) : section
        let destination = ActionReaderDestination(sectionLocator: section, focusLocator: focus, presentationMode: .newTab)
        let scene = UIStableID(rawValue: "original-window")!
        let coreReceipt = ActionUIReceipt(requestId: invocation.requestId, snapshot: invocation.snapshot,
            sceneID: scene.rawValue, destination: destination)
        let route = RouteSpec(requestId: invocation.requestId,
            destination: UIDestinationID(rawValue: isDraft ? "native.reader.noteDraft" : "native.reader")!,
            backend: invocation.snapshot.backend, content: isDraft ? nil : destination,
            presentation: .init(kind: isDraft ? .sheet : .newTab),
            scene: .init(kind: .specific, sceneID: scene, expectedRevision: 10),
            expectedBackendSnapshot: invocation.snapshot)
        let receipt = UISceneReceipt(requestId: invocation.requestId, route: route, backendSnapshot: invocation.snapshot,
            sceneID: mode == "foreign-scene" ? UIStableID(rawValue: "other-window")! : scene,
            basedOnSceneRevision: 10, appliedSceneRevision: 11, coreReceipt: isDraft ? nil : coreReceipt)
        var args = try input.arguments()
        if mode == "changed-proposal" { args["proposedText"] = .string("foreign proposal") }
        if mode == "composed-rewrite" { args["proposedText"] = .string("caf\u{00e9}") }
        if mode == "decomposed-rewrite" { args["proposedText"] = .string("cafe\u{0301}") }
        let request = ActionRequest(requestId: invocation.requestId, action: start.operation.action, arguments: args,
            expectedBackend: invocation.snapshot.backend, expectedGeneration: invocation.snapshot.generation,
            requestedPresentation: .foreground, deadlineMs: Int((invocation.deadlineUptimeNanoseconds - ticks) / 1_000_000))
        let data: ActionObject = isDraft
            ? ["locator": try .encoded(start.locator), "saved": .bool(mode == "saved-note")]
            : ["destination": try .encoded(destination), "locator": try .encoded(focus)]
        let result = ActionResult(request: request, status: mode == "core-refusal" ? .staleState : .completed, data: data,
            error: mode == "core-refusal" ? .init(code: "original_core_refusal", message: "fixture") : nil,
            backend: invocation.snapshot.backend, backendGeneration: invocation.snapshot.generation,
            effects: ["explicit-native-boundary"])
        return .init(request: request, result: result, nativeReceipt: mode == "missing-native" ? nil : receipt)
    }
    func open(_ service: Service, draft: Bool = false, proposal: String? = "טיוטה — original proposal") async throws -> Service.Execution {
        let (book, passage, commentary) = try identifiers()
        if draft { return try await service.prepareDraft(workIdentifier: book, locationIdentifier: passage,
            windowIdentifier: "explicit-window-entity", proposedText: proposal) }
        return try await service.openCommentary(workIdentifier: book, locationIdentifier: passage,
            commentaryWorkIdentifier: commentary, windowIdentifier: "explicit-window-entity")
    }
}

@main struct UTF8Controls {
    @MainActor static func main() async {
        var cases: [[String: Any]] = []
        let vectors: [(String, String?, Bool)] = [
            ("ok", nil, true), ("ok", "", true), ("ok", "טיוטה 🕎", true),
            ("ok", "cafe\u{0301}", true),
            ("composed-rewrite", "cafe\u{0301}", false),
            ("decomposed-rewrite", "caf\u{00e9}", false)]
        for (index, vector) in vectors.enumerated() {
            let (mode, proposal, shouldPass) = vector
            do {
                let f = Fixture(); f.mode = mode
                var observed: Fixture.Service.Execution?, failure: Fixture.Service.Failure?
                do { observed = try await f.open(f.service(), draft: true, proposal: proposal) }
                catch let value as Fixture.Service.Failure { failure = value }
                if shouldPass {
                    try require(observed != nil && failure == nil, "exact optional UTF8 proposal remains accepted")
                    let original = observed?.request.arguments["proposedText"]?.string
                    try require(ActionNoteDraftRequest(locator: f.location, proposedText: proposal)
                        == ActionNoteDraftRequest(locator: f.location, proposedText: original), "original bytes retained")
                } else {
                    try require(observed == nil && failure != nil, "canonical-equivalent different bytes must not qualify")
                    try require(failure?.execution.nativeReceipt == f.actual?.nativeReceipt,
                        "unqualified actual native ACK is retained")
                }
                try require(f.executions == 1 && f.released == 1, "one effect and original cleanup")
                cases.append(["name": "UTF8-\(index)-\(mode)", "pass": true])
            } catch { cases.append(["name": "UTF8-\(index)-\(mode)", "pass": false, "error": String(describing: error)]) }
        }
        let failed = cases.filter { $0["pass"] as? Bool == false }.count
        print(String(data: try! JSONSerialization.data(withJSONObject: ["passed": cases.count-failed,
            "failed": failed, "cases": cases, "scope": "Actual full service and original Core text equality; metadata/native/time boundaries, no Core execution or SDK/native claim."], options: [.sortedKeys]), encoding: .utf8)!)
        exit(failed == 0 ? 0 : 1)
    }
}
