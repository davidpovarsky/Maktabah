import Foundation
enum LibraryReaderTextMode: String, Codable, CaseIterable, Identifiable, Sendable {
    case source
    case translation
    case both

    var id: String { rawValue }
}
