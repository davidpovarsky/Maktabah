import Foundation
import OtzariaActionCore
@MainActor final class MaktabahNativeNoteEditorOwner {
    let id: UUID
    weak var reader: ReaderViewModel?
    private let annotation: Binding<Annotation?>
    private let presentationID: @MainActor () -> UUID
    private var retiredPresentationID: UUID?
    weak var textView: UITextView?
    private(set) var presentationActive = false
    @discardableResult
    func observeTextView(_ value: UITextView?, presentationID: UUID) -> Bool {
        // Reader ownership survives sheet dismissal/reopening. Only the
        // presentation captured by this original editor may publish a view.
        guard current != nil, self.presentationID() == presentationID,
              retiredPresentationID != presentationID else { return false }
        if value == nil {
            // onDisappear closes this presentation even when its asynchronous
            // onCreated callback has not arrived. Late creation cannot revive it.
            retiredPresentationID = presentationID
        }
        textView = value
        if value != nil { presentationActive = true }
        return true
    }
    @discardableResult
    func didDismiss(presentationID: UUID) -> Bool {
        guard current == nil, self.presentationID() == presentationID,
              presentationActive || textView != nil || retiredPresentationID != presentationID else { return false }
        retiredPresentationID = presentationID
        presentationActive = false
        textView = nil
        return true
    }
    init(id: UUID, reader: ReaderViewModel, annotation: Binding<Annotation?>,
         presentationID: @escaping @MainActor () -> UUID) {
        self.id = id; self.reader = reader; self.annotation = annotation
        self.presentationID = presentationID
    }
    var current: Annotation? { annotation.wrappedValue }
    func present(_ draft: Annotation) throws {
        guard current == nil, draft.id == nil else { throw ActionPortError.staleState }
        presentationActive = true
        annotation.wrappedValue = draft
    }
}

