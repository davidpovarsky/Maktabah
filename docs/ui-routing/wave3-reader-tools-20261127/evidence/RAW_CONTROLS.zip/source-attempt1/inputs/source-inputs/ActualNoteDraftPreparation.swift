import Foundation
import OtzariaActionCore
import OtzariaUIRouting
@MainActor final class MaktabahNativeNoteDraftBinding {
    let owner: MaktabahNativeNoteEditorOwner
    let request: ActionNoteDraftRequest
    let draft: Annotation
    private let reader: ReaderViewModel
    private let sourceGuard: MaktabahNativeInspectorBinding
    private let sourceText: String
    private let sceneID: UIStableID
    private let sourceFence: (@MainActor () throws -> Void)?
    private(set) var isApplied = false

    /// Original source selection, also retained before a system action activates
    /// this exact existing window. The original visible-selection gate remains
    /// mandatory in selection(), immediately before draft construction.
    static func sourceSelection(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner)
        throws -> (ReaderViewModel, TextLocator, NSRange, String) {
        guard let reader = MaktabahNativeInspectorBinding.currentReader(in: manager), owner.reader === reader,
              owner.current == nil, let locator = reader.selectedSegmentLocator,
              let range = reader.selectedSegmentRange else {
            throw UIRouteError(.unavailable, "exact_note_selection_unavailable")
        }
        // These are the original renderer/DB anchor ranges, never a guessed
        // first character, a title-derived position or a model-supplied range.
        let rendered = reader.backendRenderModel?.renderedSegment(for: locator)?.visualRange
        let anchorMatches = reader.otzariaSelectedLineAnchor.map {
            locator.backend == .otzaria && locator.workKey == "book:\($0.bookId)"
                && locator.position == .legacyLine($0.lineIndex) && $0.range == range
        } ?? false
        guard rendered == range || anchorMatches else { throw ActionPortError.staleState }
        let ref = try ActionAppIdentityBridge.actionRef(locator)
        _ = try ActionNoteDraftSelection.validate(.init(locator: ref), observedLocator: ref,
            sourceText: reader.contentText, originalRange: range)
        return (reader, locator, range, reader.contentText)
    }

    static func selection(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner,
                          sceneID: UIStableID) throws -> (ReaderViewModel, TextLocator, NSRange, String) {
        let selected = try sourceSelection(manager: manager, owner: owner)
        guard selected.0.isNativeReaderTextVisible?(sceneID.rawValue, selected.2) == true else {
            throw UIRouteError(.unavailable, "exact_note_selection_unavailable")
        }
        return selected
    }

    init(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner,
         request: ActionNoteDraftRequest, sceneID: UIStableID,
         sourceFence: (@MainActor () throws -> Void)? = nil) throws {
        let (reader, locator, range, source) = try Self.selection(manager: manager, owner: owner, sceneID: sceneID)
        let actual = try ActionAppIdentityBridge.actionRef(locator)
        let snippet = try ActionNoteDraftSelection.validate(request, observedLocator: actual, sourceText: source, originalRange: range)
        let sourceGuard = try MaktabahNativeInspectorBinding(manager: manager)
        var draft = try reader.makeAnnotationDraft(in: range, mode: .highlight, sourceText: source,
            color: UIColor(named: "HighlightText") ?? .systemYellow)
        guard draft.id == nil, draft.context.utf8.elementsEqual(snippet.utf8) else { throw ActionPortError.invalidResponse }
        // Same original editor flow: use the selected source-owned locator
        // when the original generic factory falls back to its containing unit.
        draft.backendLocator = locator
        draft.note = request.proposedText
        self.owner = owner; self.reader = reader; self.request = request; self.draft = draft
        self.sourceGuard = sourceGuard; sourceText = source; self.sceneID = sceneID
        self.sourceFence = sourceFence
        try validate()
    }
    func validate() throws {
        try sourceFence?()
        try sourceGuard.validate()
        guard owner.reader === reader, reader.contentText.utf8.elementsEqual(sourceText.utf8) else { throw ActionPortError.staleState }
        if isApplied {
            guard owner.current == draft, owner.current?.id == nil else { throw ActionPortError.staleState }
        } else {
            guard owner.current == nil else { throw ActionPortError.staleState }
        }
        try sourceFence?()
    }
    func apply() throws {
        try validate()
        isApplied = true
        try owner.present(draft)
        try validate()
    }
}
