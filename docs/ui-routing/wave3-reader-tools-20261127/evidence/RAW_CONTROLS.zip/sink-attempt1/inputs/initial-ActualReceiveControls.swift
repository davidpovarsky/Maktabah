import Foundation
import OtzariaActionCore
import OtzariaUIRouting

// Explicit boundaries: scene directory, validated command/preparation, native
// orchestrator, original note owner and final source/geometry observation.
// Actual production receive bodies and Core/UIRouting values are unchanged.
struct UIValidatedRoute { let route: RouteSpec }
struct UISceneCommand {
    let route: UIValidatedRoute
    let invocation: ActionPortInvocation
    init(route: UIValidatedRoute, invocation: ActionPortInvocation, scene: UIStableID) throws {
        self.route = route; self.invocation = invocation
    }
    func prepareNavigation(noteDraftCommand: ActionPrepareNoteDraftCommand) throws -> Self { self }
}
struct HanlinSourceObservation { let backend: ActionBackendSnapshot }
@MainActor final class MaktabahNativeReaderToolSource {}
struct EditorBoundary { let id: Int? }
@MainActor final class NoteOwnerBoundary { var current: EditorBoundary? = .init(id: nil) }
@MainActor final class MaktabahNativeNoteDraftBinding {
    let request: ActionNoteDraftRequest
    let owner = NoteOwnerBoundary()
    init(_ request: ActionNoteDraftRequest) { self.request = request }
}
@MainActor final class SessionBoundary {
    var failure: (any Error)?
    var validations = 0
    func validateNoteDraftCompletion(_ binding: MaktabahNativeNoteDraftBinding, route: RouteSpec) throws {
        validations += 1
        if let failure { throw failure }
    }
}
@MainActor struct EntryBoundary { let session: SessionBoundary }
@MainActor final class DirectoryBoundary {
    func currentScene(sceneID: UIStableID, context: ActionExecutionContext,
                      invocation: ActionPortInvocation) async throws -> UIStableID { sceneID }
}
@MainActor final class OrchestratorBoundary {
    var returned: UISceneAcknowledgement = .requiresForeground
    var onEffect: (() -> Void)?
    var calls = 0
    func commitPrepared(_ command: UISceneCommand, admitted: ActionNavigationState) async -> UISceneAcknowledgement {
        calls += 1; onEffect?(); return returned
    }
    func commit(_ command: UISceneCommand, readerCommand: ActionOpenReaderCommand,
                context: ActionExecutionContext) async -> UISceneAcknowledgement {
        calls += 1; onEffect?(); return returned
    }
}
struct SinkFailure: Error { let message: String }
@MainActor func require(_ value: @autoclosure () -> Bool, _ message: String) throws {
    if !value() { throw SinkFailure(message: message) }
}
@MainActor final class SinkControls {
    let directory = DirectoryBoundary()
    let orchestrator = OrchestratorBoundary()
    var contexts: [UIStableID: ActionExecutionContext] = [:]
    var scenes: [UIStableID: EntryBoundary] = [:]
    private final class ReaderInvocation {
        let route: UIValidatedRoute
        let context: ActionExecutionContext
        let sceneID: UIStableID
        var receipt: UISceneReceipt?
        var observedReceipt: UISceneReceipt?
        weak var commentary: CommentaryInvocation?
        init(route: UIValidatedRoute, context: ActionExecutionContext, sceneID: UIStableID,
             commentary: CommentaryInvocation? = nil) {
            self.route = route; self.context = context; self.sceneID = sceneID
            self.commentary = commentary
        }
    }

    private final class CommentaryInvocation {
        let sceneID: UIStableID
        let context: ActionExecutionContext
        let observation: HanlinSourceObservation
        let readerToolSource: MaktabahNativeReaderToolSource?
        var observedReceipt: UISceneReceipt?
        var cleanup: (@MainActor () -> Void)?
        init(sceneID: UIStableID, context: ActionExecutionContext, observation: HanlinSourceObservation,
             readerToolSource: MaktabahNativeReaderToolSource? = nil) {
            self.sceneID = sceneID; self.context = context; self.observation = observation
            self.readerToolSource = readerToolSource
        }
    }

    private final class NoteDraftInvocation {
        let sceneID: UIStableID
        let context: ActionExecutionContext
        let observation: HanlinSourceObservation
        let request: ActionNoteDraftRequest
        let readerToolSource: MaktabahNativeReaderToolSource?
        var observedReceipt: UISceneReceipt?
        var binding: MaktabahNativeNoteDraftBinding?
        var command: UISceneCommand?
        var admitted: ActionNavigationState?
        var receipt: UISceneReceipt?
        var cleanup: (@MainActor () -> Void)?
        init(sceneID: UIStableID, context: ActionExecutionContext, observation: HanlinSourceObservation,
             request: ActionNoteDraftRequest, readerToolSource: MaktabahNativeReaderToolSource? = nil) {
            self.sceneID = sceneID; self.context = context; self.observation = observation; self.request = request
            self.readerToolSource = readerToolSource
        }
    }

    private var readerInvocations: [UUID: ReaderInvocation] = [:]
    private var noteDraftInvocations: [UUID: NoteDraftInvocation] = [:]
    private func receiveNoteDraft(_ note: ActionPrepareNoteDraftCommand) async throws -> ActionNoteDraftAcknowledgement {
        guard let pending = noteDraftInvocations[note.invocation.requestId], pending.request == note.draft,
              pending.sceneID.rawValue == note.sceneID, pending.observation.backend == note.invocation.snapshot,
              contexts[pending.sceneID] == pending.context, let command = pending.command,
              command.invocation == note.invocation, let admitted = pending.admitted,
              let bound = pending.binding, let entry = scenes[pending.sceneID] else { throw ActionPortError.staleState }
        let prepared = try command.prepareNavigation(noteDraftCommand: note)
        let result = await orchestrator.commitPrepared(prepared, admitted: admitted)
        guard case .acknowledged(let receipt) = result else {
            if case .requiresForeground = result { return .requiresForeground }
            throw Self.nativeUIFailure(result)
        }
        do {
            guard noteDraftInvocations[note.invocation.requestId] === pending, pending.cleanup != nil,
                  receipt.requestId == note.invocation.requestId, receipt.backendSnapshot == note.invocation.snapshot,
                  receipt.sceneID == pending.sceneID, receipt.route == command.route.route,
                  receipt.coreReceipt == nil else { throw ActionPortError.invalidResponse }
            try entry.session.validateNoteDraftCompletion(bound, route: receipt.route)
            pending.receipt = receipt
            guard let actual = bound.owner.current else { throw ActionPortError.staleState }
            return .acknowledged(.init(requestId: receipt.requestId, snapshot: receipt.backendSnapshot,
                sceneID: receipt.sceneID.rawValue, draft: bound.request, isUnsaved: actual.id == nil))
        } catch { throw Self.uncertainNativeEffect(error) }
    }

    private static func uncertainNativeEffect(_ error: any Error) -> ActionNativeUIFailure {
        let status = (error as? UIRouteError)?.status ?? (error as? ActionNavigationError)?.status
            ?? (error as? ActionNativeUIFailure)?.status
            ?? ((error as? ActionPortError) == .staleState ? .staleState : (error is CancellationError ? .cancelled : .failed))
        return .init(status: status, failure: .init(code: "native_effect_uncertain", message: "", retryable: false))
    }

    private static func nativeUIFailure(_ result: UISceneAcknowledgement) -> ActionNativeUIFailure {
        let status: ActionStatus, failure: ActionFailure
        switch result {
        case .notSupported(let value): status = .notSupported; failure = value
        case .unavailable(let value): status = .unavailable; failure = value
        case .staleState(let value): status = .staleState; failure = value
        case .failed(let value): status = .failed; failure = value
        case .requiresConfirmation(let value): status = .requiresConfirmation; failure = value
        case .cancelled: status = .cancelled; failure = .init(code: "cancelled", message: "")
        default: status = .failed; failure = .init(code: "native_ui_failed", message: "")
        }
        return .init(status: status, failure: failure)
    }

    private func receiveReader(_ reader: ActionOpenReaderCommand) async throws -> ActionUIAcknowledgement {
        guard let pending = readerInvocations[reader.invocation.requestId],
              pending.sceneID.rawValue == reader.sceneID, pending.route.route.content == reader.destination,
              contexts[pending.sceneID] == pending.context else { throw ActionPortError.staleState }
        let scene = try await directory.currentScene(sceneID: pending.sceneID, context: pending.context, invocation: reader.invocation)
        let command = try UISceneCommand(route: pending.route, invocation: reader.invocation, scene: scene)
        let result = await orchestrator.commit(command, readerCommand: reader, context: pending.context)
        guard case .acknowledged(let receipt) = result, let coreReceipt = receipt.coreReceipt else {
            if case .requiresForeground = result { return .requiresForeground }
            throw ActionPortError.unavailable
        }
        pending.receipt = receipt
        return .acknowledged(coreReceipt)
    }


    static func check(_ mode: String) async throws {
        let f = SinkControls()
        let scene = UIStableID(rawValue: "original-window")!
        let snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 17)
        let context = ActionExecutionContext(subjectID: "source-control", origin: .appIntent,
            allowedBackends: [.otzaria], scopes: [.navigation], foregroundSceneID: scene.rawValue)
        let invocation = ActionPortInvocation(requestId: UUID(), snapshot: snapshot,
            deadlineUptimeNanoseconds: 5_000_000_100)
        let locator = ActionTextRef(backend: .otzaria, workKey: "book:42", position: .legacyLine(37))
        let draft = ActionNoteDraftRequest(locator: locator, selectedText: "מקור", proposedText: "טיוטה")
        let destination = ActionReaderDestination(sectionLocator: locator, focusLocator: locator,
            presentationMode: .newTab)
        let readerCase = mode.hasPrefix("reader")
        let route = RouteSpec(requestId: invocation.requestId,
            destination: UIDestinationID(rawValue: readerCase ? "native.reader" : "native.reader.noteDraft")!,
            backend: snapshot.backend, content: readerCase ? destination : nil,
            presentation: .init(kind: readerCase ? .newTab : .sheet),
            scene: .init(kind: .specific, sceneID: scene, expectedRevision: 2), expectedBackendSnapshot: snapshot)
        let session = SessionBoundary()
        f.scenes[scene] = .init(session: session); f.contexts[scene] = context
        let coreReceipt = ActionUIReceipt(requestId: invocation.requestId, snapshot: snapshot,
            sceneID: scene.rawValue, destination: destination)
        let receipt = UISceneReceipt(requestId: mode == "note-wrong-ack" ? UUID() : invocation.requestId,
            route: route, backendSnapshot: snapshot, sceneID: scene, basedOnSceneRevision: 2,
            appliedSceneRevision: 3, coreReceipt: readerCase && mode != "reader-missing-core" ? coreReceipt : nil)
        f.orchestrator.returned = .acknowledged(receipt)

        if readerCase {
            let commentary = CommentaryInvocation(sceneID: scene, context: context, observation: .init(backend: snapshot))
            let pending = ReaderInvocation(route: .init(route: route), context: context, sceneID: scene,
                commentary: commentary)
            f.readerInvocations[invocation.requestId] = pending
            var returned: ActionUIAcknowledgement?, caught: (any Error)?
            do { returned = try await f.receiveReader(.init(destination: destination, sceneID: scene.rawValue, invocation: invocation)) }
            catch { caught = error }
            try require(f.orchestrator.calls == 1, "one actual return from declared native boundary")
            try require(pending.observedReceipt == receipt && commentary.observedReceipt == receipt,
                "actual Reader and Commentary ACK evidence survives qualification")
            if mode == "reader-missing-core" {
                try require(caught != nil && returned == nil && pending.receipt == nil, "missing Core receipt cannot become qualified success")
            } else {
                try require(caught == nil && returned == .acknowledged(coreReceipt) && pending.receipt == receipt,
                    "original successful Reader return remains exact")
            }
            return
        }

        let pending = NoteDraftInvocation(sceneID: scene, context: context,
            observation: .init(backend: snapshot), request: draft)
        let binding = MaktabahNativeNoteDraftBinding(draft)
        pending.binding = binding; pending.cleanup = {}
        pending.command = try .init(route: .init(route: route), invocation: invocation, scene: scene)
        pending.admitted = .init(context: context, sceneID: scene.rawValue,
            lifetimeID: UUID(), authorityRevision: 2, active: true)
        f.noteDraftInvocations[invocation.requestId] = pending
        if mode == "note-late-source" { session.failure = ActionPortError.staleState }
        if mode == "note-late-cancel" { session.failure = CancellationError() }
        if mode == "note-retired-in-effect" { f.orchestrator.onEffect = { f.noteDraftInvocations.removeValue(forKey: invocation.requestId) } }
        if mode == "note-replaced-in-effect" { f.orchestrator.onEffect = {
            f.noteDraftInvocations[invocation.requestId] = NoteDraftInvocation(sceneID: scene, context: context,
                observation: .init(backend: snapshot), request: draft)
        } }
        if mode == "note-no-native" { f.orchestrator.returned = .requiresForeground }
        if mode == "note-stale-before-effect" { f.contexts.removeValue(forKey: scene) }
        var returned: ActionNoteDraftAcknowledgement?, caught: (any Error)?
        do { returned = try await f.receiveNoteDraft(.init(draft: draft, sceneID: scene.rawValue, invocation: invocation)) }
        catch { caught = error }
        if mode == "note-no-native" {
            try require(returned == .requiresForeground && caught == nil && pending.observedReceipt == nil && pending.receipt == nil,
                "no fabricated ACK when native boundary returns foreground requirement")
        } else if mode == "note-stale-before-effect" {
            try require(f.orchestrator.calls == 0 && caught != nil && pending.observedReceipt == nil && pending.receipt == nil,
                "pre-effect source mismatch neither navigates nor invents evidence")
        } else {
            try require(f.orchestrator.calls == 1 && pending.observedReceipt == receipt, "actual ACK retained before all final source/identity checks")
            if mode == "note-success" {
                try require(caught == nil && pending.receipt == receipt, "qualified note receipt preserved")
                guard case .acknowledged(let actual) = returned else { throw SinkFailure(message: "missing qualified draft") }
                try require(actual.isUnsaved && actual.draft == draft, "original unsaved draft remains exact")
            } else {
                let failure = caught as? ActionNativeUIFailure
                try require(returned == nil && pending.receipt == nil && failure?.failure.code == "native_effect_uncertain",
                    "late failure remains uncertain, with no qualified receipt")
            }
        }
    }
}

@main struct RunSinkControls {
    @MainActor static func main() async {
        var cases: [[String: Any]] = []
        for mode in ["note-success", "note-late-source", "note-late-cancel", "note-wrong-ack",
                     "note-retired-in-effect", "note-replaced-in-effect", "note-no-native",
                     "note-stale-before-effect", "reader-success", "reader-missing-core"] {
            do { try await SinkControls.check(mode); cases.append(["name": mode, "pass": true]) }
            catch { cases.append(["name": mode, "pass": false, "error": String(describing: error)]) }
        }
        let failed = cases.filter { $0["pass"] as? Bool == false }.count
        let result: [String: Any] = ["passed": cases.count - failed, "failed": failed, "cases": cases,
            "scope": "Actual production receive bodies and receipt values; explicit directory/command/native/source-observation boundaries. No Core execution, Apple SDK, or native acceptance."]
        print(String(data: try! JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]), encoding: .utf8)!)
        exit(failed == 0 ? 0 : 1)
    }
}
