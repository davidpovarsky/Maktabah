from pathlib import Path
import hashlib,json
ROOT=Path(__file__).parent
BASE=Path('wave3-all-original-entry-wiring/candidate')
OUT=ROOT/'candidate'
EDITS=json.loads((ROOT/'SHARED_EDITS.json').read_text())
path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift'
original=(BASE/path).read_bytes()
assert hashlib.sha256(original).hexdigest()=='9ebdf1237a1cd9cb0d64e7fd31542c2c3aee3907c7ce24488c966a14a4f4a720'
text=original.decode()
def edit(old,new):
 global text
 assert text.count(old)==1,(old[:100],text.count(old))
 EDITS.append({'path':path,'old':old,'new':new});text=text.replace(old,new)
edit('''        var receipt: UISceneReceipt?
        init(route: UIValidatedRoute, context: ActionExecutionContext, sceneID: UIStableID) {
            self.route = route; self.context = context; self.sceneID = sceneID
        }
    }
    private var readerInvocations''',
'''        var receipt: UISceneReceipt?
        var observedReceipt: UISceneReceipt?
        weak var commentary: CommentaryInvocation?
        init(route: UIValidatedRoute, context: ActionExecutionContext, sceneID: UIStableID,
             commentary: CommentaryInvocation? = nil) {
            self.route = route; self.context = context; self.sceneID = sceneID
            self.commentary = commentary
        }
    }
    private var readerInvocations''')
edit('''        let observation: HanlinSourceObservation
        var cleanup: (@MainActor () -> Void)?
        init(sceneID: UIStableID, context: ActionExecutionContext, observation: HanlinSourceObservation) {
            self.sceneID = sceneID; self.context = context; self.observation = observation
        }
    }
    private var commentaryInvocations''',
'''        let observation: HanlinSourceObservation
        let readerToolSource: MaktabahNativeReaderToolSource?
        var observedReceipt: UISceneReceipt?
        var cleanup: (@MainActor () -> Void)?
        init(sceneID: UIStableID, context: ActionExecutionContext, observation: HanlinSourceObservation,
             readerToolSource: MaktabahNativeReaderToolSource? = nil) {
            self.sceneID = sceneID; self.context = context; self.observation = observation
            self.readerToolSource = readerToolSource
        }
    }
    private var commentaryInvocations''')
edit('''        let request: ActionNoteDraftRequest
        var binding: MaktabahNativeNoteDraftBinding?''',
'''        let request: ActionNoteDraftRequest
        let readerToolSource: MaktabahNativeReaderToolSource?
        var observedReceipt: UISceneReceipt?
        var binding: MaktabahNativeNoteDraftBinding?''')
edit('''        init(sceneID: UIStableID, context: ActionExecutionContext, observation: HanlinSourceObservation,
             request: ActionNoteDraftRequest) {
            self.sceneID = sceneID; self.context = context; self.observation = observation; self.request = request
        }
    }
    private var noteDraftInvocations''',
'''        init(sceneID: UIStableID, context: ActionExecutionContext, observation: HanlinSourceObservation,
             request: ActionNoteDraftRequest, readerToolSource: MaktabahNativeReaderToolSource? = nil) {
            self.sceneID = sceneID; self.context = context; self.observation = observation; self.request = request
            self.readerToolSource = readerToolSource
        }
    }
    private var noteDraftInvocations''')
edit('''        // As in open(public:), reservation advances the original workspace
        // epoch BEFORE issuing/admitting the context used by the Core grant.
        let retained = try entry.session.retainReader''',
'''        // The optional system source is consumed once inside the existing Core
        // preparation sink, immediately before original retention.
        try pending.readerToolSource?.handOff(invocation)
        // As in open(public:), reservation advances the original workspace
        // epoch BEFORE issuing/admitting the context used by the Core grant.
        let retained = try entry.session.retainReader''')
edit('''        let retained = try entry.session.retainNoteDraft(draft)
        do {''',
'''        try pending.readerToolSource?.handOff(invocation)
        let sourceFence: (@MainActor () throws -> Void)?
        if let source = pending.readerToolSource { sourceFence = { try source.validateSelection() } }
        else { sourceFence = nil }
        let retained = try entry.session.retainNoteDraft(draft, sourceFence: sourceFence)
        do {''')
edit('''            readerInvocations[invocation.requestId] = ReaderInvocation(route: route, context: context, sceneID: pending.sceneID)
''',
'''            readerInvocations[invocation.requestId] = ReaderInvocation(route: route, context: context,
                sceneID: pending.sceneID, commentary: pending)
''')
edit('''        let prepared = try command.prepareNavigation(noteDraftCommand: note)
        let result = await orchestrator.commitPrepared(prepared, admitted: admitted)
        guard case .acknowledged(let receipt) = result else {
            if case .requiresForeground = result { return .requiresForeground }
''',
'''        let prepared = try command.prepareNavigation(noteDraftCommand: note)
        let result = await orchestrator.commitPrepared(prepared, admitted: admitted)
        // Preserve the actually observed native ACK even if the original final
        // source check below refuses. This is partial evidence, never authority.
        if case .acknowledged(let receipt) = result { pending.observedReceipt = receipt }
        guard case .acknowledged(let receipt) = result else {
            if case .requiresForeground = result { return .requiresForeground }
''')
edit('''        let result = await orchestrator.commit(command, readerCommand: reader, context: pending.context)
        guard case .acknowledged(let receipt) = result, let coreReceipt = receipt.coreReceipt else {
''',
'''        let result = await orchestrator.commit(command, readerCommand: reader, context: pending.context)
        if case .acknowledged(let receipt) = result {
            pending.observedReceipt = receipt
            pending.commentary?.observedReceipt = receipt
        }
        guard case .acknowledged(let receipt) = result, let coreReceipt = receipt.coreReceipt else {
''')
edit('''        let request = ActionRequest(requestId: request.requestId, action: request.action, arguments: request.arguments,
            expectedBackend: snapshot.backend, expectedGeneration: snapshot.generation, requestedPresentation: .headless)
        let context = ActionExecutionContext(subjectID: "maktabah.intent.metadata"''',
'''        let request = ActionRequest(requestId: request.requestId, action: request.action, arguments: request.arguments,
            expectedBackend: snapshot.backend, expectedGeneration: snapshot.generation, requestedPresentation: .headless,
            deadlineMs: request.deadlineMs)
        let context = ActionExecutionContext(subjectID: "maktabah.intent.metadata"''')
edit('    private func openReaderIntent(_ request: NativeReaderIntentService.OpenRequest) async throws -> UISceneAcknowledgement {\n',
(ROOT/'ReaderToolComposition.swiftfrag').read_text()+'    private func openReaderIntent(_ request: NativeReaderIntentService.OpenRequest) async throws -> UISceneAcknowledgement {\n')
edit('''        AppDependencyManager.shared.add(dependency: readerService)
        let tabService = NativeReaderTabIntentService''',
'''        AppDependencyManager.shared.add(dependency: readerService)
        let readerToolService = NativeReaderToolIntentService(snapshot: { [self] in
            try backend.currentBackendSnapshot()
        }, execute: { [self] in
            do { return try await readerIntentMetadata($0) }
            catch { logIntentFailure(error, stage: "reader_tool_metadata"); throw error }
        }, retain: { [self] in
            do { return try retainReaderToolWindow($0) }
            catch { logIntentFailure(error, stage: "reader_tool_source"); throw error }
        })
        AppDependencyManager.shared.add(dependency: readerToolService)
        let tabService = NativeReaderTabIntentService''')
inverse=text
for row in reversed([r for r in EDITS if r['path']==path]):
 assert inverse.count(row['new'])==1
 inverse=inverse.replace(row['new'],row['old'])
assert inverse.encode()==original
(OUT/path).write_text(text)
(ROOT/'SHARED_EDITS.json').write_text(json.dumps(EDITS,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'edits':len(EDITS),'compositionBytes':len(text.encode()),'compositionSHA256':hashlib.sha256(text.encode()).hexdigest()}))
