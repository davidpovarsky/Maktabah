from pathlib import Path
import hashlib,json

ROOT=Path(__file__).parent
BASE=Path('wave3-all-original-entry-wiring/candidate')
OUT=ROOT/'candidate'
EDITS=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def begin(path,expected):
 b=(BASE/path).read_bytes();assert sha(b)==expected
 return b,b.decode()
def edit(path,text,old,new):
 assert text.count(old)==1,(path,old[:100],text.count(old))
 EDITS.append({'path':path,'old':old,'new':new})
 return text.replace(old,new)
def finish(path,original,text):
 inverse=text
 for row in reversed([r for r in EDITS if r['path']==path]):
  assert inverse.count(row['new'])==1
  inverse=inverse.replace(row['new'],row['old'])
 assert inverse.encode()==original
 p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)

path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneBindings.swift'
original,text=begin(path,'3932e90ea2ef1e0d042cee70efe00ca891b5e8d1d768ee6339293e9649dee2f5')
start=text.index('    static func selection(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner,')
end=text.index('\n    init(manager:',start)
old=text[start:end]
source=old.replace('    static func selection(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner,\n                          sceneID: UIStableID) throws -> (ReaderViewModel, TextLocator, NSRange, String) {',
'    static func sourceSelection(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner)\n        throws -> (ReaderViewModel, TextLocator, NSRange, String) {')
source=source.replace('let range = reader.selectedSegmentRange,\n              reader.isNativeReaderTextVisible?(sceneID.rawValue, range) == true else {','let range = reader.selectedSegmentRange else {')
assert source!=old and 'isNativeReaderTextVisible' not in source
wrapper='''    /// Original source selection, also retained before a system action activates
    /// this exact existing window. The original visible-selection gate remains
    /// mandatory in selection(), immediately before draft construction.
'''+source+'''
    static func selection(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner,
                          sceneID: UIStableID) throws -> (ReaderViewModel, TextLocator, NSRange, String) {
        let selected = try sourceSelection(manager: manager, owner: owner)
        guard selected.0.isNativeReaderTextVisible?(sceneID.rawValue, selected.2) == true else {
            throw UIRouteError(.unavailable, "exact_note_selection_unavailable")
        }
        return selected
    }
'''
text=edit(path,text,old,wrapper)
text=edit(path,text,'    private let sceneID: UIStableID\n    private(set) var isApplied = false\n\n    /// Original source selection,',
'''    private let sceneID: UIStableID
    private let sourceFence: (@MainActor () throws -> Void)?
    private(set) var isApplied = false

    /// Original source selection,''')
text=edit(path,text,'''    init(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner,
         request: ActionNoteDraftRequest, sceneID: UIStableID) throws {''',
'''    init(manager: iOSNavigationManager, owner: MaktabahNativeNoteEditorOwner,
         request: ActionNoteDraftRequest, sceneID: UIStableID,
         sourceFence: (@MainActor () throws -> Void)? = nil) throws {''')
text=edit(path,text,'''        self.sourceGuard = sourceGuard; sourceText = source; self.sceneID = sceneID
        try validate()
    }
    func validate() throws {
        try sourceGuard.validate()''',
'''        self.sourceGuard = sourceGuard; sourceText = source; self.sceneID = sceneID
        self.sourceFence = sourceFence
        try validate()
    }
    func validate() throws {
        try sourceFence?()
        try sourceGuard.validate()''')
text=edit(path,text,'''        } else {
            guard owner.current == nil else { throw ActionPortError.staleState }
        }
    }
    func apply() throws {''',
'''        } else {
            guard owner.current == nil else { throw ActionPortError.staleState }
        }
        try sourceFence?()
    }
    func apply() throws {''')
finish(path,original,text)

path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
original,text=begin(path,'a77dd4223cf3a9c8336d405e45690b02016a022031b9002a5b97bb795650a4d9')
text=edit(path,text,'    @ObservationIgnored private var noteDraftBinding: MaktabahNativeNoteDraftBinding?\n',
'''    @ObservationIgnored private var noteDraftBinding: MaktabahNativeNoteDraftBinding?
    @ObservationIgnored private var readerToolEditorPublicationRevision: UInt64? = 0
''')
text=edit(path,text,'''    func attachNoteEditor(id: UUID, reader: ReaderViewModel, annotation: Binding<Annotation?>,
''','''    private func advanceReaderToolEditorPublication() {
        guard let revision = readerToolEditorPublicationRevision else { return }
        let (next, overflow) = revision.addingReportingOverflow(1)
        readerToolEditorPublicationRevision = overflow ? nil : next
    }

    func attachNoteEditor(id: UUID, reader: ReaderViewModel, annotation: Binding<Annotation?>,
''')
text=edit(path,text,'''        if noteEditorOwner?.id == id, noteEditorOwner?.reader === reader { return }
        if noteDraftBinding != nil { presentation.revoke() }''',
'''        if noteEditorOwner?.id == id, noteEditorOwner?.reader === reader { return }
        advanceReaderToolEditorPublication()
        if noteDraftBinding != nil { presentation.revoke() }''')
text=edit(path,text,'''              owner.id == id, owner.reader === reader else { return }
        readerTabBinding?.invalidate()''',
'''              owner.id == id, owner.reader === reader else { return }
        advanceReaderToolEditorPublication()
        readerTabBinding?.invalidate()''')
text=edit(path,text,'''    func detachNoteEditor(id: UUID) {
        guard let owner = noteEditorOwner, owner.id == id else { return }
''',
'''    func detachNoteEditor(id: UUID) {
        guard let owner = noteEditorOwner, owner.id == id else { return }
        advanceReaderToolEditorPublication()
''')
text=edit(path,text,'''    func retainNoteDraft(_ request: ActionNoteDraftRequest) throws -> MaktabahNativeNoteDraftBinding {
        guard canPrepareNoteDraft(), let owner = noteEditorOwner else { throw ActionPortError.unavailable }
        let bound = try MaktabahNativeNoteDraftBinding(manager: bindings.manager, owner: owner, request: request, sceneID: sceneID)
''',
'''    func retainNoteDraft(_ request: ActionNoteDraftRequest,
                         sourceFence: (@MainActor () throws -> Void)? = nil) throws -> MaktabahNativeNoteDraftBinding {
        guard canPrepareNoteDraft(), let owner = noteEditorOwner else { throw ActionPortError.unavailable }
        let bound = try MaktabahNativeNoteDraftBinding(manager: bindings.manager, owner: owner,
            request: request, sceneID: sceneID, sourceFence: sourceFence)
''')
text=edit(path,text,'    func canPrepareNoteDraft() -> Bool {\n',
'''    /// Capture before the first catalog await. Source metadata does not open a
    /// Reader, construct an Annotation, select a range or acquire a Core grant.
    func captureReaderToolSource(_ start: NativeReaderToolIntentService.Start,
        validateOwner: @escaping @MainActor @Sendable () throws -> Void) throws -> MaktabahNativeReaderToolSource {
        let validateWindow = try captureHistoryReaderWindow()
        guard let editorRevision = readerToolEditorPublicationRevision,
              noteEditorOwner?.current == nil, noteEditorOwner?.presentationActive != true else {
            throw UIRouteError(.unavailable, "reader_tool_original_editor_unavailable")
        }
        let editor = noteEditorOwner, manager = bindings.manager
        let selection: MaktabahNativeReaderToolSelection?
        switch start.operation {
        case .commentary: selection = nil
        case .noteDraft:
            guard let editor else { throw UIRouteError(.unavailable, "exact_note_selection_unavailable") }
            selection = try MaktabahNativeReaderToolSelection(manager: manager, owner: editor, locator: start.locator)
        }
        return try MaktabahNativeReaderToolSource(start: start, sceneID: sceneID, selection: selection) { [weak self, weak manager] in
            try validateOwner()
            try validateWindow()
            guard let self, let manager, self.bindings.manager === manager,
                  self.readerToolEditorPublicationRevision == editorRevision,
                  self.noteEditorOwner === editor, editor?.current == nil,
                  editor?.presentationActive != true else {
                throw UIRouteError(.staleState, "reader_tool_original_editor_changed")
            }
            try validateWindow()
            try validateOwner()
        }
    }

    func canPrepareNoteDraft() -> Bool {
''')
finish(path,original,text)
(ROOT/'SHARED_EDITS.json').write_text(json.dumps(EDITS,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'edits':len(EDITS),'files':[{'path':p,'bytes':(OUT/p).stat().st_size,'sha256':sha((OUT/p).read_bytes())}for p in sorted(set(r['path']for r in EDITS))]},indent=2))
