from pathlib import Path
import hashlib,json
R=Path(__file__).parent
P='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift'
out=R/'controls/sink-inputs';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def block(text,marker):
 assert text.count(marker)==1
 start=text.index(marker);end=text.index('\n    }\n',start)+len('\n    }\n')
 return text[start:end]
candidate=(R/'candidate'/P).read_text()
original=(R/'controls/preserved-pre-observed-ack-capture/MaktabahNativeRoutingComposition.swift').read_text()
classes='\n'.join(block(candidate,'    private final class '+name+' {')for name in ['ReaderInvocation','CommentaryInvocation','NoteDraftInvocation'])
rows=[]
for name,source in [('initial',original),('candidate',candidate)]:
 methods='\n'.join(block(source,marker)for marker in ['    private func receiveNoteDraft(',
   '    private static func uncertainNativeEffect(', '    private static func nativeUIFailure(', '    private func receiveReader('])
 text=(R/'controls/ReaderToolSinkBoundary.swift').read_text().replace('    // ACTUAL_CLASSES',classes).replace('    // ACTUAL_RECEIVE_BODIES',methods)
 p=out/(name+'-ActualReceiveControls.swift');p.write_text(text)
 rows.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'productionSourceSHA256':sha(source.encode()),
  'exactMethodsSHA256':sha(methods.encode()),'exactClassesSHA256':sha(classes.encode()),
  'initialControl':'Initial receive bodies run against candidate receipt storage so absence of evidence is observable; no receive body change.'if name=='initial'else None})
(R/'controls/SINK_EXTRACT.json').write_text(json.dumps({'sourcePath':P,'files':rows,'scope':'Four exact source bodies; candidate invocation classes unchanged; explicit platform/native/source boundaries.'},indent=2)+'\n')
print(json.dumps(rows,indent=2))
