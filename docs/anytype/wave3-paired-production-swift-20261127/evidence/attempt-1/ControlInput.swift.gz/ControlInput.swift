import Foundation
// Paired acceptance consumes only read-only evidence from the original full-v40
// installer. This policy never supplies a database, workspace, process or app state.
private struct OrdinaryPairedProductionReceipt: Decodable {
    struct Witness: Decodable {
        let path: String
        let bytes: Int64
        let sha256: String
    }
    struct Corpus: Decodable {
        let counts: [String: Int64]
    }
    struct TargetBook: Decodable {
        let book_id: Int64
        let title: String
    }
    let schema: String
    let udid: String
    let bundle_id: String
    let profile: String
    let release_id: Int64
    let data_container: String
    let documents_directory: String
    let data_container_metadata: Witness
    let corpus_owner_container: String
    let corpus_owner_metadata: Witness
    let installed_database: Witness
    let corpus: Corpus
    let installation_manifest: Witness
    let install_receipt: Witness
    let target_book: TargetBook
}

private enum OrdinaryPairedProductionPolicy {
    enum Rejected: Error { case invalid(String) }
    static let bundleID = "com.davidpovarsky.chavrusatext"
    static let databaseBytes: Int64 = 4_355_063_808
    static let databaseSHA256 = "8389709c1702753af6f0719ef1c98c09854450e48ebb05fe1f95486b26348b01"
    // Exact unmodified MaktabahUITestBase.launchWithTier(.production, scenario:nil).
    // smokeBackend here is the original provider-selection argument, not a scenario.
    static let launchArguments = [
        "-OtzariaDataProfile", "production", "-preferredBackend", "otzaria",
        "-smokeBackend", "otzaria", "-AppleLanguages", "(en)", "-AppleLocale", "en_US"
    ]
    static let launchEnvironment = [
        "OTZARIA_DATA_PROFILE": "production", "SIMCTL_CHILD_OTZARIA_DATA_PROFILE": "production"
    ]

    static func require(_ condition: Bool, _ message: String) throws {
        guard condition else { throw Rejected.invalid(message) }
    }

    static func validateRunner(_ environment: [String: String]) throws {
        let forbidden: Set<String> = [
            "OTZARIA_SHARED_ROOT_OVERRIDE", "OTZARIA_PRODUCTION_DB_PATH",
            "OTZARIA_ANNOTATION_ACCEPTANCE_DATABASE", "CHAVRUSA_READER_VIEWPORT_REPORT",
            "FAITHFUL_VIEWPORT_DIRECTORY",
            "OTZARIA_NATIVE_BOOTSTRAP_ACCEPTANCE", "OTZARIA_NATIVE_BOOTSTRAP_RELEASE_ID",
            "OTZARIA_ORIGINAL_EDITOR_QUALIFICATION", "OTZARIA_ORIGINAL_EDITOR_PROCESS_RESUME"
        ]
        for (rawKey, value) in environment {
            var key = rawKey
            while true {
                if key.hasPrefix("TEST_RUNNER_") { key = String(key.dropFirst("TEST_RUNNER_".count)) }
                else if key.hasPrefix("SIMCTL_CHILD_") { key = String(key.dropFirst("SIMCTL_CHILD_".count)) }
                else { break }
            }
            try require(!forbidden.contains(key), "Paired production refuses fixture or storage overrides")
            if key == "OTZARIA_DATA_PROFILE" {
                try require(value == "production", "Paired production refuses a different data profile")
            }
        }
    }

    static func validate(_ receipt: OrdinaryPairedProductionReceipt, actualUDID: String) throws {
        try require(receipt.schema == "otzaria.original.two-full-apps.production.v1"
            && receipt.bundle_id == bundleID && receipt.profile == "production"
            && receipt.release_id == 455_390_662, "Require the original full-v40 production receipt")
        try require(UUID(uuidString: actualUDID) != nil
            && UUID(uuidString: receipt.udid) == UUID(uuidString: actualUDID),
            "Production evidence must belong to the actual XCTest Simulator")
        try require(receipt.installed_database.bytes == databaseBytes
            && receipt.installed_database.sha256 == databaseSHA256
            && receipt.corpus.counts == ["book": 8259, "line": 7_925_185, "link": 7_001_824],
            "Require the independently inspected complete original v40 corpus")
        try require(receipt.target_book.book_id == 103
            && !receipt.target_book.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && receipt.target_book.title.utf8.count <= 1024,
            "Use the exact catalog identity observed by the original production controller")
        for witness in [receipt.data_container_metadata, receipt.corpus_owner_metadata,
                        receipt.installed_database, receipt.installation_manifest, receipt.install_receipt] {
            try require(witness.bytes > 0 && witness.path.hasPrefix("/")
                && witness.sha256.utf8.count == 64
                && witness.sha256.utf8.allSatisfy { (48...57).contains($0) || (97...102).contains($0) },
                "Every production input must retain a bounded, actual file witness")
        }
    }

    static func validateLaunch(arguments: [String], environment: [String: String]) throws {
        try require(arguments == launchArguments && environment == launchEnvironment,
                    "Require the unchanged original production launch without fixture, namespace or app overrides")
    }
}


public enum TestTier: String, Sendable {
    case smoke = "smoke"         // Tier S: fast smoke fixture
    case realUI = "realUI"       // Tier R: normal app bootstrap, no smoke bypass
    case production = "production" // Tier P: full production Otzaria data profile
}

final class XCUIApplication {
    var launchArguments: [String] = []
    var launchEnvironment: [String: String] = [:]
    init(bundleIdentifier: String) {}
    func launch() {}
}
final class OriginalLaunchHost {
    var app: XCUIApplication!
    private let workspaceTestNamespace = UUID().uuidString
    var isolatesStudyWorkspace: Bool { true }
    let workspaceNamespace = UUID().uuidString
    private var viewportURL: URL?
    var readerTestTier: TestTier { .realUI }
    var readerAdditionalLaunchArguments: [String] { [] }
    private func recordRuntime27Configuration(stage: String) {}
    func dismissAlertsIfNeeded() {}
    func launchWithTier(
        _ tier: TestTier,
        scenario: String? = nil,
        backend: String = "sefaria",
        extraArgs: [String] = [],
        language: String = "he",
        locale: String = "he_IL",
        extraEnvironment: [String: String] = [:]
    ) -> XCUIApplication {
        let app = XCUIApplication(bundleIdentifier: "com.davidpovarsky.chavrusatext")
        var args: [String] = []
        var env: [String: String] = [:]

        switch tier {
        case .smoke:
            args += [
                "-OtzariaDataProfile", "miniTest10",
                "-smokeBypassBootstrap"
            ]
            if let scenario {
                args += ["-smokeScenario", scenario]
            }
            args += ["-smokeBackend", backend]
            env["OTZARIA_DATA_PROFILE"] = "miniTest10"
            env["SIMCTL_CHILD_OTZARIA_DATA_PROFILE"] = "miniTest10"

        case .realUI:
            if let scenario {
                args += ["-smokeScenario", scenario]
            }
            args += [
                "-OtzariaDataProfile", "miniTest10"
            ]
            env["OTZARIA_DATA_PROFILE"] = "miniTest10"
            env["SIMCTL_CHILD_OTZARIA_DATA_PROFILE"] = "miniTest10"

        case .production:
            args += [
                "-OtzariaDataProfile", "production",
                "-preferredBackend", backend,
                "-smokeBackend", backend
            ]
            if let scenario {
                args += ["-smokeScenario", scenario]
            }
            env["OTZARIA_DATA_PROFILE"] = "production"
            env["SIMCTL_CHILD_OTZARIA_DATA_PROFILE"] = "production"
            if let sharedRoot = ProcessInfo.processInfo.environment["OTZARIA_SHARED_ROOT_OVERRIDE"] {
                env["OTZARIA_SHARED_ROOT_OVERRIDE"] = sharedRoot
                env["SIMCTL_CHILD_OTZARIA_SHARED_ROOT_OVERRIDE"] = sharedRoot
            }
            if let dbPath = ProcessInfo.processInfo.environment["OTZARIA_PRODUCTION_DB_PATH"] {
                env["OTZARIA_PRODUCTION_DB_PATH"] = dbPath
                env["SIMCTL_CHILD_OTZARIA_PRODUCTION_DB_PATH"] = dbPath
            }
        }

        args += [
            "-AppleLanguages", "(\(language))",
            "-AppleLocale", locale
        ] + extraArgs
        if isolatesStudyWorkspace && tier != .production && !args.contains("-studyWorkspaceTestingNamespace") {
            // Isolate sidecars across independent tests while preserving state
            // across relaunches within a test. All reader features stay enabled.
            args += ["-studyWorkspaceTestingNamespace", workspaceTestNamespace]
        }

        app.launchArguments = args
        env.merge(extraEnvironment) { _, extra in extra }
        for (k, v) in env {
            app.launchEnvironment[k] = v
        }
        app.launch()
        self.app = app
        recordRuntime27Configuration(stage: "launch")
        return app
    }
    func launchReader(enabled: Bool = true, scenario: String = "reader", backend: String = "otzaria", language: String = "he", background: Int = 0, recordViewport: Bool = false, fontSize: Float? = nil) {
        launchReader(enabled: enabled, scenario: scenario, backend: backend, language: language,
                     background: background, recordViewport: recordViewport, fontSize: fontSize,
                     tier: readerTestTier)
    }
    func launchReader(enabled: Bool = true, scenario: String = "reader", backend: String = "otzaria", language: String = "he", background: Int = 0, recordViewport: Bool = false, fontSize: Float? = nil, tier: TestTier) {
        // The downstream observer reads the actual original source anchor;
        // never activate the baseline renderer's crash-prone file exporter.
        let prefix = (recordViewport ? ProcessInfo.processInfo.environment["FAITHFUL_VIEWPORT_DIRECTORY"] : nil).map {
            URL(fileURLWithPath: $0).appendingPathComponent("faithful-\(scenario)-" + UUID().uuidString).path
        }
        viewportURL = prefix.map { URL(fileURLWithPath: $0 + ".viewport.json") }
        // realUI intentionally omits a backend override in launchWithTier.
        // Preserve this helper's requested backend instead of inheriting a
        // previously persisted provider when the feature-off case relaunches.
        let backendArguments = tier == .realUI
            ? ["-preferredBackend", backend, "-smokeBackend", backend] : []
        let workspaceArguments = isolatesStudyWorkspace ? ["-studyWorkspaceTestingNamespace", workspaceNamespace] : []
        launchWithTier(tier, scenario: scenario, backend: backend, extraArgs: backendArguments + workspaceArguments + [
            "-ChavrusaTextFaithfulReaderUIEnabled", enabled ? "YES" : "NO",
            "-textViewBackgroundColorLight", String(background)
        ] + (fontSize.map { ["-textViewFontSize", String($0)] } ?? []) + readerAdditionalLaunchArguments, language: language, locale: language == "he" ? "he_IL" : "en_US",
        extraEnvironment: prefix.map { ["CHAVRUSA_READER_VIEWPORT_REPORT": $0] } ?? [:])
        dismissAlertsIfNeeded()
    }

    func baseline() { launchReader(scenario: "readerDetail", backend: "otzaria", language: "en", recordViewport: true) }
    func candidate() { _ = launchWithTier(.production, scenario: nil, backend: "otzaria", language: "en", locale: "en_US") }
}

@main
struct Controls {
    static func main() throws {
        var rows: [[String: Any]] = []
        func check(_ name: String, _ condition: Bool) {
            rows.append(["name": name, "pass": condition])
        }
        func rejected(_ name: String, _ body: () throws -> Void) {
            do { try body(); check(name, false) } catch { check(name, true) }
        }
        let baseline = CommandLine.arguments.contains("--baseline")
        let app = OriginalLaunchHost()
        if baseline { app.baseline() } else { app.candidate() }
        check("actual-original-launch-uses-production", app.app.launchEnvironment["OTZARIA_DATA_PROFILE"] == "production")
        check("actual-original-launch-omits-smoke-scenario", !app.app.launchArguments.contains("-smokeScenario"))
        check("actual-original-launch-omits-UUID-test-workspace", !app.app.launchArguments.contains("-studyWorkspaceTestingNamespace"))
        do {
            try OrdinaryPairedProductionPolicy.validateLaunch(arguments: app.app.launchArguments, environment: app.app.launchEnvironment)
            check("exact-original-production-launch-contract", true)
        } catch { check("exact-original-production-launch-contract", false) }
        if !baseline {
            let udid = "11111111-1111-4111-8111-111111111111"
            let witness: [String: Any] = ["path": "/source-control-boundary/fixture", "bytes": 123,
                                          "sha256": String(repeating: "a", count: 64)]
            let canonical: [String: Any] = [
                "schema": "otzaria.original.two-full-apps.production.v1",
                "udid": udid, "bundle_id": "com.davidpovarsky.chavrusatext",
                "profile": "production", "release_id": 455390662,
                "data_container": "/source-control-boundary/app",
                "documents_directory": "/source-control-boundary/app/Documents",
                "data_container_metadata": witness,
                "corpus_owner_container": "/source-control-boundary/group",
                "corpus_owner_metadata": witness,
                "installed_database": ["path": "/source-control-boundary/group/Otzaria/seforim.db",
                    "bytes": Int64(4355063808),
                    "sha256": "8389709c1702753af6f0719ef1c98c09854450e48ebb05fe1f95486b26348b01"],
                "corpus": ["counts": ["book": 8259, "line": 7925185, "link": 7001824]],
                "installation_manifest": witness, "install_receipt": witness,
                "target_book": ["book_id": 103, "title": "Actual SQL title boundary"]
            ]
            func validate(_ object: [String: Any], udid: String = udid) throws {
                let bytes = try JSONSerialization.data(withJSONObject: object)
                let receipt = try JSONDecoder().decode(OrdinaryPairedProductionReceipt.self, from: bytes)
                try OrdinaryPairedProductionPolicy.validate(receipt, actualUDID: udid)
            }
            try validate(canonical); check("fixed-complete-v40-source-contract", true)
            for (key, bad) in [
                ("schema", "foreign"), ("bundle_id", "foreign.bundle"),
                ("profile", "miniTest10"), ("udid", "22222222-2222-4222-8222-222222222222")
            ] {
                var object = canonical; object[key] = bad
                rejected("reject-" + key) { try validate(object) }
            }
            var object = canonical; object["release_id"] = 1
            rejected("reject-different-release") { try validate(object) }
            rejected("reject-absent-actual-simulator") { try validate(canonical, udid: "") }
            object = canonical; object.removeValue(forKey: "data_container_metadata")
            rejected("reject-missing-app-owner-witness") { try validate(object) }
            object = canonical; object.removeValue(forKey: "corpus_owner_metadata")
            rejected("reject-missing-corpus-owner-witness") { try validate(object) }
            object = canonical; object.removeValue(forKey: "install_receipt")
            rejected("reject-missing-original-installer-receipt") { try validate(object) }
            for key in ["book", "line", "link"] {
                var changed = canonical
                var counts = ["book": 8259, "line": 7925185, "link": 7001824]
                counts[key] = 10; changed["corpus"] = ["counts": counts]
                rejected("reject-incomplete-corpus-" + key) { try validate(changed) }
            }
            object = canonical; object["corpus"] = ["counts": ["book": 8259, "line": 7925185, "link": 7001824, "other": 1]]
            rejected("reject-foreign-corpus-shape") { try validate(object) }
            for (name, book) in [
                ("different-book", ["book_id": 3891, "title": "Actual SQL title boundary"] as [String: Any]),
                ("empty-title", ["book_id": 103, "title": " \n "] as [String: Any]),
                ("unbounded-title", ["book_id": 103, "title": String(repeating: "x", count: 1025)] as [String: Any])
            ] {
                var changed = canonical; changed["target_book"] = book
                rejected("reject-" + name) { try validate(changed) }
            }
            for (field, value) in [("bytes", Int64(123) as Any), ("sha256", String(repeating: "b", count: 64) as Any)] {
                var changed = canonical
                var database = changed["installed_database"] as! [String: Any]
                database[field] = value; changed["installed_database"] = database
                rejected("reject-installed-database-" + field) { try validate(changed) }
            }
            for (field, value) in [("bytes", 0 as Any), ("path", "relative" as Any),
                                   ("sha256", "invalid" as Any), ("sha256", String(repeating: "G", count: 64) as Any)] {
                var changed = canonical; var invalid = witness; invalid[field] = value
                changed["installation_manifest"] = invalid
                rejected("reject-manifest-witness-" + field + "-" + String(describing: value).prefix(8)) { try validate(changed) }
            }
            try OrdinaryPairedProductionPolicy.validateRunner(["OTZARIA_DATA_PROFILE": "production",
                                                               "TEST_RUNNER_SIMCTL_CHILD_OTZARIA_DATA_PROFILE": "production"])
            check("runner-production-profile-remains-allowed", true)
            let forbidden = [
                "OTZARIA_SHARED_ROOT_OVERRIDE", "OTZARIA_PRODUCTION_DB_PATH",
                "OTZARIA_ANNOTATION_ACCEPTANCE_DATABASE", "CHAVRUSA_READER_VIEWPORT_REPORT",
                "FAITHFUL_VIEWPORT_DIRECTORY",
                "OTZARIA_NATIVE_BOOTSTRAP_ACCEPTANCE", "OTZARIA_NATIVE_BOOTSTRAP_RELEASE_ID",
                "OTZARIA_ORIGINAL_EDITOR_QUALIFICATION", "OTZARIA_ORIGINAL_EDITOR_PROCESS_RESUME"
            ]
            for key in forbidden {
                rejected("reject-runner-presence-" + key) {
                    try OrdinaryPairedProductionPolicy.validateRunner([key: ""])
                }
            }
            for prefix in ["TEST_RUNNER_", "SIMCTL_CHILD_", "TEST_RUNNER_SIMCTL_CHILD_TEST_RUNNER_"] {
                rejected("reject-runner-aliased-storage-" + prefix) {
                    try OrdinaryPairedProductionPolicy.validateRunner([prefix + "OTZARIA_PRODUCTION_DB_PATH": "0"])
                }
                rejected("reject-runner-aliased-mini-profile-" + prefix) {
                    try OrdinaryPairedProductionPolicy.validateRunner([prefix + "OTZARIA_DATA_PROFILE": "miniTest10"])
                }
            }
            for extra in [["-smokeScenario", "readerDetail"], ["-smokeBypassBootstrap"],
                          ["-studyWorkspaceTestingNamespace", udid], ["-foreignFlag"]] {
                rejected("reject-extra-app-arguments-" + extra[0]) {
                    try OrdinaryPairedProductionPolicy.validateLaunch(arguments: app.app.launchArguments + extra,
                                                                      environment: app.app.launchEnvironment)
                }
            }
            var launchEnvironment = app.app.launchEnvironment
            launchEnvironment["OTZARIA_ANYTYPE_NETWORK_UI"] = "test-owned-original-account"
            rejected("reject-network-test-flag-in-app") {
                try OrdinaryPairedProductionPolicy.validateLaunch(arguments: app.app.launchArguments, environment: launchEnvironment)
            }
            launchEnvironment = app.app.launchEnvironment; launchEnvironment["OTZARIA_DATA_PROFILE"] = "miniTest10"
            rejected("reject-app-mini-profile") {
                try OrdinaryPairedProductionPolicy.validateLaunch(arguments: app.app.launchArguments, environment: launchEnvironment)
            }
        }
        let failures = rows.filter { $0["pass"] as? Bool != true }.count
        let result: [String: Any] = [
            "mode": baseline ? "original-donor-launch" : "corrected-production-launch-and-policy",
            "passed": rows.count - failures, "failed": failures, "cases": rows,
            "actual_launch_arguments": app.app.launchArguments,
            "actual_launch_environment": app.app.launchEnvironment,
            "boundary": "Exact original launch source and actual paired receipt policy with explicit XCUIApplication double; no app, MCM, SQLite, UIKit, simulator, network or native acceptance"
        ]
        print(String(decoding: try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys, .prettyPrinted]), as: UTF8.self))
        if failures != 0 { exit(1) }
    }
}
