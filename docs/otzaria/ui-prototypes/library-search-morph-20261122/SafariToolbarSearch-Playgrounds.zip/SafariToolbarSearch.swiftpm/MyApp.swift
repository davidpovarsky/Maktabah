import SwiftUI
import CommandPalette

// Swift Playgrounds App: Safari-like grouped toolbar + expanding CommandPalette.
// The Gelatin-inspired touch physics below never changes brightness or saturation.
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

enum DemoPage: String, CaseIterable, Identifiable {
    case github, chatgpt, documents, collections, home

    var id: String { rawValue }

    var title: String {
        switch self {
        case .github: return "GitHub"
        case .chatgpt: return "ChatGPT"
        case .documents: return "תיעוד"
        case .collections: return "אוספים"
        case .home: return "דף הבית"
        }
    }

    var address: String {
        switch self {
        case .github: return "github.com"
        case .chatgpt: return "chatgpt.com"
        case .documents: return "docs.example"
        case .collections: return "collections.example"
        case .home: return "start.example"
        }
    }

    var icon: String {
        switch self {
        case .github: return "chevron.left.forwardslash.chevron.right"
        case .chatgpt: return "sparkles"
        case .documents: return "doc.text"
        case .collections: return "square.stack"
        case .home: return "house"
        }
    }

    var detail: String {
        switch self {
        case .github: return "מאגר הקוד והפרויקטים שלך"
        case .chatgpt: return "מקום לרעיונות ולשיחות"
        case .documents: return "דוגמאות, מסמכים ומידע"
        case .collections: return "קישורים ופריטים ששמרת"
        case .home: return "נקודת ההתחלה של הדפדפן"
        }
    }
}

@MainActor
final class BrowserDemoState: ObservableObject {
    @Published var currentPage: DemoPage = .github
    @Published var lastCommand = "לא נבחרה עדיין פעולה"
    @Published var selectionCount = 0

    func select(_ title: String) {
        lastCommand = title
        selectionCount += 1
    }

    func visit(_ page: DemoPage) {
        currentPage = page
        select("נפתח: \(page.title)")
    }
}

struct ContentView: View {
    @Namespace private var searchMorph
    @StateObject private var browser = BrowserDemoState()

    @State private var searchIsExpanded = false
    @State private var quickAddress = "github.com"
    @State private var initialSearchQuery = ""
    @FocusState private var quickAddressFocused: Bool

    @State private var showsTabOverview = false
    @State private var showsTabs = true
    @State private var showsSidebar = false
    @State private var showsDownloads = false
    @State private var showsProfile = false

    private let morphSpring = Animation.spring(response: 0.47, dampingFraction: 0.84)

    private var searchCommands: [Command] {
        let model = browser
        return [
            Command("GitHub", id: "web.github", subtitle: "פתח דף לדוגמה", section: "אתרים", symbol: "chevron.left.forwardslash.chevron.right", keywords: ["github", "code"]) {
                model.visit(.github)
            },
            Command("ChatGPT", id: "web.chatgpt", subtitle: "פתח דף לדוגמה", section: "אתרים", symbol: "sparkles", keywords: ["chatgpt", "ai"]) {
                model.visit(.chatgpt)
            },
            Command("דף הבית", id: "web.home", subtitle: "חזרה לדף הראשי", section: "אתרים", symbol: "house", keywords: ["home", "start"]) {
                model.visit(.home)
            },
            Command("בראשית", id: "book.genesis", subtitle: "הספר הראשון בחומש", section: "ספרים", symbol: "book.closed", keywords: ["תורה", "genesis"]) {
                model.select("בראשית")
            },
            Command("שמות", id: "book.exodus", subtitle: "יציאת מצרים", section: "ספרים", symbol: "books.vertical", keywords: ["תורה", "exodus"]) {
                model.select("שמות")
            },
            Command("ויקרא", id: "book.leviticus", subtitle: "הספר השלישי בחומש", section: "ספרים", symbol: "book.closed", keywords: ["תורה", "leviticus"]) {
                model.select("ויקרא")
            },
            Command("במדבר", id: "book.numbers", subtitle: "המסע במדבר", section: "ספרים", symbol: "books.vertical", keywords: ["תורה", "numbers"]) {
                model.select("במדבר")
            },
            Command("דברים", id: "book.deuteronomy", subtitle: "משנה תורה", section: "ספרים", symbol: "book.closed", keywords: ["תורה", "deuteronomy"]) {
                model.select("דברים")
            },
            Command("פתח תרגום", id: "tool.translate", subtitle: "פעולה לדוגמה מתוך החיפוש", section: "פעולות", symbol: "character.book.closed", keywords: ["translate", "שפה"]) {
                model.select("פתח תרגום")
            },
            Command("חפש אנשי קשר", id: "tool.contacts", subtitle: "פעולה לדוגמה מתוך החיפוש", section: "פעולות", symbol: "person.crop.circle", keywords: ["contacts", "אנשים"]) {
                model.select("חפש אנשי קשר")
            },
            Command("צור פתק חדש", id: "tool.note", subtitle: "פעולה לדוגמה", section: "פעולות", symbol: "square.and.pencil", keywords: ["notes", "כתיבה"]) {
                model.select("צור פתק חדש")
            },
            Command("הגדרות", id: "tool.settings", subtitle: "בחירת פעולה לדוגמה", section: "פעולות", symbol: "gearshape", keywords: ["settings", "אפשרויות"]) {
                model.select("הגדרות")
            }
        ]
    }

    var body: some View {
        GeometryReader { geometry in
            let compact = geometry.size.width < 740

            ZStack(alignment: .top) {
                browserScreen
                    .zIndex(0)

                safariToolbar(compact: compact)
                    .padding(.horizontal, compact ? 10 : 19)
                    .padding(.top, 7)
                    .zIndex(1)

                if searchIsExpanded {
                    Color.clear
                        .ignoresSafeArea()
                        .contentShape(Rectangle())
                        .onTapGesture(perform: closeSearch)
                        .transition(.opacity)
                        .zIndex(2)

                    expandedSearch(availableWidth: geometry.size.width)
                        .zIndex(3)
                }
            }
            .animation(morphSpring, value: searchIsExpanded)
        }
        .preferredColorScheme(.light)
        .onChange(of: quickAddressFocused) { _, focused in
            if focused {
                quickAddressFocused = false
                openSearch()
            }
        }
        .onChange(of: browser.currentPage) { _, newPage in
            quickAddress = newPage.address
        }
        .sheet(isPresented: $showsDownloads) {
            SimplePanel(title: "הורדות", symbol: "arrow.down.circle", message: "אין הורדות חדשות בהדגמה הזאת.")
                .presentationDetents([.medium])
        }
        .sheet(isPresented: $showsProfile) {
            SimplePanel(title: "פרופיל אישי", symbol: "person.crop.circle", message: "כאן ניתן לשלב את תפריט המשתמש של האפליקציה שלך.")
                .presentationDetents([.medium])
        }
    }

    // MARK: - Grouped top toolbar

    private func safariToolbar(compact: Bool) -> some View {
        HStack(spacing: compact ? 6 : 11) {
            GlassButtonGroup {
                toolbarButton("square.on.square", title: "הצג את כל הכרטיסיות") {
                    withAnimation(.smooth(duration: 0.25)) { showsTabOverview.toggle() }
                }
                toolbarButton("plus", title: "כרטיסייה חדשה") {
                    browser.visit(.home)
                    showsTabOverview = false
                }
                if !compact {
                    ShareLink(item: "https://github.com/halilozel1903/CommandPalette") {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 19, weight: .regular))
                            .frame(width: 39, height: 44)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("שתף קישור")
                    toolbarButton("arrow.down", title: "הורדות") {
                        showsDownloads = true
                    }
                }
            }

            if !searchIsExpanded {
                compactSearchField
                    .frame(maxWidth: .infinity)
                    .matchedGeometryEffect(
                        id: "browser.search.surface",
                        in: searchMorph,
                        properties: .frame,
                        anchor: .top
                    )
            } else {
                // Preserve the exact compact search location during the morph.
                Color.clear
                    .frame(height: 52)
                    .frame(maxWidth: .infinity)
                    .accessibilityHidden(true)
            }

            if !compact {
                GlassButtonGroup {
                    toolbarButton("chevron.left", title: "חזור לכרטיסייה הקודמת") {
                        browser.visit(.github)
                    }
                }
            }

            GlassButtonGroup {
                Button {
                    showsProfile = true
                } label: {
                    HStack(spacing: 5) {
                        if !compact { Text("אישי").font(.system(size: 15, weight: .medium)) }
                        Image(systemName: "person.crop.circle.fill")
                            .font(.system(size: 20))
                    }
                    .frame(height: 44)
                    .padding(.horizontal, compact ? 5 : 10)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("פרופיל אישי")
            }

            GlassButtonGroup {
                toolbarButton("sidebar.left", title: "הצג או הסתר סרגל צד") {
                    withAnimation(.smooth(duration: 0.24)) { showsSidebar.toggle() }
                }
            }
        }
        .environment(\.layoutDirection, .leftToRight)
        .frame(height: 54)
    }

    private var compactSearchField: some View {
        HStack(spacing: 11) {
            Image(systemName: "arrow.clockwise")
                .font(.system(size: 17, weight: .medium))
                .foregroundStyle(.secondary)

            TextField("חיפוש או הזנת כתובת", text: $quickAddress)
                .textFieldStyle(.plain)
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(.primary)
                .multilineTextAlignment(.center)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
                .focused($quickAddressFocused)
                .submitLabel(.search)
                .onSubmit(openSearch)
                .accessibilityLabel("חיפוש או הזנת כתובת")

            Image(systemName: "magnifyingglass")
                .font(.system(size: 18, weight: .regular))
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 16)
        .frame(height: 52)
        .contentShape(RoundedRectangle(cornerRadius: 26))
        .onTapGesture(perform: openSearch)
        .modifier(SafariGlass(radius: 26))
        .environment(\.layoutDirection, .leftToRight)
    }

    private func toolbarButton(_ symbol: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 19, weight: .regular))
                .frame(width: 39, height: 44)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
    }

    // MARK: - One search field expands into the existing CommandPalette

    private func expandedSearch(availableWidth: CGFloat) -> some View {
        CommandPaletteView(
            commands: searchCommands,
            placeholder: "חפש ספר, אתר או פעולה…",
            initialQuery: initialSearchQuery,
            autofocus: true,
            onDismiss: closeSearch
        )
        .environment(\.layoutDirection, .rightToLeft)
        .gelatinMotionOnly()
        .frame(maxWidth: min(CGFloat(690), availableWidth - 30))
        .matchedGeometryEffect(
            id: "browser.search.surface",
            in: searchMorph,
            properties: .frame,
            anchor: .top
        )
        .padding(.top, 6)
        .frame(maxWidth: .infinity, alignment: .top)
    }

    private func openSearch() {
        guard !searchIsExpanded else { return }
        let entered = quickAddress.trimmingCharacters(in: .whitespacesAndNewlines)
        initialSearchQuery = entered == browser.currentPage.address ? "" : entered
        quickAddressFocused = false
        withAnimation(morphSpring) { searchIsExpanded = true }
    }

    private func closeSearch() {
        guard searchIsExpanded else { return }
        withAnimation(morphSpring) { searchIsExpanded = false }
        quickAddress = browser.currentPage.address
    }

    // MARK: - Illustrative browser screen under the toolbar

    private var browserScreen: some View {
        VStack(spacing: 0) {
            Color.clear.frame(height: 74)

            if showsTabs { tabStrip }
            Rectangle().fill(Color.primary.opacity(0.07)).frame(height: 1)

            HStack(spacing: 0) {
                if showsSidebar {
                    sidebar
                        .transition(.move(edge: .leading).combined(with: .opacity))
                }

                if showsTabOverview {
                    tabOverview
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    browserPageContent
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
        }
        .background(Color(uiColor: .systemBackground))
    }

    private var tabStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(DemoPage.allCases) { page in
                    Button {
                        browser.visit(page)
                        showsTabOverview = false
                    } label: {
                        HStack(spacing: 7) {
                            Image(systemName: page.icon).font(.system(size: 13))
                            Text(page.title)
                                .font(.system(size: 14, weight: page == browser.currentPage ? .semibold : .regular))
                                .lineLimit(1)
                            if page == browser.currentPage {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.system(size: 12))
                                    .foregroundStyle(.tertiary)
                            }
                        }
                        .foregroundStyle(page == browser.currentPage ? .primary : .secondary)
                        .padding(.horizontal, 14)
                        .frame(height: 34)
                        .background(page == browser.currentPage ? Color(uiColor: .secondarySystemGroupedBackground) : Color.clear, in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 7)
        }
        .environment(\.layoutDirection, .leftToRight)
        .background(Color(uiColor: .systemGroupedBackground).opacity(0.7))
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("כרטיסיות")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.horizontal, 12)
                .padding(.bottom, 12)
            ForEach(DemoPage.allCases) { page in
                Button {
                    browser.visit(page)
                    showsTabOverview = false
                } label: {
                    Label(page.title, systemImage: page.icon)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                        .background(page == browser.currentPage ? Color.accentColor.opacity(0.09) : .clear, in: RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
                .foregroundStyle(.primary)
            }
            Spacer()
        }
        .frame(width: 200)
        .padding(13)
        .background(Color(uiColor: .secondarySystemBackground))
        .environment(\.layoutDirection, .rightToLeft)
    }

    private var tabOverview: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("כל הכרטיסיות")
                    .font(.system(size: 27, weight: .bold))
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 185), spacing: 14)], spacing: 14) {
                    ForEach(DemoPage.allCases) { page in
                        Button {
                            browser.visit(page)
                            withAnimation(.smooth(duration: 0.25)) { showsTabOverview = false }
                        } label: {
                            VStack(alignment: .leading, spacing: 12) {
                                Image(systemName: page.icon).font(.system(size: 27))
                                Spacer(minLength: 18)
                                Text(page.title).font(.headline)
                                Text(page.address).font(.caption).foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .frame(height: 145)
                            .padding(18)
                            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20))
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(.primary)
                    }
                }
            }
            .frame(maxWidth: 900)
            .padding(28)
            .frame(maxWidth: .infinity)
            .environment(\.layoutDirection, .rightToLeft)
        }
        .background(Color(uiColor: .systemGroupedBackground))
    }

    private var browserPageContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack(spacing: 15) {
                    Image(systemName: browser.currentPage.icon)
                        .font(.system(size: 27, weight: .medium))
                        .frame(width: 58, height: 58)
                        .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))

                    VStack(alignment: .leading, spacing: 5) {
                        Text(browser.currentPage.title)
                            .font(.system(size: 31, weight: .bold, design: .rounded))
                        Text(browser.currentPage.detail)
                            .font(.body)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                }

                Rectangle()
                    .fill(Color.primary.opacity(0.08))
                    .frame(height: 1)

                VStack(alignment: .leading, spacing: 12) {
                    Text("סרגל כלים בסגנון Safari")
                        .font(.system(size: 22, weight: .semibold))
                    Text("לחץ על שדה החיפוש במרכז סרגל הכלים. השדה יתרחב לחלון CommandPalette המקורי, עם תנועה אלסטית בהשראת Gelatin וללא שינוי צבע בזמן המגע.")
                        .font(.system(size: 16))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                HStack(alignment: .top, spacing: 12) {
                    featureCard(symbol: "square.grid.2x2", heading: "קבוצות כפתורים", caption: "רקע זכוכית משותף בכל קבוצה")
                    featureCard(symbol: "arrow.up.left.and.arrow.down.right", heading: "הרחבה רציפה", caption: "אותו שדה הופך לחלון החיפוש")
                    featureCard(symbol: "hand.draw", heading: "Elastic Motion", caption: "מתיחה וקפיץ, ללא הדגשת צבע")
                }

                VStack(alignment: .leading, spacing: 9) {
                    Text("הפעולה האחרונה שנבחרה")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Text(browser.lastCommand)
                        .font(.title3.weight(.medium))
                    Text("בחירות שבוצעו: \(browser.selectionCount)")
                        .font(.footnote)
                        .foregroundStyle(.tertiary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(20)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20))
            }
            .frame(maxWidth: 950)
            .padding(.horizontal, 30)
            .padding(.top, 48)
            .padding(.bottom, 40)
            .frame(maxWidth: .infinity, alignment: .top)
            .environment(\.layoutDirection, .rightToLeft)
        }
    }

    private func featureCard(symbol: String, heading: String, caption: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: symbol)
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(.secondary)
            Text(heading)
                .font(.system(size: 15, weight: .semibold))
            Text(caption)
                .font(.system(size: 13))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, minHeight: 116, alignment: .topLeading)
        .padding(17)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
    }
}

// A single Liquid Glass backing per toolbar group (iPadOS 26+), with a material fallback.
private struct SafariGlass: ViewModifier {
    let radius: CGFloat

    @ViewBuilder
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular, in: shape)
        } else {
            content
                .background(.regularMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.09), lineWidth: 0.7))
        }
    }
}

private struct GlassButtonGroup<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        HStack(spacing: 0) {
            content
        }
        .padding(.horizontal, 5)
        .frame(height: 52)
        .modifier(SafariGlass(radius: 26))
    }
}

// Local adaptation of the movement/press behavior from Polarizz/Gelatin (MIT).
// Color adjustments are deliberately ABSENT: no brightness or saturation changes.
private struct GelatinMotionOnly: ViewModifier {
    @State private var currentOffset: CGSize = .zero
    @State private var currentStretch: CGSize = CGSize(width: 1, height: 1)
    @State private var isPressed = false

    func body(content: Content) -> some View {
        content
            .offset(currentOffset)
            .scaleEffect(x: currentStretch.width, y: currentStretch.height)
            .scaleEffect(isPressed ? CGFloat(1.01) : CGFloat(1))
            .simultaneousGesture(dragGesture)
            .simultaneousGesture(pressGesture)
    }

    private var dragGesture: some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .global)
            .onChanged { value in
                let x = ease(value.translation.width)
                let y = ease(value.translation.height)
                let limit: CGFloat = 130
                let strength: CGFloat = 0.12
                let xRatio: CGFloat = min(abs(x) / limit, CGFloat(1))
                let scaleX: CGFloat = CGFloat(1) + strength * xRatio
                let yRatio: CGFloat = min(abs(y) / limit, CGFloat(1))
                let scaleY: CGFloat = CGFloat(1) + strength * yRatio

                withAnimation(.smooth(duration: 0.22)) {
                    currentOffset = CGSize(width: x, height: y)
                    currentStretch = CGSize(width: scaleX, height: scaleY)
                }
            }
            .onEnded { _ in
                withAnimation(.smooth(duration: 0.55, extraBounce: 0.45)) {
                    currentOffset = .zero
                    currentStretch = CGSize(width: 1, height: 1)
                }
            }
    }

    private var pressGesture: some Gesture {
        DragGesture(minimumDistance: 0, coordinateSpace: .global)
            .onChanged { _ in
                withAnimation(.smooth(duration: 0.20)) { isPressed = true }
            }
            .onEnded { _ in
                withAnimation(.smooth(duration: 0.3, extraBounce: 0.3)) { isPressed = false }
            }
    }

    private func ease(_ input: CGFloat) -> CGFloat {
        guard input != 0 else { return 0 }
        let magnitude = pow(Double(abs(input)), 0.5)
        let direction: CGFloat = input < 0 ? CGFloat(-1) : CGFloat(1)
        return CGFloat(magnitude) * direction
    }
}

private extension View {
    func gelatinMotionOnly() -> some View {
        modifier(GelatinMotionOnly())
    }
}

private struct SimplePanel: View {
    let title: String
    let symbol: String
    let message: String
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: symbol)
                .font(.system(size: 42, weight: .light))
                .foregroundStyle(.secondary)
            Text(title).font(.title2.weight(.semibold))
            Text(message)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button("סגור") { dismiss() }
                .buttonStyle(.borderedProminent)
        }
        .padding(32)
    }
}
