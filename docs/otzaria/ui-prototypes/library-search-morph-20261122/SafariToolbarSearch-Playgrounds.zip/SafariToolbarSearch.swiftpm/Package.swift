// swift-tools-version: 6.2
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "SafariToolbarSearch",
    platforms: [.iOS("17.0")],
    products: [
        .iOSApplication(
            name: "SafariToolbarSearch",
            targets: ["AppModule"],
            bundleIdentifier: "com.example.safaritoolbarsearch",
            displayVersion: "1.0",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .pencil),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [.pad, .phone],
            supportedInterfaceOrientations: [.portrait, .landscapeRight, .landscapeLeft]
        )
    ],
    dependencies: [
        .package(url: "https://github.com/halilozel1903/CommandPalette.git", branch: "main")
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            dependencies: [
                .product(name: "CommandPalette", package: "CommandPalette")
            ],
            path: ".",
            sources: ["MyApp.swift"]
        )
    ]
)
