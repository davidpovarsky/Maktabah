Safari Toolbar Search - Swift Playgrounds on iPad

Open the SafariToolbarSearch.swiftpm folder in Swift Playgrounds.
The real application code is in MyApp.swift (~25 KB), including:
- Safari-like Liquid Glass toolbar button groups
- An editable compact search/address field
- SwiftUI matched-geometry expansion into the original CommandPaletteView
- Embedded, color-neutral Gelatin-inspired elastic drag-and-press animation
- Functional tab overview, example tabs, sidebar, downloads/profile sheets

The original CommandPalette package is declared as a SwiftPM dependency:
https://github.com/halilozel1903/CommandPalette
Internet connection is needed once for Swift Playgrounds to fetch that dependency.
Gelatin is a local adaptation from its MIT-licensed animation logic; there is no separate Gelatin package dependency.
No on-screen animation settings or color highlights are included.

Important: iPadOS 26 or later gets native Liquid Glass. Older iOS gets Material fallback.
If pasting MyApp.swift into an existing App Playground, ensure there is exactly one @main App in the whole project.

Source credits: CommandPalette by halilozel1903 (MIT) and Gelatin by Polarizz (MIT).
