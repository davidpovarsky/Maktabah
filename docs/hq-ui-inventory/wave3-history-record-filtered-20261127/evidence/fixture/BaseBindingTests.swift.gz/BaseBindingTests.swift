@MainActor @Observable private final class BoundaryForeignPresentation { var value = false }

@MainActor private final class RecordBindingFixture {
    typealias Kind = NativeHistoryRecordIntentService.Kind
    let manager: iOSNavigationManager
    let workspace: StudyWorkspaceNavigationAdapter
    let workspaceSource: MaktabahNativeWorkspaceProjectionSource
    let workspacePresentation = MaktabahNativeWorkspacePresentationBinding()
    let model = HistoryViewModel.shared
    let store: QualifiedLocatorStore
    let book: BooksData
    let kind: Kind
    let rootPublications: MaktabahNativeRootPublicationSource
    let scene = UIStableID(rawValue: "original-scene")!
    let request = UUID(), rootToken = UUID()
    var rowToken = UUID()
    let window = UIWindow(), rootView = UIView(), rowView = UIView(), content = UIView(), scroll = UIScrollView()
    let scrollOwner = MaktabahNativeHistoryScrollOwner()
    let foreign = BoundaryForeignPresentation()
    var record: NativeHistoryRecordIntentService.Record!
    var tab: iOSTab
    var settings = false, foreground = true, lifetime = true
    var selectedCalls = 0, verticalCalls = 0, horizontalCalls = 0, reports = 0, graphChanges = 0
    var onSelect: (() -> Void)?, onVertical: (() -> Void)?, onValidate: (() -> Void)?
    lazy var bindings = MaktabahNativeSceneBindings(manager: manager,
        selectedTab: rootPublications.selectionBinding(Binding(get: { [unowned self] in tab }, set: { [unowned self] in
            tab = $0; selectedCalls += 1; onSelect?()
        })), showSettings: rootPublications.settingsBinding(Binding(get: { [unowned self] in settings }, set: { [unowned self] in settings = $0 })),
        rootPublications: rootPublications)
    lazy var binding = MaktabahNativeHistoryRecordBinding(sceneID: scene, bindings: bindings,
        workspaceSource: workspaceSource, workspacePresentation: workspacePresentation,
        commonReady: { [unowned self] in !settings && !foreign.value },
        windowReady: { [unowned self] in foreground && window.isKeyWindow
            && window.rootViewController?.presentedViewController == nil
            && window.rootViewController?.transitionCoordinator == nil },
        readForeignPresentations: { [unowned self] in _ = foreign.value })

    init(pad: Bool = false, kind: Kind = .history, warm: Bool = false,
         selectionSeed: UInt64? = 0, settingsSeed: UInt64? = 0,
         modeSeed: UInt64? = 0, bookSeed: UInt64? = 0) async throws {
        self.kind = kind; tab = warm ? .history : .viewer
        MaktabahApp.isIpad = pad
        let backend = BackendCoordinator.shared
        backend.activeBackendID = .otzaria; backend.generation = 1
        backend.activeTransitionToken = 1; backend.isTransitioning = false; backend.usesNativeMaktabahDataPath = false
        DonationManager.shared.showDonationSheet = false
        manager = iOSNavigationManager(modeSeed: modeSeed, bookSeed: bookSeed)
        rootPublications = .init(boundarySelection: selectionSeed, boundarySettings: settingsSeed)
        workspace = StudyWorkspaceNavigationAdapter(manager)
        workspaceSource = MaktabahNativeWorkspaceProjectionSource(workspace)
        let locator = TextLocator(backend: .otzaria, workKey: "book:3891", position: .legacyLine(523))
        book = BooksData(id: 3891, book: "Original title", locator: locator)
        let directory = URL(fileURLWithPath: ProcessInfo.processInfo.environment["HISTORY_RECORD_CONTROL_OUTPUT"]!, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        store = QualifiedLocatorStore(fileURL: directory.appendingPathComponent("record-\(UUID()).json"))
        if warm { manager.currentMode = .history }
        let tabID = UUID()
        manager.openTabs = [.init(id: tabID, book: book, viewModel: ReaderViewModel())]
        manager.activeTabId = tabID
        if !warm { manager.selectedBook = book }
        if kind == .favorite { try await store.setFavorite(true, locator: locator, title: book.book) }
        else { try await store.record(locator, title: book.book) }
        model.invalidateQualifiedPublication(); model.searchText = ""
        model.historyOrder = [book.id]; model.entriesByBookId = [book.id: 523]
        model.historyBooks = [book]; model.favoriteBooks = kind == .favorite ? [book] : []
        let load = model.beginQualifiedPublication(), entries = await store.entriesWithObservation()
        model.completeQualifiedPublication(load, entries: entries)
        let card = try XCTUnwrap(kind == .history ? model.qualifiedPublication?.history.first : model.qualifiedPublication?.favorites.first)
        record = try MaktabahNativeHistoryRecords.record(card, kind: kind)
        window.bounds = CGRect(x: 0, y: 0, width: 800, height: 900)
        window.rootViewController?.view.bounds = window.bounds
        window.rootViewController?.view.window = window
        window.rootViewController?.view.superview = window
        rootView.bounds = window.bounds; rootView.window = window; rootView.superview = window.rootViewController?.view
        scroll.bounds = CGRect(x: 0, y: 0, width: 600, height: 100)
        scroll.window = window; scroll.superview = rootView
        content.window = window; content.superview = scroll
        rowView.window = window; rowView.superview = content; rowView.offset.x = 1800
        scrollOwner.attach(scrollView: scroll, contentView: content) { [unowned self] _ in
            horizontalCalls += 1; rowView.offset.x = 20
        }
        binding.install(changed: { [unowned self] in graphChanges += 1 }, invalidated: {})
    }
    func retain() throws { try binding.retain(record: record, requestID: request) }
    func begin() throws {
        try binding.begin(requestID: request) { [unowned self] in
            onValidate?()
            guard lifetime, foreground else { throw UIRouteError(.staleState, "boundary_grant_expired") }
        }
    }
    func prepare() throws { try retain(); try begin(); try binding.apply(requestID: request) }
    func publishMode() { manager.currentMode = tab.appMode; binding.renderOriginalContainer() }
    func mountRoot(token: UUID? = nil, view: UIView? = nil) {
        binding.attachRoot(token: token ?? rootToken, view: view ?? rootView, model: model) { [unowned self] _, _ in
            verticalCalls += 1; if kind == .favorite { rowView.offset.x = 20 }; onVertical?()
        }
    }
    func mountRow(token: UUID? = nil, blocked: Bool = false) {
        binding.observeRow(token: token ?? rowToken, root: rootToken, kind: kind, book: book,
                           view: rowView, scroll: kind == .history ? scrollOwner : nil, blocked: blocked)
    }
    func mount(rowFirst: Bool = false) {
        if rowFirst { mountRow(); mountRoot() } else { mountRoot(); mountRow() }
    }
    func reveal() throws { try prepare(); if tab != .viewer && manager.currentMode != tab.appMode { publishMode() }; mount() }
    func report() throws { try binding.withValidatedRecord(requestID: request) { reports += 1 } }
    func complete() throws {
        try report(); binding.finish(requestID: request, completed: true); binding.releaseSource(requestID: request)
    }
}

// Same-file access only for a deliberately synchronous reentrant metadata
// invalidation. This is not a new app API or an actor mutation by the router.
extension HistoryQualifiedPublication {
    func boundaryAdvanceActorMetadata() { observation.source.willChange() }
}

@MainActor final class HistoryRecordBindingSourceTests: XCTestCase, @unchecked Sendable {
    func testColdPhoneWaitsForOriginalPublisherAndRevealsOriginalRowOnce() async throws {
        let h = try await RecordBindingFixture(), selected = h.manager.selectedBookPresentationRevision
        try h.prepare(); h.mount()
        XCTAssertNil(try h.binding.observedItem()); XCTAssertEqual(h.verticalCalls, 0)
        XCTAssertNil(h.manager.selectedBook)
        XCTAssertEqual(h.manager.selectedBookPresentationRevision, selected.map { $0 + 1 })
        h.publishMode()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        try h.complete()
        XCTAssertEqual(h.selectedCalls, 1); XCTAssertEqual(h.verticalCalls, 1); XCTAssertEqual(h.horizontalCalls, 1)
        XCTAssertEqual(h.reports, 1); XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
    }
    func testColdIPadKeepsOriginalReaderOwnerAndBookPublication() async throws {
        let h = try await RecordBindingFixture(pad: true), selected = h.manager.selectedBook, revision = h.manager.selectedBookPresentationRevision
        try h.reveal(); try h.complete()
        XCTAssertTrue(h.manager.selectedBook === selected); XCTAssertEqual(h.manager.selectedBookPresentationRevision, revision)
    }
    func testWarmFavoriteUsesZeroParentWritesAndNoHorizontalMutation() async throws {
        let h = try await RecordBindingFixture(kind: .favorite, warm: true)
        h.mount(); let mode = h.manager.nativeModePresentationRevision, book = h.manager.selectedBookPresentationRevision
        try h.reveal(); try h.complete()
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.horizontalCalls, 0); XCTAssertEqual(h.verticalCalls, 1)
        XCTAssertEqual(h.manager.nativeModePresentationRevision, mode); XCTAssertEqual(h.manager.selectedBookPresentationRevision, book)
    }
    func testOriginalPrivateQueryAndPublishedCardsRemainUnchanged() async throws {
        let h = try await RecordBindingFixture(); h.model.searchText = "Original"
        let original = h.model.historyBooks, entries = await h.store.entries()
        try h.reveal(); try h.complete()
        XCTAssertEqual(h.model.searchText, "Original"); XCTAssertTrue(h.model.historyBooks[0] === original[0])
        let after = await h.store.entries(); XCTAssertEqual(after, entries)
    }
    func testOriginalModelABAIsRejectedBeforeBegin() async throws {
        for key in ["query", "array", "order", "entries"] {
            let h = try await RecordBindingFixture(); try h.retain()
            switch key {
            case "query": h.model.searchText = "changed"; h.model.searchText = ""
            case "array": h.model.historyBooks = []; h.model.historyBooks = [h.book]
            case "order": h.model.historyOrder = []; h.model.historyOrder = [h.book.id]
            default: h.model.entriesByBookId = [:]; h.model.entriesByBookId = [h.book.id: 523]
            }
            XCTAssertThrowsError(try h.begin(), key)
        }
    }
    func testWorkspaceIdentityMappingAndLocalStatePublicationRetire() async throws {
        for key in ["owner", "mapping", "epoch", "localState"] {
            let h = try await RecordBindingFixture(); try h.retain()
            switch key {
            case "owner": h.workspaceSource.current = StudyWorkspaceNavigationAdapter(h.manager); h.workspaceSource.current = h.workspace
            case "mapping": h.workspace.mappingOwnershipSource.event = 2; h.workspace.mappingOwnershipSource.event = 1
            case "epoch": h.workspace.epoch.revision += 1
            default: h.workspacePresentation.originalStateRevision = 1
            }
            XCTAssertThrowsError(try h.begin(), key)
        }
    }
    func testAbortedBackendPublicationAndGenerationABARevoke() async throws {
        for eventOnly in [false, true] {
            let h = try await RecordBindingFixture(); try h.retain()
            if eventOnly { BackendCoordinator.shared.objectWillChange.send(()) }
            else {
                BackendCoordinator.shared.activeBackendID = .sefaria; BackendCoordinator.shared.generation += 1
                BackendCoordinator.shared.activeBackendID = .otzaria; BackendCoordinator.shared.generation += 1
            }
            XCTAssertThrowsError(try h.begin())
        }
    }
    func testOriginalActorMutationRetiresSourceBeforeReload() async throws {
        let h = try await RecordBindingFixture(); try h.retain()
        do { try await h.store.setFavorite(true, locator: h.book.backendLocator!, title: h.book.book) }
        catch { print("OBSERVED original Foundation persistence error: \(error)") }
        XCTAssertThrowsError(try h.begin()); XCTAssertEqual(h.model.historyBooks.count, 1)
    }
    func testUnqualifiedAndAmbiguousOriginalCardsNeverBecomeRecords() async throws {
        let h = try await RecordBindingFixture(); h.model.invalidateQualifiedPublication()
        XCTAssertTrue(try MaktabahNativeHistoryRecords.catalog().isEmpty)
        XCTAssertThrowsError(try h.retain())
        let load = h.model.beginQualifiedPublication(), entries = await h.store.entriesWithObservation()
        h.model.historyBooks = [h.book, h.book]; h.model.completeQualifiedPublication(load, entries: entries)
        XCTAssertNil(h.model.qualifiedPublication); XCTAssertThrowsError(try h.retain())
    }
    func testMountBeforeCanonicalApplyCannotJoinRetainedRequest() async throws {
        let h = try await RecordBindingFixture(); try h.retain(); h.mountRoot()
        XCTAssertThrowsError(try h.begin()); XCTAssertNil(try? h.binding.observedItem())
    }
    func testRowBeforeColdRootJoinsOnlySameAppliedOwner() async throws {
        let h = try await RecordBindingFixture(); try h.prepare(); h.publishMode(); h.mount(rowFirst: true)
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID); try h.complete()
    }
    func testRootAndRowReplacementOrDetachRevoke() async throws {
        for key in ["rootToken", "rootView", "rootDetach", "rowToken", "rowDetach"] {
            let h = try await RecordBindingFixture(); try h.reveal()
            switch key {
            case "rootToken": h.mountRoot(token: UUID())
            case "rootView": let view = UIView(); view.window = h.window; h.mountRoot(view: view)
            case "rootDetach": h.binding.detachRoot(token: h.rootToken, view: h.rootView); h.mountRoot()
            case "rowToken": h.mountRow(token: UUID())
            default: h.binding.detachRow(token: h.rowToken, kind: h.kind, book: h.book); h.mountRow()
            }
            XCTAssertThrowsError(try h.report(), key)
        }
    }
    func testOriginalRowGeometryIsRequiredAfterParentReveal() async throws {
        for key in ["offscreen", "hidden", "alpha", "clip", "drag", "decelerate", "foreignScene", "background", "nonKey", "modal", "transition"] {
            let h = try await RecordBindingFixture(); try h.reveal()
            XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
            switch key {
            case "offscreen": h.rowView.offset.x = 1800
            case "hidden": h.rowView.isHidden = true
            case "alpha": h.rowView.alpha = 0.5
            case "clip": h.content.clipsToBounds = true; h.content.bounds.size.width = 10
            case "drag": h.scroll.isDragging = true
            case "decelerate": h.scroll.isDecelerating = true
            case "foreignScene": h.window.windowScene?.session.persistentIdentifier = "other-scene"
            case "background": h.window.windowScene?.activationState = .background
            case "nonKey": h.window.isKeyWindow = false
            case "modal": h.window.rootViewController?.presentedViewController = UIViewController()
            default: h.window.rootViewController?.transitionCoordinator = NSObject()
            }
            XCTAssertNil(try? h.binding.observedItem(), key); XCTAssertThrowsError(try h.report(), key)
        }
    }
    func testRootWithoutExactRowCannotReportAnItem() async throws {
        let h = try await RecordBindingFixture(); try h.prepare(); h.publishMode(); h.mountRoot()
        XCTAssertNil(try h.binding.observedItem()); XCTAssertThrowsError(try h.report()); XCTAssertEqual(h.reports, 0)
    }
    func testSettingsAndRootSelectionABAOrEqualPublicationRefuse() async throws {
        for key in ["settingsABA", "settingsEqual", "tabABA", "tabEqual", "modeABA", "modeEqual", "bookEqual"] {
            let h = try await RecordBindingFixture(); try h.retain()
            switch key {
            case "settingsABA": h.bindings.showSettings.wrappedValue = true; h.bindings.showSettings.wrappedValue = false
            case "settingsEqual": h.bindings.showSettings.wrappedValue = false
            case "tabABA": h.bindings.selectedTab.wrappedValue = .search; h.bindings.selectedTab.wrappedValue = .viewer
            case "tabEqual": h.bindings.selectedTab.wrappedValue = .viewer
            case "modeABA": h.manager.currentMode = .search; h.manager.currentMode = .viewer
            case "modeEqual": h.manager.currentMode = .viewer
            default: h.manager.selectedBook = h.book
            }
            XCTAssertThrowsError(try h.begin(), key)
        }
    }
    func testSettingsAndOriginalOverlaysAreNotDismissed() async throws {
        for key in ["settings", "donation", "info", "readerPopover", "foreign"] {
            let h = try await RecordBindingFixture()
            switch key {
            case "settings": h.bindings.showSettings.wrappedValue = true
            case "donation": DonationManager.shared.showDonationSheet = true
            case "info": h.manager.selectedBookForInfo = h.book
            case "readerPopover": h.manager.activeReaderViewModel?.isPopoverPresented = true
            default: h.foreign.value = true
            }
            XCTAssertThrowsError(try h.retain(), key); XCTAssertEqual(h.selectedCalls, 0)
            if key == "settings" { XCTAssertTrue(h.settings) }
        }
    }
    func testMetadataExhaustionPermanentlyRefuses() async throws {
        for key in ["selection", "settings", "mode", "book", "workspace"] {
            let h = try await RecordBindingFixture(selectionSeed: key == "selection" ? nil : 0,
                settingsSeed: key == "settings" ? nil : 0, modeSeed: key == "mode" ? nil : 0,
                bookSeed: key == "book" ? nil : 0)
            if key == "workspace" { h.workspacePresentation.originalStateRevision = nil }
            XCTAssertThrowsError(try h.retain(), key)
        }
        let h = try await RecordBindingFixture(selectionSeed: .max)
        XCTAssertThrowsError(try h.retain()); h.bindings.selectedTab.wrappedValue = .viewer
        XCTAssertNil(h.rootPublications.selectionRevision); XCTAssertThrowsError(try h.retain())
    }
    func testLifetimeExpiryBeforeBeginBeforeRenderAndBeforeReportCannotRegrant() async throws {
        let before = try await RecordBindingFixture(); try before.retain(); before.lifetime = false
        XCTAssertThrowsError(try before.begin())
        let render = try await RecordBindingFixture(); try render.prepare(); render.lifetime = false; render.publishMode(); render.mount()
        XCTAssertThrowsError(try render.report()); XCTAssertEqual(render.reports, 0)
        let report = try await RecordBindingFixture(); try report.reveal(); report.lifetime = false
        XCTAssertThrowsError(try report.report()); XCTAssertEqual(report.reports, 0)
    }
    func testReentrantReleaseAtLifetimeAndParentCallbackCannotRenewSource() async throws {
        let begin = try await RecordBindingFixture(); try begin.retain()
        begin.onValidate = { [unowned begin] in begin.binding.releaseSource(requestID: begin.request) }
        XCTAssertThrowsError(try begin.begin())
        let apply = try await RecordBindingFixture(); try apply.retain(); try apply.begin()
        apply.onSelect = { [unowned apply] in apply.binding.releaseSource(requestID: apply.request) }
        XCTAssertThrowsError(try apply.binding.apply(requestID: apply.request)); XCTAssertEqual(apply.reports, 0)
    }
    func testReentrantOriginalScrollRetirementPreventsReport() async throws {
        let h = try await RecordBindingFixture()
        h.onVertical = { [unowned h] in h.binding.retire() }
        try h.prepare(); h.publishMode(); h.mount()
        XCTAssertThrowsError(try h.report()); XCTAssertEqual(h.reports, 0); XCTAssertEqual(h.verticalCalls, 1)
    }
    func testReportSourceMembershipIsRevalidatedAfterCallback() async throws {
        let h = try await RecordBindingFixture(); try h.reveal()
        var callbacks = 0
        XCTAssertThrowsError(try h.binding.withValidatedRecord(requestID: h.request) {
            callbacks += 1; h.binding.releaseSource(requestID: h.request)
        })
        XCTAssertEqual(callbacks, 1); XCTAssertThrowsError(try h.report())
    }
    func testActorPublicationLockRejectsReentrantMetadataMutation() async throws {
        let h = try await RecordBindingFixture(); try h.reveal()
        let publication = try XCTUnwrap(h.model.qualifiedPublication)
        XCTAssertThrowsError(try h.binding.withValidatedRecord(requestID: h.request) {
            publication.boundaryAdvanceActorMetadata()
        })
        XCTAssertFalse(publication.isCurrent(in: h.model)); XCTAssertThrowsError(try h.report())
    }
    func testCompletedProofSurvivesNormalReleaseButNotLaterOriginalState() async throws {
        let h = try await RecordBindingFixture(); try h.reveal(); try h.complete()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        h.binding.originalStateWillChange(root: h.rootToken)
        XCTAssertThrowsError(try h.binding.observedItem())
    }
    func testWrongIDsAndCompetingRequestCannotBorrowPendingSource() async throws {
        let h = try await RecordBindingFixture(); try h.prepare()
        XCTAssertThrowsError(try h.binding.begin(requestID: UUID(), validate: {}))
        XCTAssertThrowsError(try h.binding.apply(requestID: UUID()))
        XCTAssertThrowsError(try h.binding.retain(record: h.record, requestID: UUID()))
        h.binding.releaseSource(requestID: UUID()); h.publishMode(); h.mount(); try h.complete()
    }
    func testStableNativeUpdatesDoNotRepeatScrollOrPublishGraphLoop() async throws {
        let h = try await RecordBindingFixture(); try h.reveal()
        let changes = h.graphChanges
        for _ in 0..<20 { h.mountRoot(); h.mountRow(); h.binding.renderOriginalContainer() }
        XCTAssertEqual(h.graphChanges, changes); XCTAssertEqual(h.verticalCalls, 1); XCTAssertEqual(h.horizontalCalls, 1)
        try h.complete()
    }
    func testOriginalScrollOwnerDetachRefusesHorizontalReveal() async throws {
        let h = try await RecordBindingFixture(); try h.prepare(); h.publishMode()
        h.scrollOwner.detach(h.scroll); h.mount()
        XCTAssertNil(try h.binding.observedItem()); XCTAssertThrowsError(try h.report())
    }
    func testForeignLocalPresentationABAAndUnmountInvalidate() async throws {
        let h = try await RecordBindingFixture(); try h.retain()
        h.foreign.value = true; h.foreign.value = false
        XCTAssertThrowsError(try h.begin())
        let unmount = try await RecordBindingFixture(); try unmount.reveal(); unmount.binding.unmount()
        XCTAssertNil(try unmount.binding.observedItem()); XCTAssertThrowsError(try unmount.report())
    }
}
