// Explicit original-scene/window input boundary; no UIKit/native execution.
// Registry/descriptor, destination entity and source/card binding are original
// types/methods. The two metadata methods below are copied verbatim.
@MainActor private final class RecordMetadataBackendBoundary {
    func currentBackendSnapshot() throws -> ActionBackendSnapshot {
        let source = BackendCoordinator.shared
        guard !source.isTransitioning else { throw ActionPortError.staleState }
        return .init(backend: ActionBackendID(rawValue: source.activeBackendID.rawValue)!,
                     generation: source.generation)
    }
}
@MainActor private struct RecordMetadataComponentBoundary {
    struct Descriptor { let anchor: UIDestinationID; let title: String }
    var descriptors: [Descriptor] { [] }
    func isAvailable(_ anchor: UIDestinationID) -> Bool { false }
}
@MainActor private final class RecordMetadataSessionBoundary {
    let sceneID: UIStableID
    var mounted = true
    var foreground = true
    var historyRecordBinding: MaktabahNativeHistoryRecordBinding?
    var onLabel: (() -> Void)?
    init(sceneID: UIStableID, original: MaktabahNativeHistoryRecordBinding?) {
        self.sceneID = sceneID; historyRecordBinding = original
    }
    func windowLabel(number: Int) -> String { onLabel?(); return "Original Window \(number)" }
    func isRootAvailable(_ destination: UIDestinationID) -> Bool {
        MaktabahNativeRootDestination(rawValue: destination.rawValue)?.isAvailable == true
    }
    func componentOwner(for destination: UIDestinationID) -> RecordMetadataComponentBoundary? { nil }
}
@MainActor private final class RecordMetadataCompositionBoundary {
    struct Entry { let session: RecordMetadataSessionBoundary; let windowNumber: Int }
    let backend = RecordMetadataBackendBoundary()
    var registry: UIDestinationRegistry
    var scenes: [UIStableID: Entry]
    init(fixture: RecordBindingFixture, descriptors: [UIDestinationDescriptor]? = nil) throws {
        registry = try UIDestinationRegistry(descriptors: descriptors ?? [Self.descriptor()])
        scenes = [fixture.scene: .init(session: .init(sceneID: fixture.scene, original: fixture.binding), windowNumber: 1)]
    }
    static func descriptor(id: String = "native.history",
                           implementation: UIDestinationDescriptor.Implementation = .implemented,
                           backend: ActionBackendID = .otzaria,
                           presentation: PresentationSpec.Kind = .currentTab,
                           actions: [String] = [], content: Bool = false,
                           privateState: Bool = false) -> UIDestinationDescriptor {
        .init(id: .init(rawValue: id)!, title: "History", implementation: implementation,
              supportedBackends: [backend], presentations: [presentation],
              requiredCoreActions: actions, requiresContent: content, allowsPrivateState: privateState)
    }
    func recordWindows() throws -> [NativeIntentService.Destination] { try intentHistoryRecordWindows() }
    func genericWindows() throws -> [NativeIntentService.Destination] { try intentRootEntities() }
/* ORIGINAL_ROOT_METADATA */
/* RECORD_METADATA */
}
