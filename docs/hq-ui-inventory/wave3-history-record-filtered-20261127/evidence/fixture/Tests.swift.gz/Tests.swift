@MainActor final class HistoryRecordWindowMetadataSourceTests: XCTestCase, @unchecked Sendable {
    func testFilteredMetadataPreservesGenericRootContract() async throws {
        let h = try await RecordBindingFixture()
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        h.model.searchText = "Original"
        let selection = h.rootPublications.selectionRevision
        let mode = h.manager.nativeModePresentationRevision
        XCTAssertTrue(try metadata.genericWindows().isEmpty)
        let windows = try metadata.recordWindows()
        XCTAssertEqual(windows.count, 1)
        XCTAssertEqual(windows.first?.sceneID, h.scene)
        XCTAssertEqual(windows.first?.destination, MaktabahNativeHistoryRecords.destination)
        XCTAssertEqual(h.model.searchText, "Original")
        XCTAssertEqual(h.rootPublications.selectionRevision, selection)
        XCTAssertEqual(h.manager.nativeModePresentationRevision, mode)
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.verticalCalls, 0); XCTAssertEqual(h.reports, 0)
        XCTAssertTrue(try metadata.genericWindows().isEmpty)
    }

    func testFilteredColdParentRetainsQueryThroughActualSourceRowProof() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        try h.reveal(); try h.complete()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        XCTAssertEqual(h.model.searchText, "Original")
        XCTAssertEqual(h.selectedCalls, 1); XCTAssertEqual(h.reports, 1)
        XCTAssertTrue(try metadata.genericWindows().isEmpty)
    }

    func testFilteredWarmFavoriteNeedsActualOriginalRowAndDoesNotMutateFilter() async throws {
        let h = try await RecordBindingFixture(kind: .favorite, warm: true)
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        try h.prepare(); h.mountRoot()
        XCTAssertNil(try h.binding.observedItem())
        h.mountRow(); try h.complete()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        XCTAssertEqual(h.model.searchText, "Original")
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.horizontalCalls, 0)
    }

    func testEmptyFilteredCatalogDoesNotManufactureWindowOrCard() async throws {
        let h = try await RecordBindingFixture()
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        h.model.searchText = "No original card matches this"
        XCTAssertTrue(try MaktabahNativeHistoryRecords.catalog().isEmpty)
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        XCTAssertThrowsError(try h.retain())
        XCTAssertEqual(h.model.searchText, "No original card matches this")
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.reports, 0)
    }

    func testFilteredQueryABARevokesRetainedAndCompletedRecordSources() async throws {
        for complete in [false, true] {
            let h = try await RecordBindingFixture()
            h.model.searchText = "Original"
            let metadata = try RecordMetadataCompositionBoundary(fixture: h)
            XCTAssertEqual(try metadata.recordWindows().count, 1)
            if complete { try h.reveal(); try h.complete() } else { try h.retain() }
            h.model.searchText = "Different"
            h.model.searchText = "Original"
            if complete { XCTAssertThrowsError(try h.binding.observedItem()) }
            else { XCTAssertThrowsError(try h.binding.validateSource(requestID: h.request)) }
            XCTAssertEqual(h.model.searchText, "Original")
            // A fresh metadata query is not a renewed execution grant.
            XCTAssertEqual(try metadata.recordWindows().count, 1)
        }
    }

    func testMetadataRequiresExactDictionarySessionAndOriginalBindingScene() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        let foreign = UIStableID(rawValue: "foreign-scene")!
        let original = try XCTUnwrap(metadata.scenes[h.scene])
        metadata.scenes = [foreign: original]
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        metadata.scenes = [foreign: .init(session: .init(sceneID: foreign, original: h.binding), windowNumber: 2)]
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        metadata.scenes = [h.scene: .init(session: .init(sceneID: h.scene, original: nil), windowNumber: 1)]
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        metadata.scenes = [h.scene: original]
        original.session.mounted = false
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
    }

    func testBackgroundMetadataDoesNotBypassForegroundOrOriginalOverlays() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        let session = try XCTUnwrap(metadata.scenes[h.scene]?.session)
        session.foreground = false; h.foreground = false
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        try h.retain(); XCTAssertThrowsError(try h.begin())
        h.binding.retire()
        h.foreground = true; session.foreground = true
        h.settings = true
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        h.settings = false; DonationManager.shared.showDonationSheet = true
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        DonationManager.shared.showDonationSheet = false; h.workspace.isSwitching = true
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
    }

    func testRegistryMetadataMustActuallySupportThisReadOnlyCurrentTab() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let candidates: [[UIDestinationDescriptor]] = [
            [],
            [.init(id: .init(rawValue: "native.library")!, title: "Library", implementation: .implemented,
                   supportedBackends: [.otzaria], presentations: [.currentTab])],
            [RecordMetadataCompositionBoundary.descriptor(implementation: .inventoryOnly)],
            [RecordMetadataCompositionBoundary.descriptor(backend: .sefaria)],
            [RecordMetadataCompositionBoundary.descriptor(presentation: .sheet)],
            [RecordMetadataCompositionBoundary.descriptor(actions: ["reader.open"], content: true)],
            [RecordMetadataCompositionBoundary.descriptor(actions: ["reader.open"], privateState: true)]
        ]
        for descriptors in candidates {
            let metadata = try RecordMetadataCompositionBoundary(fixture: h, descriptors: descriptors)
            XCTAssertTrue(try metadata.recordWindows().isEmpty)
        }
    }

    func testStaleActorPublicationAndBackendCannotAdvertiseCardWindow() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        do { try await h.store.record(try XCTUnwrap(h.book.backendLocator), title: h.book.book) }
        catch { print("OBSERVED original Foundation persistence error: \(error)") }
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        let next = try await RecordBindingFixture()
        next.model.searchText = "Original"
        let changedBackend = try RecordMetadataCompositionBoundary(fixture: next)
        BackendCoordinator.shared.generation += 1
        XCTAssertTrue(try changedBackend.recordWindows().isEmpty)
    }

    func testFinalMetadataRevalidationRejectsQueryOrBackendChangeDuringLabelRead() async throws {
        for changesBackend in [false, true] {
            let h = try await RecordBindingFixture()
            h.model.searchText = "Original"
            let metadata = try RecordMetadataCompositionBoundary(fixture: h)
            metadata.scenes[h.scene]?.session.onLabel = {
                if changesBackend { BackendCoordinator.shared.generation += 1 }
                else { h.model.searchText = "No matching card" }
            }
            XCTAssertThrowsError(try metadata.recordWindows())
            XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.reports, 0)
        }
    }
}
