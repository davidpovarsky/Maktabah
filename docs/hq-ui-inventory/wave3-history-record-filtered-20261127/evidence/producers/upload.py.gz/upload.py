import base64,gzip,hashlib,json,pathlib,subprocess,shutil,sys
root=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
base=root/'build/history-record-filtered-controls-20261127'
assert not base.exists()
assert shutil.disk_usage(root).free>838860800
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='a1aad59adda0b27f0a2264d507ded9753cecdb1a'
assert not subprocess.check_output(['git','status','--short'],cwd=root,text=True).strip()
payload=json.loads(gzip.decompress(base64.b64decode(sys.argv[1],validate=True)))
updates={}
for path,spec in payload['source'].items():
 old=(root/path).read_bytes();assert hashlib.sha256(old).hexdigest()==spec['before']
 new=old.decode()
 for a,b in spec.get('replace',[]):assert new.count(a)==1;new=new.replace(a,b,1)
 new+=spec.get('append','')
 assert hashlib.sha256(new.encode()).hexdigest()==spec['after']
 updates[path]=new
base.mkdir();fixture=base/'fixture';fixture.mkdir()
for name,text in payload['fixtures'].items():
 assert name in ['generate.py','DomainBoundary.swift','BaseBindingTests.swift','MetadataBoundary.swift','Tests.swift']
 (fixture/name).write_text(text)
for path,text in updates.items():(root/path).write_text(text)
(base/'DRAFT_INPUTS.json').write_text(json.dumps(payload['source'],ensure_ascii=False,indent=2)+'\n')
g=subprocess.run(['python3',str(fixture/'generate.py'),str(root),str(base/'candidate-source')],capture_output=True,text=True)
(base/'generator.log').write_text(g.stdout+g.stderr)
assert g.returncode==0,g.stdout+g.stderr
print(json.dumps({'sourceFiles':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in updates},'generator':g.stdout,'syntaxPrior':json.loads((root/'build/history-record-controls-20261127/source-syntax-attempt-1/RESULT.json').read_text())['results'][0] if 'results' in json.loads((root/'build/history-record-controls-20261127/source-syntax-attempt-1/RESULT.json').read_text()) else None,'freeAfter':shutil.disk_usage(root).free}))