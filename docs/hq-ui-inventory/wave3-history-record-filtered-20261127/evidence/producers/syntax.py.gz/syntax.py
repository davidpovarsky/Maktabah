import pathlib,subprocess,json,hashlib,shutil,datetime
r=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
b=r/'build/history-record-filtered-controls-20261127'
out=b/'syntax-attempt-1';out.mkdir(exist_ok=False)
compiler=shutil.which('swiftc');assert compiler
paths=json.loads((b/'DRAFT_INPUTS.json').read_text())
results=[]
for i,p in enumerate(paths):
 cmd=[compiler,'-frontend','-parse','-target','arm64-apple-ios27.0',str(r/p)]
 q=subprocess.run(cmd,capture_output=True,text=True,timeout=20)
 (out/(str(i)+'.log')).write_text(q.stdout+q.stderr)
 results.append({'path':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest(),'command':cmd,'exit':q.returncode})
old='a1aad59adda0b27f0a2264d507ded9753cecdb1a'
prefixes=[]
for p in ['Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift','Maktabah-iOSUITests/NativeHistoryRecordAcceptanceTests.swift']:
 original=subprocess.check_output(['git','show',old+':'+p],cwd=r)
 assert (r/p).read_bytes().startswith(original)
 prefixes.append({'path':p,'prefixBytes':len(original),'prefixSha256':hashlib.sha256(original).hexdigest(),'preserved':True})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'syntax only; no Apple SDK/typecheck/native execution','results':results,'prefixes':prefixes}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
modules=[]
scratch=r/'build/history-record-controls-20261127/cache-restoration/scratch'
for name in ['OtzariaActionCore.swiftmodule','OtzariaUIRouting.swiftmodule','ChavrusaUIRoutingHost.swiftmodule']:
 for p in scratch.rglob(name):
  if p.is_file():modules.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
print(json.dumps({'syntax':result,'modules':modules,'free':shutil.disk_usage(r).free}))
assert all(x['exit']==0 for x in results)
