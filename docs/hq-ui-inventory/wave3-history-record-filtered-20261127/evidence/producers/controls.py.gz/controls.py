import pathlib,subprocess,json,hashlib,gzip,shutil,os,signal,time,datetime
root=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
base=root/'build/history-record-controls-20261127';follow=root/'build/history-record-filtered-controls-20261127'
out=follow/'suite-attempt-1';out.mkdir(exist_ok=False)
assert shutil.disk_usage(root).free>838860800
generated=(follow/'candidate-source/HistoryRecordBindingSourceTests.swift').read_bytes()
assert hashlib.sha256(generated).hexdigest()=='421fbe58d0c20ba366d2c5bfda86d4d429f9f427091eac2ed5dd65177172e7c8'
def block(raw,marker):
 start=raw.index(marker);i=raw.index(b'{',start);depth=1;end=i+1
 while depth:
  if raw[end:end+1]==b'{':depth+=1
  elif raw[end:end+1]==b'}':depth-=1
  end+=1
 return raw[start:end]
oldmethod=b'    private func intentHistoryRecordWindows() throws -> [NativeIntentService.Destination] {\n        try intentRootEntities()\n    }'
method=block(generated,b'    private func intentHistoryRecordWindows()')
baseline=generated.replace(method,oldmethod,1)
(out/'BASELINE_SOURCE.swift').write_bytes(baseline)
(out/'CANDIDATE_SOURCE.swift').write_bytes(generated)
comp='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift'
oldcomp=subprocess.check_output(['git','show','a1aad59adda0b27f0a2264d507ded9753cecdb1a:'+comp],cwd=root)
newcomp=(root/comp).read_bytes()
generic=block(oldcomp,b'    private func intentRootEntities()')
assert generic==block(newcomp,b'    private func intentRootEntities()')
(out/'GENERIC_ROOT_PRESERVED.json').write_text(json.dumps({'sha256':hashlib.sha256(generic).hexdigest(),'bytes':len(generic),'base':'a1aad59adda0b27f0a2264d507ded9753cecdb1a','method':'intentRootEntities','preserved':True},indent=2)+'\n')
target=base/'package-source/Source/ChavrusaText/UIRoutingHost/Tests/ChavrusaUIRoutingHostTests/HistoryRecordBindingSourceTests.swift'
previous=target.read_bytes()
assert hashlib.sha256(previous).hexdigest()=='a0c76c3ebd380f7be64a87195a33bd6f5bd66e0582f303e7084eba45841693ea'
(out/'PREVIOUS_CAPSULE.swift.gz').write_bytes(gzip.compress(previous,mtime=0))
cmd=json.loads((base/'service-attempt-3/START.json').read_text())['command']
results=[]
try:
 for name,source,selection in [('baseline',baseline,'HistoryRecordWindowMetadataSourceTests/testFilteredMetadataPreservesGenericRootContract'),('candidate',generated,'HistoryRecordWindowMetadataSourceTests')]:
  if shutil.disk_usage(root).free<838860800:raise RuntimeError('protected reserve before phase')
  target.write_bytes(source);phase=out/name;phase.mkdir()
  files=[]
  for file in sorted((base/'package-source').rglob('*')):
   if file.is_file():
    b=file.read_bytes();files.append({'path':str(file.relative_to(base/'package-source')),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
  inputs=(json.dumps({'scope':'actual original portable packages; verbatim generic/record metadata, binding, original row and source methods over explicit scene/UI/domain/lifetime boundaries','files':files},indent=2)+'\n').encode()
  (phase/'PACKAGE_INPUTS.json').write_bytes(inputs)
  run=list(cmd);run[run.index('--filter')+1]=selection
  env=dict(os.environ);env['HISTORY_RECORD_CONTROL_OUTPUT']=str(phase/'actual-store-fixtures')
  start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (phase/'raw.log').open('w') as log:
   p=subprocess.Popen(run,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   (phase/'START.json').write_text(json.dumps({'command':run,'pid':p.pid,'pgid':p.pid,'utc':start,'free':shutil.disk_usage(root).free,'reserveStopBytes':838860800},indent=2)+'\n')
   samples=[];stopped=False
   while p.poll() is None:
    free=shutil.disk_usage(root).free;samples.append({'t':time.time(),'free':free})
    if free<838860800:os.killpg(p.pid,signal.SIGTERM);stopped=True;break
    time.sleep(1)
   try:code=p.wait(timeout=30)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
  (phase/'DISK_SAMPLES.json').write_text(json.dumps(samples)+'\n')
  raw=(phase/'raw.log').read_bytes()
  result={'phase':name,'exit':code,'stoppedForReserve':stopped,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packageInputSha256':hashlib.sha256(inputs).hexdigest(),'generatedSourceSha256':hashlib.sha256(source).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest(),'freeAfter':shutil.disk_usage(root).free,'scope':'source controls only; explicit scene/UI/domain/Core lifetime boundaries, no app SDK/native claim'}
  (phase/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
  print(json.dumps(result),flush=True)
  print('\n'.join(line[:2000] for line in raw.decode(errors='replace').splitlines() if 'error:' in line or 'failed' in line or 'Executed ' in line),flush=True)
  if stopped:raise RuntimeError('protected reserve stopped owned compiler')
  if name=='baseline' and b'Executed 1 test, with 3 failures' not in raw:raise RuntimeError('baseline did not produce exact three filtered-window assertion failures')
  if name=='candidate' and code!=0:raise RuntimeError('candidate failed; preserve evidence')
finally:
 target.write_bytes(generated)
 (out/'SOURCE_RESTORED.json').write_text(json.dumps({'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source':'candidate source capsule','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
