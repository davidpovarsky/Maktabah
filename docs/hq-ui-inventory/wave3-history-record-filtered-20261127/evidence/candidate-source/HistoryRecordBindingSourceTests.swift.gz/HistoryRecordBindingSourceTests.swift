import Foundation
import Observation
import XCTest
import OtzariaActionCore
import OtzariaUIRouting
@testable import ChavrusaUIRoutingHost
// Explicit Foundation/Observation controls. UIKit, SwiftUI Bindings, Combine,
// app models and the Core lifetime callback below are DOMAIN/VIEW DOUBLES.
// They exercise verbatim production ownership/lifecycle methods, not native UI.
@MainActor final class AnyCancellable {
    let cancel: @MainActor () -> Void
    init(_ cancel: @escaping @MainActor () -> Void) { self.cancel = cancel }
    isolated deinit { cancel() }
}
@MainActor final class BoundaryPublisher<Value> {
    var callbacks: [UUID: (Value) -> Void] = [:]
    func send(_ value: Value) { for callback in Array(callbacks.values) { callback(value) } }
    func sink(_ receive: @escaping (Value) -> Void) -> AnyCancellable {
        let id = UUID(); callbacks[id] = receive
        return AnyCancellable { [weak self] in self?.callbacks.removeValue(forKey: id) }
    }
}
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    var activeBackendID: BackendID = .otzaria
    var generation: UInt64 = 1
    var activeTransitionToken: UInt64 = 1
    var activeCapabilities: BackendCapabilities = [.catalog, .reading, .navigation, .search, .authors]
    var usesNativeMaktabahDataPath = false
    var isTransitioning = false
    let objectWillChange = BoundaryPublisher<Void>()
}
@MainActor enum MaktabahApp { static var isIpad = false }
enum iOSTab: Equatable {
    case viewer, search, history, legacy, author, annotations
    var canonical: iOSTab { self == .legacy ? .search : self }
    var appMode: AppMode { self == .viewer ? .viewer : (self == .history ? .history : .search) }
}
enum AppMode { case viewer, search, history }
// BooksData is intentionally NON-observable, matching the actual boundary.
final class BooksData {
    let id: Int
    let book: String
    var backendLocator: TextLocator?
    init(id: Int, book: String, locator: TextLocator?) {
        self.id = id; self.book = book; backendLocator = locator
    }
}
@MainActor @Observable final class ReaderViewModel {
    var isPopoverPresented = false
    var readerInspectorVisible = false
}
@MainActor @Observable final class DonationManager {
    static let shared = DonationManager()
    var showDonationSheet = false
}
@MainActor @Observable final class BoundaryOverview { var blocksRouting = false }
@MainActor final class ReaderSidebarPageCoordinator { let overview = BoundaryOverview() }
struct Transaction { var marker = 0 }
@MainActor struct Binding<Value> {
    let get: () -> Value
    let set: (Value, Transaction) -> Void
    init(get: @escaping () -> Value, set: @escaping (Value) -> Void) {
        self.get = get; self.set = { value, _ in set(value) }
    }
    init(get: @escaping () -> Value, set: @escaping (Value, Transaction) -> Void) {
        self.get = get; self.set = set
    }
    var wrappedValue: Value { get { get() } nonmutating set { set(newValue, Transaction()) } }
    func transaction(_ transaction: Transaction) -> Binding<Value> {
        Binding(get: get, set: { value, _ in set(value, transaction) })
    }
}
@MainActor @Observable final class MappingSource { var event = 1 }
enum MappingCoverage { case liveNativeSetters, unqualified }
struct MappingProjection: Equatable { var value = "original-profile/group/tab" }
struct MappingEpoch: Equatable { var revision: UInt64 = 1 }
@MainActor struct MappingObservation {
    let source: MappingSource
    let owner: ObjectIdentifier
    let scene: String
    let epoch: MappingEpoch
    let projection: MappingProjection
    let coverage: MappingCoverage
}
@MainActor @Observable final class StudyWorkspaceNavigationAdapter {
    var attached = true
    var isSwitching = false
    var sceneID = "original-scene"
    var mappingOwnershipSource = MappingSource()
    var epoch = MappingEpoch()
    var projection = MappingProjection()
    var coverage = MappingCoverage.liveNativeSetters
    let manager: iOSNavigationManager
    init(_ manager: iOSNavigationManager) { self.manager = manager }
    func mappingOwnershipObservation() -> MappingObservation? {
        .init(source: mappingOwnershipSource, owner: ObjectIdentifier(manager), scene: sceneID,
              epoch: epoch, projection: projection, coverage: coverage)
    }
}
@MainActor @Observable final class MaktabahNativeWorkspaceProjectionSource {
    var current: StudyWorkspaceNavigationAdapter?
    var isAuthoritative = true
    init(_ current: StudyWorkspaceNavigationAdapter) { self.current = current }
    func read() throws -> StudyWorkspaceNavigationAdapter? { current }
}
@MainActor final class MaktabahNativeWorkspacePresentationBinding {
    var originalStateRevision: UInt64? = 0
}
struct UIEdgeInsets { var top: CGFloat = 0; var left: CGFloat = 0; var bottom: CGFloat = 0; var right: CGFloat = 0 }
extension CGRect {
    func inset(by value: UIEdgeInsets) -> CGRect {
        .init(x: minX + value.left, y: minY + value.top,
              width: width - value.left - value.right, height: height - value.top - value.bottom)
    }
}
@MainActor class UIView {
    weak var window: UIWindow?
    weak var superview: UIView?
    var bounds = CGRect(x: 0, y: 0, width: 250, height: 50)
    var offset = CGPoint.zero
    var isHidden = false
    var alpha: CGFloat = 1
    var clipsToBounds = false
    func convert(_ rect: CGRect, to: UIView?) -> CGRect { rect.offsetBy(dx: offset.x, dy: offset.y) }
    func isDescendant(of other: UIView) -> Bool {
        var value: UIView? = self
        while let current = value { if current === other { return true }; value = current.superview }
        return false
    }
}
@MainActor final class UIScrollView: UIView {
    var isDragging = false; var isDecelerating = false
    var adjustedContentInset = UIEdgeInsets()
    var contentSize = CGSize(width: 2000, height: 50)
}
@MainActor final class UIWindow: UIView {
    var isKeyWindow = true
    var windowScene: UIWindowScene? = UIWindowScene()
    var rootViewController: UIViewController? = UIViewController()
}
@MainActor final class UIWindowScene {
    enum Activation { case foregroundActive, background }
    var activationState = Activation.foregroundActive
    let session = Session()
    final class Session { var persistentIdentifier = "original-scene" }
}
@MainActor final class UIViewController {
    var view = UIView()
    var viewIfLoaded: UIView? { view }
    var children: [UIViewController] = []
    var presentedViewController: UIViewController?
    var isBeingPresented = false
    var isBeingDismissed = false
    var transitionCoordinator: NSObject?
}
extension String { func normalizeArabic(_ unused: Bool) -> String { self } }

// CryptoKit is not present in this Linux Foundation capsule. Only the record
// hash constructor is an explicit deterministic ID boundary. The actual
// original catalog/filter/publication bodies and real portable entity codec
// execute; no SHA256/native identity claim is made by these lifecycle controls.
@MainActor enum BoundaryRecordIdentity {
    static func make(_ card: HistoryQualifiedPublication.Card,
                     kind: NativeHistoryRecordIntentService.Kind) throws -> NativeHistoryRecordIntentService.Record {
        let position: ActionTextPosition
        switch card.locator.position {
        case .legacyLine(let value): position = .legacyLine(Int64(value))
        case .canonicalRef(let value): position = .canonicalRef(value)
        }
        let ref = ActionTextRef(backend: ActionBackendID(rawValue: card.locator.backend.rawValue)!,
            workKey: card.locator.workKey, position: position)
        return try .init(reference: .init(kind: kind, locator: ref), title: card.book.book,
            itemID: .init(rawValue: "boundary.\(kind.rawValue).\(card.book.id)")!)
    }
}

extension iOSTab {
    func isAvailable(for capabilities: BackendCapabilities) -> Bool {
        switch canonical {
        case .search: capabilities.contains(.search)
        case .author: capabilities.contains(.authors)
        default: true
        }
    }
}

@MainActor @Observable final class iOSNavigationManager {
    var currentMode: AppMode = .viewer {
        willSet {
            // Observe every original mode publication, including equal writes.
            // This metadata neither selects a mode nor replaces TabView's owner.
            if let revision = nativeModePresentationRevision, revision < .max {
                nativeModePresentationRevision = revision + 1
            } else {
                nativeModePresentationRevision = nil
            }
        }
    }
    private(set) var nativeModePresentationRevision: UInt64? = 0
    var selectedBook: BooksData? {
        willSet {
            // Original presentation ownership metadata. Every setter, including
            // an equal-value write, advances; exhaustion can never recycle it.
            if let revision = selectedBookPresentationRevision, revision < .max {
                selectedBookPresentationRevision = revision + 1
            } else {
                selectedBookPresentationRevision = nil
            }
        }
        didSet { selectedBookPresentationMode = selectedBook.map { _ in currentMode } }
    }
    private(set) var selectedBookPresentationRevision: UInt64? = 0
    private(set) var selectedBookPresentationMode: AppMode?

    struct ReaderTab { let id: UUID; let book: BooksData; let viewModel: ReaderViewModel }
    var openTabs: [ReaderTab] = []
    var activeTabId: UUID?
    var selectedContentId: Int? = 523
    var selectedBookForInfo: BooksData?
    var showingTabsList = false
    var alertMessage: String?
    var activeReaderViewModel: ReaderViewModel? { openTabs.first { $0.id == activeTabId }?.viewModel }
    init(modeSeed: UInt64? = 0, bookSeed: UInt64? = 0) {
        nativeModePresentationRevision = modeSeed; selectedBookPresentationRevision = bookSeed
    }
}
@MainActor struct MaktabahNativeSceneBindings {
    let manager: iOSNavigationManager
    let selectedTab: Binding<iOSTab>
    let showSettings: Binding<Bool>
    let sidebar: ReaderSidebarPageCoordinator? = nil
    let rootPublications: MaktabahNativeRootPublicationSource?
    var isPresentationReady: Bool {
        !DonationManager.shared.showDonationSheet && manager.selectedBookForInfo == nil
            && !manager.showingTabsList && manager.activeReaderViewModel?.isPopoverPresented != true
            && sidebar?.overview.blocksRouting != true
    }
}

@MainActor @Observable final class HistoryViewModel {
    static let shared = HistoryViewModel()
    var entriesByBookId: [Int: Int] = [:]
    var historyOrder: [Int] = []
    var historyBooks: [BooksData] = []
    var favoriteBooks: [BooksData] = []
    var searchText = ""
    /// Passive provenance only. The original arrays remain the UI's data owner;
    /// unqualified or obsolete publications never become record-route authority.
    private(set) var qualifiedPublication: HistoryQualifiedPublication?
    private var qualifiedLoadRevision: UInt64? = 0

    func beginQualifiedPublication() -> HistoryQualifiedPublication.Load {
        qualifiedPublication = nil
        if let revision = qualifiedLoadRevision, revision < .max {
            qualifiedLoadRevision = revision + 1
        } else {
            qualifiedLoadRevision = nil
        }
        return .init(revision: qualifiedLoadRevision)
    }

    func invalidateQualifiedPublication() { qualifiedPublication = nil }

    func completeQualifiedPublication(_ load: HistoryQualifiedPublication.Load,
                                      entries: QualifiedLocatorStore.PublishedEntries) {
        qualifiedPublication = nil
        guard let revision = load.revision, qualifiedLoadRevision == revision,
              load.isCurrent, let observation = entries.observation, observation.isCurrent,
              let publication = HistoryQualifiedPublication(
                model: self, load: load, entries: entries.entries, observation: observation) else { return }
        qualifiedPublication = publication
    }

    func isCurrentQualifiedLoad(_ load: HistoryQualifiedPublication.Load) -> Bool {
        guard let revision = load.revision else { return false }
        return qualifiedLoadRevision == revision && load.isCurrent
    }

    func filterBooks(_ books: [BooksData]) -> [BooksData] {
        guard !searchText.isEmpty else { return books }
        let normalizedSearchText = searchText.normalizeArabic(false)
        return books.filter { book in
            book.book.normalizeArabic(false).localizedStandardContains(normalizedSearchText)
        }
    }

    var filteredFavorites: [BooksData] {
        filterBooks(favoriteBooks)
    }

    var filteredHistory: [BooksData] {
        filterBooks(historyBooks)
    }


}

import Foundation

enum BackendID: String, Codable, CaseIterable, Identifiable, Sendable {
    case otzaria
    case sefaria
    case sefariaEmbedded

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .otzaria: return "אוצריא"
        case .sefaria: return "ספריא (ישן)"
        case .sefariaEmbedded: return "ספריא"
        }
    }

    var englishDisplayName: String {
        switch self {
        case .otzaria: return "Otzaria"
        case .sefaria: return "Sefaria (Legacy)"
        case .sefariaEmbedded: return "Sefaria"
        }
    }
}

struct BackendCapabilities: OptionSet, Codable, Sendable {
    let rawValue: Int

    static let catalog = Self(rawValue: 1 << 0)
    static let reading = Self(rawValue: 1 << 1)
    static let navigation = Self(rawValue: 1 << 2)
    static let search = Self(rawValue: 1 << 3)
    static let authors = Self(rawValue: 1 << 4)
    static let links = Self(rawValue: 1 << 5)
    static let versions = Self(rawValue: 1 << 6)
    static let offlineLibrary = Self(rawValue: 1 << 7)
    static let offlineSearch = Self(rawValue: 1 << 8)
    static let workMetadata = Self(rawValue: 1 << 9)
}

enum TextPosition: Codable, Hashable, Sendable, CustomStringConvertible {
    case legacyLine(Int)
    case canonicalRef(String)

    private enum CodingKeys: String, CodingKey { case kind, integer, string }
    private enum Kind: String, Codable { case legacyLine, canonicalRef }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        switch try values.decode(Kind.self, forKey: .kind) {
        case .legacyLine: self = .legacyLine(try values.decode(Int.self, forKey: .integer))
        case .canonicalRef: self = .canonicalRef(try values.decode(String.self, forKey: .string))
        }
    }

    var description: String {
        switch self {
        case .legacyLine(let value): return "line:\(value)"
        case .canonicalRef(let value): return value
        }
    }

    func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .legacyLine(let value):
            try values.encode(Kind.legacyLine, forKey: .kind)
            try values.encode(value, forKey: .integer)
        case .canonicalRef(let value):
            try values.encode(Kind.canonicalRef, forKey: .kind)
            try values.encode(value, forKey: .string)
        }
    }
}

struct TextLocator: Codable, Hashable, Sendable {
    let backend: BackendID
    let workKey: String
    let position: TextPosition

    var persistenceKey: String {
        let positionKey: String
        switch position {
        case .legacyLine(let value): positionKey = "line:\(value)"
        case .canonicalRef(let value): positionKey = "ref:\(value)"
        }
        return "\(backend.rawValue)|\(workKey)|\(positionKey)"
    }
}


import Foundation

/// Non-destructive sidecar persistence for source-qualified positions. Existing numeric
/// Maktabah records remain authoritative until an associated locator is written.
actor QualifiedLocatorStore {
    static let shared = QualifiedLocatorStore()

    /// Read-only provenance for the exact actor-owned history publication.
    /// The lock guards only this monotonically advancing metadata. Existing
    /// state mutation, persistence and actor ordering remain the original path.
    final class PublicationSource: @unchecked Sendable {
        private let lock = NSRecursiveLock()
        private var revision: UInt64? = 0

        struct Observation: Sendable {
            fileprivate let source: PublicationSource
            fileprivate let revision: UInt64
            var isCurrent: Bool { source.matches(revision) }
            /// The final synchronous native report may revalidate this same
            /// token. No actor call or suspension belongs inside this boundary.
            func withCurrent<Result>(_ operation: () throws -> Result) rethrows -> Result? {
                try source.withCurrent(revision, operation)
            }
        }

        fileprivate func capture() -> Observation? {
            lock.lock(); defer { lock.unlock() }
            guard let revision else { return nil }
            return Observation(source: self, revision: revision)
        }
        fileprivate func willChange() {
            lock.lock(); defer { lock.unlock() }
            guard let revision, revision < .max else { self.revision = nil; return }
            self.revision = revision + 1
        }
        private func matches(_ expected: UInt64) -> Bool {
            lock.lock(); defer { lock.unlock() }
            return revision == expected
        }
        private func withCurrent<Result>(_ expected: UInt64,
                                         _ operation: () throws -> Result) rethrows -> Result? {
            lock.lock(); defer { lock.unlock() }
            guard revision == expected else { return nil }
            let value = try operation()
            guard revision == expected else { return nil }
            return value
        }
    }

    struct PublishedEntries: Sendable {
        let entries: [HistoryEntry]
        let observation: PublicationSource.Observation?
    }
    private let publicationSource = PublicationSource()

    private struct State: Codable {
        var schemaVersion = 1
        var locatorsByLegacyKey: [String: TextLocator] = [:]
        var favorites: [String: TextLocator] = [:]
        var history: [HistoryEntry] = []
    }

    struct HistoryEntry: Codable, Hashable, Identifiable, Sendable {
        let locator: TextLocator
        var title: String
        var lastOpened: Date
        var isFavorite: Bool
        var id: String { locator.persistenceKey }
    }

    private let fileURL: URL
    private var state: State

    init(fileURL: URL? = nil) {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        self.fileURL = fileURL ?? base.appendingPathComponent("Maktabah/qualified-locators-v1.json")
        if let data = try? Data(contentsOf: self.fileURL),
           let decoded = try? JSONDecoder().decode(State.self, from: data) {
            state = decoded
        } else {
            state = State()
        }
    }

    func associate(_ locator: TextLocator, withLegacyKey key: String) async throws {
        publicationSource.willChange()
        state.locatorsByLegacyKey[key] = locator
        try persist()
    }

    func locator(forLegacyKey key: String) -> TextLocator? { state.locatorsByLegacyKey[key] }

    func record(_ locator: TextLocator, title: String) async throws {
        publicationSource.willChange()
        let favorite = state.favorites[locator.persistenceKey] != nil
        state.history.removeAll { $0.id == locator.persistenceKey }
        state.history.insert(.init(locator: locator, title: title, lastOpened: Date(), isFavorite: favorite), at: 0)
        state.history = Array(state.history.prefix(500))
        try persist()
    }

    func setFavorite(_ favorite: Bool, locator: TextLocator, title: String) async throws {
        publicationSource.willChange()
        if favorite { state.favorites[locator.persistenceKey] = locator }
        else { state.favorites.removeValue(forKey: locator.persistenceKey) }
        if let index = state.history.firstIndex(where: { $0.id == locator.persistenceKey }) {
            state.history[index].isFavorite = favorite
        } else if favorite {
            state.history.insert(.init(locator: locator, title: title, lastOpened: Date(), isFavorite: true), at: 0)
        }
        try persist()
    }

    func entries() -> [HistoryEntry] { state.history }

    /// No suspension separates the original entries and their source token.
    func entriesWithObservation() -> PublishedEntries {
        PublishedEntries(entries: state.history, observation: publicationSource.capture())
    }

    func removeHistory(_ locator: TextLocator) async throws {
        if let index = state.history.firstIndex(where: { $0.id == locator.persistenceKey }) {
            publicationSource.willChange()
            if state.history[index].isFavorite {
                state.history[index].lastOpened = .distantPast
            } else {
                state.history.remove(at: index)
            }
            try persist()
        }
    }

    private func persist() throws {
        let manager = FileManager.default
        let directory = fileURL.deletingLastPathComponent()
        try manager.createDirectory(at: directory, withIntermediateDirectories: true)
        let data = try JSONEncoder().encode(state)
        let temporary = directory.appendingPathComponent(".qualified-locators-\(UUID().uuidString).tmp")
        try data.write(to: temporary, options: .atomic)
        if manager.fileExists(atPath: fileURL.path) {
            _ = try manager.replaceItemAt(fileURL, withItemAt: temporary)
        } else {
            try manager.moveItem(at: temporary, to: fileURL)
        }
    }
}

@MainActor
final class HistoryQualifiedPublication {
    @MainActor struct Load {
        let revision: UInt64?
        let backend: BackendID
        let generation: UInt64
        let transition: UInt64
        let qualified: Bool

        init(revision: UInt64?) {
            let source = BackendCoordinator.shared
            self.revision = revision
            backend = source.activeBackendID; generation = source.generation
            transition = source.activeTransitionToken
            qualified = !source.usesNativeMaktabahDataPath && !source.isTransitioning
        }
        var isCurrent: Bool {
            let source = BackendCoordinator.shared
            return revision != nil && qualified && !source.usesNativeMaktabahDataPath
                && !source.isTransitioning && source.activeBackendID == backend
                && source.generation == generation && source.activeTransitionToken == transition
        }
    }
    struct Card {
        let book: BooksData
        let locator: TextLocator
        let recordID: String
    }
    let load: Load
    let history: [Card]
    let favorites: [Card]
    private weak var model: HistoryViewModel?
    private let observation: QualifiedLocatorStore.PublicationSource.Observation

    init?(model: HistoryViewModel, load: Load,
          entries: [QualifiedLocatorStore.HistoryEntry],
          observation: QualifiedLocatorStore.PublicationSource.Observation) {
        guard load.isCurrent, observation.isCurrent else { return nil }
        let relevant = entries.filter { $0.locator.backend == load.backend }
        guard Set(relevant.map(\.id)).count == relevant.count else { return nil }
        let byID = Dictionary(uniqueKeysWithValues: relevant.map { ($0.id, $0) })
        func cards(_ books: [BooksData], favorite: Bool) -> [Card]? {
            // The original ForEach uses numeric work IDs. Two positions of the
            // same work cannot be distinguished by that original row identity.
            guard Set(books.map(\.id)).count == books.count else { return nil }
            var result: [Card] = []
            for book in books {
                guard let locator = book.backendLocator, locator.backend == load.backend,
                      let entry = byID[locator.persistenceKey], entry.locator == locator,
                      favorite ? entry.isFavorite : entry.lastOpened != .distantPast else { return nil }
                result.append(Card(book: book, locator: locator, recordID: entry.id))
            }
            return result
        }
        guard let history = cards(model.historyBooks, favorite: false),
              let favorites = cards(model.favoriteBooks, favorite: true) else { return nil }
        self.model = model; self.load = load; self.observation = observation
        self.history = history; self.favorites = favorites
    }

    func isCurrent(in model: HistoryViewModel) -> Bool {
        guard self.model === model, model.qualifiedPublication === self,
              load.isCurrent, observation.isCurrent else { return false }
        func matches(_ cards: [Card], _ books: [BooksData]) -> Bool {
            cards.count == books.count && zip(cards, books).allSatisfy {
                $0.book === $1 && $1.backendLocator == $0.locator
                    && $0.recordID == $0.locator.persistenceKey
            }
        }
        return matches(history, model.historyBooks) && matches(favorites, model.favoriteBooks)
    }

    /// Atomic only with respect to the original actor's publication metadata;
    /// callers still must validate the exact scene/view/route before reporting.
    func withCurrent<Result>(in model: HistoryViewModel,
                             _ operation: () throws -> Result) rethrows -> Result? {
        try observation.withCurrent {
            guard isCurrent(in: model) else { return nil as Result? }
            return try operation()
        } ?? nil
    }
}
@MainActor
final class MaktabahNativeRootPublicationSource {
    private(set) var selectionRevision: UInt64? = 0
    private(set) var settingsRevision: UInt64? = 0

    func selectionBinding(_ original: Binding<iOSTab>) -> Binding<iOSTab> {
        Binding(get: { original.wrappedValue }, set: { [self] value, transaction in
            selectionRevision = Self.advanced(selectionRevision)
            original.transaction(transaction).wrappedValue = value
        })
    }
    func settingsBinding(_ original: Binding<Bool>) -> Binding<Bool> {
        Binding(get: { original.wrappedValue }, set: { [self] value, transaction in
            settingsRevision = Self.advanced(settingsRevision)
            original.transaction(transaction).wrappedValue = value
        })
    }
    private static func advanced(_ revision: UInt64?) -> UInt64? {
        guard let revision, revision < .max else { return nil }
        return revision + 1
    }
}
// Test-only initialization of exact original private metadata. Product has no reset.
extension MaktabahNativeRootPublicationSource {
    convenience init(boundarySelection: UInt64?, boundarySettings: UInt64?) {
        self.init(); selectionRevision = boundarySelection; settingsRevision = boundarySettings
    }
}

@MainActor final class MaktabahNativeComponentSourceObservation {
    private let observation: NativeComponentSourceObservation
    private let coordinator: BackendCoordinator
    private let backend: BackendID
    private let generation: UInt64
    private let backendChanges: AnyCancellable

    init(read: @MainActor () -> Void) {
        let coordinator = BackendCoordinator.shared
        let observation = NativeComponentSourceObservation(read: read)
        self.coordinator = coordinator
        self.observation = observation
        backend = coordinator.activeBackendID
        generation = coordinator.generation
        backendChanges = coordinator.objectWillChange.sink { _ in
            observation.invalidate()
        }
    }

    func validate() throws {
        try observation.validate()
        guard BackendCoordinator.shared === coordinator, !coordinator.isTransitioning,
              coordinator.activeBackendID == backend, coordinator.generation == generation else {
            throw UIRouteError(.staleState, "native_component_backend_changed")
        }
    }
}
@MainActor
struct MaktabahNativeHistoryRecordParentTransition {
    let rootPublications: MaktabahNativeRootPublicationSource
    let selectionRevision: UInt64
    let presentedSelectionRevision: UInt64
    let settingsRevision: UInt64
    let tab: iOSTab
    let mode: AppMode
    let modeRevision: UInt64
    let presentedModeRevision: UInt64
    let book: BooksData?
    let bookMode: AppMode?
    let bookRevision: UInt64
    let presentedBookRevision: UInt64
    let changesTab: Bool
    let popsBook: Bool

    init(bindings: MaktabahNativeSceneBindings) throws {
        let manager = bindings.manager
        tab = bindings.selectedTab.wrappedValue
        mode = manager.currentMode
        guard let rootPublications = bindings.rootPublications,
              let selectionRevision = rootPublications.selectionRevision,
              let settingsRevision = rootPublications.settingsRevision,
              tab == tab.canonical, mode == tab.appMode,
              let modeRevision = manager.nativeModePresentationRevision,
              let bookRevision = manager.selectedBookPresentationRevision else {
            throw UIRouteError(.unavailable, "native_history_record_parent_unavailable")
        }
        self.modeRevision = modeRevision; self.bookRevision = bookRevision
        self.rootPublications = rootPublications
        self.selectionRevision = selectionRevision; self.settingsRevision = settingsRevision
        book = manager.selectedBook; bookMode = manager.selectedBookPresentationMode
        changesTab = tab != .history
        popsBook = !MaktabahApp.isIpad && book != nil
        guard (!changesTab || (selectionRevision < .max && modeRevision < .max)),
              (!popsBook || bookRevision < .max) else {
            throw UIRouteError(.staleState, "native_history_record_parent_exhausted")
        }
        presentedModeRevision = changesTab ? modeRevision + 1 : modeRevision
        presentedSelectionRevision = changesTab ? selectionRevision + 1 : selectionRevision
        presentedBookRevision = popsBook ? bookRevision + 1 : bookRevision
    }

    func validateBefore(_ bindings: MaktabahNativeSceneBindings) throws {
        let manager = bindings.manager
        guard bindings.rootPublications === rootPublications,
              rootPublications.selectionRevision == selectionRevision,
              rootPublications.settingsRevision == settingsRevision,
              bindings.selectedTab.wrappedValue == tab, manager.currentMode == mode,
              manager.nativeModePresentationRevision == modeRevision,
              manager.selectedBook === book, manager.selectedBookPresentationMode == bookMode,
              manager.selectedBookPresentationRevision == bookRevision else {
            throw UIRouteError(.staleState, "native_history_record_parent_changed")
        }
    }

    func validateAfter(_ bindings: MaktabahNativeSceneBindings, requiresPublishedMode: Bool) throws {
        let manager = bindings.manager
        let published = manager.currentMode == .history
            && manager.nativeModePresentationRevision == presentedModeRevision
        let awaitingOriginalPublisher = changesTab && !requiresPublishedMode
            && manager.currentMode == mode && manager.nativeModePresentationRevision == modeRevision
        guard bindings.rootPublications === rootPublications,
              rootPublications.selectionRevision == presentedSelectionRevision,
              rootPublications.settingsRevision == settingsRevision,
              bindings.selectedTab.wrappedValue == .history, published || awaitingOriginalPublisher,
              manager.selectedBook === (popsBook ? nil : book),
              manager.selectedBookPresentationMode == (popsBook ? nil : bookMode),
              manager.selectedBookPresentationRevision == presentedBookRevision else {
            throw UIRouteError(.staleState, "native_history_record_parent_transition_changed")
        }
    }
}
extension MaktabahNativeSceneBindings {
    func presentOriginalHistoryRecord(_ expected: MaktabahNativeHistoryRecordParentTransition) throws {
        guard !showSettings.wrappedValue, isPresentationReady else {
            throw UIRouteError(.unavailable, "native_history_record_parent_blocked")
        }
        try expected.validateBefore(self)
        if expected.popsBook { manager.selectedBook = nil }
        if expected.changesTab { selectedTab.wrappedValue = .history }
        // The original TabView remains the sole currentMode publisher.
        try expected.validateAfter(self, requiresPublishedMode: false)
    }
}
@MainActor enum MaktabahNativeHistoryRecords {
    typealias Kind = NativeHistoryRecordIntentService.Kind
    typealias Record = NativeHistoryRecordIntentService.Record
    static let destination = UIDestinationID(rawValue: "native.history")!
    static let originalGridID = "native.history.original-grid"

    static func record(_ card: HistoryQualifiedPublication.Card, kind: Kind) throws -> Record {
        try BoundaryRecordIdentity.make(card, kind: kind)
    }
    static func catalog(model: HistoryViewModel = .shared) throws -> [Record] {
        guard let publication = model.qualifiedPublication, publication.isCurrent(in: model) else { return [] }
        let history = model.filteredHistory, favorites = model.filteredFavorites
        let values = try publication.history.filter { card in history.contains { $0 === card.book } }
            .map { try record($0, kind: .history) }
            + publication.favorites.filter { card in favorites.contains { $0 === card.book } }
            .map { try record($0, kind: .favorite) }
        guard publication.isCurrent(in: model), Set(values.map(\.id)).count == values.count,
              Set(values.map(\.itemID)).count == values.count else {
            throw UIRouteError(.staleState, "native_history_record_catalog_changed")
        }
        return values
    }
    static func accessibilityID(book: BooksData, kind: Kind, model: HistoryViewModel) -> String {
        guard let publication = model.qualifiedPublication, publication.isCurrent(in: model) else { return "" }
        let cards = kind == .history ? publication.history : publication.favorites
        let matches = cards.filter { $0.book === book }
        guard matches.count == 1, let card = matches.first, let value = try? record(card, kind: kind) else { return "" }
        return "native-history-record-" + value.itemID.rawValue
    }
}
@MainActor enum MaktabahNativeRootDestination: String, CaseIterable {
    case library = "native.library"
    case tableOfContents = "native.reader.toc"
    case history = "native.history"
    case search = "native.search"
    case annotations = "native.annotations"

    var tab: iOSTab {
        switch self {
        case .library, .tableOfContents: .viewer
        case .history: .history
        case .search: .search
        case .annotations: .annotations
        }
    }
    var isAvailable: Bool {
        tab.isAvailable(for: BackendCoordinator.shared.activeCapabilities)
            && (self != .history || HistoryViewModel.shared.searchText.isEmpty)
            && (self != .tableOfContents || MaktabahApp.isIpad)
    }
}
@MainActor final class MaktabahNativeHistoryRecordBinding {
    typealias Kind = NativeHistoryRecordIntentService.Kind
    typealias Record = NativeHistoryRecordIntentService.Record
    let sceneID: UIStableID
    private let bindings: MaktabahNativeSceneBindings
    private let workspaceSource: MaktabahNativeWorkspaceProjectionSource
    private weak var workspacePresentation: MaktabahNativeWorkspacePresentationBinding?
    private let commonReady: @MainActor () -> Bool
    private let windowReady: @MainActor () -> Bool
    private let readForeignPresentations: @MainActor () -> Void
    private var changed: (@MainActor () -> Void)?
    private var invalidated: (@MainActor () -> Void)?
    private var root: Root?
    private var rows: [RowKey: Row] = [:]
    private var source: Source?
    private var completed: Source?
    private var pending: Pending?

    private struct RowKey: Hashable {
        let book: ObjectIdentifier
        let section: String
        init(_ book: BooksData, _ kind: Kind) { self.book = ObjectIdentifier(book); section = kind.rawValue }
    }
    private final class Root {
        let token: UUID
        weak var view: UIView?
        weak var model: HistoryViewModel?
        var reveal: @MainActor (BooksData, Kind) -> Void
        init(token: UUID, view: UIView, model: HistoryViewModel,
             reveal: @escaping @MainActor (BooksData, Kind) -> Void) {
            self.token = token; self.view = view; self.model = model; self.reveal = reveal
        }
    }
    private final class Row {
        let token: UUID
        let root: UUID
        let kind: Kind
        weak var book: BooksData?
        weak var view: UIView?
        weak var scroll: MaktabahNativeHistoryScrollOwner?
        var blocked: Bool
        init(token: UUID, root: UUID, kind: Kind, book: BooksData, view: UIView,
             scroll: MaktabahNativeHistoryScrollOwner?, blocked: Bool) {
            self.token = token; self.root = root; self.kind = kind; self.book = book
            self.view = view; self.scroll = scroll; self.blocked = blocked
        }
    }
    private final class Source {
        enum Phase { case retained, applying, presented }
        let requestID: UUID
        let record: Record
        let card: HistoryQualifiedPublication.Card
        let publication: HistoryQualifiedPublication
        let model: HistoryViewModel
        let parent: MaktabahNativeHistoryRecordParentTransition
        let validateData: @MainActor () throws -> Void
        var rootToken: UUID?
        var rowToken: UUID?
        var phase: Phase = .retained
        var valid = true
        var revealed = false
        init(requestID: UUID, record: Record, card: HistoryQualifiedPublication.Card,
             publication: HistoryQualifiedPublication, model: HistoryViewModel,
             parent: MaktabahNativeHistoryRecordParentTransition, rootToken: UUID?, rowToken: UUID?,
             validateData: @escaping @MainActor () throws -> Void) {
            self.requestID = requestID; self.record = record; self.card = card; self.publication = publication
            self.model = model; self.parent = parent; self.rootToken = rootToken; self.rowToken = rowToken
            self.validateData = validateData
        }
    }
    private final class Pending {
        let source: Source
        let validate: @MainActor () throws -> Void
        var applied = false
        var rendering = false
        var vertical = false
        var horizontal = false
        init(source: Source, validate: @escaping @MainActor () throws -> Void) {
            self.source = source; self.validate = validate
        }
    }

    init(sceneID: UIStableID, bindings: MaktabahNativeSceneBindings,
         workspaceSource: MaktabahNativeWorkspaceProjectionSource,
         workspacePresentation: MaktabahNativeWorkspacePresentationBinding,
         commonReady: @escaping @MainActor () -> Bool,
         windowReady: @escaping @MainActor () -> Bool,
         readForeignPresentations: @escaping @MainActor () -> Void) {
        self.sceneID = sceneID; self.bindings = bindings; self.workspaceSource = workspaceSource
        self.workspacePresentation = workspacePresentation
        self.commonReady = commonReady; self.windowReady = windowReady
        self.readForeignPresentations = readForeignPresentations
    }
    func install(changed: @escaping @MainActor () -> Void, invalidated: @escaping @MainActor () -> Void) {
        self.changed = changed; self.invalidated = invalidated
    }

    var isAvailable: Bool {
        guard iOSTab.history.isAvailable(for: BackendCoordinator.shared.activeCapabilities),
              commonReady(), !bindings.showSettings.wrappedValue, bindings.isPresentationReady,
              bindings.manager.alertMessage == nil, workspaceSource.isAuthoritative,
              let workspace = try? workspaceSource.read(), workspace.attached, !workspace.isSwitching,
              workspace.sceneID == sceneID.rawValue, let mapping = workspace.mappingOwnershipObservation(),
              mapping.owner == ObjectIdentifier(bindings.manager), mapping.scene == sceneID.rawValue,
              bindings.rootPublications?.selectionRevision != nil,
              bindings.rootPublications?.settingsRevision != nil,
              workspacePresentation?.originalStateRevision != nil,
              bindings.manager.nativeModePresentationRevision != nil,
              bindings.manager.selectedBookPresentationRevision != nil else { return false }
        guard case .liveNativeSetters = mapping.coverage else { return false }
        return true
    }

    func retain(record: Record, requestID: UUID) throws {
        guard source == nil, pending == nil, isAvailable,
              let workspacePresentation, let workspaceRevision = workspacePresentation.originalStateRevision,
              let workspace = try workspaceSource.read(), let mapping = workspace.mappingOwnershipObservation() else {
            throw UIRouteError(.unavailable, "native_history_record_owner_unavailable")
        }
        let model = HistoryViewModel.shared, manager = bindings.manager
        guard let publication = model.qualifiedPublication, publication.isCurrent(in: model) else {
            throw UIRouteError(.unavailable, "native_history_record_publication_missing")
        }
        let candidates = record.reference.kind == .history ? publication.history : publication.favorites
        let matches = try candidates.filter { try MaktabahNativeHistoryRecords.record($0, kind: record.reference.kind).reference == record.reference }
        guard matches.count == 1, let card = matches.first,
              try MaktabahNativeHistoryRecords.record(card, kind: record.reference.kind) == record,
              try MaktabahNativeHistoryRecords.catalog(model: model).contains(record) else {
            throw UIRouteError(.staleState, "native_history_record_no_longer_published")
        }
        let parent = try MaktabahNativeHistoryRecordParentTransition(bindings: bindings)
        let reader = manager.activeReaderViewModel
        let observation = MaktabahNativeComponentSourceObservation {
            _ = try? workspaceSource.read(); _ = workspace.attached; _ = workspace.isSwitching
            _ = workspace.mappingOwnershipSource.event
            _ = manager.openTabs; _ = manager.activeTabId; _ = manager.selectedContentId
            _ = manager.selectedBookForInfo; _ = manager.showingTabsList; _ = manager.alertMessage
            _ = DonationManager.shared.showDonationSheet
            _ = reader?.isPopoverPresented; _ = reader?.readerInspectorVisible
            _ = model.qualifiedPublication; _ = model.historyBooks; _ = model.favoriteBooks
            _ = model.searchText; _ = model.historyOrder; _ = model.entriesByBookId
            readForeignPresentations()
        }
        let query = Array(model.searchText.utf8)
        let selected = Source(requestID: requestID, record: record, card: card, publication: publication,
            model: model, parent: parent, rootToken: root?.token,
            rowToken: rows[RowKey(card.book, record.reference.kind)]?.token) { [weak self, weak workspace, weak manager, weak workspacePresentation] in
                try observation.validate()
                guard let self, let workspace, let manager, let workspacePresentation, isAvailable,
                      self.workspacePresentation === workspacePresentation,
                      workspacePresentation.originalStateRevision == workspaceRevision,
                      let actualWorkspace = try workspaceSource.read(), actualWorkspace === workspace,
                      let actual = workspace.mappingOwnershipObservation(), actual.source === mapping.source,
                      actual.owner == mapping.owner, actual.scene == mapping.scene, actual.epoch == mapping.epoch,
                      actual.projection == mapping.projection, ObjectIdentifier(manager) == mapping.owner,
                      model.searchText.utf8.elementsEqual(query), publication.isCurrent(in: model),
                      card.book.backendLocator == card.locator,
                      try MaktabahNativeHistoryRecords.record(card, kind: record.reference.kind) == record,
                      try MaktabahNativeHistoryRecords.catalog(model: model).contains(record) else {
                    throw UIRouteError(.staleState, "native_history_record_source_changed")
                }
                guard case .liveNativeSetters = actual.coverage else {
                    throw UIRouteError(.staleState, "native_history_record_mapping_changed")
                }
            }
        try validate(selected)
        completed = nil; source = selected
    }

    func validateSource(requestID: UUID) throws {
        guard let source, source.requestID == requestID else {
            throw UIRouteError(.staleState, "native_history_record_request_changed")
        }
        try validate(source)
    }
    func selectedItem(requestID: UUID) throws -> UIStableID {
        try validateSource(requestID: requestID)
        guard let source, source.requestID == requestID else {
            throw UIRouteError(.staleState, "native_history_record_request_changed")
        }
        return source.record.itemID
    }
    private func validate(_ value: Source, rendered: Bool = false) throws {
        guard value.valid else { throw UIRouteError(.staleState, "native_history_record_retired") }
        try value.validateData()
        guard value.valid else { throw UIRouteError(.staleState, "native_history_record_retired") }
        switch value.phase {
        case .retained: try value.parent.validateBefore(bindings)
        case .presented: try value.parent.validateAfter(bindings, requiresPublishedMode: rendered || value.revealed)
        case .applying: throw UIRouteError(.staleState, "native_history_record_apply_in_progress")
        }
        if let token = value.rootToken {
            guard root?.token == token, root?.model === value.model, root?.view?.window != nil else {
                throw UIRouteError(.staleState, "native_history_record_root_replaced")
            }
        } else if root != nil && value.phase == .retained {
            throw UIRouteError(.staleState, "native_history_record_root_not_admitted")
        }
        let row = rows[RowKey(value.card.book, value.record.reference.kind)]
        if let token = value.rowToken {
            guard row?.token == token, row?.root == value.rootToken, row?.book === value.card.book,
                  row?.view?.window != nil, row?.blocked == false else {
                throw UIRouteError(.staleState, "native_history_record_row_replaced")
            }
        } else if row != nil && value.phase == .retained {
            throw UIRouteError(.staleState, "native_history_record_row_not_admitted")
        }
    }

    func begin(requestID: UUID, validate lifetime: @escaping @MainActor () throws -> Void) throws {
        guard pending == nil, let source, source.requestID == requestID, windowReady() else {
            throw UIRouteError(.unavailable, "native_history_record_not_ready")
        }
        try validate(source); try lifetime()
        guard self.source === source, source.valid else { throw UIRouteError(.staleState, "native_history_record_reentered") }
        pending = Pending(source: source, validate: lifetime)
    }
    func apply(requestID: UUID) throws {
        guard let value = pending, value.source === source, value.source.requestID == requestID, !value.applied else {
            throw UIRouteError(.staleState, "native_history_record_command_changed")
        }
        try validate(value.source); try value.validate()
        guard pending === value, value.source.valid else { throw UIRouteError(.staleState, "native_history_record_reentered") }
        value.source.phase = .applying
        do { try bindings.presentOriginalHistoryRecord(value.source.parent) }
        catch { retire(); throw error }
        value.source.phase = .presented
        guard pending === value, value.source.valid else { throw UIRouteError(.staleState, "native_history_record_reentered") }
        try validate(value.source)
        value.applied = true
        renderOriginalContainer()
        try value.validate(); try validate(value.source)
    }

    func attachRoot(token: UUID, view: UIView, model: HistoryViewModel,
                    reveal: @escaping @MainActor (BooksData, Kind) -> Void) {
        if let root, root.token == token, root.view === view, root.model === model {
            root.reveal = reveal; renderOriginalContainer(); return
        }
        if root != nil || source?.phase == .retained { retire() }
        root = Root(token: token, view: view, model: model, reveal: reveal)
        if let value = pending, value.applied, value.source.rootToken == nil {
            value.source.rootToken = token
            if let row = rows[RowKey(value.source.card.book, value.source.record.reference.kind)],
               row.root == token, row.book === value.source.card.book, row.view?.window != nil {
                value.source.rowToken = row.token
            }
        }
        renderOriginalContainer(); changed?()
    }
    func detachRoot(token: UUID, view: UIView) {
        guard root?.token == token, root?.view === view else { return }
        retire(); root = nil; rows.removeAll(); changed?()
    }
    func observeRow(token: UUID, root rootToken: UUID, kind: Kind, book: BooksData,
                    view: UIView, scroll: MaktabahNativeHistoryScrollOwner?, blocked: Bool) {
        let key = RowKey(book, kind)
        var ownershipChanged = false
        if let old = rows[key], old.token == token, old.root == rootToken, old.view === view {
            if old.blocked != blocked { originalStateWillChange(root: rootToken); ownershipChanged = true }
            if old.scroll !== scroll { originalStateWillChange(root: rootToken); ownershipChanged = true }
            old.blocked = blocked; old.scroll = scroll
        } else {
            if let target = source ?? completed, target.card.book === book, target.record.reference.kind == kind,
               rows[key] != nil || target.phase == .retained { retire() }
            rows[key] = Row(token: token, root: rootToken, kind: kind, book: book, view: view, scroll: scroll, blocked: blocked)
            ownershipChanged = true
        }
        if let value = pending, value.applied, value.source.rowToken == nil,
           value.source.card.book === book, value.source.record.reference.kind == kind,
           value.source.rootToken == rootToken { value.source.rowToken = token }
        renderOriginalContainer()
        // Stable UIViewRepresentable updates are not source changes and must
        // not create a SwiftUI update/layout loop. Actual geometry is read live.
        if ownershipChanged { changed?() }
    }
    func detachRow(token: UUID, kind: Kind, book: BooksData) {
        let key = RowKey(book, kind)
        guard rows[key]?.token == token else { return }
        if source?.rowToken == token || completed?.rowToken == token { retire() }
        rows.removeValue(forKey: key); changed?()
    }
    func originalStateWillChange(root token: UUID) {
        guard root?.token == token else { return }
        retire()
    }
    func originalForeignStateWillChange() { retire() }

    func renderOriginalContainer() {
        guard let value = pending, value.applied, !value.rendering, value.source === source,
              let root, let view = root.view, view.window != nil,
              view.bounds.width > 1, view.bounds.height > 1, windowReady() else { return }
        do {
            try validate(value.source); try value.validate()
            // The original TabView's own mode publication may follow its
            // selection setter. Keep the same admission until that publication.
            guard bindings.manager.currentMode == .history,
                  bindings.manager.nativeModePresentationRevision == value.source.parent.presentedModeRevision else { return }
            try validate(value.source, rendered: true)
            guard pending === value, self.root === root, value.source.valid else {
                throw UIRouteError(.staleState, "native_history_record_render_changed")
            }
            value.rendering = true
            defer { value.rendering = false }
            if !value.vertical {
                value.vertical = true
                root.reveal(value.source.card.book, value.source.record.reference.kind)
                try validate(value.source, rendered: true); try value.validate()
            }
            if value.source.record.reference.kind == .history {
                guard let row = rows[RowKey(value.source.card.book, .history)],
                      row.token == value.source.rowToken, row.root == root.token,
                      let original = row.view, let scroll = row.scroll else { return }
                if !value.horizontal {
                    guard scroll.canReveal(original, in: sceneID) else { return }
                    value.horizontal = true
                    try scroll.reveal(original, in: sceneID)
                    try validate(value.source, rendered: true); try value.validate()
                }
            }
            guard pending === value, value.source.valid else { throw UIRouteError(.staleState, "native_history_record_render_changed") }
            if !value.source.revealed {
                value.source.revealed = true
                changed?()
            }
        } catch { retire() }
    }

    func observedItem() throws -> UIStableID? {
        guard let value = source ?? completed, value.revealed else { return nil }
        try validate(value, rendered: true)
        guard windowReady(), let root, root.token == value.rootToken,
              let row = rows[RowKey(value.card.book, value.record.reference.kind)], row.token == value.rowToken,
              row.root == root.token, row.book === value.card.book, !row.blocked,
              let view = row.view, MaktabahNativeHistoryRecordGeometry.isVisible(view, sceneID: sceneID) else { return nil }
        return value.record.itemID
    }
    func withValidatedRecord(requestID: UUID, _ report: @MainActor () throws -> Void) throws {
        guard let value = pending, value.applied, value.source === source,
              value.source.requestID == requestID else { throw UIRouteError(.staleState, "native_history_record_report_changed") }
        let executed: Bool? = try value.source.publication.withCurrent(in: value.source.model) {
            try validate(value.source, rendered: true); try value.validate()
            guard pending === value, source === value.source, try observedItem() == value.source.record.itemID else {
                throw UIRouteError(.staleState, "native_history_record_not_visible")
            }
            try report()
            try validate(value.source, rendered: true)
            guard pending === value, source === value.source, value.source.valid else {
                throw UIRouteError(.staleState, "native_history_record_report_reentered")
            }
            return true
        }
        guard executed == true else { throw UIRouteError(.staleState, "native_history_record_store_changed") }
    }
    func finish(requestID: UUID, completed success: Bool) {
        guard let value = pending, value.source.requestID == requestID else { return }
        if success, value.source.valid, (try? observedItem()) == value.source.record.itemID { completed = value.source }
        else { value.source.valid = false; completed = nil }
        pending = nil
    }
    func releaseSource(requestID: UUID) {
        guard let source, source.requestID == requestID else { return }
        if pending?.source === source { retire(); pending = nil }
        if completed !== source { source.valid = false }
        self.source = nil
    }
    func clearCompletedProof() { completed?.valid = false; completed = nil }
    func retire() {
        source?.valid = false; completed?.valid = false
        invalidated?()
    }
    func unmount() { retire(); pending = nil; source = nil; completed = nil; root = nil; rows.removeAll() }
}
@MainActor final class MaktabahNativeHistoryScrollOwner {
    private weak var scrollView: UIScrollView?
    private weak var contentView: UIView?
    private var apply: (@MainActor (CGRect) -> Void)?

    func attach(scrollView: UIScrollView, contentView: UIView,
                reveal: @escaping @MainActor (CGRect) -> Void) {
        self.scrollView = scrollView; self.contentView = contentView; apply = reveal
    }
    func detach(_ view: UIScrollView) {
        guard scrollView === view else { return }
        scrollView = nil; contentView = nil; apply = nil
    }
    func canReveal(_ row: UIView, in sceneID: UIStableID) -> Bool {
        guard let scrollView, let contentView, let window = scrollView.window,
              row.window === window, row.isDescendant(of: contentView),
              window.windowScene?.session.persistentIdentifier == sceneID.rawValue,
              window.windowScene?.activationState == .foregroundActive,
              !scrollView.isDragging, !scrollView.isDecelerating,
              scrollView.bounds.width > 1, row.bounds.width > 1, row.bounds.height > 1,
              scrollView.contentSize.width.isFinite, scrollView.contentSize.width > 1,
              apply != nil else { return false }
        let rect = row.convert(row.bounds, to: scrollView)
        return !rect.isEmpty && rect.origin.x.isFinite && rect.origin.y.isFinite
            && rect.width.isFinite && rect.height.isFinite
    }
    func reveal(_ row: UIView, in sceneID: UIStableID) throws {
        guard canReveal(row, in: sceneID), let scrollView, let apply else {
            throw UIRouteError(.unavailable, "native_history_original_scroll_unavailable")
        }
        apply(row.convert(row.bounds, to: scrollView))
        guard self.scrollView === scrollView, canReveal(row, in: sceneID) else {
            throw UIRouteError(.staleState, "native_history_original_scroll_replaced")
        }
    }
}
@MainActor enum MaktabahNativeHistoryRecordGeometry {
    static func isVisible(_ view: UIView, sceneID: UIStableID) -> Bool {
        guard let window = view.window, window.isKeyWindow, !window.isHidden,
              window.windowScene?.session.persistentIdentifier == sceneID.rawValue,
              window.windowScene?.activationState == .foregroundActive,
              view.bounds.width > 1, view.bounds.height > 1 else { return false }
        let rect = view.convert(view.bounds, to: window)
        guard rect.origin.x.isFinite, rect.origin.y.isFinite, rect.width.isFinite, rect.height.isFinite else { return false }
        var visible = rect.intersection(window.bounds)
        var alpha: CGFloat = 1
        var current: UIView? = view
        while let node = current {
            guard !node.isHidden else { return false }
            alpha *= node.alpha
            if node.clipsToBounds { visible = visible.intersection(node.convert(node.bounds, to: window)) }
            if let scroll = node as? UIScrollView {
                guard !scroll.isDragging, !scroll.isDecelerating else { return false }
                visible = visible.intersection(scroll.convert(scroll.bounds.inset(by: scroll.adjustedContentInset), to: window))
            }
            current = node.superview
        }
        guard alpha >= 0.95, !visible.isNull,
              visible.width * visible.height >= rect.width * rect.height * 0.98,
              let root = window.rootViewController, root.viewIfLoaded?.window === window else { return false }
        var controllers = [root]
        while let controller = controllers.popLast() {
            guard controller.presentedViewController == nil, !controller.isBeingPresented,
                  !controller.isBeingDismissed, controller.transitionCoordinator == nil else { return false }
            controllers.append(contentsOf: controller.children)
        }
        return true
    }
}

@MainActor @Observable private final class BoundaryForeignPresentation { var value = false }

@MainActor private final class RecordBindingFixture {
    typealias Kind = NativeHistoryRecordIntentService.Kind
    let manager: iOSNavigationManager
    let workspace: StudyWorkspaceNavigationAdapter
    let workspaceSource: MaktabahNativeWorkspaceProjectionSource
    let workspacePresentation = MaktabahNativeWorkspacePresentationBinding()
    let model = HistoryViewModel.shared
    let store: QualifiedLocatorStore
    let book: BooksData
    let kind: Kind
    let rootPublications: MaktabahNativeRootPublicationSource
    let scene = UIStableID(rawValue: "original-scene")!
    let request = UUID(), rootToken = UUID()
    var rowToken = UUID()
    let window = UIWindow(), rootView = UIView(), rowView = UIView(), content = UIView(), scroll = UIScrollView()
    let scrollOwner = MaktabahNativeHistoryScrollOwner()
    let foreign = BoundaryForeignPresentation()
    var record: NativeHistoryRecordIntentService.Record!
    var tab: iOSTab
    var settings = false, foreground = true, lifetime = true
    var selectedCalls = 0, verticalCalls = 0, horizontalCalls = 0, reports = 0, graphChanges = 0
    var onSelect: (() -> Void)?, onVertical: (() -> Void)?, onValidate: (() -> Void)?
    lazy var bindings = MaktabahNativeSceneBindings(manager: manager,
        selectedTab: rootPublications.selectionBinding(Binding(get: { [unowned self] in tab }, set: { [unowned self] in
            tab = $0; selectedCalls += 1; onSelect?()
        })), showSettings: rootPublications.settingsBinding(Binding(get: { [unowned self] in settings }, set: { [unowned self] in settings = $0 })),
        rootPublications: rootPublications)
    lazy var binding = MaktabahNativeHistoryRecordBinding(sceneID: scene, bindings: bindings,
        workspaceSource: workspaceSource, workspacePresentation: workspacePresentation,
        commonReady: { [unowned self] in !settings && !foreign.value },
        windowReady: { [unowned self] in foreground && window.isKeyWindow
            && window.rootViewController?.presentedViewController == nil
            && window.rootViewController?.transitionCoordinator == nil },
        readForeignPresentations: { [unowned self] in _ = foreign.value })

    init(pad: Bool = false, kind: Kind = .history, warm: Bool = false,
         selectionSeed: UInt64? = 0, settingsSeed: UInt64? = 0,
         modeSeed: UInt64? = 0, bookSeed: UInt64? = 0) async throws {
        self.kind = kind; tab = warm ? .history : .viewer
        MaktabahApp.isIpad = pad
        let backend = BackendCoordinator.shared
        backend.activeBackendID = .otzaria; backend.generation = 1
        backend.activeTransitionToken = 1; backend.isTransitioning = false; backend.usesNativeMaktabahDataPath = false
        DonationManager.shared.showDonationSheet = false
        manager = iOSNavigationManager(modeSeed: modeSeed, bookSeed: bookSeed)
        rootPublications = .init(boundarySelection: selectionSeed, boundarySettings: settingsSeed)
        workspace = StudyWorkspaceNavigationAdapter(manager)
        workspaceSource = MaktabahNativeWorkspaceProjectionSource(workspace)
        let locator = TextLocator(backend: .otzaria, workKey: "book:3891", position: .legacyLine(523))
        book = BooksData(id: 3891, book: "Original title", locator: locator)
        let directory = URL(fileURLWithPath: ProcessInfo.processInfo.environment["HISTORY_RECORD_CONTROL_OUTPUT"]!, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        store = QualifiedLocatorStore(fileURL: directory.appendingPathComponent("record-\(UUID()).json"))
        if warm { manager.currentMode = .history }
        let tabID = UUID()
        manager.openTabs = [.init(id: tabID, book: book, viewModel: ReaderViewModel())]
        manager.activeTabId = tabID
        if !warm { manager.selectedBook = book }
        if kind == .favorite { try await store.setFavorite(true, locator: locator, title: book.book) }
        else { try await store.record(locator, title: book.book) }
        model.invalidateQualifiedPublication(); model.searchText = ""
        model.historyOrder = [book.id]; model.entriesByBookId = [book.id: 523]
        model.historyBooks = [book]; model.favoriteBooks = kind == .favorite ? [book] : []
        let load = model.beginQualifiedPublication(), entries = await store.entriesWithObservation()
        model.completeQualifiedPublication(load, entries: entries)
        let card = try XCTUnwrap(kind == .history ? model.qualifiedPublication?.history.first : model.qualifiedPublication?.favorites.first)
        record = try MaktabahNativeHistoryRecords.record(card, kind: kind)
        window.bounds = CGRect(x: 0, y: 0, width: 800, height: 900)
        window.rootViewController?.view.bounds = window.bounds
        window.rootViewController?.view.window = window
        window.rootViewController?.view.superview = window
        rootView.bounds = window.bounds; rootView.window = window; rootView.superview = window.rootViewController?.view
        scroll.bounds = CGRect(x: 0, y: 0, width: 600, height: 100)
        scroll.window = window; scroll.superview = rootView
        content.window = window; content.superview = scroll
        rowView.window = window; rowView.superview = content; rowView.offset.x = 1800
        scrollOwner.attach(scrollView: scroll, contentView: content) { [unowned self] _ in
            horizontalCalls += 1; rowView.offset.x = 20
        }
        binding.install(changed: { [unowned self] in graphChanges += 1 }, invalidated: {})
    }
    func retain() throws { try binding.retain(record: record, requestID: request) }
    func begin() throws {
        try binding.begin(requestID: request) { [unowned self] in
            onValidate?()
            guard lifetime, foreground else { throw UIRouteError(.staleState, "boundary_grant_expired") }
        }
    }
    func prepare() throws { try retain(); try begin(); try binding.apply(requestID: request) }
    func publishMode() { manager.currentMode = tab.appMode; binding.renderOriginalContainer() }
    func mountRoot(token: UUID? = nil, view: UIView? = nil) {
        binding.attachRoot(token: token ?? rootToken, view: view ?? rootView, model: model) { [unowned self] _, _ in
            verticalCalls += 1; if kind == .favorite { rowView.offset.x = 20 }; onVertical?()
        }
    }
    func mountRow(token: UUID? = nil, blocked: Bool = false) {
        binding.observeRow(token: token ?? rowToken, root: rootToken, kind: kind, book: book,
                           view: rowView, scroll: kind == .history ? scrollOwner : nil, blocked: blocked)
    }
    func mount(rowFirst: Bool = false) {
        if rowFirst { mountRow(); mountRoot() } else { mountRoot(); mountRow() }
    }
    func reveal() throws { try prepare(); if tab != .viewer && manager.currentMode != tab.appMode { publishMode() }; mount() }
    func report() throws { try binding.withValidatedRecord(requestID: request) { reports += 1 } }
    func complete() throws {
        try report(); binding.finish(requestID: request, completed: true); binding.releaseSource(requestID: request)
    }
}

// Same-file access only for a deliberately synchronous reentrant metadata
// invalidation. This is not a new app API or an actor mutation by the router.
extension HistoryQualifiedPublication {
    func boundaryAdvanceActorMetadata() { observation.source.willChange() }
}

@MainActor final class HistoryRecordBindingSourceTests: XCTestCase, @unchecked Sendable {
    func testColdPhoneWaitsForOriginalPublisherAndRevealsOriginalRowOnce() async throws {
        let h = try await RecordBindingFixture(), selected = h.manager.selectedBookPresentationRevision
        try h.prepare(); h.mount()
        XCTAssertNil(try h.binding.observedItem()); XCTAssertEqual(h.verticalCalls, 0)
        XCTAssertNil(h.manager.selectedBook)
        XCTAssertEqual(h.manager.selectedBookPresentationRevision, selected.map { $0 + 1 })
        h.publishMode()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        try h.complete()
        XCTAssertEqual(h.selectedCalls, 1); XCTAssertEqual(h.verticalCalls, 1); XCTAssertEqual(h.horizontalCalls, 1)
        XCTAssertEqual(h.reports, 1); XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
    }
    func testColdIPadKeepsOriginalReaderOwnerAndBookPublication() async throws {
        let h = try await RecordBindingFixture(pad: true), selected = h.manager.selectedBook, revision = h.manager.selectedBookPresentationRevision
        try h.reveal(); try h.complete()
        XCTAssertTrue(h.manager.selectedBook === selected); XCTAssertEqual(h.manager.selectedBookPresentationRevision, revision)
    }
    func testWarmFavoriteUsesZeroParentWritesAndNoHorizontalMutation() async throws {
        let h = try await RecordBindingFixture(kind: .favorite, warm: true)
        h.mount(); let mode = h.manager.nativeModePresentationRevision, book = h.manager.selectedBookPresentationRevision
        try h.reveal(); try h.complete()
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.horizontalCalls, 0); XCTAssertEqual(h.verticalCalls, 1)
        XCTAssertEqual(h.manager.nativeModePresentationRevision, mode); XCTAssertEqual(h.manager.selectedBookPresentationRevision, book)
    }
    func testOriginalPrivateQueryAndPublishedCardsRemainUnchanged() async throws {
        let h = try await RecordBindingFixture(); h.model.searchText = "Original"
        let original = h.model.historyBooks, entries = await h.store.entries()
        try h.reveal(); try h.complete()
        XCTAssertEqual(h.model.searchText, "Original"); XCTAssertTrue(h.model.historyBooks[0] === original[0])
        let after = await h.store.entries(); XCTAssertEqual(after, entries)
    }
    func testOriginalModelABAIsRejectedBeforeBegin() async throws {
        for key in ["query", "array", "order", "entries"] {
            let h = try await RecordBindingFixture(); try h.retain()
            switch key {
            case "query": h.model.searchText = "changed"; h.model.searchText = ""
            case "array": h.model.historyBooks = []; h.model.historyBooks = [h.book]
            case "order": h.model.historyOrder = []; h.model.historyOrder = [h.book.id]
            default: h.model.entriesByBookId = [:]; h.model.entriesByBookId = [h.book.id: 523]
            }
            XCTAssertThrowsError(try h.begin(), key)
        }
    }
    func testWorkspaceIdentityMappingAndLocalStatePublicationRetire() async throws {
        for key in ["owner", "mapping", "epoch", "localState"] {
            let h = try await RecordBindingFixture(); try h.retain()
            switch key {
            case "owner": h.workspaceSource.current = StudyWorkspaceNavigationAdapter(h.manager); h.workspaceSource.current = h.workspace
            case "mapping": h.workspace.mappingOwnershipSource.event = 2; h.workspace.mappingOwnershipSource.event = 1
            case "epoch": h.workspace.epoch.revision += 1
            default: h.workspacePresentation.originalStateRevision = 1
            }
            XCTAssertThrowsError(try h.begin(), key)
        }
    }
    func testAbortedBackendPublicationAndGenerationABARevoke() async throws {
        for eventOnly in [false, true] {
            let h = try await RecordBindingFixture(); try h.retain()
            if eventOnly { BackendCoordinator.shared.objectWillChange.send(()) }
            else {
                BackendCoordinator.shared.activeBackendID = .sefaria; BackendCoordinator.shared.generation += 1
                BackendCoordinator.shared.activeBackendID = .otzaria; BackendCoordinator.shared.generation += 1
            }
            XCTAssertThrowsError(try h.begin())
        }
    }
    func testOriginalActorMutationRetiresSourceBeforeReload() async throws {
        let h = try await RecordBindingFixture(); try h.retain()
        do { try await h.store.setFavorite(true, locator: h.book.backendLocator!, title: h.book.book) }
        catch { print("OBSERVED original Foundation persistence error: \(error)") }
        XCTAssertThrowsError(try h.begin()); XCTAssertEqual(h.model.historyBooks.count, 1)
    }
    func testUnqualifiedAndAmbiguousOriginalCardsNeverBecomeRecords() async throws {
        let h = try await RecordBindingFixture(); h.model.invalidateQualifiedPublication()
        XCTAssertTrue(try MaktabahNativeHistoryRecords.catalog().isEmpty)
        XCTAssertThrowsError(try h.retain())
        let load = h.model.beginQualifiedPublication(), entries = await h.store.entriesWithObservation()
        h.model.historyBooks = [h.book, h.book]; h.model.completeQualifiedPublication(load, entries: entries)
        XCTAssertNil(h.model.qualifiedPublication); XCTAssertThrowsError(try h.retain())
    }
    func testMountBeforeCanonicalApplyCannotJoinRetainedRequest() async throws {
        let h = try await RecordBindingFixture(); try h.retain(); h.mountRoot()
        XCTAssertThrowsError(try h.begin()); XCTAssertNil(try? h.binding.observedItem())
    }
    func testRowBeforeColdRootJoinsOnlySameAppliedOwner() async throws {
        let h = try await RecordBindingFixture(); try h.prepare(); h.publishMode(); h.mount(rowFirst: true)
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID); try h.complete()
    }
    func testRootAndRowReplacementOrDetachRevoke() async throws {
        for key in ["rootToken", "rootView", "rootDetach", "rowToken", "rowDetach"] {
            let h = try await RecordBindingFixture(); try h.reveal()
            switch key {
            case "rootToken": h.mountRoot(token: UUID())
            case "rootView": let view = UIView(); view.window = h.window; h.mountRoot(view: view)
            case "rootDetach": h.binding.detachRoot(token: h.rootToken, view: h.rootView); h.mountRoot()
            case "rowToken": h.mountRow(token: UUID())
            default: h.binding.detachRow(token: h.rowToken, kind: h.kind, book: h.book); h.mountRow()
            }
            XCTAssertThrowsError(try h.report(), key)
        }
    }
    func testOriginalRowGeometryIsRequiredAfterParentReveal() async throws {
        for key in ["offscreen", "hidden", "alpha", "clip", "drag", "decelerate", "foreignScene", "background", "nonKey", "modal", "transition"] {
            let h = try await RecordBindingFixture(); try h.reveal()
            XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
            switch key {
            case "offscreen": h.rowView.offset.x = 1800
            case "hidden": h.rowView.isHidden = true
            case "alpha": h.rowView.alpha = 0.5
            case "clip": h.content.clipsToBounds = true; h.content.bounds.size.width = 10
            case "drag": h.scroll.isDragging = true
            case "decelerate": h.scroll.isDecelerating = true
            case "foreignScene": h.window.windowScene?.session.persistentIdentifier = "other-scene"
            case "background": h.window.windowScene?.activationState = .background
            case "nonKey": h.window.isKeyWindow = false
            case "modal": h.window.rootViewController?.presentedViewController = UIViewController()
            default: h.window.rootViewController?.transitionCoordinator = NSObject()
            }
            XCTAssertNil(try? h.binding.observedItem(), key); XCTAssertThrowsError(try h.report(), key)
        }
    }
    func testRootWithoutExactRowCannotReportAnItem() async throws {
        let h = try await RecordBindingFixture(); try h.prepare(); h.publishMode(); h.mountRoot()
        XCTAssertNil(try h.binding.observedItem()); XCTAssertThrowsError(try h.report()); XCTAssertEqual(h.reports, 0)
    }
    func testSettingsAndRootSelectionABAOrEqualPublicationRefuse() async throws {
        for key in ["settingsABA", "settingsEqual", "tabABA", "tabEqual", "modeABA", "modeEqual", "bookEqual"] {
            let h = try await RecordBindingFixture(); try h.retain()
            switch key {
            case "settingsABA": h.bindings.showSettings.wrappedValue = true; h.bindings.showSettings.wrappedValue = false
            case "settingsEqual": h.bindings.showSettings.wrappedValue = false
            case "tabABA": h.bindings.selectedTab.wrappedValue = .search; h.bindings.selectedTab.wrappedValue = .viewer
            case "tabEqual": h.bindings.selectedTab.wrappedValue = .viewer
            case "modeABA": h.manager.currentMode = .search; h.manager.currentMode = .viewer
            case "modeEqual": h.manager.currentMode = .viewer
            default: h.manager.selectedBook = h.book
            }
            XCTAssertThrowsError(try h.begin(), key)
        }
    }
    func testSettingsAndOriginalOverlaysAreNotDismissed() async throws {
        for key in ["settings", "donation", "info", "readerPopover", "foreign"] {
            let h = try await RecordBindingFixture()
            switch key {
            case "settings": h.bindings.showSettings.wrappedValue = true
            case "donation": DonationManager.shared.showDonationSheet = true
            case "info": h.manager.selectedBookForInfo = h.book
            case "readerPopover": h.manager.activeReaderViewModel?.isPopoverPresented = true
            default: h.foreign.value = true
            }
            XCTAssertThrowsError(try h.retain(), key); XCTAssertEqual(h.selectedCalls, 0)
            if key == "settings" { XCTAssertTrue(h.settings) }
        }
    }
    func testMetadataExhaustionPermanentlyRefuses() async throws {
        for key in ["selection", "settings", "mode", "book", "workspace"] {
            let h = try await RecordBindingFixture(selectionSeed: key == "selection" ? nil : 0,
                settingsSeed: key == "settings" ? nil : 0, modeSeed: key == "mode" ? nil : 0,
                bookSeed: key == "book" ? nil : 0)
            if key == "workspace" { h.workspacePresentation.originalStateRevision = nil }
            XCTAssertThrowsError(try h.retain(), key)
        }
        let h = try await RecordBindingFixture(selectionSeed: .max)
        XCTAssertThrowsError(try h.retain()); h.bindings.selectedTab.wrappedValue = .viewer
        XCTAssertNil(h.rootPublications.selectionRevision); XCTAssertThrowsError(try h.retain())
    }
    func testLifetimeExpiryBeforeBeginBeforeRenderAndBeforeReportCannotRegrant() async throws {
        let before = try await RecordBindingFixture(); try before.retain(); before.lifetime = false
        XCTAssertThrowsError(try before.begin())
        let render = try await RecordBindingFixture(); try render.prepare(); render.lifetime = false; render.publishMode(); render.mount()
        XCTAssertThrowsError(try render.report()); XCTAssertEqual(render.reports, 0)
        let report = try await RecordBindingFixture(); try report.reveal(); report.lifetime = false
        XCTAssertThrowsError(try report.report()); XCTAssertEqual(report.reports, 0)
    }
    func testReentrantReleaseAtLifetimeAndParentCallbackCannotRenewSource() async throws {
        let begin = try await RecordBindingFixture(); try begin.retain()
        begin.onValidate = { [unowned begin] in begin.binding.releaseSource(requestID: begin.request) }
        XCTAssertThrowsError(try begin.begin())
        let apply = try await RecordBindingFixture(); try apply.retain(); try apply.begin()
        apply.onSelect = { [unowned apply] in apply.binding.releaseSource(requestID: apply.request) }
        XCTAssertThrowsError(try apply.binding.apply(requestID: apply.request)); XCTAssertEqual(apply.reports, 0)
    }
    func testReentrantOriginalScrollRetirementPreventsReport() async throws {
        let h = try await RecordBindingFixture()
        h.onVertical = { [unowned h] in h.binding.retire() }
        try h.prepare(); h.publishMode(); h.mount()
        XCTAssertThrowsError(try h.report()); XCTAssertEqual(h.reports, 0); XCTAssertEqual(h.verticalCalls, 1)
    }
    func testReportSourceMembershipIsRevalidatedAfterCallback() async throws {
        let h = try await RecordBindingFixture(); try h.reveal()
        var callbacks = 0
        XCTAssertThrowsError(try h.binding.withValidatedRecord(requestID: h.request) {
            callbacks += 1; h.binding.releaseSource(requestID: h.request)
        })
        XCTAssertEqual(callbacks, 1); XCTAssertThrowsError(try h.report())
    }
    func testActorPublicationLockRejectsReentrantMetadataMutation() async throws {
        let h = try await RecordBindingFixture(); try h.reveal()
        let publication = try XCTUnwrap(h.model.qualifiedPublication)
        XCTAssertThrowsError(try h.binding.withValidatedRecord(requestID: h.request) {
            publication.boundaryAdvanceActorMetadata()
        })
        XCTAssertFalse(publication.isCurrent(in: h.model)); XCTAssertThrowsError(try h.report())
    }
    func testCompletedProofSurvivesNormalReleaseButNotLaterOriginalState() async throws {
        let h = try await RecordBindingFixture(); try h.reveal(); try h.complete()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        h.binding.originalStateWillChange(root: h.rootToken)
        XCTAssertThrowsError(try h.binding.observedItem())
    }
    func testWrongIDsAndCompetingRequestCannotBorrowPendingSource() async throws {
        let h = try await RecordBindingFixture(); try h.prepare()
        XCTAssertThrowsError(try h.binding.begin(requestID: UUID(), validate: {}))
        XCTAssertThrowsError(try h.binding.apply(requestID: UUID()))
        XCTAssertThrowsError(try h.binding.retain(record: h.record, requestID: UUID()))
        h.binding.releaseSource(requestID: UUID()); h.publishMode(); h.mount(); try h.complete()
    }
    func testStableNativeUpdatesDoNotRepeatScrollOrPublishGraphLoop() async throws {
        let h = try await RecordBindingFixture(); try h.reveal()
        let changes = h.graphChanges
        for _ in 0..<20 { h.mountRoot(); h.mountRow(); h.binding.renderOriginalContainer() }
        XCTAssertEqual(h.graphChanges, changes); XCTAssertEqual(h.verticalCalls, 1); XCTAssertEqual(h.horizontalCalls, 1)
        try h.complete()
    }
    func testOriginalScrollOwnerDetachRefusesHorizontalReveal() async throws {
        let h = try await RecordBindingFixture(); try h.prepare(); h.publishMode()
        h.scrollOwner.detach(h.scroll); h.mount()
        XCTAssertNil(try h.binding.observedItem()); XCTAssertThrowsError(try h.report())
    }
    func testForeignLocalPresentationABAAndUnmountInvalidate() async throws {
        let h = try await RecordBindingFixture(); try h.retain()
        h.foreign.value = true; h.foreign.value = false
        XCTAssertThrowsError(try h.begin())
        let unmount = try await RecordBindingFixture(); try unmount.reveal(); unmount.binding.unmount()
        XCTAssertNil(try unmount.binding.observedItem()); XCTAssertThrowsError(try unmount.report())
    }
}

// Explicit original-scene/window input boundary; no UIKit/native execution.
// Registry/descriptor, destination entity and source/card binding are original
// types/methods. The two metadata methods below are copied verbatim.
@MainActor private final class RecordMetadataBackendBoundary {
    func currentBackendSnapshot() throws -> ActionBackendSnapshot {
        let source = BackendCoordinator.shared
        guard !source.isTransitioning else { throw ActionPortError.staleState }
        return .init(backend: ActionBackendID(rawValue: source.activeBackendID.rawValue)!,
                     generation: source.generation)
    }
}
@MainActor private struct RecordMetadataComponentBoundary {
    struct Descriptor { let anchor: UIDestinationID; let title: String }
    var descriptors: [Descriptor] { [] }
    func isAvailable(_ anchor: UIDestinationID) -> Bool { false }
}
@MainActor private final class RecordMetadataSessionBoundary {
    let sceneID: UIStableID
    var mounted = true
    var foreground = true
    var historyRecordBinding: MaktabahNativeHistoryRecordBinding?
    var onLabel: (() -> Void)?
    init(sceneID: UIStableID, original: MaktabahNativeHistoryRecordBinding?) {
        self.sceneID = sceneID; historyRecordBinding = original
    }
    func windowLabel(number: Int) -> String { onLabel?(); return "Original Window \(number)" }
    func isRootAvailable(_ destination: UIDestinationID) -> Bool {
        MaktabahNativeRootDestination(rawValue: destination.rawValue)?.isAvailable == true
    }
    func componentOwner(for destination: UIDestinationID) -> RecordMetadataComponentBoundary? { nil }
}
@MainActor private final class RecordMetadataCompositionBoundary {
    struct Entry { let session: RecordMetadataSessionBoundary; let windowNumber: Int }
    let backend = RecordMetadataBackendBoundary()
    var registry: UIDestinationRegistry
    var scenes: [UIStableID: Entry]
    init(fixture: RecordBindingFixture, descriptors: [UIDestinationDescriptor]? = nil) throws {
        registry = try UIDestinationRegistry(descriptors: descriptors ?? [Self.descriptor()])
        scenes = [fixture.scene: .init(session: .init(sceneID: fixture.scene, original: fixture.binding), windowNumber: 1)]
    }
    static func descriptor(id: String = "native.history",
                           implementation: UIDestinationDescriptor.Implementation = .implemented,
                           backend: ActionBackendID = .otzaria,
                           presentation: PresentationSpec.Kind = .currentTab,
                           actions: [String] = [], content: Bool = false,
                           privateState: Bool = false) -> UIDestinationDescriptor {
        .init(id: .init(rawValue: id)!, title: "History", implementation: implementation,
              supportedBackends: [backend], presentations: [presentation],
              requiredCoreActions: actions, requiresContent: content, allowsPrivateState: privateState)
    }
    func recordWindows() throws -> [NativeIntentService.Destination] { try intentHistoryRecordWindows() }
    func genericWindows() throws -> [NativeIntentService.Destination] { try intentRootEntities() }
    private func intentRootEntities() throws -> [NativeIntentService.Destination] {
        try Task.checkCancellation()
        let snapshot = try backend.currentBackendSnapshot()
        var values: [NativeIntentService.Destination] = []
        for (id, entry) in scenes.sorted(by: { $0.key.rawValue < $1.key.rawValue }) where entry.session.mounted {
            let windowLabel = entry.session.windowLabel(number: entry.windowNumber)
            for descriptor in registry.descriptors where descriptor.implementation == .implemented
                && descriptor.supportedBackends.contains(snapshot.backend)
                && descriptor.requiredCoreActions.isEmpty && !descriptor.requiresContent
                && !descriptor.mutatesUserData && !descriptor.allowsPrivateState {
                guard descriptor.id.rawValue == "native.settings" || entry.session.isRootAvailable(descriptor.id) else { continue }
                values.append(.init(backend: snapshot.backend, destination: descriptor.id,
                    title: descriptor.title + " — " + windowLabel, sceneID: id))
                if !entry.session.foreground, let owner = entry.session.componentOwner(for: descriptor.id) {
                    // Existing scene/source identity may resolve before the
                    // system foregrounds it. Execution still discovers afresh.
                    values += owner.descriptors.filter { owner.isAvailable($0.anchor) }.map {
                        .init(backend: snapshot.backend, destination: descriptor.id,
                              title: $0.title + " — " + windowLabel, sceneID: id, component: $0.anchor)
                    }
                }
            }
        }
        try Task.checkCancellation()
        guard try backend.currentBackendSnapshot() == snapshot else {
            throw UIRouteError(.staleState, "intent_source_generation_changed")
        }
        return values
    }
    private func intentHistoryRecordWindows() throws -> [NativeIntentService.Destination] {
        try Task.checkCancellation()
        let snapshot = try backend.currentBackendSnapshot()
        guard let descriptor = registry.descriptor(for: MaktabahNativeHistoryRecords.destination),
              descriptor.implementation == .implemented,
              descriptor.supportedBackends.contains(snapshot.backend),
              descriptor.presentations.contains(.currentTab),
              descriptor.requiredCoreActions.isEmpty, !descriptor.requiresContent,
              !descriptor.mutatesUserData, !descriptor.allowsPrivateState else { return [] }
        let records = try MaktabahNativeHistoryRecords.catalog()
        guard !records.isEmpty,
              records.allSatisfy({ $0.reference.locator.backend == snapshot.backend }) else { return [] }
        var values: [NativeIntentService.Destination] = []
        for (id, entry) in scenes.sorted(by: { $0.key.rawValue < $1.key.rawValue }) where entry.session.mounted {
            guard entry.session.sceneID == id, let original = entry.session.historyRecordBinding,
                  original.sceneID == id, original.isAvailable else { continue }
            let windowLabel = entry.session.windowLabel(number: entry.windowNumber)
            values.append(.init(backend: snapshot.backend, destination: descriptor.id,
                title: descriptor.title + " — " + windowLabel, sceneID: id))
        }
        try Task.checkCancellation()
        guard try backend.currentBackendSnapshot() == snapshot,
              try MaktabahNativeHistoryRecords.catalog() == records else {
            throw UIRouteError(.staleState, "intent_record_window_source_changed")
        }
        return values
    }
}

@MainActor final class HistoryRecordWindowMetadataSourceTests: XCTestCase, @unchecked Sendable {
    func testFilteredMetadataPreservesGenericRootContract() async throws {
        let h = try await RecordBindingFixture()
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        h.model.searchText = "Original"
        let selection = h.rootPublications.selectionRevision
        let mode = h.manager.nativeModePresentationRevision
        XCTAssertTrue(try metadata.genericWindows().isEmpty)
        let windows = try metadata.recordWindows()
        XCTAssertEqual(windows.count, 1)
        XCTAssertEqual(windows.first?.sceneID, h.scene)
        XCTAssertEqual(windows.first?.destination, MaktabahNativeHistoryRecords.destination)
        XCTAssertEqual(h.model.searchText, "Original")
        XCTAssertEqual(h.rootPublications.selectionRevision, selection)
        XCTAssertEqual(h.manager.nativeModePresentationRevision, mode)
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.verticalCalls, 0); XCTAssertEqual(h.reports, 0)
        XCTAssertTrue(try metadata.genericWindows().isEmpty)
    }

    func testFilteredColdParentRetainsQueryThroughActualSourceRowProof() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        try h.reveal(); try h.complete()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        XCTAssertEqual(h.model.searchText, "Original")
        XCTAssertEqual(h.selectedCalls, 1); XCTAssertEqual(h.reports, 1)
        XCTAssertTrue(try metadata.genericWindows().isEmpty)
    }

    func testFilteredWarmFavoriteNeedsActualOriginalRowAndDoesNotMutateFilter() async throws {
        let h = try await RecordBindingFixture(kind: .favorite, warm: true)
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        try h.prepare(); h.mountRoot()
        XCTAssertNil(try h.binding.observedItem())
        h.mountRow(); try h.complete()
        XCTAssertEqual(try h.binding.observedItem(), h.record.itemID)
        XCTAssertEqual(h.model.searchText, "Original")
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.horizontalCalls, 0)
    }

    func testEmptyFilteredCatalogDoesNotManufactureWindowOrCard() async throws {
        let h = try await RecordBindingFixture()
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        h.model.searchText = "No original card matches this"
        XCTAssertTrue(try MaktabahNativeHistoryRecords.catalog().isEmpty)
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        XCTAssertThrowsError(try h.retain())
        XCTAssertEqual(h.model.searchText, "No original card matches this")
        XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.reports, 0)
    }

    func testFilteredQueryABARevokesRetainedAndCompletedRecordSources() async throws {
        for complete in [false, true] {
            let h = try await RecordBindingFixture()
            h.model.searchText = "Original"
            let metadata = try RecordMetadataCompositionBoundary(fixture: h)
            XCTAssertEqual(try metadata.recordWindows().count, 1)
            if complete { try h.reveal(); try h.complete() } else { try h.retain() }
            h.model.searchText = "Different"
            h.model.searchText = "Original"
            if complete { XCTAssertThrowsError(try h.binding.observedItem()) }
            else { XCTAssertThrowsError(try h.binding.validateSource(requestID: h.request)) }
            XCTAssertEqual(h.model.searchText, "Original")
            // A fresh metadata query is not a renewed execution grant.
            XCTAssertEqual(try metadata.recordWindows().count, 1)
        }
    }

    func testMetadataRequiresExactDictionarySessionAndOriginalBindingScene() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        let foreign = UIStableID(rawValue: "foreign-scene")!
        let original = try XCTUnwrap(metadata.scenes[h.scene])
        metadata.scenes = [foreign: original]
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        metadata.scenes = [foreign: .init(session: .init(sceneID: foreign, original: h.binding), windowNumber: 2)]
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        metadata.scenes = [h.scene: .init(session: .init(sceneID: h.scene, original: nil), windowNumber: 1)]
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        metadata.scenes = [h.scene: original]
        original.session.mounted = false
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
    }

    func testBackgroundMetadataDoesNotBypassForegroundOrOriginalOverlays() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        let session = try XCTUnwrap(metadata.scenes[h.scene]?.session)
        session.foreground = false; h.foreground = false
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        try h.retain(); XCTAssertThrowsError(try h.begin())
        h.binding.retire()
        h.foreground = true; session.foreground = true
        h.settings = true
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        h.settings = false; DonationManager.shared.showDonationSheet = true
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        DonationManager.shared.showDonationSheet = false; h.workspace.isSwitching = true
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
    }

    func testRegistryMetadataMustActuallySupportThisReadOnlyCurrentTab() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let candidates: [[UIDestinationDescriptor]] = [
            [],
            [.init(id: .init(rawValue: "native.library")!, title: "Library", implementation: .implemented,
                   supportedBackends: [.otzaria], presentations: [.currentTab])],
            [RecordMetadataCompositionBoundary.descriptor(implementation: .inventoryOnly)],
            [RecordMetadataCompositionBoundary.descriptor(backend: .sefaria)],
            [RecordMetadataCompositionBoundary.descriptor(presentation: .sheet)],
            [RecordMetadataCompositionBoundary.descriptor(actions: ["reader.open"], content: true)],
            [RecordMetadataCompositionBoundary.descriptor(actions: ["reader.open"], privateState: true)]
        ]
        for descriptors in candidates {
            let metadata = try RecordMetadataCompositionBoundary(fixture: h, descriptors: descriptors)
            XCTAssertTrue(try metadata.recordWindows().isEmpty)
        }
    }

    func testStaleActorPublicationAndBackendCannotAdvertiseCardWindow() async throws {
        let h = try await RecordBindingFixture()
        h.model.searchText = "Original"
        let metadata = try RecordMetadataCompositionBoundary(fixture: h)
        XCTAssertEqual(try metadata.recordWindows().count, 1)
        do { try await h.store.record(try XCTUnwrap(h.book.backendLocator), title: h.book.book) }
        catch { print("OBSERVED original Foundation persistence error: \(error)") }
        XCTAssertTrue(try metadata.recordWindows().isEmpty)
        let next = try await RecordBindingFixture()
        next.model.searchText = "Original"
        let changedBackend = try RecordMetadataCompositionBoundary(fixture: next)
        BackendCoordinator.shared.generation += 1
        XCTAssertTrue(try changedBackend.recordWindows().isEmpty)
    }

    func testFinalMetadataRevalidationRejectsQueryOrBackendChangeDuringLabelRead() async throws {
        for changesBackend in [false, true] {
            let h = try await RecordBindingFixture()
            h.model.searchText = "Original"
            let metadata = try RecordMetadataCompositionBoundary(fixture: h)
            metadata.scenes[h.scene]?.session.onLabel = {
                if changesBackend { BackendCoordinator.shared.generation += 1 }
                else { h.model.searchText = "No matching card" }
            }
            XCTAssertThrowsError(try metadata.recordWindows())
            XCTAssertEqual(h.selectedCalls, 0); XCTAssertEqual(h.reports, 0)
        }
    }
}
