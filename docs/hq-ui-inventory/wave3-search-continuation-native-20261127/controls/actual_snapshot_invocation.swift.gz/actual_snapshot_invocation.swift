import Foundation

public struct ActionBackendSnapshot: Codable, Sendable, Equatable, Hashable {
    public let backend: ActionBackendID
    public let generation: UInt64
    public let rpcEpoch: UInt64?
    public init(backend: ActionBackendID, generation: UInt64, rpcEpoch: UInt64? = nil) {
        self.backend = backend; self.generation = generation; self.rpcEpoch = rpcEpoch
    }
}
public struct ActionPortInvocation: Sendable, Equatable {
    public let requestId: UUID
    public let snapshot: ActionBackendSnapshot
    public let deadlineUptimeNanoseconds: UInt64
    public init(requestId: UUID, snapshot: ActionBackendSnapshot, deadlineUptimeNanoseconds: UInt64) {
        self.requestId = requestId; self.snapshot = snapshot; self.deadlineUptimeNanoseconds = deadlineUptimeNanoseconds
    }
}
