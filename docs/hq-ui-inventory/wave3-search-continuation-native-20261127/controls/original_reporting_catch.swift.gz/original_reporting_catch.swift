            if consumed || !(error is CancellationError) {
                try? probe.write(payload: ["probeError": "continuation_probe_failed",
                                          "triggerConsumed": consumed,
                                          "errorType": String(describing: type(of: error))])
            }