@MainActor
private final class MaktabahNativeSearchContinuationProbeReturn {
    private static var retained: MaktabahNativeSearchContinuationProbeReturn?
    private enum RetentionError: Error { case alreadyInvoked, alreadyReturned, invalidKind }
    let kind: String
    let token: UUID
    private(set) var returned: ActionSearchContinuationOutcome?
    private(set) var checkpointReference: [String: Any]?

    private init(kind: String, token: UUID) { self.kind = kind; self.token = token }

    static func reserve(kind: String, token: UUID) throws -> MaktabahNativeSearchContinuationProbeReturn {
        guard ["search-continuation-hit", "search-continuation-page"].contains(kind) else {
            throw RetentionError.invalidKind
        }
        guard retained == nil else { throw RetentionError.alreadyInvoked }
        let entry = MaktabahNativeSearchContinuationProbeReturn(kind: kind, token: token)
        retained = entry
        return entry
    }

    // Both closures only project/write evidence. Neither is a source validator,
    // a grant, an operation chooser, or a fallback executor.
    func publish(_ actualReturn: ActionSearchContinuationOutcome,
                 checkpoint: (ActionSearchContinuationOutcome) throws -> [String: Any],
                 envelope: ([String: Any]) throws -> Void) throws {
        guard returned == nil else { throw RetentionError.alreadyReturned }
        returned = actualReturn
        let reference = try checkpoint(actualReturn)
        checkpointReference = reference
        try envelope(reference)
    }
}

