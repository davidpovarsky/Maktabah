                    let evidence = MaktabahNativeSearchContinuationProbeEvidence(probe)
                    var payload: [String: Any] = [
                        "schemaVersion": 1, "triggerToken": probe.token.uuidString, "probeKind": probe.kind,
                        "processID": ProcessInfo.processInfo.processIdentifier,
                        "outcome": try evidence.outcome(result),
                        "originalBeforeRowIDs": beforeIDs, "originalAfterRowIDs": search.results.map(\.stableID),
                        "originalSubmissionBefore": beforeSubmission, "originalSubmissionAfter": search.submissionRevision,
                        "originalCancellationBefore": beforeCancellation, "originalCancellationAfter": search.cancellationRevision,
                        "originalPaginationBefore": beforePagination, "originalPaginationAfter": search.paginationRevision,
                        "originalHasSubmitted": search.hasSubmitted, "originalIsSearching": search.isSearching,
                        "originalIsLoadingMore": search.isLoadingMore, "originalResultsAreDirty": search.resultsAreDirty,
                        "originalBookIDs": search.selectedBookIds.sorted(), "originalQuery": search.query,
                    ]
                    if let selectedObservation { payload["observation"] = try evidence.observation(selectedObservation) }
                    if let selectedOperation { payload["selectedOperation"] = evidence.operation(selectedOperation) }
                    if let error = search.errorMessage { payload["originalError"] = error }
                    let encoded = try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
                    guard encoded.count < 128 * 1024 else { throw CocoaError(.coderInvalidValue) }
                    try probe.write(payload: payload)
                    return
