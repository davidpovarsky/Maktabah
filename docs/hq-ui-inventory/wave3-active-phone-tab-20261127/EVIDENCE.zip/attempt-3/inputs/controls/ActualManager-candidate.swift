import Foundation
import Observation

// Explicit app-domain boundaries. The Manager declaration bodies, original
// setter callbacks, selection action, factored presentation, and new one-use
// owner are extracted verbatim below. No UIKit/Core/native receipt is mocked
// into acceptance: this executable tests only those synchronous source bodies.
enum AppMode: Equatable { case viewer, history, search }
enum StudyWorkspaceError: Error { case invalidMembership }
enum ControlError: Error { case failed(String), staleSource }
@MainActor enum MaktabahApp { static var isIpad = false }
@MainActor final class BooksData { let id: Int; init(_ id: Int) { self.id = id } }
@MainActor @Observable final class ReaderViewModel {
    var annotationEvent: String? = "note" { didSet { events.append("annotation"); annotationHook?() } }
    var searchEvent: String? = "query" { didSet { events.append("search"); searchHook?() } }
    var needsScrollRestore = false { didSet { events.append("restore"); restoreHook?() } }
    var currentContentId: Int? = 523
    @ObservationIgnored var events: [String] = []
    @ObservationIgnored var annotationHook: (() -> Void)?
    @ObservationIgnored var searchHook: (() -> Void)?
    @ObservationIgnored var restoreHook: (() -> Void)?
    @ObservationIgnored var saveCalls = 0
    @ObservationIgnored var closeCalls = 0
    func saveCurrentState() { saveCalls += 1 }
    func closeReaderInspector() { closeCalls += 1 }
}
@MainActor enum StudyWorkspaceNavigationAdapter {
    static var bookWill: ((iOSNavigationManager, BooksData?) -> Void)?
    static var bookDid: ((iOSNavigationManager) -> Void)?
    static var events: [String] = []
    static func reset() { bookWill = nil; bookDid = nil; events = [] }
    static func nativeGroupBookWillChange(_ manager: iOSNavigationManager, to book: BooksData?) {
        events.append("group-will"); bookWill?(manager, book)
    }
    static func nativeGroupBookDidChange(_ manager: iOSNavigationManager) {
        events.append("group-did"); bookDid?(manager)
    }
    static func nativeMappingTabsWillChange(_ manager: iOSNavigationManager, to value: [iOSNavigationManager.ReaderTab]) {}
    static func nativeMappingSelectionWillChange(_ manager: iOSNavigationManager, to value: UUID?) {}
    static func nativeMappingDidChange(_ manager: iOSNavigationManager) {}
}

@MainActor @Observable final class iOSNavigationManager {
    struct ReaderTab: Identifiable, Equatable {
        let id: UUID
        let book: BooksData
        var initialContentId: Int?
        var viewModel: ReaderViewModel

        static func == (lhs: ReaderTab, rhs: ReaderTab) -> Bool {
            lhs.id == rhs.id
        }
    }

    var currentMode: AppMode = .viewer {
        willSet {
            // Observe every original mode publication, including equal writes.
            // This metadata neither selects a mode nor replaces TabView's owner.
            if let revision = nativeModePresentationRevision, revision < .max {
                nativeModePresentationRevision = revision + 1
            } else {
                nativeModePresentationRevision = nil
            }
        }
    }
    @ObservationIgnored private(set) var nativeModePresentationRevision: UInt64? = 0
    var selectedBook: BooksData? {
        willSet {
            activeReaderTabPresentation?.bookWillChange(to: newValue)
            StudyWorkspaceNavigationAdapter.nativeGroupBookWillChange(self, to: newValue)
            // Original presentation ownership metadata. Every setter, including
            // an equal-value write, advances; exhaustion can never recycle it.
            if let revision = selectedBookPresentationRevision, revision < .max {
                selectedBookPresentationRevision = revision + 1
            } else {
                selectedBookPresentationRevision = nil
            }
        }
        didSet {
            selectedBookPresentationMode = selectedBook.map { _ in currentMode }
            StudyWorkspaceNavigationAdapter.nativeGroupBookDidChange(self)
            activeReaderTabPresentation?.bookDidChange()
        }
    }
    @ObservationIgnored private weak var activeReaderTabPresentation: ActiveReaderTabPresentation?
    private(set) var selectedBookPresentationRevision: UInt64? = 0
    private(set) var selectedBookPresentationMode: AppMode?


    var openTabs: [ReaderTab] = [] {
        willSet { StudyWorkspaceNavigationAdapter.nativeMappingTabsWillChange(self, to: newValue) }
        didSet { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) }
    }

    var activeTabId: UUID? {
        willSet { StudyWorkspaceNavigationAdapter.nativeMappingSelectionWillChange(self, to: newValue) }
        didSet { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) }
    }

    func switchToMode(_ mode: AppMode) {
        currentMode = mode
    }

    func selectTab(id: UUID) {
        guard activeTabId != id else { return }
        if let activeId = activeTabId, let currentTab = openTabs.first(where: { $0.id == activeId }) {
            currentTab.viewModel.saveCurrentState()
            if activeId != id { currentTab.viewModel.closeReaderInspector() }
        }
        activeTabId = id
        if let nextTab = openTabs.first(where: { $0.id == id }) {
            presentOriginalSelectedTab(nextTab) { _ in }
        }
        persistCurrentSession(immediate: false)
    }

    private func presentOriginalSelectedTab(
        _ nextTab: ReaderTab,
        before: (ActiveReaderTabPresentation.Step) throws -> Void
    ) rethrows {
        try before(.annotation)
        nextTab.viewModel.annotationEvent = nil
        try before(.search)
        nextTab.viewModel.searchEvent = nil
        try before(.restore)
        nextTab.viewModel.needsScrollRestore = true
        try before(.book)
        selectedBook = nextTab.book
        try before(.content)
        selectedContentId = nextTab.viewModel.currentContentId
    }

    func retainActiveReaderTabPresentation(requestID: UUID, tab: ReaderTab) throws -> ActiveReaderTabPresentation {
        guard activeReaderTabPresentation == nil else { throw StudyWorkspaceError.invalidMembership }
        let value = try ActiveReaderTabPresentation(requestID: requestID, manager: self, tab: tab)
        activeReaderTabPresentation = value
        do { try value.validate(); return value }
        catch { value.release(); throw error }
    }

    @MainActor final class ActiveReaderTabPresentation {
        fileprivate enum Step: Int { case annotation, search, restore, book, content }
        private enum Phase: Equatable { case retained, applying, completed, invalid, released }
        private enum BookPhase: Equatable { case waiting, publishing, published }
        let requestID: UUID
        private weak var manager: iOSNavigationManager?
        private let tab: ReaderTab
        private let bookRevision: UInt64
        private var phase: Phase = .retained
        private var bookPhase: BookPhase = .waiting
        private var nextStep = 0

        var hasPublishedBook: Bool { bookPhase == .published }

        fileprivate init(requestID: UUID, manager: iOSNavigationManager, tab: ReaderTab) throws {
            guard !MaktabahApp.isIpad, manager.activeTabId == tab.id,
                  manager.selectedBook == nil, manager.selectedBookPresentationMode == nil,
                  let revision = manager.selectedBookPresentationRevision, revision < .max else {
                throw StudyWorkspaceError.invalidMembership
            }
            self.requestID = requestID; self.manager = manager; self.tab = tab; bookRevision = revision
        }

        private func originalOwner() throws -> iOSNavigationManager {
            guard phase != .invalid, phase != .released, let manager,
                  manager.activeReaderTabPresentation === self, !MaktabahApp.isIpad,
                  manager.activeTabId == tab.id else { throw StudyWorkspaceError.invalidMembership }
            let matches = manager.openTabs.filter { $0.id == tab.id }
            guard matches.count == 1, let actual = matches.first,
                  actual.book === tab.book, actual.viewModel === tab.viewModel else {
                throw StudyWorkspaceError.invalidMembership
            }
            return manager
        }

        func validate() throws {
            let manager = try originalOwner()
            guard bookPhase != .publishing,
                  phase == .retained || manager.currentMode == .viewer,
                  manager.selectedBook === (hasPublishedBook ? tab.book : nil),
                  manager.selectedBookPresentationMode == (hasPublishedBook ? .viewer : nil),
                  manager.selectedBookPresentationRevision == bookRevision + (hasPublishedBook ? 1 : 0) else {
                throw StudyWorkspaceError.invalidMembership
            }
        }

        fileprivate func bookWillChange(to value: BooksData?) {
            do {
                try validate()
                guard phase == .applying, nextStep == Step.book.rawValue + 1,
                      bookPhase == .waiting, value === tab.book else { throw StudyWorkspaceError.invalidMembership }
                // Consume BEFORE the original Group/Observation callbacks.
                // A second/equal/nested setter invalidates; ordinary UI still
                // performs its own setter and is never blocked by this proof.
                bookPhase = .publishing
            } catch { phase = .invalid }
        }

        fileprivate func bookDidChange() {
            do {
                let manager = try originalOwner()
                guard phase == .applying, bookPhase == .publishing,
                      nextStep == Step.book.rawValue + 1, manager.currentMode == .viewer,
                      manager.selectedBook === tab.book, manager.selectedBookPresentationMode == .viewer,
                      manager.selectedBookPresentationRevision == bookRevision + 1 else {
                    throw StudyWorkspaceError.invalidMembership
                }
                bookPhase = .published
            } catch { phase = .invalid }
        }

        /// Called only inside the SAME Core-authorized original selection.
        /// The supplied check cannot grant an effect; it rechecks the retained
        /// binding before each original assignment and around persistence.
        func apply(validateSource: () throws -> Void) throws {
            do {
                try validate()
                guard phase == .retained else { throw StudyWorkspaceError.invalidMembership }
                let manager = try originalOwner()
                guard manager.currentMode == .viewer else { throw StudyWorkspaceError.invalidMembership }
                phase = .applying
                try manager.presentOriginalSelectedTab(tab) { [self] step in
                    guard phase == .applying, nextStep == step.rawValue else { throw StudyWorkspaceError.invalidMembership }
                    nextStep += 1
                    try validate(); try validateSource(); try validate()
                    guard phase == .applying, nextStep == step.rawValue + 1 else { throw StudyWorkspaceError.invalidMembership }
                }
                guard hasPublishedBook, nextStep == Step.content.rawValue + 1 else { throw StudyWorkspaceError.invalidMembership }
                try validate(); try validateSource(); try validate()
                manager.persistCurrentSession(immediate: false)
                try validate(); try validateSource(); try validate()
                guard phase == .applying else { throw StudyWorkspaceError.invalidMembership }
                phase = .completed
            } catch { phase = .invalid; throw error }
        }

        func release() {
            phase = .released
            if manager?.activeReaderTabPresentation === self { manager?.activeReaderTabPresentation = nil }
        }
    }
    var selectedContentId: Int? { didSet { contentPublications += 1 } }
    @ObservationIgnored var contentPublications = 0
    @ObservationIgnored var persistCalls: [Bool] = []
    @ObservationIgnored var persistHook: (() -> Void)?
    func persistCurrentSession(immediate: Bool = false) {
        persistCalls.append(immediate); persistHook?()
    }
    // Explicit test fixture access to the actual private metadata field;
    // production has no setter or route input for this value.
    func fixtureBookRevision(_ value: UInt64?) { selectedBookPresentationRevision = value }

}

@MainActor final class Fixture {
    let manager = iOSNavigationManager()
    let first: iOSNavigationManager.ReaderTab
    let active: iOSNavigationManager.ReaderTab
    init() {
        MaktabahApp.isIpad = false; StudyWorkspaceNavigationAdapter.reset()
        first = .init(id: UUID(), book: BooksData(103), initialContentId: nil, viewModel: ReaderViewModel())
        active = .init(id: UUID(), book: BooksData(103), initialContentId: nil, viewModel: ReaderViewModel())
        active.viewModel.currentContentId = 911
        manager.openTabs = [first, active]; manager.activeTabId = active.id
    }
}
@main struct Controls {
    @MainActor static func main() {
        var passed = 0, failed = 0
        func require(_ value: Bool, _ reason: String) throws { if !value { throw ControlError.failed(reason) } }
        func refuses(_ run: () throws -> Void) -> Bool { do { try run(); return false } catch { return true } }
        func test(_ name: String, _ body: () throws -> Void) {
            do { try body(); passed += 1; print("PASS " + name) }
            catch { failed += 1; print("FAIL \(name): \(error)") }
        }
        test("ordinary already-active selection remains a complete no-op") {
            let f = Fixture(); f.manager.selectTab(id: f.active.id)
            try require(f.manager.selectedBook == nil && f.manager.selectedBookPresentationRevision == 0, "no original presentation")
            try require(f.manager.persistCalls.isEmpty && f.active.viewModel.events.isEmpty && f.active.viewModel.saveCalls == 0, "ordinary early return")
        }
        test("ordinary different-tab selection preserves original effects and order") {
            let f = Fixture(); f.manager.selectTab(id: f.first.id)
            try require(f.manager.activeTabId == f.first.id && f.manager.selectedBook === f.first.book, "exact original target")
            try require(f.active.viewModel.saveCalls == 1 && f.active.viewModel.closeCalls == 1, "original outgoing state")
            try require(f.first.viewModel.events == ["annotation", "search", "restore"], "same assignment order")
            try require(f.manager.selectedContentId == 523 && f.manager.persistCalls == [false], "original content and persistence")
            try require(f.manager.nativeModePresentationRevision == 0, "no new mode publication")
        }
        test("ordinary invalid tab ID preserves original behavior") {
            let f = Fixture(); let missing = UUID(); f.manager.selectTab(id: missing)
            try require(f.manager.activeTabId == missing && f.manager.selectedBook == nil && f.manager.persistCalls == [false], "original missing-tab path")
        }

        test("hidden phone retains and presents exact active original tab once") {
            let f = Fixture(); let request = UUID(); let ids = f.manager.openTabs.map(\.id)
            let owner = try f.manager.retainActiveReaderTabPresentation(requestID: request, tab: f.active)
            try owner.apply(validateSource: {})
            try owner.validate()
            try require(owner.requestID == request && owner.hasPublishedBook, "same one-use owner")
            try require(f.manager.activeTabId == f.active.id && f.manager.openTabs.map(\.id) == ids, "unchanged tabs")
            try require(f.manager.selectedBook === f.active.book && f.manager.selectedBookPresentationRevision == 1, "one original book setter")
            try require(f.manager.selectedContentId == 911 && f.manager.persistCalls == [false], "original content/persist path")
            try require(f.manager.nativeModePresentationRevision == 0, "no mode assignment")
        }
        test("duplicate book IDs retain distinct original tab and Reader identity") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            try owner.apply(validateSource: {})
            try require(f.manager.selectedBook === f.active.book && f.manager.selectedBook !== f.first.book, "actual tab book identity")
            try require(f.first.viewModel.events.isEmpty && f.active.viewModel.events == ["annotation", "search", "restore"], "actual Reader identity")
        }
        test("already-visible phone refuses the hidden-only permit") {
            let f = Fixture(); f.manager.selectedBook = f.active.book
            try require(refuses { _ = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active) }, "visible state is not hidden")
        }
        test("iPad refuses the phone-only presentation permit") {
            let f = Fixture(); MaktabahApp.isIpad = true
            try require(refuses { _ = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active) }, "phone-only")
            MaktabahApp.isIpad = false
        }
        test("exhausted original revision cannot issue a permit") {
            let f = Fixture(); f.manager.fixtureBookRevision(.max)
            try require(refuses { _ = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active) }, "overflow refuses")
            f.manager.fixtureBookRevision(nil)
            try require(refuses { _ = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active) }, "nil refuses")
        }
        test("foreign mode must reach actual Viewer before the original effect") {
            let f = Fixture(); f.manager.switchToMode(.history)
            let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            try require(refuses { try owner.apply(validateSource: {}) }, "foreign parent not yet ready")
            try require(f.manager.selectedBook == nil && f.active.viewModel.events.isEmpty, "no early effect")
            f.manager.switchToMode(.viewer)
            try require(refuses { try owner.apply(validateSource: {}) }, "failed owner not rearmed")
        }
        test("retained owner permits the original parent mode publication without selecting it") {
            let f = Fixture(); f.manager.switchToMode(.search)
            let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            try owner.validate(); f.manager.switchToMode(.viewer)
            let revision = f.manager.nativeModePresentationRevision
            try owner.apply(validateSource: {})
            try require(f.manager.nativeModePresentationRevision == revision, "original parent remains sole mode writer")
        }
        test("closed and replaced original tab source cannot present") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            f.manager.openTabs.removeLast()
            try require(refuses { try owner.apply(validateSource: {}) }, "closed source")
            try require(f.manager.selectedBook == nil, "no replacement lookup")
        }
        test("same tab UUID with replacement Reader cannot donate ownership") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            f.manager.openTabs[1].viewModel = ReaderViewModel()
            try require(refuses { try owner.apply(validateSource: {}) }, "exact retained Reader")
        }
        test("equal nil original setter retires a retained permit") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            f.manager.selectedBook = nil
            try require(refuses { try owner.apply(validateSource: {}) }, "equal publication is not absence")
        }
        test("original book nil-to-foreign-to-nil ABA cannot restore a permit") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            f.manager.selectedBook = f.first.book; f.manager.selectedBook = nil
            try require(refuses { try owner.apply(validateSource: {}) }, "source history retired")
        }
        test("one-use setter fence rejects nested counter-only ABA") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            let before = f.manager.selectedBookPresentationRevision!
            var nested = false
            withObservationTracking { _ = f.manager.selectedBookPresentationRevision } onChange: {
                MainActor.assumeIsolated {
                    if !nested { nested = true; f.manager.selectedBook = f.first.book; f.manager.selectedBook = nil }
                }
            }
            try require(refuses { try owner.apply(validateSource: {}) }, "nested setter must refuse")
            try require(nested && f.manager.selectedBookPresentationRevision == before + 1, "actual lost-update counterexample reached")
            try require(f.manager.contentPublications == 0 && f.manager.persistCalls.isEmpty, "no later effects after stale book boundary")
        }
        test("release during annotation callback stops before the next original assignment") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            f.active.viewModel.annotationHook = { owner.release() }
            try require(refuses { try owner.apply(validateSource: {}) }, "released owner")
            try require(f.active.viewModel.events == ["annotation"] && f.manager.selectedBook == nil && f.manager.persistCalls.isEmpty, "partial effect remains bounded")
        }
        test("replacement registration cannot be erased or borrowed by old owner") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            var replacement: iOSNavigationManager.ActiveReaderTabPresentation?
            f.active.viewModel.annotationHook = {
                owner.release()
                replacement = try? f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            }
            try require(refuses { try owner.apply(validateSource: {}) }, "old ownership stopped")
            owner.release(); f.active.viewModel.annotationHook = nil
            guard let replacement else { throw ControlError.failed("new exact owner retained") }
            try replacement.validate(); try replacement.apply(validateSource: {})
            try require(f.manager.selectedBook === f.active.book, "new independent owner remains intact")
        }
        test("release inside original Group will callback cannot earn completion") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            StudyWorkspaceNavigationAdapter.bookWill = { _, _ in owner.release() }
            try require(refuses { try owner.apply(validateSource: {}) }, "setter release")
            try require(f.manager.selectedBook === f.active.book && f.manager.persistCalls.isEmpty && f.manager.contentPublications == 0, "actual partial book effect is not ACK")
        }
        test("original Group callbacks cannot reenter the one-use setter") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            var willClosed = false, didClosed = false
            StudyWorkspaceNavigationAdapter.bookWill = { _, _ in willClosed = refuses { try owner.validate() } }
            StudyWorkspaceNavigationAdapter.bookDid = { _ in didClosed = refuses { try owner.validate() } }
            try owner.apply(validateSource: {})
            try require(willClosed && didClosed && StudyWorkspaceNavigationAdapter.events == ["group-will", "group-did"], "consume before and complete after original callbacks")
        }
        test("reentrant apply during source validation consumes nothing twice") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            var entered = false
            try require(refuses { try owner.apply {
                if !entered { entered = true; _ = refuses { try owner.apply(validateSource: {}) } }
            } }, "nested attempt retires original")
            try require(entered && f.active.viewModel.events.isEmpty && f.manager.selectedBook == nil, "no replay effects")
        }
        test("completed permit cannot replay presentation") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            try owner.apply(validateSource: {}); let events = f.active.viewModel.events
            try require(refuses { try owner.apply(validateSource: {}) }, "one-use completed")
            try require(f.manager.selectedBookPresentationRevision == 1 && f.active.viewModel.events == events && f.manager.persistCalls == [false], "no repeated effect")
        }
        test("source revocation after restore stops before the book setter") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            var valid = true; f.active.viewModel.restoreHook = { valid = false }
            try require(refuses { try owner.apply { if !valid { throw ControlError.staleSource } } }, "same source callback enforced")
            try require(f.manager.selectedBook == nil && f.manager.contentPublications == 0 && f.manager.persistCalls.isEmpty, "no late presentation")
        }
        test("cancellation after original book setter preserves failure and stops later effects") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            var cancelled = false; StudyWorkspaceNavigationAdapter.bookDid = { _ in cancelled = true }
            var sawCancellation = false
            do { try owner.apply { if cancelled { throw CancellationError() } } }
            catch is CancellationError { sawCancellation = true }
            try require(sawCancellation && f.manager.selectedBook === f.active.book && f.manager.contentPublications == 0 && f.manager.persistCalls.isEmpty, "actual error and partial effect")
        }
        test("source revocation during original persistence is never completion") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            var valid = true; f.manager.persistHook = { valid = false }
            try require(refuses { try owner.apply { if !valid { throw ControlError.staleSource } } }, "post-persistence check")
            try require(f.manager.persistCalls == [false] && owner.hasPublishedBook, "exact recorded partial effect remains")
        }
        test("equal original setter after completion invalidates final proof") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            try owner.apply(validateSource: {}); f.manager.selectedBook = f.active.book
            try require(refuses { try owner.validate() }, "post-effect source history cannot be rearmed")
        }
        test("ordinary foreign selection remains effective while retiring a retained permit") {
            let f = Fixture(); let owner = try f.manager.retainActiveReaderTabPresentation(requestID: UUID(), tab: f.active)
            f.manager.selectTab(id: f.first.id)
            try require(f.manager.activeTabId == f.first.id && f.manager.selectedBook === f.first.book && f.manager.persistCalls == [false], "ordinary user operation preserved")
            try require(refuses { try owner.validate() }, "old native owner retired")
        }

        print("RESULT passed=\(passed) failed=\(failed)")
        if failed > 0 { exit(1) }
    }
}
