import Foundation
import Observation

// Explicit app-domain boundaries. The Manager declaration bodies, original
// setter callbacks, selection action, factored presentation, and new one-use
// owner are extracted verbatim below. No UIKit/Core/native receipt is mocked
// into acceptance: this executable tests only those synchronous source bodies.
enum AppMode: Equatable { case viewer, history, search }
enum StudyWorkspaceError: Error { case invalidMembership }
enum ControlError: Error { case failed(String), staleSource }
@MainActor enum MaktabahApp { static var isIpad = false }
@MainActor final class BooksData { let id: Int; init(_ id: Int) { self.id = id } }
@MainActor @Observable final class ReaderViewModel {
    var annotationEvent: String? = "note" { didSet { events.append("annotation"); annotationHook?() } }
    var searchEvent: String? = "query" { didSet { events.append("search"); searchHook?() } }
    var needsScrollRestore = false { didSet { events.append("restore"); restoreHook?() } }
    var currentContentId: Int? = 523
    @ObservationIgnored var events: [String] = []
    @ObservationIgnored var annotationHook: (() -> Void)?
    @ObservationIgnored var searchHook: (() -> Void)?
    @ObservationIgnored var restoreHook: (() -> Void)?
    @ObservationIgnored var saveCalls = 0
    @ObservationIgnored var closeCalls = 0
    func saveCurrentState() { saveCalls += 1 }
    func closeReaderInspector() { closeCalls += 1 }
}
@MainActor enum StudyWorkspaceNavigationAdapter {
    static var bookWill: ((iOSNavigationManager, BooksData?) -> Void)?
    static var bookDid: ((iOSNavigationManager) -> Void)?
    static var events: [String] = []
    static func reset() { bookWill = nil; bookDid = nil; events = [] }
    static func nativeGroupBookWillChange(_ manager: iOSNavigationManager, to book: BooksData?) {
        events.append("group-will"); bookWill?(manager, book)
    }
    static func nativeGroupBookDidChange(_ manager: iOSNavigationManager) {
        events.append("group-did"); bookDid?(manager)
    }
    static func nativeMappingTabsWillChange(_ manager: iOSNavigationManager, to value: [iOSNavigationManager.ReaderTab]) {}
    static func nativeMappingSelectionWillChange(_ manager: iOSNavigationManager, to value: UUID?) {}
    static func nativeMappingDidChange(_ manager: iOSNavigationManager) {}
}

@MainActor @Observable final class iOSNavigationManager {
    struct ReaderTab: Identifiable, Equatable {
        let id: UUID
        let book: BooksData
        var initialContentId: Int?
        var viewModel: ReaderViewModel

        static func == (lhs: ReaderTab, rhs: ReaderTab) -> Bool {
            lhs.id == rhs.id
        }
    }

    var currentMode: AppMode = .viewer {
        willSet {
            // Observe every original mode publication, including equal writes.
            // This metadata neither selects a mode nor replaces TabView's owner.
            if let revision = nativeModePresentationRevision, revision < .max {
                nativeModePresentationRevision = revision + 1
            } else {
                nativeModePresentationRevision = nil
            }
        }
    }
    @ObservationIgnored private(set) var nativeModePresentationRevision: UInt64? = 0
    var selectedBook: BooksData? {
        willSet {
            StudyWorkspaceNavigationAdapter.nativeGroupBookWillChange(self, to: newValue)
            // Original presentation ownership metadata. Every setter, including
            // an equal-value write, advances; exhaustion can never recycle it.
            if let revision = selectedBookPresentationRevision, revision < .max {
                selectedBookPresentationRevision = revision + 1
            } else {
                selectedBookPresentationRevision = nil
            }
        }
        didSet {
            selectedBookPresentationMode = selectedBook.map { _ in currentMode }
            StudyWorkspaceNavigationAdapter.nativeGroupBookDidChange(self)
        }
    }
    private(set) var selectedBookPresentationRevision: UInt64? = 0
    private(set) var selectedBookPresentationMode: AppMode?


    var openTabs: [ReaderTab] = [] {
        willSet { StudyWorkspaceNavigationAdapter.nativeMappingTabsWillChange(self, to: newValue) }
        didSet { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) }
    }

    var activeTabId: UUID? {
        willSet { StudyWorkspaceNavigationAdapter.nativeMappingSelectionWillChange(self, to: newValue) }
        didSet { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) }
    }

    func switchToMode(_ mode: AppMode) {
        currentMode = mode
    }

    func selectTab(id: UUID) {
        guard activeTabId != id else { return }
        if let activeId = activeTabId, let currentTab = openTabs.first(where: { $0.id == activeId }) {
            currentTab.viewModel.saveCurrentState()
            if activeId != id { currentTab.viewModel.closeReaderInspector() }
        }
        activeTabId = id
        if let nextTab = openTabs.first(where: { $0.id == id }) {
            nextTab.viewModel.annotationEvent = nil
            nextTab.viewModel.searchEvent = nil
            nextTab.viewModel.needsScrollRestore = true
            selectedBook = nextTab.book
            selectedContentId = nextTab.viewModel.currentContentId
        }
        persistCurrentSession(immediate: false)
    }
    var selectedContentId: Int? { didSet { contentPublications += 1 } }
    @ObservationIgnored var contentPublications = 0
    @ObservationIgnored var persistCalls: [Bool] = []
    @ObservationIgnored var persistHook: (() -> Void)?
    func persistCurrentSession(immediate: Bool = false) {
        persistCalls.append(immediate); persistHook?()
    }
    // Explicit test fixture access to the actual private metadata field;
    // production has no setter or route input for this value.
    func fixtureBookRevision(_ value: UInt64?) { selectedBookPresentationRevision = value }

}

@MainActor final class Fixture {
    let manager = iOSNavigationManager()
    let first: iOSNavigationManager.ReaderTab
    let active: iOSNavigationManager.ReaderTab
    init() {
        MaktabahApp.isIpad = false; StudyWorkspaceNavigationAdapter.reset()
        first = .init(id: UUID(), book: BooksData(103), initialContentId: nil, viewModel: ReaderViewModel())
        active = .init(id: UUID(), book: BooksData(103), initialContentId: nil, viewModel: ReaderViewModel())
        active.viewModel.currentContentId = 911
        manager.openTabs = [first, active]; manager.activeTabId = active.id
    }
}
@main struct Controls {
    @MainActor static func main() {
        var passed = 0, failed = 0
        func require(_ value: Bool, _ reason: String) throws { if !value { throw ControlError.failed(reason) } }
        func refuses(_ run: () throws -> Void) -> Bool { do { try run(); return false } catch { return true } }
        func test(_ name: String, _ body: () throws -> Void) {
            do { try body(); passed += 1; print("PASS " + name) }
            catch { failed += 1; print("FAIL \(name): \(error)") }
        }
        test("ordinary already-active selection remains a complete no-op") {
            let f = Fixture(); f.manager.selectTab(id: f.active.id)
            try require(f.manager.selectedBook == nil && f.manager.selectedBookPresentationRevision == 0, "no original presentation")
            try require(f.manager.persistCalls.isEmpty && f.active.viewModel.events.isEmpty && f.active.viewModel.saveCalls == 0, "ordinary early return")
        }
        test("ordinary different-tab selection preserves original effects and order") {
            let f = Fixture(); f.manager.selectTab(id: f.first.id)
            try require(f.manager.activeTabId == f.first.id && f.manager.selectedBook === f.first.book, "exact original target")
            try require(f.active.viewModel.saveCalls == 1 && f.active.viewModel.closeCalls == 1, "original outgoing state")
            try require(f.first.viewModel.events == ["annotation", "search", "restore"], "same assignment order")
            try require(f.manager.selectedContentId == 523 && f.manager.persistCalls == [false], "original content and persistence")
            try require(f.manager.nativeModePresentationRevision == 0, "no new mode publication")
        }
        test("ordinary invalid tab ID preserves original behavior") {
            let f = Fixture(); let missing = UUID(); f.manager.selectTab(id: missing)
            try require(f.manager.activeTabId == missing && f.manager.selectedBook == nil && f.manager.persistCalls == [false], "original missing-tab path")
        }

        test("counter-only retained presentation refuses nested original setter ABA") {
            let f = Fixture(); let before = f.manager.selectedBookPresentationRevision!
            var nested = false
            withObservationTracking { _ = f.manager.selectedBookPresentationRevision } onChange: {
                MainActor.assumeIsolated {
                    if !nested {
                        nested = true
                        f.manager.selectedBook = f.first.book
                        f.manager.selectedBook = nil
                    }
                }
            }
            // Deliberate counter-only negative control of the proposed boundary.
            // The actual ORIGINAL setter below is unchanged, including its
            // observable revision update; this is not a native product route.
            f.manager.selectedBook = f.active.book
            let falseAcceptance = f.manager.selectedBook === f.active.book
                && f.manager.selectedBookPresentationMode == .viewer
                && f.manager.selectedBookPresentationRevision == before + 1
            try require(nested && !falseAcceptance, "three original setters collapsed into the apparently allowed +1")
        }

        print("RESULT passed=\(passed) failed=\(failed)")
        if failed > 0 { exit(1) }
    }
}
