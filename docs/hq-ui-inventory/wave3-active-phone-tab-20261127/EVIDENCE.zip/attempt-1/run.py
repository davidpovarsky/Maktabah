import datetime,hashlib,json,os,pathlib,shutil,signal,subprocess,time,traceback
ROOT=pathlib.Path(__file__).resolve().parent
TASK=ROOT.parent
FLOOR=1342177280
CAP=104857600
SWIFT='/usr/local/bin/swiftc'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def allocated(): return sum(p.lstat().st_blocks*512 for p in TASK.rglob('*'))
def capacity():
 value={'rootfs_free':shutil.disk_usage(ROOT).free,'task_allocated':allocated()}
 if value['rootfs_free']<FLOOR or value['task_allocated']>CAP: raise RuntimeError('capacity stop '+str(value))
 return value
def save(name,obj):
 with (ROOT/name).open('x') as f: json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
def step(name,argv,expect):
 entry={'name':name,'argv':argv,'started':now(),'before':capacity()}
 stdout=(ROOT/(name+'.stdout')).open('xb');stderr=(ROOT/(name+'.stderr')).open('xb')
 p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,start_new_session=True);entry['pid']=p.pid
 began=time.monotonic()
 try:
  while p.poll() is None:
   time.sleep(.5);capacity()
   if time.monotonic()-began>90: raise TimeoutError(name)
 except BaseException:
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  raise
 finally:stdout.close();stderr.close()
 entry['exit']=p.returncode;entry['finished']=now();entry['after']=capacity()
 result['steps'].append(entry);print(json.dumps(entry),flush=True)
 if p.returncode not in expect: raise RuntimeError(name+' exit '+str(p.returncode))
 return p.returncode
result={'schema':'otzaria.active-phone.original-manager.controls.v1','status':'NOT_COMPLETE','started':now(),'steps':[],'floor_bytes':FLOOR,'cap_bytes':CAP,'scope':'actual original setter/selection/new permit bodies with explicit app-domain callbacks; UIKit/Core/app/native NOT_RUN'}
try:
 save('STARTED.json',{'pid':os.getpid(),'started':result['started'],'before':capacity()})
 print(json.dumps({'pid':os.getpid(),'started':result['started'],'before':capacity()}),flush=True)
 result['swift_version']=subprocess.check_output([SWIFT,'--version'],text=True)
 cache=ROOT/'module-cache';cache.mkdir()
 for variant in ['baseline','candidate']:
  source=ROOT/'inputs/controls'/('ActualManager-'+variant+'.swift')
  executable=ROOT/('controls-'+variant)
  step(variant+'-compile',[SWIFT,'-swift-version','6','-parse-as-library','-module-cache-path',str(cache),str(source),'-o',str(executable)],[0])
  step(variant+'-run',[str(executable)],[1] if variant=='baseline' else [0])
  result[variant]={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'executable_sha256':hashlib.sha256(executable.read_bytes()).hexdigest(),'stdout':(ROOT/(variant+'-run.stdout')).read_text()}
 result['status']='SOURCE_CONTROLS_COMPLETE'
except BaseException as e:
 result['status']='FAILED';result['error']=repr(e);result['traceback']=traceback.format_exc()
finally:
 result['finished']=now();result['after']={'rootfs_free':shutil.disk_usage(ROOT).free,'task_allocated':allocated()}
 save('RESULT.json',result);print(json.dumps({'status':result['status'],'error':result.get('error'),'after':result['after']}),flush=True)
