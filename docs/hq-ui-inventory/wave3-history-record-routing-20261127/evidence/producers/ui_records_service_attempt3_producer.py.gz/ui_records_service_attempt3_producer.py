import pathlib,json,hashlib,subprocess,shutil,os,time,signal,datetime
root=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
base=root/'build/history-record-controls-20261127'; prior=base/'service-attempt-2'; out=base/'service-attempt-3'
assert shutil.disk_usage(root).free>700*1024*1024
rel='Source/ChavrusaText/UIRoutingHost/Tests/ChavrusaUIRoutingHostTests/NativeHistoryRecordIntentServiceTests.swift'
old='position: .legacyLine(position), catalogRevision: "v40", dataRevision: "source-revision")),';new='position: .legacyLine(Int64(position)), catalogRevision: "v40", dataRevision: "source-revision")),'
paths=[root/rel,base/'package-source'/rel]
for p in paths:
 b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='d8e3ad719ea75a917d28e889ea0078c956de7de10c75cfe3a9951a0fc672fa49';assert b.decode().count(old)==1
out.mkdir(exist_ok=False)
for p in paths:p.write_text(p.read_text().replace(old,new))
data=json.loads((prior/'SOURCE_INPUTS.json').read_text())
for f in data['files']:
 p=base/'package-source'/f['path'];b=p.read_bytes()
 if f['path']==rel:f.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 else:assert hashlib.sha256(b).hexdigest()==f['sha256']
inputs=(json.dumps(data,indent=2)+'\n').encode();(out/'SOURCE_INPUTS.json').write_bytes(inputs)
cmd=json.loads((prior/'START.json').read_text())['command'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'raw.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'START.json').write_text(json.dumps({'command':cmd,'pid':p.pid,'pgid':p.pid,'utc':start,'free':shutil.disk_usage(root).free},indent=2)+'\n')
 samples=[];stopped=False
 while p.poll() is None:
  free=shutil.disk_usage(root).free;samples.append({'t':time.time(),'free':free})
  if free<301989888:os.killpg(p.pid,signal.SIGTERM);stopped=True;break
  time.sleep(1)
 try:code=p.wait(timeout=30)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
(out/'DISK_SAMPLES.json').write_text(json.dumps(samples)+'\n')
result={'exit':code,'stoppedForReserve':stopped,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputSha256':hashlib.sha256(inputs).hexdigest(),'rawSha256':hashlib.sha256((out/'raw.log').read_bytes()).hexdigest(),'freeAfter':shutil.disk_usage(root).free,'scope':'actual original package compilation; only History record service tests; no app/native proof'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
lines=(out/'raw.log').read_text().splitlines();print('\n'.join(x for x in lines if ('error:' in x or 'failed' in x or 'Executed ' in x or 'Test Suite ' in x)))
