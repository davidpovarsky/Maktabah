import pathlib,subprocess,json,hashlib,shutil,datetime,os,signal,time
root=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
base=root/'build/history-record-controls-20261127'
assert shutil.disk_usage(root).free>700*1024*1024
out=base/'service-attempt-1';out.mkdir(exist_ok=False)
pkg=base/'package-source';pkg.mkdir(exist_ok=False)
donor='6d6b45e28969c0f967bfdd4162f70fac879e6cb4'
def blob(path):return subprocess.check_output(['git','-C',str(root),'show',donor+':'+path])
old=json.loads(blob('docs/ui-routing/wave3-semantic-search-intent-20261127/evidence/linux/SOURCE_INPUTS.json'))
prefixes=['Source/Otzaria/Actions/','Source/Otzaria/UIRouting/','Source/ChavrusaText/UIRoutingHost/']
inputs=[]
for entry in old['files']:
 path=entry['path']; rel=next((path[len(p):] for p in prefixes if path.startswith(p)),None)
 if rel is None or not (rel in ['Package.swift','Package.resolved'] or rel.startswith(('Sources/','Tests/'))): continue
 data=blob(path)
 assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],path
 dest=pkg/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);inputs.append(dict(entry,source=donor))
assert len(inputs)==132,len(inputs)
added=['Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/NativeHistoryRecordIntentService.swift','Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/NativeHistoryRecordIntents.swift','Source/ChavrusaText/UIRoutingHost/Tests/ChavrusaUIRoutingHostTests/NativeHistoryRecordIntentServiceTests.swift']
for path in added:
 data=(root/path).read_bytes();dest=pkg/path;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source':'current isolated History packet'})
(out/'SOURCE_INPUTS.json').write_text(json.dumps({'files':inputs,'scope':'actual original three-package SwiftPM inputs; added actual History service/intents/tests'},indent=2)+'\n')
cmd=['/usr/local/bin/swift','test','--package-path',str(pkg/'Source/ChavrusaText/UIRoutingHost'),'--scratch-path',str(base/'cache-restoration/scratch'),'--jobs','2','--filter','NativeHistoryRecordIntentServiceTests']
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'raw.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'START.json').write_text(json.dumps({'command':cmd,'pid':p.pid,'pgid':p.pid,'utc':started,'scope':'actual package source controls; catalog/native transport doubles, SDK/native NOT_RUN','free':shutil.disk_usage(root).free},indent=2)+'\n')
 samples=[];stopped=False
 while p.poll() is None:
  free=shutil.disk_usage(root).free;samples.append({'t':time.time(),'free':free})
  if free<301989888:
   os.killpg(p.pid,signal.SIGTERM);stopped=True;break
  time.sleep(1)
 try:code=p.wait(timeout=30)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
(out/'DISK_SAMPLES.json').write_text(json.dumps(samples)+'\n')
text=(out/'raw.log').read_text()
result={'exit':code,'stoppedForReserve':stopped,'start':started,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputSha256':hashlib.sha256((out/'SOURCE_INPUTS.json').read_bytes()).hexdigest(),'rawSha256':hashlib.sha256((out/'raw.log').read_bytes()).hexdigest(),'freeAfter':shutil.disk_usage(root).free,'scope':'actual package/service controls; no app/native claim'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));print(text[-16000:])
