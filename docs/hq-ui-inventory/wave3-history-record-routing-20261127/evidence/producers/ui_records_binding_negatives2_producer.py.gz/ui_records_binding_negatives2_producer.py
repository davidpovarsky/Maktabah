import pathlib,json,hashlib,subprocess,shutil,os,time,signal,datetime
root=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
base=root/'build/history-record-controls-20261127';prior=base/'binding-attempt-1'
target=base/'package-source/Source/ChavrusaText/UIRoutingHost/Tests/ChavrusaUIRoutingHostTests/HistoryRecordBindingSourceTests.swift'
original=target.read_bytes();manifest=json.loads((prior/'source/SOURCE_INPUTS.json').read_text());assert hashlib.sha256(original).hexdigest()==manifest['generatedSHA256']
assert shutil.disk_usage(root).free>1024*1024*1024
products=base/'cache-restoration/scratch/out/Products/Debug-linux-aarch64'
saved=prior/'preserved-candidate-products'
proof=json.loads((saved/'MANIFEST.json').read_text())
for f in proof:
 p=saved/f['path'];assert p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
variants=[
 ('binding-negative-observation',b'\n                try observation.validate()\n',b'\n', 'HistoryRecordBindingSourceTests.testOriginalModelABAIsRejectedBeforeBegin','four original model ABA variants must fail'),
 ('binding-negative-row-geometry',b'MaktabahNativeHistoryRecordGeometry.isVisible(view, sceneID: sceneID)',b'true','HistoryRecordBindingSourceTests.testOriginalRowGeometryIsRequiredAfterParentReveal','actual row geometry counterfactual must fail; independent window readiness remains active')
]
allResults=[]
try:
 for name,before,after,selector,expectation in variants:
  assert original.count(before)==1
  out=base/name;out.mkdir(exist_ok=False);negative=original.replace(before,after)
  (out/'NEGATIVE_SOURCE.swift').write_bytes(negative);target.write_bytes(negative)
  data=json.loads((prior/'PACKAGE_INPUTS.json').read_text())
  rel=str(target.relative_to(base/'package-source'))
  for f in data['files']:
   p=base/'package-source'/f['path']
   if f['path']==rel:f.update(bytes=len(negative),sha256=hashlib.sha256(negative).hexdigest())
   else:assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
  inputs=(json.dumps(data,indent=2)+'\n').encode();(out/'PACKAGE_INPUTS.json').write_bytes(inputs)
  cmd=json.loads((prior/'START.json').read_text())['command'];cmd[cmd.index('--filter')+1]=selector
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();env=dict(os.environ);env['HISTORY_RECORD_CONTROL_OUTPUT']=str(out/'actual-store-fixtures')
  with (out/'raw.log').open('w') as log:
   p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   (out/'START.json').write_text(json.dumps({'command':cmd,'pid':p.pid,'pgid':p.pid,'utc':start,'free':shutil.disk_usage(root).free,'reserveStopBytes':838860800},indent=2)+'\n')
   samples=[];stopped=False
   while p.poll() is None:
    free=shutil.disk_usage(root).free;samples.append({'t':time.time(),'free':free})
    if free<838860800:os.killpg(p.pid,signal.SIGTERM);stopped=True;break
    time.sleep(1)
   try:code=p.wait(timeout=30)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
  (out/'DISK_SAMPLES.json').write_text(json.dumps(samples)+'\n')
  result={'exit':code,'expected':expectation,'stoppedForReserve':stopped,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packageInputSha256':hashlib.sha256(inputs).hexdigest(),'rawSha256':hashlib.sha256((out/'raw.log').read_bytes()).hexdigest(),'freeAfter':shutil.disk_usage(root).free,'scope':'one exact isolated source predicate counterfactual over domain/UI inputs; no app/native proof'}
  (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');allResults.append(result)
  saved=out/'preserved-negative-products';saved.mkdir();proof=[]
  for product in ['ChavrusaUIRoutingHostTests.so','ChavrusaUIRoutingHostTests-test-runner']:
   p=products/product;q=saved/product;shutil.copy2(p,q);proof.append({'path':product,'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
  (saved/'MANIFEST.json').write_text(json.dumps(proof,indent=2)+'\n')
  print(json.dumps(result),flush=True);print('\n'.join(x[:1000] for x in (out/'raw.log').read_text().splitlines() if ('error:' in x or 'Executed ' in x)),flush=True)
  if stopped:break
finally:
 target.write_bytes(original)
 (base/'BINDING_SOURCE_RESTORED_AFTER_NEGATIVES.json').write_text(json.dumps({'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'restore byte-exact candidate test capsule; production source was never mutated'},indent=2)+'\n')
print(json.dumps({'results':len(allResults),'restoredSHA256':hashlib.sha256(target.read_bytes()).hexdigest(),'freeAfter':shutil.disk_usage(root).free}))
