import pathlib,json,hashlib,subprocess,shutil,os,time,signal,datetime
root=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
base=root/'build/history-record-controls-20261127';prior=base/'service-attempt-3';out=base/'service-selected-item-negative-attempt-2'
assert shutil.disk_usage(root).free>700*1024*1024
out.mkdir(exist_ok=False)
rel='Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/NativeHistoryRecordIntentService.swift';target=base/'package-source'/rel
original=target.read_bytes();assert hashlib.sha256(original).hexdigest()=='cea5c452b7168eba3f8a9617b2b7f330dbe044eff80059e49366b298a0ab5a3c'
guard=b'              receipt.route.state.selectedItemID == record.itemID,\n';assert original.count(guard)==1
(out/'CANDIDATE_SERVICE.swift').write_bytes(original);negative=original.replace(guard,b'');(out/'NEGATIVE_SERVICE.swift').write_bytes(negative)
products=base/'cache-restoration/scratch/out/Products/Debug-linux-aarch64'
bins=[products/'ChavrusaUIRoutingHostTests.so',products/'ChavrusaUIRoutingHostTests-test-runner']
assert all(p.is_file() and not p.is_symlink() for p in bins)
saved=out/'preserved-candidate-products';saved.mkdir();productProof=[]
for binary in bins:
 dest=saved/binary.name;shutil.copy2(binary,dest)
 productProof.append({'originalPath':str(binary),'copyPath':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
(out/'PRESERVED_PRODUCT.json').write_text(json.dumps(productProof,indent=2)+'\n')
data=json.loads((prior/'SOURCE_INPUTS.json').read_text())
for f in data['files']:
 p=base/'package-source'/f['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
 if f['path']==rel:f.update(bytes=len(negative),sha256=hashlib.sha256(negative).hexdigest())
inputs=(json.dumps(data,indent=2)+'\n').encode();(out/'SOURCE_INPUTS.json').write_bytes(inputs)
cmd=json.loads((prior/'START.json').read_text())['command'];cmd[cmd.index('--filter')+1]='NativeHistoryRecordIntentServiceTests.testRootReceiptAndWrongItemCannotSatisfyRecordReveal'
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 target.write_bytes(negative)
 with (out/'raw.log').open('w') as log:
  p=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (out/'START.json').write_text(json.dumps({'command':cmd,'pid':p.pid,'pgid':p.pid,'utc':start,'free':shutil.disk_usage(root).free},indent=2)+'\n')
  samples=[];stopped=False
  while p.poll() is None:
   free=shutil.disk_usage(root).free;samples.append({'t':time.time(),'free':free})
   if free<301989888:os.killpg(p.pid,signal.SIGTERM);stopped=True;break
   time.sleep(1)
  try:code=p.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
finally:target.write_bytes(original)
(out/'DISK_SAMPLES.json').write_text(json.dumps(samples)+'\n')
logtext=(out/'raw.log').read_text()
result={'exit':code,'expected':'one test fails both root-only and wrong-item variants','stoppedForReserve':stopped,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputSha256':hashlib.sha256(inputs).hexdigest(),'rawSha256':hashlib.sha256((out/'raw.log').read_bytes()).hexdigest(),'restoredProductionSourceSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'freeAfter':shutil.disk_usage(root).free,'scope':'isolated package-only counterfactual; original production/worktree service untouched; no app/native proof'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));print('\n'.join(x for x in logtext.splitlines() if ('error:' in x or 'failed' in x or 'Executed ' in x or 'Test Suite ' in x)))
