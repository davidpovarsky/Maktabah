import pathlib,json,hashlib,subprocess,shutil,os,time,signal,datetime
root=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127')
base=root/'build/history-record-controls-20261127';prior=base/'service-attempt-1';out=base/'service-attempt-2'
assert shutil.disk_usage(root).free>700*1024*1024;out.mkdir(exist_ok=False)
mc=base/'cache-restoration/scratch/out/ModuleCache.noindex';saved=base/'cache-restoration/relocated-original-ModuleCache.noindex'
assert mc.is_dir() and not saved.exists()
files=[{'path':str(p.relative_to(mc)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in mc.rglob('*') if p.is_file() and not p.is_symlink()]
mc.rename(saved)
(out/'RELOCATED_CACHE.json').write_text(json.dumps({'reason':'actual compiler rejects PCMs bound to old absolute module cache path','preserved':str(saved),'files':files},indent=2)+'\n')
inputs=(prior/'SOURCE_INPUTS.json').read_bytes();(out/'SOURCE_INPUTS.json').write_bytes(inputs)
for f in json.loads(inputs)['files']:
 p=base/'package-source'/f['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
cmd=json.loads((prior/'START.json').read_text())['command']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'raw.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'START.json').write_text(json.dumps({'command':cmd,'pid':p.pid,'pgid':p.pid,'utc':start,'free':shutil.disk_usage(root).free},indent=2)+'\n')
 samples=[];stopped=False
 while p.poll() is None:
  free=shutil.disk_usage(root).free;samples.append({'t':time.time(),'free':free})
  if free<301989888:os.killpg(p.pid,signal.SIGTERM);stopped=True;break
  time.sleep(1)
 try:code=p.wait(timeout=30)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
(out/'DISK_SAMPLES.json').write_text(json.dumps(samples)+'\n')
result={'exit':code,'stoppedForReserve':stopped,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputSha256':hashlib.sha256(inputs).hexdigest(),'rawSha256':hashlib.sha256((out/'raw.log').read_bytes()).hexdigest(),'freeAfter':shutil.disk_usage(root).free,'scope':'actual original package compilation; only History record service tests; no app/native proof'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((out/'raw.log').read_text()[-12000:])
