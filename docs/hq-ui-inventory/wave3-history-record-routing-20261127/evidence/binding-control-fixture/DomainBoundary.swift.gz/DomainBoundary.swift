// Explicit Foundation/Observation controls. UIKit, SwiftUI Bindings, Combine,
// app models and the Core lifetime callback below are DOMAIN/VIEW DOUBLES.
// They exercise verbatim production ownership/lifecycle methods, not native UI.
@MainActor final class AnyCancellable {
    let cancel: @MainActor () -> Void
    init(_ cancel: @escaping @MainActor () -> Void) { self.cancel = cancel }
    isolated deinit { cancel() }
}
@MainActor final class BoundaryPublisher<Value> {
    var callbacks: [UUID: (Value) -> Void] = [:]
    func send(_ value: Value) { for callback in Array(callbacks.values) { callback(value) } }
    func sink(_ receive: @escaping (Value) -> Void) -> AnyCancellable {
        let id = UUID(); callbacks[id] = receive
        return AnyCancellable { [weak self] in self?.callbacks.removeValue(forKey: id) }
    }
}
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    var activeBackendID: BackendID = .otzaria
    var generation: UInt64 = 1
    var activeTransitionToken: UInt64 = 1
    var usesNativeMaktabahDataPath = false
    var isTransitioning = false
    let objectWillChange = BoundaryPublisher<Void>()
}
@MainActor enum MaktabahApp { static var isIpad = false }
enum iOSTab: Equatable {
    case viewer, search, history, legacy
    var canonical: iOSTab { self == .legacy ? .search : self }
    var appMode: AppMode { self == .viewer ? .viewer : (self == .history ? .history : .search) }
}
enum AppMode { case viewer, search, history }
// BooksData is intentionally NON-observable, matching the actual boundary.
final class BooksData {
    let id: Int
    let book: String
    var backendLocator: TextLocator?
    init(id: Int, book: String, locator: TextLocator?) {
        self.id = id; self.book = book; backendLocator = locator
    }
}
@MainActor @Observable final class ReaderViewModel {
    var isPopoverPresented = false
    var readerInspectorVisible = false
}
@MainActor @Observable final class DonationManager {
    static let shared = DonationManager()
    var showDonationSheet = false
}
@MainActor @Observable final class BoundaryOverview { var blocksRouting = false }
@MainActor final class ReaderSidebarPageCoordinator { let overview = BoundaryOverview() }
struct Transaction { var marker = 0 }
@MainActor struct Binding<Value> {
    let get: () -> Value
    let set: (Value, Transaction) -> Void
    init(get: @escaping () -> Value, set: @escaping (Value) -> Void) {
        self.get = get; self.set = { value, _ in set(value) }
    }
    init(get: @escaping () -> Value, set: @escaping (Value, Transaction) -> Void) {
        self.get = get; self.set = set
    }
    var wrappedValue: Value { get { get() } nonmutating set { set(newValue, Transaction()) } }
    func transaction(_ transaction: Transaction) -> Binding<Value> {
        Binding(get: get, set: { value, _ in set(value, transaction) })
    }
}
@MainActor @Observable final class MappingSource { var event = 1 }
enum MappingCoverage { case liveNativeSetters, unqualified }
struct MappingProjection: Equatable { var value = "original-profile/group/tab" }
struct MappingEpoch: Equatable { var revision: UInt64 = 1 }
@MainActor struct MappingObservation {
    let source: MappingSource
    let owner: ObjectIdentifier
    let scene: String
    let epoch: MappingEpoch
    let projection: MappingProjection
    let coverage: MappingCoverage
}
@MainActor @Observable final class StudyWorkspaceNavigationAdapter {
    var attached = true
    var isSwitching = false
    var sceneID = "original-scene"
    var mappingOwnershipSource = MappingSource()
    var epoch = MappingEpoch()
    var projection = MappingProjection()
    var coverage = MappingCoverage.liveNativeSetters
    let manager: iOSNavigationManager
    init(_ manager: iOSNavigationManager) { self.manager = manager }
    func mappingOwnershipObservation() -> MappingObservation? {
        .init(source: mappingOwnershipSource, owner: ObjectIdentifier(manager), scene: sceneID,
              epoch: epoch, projection: projection, coverage: coverage)
    }
}
@MainActor @Observable final class MaktabahNativeWorkspaceProjectionSource {
    var current: StudyWorkspaceNavigationAdapter?
    var isAuthoritative = true
    init(_ current: StudyWorkspaceNavigationAdapter) { self.current = current }
    func read() throws -> StudyWorkspaceNavigationAdapter? { current }
}
@MainActor final class MaktabahNativeWorkspacePresentationBinding {
    var originalStateRevision: UInt64? = 0
}
struct UIEdgeInsets { var top: CGFloat = 0; var left: CGFloat = 0; var bottom: CGFloat = 0; var right: CGFloat = 0 }
extension CGRect {
    func inset(by value: UIEdgeInsets) -> CGRect {
        .init(x: minX + value.left, y: minY + value.top,
              width: width - value.left - value.right, height: height - value.top - value.bottom)
    }
}
@MainActor class UIView {
    weak var window: UIWindow?
    weak var superview: UIView?
    var bounds = CGRect(x: 0, y: 0, width: 250, height: 50)
    var offset = CGPoint.zero
    var isHidden = false
    var alpha: CGFloat = 1
    var clipsToBounds = false
    func convert(_ rect: CGRect, to: UIView?) -> CGRect { rect.offsetBy(dx: offset.x, dy: offset.y) }
    func isDescendant(of other: UIView) -> Bool {
        var value: UIView? = self
        while let current = value { if current === other { return true }; value = current.superview }
        return false
    }
}
@MainActor final class UIScrollView: UIView {
    var isDragging = false; var isDecelerating = false
    var adjustedContentInset = UIEdgeInsets()
    var contentSize = CGSize(width: 2000, height: 50)
}
@MainActor final class UIWindow: UIView {
    var isKeyWindow = true
    var windowScene: UIWindowScene? = UIWindowScene()
    var rootViewController: UIViewController? = UIViewController()
}
@MainActor final class UIWindowScene {
    enum Activation { case foregroundActive, background }
    var activationState = Activation.foregroundActive
    let session = Session()
    final class Session { var persistentIdentifier = "original-scene" }
}
@MainActor final class UIViewController {
    var view = UIView()
    var viewIfLoaded: UIView? { view }
    var children: [UIViewController] = []
    var presentedViewController: UIViewController?
    var isBeingPresented = false
    var isBeingDismissed = false
    var transitionCoordinator: NSObject?
}
extension String { func normalizeArabic(_ unused: Bool) -> String { self } }

// CryptoKit is not present in this Linux Foundation capsule. Only the record
// hash constructor is an explicit deterministic ID boundary. The actual
// original catalog/filter/publication bodies and real portable entity codec
// execute; no SHA256/native identity claim is made by these lifecycle controls.
@MainActor enum BoundaryRecordIdentity {
    static func make(_ card: HistoryQualifiedPublication.Card,
                     kind: NativeHistoryRecordIntentService.Kind) throws -> NativeHistoryRecordIntentService.Record {
        let position: ActionTextPosition
        switch card.locator.position {
        case .legacyLine(let value): position = .legacyLine(Int64(value))
        case .canonicalRef(let value): position = .canonicalRef(value)
        }
        let ref = ActionTextRef(backend: ActionBackendID(rawValue: card.locator.backend.rawValue)!,
            workKey: card.locator.workKey, position: position)
        return try .init(reference: .init(kind: kind, locator: ref), title: card.book.book,
            itemID: .init(rawValue: "boundary.\(kind.rawValue).\(card.book.id)")!)
    }
}
