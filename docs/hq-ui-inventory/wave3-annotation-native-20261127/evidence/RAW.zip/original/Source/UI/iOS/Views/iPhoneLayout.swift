//
//  iPhoneLayout.swift
//  Maktabah-iOS
//
//  Created by Ghoys Mawahib on 03/05/26.
//

import SwiftUI

// MARK: - iPhone Layout

struct iPhoneLayout: View {
    @Bindable var bManager: iOSNavigationManager
    @Binding var selectedTab: iOSTab
    @Binding var showSettings: Bool
    @State private var showingAddFavorites = false
    @AppStorage("lastSelectedTab") private var savedSelectedTab: iOSTab = .viewer
    @StateObject private var backendCoordinator = BackendCoordinator.shared
    @Environment(\.maktabahNativeRoutingSession) private var routingSession

    var body: some View {
        TabView(selection: $selectedTab) {
            Tab(iOSTab.viewer.title, systemImage: iOSTab.viewer.icon, value: .viewer) {
                viewerTabContent
                    .modifier(MaktabahNativeViewerParentSurface(manager: bManager, selectedTab: selectedTab))
            }

            if iOSTab.search.isAvailable(for: backendCoordinator.activeCapabilities) {
                Tab(iOSTab.search.title, systemImage: iOSTab.search.icon, value: .search) {
                    searchTabContent
                }
            }

            if iOSTab.author.isAvailable(for: backendCoordinator.activeCapabilities) {
                Tab(iOSTab.author.title, systemImage: iOSTab.author.icon, value: .author) {
                    authorTabContent
                }
            }

            Tab(iOSTab.annotations.title, systemImage: iOSTab.annotations.icon, value: .annotations) {
                annotationsTabContent
            }

            Tab(iOSTab.history.title, systemImage: iOSTab.history.icon, value: .history) {
                historyTabContent
            }
        }
        .themeTint()
        .sheet(isPresented: $showingAddFavorites) {
            iOSAddFavoriteSheet(viewModel: HistoryViewModel.shared)
        }
        .onAppear {
            if savedSelectedTab == .textSearch || savedSelectedTab == .zayitSearch {
                selectedTab = .search
                savedSelectedTab = .search
            } else {
                selectedTab = savedSelectedTab.canonical
            }
            if !selectedTab.isAvailable(for: backendCoordinator.activeCapabilities) {
                selectedTab = .viewer
                savedSelectedTab = .viewer
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .activeLibraryBackendDidChange)) { _ in
            if !selectedTab.isAvailable(for: backendCoordinator.activeCapabilities) {
                selectedTab = .viewer
                savedSelectedTab = .viewer
            }
        }
        .onChange(of: selectedTab) { _, newValue in
            let canonical = newValue.canonical
            savedSelectedTab = canonical
            if selectedTab != canonical {
                selectedTab = canonical
            }
            MaktabahNativeViewerModePublication.perform(host: routingSession?.viewerParentHost,
                manager: bManager, mode: canonical.appMode) {
                bManager.switchToMode(canonical.appMode)
            }
        }
        .onChange(of: bManager.currentMode) { _, newMode in
            let matchingTab = iOSTab(appMode: newMode)
            if selectedTab != matchingTab {
                selectedTab = matchingTab
            }
        }
    }

    // Each NavigationStack presents a book only when it owns that Reader.
    private func readerSelection(in tab: iOSTab) -> Binding<BooksData?> {
        Binding(
            get: { bManager.selectedBookPresentationMode == tab.appMode ? bManager.selectedBook : nil },
            set: { book in
                guard bManager.selectedBookPresentationMode == tab.appMode else { return }
                bManager.selectedBook = book
            }
        )
    }

    // MARK: - Tab Contents

    private var viewerTabContent: some View {
        NavigationStack {
            iOSLibraryView()
                .modifier(MaktabahNativeRoutingSurface(kind: .library))
                .navigationTitle(iOSTab.viewer.title)
                .adaptiveReaderPush(
                    item: readerSelection(in: .viewer),
                    manager: bManager
                )
                .toolbarGeneral(showSettings: $showSettings)
        }
        .searchable(
            text: Bindable(bManager.libraryViewModel).searchQuery,
            placement: .toolbar,
            prompt: String(localized: .Library.searchLibrary)
        )
    }

    private var searchTabContent: some View {
        NavigationStack {
            SearchModeView()
                .modifier(MaktabahNativeRoutingSurface(kind: .search))
                .navigationTitle(iOSTab.search.title)
                .adaptiveReaderPush(
                    item: readerSelection(in: .search),
                    manager: bManager
                )
                .toolbarGeneral(showSettings: $showSettings)
        }
    }

    private var authorTabContent: some View {
        NavigationStack {
            AuthorModeView()
                .navigationTitle(iOSTab.author.title)
                .adaptiveReaderPush(
                    item: readerSelection(in: .author),
                    manager: bManager
                )
                .toolbarGeneral(showSettings: $showSettings)
        }
        .searchable(
            text: Bindable(bManager.authorViewModel).searchText,
            placement: .toolbar,
            prompt: String(localized: "Search Narrators")
        )
    }

    private var annotationsTabContent: some View {
        NavigationStack {
            AnnotationListView()
                .modifier(MaktabahNativeRoutingSurface(kind: .annotations))
                .navigationTitle(iOSTab.annotations.title)
                .adaptiveReaderPush(
                    item: readerSelection(in: .annotations),
                    manager: bManager
                )
                .toolbarGeneral(showSettings: $showSettings)
        }
    }

    private var historyTabContent: some View {
        NavigationStack {
            iOSHistoryView()
                .modifier(MaktabahNativeRoutingSurface(kind: .history))
                .navigationTitle(iOSTab.history.title)
                .adaptiveReaderPush(
                    item: readerSelection(in: .history),
                    manager: bManager
                )
                .toolbar {
                    HomeToolbarItems(
                        showSettings: $showSettings,
                        showingAddFavorites: $showingAddFavorites
                    )
                }
        }
        .searchable(
            text: Binding(
                get: { HistoryViewModel.shared.searchText },
                set: { HistoryViewModel.shared.searchText = $0 }
            ),
            placement: .toolbar,
            prompt: String(localized: "Search History & Favorites")
        )
    }
}

// MARK: - Shared Home Toolbar Items

struct HomeToolbarItems: ToolbarContent {
    @Binding var showSettings: Bool
    @Binding var showingAddFavorites: Bool

    var body: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            Button {
                showSettings = true
            } label: {
                Image(systemName: "gear")
            }
            .accessibilityLabel(String(localized: "Settings"))
            .help(String(localized: "Settings"))
        }
        ToolbarItem(placement: .topBarTrailing) {
            Button(action: { showingAddFavorites = true }) {
                Image(systemName: "plus")
            }
            .accessibilityLabel(String(localized: "Add Favorite"))
            .help(String(localized: "Add Favorite"))
        }
    }
}
