import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

actor SefariaHTTPClient {
    private let session: URLSession
    private let decoder: JSONDecoder
    private let maximumAttempts = 3

    init(session: URLSession = .shared) {
        #if DEBUG && (targetEnvironment(simulator) || SEFARIA_TOC_TRANSPORT_ACCEPTANCE_TESTS)
        self.session = SefariaTOCTransportAcceptance.session(replacingShared: session)
        #else
        self.session = session
        #endif
        self.decoder = JSONDecoder()
    }

    func get<T: Decodable & Sendable>(
        _ type: T.Type,
        url: URL,
        timeoutInterval: TimeInterval = 30,
        maxAttempts: Int? = nil
    ) async throws -> T {
        var request = URLRequest(url: url, timeoutInterval: timeoutInterval)
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        #if DEBUG && (targetEnvironment(simulator) || SEFARIA_TOC_TRANSPORT_ACCEPTANCE_TESTS)
        SefariaTOCTransportAcceptance.tag(&request)
        #endif
        return try await send(type, request: request, maxAttempts: maxAttempts ?? maximumAttempts)
    }

    func post<T: Decodable & Sendable, Body: Encodable & Sendable>(
        _ type: T.Type, url: URL, body: Body,
        timeoutInterval: TimeInterval = 30, maxAttempts: Int? = nil
    ) async throws -> T {
        var request = URLRequest(url: url, timeoutInterval: timeoutInterval)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        request.httpBody = try JSONEncoder().encode(body)
        return try await send(type, request: request, maxAttempts: maxAttempts ?? maximumAttempts)
    }

    func postData<Body: Encodable & Sendable>(url: URL, body: Body) async throws -> (Data, HTTPURLResponse) {
        var request = URLRequest(url: url, timeoutInterval: 300)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        request.httpBody = try JSONEncoder().encode(body)
        do {
            let (data, response) = try await session.data(for: request)
            try validate(response)
            guard let http = response as? HTTPURLResponse else {
                throw LibraryBackendError.invalidResponse("missing HTTP response")
            }
            return (data, http)
        } catch {
            throw Self.userFacing(error)
        }
    }

    func data(url: URL) async throws -> Data {
        var request = URLRequest(url: url, timeoutInterval: 120)
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        do {
            let (data, response) = try await session.data(for: request)
            try validate(response)
            return data
        } catch {
            throw Self.userFacing(error)
        }
    }

    func download(url: URL) async throws -> (URL, HTTPURLResponse) {
        var request = URLRequest(url: url, timeoutInterval: 300)
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        do {
            let (temporary, response) = try await session.download(for: request)
            try validate(response)
            guard let response = response as? HTTPURLResponse else {
                throw LibraryBackendError.invalidResponse("missing HTTP response")
            }
            return (temporary, response)
        } catch {
            throw Self.userFacing(error)
        }
    }

    private func send<T: Decodable>(
        _ type: T.Type,
        request: URLRequest,
        maxAttempts: Int = 3
    ) async throws -> T {
        var attempt = 1
        while true {
            try Task.checkCancellation()
            do {
                let (data, response) = try await session.data(for: request)
                try validate(response)
                do { return try decoder.decode(type, from: data) }
                catch { throw LibraryBackendError.invalidResponse(String(describing: error)) }
            } catch {
                try Task.checkCancellation()
                guard attempt < maxAttempts, Self.isTransient(error) else {
                    throw Self.userFacing(error)
                }
                try await Task.sleep(nanoseconds: UInt64(attempt) * 500_000_000)
                try Task.checkCancellation()
                attempt += 1
            }
        }
    }

    nonisolated static func userFacing(_ error: Error) -> Error {
        guard let urlError = error as? URLError else { return error }
        switch urlError.code {
        case .timedOut, .networkConnectionLost, .cannotFindHost, .cannotConnectToHost,
             .dnsLookupFailed, .notConnectedToInternet, .internationalRoamingOff,
             .dataNotAllowed:
            return LibraryBackendError.unavailableOffline
        default:
            return error
        }
    }

    private nonisolated static func isTransient(_ error: Error) -> Bool {
        if let backendError = error as? LibraryBackendError,
           case .httpStatus(let status) = backendError {
            return status == 429 || status == 500 || status == 502 || status == 503 || status == 504
        }
        guard let urlError = error as? URLError else { return false }
        switch urlError.code {
        case .timedOut, .networkConnectionLost, .cannotConnectToHost,
             .dnsLookupFailed, .notConnectedToInternet:
            return true
        default:
            return false
        }
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else {
            throw LibraryBackendError.invalidResponse("missing HTTP status")
        }
        guard (200...299).contains(http.statusCode) else {
            throw LibraryBackendError.httpStatus(http.statusCode)
        }
    }
}

#if DEBUG && (targetEnvironment(simulator) || SEFARIA_TOC_TRANSPORT_ACCEPTANCE_TESTS)
/// Disposable Simulator acceptance only. This never supplies response bytes:
/// one original Remote TOC request is held and fails at URL Loading; retry
/// returns to the unchanged original transport. Embedded Hermes is not covered.
enum SefariaTOCTransportAcceptance {
    struct Configuration: Sendable {
        let namespace: UUID
        let documents: URL

        var prefix: String { "sefaria-toc-" + namespace.uuidString }
        var commandURL: URL { documents.appendingPathComponent(prefix + "-command.json") }
        func url(nonce: UUID, stage: String) -> URL {
            documents.appendingPathComponent(prefix + "-" + nonce.uuidString + "-" + stage + ".json")
        }
    }

    struct Context: Sendable {
        let configuration: Configuration
        let nonce: UUID
        let workKey: String
        let ownerID: String
        var expectedURL: String { "https://www.sefaria.org/api/v2/raw/index/" + workKey }
    }

    @TaskLocal static var context: Context?

    private final class Admission: @unchecked Sendable {
        private let lock = NSLock()
        private var context: Context?
        private var tagged = false
        private var claimed = false

        func arm(_ value: Context) -> Bool {
            lock.lock(); defer { lock.unlock() }
            guard context == nil else { return false }
            context = value
            return true
        }
        func tag(_ value: Context, request: URLRequest) -> Bool {
            lock.lock(); defer { lock.unlock() }
            guard context?.nonce == value.nonce, !tagged, !claimed,
                  request.httpMethod == nil || request.httpMethod == "GET",
                  request.httpBody == nil, request.url?.absoluteString == value.expectedURL else { return false }
            tagged = true
            return true
        }
        func matches(_ request: URLRequest, claim: Bool) -> Context? {
            lock.lock(); defer { lock.unlock() }
            guard let context, tagged, !claimed,
                  let nonce = URLProtocol.property(forKey: propertyKey, in: request) as? String,
                  nonce == context.nonce.uuidString,
                  request.url?.absoluteString == context.expectedURL,
                  request.httpMethod == nil || request.httpMethod == "GET",
                  request.httpBody == nil else { return nil }
            if claim { claimed = true }
            return context
        }
    }

    private static let propertyKey = "org.maktabah.native-toc-one-shot"
    private static let admission = Admission()

    static let configuration: Configuration? = {
        #if targetEnvironment(simulator)
        let environment = ProcessInfo.processInfo.environment
        guard environment["OTZARIA_DATA_PROFILE"] == "miniTest10",
              Bundle.main.bundleIdentifier == "com.davidpovarsky.chavrusatext",
              ProcessInfo.processInfo.arguments.contains("-SefariaTOCTransportAcceptance"),
              UserDefaults.standard.bool(forKey: "SefariaTOCTransportAcceptance"),
              UserDefaults.standard.string(forKey: "preferredBackend") == "sefaria",
              let namespace = UserDefaults.standard.string(forKey: "studyWorkspaceTestingNamespace")
                .flatMap(UUID.init(uuidString:)),
              let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
        let canonical = documents.standardizedFileURL.resolvingSymlinksInPath()
        guard canonical.pathComponents.contains("Application"),
              canonical.lastPathComponent == "Documents",
              UUID(uuidString: canonical.deletingLastPathComponent().lastPathComponent) != nil,
              (try? canonical.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true else { return nil }
        return Configuration(namespace: namespace, documents: canonical)
        #else
        return nil
        #endif
    }()

    private static let configuredSession: URLSession? = {
        guard Self.configuration != nil else { return nil }
        let sessionConfiguration = URLSession.shared.configuration
        sessionConfiguration.protocolClasses = [SefariaTOCFailureURLProtocol.self]
            + (sessionConfiguration.protocolClasses ?? [])
        return URLSession(configuration: sessionConfiguration)
    }()

    static func session(replacingShared session: URLSession) -> URLSession {
        guard session === URLSession.shared else { return session }
        return configuredSession ?? session
    }

    static func tag(_ request: inout URLRequest) {
        guard let context, admission.tag(context, request: request),
              let mutable = (request as NSURLRequest).mutableCopy() as? NSMutableURLRequest else { return }
        URLProtocol.setProperty(context.nonce.uuidString, forKey: propertyKey, in: mutable)
        request = mutable as URLRequest
        record(context, stage: "tagged")
    }

    static func command(configuration: Configuration) -> UUID? {
        guard let object = object(at: configuration.commandURL),
              Set(object.keys) == Set(["schemaVersion", "namespace", "nonce", "backend", "workKey", "operation"]),
              object["schemaVersion"] as? Int == 1,
              object["namespace"] as? String == configuration.namespace.uuidString,
              object["backend"] as? String == "sefaria",
              object["workKey"] as? String == "Genesis",
              object["operation"] as? String == "reloadOwnedTOC",
              let nonce = (object["nonce"] as? String).flatMap(UUID.init(uuidString:)) else { return nil }
        return nonce
    }

    static func arm(configuration: Configuration, nonce: UUID, ownerID: String) -> Context? {
        let context = Context(configuration: configuration, nonce: nonce,
                              workKey: "Genesis", ownerID: ownerID)
        guard admission.arm(context) else { return nil }
        record(context, stage: "armed")
        return context
    }

    fileprivate static func matching(_ request: URLRequest, claim: Bool) -> Context? {
        admission.matches(request, claim: claim)
    }

    fileprivate static func released(_ context: Context) -> Bool {
        guard let object = object(at: context.configuration.url(nonce: context.nonce, stage: "release")),
              Set(object.keys) == Set(["schemaVersion", "namespace", "nonce", "operation"]),
              object["schemaVersion"] as? Int == 1,
              object["namespace"] as? String == context.configuration.namespace.uuidString,
              object["nonce"] as? String == context.nonce.uuidString,
              object["operation"] as? String == "releaseFault" else { return false }
        return true
    }

    /// Bounded regular-file reads; no preference, response, corpus or cache writes.
    private static func object(at url: URL) -> [String: Any]? {
        guard url.standardizedFileURL == url.resolvingSymlinksInPath().standardizedFileURL,
              let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]),
              values.isRegularFile == true, values.isSymbolicLink != true,
              let size = values.fileSize, size <= 4_096,
              let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }
        var bytes = Data()
        do {
            while bytes.count <= 4_096 {
                guard let part = try handle.read(upToCount: 4_097 - bytes.count), !part.isEmpty else { break }
                bytes.append(part)
            }
            guard bytes.count <= 4_096 else { return nil }
            return try JSONSerialization.jsonObject(with: bytes) as? [String: Any]
        } catch { return nil }
    }

    fileprivate static func record(_ context: Context, stage: String) {
        guard ["armed", "tagged", "held", "failed", "cancelled", "expired"].contains(stage) else { return }
        let object: [String: Any] = [
            "schemaVersion": 1, "namespace": context.configuration.namespace.uuidString,
            "nonce": context.nonce.uuidString, "backend": "sefaria", "workKey": context.workKey,
            "ownerID": context.ownerID, "stage": stage, "method": "GET",
            "url": context.expectedURL, "timestamp": Date().timeIntervalSince1970,
            "errorCode": stage == "failed" ? URLError.dataNotAllowed.rawValue : 0
        ]
        guard let data = try? JSONSerialization.data(withJSONObject: object, options: [.sortedKeys]) else { return }
        let url = context.configuration.url(nonce: context.nonce, stage: stage)
        guard !FileManager.default.fileExists(atPath: url.path) else { return }
        try? data.write(to: url, options: [.atomic])
    }
}

private final class SefariaTOCFailureURLProtocol: URLProtocol {
    /// URLProtocol itself is not Sendable. The worker retains only this lifetime,
    /// whose state and weak callback owner are always accessed under one lock.
    /// A recursive lock permits URL Loading to call stopLoading synchronously
    /// from the failure callback, without allowing a callback after stop returns.
    private final class Lifetime: @unchecked Sendable {
        private let lock = NSRecursiveLock()
        private weak var owner: SefariaTOCFailureURLProtocol?
        private var worker: Task<Void, Never>?
        private var stopped = false
        private var finished = false

        func begin(owner: SefariaTOCFailureURLProtocol) -> Bool {
            lock.lock(); defer { lock.unlock() }
            guard !stopped, !finished, self.owner == nil else { return false }
            self.owner = owner
            return true
        }

        func install(_ task: Task<Void, Never>) {
            lock.lock()
            if stopped || finished {
                lock.unlock()
                task.cancel()
            } else {
                worker = task
                lock.unlock()
            }
        }

        func complete(_ context: SefariaTOCTransportAcceptance.Context,
                      stage: String, error: URLError.Code) {
            lock.lock(); defer { lock.unlock() }
            guard !stopped, !finished else { return }
            finished = true
            worker = nil
            guard let owner else { return }
            SefariaTOCTransportAcceptance.record(context, stage: stage)
            owner.client?.urlProtocol(owner, didFailWithError: URLError(error))
            self.owner = nil
        }

        func stop() {
            lock.lock()
            stopped = true
            owner = nil
            let task = worker
            worker = nil
            lock.unlock()
            task?.cancel()
        }
    }

    private let lifetime = Lifetime()

    override class func canInit(with request: URLRequest) -> Bool {
        SefariaTOCTransportAcceptance.matching(request, claim: false) != nil
    }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }

    override func startLoading() {
        guard let context = SefariaTOCTransportAcceptance.matching(request, claim: true) else {
            client?.urlProtocol(self, didFailWithError: URLError(.cancelled))
            return
        }
        let lifetime = self.lifetime
        guard lifetime.begin(owner: self) else { return }
        let task = Task.detached { [lifetime] in
            SefariaTOCTransportAcceptance.record(context, stage: "held")
            let deadline = ContinuousClock.now.advanced(by: .seconds(25))
            while !Task.isCancelled, ContinuousClock.now < deadline {
                if SefariaTOCTransportAcceptance.released(context) {
                    lifetime.complete(context, stage: "failed", error: .dataNotAllowed)
                    return
                }
                do { try await Task.sleep(for: .milliseconds(50)) }
                catch { break }
            }
            lifetime.complete(context, stage: Task.isCancelled ? "cancelled" : "expired",
                              error: .cancelled)
        }
        lifetime.install(task)
    }

    override func stopLoading() {
        lifetime.stop()
    }
}
#endif


#if DEBUG && SEFARIA_TOC_TRANSPORT_ACCEPTANCE_TESTS
private struct TOCTransportFixtureReply: Decodable, Sendable { let value: Int }

private final class TOCTransportFixtureObservation: @unchecked Sendable {
    private let lock = NSLock()
    private var count = 0
    func record() { lock.lock(); count += 1; lock.unlock() }
    func observed() -> Int { lock.lock(); defer { lock.unlock() }; return count }
}

private final class TOCTransportSuccessFixture: URLProtocol {
    static let observation = TOCTransportFixtureObservation()
    override class func canInit(with request: URLRequest) -> Bool {
        request.url?.absoluteString == "https://www.sefaria.org/api/v2/raw/index/Genesis"
    }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.observation.record()
        let response = HTTPURLResponse(url: request.url!, statusCode: 200, httpVersion: nil,
                                       headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Data(#"{"value":17}"#.utf8))
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

extension SefariaTOCTransportAcceptance {
    fileprivate static func fixtureAdmissionChecks(_ configuration: Configuration, nonce: UUID) throws -> [[String: Any]] {
        var rows: [[String: Any]] = []
        func check(_ name: String, _ value: Bool) { rows.append(["name": name, "passed": value]) }
        let context = Context(configuration: configuration, nonce: nonce, workKey: "Genesis", ownerID: "fixture-owner")
        let gate = Admission()
        check("admission.arm-once", gate.arm(context) && !gate.arm(context))
        let unrelated = URLRequest(url: URL(string: "https://www.sefaria.org/api/shape/Genesis")!)
        check("admission.reject-shape", !gate.tag(context, request: unrelated))
        var post = URLRequest(url: URL(string: context.expectedURL)!)
        post.httpMethod = "POST"
        check("admission.reject-post", !gate.tag(context, request: post))
        var body = URLRequest(url: URL(string: context.expectedURL)!)
        body.httpBody = Data("body".utf8)
        check("admission.reject-body", !gate.tag(context, request: body))
        var query = URLRequest(url: URL(string: context.expectedURL + "?another=1")!)
        query.httpMethod = "GET"
        check("admission.exact-url", !gate.tag(context, request: query))
        let foreign = Context(configuration: configuration, nonce: UUID(), workKey: "Genesis", ownerID: "fixture-owner")
        let get = URLRequest(url: URL(string: context.expectedURL)!)
        check("admission.exact-nonce", !gate.tag(foreign, request: get))
        check("admission.tag-once", gate.tag(context, request: get) && !gate.tag(context, request: get))
        check("admission.no-untagged-claim", gate.matches(get, claim: true) == nil)
        let mutable = (get as NSURLRequest).mutableCopy() as! NSMutableURLRequest
        URLProtocol.setProperty(nonce.uuidString, forKey: propertyKey, in: mutable)
        let tagged = mutable as URLRequest
        check("admission.property-local-not-header",
              URLProtocol.property(forKey: propertyKey, in: tagged) as? String == nonce.uuidString
              && !(tagged.allHTTPHeaderFields?.values.contains(nonce.uuidString) ?? false))
        check("admission.can-init-is-passive", gate.matches(tagged, claim: false) != nil && gate.matches(tagged, claim: false) != nil)
        check("admission.claim-once", gate.matches(tagged, claim: true) != nil && gate.matches(tagged, claim: true) == nil)
        let valid: [String: Any] = ["schemaVersion": 1, "namespace": configuration.namespace.uuidString,
            "nonce": nonce.uuidString, "backend": "sefaria", "workKey": "Genesis", "operation": "reloadOwnedTOC"]
        try JSONSerialization.data(withJSONObject: valid).write(to: configuration.commandURL)
        check("command.valid-exact-schema", command(configuration: configuration) == nonce)
        var wrong = valid; wrong["namespace"] = UUID().uuidString
        try JSONSerialization.data(withJSONObject: wrong).write(to: configuration.commandURL)
        check("command.foreign-namespace-rejected", command(configuration: configuration) == nil)
        wrong = valid; wrong["unrequested"] = true
        try JSONSerialization.data(withJSONObject: wrong).write(to: configuration.commandURL)
        check("command.extra-field-rejected", command(configuration: configuration) == nil)
        try Data(repeating: 32, count: 4_097).write(to: configuration.commandURL)
        check("command.bounded-bytes", command(configuration: configuration) == nil)
        try FileManager.default.removeItem(at: configuration.commandURL)
        return rows
    }
}

@main enum TOCTransportFoundationAcceptance {
    @MainActor
    static func main() async throws {
        let mode = CommandLine.arguments[1]
        let directory = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
        let configuration = SefariaTOCTransportAcceptance.Configuration(namespace: UUID(), documents: directory)
        let nonce = UUID()
        var rows = try SefariaTOCTransportAcceptance.fixtureAdmissionChecks(configuration, nonce: nonce)
        func check(_ name: String, _ passed: Bool) { rows.append(["name": name, "passed": passed]) }
        check("runtime.real-app-configuration-not-enabled", SefariaTOCTransportAcceptance.configuration == nil)
        let context = SefariaTOCTransportAcceptance.arm(configuration: configuration, nonce: nonce,
                                                        ownerID: "whole-client-child-task-fixture")!
        let sessionConfig = URLSessionConfiguration.ephemeral
        // Only successful retry transport bytes are a fixture boundary. The
        // original failure URLProtocol/client/TaskLocal path below is whole source.
        sessionConfig.protocolClasses = [SefariaTOCFailureURLProtocol.self, TOCTransportSuccessFixture.self]
        let session = URLSession(configuration: sessionConfig)
        let client = SefariaHTTPClient(session: session)
        defer { session.invalidateAndCancel() }
        var completed = false
        let worker = SefariaTOCTransportAcceptance.$context.withValue(context) {
            // Explicit Foundation control for the original owner's child-Task
            // shape, not a claim that SwiftUI/BookTOCViewModel ran here.
            Task { @MainActor in
                defer { completed = true }
                do {
                    let reply = try await client.get(TOCTransportFixtureReply.self,
                        url: URL(string: context.expectedURL)!, timeoutInterval: 5, maxAttempts: 3)
                    return "success:\(reply.value)"
                } catch is CancellationError { return "cancelled" }
                catch LibraryBackendError.unavailableOffline { return "unavailableOffline" }
                catch { return "other:\(type(of: error))" }
            }
        }
        let deadline = ContinuousClock.now.advanced(by: .seconds(2))
        while !FileManager.default.fileExists(atPath: configuration.url(nonce: nonce, stage: "held").path),
              ContinuousClock.now < deadline {
            try await Task.sleep(for: .milliseconds(10))
        }
        let held = FileManager.default.fileExists(atPath: configuration.url(nonce: nonce, stage: "held").path)
        check("runtime.actual-urlprotocol-held", held)
        check("runtime.tasklocal-inherited-by-child", FileManager.default.fileExists(
            atPath: configuration.url(nonce: nonce, stage: "tagged").path))
        check("runtime.no-completion-before-release", !completed)
        check("runtime.success-boundary-not-called-while-held", TOCTransportSuccessFixture.observation.observed() == 0)
        if mode == "failure-retry", held {
            let release: [String: Any] = ["schemaVersion": 1, "namespace": configuration.namespace.uuidString,
                "nonce": nonce.uuidString, "operation": "releaseFault"]
            try JSONSerialization.data(withJSONObject: release).write(
                to: configuration.url(nonce: nonce, stage: "release"))
        } else { worker.cancel() }
        let result = await worker.value
        check(mode == "failure-retry" ? "runtime.original-offline-error-mapping" : "runtime.held-cancellation",
              result == (mode == "failure-retry" ? "unavailableOffline" : "cancelled"))
        check("runtime.no-automatic-success-retry", TOCTransportSuccessFixture.observation.observed() == 0)
        check("runtime.no-fake-success-response", completed && result != "success:17")
        if mode == "failure-retry" {
            check("runtime.actual-failure-receipt", FileManager.default.fileExists(
                atPath: configuration.url(nonce: nonce, stage: "failed").path))
        } else {
            check("runtime.cancel-does-not-publish-failure", !FileManager.default.fileExists(
                atPath: configuration.url(nonce: nonce, stage: "failed").path))
        }
        do {
            let reply = try await client.get(TOCTransportFixtureReply.self,
                url: URL(string: context.expectedURL)!, timeoutInterval: 5, maxAttempts: 1)
            check("runtime.retry-outside-tasklocal-uses-original-session", reply.value == 17
                  && TOCTransportSuccessFixture.observation.observed() == 1)
        } catch { check("runtime.retry-outside-tasklocal-uses-original-session", false) }
        let late = try await SefariaTOCTransportAcceptance.$context.withValue(context) {
            try await client.get(TOCTransportFixtureReply.self,
                url: URL(string: context.expectedURL)!, timeoutInterval: 5, maxAttempts: 1)
        }
        check("runtime.consumed-token-cannot-steal-later-request", late.value == 17
              && TOCTransportSuccessFixture.observation.observed() == 2)
        FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject: rows, options: [.sortedKeys]))
        FileHandle.standardOutput.write(Data("\n".utf8))
        exit(rows.allSatisfy { $0["passed"] as? Bool == true } ? 0 : 1)
    }
}
#endif
