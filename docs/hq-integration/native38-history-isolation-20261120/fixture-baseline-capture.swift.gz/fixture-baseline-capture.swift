import Foundation

/// Find only this test's unique sidecar after XCTest's app installation. The
/// pre-install container UUID is a hint to its parent, never a durable app ID.
private func matchingTestSidecars(in containers: URL, namespace: String) -> [URL] {
    guard UUID(uuidString: namespace) != nil,
          let candidates = try? FileManager.default.contentsOfDirectory(at: containers, includingPropertiesForKeys: nil) else { return [] }
    return candidates.map {
        $0.appendingPathComponent("Library/Application Support/ChavrusaText/StudyWorkspace/UITests/\(namespace).json")
    }.filter { FileManager.default.fileExists(atPath: $0.path) }
}


/// Read-only evidence from this Simulator installation. The runner's pre-install
/// container UUID is only a parent hint: XCTest may reinstall the app.
private struct NativeGlobalHistoryObservation {
    let container: URL?
    let metadataBytes: Data?
    let persistedExactlyOnce: Bool
    let details: [String: Any]
}

private func observeNativeGlobalHistory(
    in parent: URL, namespace: String, query: String,
    expectedContainer: URL? = nil, expectedMetadata: Data? = nil
) -> NativeGlobalHistoryObservation {
    let bundleID = "com.davidpovarsky.chavrusatext"
    func boundedRegularFile(_ url: URL, maximum: Int) -> Data? {
        guard let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]),
              values.isRegularFile == true, values.isSymbolicLink == false,
              let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }
        do {
            var bytes = Data()
            while bytes.count <= maximum {
                guard let chunk = try handle.read(upToCount: min(65536, maximum + 1 - bytes.count)),
                      !chunk.isEmpty else { return bytes }
                bytes.append(chunk)
            }
        } catch { return nil }
        return nil
    }
    func dictionary(_ bytes: Data) -> [String: Any]? {
        (try? PropertyListSerialization.propertyList(from: bytes, format: nil)) as? [String: Any]
    }
    let root = parent.standardizedFileURL
    let children = (try? FileManager.default.contentsOfDirectory(
        at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
        options: [.skipsHiddenFiles])) ?? []
    let candidates: [(URL, Data)] = children.compactMap { child in
        let container = child.standardizedFileURL
        guard UUID(uuidString: container.lastPathComponent) != nil,
              container.deletingLastPathComponent().pathComponents == root.pathComponents,
              let values = try? container.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]),
              values.isDirectory == true, values.isSymbolicLink == false,
              let metadata = boundedRegularFile(
                container.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist"),
                maximum: 65536),
              dictionary(metadata)?["MCMMetadataIdentifier"] as? String == bundleID else { return nil }
        return (container, metadata)
    }
    var details: [String: Any] = [
        "metadataBundleIdentifier": bundleID,
        "matchingInstallationCount": candidates.count,
        "candidateContainerIDs": candidates.map { $0.0.lastPathComponent },
        "queryPersistedExactlyOnce": false
    ]
    guard candidates.count == 1, let (container, metadata) = candidates.first else {
        details["observationError"] = "missing_or_ambiguous_original_installation"
        return .init(container: nil, metadataBytes: nil, persistedExactlyOnce: false, details: details)
    }
    // Feature-off deliberately has no workspace sidecar. If the existing UUID
    // sidecar is present, it must corroborate this same original installation.
    let sidecars = matchingTestSidecars(in: root, namespace: namespace)
    let namespaceMatches = sidecars.isEmpty || (sidecars.count == 1 &&
        sidecars[0].standardizedFileURL.pathComponents.starts(with: container.pathComponents))
    let pinned = expectedContainer != nil && expectedMetadata != nil
    let installationMatches = pinned &&
        expectedContainer?.standardizedFileURL.pathComponents == container.pathComponents && expectedMetadata == metadata
    details["containerID"] = container.lastPathComponent
    details["metadataByteCount"] = metadata.count
    details["namespaceSidecarCount"] = sidecars.count
    details["namespaceMatchesInstallation"] = namespaceMatches
    details["installationPinned"] = pinned
    details["installationMatchesInitialBytes"] = installationMatches
    let preference = container.appendingPathComponent("Library/Preferences/" + bundleID + ".plist")
    let preferences = boundedRegularFile(preference, maximum: 1024 * 1024).flatMap(dictionary)
    let history = preferences?["SearchHistory"] as? [String] ?? []
    let count = history.filter { $0 == query }.count
    details["preferenceReadable"] = preferences != nil
    details["historyCount"] = history.count
    details["submittedQueryCount"] = count
    if let preferences {
        details["recordSearchHistory"] = preferences["recordSearchHistory"] as? Bool ?? true
    }
    let persisted = installationMatches && namespaceMatches && preferences != nil && count == 1
    details["queryPersistedExactlyOnce"] = persisted
    if !namespaceMatches { details["observationError"] = "namespace_installation_mismatch" }
    else if pinned && !installationMatches { details["observationError"] = "original_installation_changed" }
    else if preferences == nil { details["observationError"] = "original_preferences_unreadable" }
    return .init(container: namespaceMatches ? container : nil,
                 metadataBytes: namespaceMatches ? metadata : nil,
                 persistedExactlyOnce: persisted, details: details)
}


private final class HistoryCaptureOwner {
    var workspaceNamespace: String
    init(_ namespace: String) { workspaceNamespace = namespace }
    func observation(in containers: URL, query: String, originalContainer: URL, originalMetadata: Data)
        -> @Sendable () -> NativeGlobalHistoryObservation {
        func historyObservation() -> NativeGlobalHistoryObservation {
            observeNativeGlobalHistory(in: containers, namespace: workspaceNamespace, query: query,
                                       expectedContainer: originalContainer, expectedMetadata: originalMetadata)
        }
        return historyObservation
    }
    func predicate(in containers: URL, query: String, originalContainer: URL, originalMetadata: Data) -> NSPredicate {
        let captured = observation(in: containers, query: query, originalContainer: originalContainer, originalMetadata: originalMetadata)
        return NSPredicate { _, _ in
            MainActor.assumeIsolated { captured().persistedExactlyOnce }
        }
    }
}

@main
struct HistoryCaptureAcceptance {
    static func plist(_ value: [String: Any], _ url: URL) throws -> Data {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let data = try PropertyListSerialization.data(fromPropertyList: value, format: .binary, options: 0)
        try data.write(to: url)
        return data
    }
    static func main() throws {
        let root = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true).appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let container = root.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let namespace = UUID().uuidString
        let query = "בדיקת היסטוריה " + UUID().uuidString
        let metadataURL = container.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")
        let metadata = try plist(["MCMMetadataIdentifier": "com.davidpovarsky.chavrusatext"], metadataURL)
        let preferences = container.appendingPathComponent("Library/Preferences/com.davidpovarsky.chavrusatext.plist")
        _ = try plist(["SearchHistory": [query]], preferences)
        let owner = HistoryCaptureOwner(namespace)
        let observed = owner.observation(in: root, query: query, originalContainer: container, originalMetadata: metadata)
        guard observed().persistedExactlyOnce else { fatalError("original pinned observation failed") }
        print("CASE original_pinned_observation PASS")
        // A different namespace exists only in a foreign installation. Changing
        // this non-Sendable owner's later state must not change the captured grant.
        let foreign = root.appendingPathComponent(UUID().uuidString, isDirectory: true)
        _ = try plist(["MCMMetadataIdentifier": "com.example.foreign"], foreign.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist"))
        let changedNamespace = UUID().uuidString
        let sidecar = foreign.appendingPathComponent("Library/Application Support/ChavrusaText/StudyWorkspace/UITests/" + changedNamespace + ".json")
        try FileManager.default.createDirectory(at: sidecar.deletingLastPathComponent(), withIntermediateDirectories: true)
        try Data("{}".utf8).write(to: sidecar)
        owner.workspaceNamespace = changedNamespace
        guard !observeNativeGlobalHistory(in: root, namespace: changedNamespace, query: query,
                                         expectedContainer: container, expectedMetadata: metadata).persistedExactlyOnce,
              observed().persistedExactlyOnce else { fatalError("namespace was not frozen") }
        print("CASE namespace_capture_independent_of_owner PASS")
        _ = try plist(["SearchHistory": [query, query]], preferences)
        guard !observed().persistedExactlyOnce else { fatalError("duplicate query accepted") }
        print("CASE exact_query_oracle_preserved PASS")
        _ = try plist(["SearchHistory": [query]], preferences)
        var changed = metadata; changed.append(10); try changed.write(to: metadataURL)
        guard !observed().persistedExactlyOnce else { fatalError("changed metadata accepted") }
        print("CASE pinned_metadata_oracle_preserved PASS")
        print("RESULT 4 PASS 0 FAIL; no UIKit/Simulator/runtime acceptance")
    }
}
