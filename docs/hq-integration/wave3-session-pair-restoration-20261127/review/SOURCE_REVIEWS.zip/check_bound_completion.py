#!/usr/bin/env python3
"""Local pure-predicate controls; never import or run either controller."""
from pathlib import Path
import ast
import base64
import copy
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'restore_session_pair_differential.py'
raw = SOURCE.read_bytes()
tree = ast.parse(raw)
names = {'require_actual_binding', 'digest', 'leaf_name', 'verify_receipt',
         'verify_transport_completion', 'verify_dependencies', 'verify_manifest'}
body = [n for n in tree.body if isinstance(n, ast.Assign)
        or isinstance(n, ast.FunctionDef) and n.name in names]
assert {n.name for n in body if isinstance(n, ast.FunctionDef)} == names
namespace = {'Path': Path, 'hashlib': hashlib, 'base64': base64, 'json': json}
exec(compile(ast.Module(body=body, type_ignores=[]), str(SOURCE) + ':pure-only', 'exec'), namespace)

receipt_path = HERE / 'evidence/continuation-1/raw/original/VERIFIED_PRIVATE_SESSION_PAIR_TRANSPORT.json'
manifest_path = HERE / 'evidence/attempt-1/raw/PRESERVED_SESSION_PAIR_MANIFEST.json'
preflight_path = HERE / 'evidence/attempt-1/raw/SOURCE_PREFLIGHT.json'
receipt_raw = receipt_path.read_bytes()
manifest_raw = manifest_path.read_bytes()
proof = {}
for label, pin in namespace['TRANSPORT_COMPLETION'].items():
    value = (HERE / pin['name']).read_bytes()
    proof[label] = {**pin, 'base64': base64.b64encode(value).decode('ascii')}
cases = []

def run(name, action, refuses=False):
    try:
        action()
        passed = not refuses
        error = None
    except (AssertionError, ValueError, KeyError, TypeError) as failure:
        passed = refuses
        error = type(failure).__name__
    cases.append({'name': name, 'pass': passed, 'expectedRefusal': refuses, 'error': error})

run('actual receipt contains exact three authenticated full asset readbacks',
    lambda: namespace['verify_receipt'](receipt_raw))
run('actual unchanged manifest joins original identity and captured atime',
    lambda: namespace['verify_manifest'](manifest_raw, namespace['verify_receipt'](receipt_raw)))
run('actual succeeded job and final publication marker are jointly required',
    lambda: namespace['verify_transport_completion'](proof))
run('intermediate receipt without terminal or marker cannot satisfy completion',
    lambda: namespace['verify_transport_completion']({}), True)
run('terminal without final publication is refused',
    lambda: namespace['verify_transport_completion']({'terminal': proof['terminal']}), True)
run('publication without succeeded terminal is refused',
    lambda: namespace['verify_transport_completion']({'publication': proof['publication']}), True)
failed_terminal = copy.deepcopy(proof)
terminal = json.loads(base64.b64decode(failed_terminal['terminal']['base64']))
terminal['job']['exit_code'] = 1
failed_terminal['terminal']['base64'] = base64.b64encode(json.dumps(terminal).encode()).decode()
run('changed terminal failure cannot inherit the actual terminal identity',
    lambda: namespace['verify_transport_completion'](failed_terminal), True)
wrong_marker = copy.deepcopy(proof)
marker = json.loads(base64.b64decode(wrong_marker['publication']['base64']))
marker['originalReceipt']['sha256'] = '0' * 64
wrong_marker['publication']['base64'] = base64.b64encode(json.dumps(marker).encode()).decode()
run('marker for another receipt cannot inherit final publication identity',
    lambda: namespace['verify_transport_completion'](wrong_marker), True)

old = HERE / 'review/unbound-actual-transport-pending'
preservation = []
expected_changes = {
    'restore_session_pair_differential.py': {'verify_receipt', 'main'},
    'retire_session_pair_differential.py': {'load_preservation', 'source_check', 'prepare', 'commit'},
}
for name, allowed in expected_changes.items():
    before_raw, after_raw = (old / name).read_bytes(), (HERE / name).read_bytes()
    before_tree, after_tree = ast.parse(before_raw), ast.parse(after_raw)
    def functions(value):
        parsed = ast.parse(value)
        return {n.name: ast.get_source_segment(value.decode(), n)
                for n in parsed.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    before, after = functions(before_raw), functions(after_raw)
    assert set(before) <= set(after)
    changed = {name for name in before if before[name] != after[name]}
    assert changed == allowed, (name, changed)
    before_classes = {n.name: ast.get_source_segment(before_raw.decode(), n)
                      for n in before_tree.body if isinstance(n, ast.ClassDef)}
    after_classes = {n.name: ast.get_source_segment(after_raw.decode(), n)
                     for n in after_tree.body if isinstance(n, ast.ClassDef)}
    assert before_classes == after_classes
    before_constants = {n.targets[0].id: ast.dump(n.value) for n in before_tree.body
                        if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)}
    after_constants = {n.targets[0].id: ast.dump(n.value) for n in after_tree.body
                       if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)}
    assert set(before_constants) <= set(after_constants)
    changed_constants = {key for key in before_constants if before_constants[key] != after_constants[key]}
    expected_constants = ({'RELEASE_ID', 'RECEIPT_SHA', 'ASSETS'} if name.startswith('restore_')
                          else {'RESTORE_SCRIPT_SHA256'})
    assert changed_constants == expected_constants
    preservation.append({'path': name, 'unchangedOriginalFunctions': sorted(set(before) - changed),
        'changedOriginalFunctions': sorted(changed), 'newFunctions': sorted(set(after) - set(before)),
        'unchangedOriginalClasses': sorted(before_classes),
        'unchangedOriginalConstants': sorted(set(before_constants) - changed_constants),
        'changedOriginalConstants': sorted(changed_constants),
        'beforeSHA256': hashlib.sha256(before_raw).hexdigest(),
        'afterSHA256': hashlib.sha256(after_raw).hexdigest()})

preflight = json.loads(preflight_path.read_bytes())
result = {'status': 'LOCAL_PURE_PREDICATES_ONLY_NO_CONTROLLER_OR_NETWORK_EXECUTION',
    'sourceSHA256': hashlib.sha256(raw).hexdigest(), 'cases': cases,
    'passed': sum(r['pass'] for r in cases), 'failed': sum(not r['pass'] for r in cases),
    'originalFunctionPreservation': preservation,
    'receiptSHA256': hashlib.sha256(receipt_raw).hexdigest(),
    'manifestSHA256': hashlib.sha256(manifest_raw).hexdigest(),
    'sourcePreflightSHA256': hashlib.sha256(preflight_path.read_bytes()).hexdigest(),
    'originalAtimeNs': json.loads(receipt_raw)['sourceRestoreMetadata']['atime_ns'],
    'boundaries': ['Only literal assignments and seven named actual pure functions were compiled.',
        'No controller module import, main, Journal, network, source scan, restore, prepare or retirement ran.',
        'Existing no-use, source, metadata, budget, process-cleanup and unlink bodies remain source-reviewed.']}
encoded = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
with (HERE / 'BOUND_COMPLETION_CHECK.json').open('xb') as output:
    output.write(encoded)
print(json.dumps({'passed': result['passed'], 'failed': result['failed'],
    'bytes': len(encoded), 'sha256': hashlib.sha256(encoded).hexdigest()}))
assert result['failed'] == 0
