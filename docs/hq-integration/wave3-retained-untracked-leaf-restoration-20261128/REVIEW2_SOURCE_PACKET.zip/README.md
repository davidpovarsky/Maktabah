# Exact retained untracked archive: source proposal

Status: **SOURCE ONLY. No controller, authentication, API, upload, restore, retirement, build or test was run.**

## Exact scope

The sole prospective upload/removal payload is:

`/mnt/development/projects/preserved/maktabah-final-delivery-20261126.HEKmdGhG/Maktabah/untracked.tar.gz`

- Original size: **691,303,419 bytes**.
- SHA256: `e7783edfe09c044fb8b13f398604b35011a987970495c47d52a3306a15b8b100`.
- Device/inode: **2064 / 6204866**, one hard link, mode0600, owner1001/group1002.
- Container: device2064/inode6204847. Immediate parent inode6204860.
- Original source snapshot:85 entries,73 regular files and12 directories. All84 non-target entries stay protected.

Root's actual preflight job`job_9e1b71f819ac` captured full raw hashes and metadata with O_NOATIME. It observed zero candidate FDs and zero unreadable process entries. It explicitly did **not** establish closed ownership or archive-member qualification. Its unmodified source/result/snapshot are retained here.

The archive may contain unique untracked work. Its capture date and UID are not disposal proofs. This proposal treats it as one opaque exact object. No tar extraction, regeneration, source-tree recovery or compiler/native qualification is attempted.

## Source files and exact seal

`SOURCE_SEAL.json`: 943bytes / `b3fb30020b2bafffd741829e78974f1fa088e20c70d5291d8d35648463ab0e1e`.

The six sealed inputs are the common helper, preserve/retire/whole-leaf restore entrypoints, exact original snapshot and preflight result. Entry scripts compile only the just-read hash-pinned helper bytes under a private module name; they do not rewrite tests or process globals. Every entry rejects optimized Python before an action. Imported helper definitions have no execution side effect.

All runtime operations require the Root executor. New journals are fixed, exclusive Rootfs phases at:

`/home/ubuntu/otzaria-wave3-preserved-untracked-leaf-transport-20261128`

The proposal has an8MiB allocation cap. Future runtime metadata has a separate conservative4MiB cap across all phases, a64KiB preallocated terminal slot per phase, and the unchanged1,593,835,520-byte Rootfs floor. Original Data is only read during prepare/publication, and only the exact leaf may later be unlinked. No new large archive is staged.

## Reviewable future ordering

These are invocation prerequisites, not execution authorization.

1. Root stages the exact six sources and seal, verifies all hashes, confirms writer exclusion, and reviews this code. Run the `prepare` phase once. It rehashes all73 files and checks all85 metadata/path entries, then writes the exact private manifest and PREPARED receipt. It uses no authentication or network.

2. After Root reads the complete actual PREPARED and terminal, run `publish` once with its exact digest. It rechecks all source bytes, authenticates the exact private repository1474927804, exhaustively checks bounded release-list absence, creates one unique private draft, then uploads the manifest and existing archive once each. It never regenerates the archive. Explicit-length upload POSTs go only to the fixed release-ID endpoint on uploads.github.com with no redirect/retry/reconnection. The existing reviewed bounded gh client performs full authenticated immutable-ID readbacks. Full SHA and byte count of both objects, final source rejoin and exact server identities are required before the final marker and successful terminal.

3. Root independently reads the actual completed Sentinel job, publication marker and full readback receipt. The actual binding template remains inadmissibly unbound until then. No release/asset/job ID is guessed.

4. Root supplies its concrete closed-ownership/local-dependency review. `retire prepare` checks that record, the actual transport completion, fresh server metadata, all85 source hashes and full no-use evidence. It writes the restoration pointer and PREDELETE, keeping the original leaf.

5. Root publishes **all** exact prepared restoration sources/records plus PREDELETE in its existing Maktabah documentation branch and independently reads them back. Only then may a separately reviewed `retire commit` invocation provide the exact PREDELETE ACK and Git proof. The controller reads every required Git blob through the authenticated API, verifies full Git-blob SHA1+bytes+SHA256 and the published ref, rechecks private asset identities, rehashes all85 entries, performs a fresh bounded /proc FD/mapping/cwd/exe scan, then repeats complete metadata and root/parent/leaf FD joins. It calls unlink only on `untracked.tar.gz` through the pinned immediate parent FD.

No phase automatically retries or reuses an occupied journal after failure. Failed requests, unknown/partial remote assets, source files and all existing evidence remain intact.

## Restore guarantee and limits

The pointer includes exact immutable asset IDs, actual transport/job completion, complete original source metadata, the original atime, exact manifest and helper/script digests. The single restoration command downloads only the whole archive into an exclusively created temporary sibling. It verifies the complete download and disk bytes, restores mode/uid/gid/atime/mtime/xattrs, and exclusively publishes the absent final leaf. It never extracts the archive, chooses another destination or replaces an existing leaf. Failed partials remain preserved.

All84 surrounding entries must still match. The immediate parent directory necessarily changes mtime/ctime on unlink or restore; this is the only declared parent-metadata exception. Inode and ctime are evidence, not recreatable metadata. Other entry contents, identities, modes and xattrs must remain exact.

Future restoration requires enough Data space for the full691,303,419-byte leaf above the original2GiB Data floor plus1MiB. Preservation/retirement do not lower any compiler or SDK capacity gate.

## Established reuse

The no-use inspection, pinned directory traversal, owned process identity/stop, gh readback, restore downloader and private token getter are reused from the previously reviewed session-pair and Native116 source. `SOURCE_REVIEW_PROOF.json` records exact source-body joins. This is static provenance, not a rerun of historical controls.

New code consists of the exact85-entry schema, fixed leaf/parent/source joins, two-asset publication, actual-binding schema, and this one-leaf Git/retirement/restoration orchestration. It still requires independent Root source review before any dispatch.

Official GitHub documentation distinguishes direct200 download from302 redirection: https://docs.github.com/en/rest/releases/assets . Root clarified that the existing reviewed gh readback behavior remains allowed; only the new credential-bearing upload and any new raw HTTP logic must reject redirects. No manual signed-location or token-forwarding logic was added.

## Original-source qualification

No archive member was read by this source preparation. The other72 regular-file payloads are not uploaded by this plan; their complete metadata/hashes remain bound and their local originals remain intact. The manifest is sufficient to bind and restore this one archive object, and does not claim an entire original source tree is recoverable.

All source-only packets already sealed for Inspector, primary/BookInfo and focused controls remain unchanged.

## Separate review2 correction

The original23-file proposal remains unchanged and unexecuted at
`/home/ubuntu/otzaria-wave3-preserved-untracked-leaf-transport-proposal-20261128`.

Root's complete source read identified two concrete source joins: the reused restoration transfer body lacked its two module-level helper aliases, and actual Sentinel job output was not compared to the final local receipt/marker/terminal pins. This revision adds only those aliases and exact output comparison, plus the requested isolated/-B/absent-GH_DEBUG invocation guard. The three entrypoints change only their helper digest. Reused transfer/getter/process/no-use bodies and all transport/retirement semantics remain exact. These are source findings, not results of an attempted runtime.

`CORRECTION_EDITS.json` contains six unique reversible text edits; `CANDIDATE.patch` is recomputed from complete original/current bytes. The new source proof checks full inverse equality and explicit alias binding. No control suite, API, authentication or protocol execution was run.
