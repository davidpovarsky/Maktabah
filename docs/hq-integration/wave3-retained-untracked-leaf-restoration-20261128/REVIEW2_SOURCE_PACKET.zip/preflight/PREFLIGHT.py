import os,sys,stat,time,json,pathlib,hashlib,base64,datetime
SRC=pathlib.Path('/mnt/development/projects/preserved/maktabah-final-delivery-20261126.HEKmdGhG')
LEAF=SRC/'Maktabah/untracked.tar.gz'
OUT=pathlib.Path('/home/ubuntu/otzaria-wave3-preserved-untracked-leaf-preflight-20261128')
FLOOR=1593835520;CAP=8388608;started=time.monotonic()
def need(v,m):
 if not v:raise RuntimeError(m)
def sh(b):return hashlib.sha256(b).hexdigest()
def guard():
 need(time.monotonic()-started<100,'Finite preservation preflight deadline')
 v=os.statvfs('/home/ubuntu');need(v.f_bavail*v.f_frsize>=FLOOR+CAP,'Root floor plus report reserve')
def attrs(p):
 return [[base64.b64encode(os.fsencode(k)).decode(),base64.b64encode(os.getxattr(p,k,follow_symlinks=False)).decode()]for k in sorted(os.listxattr(p,follow_symlinks=False))]
def meta(p):
 s=p.lstat()
 return {'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,'bytes':s.st_size,'allocatedBytes':s.st_blocks*512,'atimeNS':str(s.st_atime_ns),'mtimeNS':str(s.st_mtime_ns),'ctimeNS':str(s.st_ctime_ns),'xattrs':attrs(p)}
guard();rs=SRC.lstat();need(rs.st_dev==2064 and rs.st_ino==6204847 and stat.S_ISDIR(rs.st_mode),'Exact retained delivery root')
need(not os.path.lexists(OUT),'Fresh exclusive preflight scope');OUT.mkdir(mode=0o700);os.chown(OUT,1001,1001)
def put(name,obj):
 b=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode();need(len(b)<=1048576,'Bounded report')
 need(sum(p.stat().st_blocks*512 for p in OUT.iterdir())+len(b)+4096<CAP,'Scope cap')
 p=OUT/name;fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  os.fchown(fd,1001,1001)
  for start in range(0,len(b),65536):os.write(fd,b[start:start+65536])
  os.fsync(fd)
 finally:os.close(fd)
 return {'bytes':len(b),'sha256':sh(b)}
def walk():
 stack=[SRC];rows={}
 while stack:
  p=stack.pop();m=meta(p);rel=p.relative_to(SRC).as_posix()
  need(len(rows)<256 and m['device']==2064,'Exact bounded same-volume source scope')
  if stat.S_ISDIR(m['mode']):
   kind='directory'
   with os.scandir(p)as it:
    for c in it:stack.append(pathlib.Path(c.path))
  elif stat.S_ISREG(m['mode']):kind='file'
  else:raise RuntimeError('No symlink/special source admission')
  rows[rel]={'path':rel,'kind':kind,'metadata':m}
 return rows
try:
 before=walk();need(len(before)==85,'Original finite scope cardinality')
 candidate=before['Maktabah/untracked.tar.gz'];cm=candidate['metadata']
 need(cm['inode']==6204866 and cm['bytes']==691303419 and cm['nlink']==1 and cm['uid']==1001 and cm['gid']==1002,'Exact candidate leaf identity')
 for rel,row in sorted(before.items()):
  guard()
  if row['kind']!='file':continue
  p=SRC/rel;orig=row['metadata'];fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
  try:
   st=os.fstat(fd);need(st.st_dev==orig['device'] and st.st_ino==orig['inode'] and stat.S_ISREG(st.st_mode),'Opened captured inode')
   h=hashlib.sha256();n=0
   while True:
    guard();b=os.read(fd,1048576)
    if not b:break
    n+=len(b);need(n<=orig['bytes'],'Source length cannot grow');h.update(b)
   need(n==orig['bytes'] and meta(p)==orig,'Full raw source rejoin')
   row['content']={'bytes':n,'sha256':h.hexdigest()}
  finally:os.close(fd)
 after=walk();need({k:{'path':v['path'],'kind':v['kind'],'metadata':v['metadata']}for k,v in before.items()}==after,'Full source metadata set unchanged')
 # Fresh observation only. Any process scan ambiguity prevents closure claim.
 users=[];unreadable=[];proc=pathlib.Path('/proc')
 for pp in proc.iterdir():
  if not pp.name.isdigit():continue
  guard();pid=int(pp.name)
  try:
   with os.scandir(pp/'fd')as fds:
    for e in fds:
     try:fs=os.stat(e.path)
     except FileNotFoundError:continue
     except PermissionError:unreadable.append({'pid':pid,'area':'fd-stat'});continue
     if fs.st_dev==2064 and fs.st_ino==6204866:users.append({'pid':pid,'fd':e.name,'link':os.readlink(e.path)})
  except FileNotFoundError:continue
  except PermissionError:unreadable.append({'pid':pid,'area':'fd-directory'})
 snapshots=put('SOURCE_SNAPSHOT.json',{'schema':'otzaria.retained-delivery-readonly-preflight/1','sourceRoot':str(SRC),'entries':before,'sourceUnchanged':True,'readMethod':'O_NOATIME|O_NOFOLLOW; exact before/after metadata and complete SHA256'})
 proof=put('RESULT.json',{'status':'READ_ONLY_RAW_BYTES_AND_METADATA_CAPTURED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':{'path':str(LEAF),**candidate},'entryCount':len(before),'fileCount':sum(x['kind']=='file'for x in before.values()),'directoryCount':sum(x['kind']=='directory'for x in before.values()),'scopeAllocatedBytes':sum(x['metadata']['allocatedBytes']for x in before.values()),'snapshot':snapshots,'observedOpenCandidateFDs':users,'processScanUnreadable':unreadable,'archiveMembersInspected':False,'closedOwnershipEstablished':False,'retirementAuthorized':False,'sourceChanged':False,'apiOperations':0})
 print(json.dumps({'result':proof,'snapshot':snapshots,'candidate':{'path':str(LEAF),'metadata':cm,'content':candidate['content']},'entryCount':len(before),'openFDs':users,'unreadableProcessCount':len(unreadable),'scope':str(OUT),'sourceUnchanged':True}))
except BaseException as e:
 put('FAILED.json',{'errorType':type(e).__name__,'message':str(e),'noSourceMutation':True});raise
