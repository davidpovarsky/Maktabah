import pathlib,subprocess,os,json,hashlib,time,datetime,shutil
root=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-actioncore-platform-20261120")
package=root/"Source/Otzaria/Actions"
manifest=package/"Package.swift"
out=root/"build/actioncore-platform-20261120";out.mkdir(parents=True,exist_ok=True)
base="f064b5517f560e2b52838bf321214baa3fb09e2c"
assert subprocess.run(["git","rev-parse","HEAD"],cwd=root,capture_output=True,text=True,check=True).stdout.strip()==base
original=manifest.read_bytes()
assert b"platforms:" not in original
eol=b"\r\n" if b"\r\n" in original else b"\n"
needle=b'    name: "OtzariaActionCore",'+eol
assert original.count(needle)==1
sources={p.relative_to(package).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob("*") if p.is_file() and p!=manifest}
bin=pathlib.Path(r"C:\Users\DAVID\AppData\Local\Programs\Swift\Toolchains\6.3.3+Asserts\usr\bin")
env=os.environ.copy();env["PATH"]=str(bin)+";"+r"C:\Users\DAVID\AppData\Local\Programs\Swift\Runtimes\6.3.3\usr\bin"+";"+env.get("PATH","")
cmd=[str(bin/"swift.exe"),"package","--package-path",str(package),"--scratch-path",str(out/"swiftpm-metadata"),"--manifest-cache","none","dump-package"]
def dump(name):
 started=time.monotonic()
 with (out/(name+".json")).open("wb") as output,(out/(name+".stderr.log")).open("wb") as errors:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=output,stderr=errors)
  try:p.wait(timeout=90)
  except subprocess.TimeoutExpired:
   subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=20)
   p.wait(timeout=10)
   raise RuntimeError("Owned manifest evaluation timed out; no test executed")
 assert p.returncode==0,(name,p.returncode)
 return json.loads((out/(name+".json")).read_text(encoding="utf-8")),{"exitCode":p.returncode,"seconds":round(time.monotonic()-started,3),"command":cmd,"stderrBytes":(out/(name+".stderr.log")).stat().st_size}
before,beforeRun=dump("before-dump")
assert before["platforms"]==[]
manifest.write_bytes(original.replace(needle,needle+b"    platforms: [.iOS(.v13)],"+eol))
after,afterRun=dump("after-dump")
assert after["platforms"]==[{"options":[],"platformName":"ios","version":"13.0"}],after["platforms"]
stripped=dict(after);stripped["platforms"]=[]
assert stripped==before,"Non-platform manifest behavior changed"
assert all(hashlib.sha256((package/p).read_bytes()).hexdigest()==h for p,h in sources.items())
metadata=out/"swiftpm-metadata"
metadataBytes=sum(p.stat().st_size for p in metadata.rglob("*") if p.is_file()) if metadata.exists() else 0
result={"base":base,"failingRun":44672943654,"failingHead":"127ee9eddc2a9aea05c45ccf41420bb0cdd47705","failingJob":136087824609,"failingTarget":"arm64-apple-ios12.0","originalManifestGitBlob":"db3c297b2f8bf456067f87dad3c895a31b1970c4","selectedIOSMinimum":"13.0","reason":"Actual original Swift concurrency diagnostics require iOS13; app/UIRouting/Host remain27","before":beforeRun,"after":afterRun,"onlyDescriptorDelta":"platforms: [] -> iOS13.0","originalCoreSourceAndResourceFilesUnchanged":len(sources),"otherDeclaredPlatformsChanged":False,"productsTargetsResourcesDependenciesLanguageModeUnchanged":True,"manifestCache":"none","newScratchBytes":metadataBytes,"observedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"newAppleCompilerExecutions":0,"functionalTestsExecuted":0,"newNativeExecutions":0,"sourcePhysicalSHA256Before":hashlib.sha256(original).hexdigest(),"sourcePhysicalSHA256After":hashlib.sha256(manifest.read_bytes()).hexdigest(),"canonicalLFSHA256After":hashlib.sha256(manifest.read_bytes().replace(b"\r\n",b"\n")).hexdigest(),"diskFreeAfter":shutil.disk_usage(root).free}
(out/"MANIFEST_VALIDATION.json").write_bytes((json.dumps(result,indent=2)+"\n").encode())
(out/"ORIGINAL_SOURCE_HASHES.json").write_bytes((json.dumps(sources,indent=2)+"\n").encode())
(out/"OriginalPackage.swift").write_bytes(original)
subprocess.run(["git","diff","--check"],cwd=root,capture_output=True,check=True)
print(json.dumps(result,ensure_ascii=False))