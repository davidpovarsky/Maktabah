import gzip,hashlib,io,json,os,pathlib,shutil,signal,subprocess,tarfile,time,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='3bee41830fa4b1dce355d7e09a2a6c4c2ec36a44'
PARENT='37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be'
SOURCE='8f7142bba6efb8f4a93c4e325ee6cdb835041bb5'
DOCS='fd1407823dc346ea800cfba20523b56b98de8f08'
FOLLOW='947f6f531b5a927919d60e365f806286ce564ca4'
DONOR='/home/ubuntu/otzaria-wave3-annotation-selection-published-20261127/source'
RNDONOR='/mnt/development/projects/worktrees/Maktabah-wave3-vendor-admission-private-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127'
D='docs/hq-ui-inventory/wave3-annotation-selection-20261127'
F='docs/ui-routing/wave3-sefaria-annotation-source-20261127'
PROOF='docs/hq-integration/wave3-annotation-selection-intake-20261127'
ZIP=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-annotation-shared-intake-20261127.zip')
SWIFT=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
CORE=ROOT/'.git/search-continuation-integrated-controls-20261127'
RN=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-rn-semantic-intake-20261127')
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[];steps=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes'] and sha(b)==row['sha256'],row.get('path','unnamed')
def apply(text,changes,a,b):
 for e in changes:
  if 'append' in e:
   if (a,b)==('before','after'):text+=e['append']
   else:
    assert (a,b)==('after','before') and text.endswith(e['append'])
    text=text[:-len(e['append'])]
   continue
  assert text.count(e[a])==e.get('occurrences',1),(e.get('path'),e[a][:100])
  text=text.replace(e[a],e[b])
 return text
def capacity():
 assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
 assert sum(p.stat().st_blocks*512 for p in RUN.rglob('*')if p.is_file())<268435456
def run(name,argv,timeout=120):
 capacity();step={'name':name,'argv':list(map(str,argv)),'started':time.time()};steps.append(step)
 with (RUN/(name+'.stdout')).open('wb')as out,(RUN/(name+'.stderr')).open('wb')as err:
  p=subprocess.Popen(list(map(str,argv)),stdout=out,stderr=err,start_new_session=True,env={**os.environ,'TMPDIR':str(RUN/'tmp')})
  step['pid']=p.pid;step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21];until=time.time()+timeout
  while p.poll()is None:
   try:capacity();assert time.time()<until
   except BaseException:
    step['interrupted']='owned deadline/capacity guard';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
  step['exit']=p.returncode
 step['finished']=time.time();step['logs']={s:{'bytes':(RUN/(name+s)).stat().st_size,'sha256':sha((RUN/(name+s)).read_bytes())}for s in ['.stdout','.stderr']}
 dump(RUN/'STEPS.json',steps);assert p.returncode==0,name
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,DOCS)
 git('fetch','--no-tags','--no-write-fetch-head',RNDONOR,FOLLOW)
 assert rev(SOURCE+'^')==PARENT and rev(DOCS+'^')==SOURCE
 assert rev(FOLLOW+'^')=='7215591a74f48e3d50b14d22b35c3a602e9f9753'
 manifests=[]
 for commit,folder,name,digest,count in [(DOCS,D,'MANIFEST.json','e5a5d4f8eed256c71c79a0d74a6b5a4005cdaca300ddc40bbdb876928f5a3711',164),(FOLLOW,F,'ARTIFACTS.json','61ffd26fdcdfcc7ccfe483b8039a231200a58d28ccac7086a92e906b36bc21d1',15)]:
  raw=show(commit,folder+'/'+name);assert sha(raw)==digest
  rows=json.loads(raw);rows=rows['artifacts']if isinstance(rows,dict)else rows;assert len(rows)==count
  paths=git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()
  assert set(paths)=={folder+'/'+r['path']for r in rows}|{folder+'/'+name}
  for row in rows:pin(show(commit,folder+'/'+row['path']),row)
  manifests.append({'commit':commit,'path':folder+'/'+name,'rows':count,'sha256':digest})
 packet=json.loads(show(DOCS,D+'/SOURCE_PACKET.json'));assert packet['native']==packet['apple_sdk_typecheck']=='NOT_RUN'
 assert len(packet['product'])==8 and packet['original_edits']==47
 sourcePaths=git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines()
 assert set(sourcePaths)=={r['path']for r in packet['product']}
 beforeRows={r['path']:r for r in packet['original_source_inputs']};assert len(beforeRows)==16
 for row in beforeRows.values():pin(show(BASE,row['path']),row);assert show(BASE,row['path'])==show(PARENT,row['path'])
 hooks=json.loads(show(DOCS,D+'/FINAL_ORIGINAL_HOOKS.json'));assert len(hooks['edits'])==47
 for row in packet['product']:
  p=row['path'];after=show(SOURCE,p);pin(after,row)
  if p in beforeRows:
   before=show(BASE,p);selected=[e for e in hooks['edits']if e['path']==p]
   assert apply(before.decode(),selected,'before','after').encode()==after
   assert apply(after.decode(),list(reversed(selected)),'after','before').encode()==before
  else:assert not git('ls-tree',BASE,'--',p)
 for folder,count in [('evidence/raw-controls/files',34),('evidence/modal-controls/files',18)]:
  rows=json.loads(show(DOCS,D+'/'+folder+'/RAW_MANIFEST.json'));assert len(rows)==count
  for row in rows:pin(show(DOCS,D+'/'+folder+'/'+row['path']),row)
 for suffix,count in [('evidence/raw-controls/files/attempt-1/service-controls.stdout',11),('evidence/raw-controls/files/attempt-2/publication-controls.stdout',10),('evidence/raw-controls/files/attempt-3/actual-owner-controls.stdout',24)]:
  result=json.loads(show(DOCS,D+'/'+suffix));assert result['passed']==count and result['failed']==0
 assert b'RESULT passed=24 failed=0' in show(DOCS,D+'/evidence/modal-controls/files/attempt-5/actual-modal-controls.stdout')
 assert b'RESULT passed=0 failed=2' in show(DOCS,D+'/evidence/modal-controls/files/attempt-5/old-caller-annotations-aba.stdout')
 rnIndex=json.loads(show(FOLLOW,F+'/ARCHIVE_INDEX.json'))['members'];assert len(rnIndex)==33
 with tarfile.open(fileobj=io.BytesIO(show(FOLLOW,F+'/actual-root-facet-source-controls.tar.gz')),mode='r:gz')as tar:
  assert {m.name for m in tar.getmembers()if m.isfile()}=={r['path']for r in rnIndex}
  for row in rnIndex:pin(tar.extractfile(row['path']).read(),row)
 rnResults=json.loads(show(FOLLOW,F+'/RESULT.json'));assert rnResults['native']==rnResults['sdk']=='NOT_RUN'
 for row,counts in zip(rnResults['results'],[(2,8),(10,0),(5,5)]):assert row['compile_exit']==0 and (row['passed'],row['failed'])==counts
 raw=ZIP.read_bytes();assert len(raw)==220920 and sha(raw)=='df7bcb6754e971dba83d0596a61a8d91a9ccf55a392f74ae5224e5eb5cac6203'
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  rows=json.loads(z.read('MANIFEST.json'));assert len(rows)==9 and len(z.namelist())==10
  assert set(z.namelist())=={r['path']for r in rows}|{'MANIFEST.json'}
  files={r['path']:z.read(r['path'])for r in rows}
  for row in rows:pin(files[row['path']],row)
 sharedRows=json.loads(files['MERGE_RESULT.json']);assert len(sharedRows)==5
 nav=json.loads(show(DOCS,D+'/proposal/shared/EXACT_SHARED_EDITS.json'));assert len(nav['edits'])==37
 rnEdits=json.loads(files['RN_FOLLOWUP_EDITS.json']);assert len(rnEdits)==6
 patch=show(FOLLOW,F+'/RN_ANNOTATION_FACET.patch').decode();parts=[];part=None
 for line in patch.splitlines(True):
  if line.startswith('@@'):part={'path':rnEdits[0]['path'],'before':'','after':'','occurrences':1};parts.append(part)
  elif part is not None:
   if line[0]in' -':part['before']+=line[1:]
   if line[0]in' +':part['after']+=line[1:]
 assert parts==rnEdits
 shared={}
 for row in sharedRows:
  p=row['path'];old=show(BASE,p);assert sha(old)==row['beforeSHA256'] and len(old)==row['beforeBytes']
  new=files['candidate/'+p];assert sha(new)==row['afterSHA256'] and len(new)==row['afterBytes'];shared[p]=new
  selected=[e for e in nav['edits']if e['path']==p];follow=[e for e in rnEdits if e['path']==p]
  if selected:
   assert apply(apply(old.decode(),selected,'before','after'),follow,'before','after').encode()==new
   assert apply(apply(new.decode(),list(reversed(follow)),'after','before'),list(reversed(selected)),'after','before').encode()==old
 registration=json.loads(files['REGISTRATION.json']);assert registration['target']=='Maktabah-iOS'and len(registration['newObjects'])==4
 project='Maktabah.xcodeproj/project.pbxproj';inverse=shared[project].decode()
 for e in reversed(registration['projectInsertions']):
  assert inverse[e['offset']:e['offset']+len(e['text'])]==e['text'];inverse=inverse[:e['offset']]+inverse[e['offset']+len(e['text']):]
 assert inverse.encode()==show(BASE,project)
 catalog='Source/Localizable.xcstrings';item=registration['catalogInsertion'];inverse=shared[catalog].decode()
 assert inverse.count(item['anchor']+item['block'])==1 and inverse.replace(item['anchor']+item['block'],item['anchor'],1).encode()==show(BASE,catalog)
 shortcut='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift'
 assert show(BASE,shortcut).count(b'AppShortcut(intent:')==10
 # One current merged Host compilation. Reuse only exact RN UI/Core products.
 for name in ['inputs','output','tmp','module-cache']:(RUN/name).mkdir()
 assert sha(SWIFT.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 coreRows=[r for r in json.loads((CORE/'INPUTS.json').read_text())['files']if r['path'].startswith('Source/Otzaria/Actions/Sources/OtzariaActionCore/')];assert len(coreRows)==31
 for row in coreRows:pin(show(BASE,row['path']),row)
 for name,digest in [('OtzariaActionCore.swiftmodule','c45482e0c872e1378e9048b9f1b9fef473b0a9b8973ef0e17ee9e2df22a24103'),('libOtzariaActionCore.so','f7a7d43d27b341f53a32b5205306c6bcec69c7a05b1f381d6e2239d5803d049a')]:assert sha((CORE/'output'/name).read_bytes())==digest
 uiRows=[r for r in json.loads((RN/'PACKAGE_INPUTS.json').read_text())['files']if r['path'].startswith('Source/Otzaria/UIRouting/Sources/')];assert len(uiRows)==13
 for row in uiRows:pin(show(BASE,row['path']),row)
 for name,digest in [('OtzariaUIRouting.swiftmodule','7d3b1cb4f488ef5178a117c9200458a33d5e83578255f648d87feb6a7d0793e4'),('libOtzariaUIRouting.so','d5f0b4a3880467dab9103481dd11b825008c74958395d1ac122671b2d482595d')]:assert sha((RN/'output'/name).read_bytes())==digest
 host='Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost';paths=git('ls-tree','-r','--name-only',BASE,host).decode().splitlines()
 paths=sorted(set(p for p in paths if p.endswith('.swift'))|{p for p in sourcePaths if p.startswith(host+'/')});assert len(paths)==41
 packageRows=[];inputs=[]
 for p in paths:
  b=show(SOURCE,p)if p in sourcePaths else show(BASE,p);target=RUN/'inputs'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);inputs.append(target);packageRows.append({'path':p,'bytes':len(b),'sha256':sha(b)})
 flags=[SWIFT,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',RUN/'module-cache','-I',RN/'output','-L',RN/'output','-lOtzariaUIRouting','-Xlinker','-rpath','-Xlinker',RN/'output','-I',CORE/'output','-L',CORE/'output','-lOtzariaActionCore','-Xlinker','-rpath','-Xlinker',CORE/'output']
 previousCompile=RUN.with_name('otzaria-wave3-annotation-selection-intake-20261127-attempt2')
 previousInputs=json.loads((previousCompile/'PACKAGE_INPUTS.json').read_text())
 assert packageRows==previousInputs['currentHost'] and coreRows==previousInputs['reusedExactCore'] and uiRows==previousInputs['reusedExactUI']
 for row in packageRows:pin((previousCompile/'inputs'/row['path']).read_bytes(),row)
 syntax=[]
 for p in sourcePaths+[p for p in shared if p.endswith('.swift')]:
  b=shared[p]if p in shared else show(SOURCE,p);target=RUN/'inputs'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);syntax.append(target)
 assert len(syntax)==11
 syntaxRows=[{'path':str(p.relative_to(RUN/'inputs')),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in syntax]
 assert syntaxRows==previousInputs['syntax']
 for row in syntaxRows:pin((previousCompile/'inputs'/row['path']).read_bytes(),row)
 steps=json.loads((previousCompile/'STEPS.json').read_text())
 assert [s['name']for s in steps]==['compile-current-host','full-ios-syntax-release','full-ios-syntax-debug'] and all(s['exit']==0 for s in steps)
 for step in steps:
  for suffix,row in step['logs'].items():
   b=(previousCompile/(step['name']+suffix)).read_bytes();pin(b,row);(RUN/(step['name']+suffix)).write_bytes(b)
 dump(RUN/'STEPS.json',steps)
 dump(RUN/'PACKAGE_INPUTS.json',{'currentHost':packageRows,'reusedExactCore':coreRows,'reusedExactUI':uiRows,'syntax':[{'path':str(p.relative_to(RUN/'inputs')),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in syntax]})
 protected=['Source/Otzaria/Actions','Source/Otzaria/UIRouting','Vendor','Scripts','.github','docs/architecture','Maktabah-iOSUITests',shortcut]
 trees={p:rev(BASE+':'+p)for p in protected}
 for a,b in [(PARENT,SOURCE),(FOLLOW+'^',FOLLOW)]:git('diff','--check',a,b)
 # This immutable docs commit preserves literal patch context, compiler
 # diagnostics and extracted control bodies. Record its exact reviewed raw-data
 # whitespace diagnostic; never rewrite evidence bytes or alter Git settings.
 diagnostic=subprocess.run(['git','-C',str(ROOT),'diff','--check',SOURCE,DOCS],capture_output=True)
 assert diagnostic.returncode==2 and diagnostic.stderr==b'' and len(diagnostic.stdout)==5503
 assert sha(diagnostic.stdout)=='aeab4abe73317590de5bd933576841b722418b6fd0aadb0caef3ee4599cd6143'
 artifactDiagnostic={'from':SOURCE,'to':DOCS,'exit':2,'stdout':diagnostic.stdout.decode(),'stdoutSHA256':sha(diagnostic.stdout),'reason':'Exact preserved raw patch context, original compiler logs and extracted control bodies. Product diff and every actual shared source still require clean git diff --check; no policy or release gate changed.'}
 dump(RUN/'ARTIFACT_WHITESPACE.json',artifactDiagnostic)
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 picked=[]
 for donor in [SOURCE,DOCS,FOLLOW]:
  git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',donor)
  picked.append({'donor':donor,'intake':rev('HEAD')});assert not git('status','--porcelain')
 for p,b in shared.items():assert (ROOT/p).read_bytes()==show(BASE,p);(ROOT/p).write_bytes(b)
 git('add','--sparse','--',*shared);git('diff','--cached','--check');assert set(git('diff','--cached','--name-only').decode().splitlines())==set(shared)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Join original annotation selection and modal lifetime to native routing')
 sharedCommit=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 previous=RUN.with_name('otzaria-wave3-annotation-selection-intake-20261127')
 failure=json.loads((previous/'FAILURE.json').read_text());assert failure['error']=="KeyError('before')"
 priorEvents=json.loads((previous/'EVENTS.json').read_text());assert not any('cherry-pick'in e['args'] or 'commit'in e['args'] for e in priorEvents)
 (proof/'preserved-intake-attempt-1').mkdir()
 for name in ['RUN.py','FAILURE.json','EVENTS.json']:(proof/'preserved-intake-attempt-1'/(name+'.gz')).write_bytes(gzip.compress((previous/name).read_bytes(),mtime=0))
 (proof/'preserved-intake-attempt-2').mkdir()
 for name in ['RUN.py','FAILURE.json','EVENTS.json','STEPS.json','PACKAGE_INPUTS.json']:(proof/'preserved-intake-attempt-2'/(name+'.gz')).write_bytes(gzip.compress((previousCompile/name).read_bytes(),mtime=0))
 (proof/'ARTIFACT_WHITESPACE.json.gz').write_bytes(gzip.compress((RUN/'ARTIFACT_WHITESPACE.json').read_bytes(),mtime=0))
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 for name in ['RN_FOLLOWUP_EDITS.json','HUNK_JOIN.json','REGISTRATION.json','MERGE_RESULT.json']:(proof/(name+'.gz')).write_bytes(gzip.compress(files[name],mtime=0))
 for name in ['STEPS.json','PACKAGE_INPUTS.json']:(proof/name).write_bytes((RUN/name).read_bytes())
 for step in steps:
  for suffix in step['logs']:(proof/(step['name']+suffix)).write_bytes((RUN/(step['name']+suffix)).read_bytes())
 report={'schema':'otzaria.wave3.annotation-selection-intake.v1','base':BASE,'picked':picked,'sharedCommit':sharedCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'productPaths':8,'docsPaths':181,'manifests':manifests,'originalInputFiles':16,'originalEditsInverseVerified':47,'annotationSharedHunks':37,'rnFollowupHunks':6,'sharedFiles':5,'registration':registration,'rootHunkJoin':json.loads(files['HUNK_JOIN.json']),'rawAnnotationFilesVerified':52,'rawRNArchiveMembers':33,'sourceControls':packet['source_controls'],'rnRootControls':rnResults,'actualCurrentHostFiles':41,'actualSyntaxFilesBothModes':11,'compileEvidenceReusedFrom':str(previousCompile),'newCompileRunsThisAttempt':0,'artifactWhitespaceDiagnosticSHA256':artifactDiagnostic['stdoutSHA256'],'steps':steps,'protectedTrees':trees,'AppleSDK':'NOT_RUN','nativeRuns':0,'open':['Separate original expansion helper callback fence','Original editor body/tags/style and actual filter controls','Cold/foreign-root annotation entry','Actual system metadata and native selectors','Final production/owner/target merge/TestFlight']}
 dump(proof/'RESULT.json',report)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record original annotations and RN modal integration evidence')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sharedCommit':sharedCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'currentHostFiles':41,'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc(),'steps':steps});raise
