# Exact reviewed Vendor source admission — proposal for root review

Status: CONTRACT PROPOSAL ONLY. No CI predicate, product source, approval record, source manifest, SDK input, build or native run has been changed by this task.

## Verified source and problem

The current immutable root read is `24cd9291dbc87d799c22a41f0bc73a82c6415bfa`, Source tree `23cdfce49553927656ef79c6db10f654c889e2fc`, Vendor tree `9e4f188c5bedeef55ce95d97943f5e5046b6f3d6`. All six downstream Vendor objects are byte-identical to the independently inventoried ec5385 source. This is not a final application freeze.

The actual historical Vendor inventory has 200 leaves; current has 202. Exactly seven leaves differ: the already admitted Hanlin gitlink and the six downstream hooks below. All 195 remaining leaves have exactly the same path, mode, kind and Git object. Zayit's producer-to-current difference is exactly its one Swift consumer file. Sefaria's resource-producer-to-current difference is exactly its four JS integration files and one native Swift bridge file.

Three existing entry points reject the accepted source:
- `final_integration_source.verify` admits only the historical Hanlin gitlink difference.
- `hq-stage2-focused-apple.preflight` also compares the whole Zayit tree to its binary producer and permits only one Sefaria JS facade difference.
- `prepare-normal-ios-workspace.embedded_source_plan` independently repeats that one-facade Sefaria condition.

The current source manifest still names 64c1e74a. Its engine/resource/artifact/build-input payload, excluding the original source-binding fields, is exactly equal to the integration-base payload: canonical SHA256 `367149f9f2410551dafb52eb7635206af559940ca77e95082b3318a569553da8`.

## Closed review scope

| Exact path | Accepted Git object | Actual accepted lineage |
| --- | --- | --- |
| `Vendor/HanlinSDK` | `9565a9e4775901a4cee6f0402d7fd2978fab6612` (gitlink) | Retained 29a source; existing SDK gate remains separate |
| `Vendor/SefariaMobile/Integration/JS/ChavrusaRoot.js` | `cac6a68cfbcf7c652f60a25889e2f8625b4e8f82` | Root intake 791f88f2; donor b712b3c1 |
| `Vendor/SefariaMobile/Integration/JS/ChavrusaVisibleSurface.js` | `d37aca66489afb5b1268fe183b5adc17aa120535` | Root intake 791f88f2; newly added downstream wrapper |
| `Vendor/SefariaMobile/Integration/JS/ChavrusaVisibleSurfaceRegistry.js` | `e06994f58e3e68376fe785fdcd875d5c4508b6ad` | Root intake 791f88f2; newly added downstream registry |
| `Vendor/SefariaMobile/Integration/JS/chavrusaRPCFacade.js` | `db369aaf2b896b759660705524a5c0d9fcf1dc3e` | Root 791f88f2 plus c19b672d delayed-RPC intake (donor f03802af) |
| `Vendor/SefariaMobile/Integration/iOS/ChavrusaSefariaBridgeModule.swift` | `62a8d564a24352037d2ef26e22385cd74bc6a8e1` | Root intake 791f88f2 |
| `Vendor/ZayitSearchPort/Swift/ZayitSearchViewModel.swift` | `3c09ba0da39ac8e32f59b24c20133d12bf80efea` | Root accepted ledger commit 49a28bcc |

The six files are downstream integration code, not imported engine internals. The Sefaria Integration lineage is recorded from b13aabcd; its two new wrapper files are identified as new. The Zayit Swift adapter is distinct from the retained Rust and Upstream trees. The source-owned provenance records, exact initial/current objects, complete canonical binary patches and actual root intake revisions are retained in PROPOSAL_INPUTS.json and the read packet. The last facade intake must be recorded as an additional actual root delta; its earlier RN control receipt does not cover the later facade bytes.

Relevant existing evidence is the UI-03 RN source packet for Asana1220542361203468 and its SOURCE_PROVENANCE, the separately intaked delayed RPC source/controls, and the Wave2 search-page-ledger packet/provenance (coordination task1220939535420506, comment1220949535776986). Their Apple/Metro/native limitations remain unchanged. No existing source-control result becomes runtime acceptance.

## Proposed strict contract

Add one versioned `otzaria.reviewed-vendor-source/1` contract, pinned by a fixed path and SHA256 in its verifier, and referenced by the regenerated final source manifest. It records the exact reviewed Vendor tree above, all seven path objects, historical/producer/accepted revisions, file lengths/SHA256, canonical full-index binary patch digests, root intake ancestry and immutable provenance/evidence pointers. It exposes no wildcard namespace, arbitrary additional path or caller-supplied alternate producer.

The shared verifier must:
1. Require committed, regular, canonical contract bytes at its fixed path, matching its independently reviewed digest. Reject aliasing, duplicate keys/paths, missing fields and unknown contract versions.
2. Require the final application source and current committed Vendor tree to match the exact reviewed tree; verify the entire historical/current leaf maps and exactly the seven declared changes. Every other leaf must remain identical. Check object mode/kind, not just text or path names.
3. Verify all six exact accepted blobs and raw working-file bytes. Added files must be genuinely absent from historical/source producer trees. A symlink, renamed imported input, executable-mode change, extra comment or additional hunk fails.
4. Verify actual root intake commits are ancestors of the application source and that their recorded component objects and complete historical-to-current patches match. Keep donor provenance distinct from root integration objects; never assume a cherry-pick's entire donor file is identical after integration.
5. Preserve the original engine producer99f7927e, artifacts/run/job/archive identities and test-exclusion proof. Compare the whole producer/current Zayit inventories, allowing only the exact frozen Swift consumer object. Rust tree13cb3a06 and Upstream treedb6dc600, original build scripts and locks remain identical. The retained binary is still attributed to its original compiled Rust producer.
6. Preserve Sefaria gitlink2fd173a5, resource producer70810eec, original data resources, Metro entry/config and npm lock. Verify the complete producer/current Sefaria map: exactly four JS inputs plus the one native bridge change. The Swift bridge requires a new app compile; it is never treated as a JS overlay.
7. Require a new real Metro bundle from those four exact JS inputs. Record their hashes before/after, the whole current resource source tree, the newly produced bundle hash and the original baseline bundle separately. Keep the existing original Metro argv, resource verification, lock checks, native Pods preparation and built-app bundle equality checks.
8. Preserve the existing final source row, ancestor, project-exclusion, physical-source and historical-receipt checks. The new report remains source identity/attribution only, with new native/SDK/runtime qualification explicitly required.

The original Hanlin-only/historical source path may remain as the unchanged legacy predicate. A refreshed Wave3 manifest must carry the new exact contract and must not fall back to legacy admission if its contract is missing, stale or invalid. No future Vendor change is admitted by this proposal: a changed blob/tree requires a separately reviewed contract.

## One explicit source-input declaration

Recommend updating `embedded_js_overlay_paths` in the newly generated inputs from the old single facade to the exact four JS paths above, so that the current input declaration names the source actually being bundled.

This is the only additional intentional input-binding delta. Do not add the key to BINDING_FIELDS and silently ignore it. Validate the exact frozen old list and exact frozen new list against the review contract, then compare every other original common input unchanged. Preserve the original baseline common-input hash and additionally record the current common-input hash plus this exact reviewed field delta. All artifact SHA/ID/producer metadata, bundle baseline hash, resource dictionaries, engine trees, rebuild flags and other build inputs remain unchanged. The old receipts and old input snapshots remain immutable.

This narrow field transition is part of root's review request, not an already applied exception. It is needed because declaring one facade while actually bundling four reviewed inputs would obscure the new source scope.

## Proposed edit ownership

| Path | Classification and exact intended edit |
| --- | --- |
| `Scripts/CI/reviewed_vendor_source.py` (new) | Downstream CI source-identity helper; one fixed contract reader and exact tree/object/patch/producer checks |
| `Scripts/CI/reviewed-vendor-source.inputs.json` (new) | Closed reviewed source/evidence contract; no owner signature or runtime assertion |
| `Scripts/CI/final_integration_source.py` | Fork CI introduced04b59e07, absent from actual Maktabah upstream4203de5; replace only Vendor admission and validate the one exact input-field transition |
| `Scripts/CI/hq-stage2-focused-apple.py` | Fork CI introduced7f0ca571, absent from upstream; shared exact Zayit consumer/Sefaria plans and before/after current JS attribution, retaining original build/restore/metadata checks |
| `Scripts/CI/prepare-normal-ios-workspace.py` | Fork adapter introduced14d0e939, absent from upstream; consume the same Sefaria plan, retaining resource-only restoration and same-run engine/SwiftPM ownership |
| `Scripts/CI/test-reviewed-vendor-source.py` (new) | Meaningful real Git/temporary-file positive and adversarial controls for the actual helper and route integrations |
| `Scripts/CI/test-normal-ios-workspace.py` (only if needed) | Preserve all original scenarios/assertions. Its current ACTUAL_CONFIG fixture assumes one facade; bind that legacy fixture explicitly to the original immutable input snapshot and add separate current-contract route controls, rather than weakening expected failures |
| `docs/hq-integration/wave3-vendor-source-admission-20261127/` | Exact source/provenance/control receipts and failed baseline retained |

The final application manifest and hq-stage2 inputs are root's final-freeze outputs; this lane will supply the exact generation plan and isolated dry candidate, without declaring a moving root frozen. No product Vendor file, engine import, dependency lock, resource producer artifact, owner registry, cryptographic verifier, trusted PR workflow, runtime gate or SDK qualification controller is in the edit scope.

## Required controls before source delivery

Use actual Git trees/objects and temporary regular files, not a model that reproduces the predicate. No npm, Pods, Xcode, simulator or remote native execution is required for these controls.

- Preserve the actual old rejection of the seven-path current source. Positive new-contract control must admit only the exact source identity and still report native acceptance false.
- Reject an additional imported engine/data/lock/build-script change; a wrong Sefaria/Hanlin gitlink; an undeclared path; a missing new file; a renamed/mode-changed/symlink input; and any extra hunk in an otherwise named file.
- Reject wrong component ancestry, altered canonical patch, contract-byte/digest mismatch and a missing new contract.
- Reject any original engine/resource artifact hash, run/job/producer or retained receipt change, including an attempt to relabel the old bundle as the newly built one.
- Verify the exact four-JS/one-native separation; reject dropping a JS path or including the Swift bridge as JS; verify a changed input during bundling fails and the copied app bundle must equal the actual newly produced bundle.
- Exercise the focused and normal routes against the same accepted/refused source facts. Retain every original normal-adapter assertion and its explicit legacy scope; the normal route must still avoid restoring historical engine/SwiftPM archives.
- Include actual one-field input transition controls: expected old→new declaration accepted, any other field or arbitrary overlay value rejected. Freeze both baseline and candidate source/input/log hashes.

These are proposed controls, not executed results. Final app build, native selectors, full acceptance and physical checks remain separate.

## Final manifest generation plan

1. Finish all source/test/PBX/catalog/dependency integration and record immutable productS. Read the actual target policy separately; this contract does not authorize target or owner-gate changes.
2. Keep historical source d3da5541 and integration base08f50a56 unchanged. Retain all accepted components and add only actual root intake revisions needed by the final source, all ancestors ofS; donor refs are provenance, not invented ancestry.
3. Regenerate the complete sorted product delta over Source/Vendor/project/UI-tests. Reuse exact component objects; give genuine composed objects their complete patch and every original component object required by verify_rows. Do not omit protected paths or original tests.
4. Add the pinned Vendor contract reference. Verify the exact closed Vendor tree onS. If any Vendor object differs from this proposal, stop that admission and review the real new delta; do not regenerate the policy to fit it automatically.
5. Rebind application source/trees, original Hanlin and Swift-AI source identities, original additions/project-exclusion record, final manifest hash and the one explicitly reviewed JS-input list. Preserve historical receipts and all remaining common build inputs byte-for-byte/semantically as required by the original checker.
6. Commit the source-admission and SDK-route inputs and authentic final owner records before the qualifying UI run. Root's unchanged runtime-release gate only permits later docs/hq-integration descendants; an after-run approval/input/test change cannot be relabelled as covered.
7. Run the genuine source verifier and original preparation gates on that clean final candidate, report exact verified object/input counts and hashes, then execute the separately required SDK/app/runtime acceptance. This proposal confers none of those later results.

## Read evidence and limits

CURRENT_ROOT_PROOF.json is a direct immutable read from root's actual Git store; no foreign working files or dirty checkout were verified. PROPOSAL_INPUTS.json retains the earlier exact ec5385 component/producer history, proven Vendor-equivalent to24cd. READ_SOURCE_INPUTS.json and READ_PACKET_ENVELOPE.json bind nine exact source/provenance files and canonical Vendor patch (raw109466B, SHA359772ba…).

The first large read exceeded Sentinel's bounded output and was retained as a failed/truncated retrieval; the subsequent bounded reads and lossless compressed packet succeeded. Missing c443/7fbe objects in this lane's older private store were not interpreted as missing root commits. No current upstream merge, owner-signing run, original SDK/app compile or native acceptance was performed.

