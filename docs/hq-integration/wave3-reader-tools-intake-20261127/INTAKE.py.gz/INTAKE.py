import gzip,hashlib,io,json,os,pathlib,shutil,subprocess,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='ce4fe5a327168524f6f1fef1e7792a275ece0ebe'
BRANCH='codex/otzaria-wave3-integration-20261127'
D='docs/ui-routing/wave3-reader-tools-20261127'
PROOF='docs/hq-integration/wave3-reader-tools-intake-20261127'
ZIP=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-reader-tools-source-packet-20261127.zip')
SWIFT=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def decoded(files,rel):return json.loads(gzip.decompress(files[D+'/'+rel+'.gz']))
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain')
 assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 b=ZIP.read_bytes();assert len(b)==868060 and sha(b)=='4c58ed25e62ab98da66ed1c76f31283d0d0e56ac5116a9cea2867583b99968ec'
 with zipfile.ZipFile(io.BytesIO(b))as z:
  manifest=json.loads(z.read('MANIFEST.json'));assert len(manifest)==47 and len(z.namelist())==48
  assert set(z.namelist())=={r['path']for r in manifest}|{'MANIFEST.json'}
  files={r['path']:z.read(r['path'])for r in manifest}
  for row in manifest:pin(files[row['path']],row)
  assert all(not pathlib.PurePosixPath(p).is_absolute()and'..'not in pathlib.PurePosixPath(p).parts for p in files)
 products=json.loads(files[D+'/PRODUCT_FILES.json']);assert len(products)==8
 for row in products:
  pin(files['candidate/'+row['path']],row)
  if row['beforeSHA256']:assert sha(show(BASE,row['path']))==row['beforeSHA256']
  else:assert not git('ls-tree',BASE,'--',row['path'])
 for row in json.loads(files[D+'/LOCAL_SOURCE_EVIDENCE.json']):
  pin(files[D+'/'+row['path']],row);raw=gzip.decompress(files[D+'/'+row['path']])
  assert len(raw)==row['uncompressedBytes']and sha(raw)==row['uncompressedSHA256']
 # Reapply every reviewed shared hunk to the actual current preimage. The
 # existing thirteen Group hunks remain, and the two application orders join.
 edits=decoded(files,'SHARED_EDITS.json');assert len(edits)==24
 shared={}
 for row in edits:
  p=row['path'];text=shared.get(p,show(BASE,p).decode())
  assert text.count(row['old'])==1,p;shared[p]=text.replace(row['old'],row['new'],1)
 for p,text in shared.items():
  assert text.encode()==files['candidate/'+p]
  inverse=text
  for row in reversed([x for x in edits if x['path']==p]):
   assert inverse.count(row['new'])==1;inverse=inverse.replace(row['new'],row['old'],1)
  assert inverse.encode()==show(BASE,p)
 session='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
 joined=decoded(files,'SESSION_GROUP_JOIN.json');assert joined['commuteExactly']is True and joined['groupHunks']==13 and joined['readerToolSessionHunks']==7
 group=json.loads(show(BASE,'docs/ui-routing/wave3-group-parent-selection-20261127/proposal/SESSION_EDITS.json'))
 before=show('37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be',session).decode()
 for row in edits:
  if row['path']==session:assert before.count(row['old'])==1;before=before.replace(row['old'],row['new'],1)
 for row in group:assert before.count(row['before'])==1;before=before.replace(row['before'],row['after'],1)
 assert before.encode()==files['candidate/'+session]and sha(before.encode())==joined['combinedSHA256']
 registration=decoded(files,'REGISTRATION.json')
 project='Maktabah.xcodeproj/project.pbxproj';inverse=files['candidate/'+project].decode()
 for row in reversed(registration['projectInsertions']):
  assert inverse[row['offset']:row['offset']+len(row['text'])]==row['text']
  inverse=inverse[:row['offset']]+inverse[row['offset']+len(row['text']):]
 assert inverse.encode()==show(BASE,project)and len(registration['newPBXObjects'])==2
 oldCatalog=json.loads(show(BASE,'Source/Localizable.xcstrings'));catalog=json.loads(files['candidate/Source/Localizable.xcstrings'])
 keys=registration['files'][1]['addedKeys'];assert len(keys)==7
 assert {k:v for k,v in catalog['strings'].items()if k not in keys}==oldCatalog['strings']
 assert all(catalog['strings'][k]['localizations']['en']['stringUnit']['value']==k and catalog['strings'][k]['localizations']['he']['stringUnit']['value']for k in keys)
 originalIntent='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift'
 assert sha(show(BASE,originalIntent))==registration['curatedShortcutSourceSHA256']and show(BASE,originalIntent).count(b'AppShortcut(intent:')==10
 # Preserve the complete source/log/result inputs for all actual control
 # attempts, including failures. Compiled products stay in place and are pinned.
 scopes=[
 ('service-attempt1','Maktabah-wave3-reader-tools-controls-20261127-attempt1','d4f8657dc9be063ba46fdfd1babd0c983378534e89cbcf8419cd86e49ba7e6ea'),
 ('service-attempt2','Maktabah-wave3-reader-tools-controls-20261127-attempt2','1d2ffbeea73ad3e59f3ef00474692c05d82594b65e5118d5e0f50ebdbbb7bcd1'),
 ('source-attempt1','Maktabah-wave3-reader-tools-source-controls-20261127-attempt1','c3cfd0980f87cce09b0f0187acaa05a1d27a9d37c762589352fa3e55005d9305'),
 ('sink-attempt1','Maktabah-wave3-reader-tools-sink-controls-20261127-attempt1','8216488158c1ad8c4aacfef897f2c8e4d92f496f5a421139d9893bf5f2f90a9d'),
 ('utf8-attempt1','Maktabah-wave3-reader-tools-utf8-controls-20261127-attempt1','f91b6d843aa9b08601c6c7a3d46b80eb29305bd920dd5349635055af2348d972'),
 ('utf8-attempt2','Maktabah-wave3-reader-tools-utf8-controls-20261127-attempt2','6f9fff0004e9f82b6df9910bb6fc6bad5374ce9d5abd6604d182113863ec637d')]
 rawRows=[];productRows=[];results={};rawBuffer=io.BytesIO()
 with zipfile.ZipFile(rawBuffer,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for label,name,digest in scopes:
   directory=pathlib.Path('/mnt/development/projects/worktrees')/name
   resultBytes=(directory/'RESULT.json').read_bytes();assert sha(resultBytes)==digest;results[label]=json.loads(resultBytes)
   for step in results[label]['steps']:
    for suffix,value in step['logs'].items():pin((directory/(step['name']+suffix)).read_bytes(),value)
   for p in sorted(directory.rglob('*')):
    if not p.is_file():continue
    relative=p.relative_to(directory)
    if 'tmp'in relative.parts or'module-cache'in relative.parts:continue
    b=p.read_bytes();row={'path':label+'/'+relative.as_posix(),'bytes':len(b),'sha256':sha(b)}
    if 'output'in relative.parts:productRows.append({**row,'preservedAt':str(p)});continue
    z.writestr(row['path'],b);rawRows.append(row)
  z.writestr('MANIFEST.json',json.dumps(rawRows,indent=2)+'\n')
 assert results['service-attempt2']['verdict']['passed']==30 and results['service-attempt2']['verdict']['failed']==0
 assert results['source-attempt1']['candidate']['passed']==20 and results['source-attempt1']['candidate']['failed']==0
 assert results['source-attempt1']['initial']['passed']==18 and results['source-attempt1']['initial']['failed']==2
 assert results['sink-attempt1']['candidate']['passed']==10 and results['sink-attempt1']['initial']['failed']==8
 assert results['utf8-attempt2']['candidate']['passed']==6 and results['utf8-attempt2']['initial']['failed']==2
 assert all(x['nativeRuns']==0 and x['AppleSDK']=='NOT_RUN'for x in results.values())
 # Exact tested source joins. The old service's broad suite and the final
 # narrow UTF8 delta keep distinct provenance and are never conflated.
 scopeRoot=pathlib.Path('/mnt/development/projects/worktrees')
 toolRoot='Source/ChavrusaText/UIRoutingHost/'
 assert files['candidate/'+toolRoot+'Integration/MaktabahNativeReaderToolSource.swift']==(scopeRoot/scopes[2][1]/'inputs/candidate'/toolRoot/'Integration/MaktabahNativeReaderToolSource.swift').read_bytes()
 assert files['candidate/'+toolRoot+'Integration/MaktabahNativeSceneBindings.swift']==(scopeRoot/scopes[2][1]/'inputs/candidate'/toolRoot/'Integration/MaktabahNativeSceneBindings.swift').read_bytes()
 assert files['candidate/'+toolRoot+'Integration/MaktabahNativeRoutingComposition.swift']==(scopeRoot/scopes[3][1]/'inputs/MaktabahNativeRoutingComposition.swift').read_bytes()
 assert files['candidate/'+toolRoot+'Sources/ChavrusaUIRoutingHost/NativeReaderToolIntentService.swift']==(scopeRoot/scopes[5][1]/'inputs/candidate-NativeReaderToolIntentService.swift').read_bytes()
 assert files['candidate/'+toolRoot+'Sources/ChavrusaUIRoutingHost/NativeReaderToolIntents.swift']==(scopeRoot/scopes[2][1]/'inputs/candidate'/toolRoot/'Sources/ChavrusaUIRoutingHost/NativeReaderToolIntents.swift').read_bytes()
 assert sha(SWIFT.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 sessionInput=RUN/'MaktabahNativeSceneSession.swift';sessionInput.write_bytes(files['candidate/'+session]);parses=[]
 for mode in ['release','debug']:
  argv=[str(SWIFT),'-frontend','-parse','-target','arm64-apple-ios27.0-simulator']+(['-D','DEBUG']if mode=='debug'else[])+[str(sessionInput)]
  p=subprocess.run(argv,capture_output=True,timeout=30)
  (RUN/(mode+'.stdout')).write_bytes(p.stdout);(RUN/(mode+'.stderr')).write_bytes(p.stderr)
  parses.append({'mode':mode,'argv':argv,'exit':p.returncode,'stdoutSHA256':sha(p.stdout),'stderrSHA256':sha(p.stderr)});assert p.returncode==0
 protected=['Vendor','Source/Otzaria/Actions','Scripts','.github','docs/architecture','Maktabah-iOSUITests']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain')
 for row in products:
  p=ROOT/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(files['candidate/'+row['path']])
 git('diff','--check');git('add','--sparse','--',*[row['path']for row in products])
 assert set(git('diff','--cached','--name-only').decode().splitlines())=={row['path']for row in products}
 git('diff','--cached','--check')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Add original commentary and unsaved note App Intents')
 productCommit=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 for name,b in files.items():
  if name.startswith(D+'/'):
   p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 evidence=ROOT/D/'evidence';evidence.mkdir()
 packed=rawBuffer.getvalue();(evidence/'RAW_CONTROLS.zip').write_bytes(packed)
 dump(evidence/'RAW_CONTROLS_INDEX.json',rawRows);dump(evidence/'RETAINED_PRODUCTS.json',productRows)
 dump(evidence/'CONTROL_RESULTS.json',results)
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 for name in ['release.stdout','release.stderr','debug.stdout','debug.stderr']:(proof/name).write_bytes((RUN/name).read_bytes())
 report={'schema':'otzaria.wave3.reader-tools-intake.v1','base':BASE,'productCommit':productCommit,'productFiles':products,'sourceTree':rev('HEAD:Source'),
  'sharedHunks':24,'groupSessionHunksPreserved':13,'commutedSessionJoin':joined,'PBXAndCatalogRegistration':registration,
  'rawControlFiles':len(rawRows),'retainedProductFiles':len(productRows),'rawArchive':{'bytes':len(packed),'sha256':sha(packed)},
  'sourceEvidence':{'initialService':'30/30 on ec19d433, final UTF8 delta separately verified','sourceSelection':'20/20 vs18/20','receiveACK':'10/10 vs2/10','finalUTF8Service':'6/6 vs4/6'},
  'newCombinedSessionSyntax':parses,'preservedFailedAttempts':[scopes[0],scopes[4]],'protectedTrees':trees,
  'nativeRuns':0,'AppleSDK':'NOT_RUN','CoreExecution':'NOT_RUN','curatedShortcutCount':10,
  'open':['Cold initial-content readonly source fence join','Original Annotations modal source join','Precise original Inspector tabs','Actual App Intents SDK and metadata extraction','Final Native116/Release114+2/production/owner gates','Signed production release and physical owner QA']}
 dump(proof/'RESULT.json',report)
 artifactRows=[{'path':p.relative_to(ROOT/D).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted((ROOT/D).rglob('*'))if p.is_file()]
 dump(ROOT/D/'ARTIFACTS.json',{'files':artifactRows,'productCommit':productCommit})
 git('add','--sparse','--',D,PROOF);git('diff','--cached','--check')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Preserve Reader tool source controls and integration evidence')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'productCommit':productCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),
  'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'rawControlFiles':len(rawRows),'retainedProducts':len(productRows),'nativeRuns':0,
  'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
