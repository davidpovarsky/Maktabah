from pathlib import Path
import ast
import hashlib
import json
import shutil

base = Path(__file__).resolve().parent
out = base / 'launch-envelope'
out.mkdir(exist_ok=False)

def sha(body):
    return hashlib.sha256(body).hexdigest()

old_watcher = (base / 'actual-cutover/completion_watcher.py').read_bytes()
old_launcher = (base / 'actual-cutover/launch_owned.py').read_bytes()
assert sha(old_watcher) == 'd3dbbf9b6258d6818e4c58e6026446cf5995f28ddffbeaa7c6e9d9d31437ec23'
assert sha(old_launcher) == '583e599ab0a226d3d5be3a070fadae0dd8d895645b2d17706ee8e387cd59448e'
watcher = old_watcher.decode().replace(
    '30cb3a7d41201271c53b08494d2bf2dbd027e8dba61f86538f1c75e969dc2416',
    '4720728f67862a003ed527a56ef1164eae6e063509eb3b619f7a26b346f6be2b').replace(
    'wave3-sdk-fresh-after-five-scopes-20261127.',
    'wave3-sdk-pasteboard-options-20261127.').replace(
    'assert started["freeBefore"] >= 2415919104, "Original reserve unavailable before supervisor"',
    'assert started["freeBefore"] >= 15032385536, "Root fourteen-GiB launch admission unavailable before supervisor"')
ast.parse(watcher)
(out / 'completion_watcher.py').write_text(watcher)

names = ['supervisor.py', 'FRESH_RUN_COMMANDS.json', 'HISTORICAL_OBSERVED_CONTRACT.json',
         'UNCHANGED_ORIGINAL_GUARDS.json', 'PROPOSAL.json', 'COMPLETE_PLAN.json']
for name in names:
    shutil.copyfile(base / name, out / name)
shutil.copyfile(base / 'actual-cutover/CUTOVER_RESULT.json', out / 'CUTOVER_RESULT.json')
names += ['completion_watcher.py', 'CUTOVER_RESULT.json']
guards = json.loads((base / 'UNCHANGED_ORIGINAL_GUARDS.json').read_bytes())['original_files']
manifest = {
    'schema': 1,
    'status': 'CONDITIONAL_ROOT_AUTHORIZATION_NOT_LAUNCHED',
    'sourceSHA': 'd6090c03b9ac4e5760941e34f4c04478db4ae59f',
    'approvedSupervisorSHA256': '4720728f67862a003ed527a56ef1164eae6e063509eb3b619f7a26b346f6be2b',
    'minimumLaunchFreeBytes': 15032385536,
    'unchangedLiveStopReserveBytes': 2415919104,
    'minimumLaunchFreeIsNotACompletedPeakOrAcceptance': True,
    'singleAttemptNoAutomaticRetry': True,
    'preflightGuard': next(row for row in guards if row['path'] == 'Tools/PinkhaSimulatorGate/preflight.py'),
    'files': [dict(path=name, bytes=(out / name).stat().st_size, sha256=sha((out / name).read_bytes())) for name in names],
    'originalControllerSources': {
        'launcherSHA256': sha(old_launcher), 'watcherSHA256': sha(old_watcher),
        'watcherChanges': ['approved supervisor pin', 'exact new owned output prefix', 'root fourteen-GiB pre-launch admission'],
        'watcherProcessOwnershipObservationAndWaitUnchanged': True,
        'watcherIssuesProcessSignals': False,
    },
}
raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
(out / 'LAUNCH_INPUTS.json').write_bytes(raw)
manifest_sha = sha(raw)
launcher = old_launcher.decode().replace(
    '47058156954a5279eb44d6c7290f3eed7ef6c0430a9d7fa683b11fcb27650f83', manifest_sha).replace(
    '1be970356c655bcef3688ddf1d129d5029bbc533',
    'd6090c03b9ac4e5760941e34f4c04478db4ae59f').replace(
    'assert available >= 2415919104, "Original2GiB+256MiB reserve not available"',
    'assert available >= 15032385536, "Root fourteen-GiB launch admission not available"')
needle = '    df = subprocess.run(["/bin/df", "-k", "/System/Volumes/Data"], capture_output=True, text=True, check=True).stdout\n'
assert launcher.count(needle) == 1
launcher = launcher.replace(needle, '''    compiler_rows = subprocess.run(["/bin/ps", "-axo", "pid=,comm="], capture_output=True, text=True, check=True).stdout
    compiler_names = {"xcodebuild", "swiftc", "swift-frontend", "clang", "clang++", "cc1", "actool", "ibtool", "ld", "gomobile", "gobind"}
    active_compilers = []
    for line in compiler_rows.splitlines():
        fields = line.strip().split(None, 1)
        if len(fields) == 2 and Path(fields[1]).name in compiler_names:
            active_compilers.append({"pid": int(fields[0]), "executable": fields[1]})
    assert not active_compilers, "Exclusive compiler slot is occupied; no process is stopped"
''' + needle)
launcher = launcher.replace('"originalGuardFilesVerified": 17, "freshPathsAbsent": recipe["fresh_paths"],',
    '"originalGuardFilesVerified": 17, "freshPathsAbsent": recipe["fresh_paths"],\n             "minimumLaunchFreeBytes": 15032385536, "activeCompilers": active_compilers,')
ast.parse(launcher)
(out / 'launch_owned.py').write_text(launcher)

def function_source(raw, name):
    text = raw.decode() if isinstance(raw, bytes) else raw
    for node in ast.parse(text).body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return ast.get_source_segment(text, node)
    raise AssertionError(name)

for name in ['utc', 'digest', 'identity', 'free', 'write']:
    assert function_source(old_watcher, name) == function_source(watcher, name)
for name in ['utc', 'save', 'git', 'identity']:
    assert function_source(old_launcher, name) == function_source(launcher, name)
result = {'status': 'OWNED_LAUNCH_ENVELOPE_PREPARED_NOT_EXECUTED', 'manifest_sha256': manifest_sha,
          'launcher_sha256': sha(launcher.encode()), 'watcher_sha256': sha(watcher.encode()),
          'supervisor_sha256': sha((out / 'supervisor.py').read_bytes()), 'minimum_free_bytes': 15032385536,
          'command': ['/opt/homebrew/opt/python@3.12/libexec/bin/python3', '-B', 'launch_owned.py', '--execute-root-authorized-attempt'],
          'builds_run': 0, 'native_runs': 0}
(out / 'ENVELOPE_PREPARATION.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
