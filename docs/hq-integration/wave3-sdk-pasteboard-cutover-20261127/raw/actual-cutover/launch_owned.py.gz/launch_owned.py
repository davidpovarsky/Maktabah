"""Launch one reviewed, durable SDK watcher; a repeated invocation cannot relaunch."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

EXPECTED_MANIFEST = "47058156954a5279eb44d6c7290f3eed7ef6c0430a9d7fa683b11fcb27650f83"
PYTHON = "/opt/homebrew/opt/python@3.12/libexec/bin/python3"
SDK = Path("/Users/m1/builds/otzaria-wave1-sdk-20261127/source")
SOURCE = "1be970356c655bcef3688ddf1d129d5029bbc533"


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, data):
    with path.open("xb") as f:
        f.write((json.dumps(data, indent=2) + "\n").encode())
        f.flush()
        os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def git(*args):
    return subprocess.run(["/usr/bin/git", "-c", "gc.auto=0", "-c", "maintenance.auto=false", "-C", str(SDK), *args],
                          capture_output=True, check=True).stdout


def identity(pid):
    p = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "pid=,ppid=,pgid=,lstart=,command="], capture_output=True, text=True)
    raw = p.stdout.strip()
    fields = raw.split(None, 8)
    if p.returncode or len(fields) != 9:
        return {"pid": pid, "available": False, "raw": raw, "observed_at": utc()}
    return {"pid": int(fields[0]), "ppid": int(fields[1]), "pgid": int(fields[2]),
            "start": " ".join(fields[3:8]), "command": fields[8],
            "available": True, "raw": raw, "observed_at": utc()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--execute-root-authorized-attempt", action="store_true", required=True)
    ap.parse_args()
    control = Path(__file__).resolve().parent
    manifest_bytes = (control / "LAUNCH_INPUTS.json").read_bytes()
    assert hashlib.sha256(manifest_bytes).hexdigest() == EXPECTED_MANIFEST
    manifest = json.loads(manifest_bytes)
    for row in manifest["files"]:
        path = control / row["path"]
        assert path.parent == control and not path.is_symlink()
        b = path.read_bytes()
        assert len(b) == row["bytes"] and hashlib.sha256(b).hexdigest() == row["sha256"]
    assert git("rev-parse", "HEAD").decode().strip() == SOURCE
    assert not git("status", "--porcelain", "--untracked-files=no").strip()
    original = json.loads((control / "HISTORICAL_OBSERVED_CONTRACT.json").read_bytes())
    for row in original["original_files"] + [manifest["preflightGuard"]]:
        b = (SDK / row["path"]).read_bytes()
        assert len(b) == row["bytes"] and hashlib.sha256(b).hexdigest() == row["sha256"]
        assert git("show", "HEAD:" + row["path"]) == b
    recipe = json.loads((control / "FRESH_RUN_COMMANDS.json").read_bytes())
    for value in recipe["fresh_paths"].values():
        p = Path(value)
        assert p.is_relative_to(SDK / "build") and not p.exists() and not p.is_symlink()
    ps = subprocess.run(["/bin/ps", "-axo", "pid,ppid,command"], capture_output=True, text=True, check=True).stdout
    assert not any(str(SDK) in line and any(k in line for k in ["run_framework_acceptance.py", "prepare_local_execution.py", "xcodebuild", "swift-frontend"])
                   for line in ps.splitlines()), "Original SDK slot already active"
    df = subprocess.run(["/bin/df", "-k", "/System/Volumes/Data"], capture_output=True, text=True, check=True).stdout
    available = int(df.splitlines()[1].split()[3]) * 1024
    assert available >= 2415919104, "Original2GiB+256MiB reserve not available"
    claim = {"schema": 1, "status": "ROOT_AUTHORIZED_SINGLE_ATTEMPT_CLAIMED", "created_at": utc(),
             "manifestSHA256": EXPECTED_MANIFEST, "approvedSupervisorSHA256": manifest["approvedSupervisorSHA256"],
             "launcherIdentity": identity(os.getpid()), "sourceSHA": SOURCE,
             "originalGuardFilesVerified": 17, "freshPathsAbsent": recipe["fresh_paths"],
             "freeBefore": available, "rawDf": df, "retryAuthorized": False}
    save(control / "LAUNCH_CLAIM.json", claim)
    command = [PYTHON, "-B", str(control / "completion_watcher.py"),
               "--execute-owned-supervisor", "--manifest-sha256", EXPECTED_MANIFEST]
    with (control / "watcher.stdout.log").open("xb") as so, (control / "watcher.stderr.log").open("xb") as se:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=so, stderr=se,
                                 cwd=control, start_new_session=True, close_fds=True)
        observed = identity(child.pid)
        if observed["available"]:
            assert observed["pid"] == child.pid and observed["pgid"] == child.pid
    result = {"schema": 1, "status": "OWNED_WATCHER_LAUNCHED_NOT_ACCEPTANCE", "created_at": utc(),
              "watcherIdentity": observed, "watcherPID": child.pid, "command": command,
              "manifestSHA256": EXPECTED_MANIFEST, "control": str(control), "freeBefore": available,
              "launcherSourceSHA256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    save(control / "LAUNCH_RESULT.json", result)
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
