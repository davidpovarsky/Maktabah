#!/usr/bin/env python3
"""Prepare review-only configuration for a genuine corrected-source SDK execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
OLD_SHA = '1be970356c655bcef3688ddf1d129d5029bbc533'
NEW_SHA = 'd6090c03b9ac4e5760941e34f4c04478db4ae59f'
SUPERVISOR_SHA = '30cb3a7d41201271c53b08494d2bf2dbd027e8dba61f86538f1c75e969dc2416'


def sha(value):
    return hashlib.sha256(value).hexdigest()


def save(name, value):
    raw = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    with (ROOT / name).open('xb') as f:
        f.write(raw)
    return {'path': name, 'bytes': len(raw), 'sha256': sha(raw)}


old = (ROOT / 'reviewed-supervisor-30cb.py').read_bytes()
assert sha(old) == SUPERVISOR_SHA
text = old.decode()
tree = ast.parse(text)
assignment = next(n for n in tree.body if isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'payload' for t in n.targets))
old_payload = json.loads(ast.literal_eval(assignment.value.args[0]))
recipe = json.loads(old_payload['recipeText'])
assert recipe['source_sha'] == OLD_SHA
old_paths = recipe['fresh_paths']
new_paths = {
    'evidence': recipe['root'] + '/build/SDK-Wave3-d6090c03-Debug-PasteboardOptions-20261127-Evidence',
    'work': recipe['root'] + '/build/SDK-Wave3-d6090c03-Debug-PasteboardOptions-20261127-Work',
    'abi': recipe['root'] + '/build/SDK-Wave3-d6090c03-NativeABI-PasteboardOptions-20261127',
    'macro': recipe['root'] + '/build/SDK-Wave3-d6090c03-ReviewedMacro-PasteboardOptions-20261127',
}


def rename_paths(value):
    if isinstance(value, str):
        for key, before in old_paths.items():
            value = value.replace(before, new_paths[key])
        return value
    if isinstance(value, list):
        return [rename_paths(v) for v in value]
    if isinstance(value, dict):
        return {k: rename_paths(v) for k, v in value.items()}
    return value


recipe = rename_paths(recipe)
recipe['source_sha'] = NEW_SHA
recipe['source_cutover_is_a_separate_reviewed_operation'] = True
recipe['previous_failed_execution'] = 'local-ad6e0a4b-ca9a-4d64-91ea-8d1c1c843ee7'
recipe['previous_failure_remains_not_accepted'] = True
recipe['required_capacity'] = ('One root-owned exclusive SDK slot and fresh live capacity observation; unchanged 2 GiB '
                               'reserve plus 256 MiB early-stop margin. The completed fresh framework-plus-consumer '
                               'peak is unknown; no fixed peak, guaranteed success or production admission is inferred.')
recipe_text = json.dumps(recipe, indent=2) + '\n'
assert recipe['fresh_paths'] == new_paths
assert len(recipe['commands']) == len(json.loads(old_payload['recipeText'])['commands'])
old_commands = json.loads(old_payload['recipeText'])['commands']
assert recipe['commands'] == rename_paths(old_commands)
payload = {'recipeText': recipe_text, 'contractText': old_payload['contractText']}
start = text.splitlines(keepends=True)
replacement = 'payload=json.loads(' + repr(json.dumps(payload, ensure_ascii=False)) + ')\n'
candidate = ''.join(start[:assignment.lineno - 1]) + replacement + ''.join(start[assignment.end_lineno:])
old_recipe_sha = sha(old_payload['recipeText'].encode())
assert old_recipe_sha == 'b9a1cd379f4572e4d142a47a31a51bfceb509f687ede5856226cb01d11ce048d'
candidate = candidate.replace(old_recipe_sha, sha(recipe_text.encode()))
candidate = candidate.replace('Source is not exact clean1be', 'Source is not exact reviewed clean d6090c03')
candidate = candidate.replace('wave3-sdk-fresh-after-five-scopes-20261127.', 'wave3-sdk-pasteboard-options-20261127.')
old_capacity = ('Fresh live df after byte-verified five-scope preservation and exact retirement. Historical preproducer '
                'observed shared-filesystem difference890204160B; completed fresh producer-plus-consumer peak is unknown. '
                'Same2GiB+256MiB guard sampled every2seconds. No completed SDK result or fixed total peak is inferred.')
new_capacity = ('Fresh live df after fully verified failed-ad6 preservation and separately authorized exact retirement. '
                'The last actual preproducer shared free-space change was39718912B; completed corrected-source '
                'framework-plus-consumer peak remains unknown. Same2GiB+256MiB guard sampled every2seconds. '
                'No guaranteed capacity, cache qualification or production admission is inferred.')
assert candidate.count(old_capacity) == 1
candidate = candidate.replace(old_capacity, new_capacity)
candidate = candidate.replace("'fiveScopePreservationSHA256':'ef4ab6539a882c68df77ce8d0d349c2eeb83a2167bbb8b260cb6e2777ebc48a0'",
                              "'ad6PreservationSHA256':'b93cf1bca06300066702c0d588cd14efe166e753f11f3d4fbca18e79a0d0ac68'")
candidate = candidate.replace("'fiveScopeRetirementSHA256':'31de3721288dddaee455e8d88dd50f3a7cb5918540b19d57dc5223c4901b3f8d'",
                              "'ad6RetirementSHA256':'45556d5e873441983cc819beb46f04f5feb300f35363d5f5e1b34d5e79c13d4f'")
candidate = candidate.replace("'historicalSupervisorSHA256':'d8a6e3a9dba85e76b27fc0bf6359b4a5a344a2e435df85b1d424ae6277020844'",
                              "'historicalSupervisorSHA256':'" + SUPERVISOR_SHA + "'")
new_tree = ast.parse(candidate)
functions = ('git', 'free', 'save', 'runstep', 'restore_original_macro')
unchanged = []
for name in functions:
    a = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    b = next(n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    before = ast.get_source_segment(text, a)
    after = ast.get_source_segment(candidate, b)
    assert before == after
    unchanged.append({'name': name, 'bytes': len(before.encode()), 'sha256': sha(before.encode()), 'byte_identical': True})
assert candidate[candidate.index('steps={'): ] == text[text.index('steps={'): ]
assert '2415919104' in candidate and 'timeout=3000' in candidate and 'timeout=180' in candidate
recipe_pin = save('FRESH_RUN_COMMANDS.json', recipe_text.encode())
historical_pin = save('HISTORICAL_OBSERVED_CONTRACT.json', old_payload['contractText'].encode())
supervisor_pin = save('supervisor.py', candidate.encode())
diff = ''.join(difflib.unified_diff(text.splitlines(True), candidate.splitlines(True),
                                 fromfile='reviewed-supervisor-30cb.py', tofile='supervisor.py'))
diff_pin = save('SUPERVISOR_CONFIGURATION.diff', diff.encode())
contract = json.loads(old_payload['contractText'])
rows = contract['original_files'] + [{'path': 'Tools/PinkhaSimulatorGate/preflight.py', 'bytes': 4319,
    'sha256': '0e1c6491e8bb30d9e97cf65cf3b820a8860d0a32237676f2c3a7613668ddee66',
    'git_blob': '2628b345d5743bbe1ddc0d1afaeef9fb410f3daf', 'matches_committed_head': True}]
assert len(rows) == 17
guard_pin = save('UNCHANGED_ORIGINAL_GUARDS.json', {'source_before': OLD_SHA, 'candidate': NEW_SHA,
    'verification': 'Actual current original bytes compared to exact candidate Git blobs during read-only source review; every listed digest/size matched.',
    'original_files': rows, 'original_driver_changed': False})
proposal = {'schema': 'otzaria.corrected-source-original-sdk-proposal/1', 'status': 'REVIEW_ONLY_NOT_EXECUTED',
            'root': recipe['root'], 'source_before': OLD_SHA, 'source_after_separate_cutover': NEW_SHA,
            'existing_owned_branch_to_preserve': 'codex/anytype-wave1-sdk-admission-20261127',
            'source_correction_scope': 'Only original PasteboardHelper options: [] product hunk plus append-only upstream exception/provenance.',
            'bundle': {'path': '/Users/m1/builds/otzaria-wave3-sdk-pasteboard-fix-20261127/.git/EXACT_FIX.bundle',
                       'bytes': 6489, 'sha256': '830388532b1a69e7549a9075f0777da1253b16e95d51292c2ba1f2108cc3054d'},
            'recipe': recipe_pin, 'historical_contract': historical_pin, 'supervisor': supervisor_pin,
            'configuration_diff': diff_pin, 'original_guard_binding': guard_pin,
            'unchanged_supervisor_functions': unchanged,
            'original_execution_and_finally_tail_byte_identical': True,
            'fresh_paths': new_paths, 'new_descriptor_and_uuid_generated_only_by_original_prepare': True,
            'previous_descriptor_or_abi_receipt_reused': False,
            'continue_verified_framework_used': False, 'failed_work_or_partial_seed_used': False,
            'qualified_and_original_donor_seed_directories_observed_absent': True,
            'reserve_bytes': 2147483648, 'early_stop_margin_bytes': 268435456,
            'sample_interval_seconds': 2, 'full_framework_step_timeout_seconds': 3000,
            'original_macro_restore_timeout_seconds': 180,
            'original_macro_restore_is_separate_nonbuilding_finally_step': True,
            'historical_preproducer_shared_free_change_bytes': 39718912,
            'historical_change_is_not_an_exclusive_allocation_or_full_peak_bound': True,
            'completed_corrected_framework_and_consumer_peak_known': False,
            'live_capacity_and_exclusive_sdk_slot_required_at_launch': True,
            'current_host_capacity_not_assumed_sufficient': True,
            'native_or_app_builds_requested_by_this_proposal': 0,
            'proposed_acceptance': recipe['acceptance_requirements'],
            'source_cutover_and_execution_require_root_separate_review': True}
proposal_pin = save('PROPOSAL.json', proposal)
print(json.dumps({'proposal': proposal_pin, 'recipe': recipe_pin, 'supervisor': supervisor_pin,
                  'original_guard_count': 17, 'status': proposal['status']}))
