#!/usr/bin/env python3
"""One reviewed fast-forward of the existing SDK branch; no build or cleanup."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys

ROOT = Path('/Users/m1/builds/otzaria-wave1-sdk-20261127/source')
FIX = Path('/Users/m1/builds/otzaria-wave3-sdk-pasteboard-fix-20261127')
BUNDLE = FIX / '.git/EXACT_FIX.bundle'
BUNDLE_SHA = '830388532b1a69e7549a9075f0777da1253b16e95d51292c2ba1f2108cc3054d'
OLD = '1be970356c655bcef3688ddf1d129d5029bbc533'
NEW = 'd6090c03b9ac4e5760941e34f4c04478db4ae59f'
BRANCH = 'codex/anytype-wave1-sdk-admission-20261127'
FIX_BRANCH = 'refs/heads/codex/otzaria-wave3-sdk-pasteboard-fix-20261127'
PRESERVE_REF = 'refs/otzaria-preserved/sdk-before-pasteboard-options-20261127'
REVIEW_REF = 'refs/otzaria-reviewed/sdk-pasteboard-options-20261127'
OUT = Path(__file__).resolve().parent
GUARDS_SHA = '0094fe3ec56924a9181863c47cf6664f87c7d38797dd62155aa8c04288ff3171'
RECIPE_SHA = '677c18318f52912e188c8c48501333462932a330ef7584160adb2f8fb2566490'
PINS = {
    'Anytype/Sources/ServiceLayer/Block/Pastboard/PasteboardHelper.swift': '0eee42f7036e43d74d82088b2bd21696dc3b248f4430e4c9dfc887bbbc1a60d9',
    'docs/architecture/UPSTREAM_EXCEPTION_REGISTER.md': '5b70026206ae1f765fdd451b6a129ddf8fc571da7c3c49db63265bc87442c2b6',
    'docs/otzaria-wave3-sdk-pasteboard-compatibility-20261127/ORIGINAL_UPSTREAM.swift.gz': 'd13b83c811bbf2572bc599cba5a95b3c9a45de52b2de9bfe769a3b59f1013374',
    'docs/otzaria-wave3-sdk-pasteboard-compatibility-20261127/PRE_EDIT.json': '0244b05a42b36738d3c8e79fd3278a3daed0e37a7a164658149710617fae8424',
    'docs/otzaria-wave3-sdk-pasteboard-compatibility-20261127/README.md': '307d9321def661abffa4c133f0280200fe8f08cb43156e0f1f81e6128a87f963',
    'docs/otzaria-wave3-sdk-pasteboard-compatibility-20261127/SOURCE.patch.gz': 'd9d392f1a6f4f641e96f406f942c6117ecbdd5561da4434c0aa29587305f2499',
}


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(body):
    return hashlib.sha256(body).hexdigest()


def save(name, value):
    body = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    assert shutil.disk_usage(OUT).free - len(body) >= 2415919104
    with (OUT / name).open('xb') as f:
        f.write(body)
        f.flush()
        os.fsync(f.fileno())
    return {'path': str(OUT / name), 'bytes': len(body), 'sha256': sha(body)}


def git(root, *args):
    return subprocess.check_output(['/usr/bin/git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
                                    '-C', str(root), *args])


def state():
    return {'head': git(ROOT, 'rev-parse', 'HEAD').decode().strip(),
            'branch': git(ROOT, 'branch', '--show-current').decode().strip(),
            'tracked_status': git(ROOT, 'status', '--porcelain=v1', '--untracked-files=no').decode()}


def quiet_sdk():
    rows = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,lstart=,comm=,args='], text=True)
    found = [line for line in rows.splitlines() if str(ROOT) in line
             and any(x in line for x in ('run_framework_acceptance.py', 'prepare_local_execution.py',
                                        'xcodebuild', 'swift-frontend', 'clang'))
             and int(line.split()[0]) not in (os.getpid(), os.getppid())]
    assert not found, 'An exact-source SDK command remains active'
    return {'utc': utc(), 'active_exact_source_sdk_processes': []}


def require_no_active_hooks():
    # Do not disable existing hooks. Any installed executable hook must first
    # be reviewed separately rather than accidentally launching unknown work.
    r = subprocess.run(['/usr/bin/git', '-C', str(ROOT), 'config', '--path', '--get', 'core.hooksPath'], capture_output=True, text=True)
    assert r.returncode in (0, 1)
    if r.returncode == 0:
        value = Path(r.stdout.strip())
        directory = value if value.is_absolute() else ROOT / value
    else:
        directory = ROOT / '.git/hooks'
    active = [p.name for p in directory.iterdir() if p.is_file() and not p.name.endswith('.sample') and os.access(p, os.X_OK)] if directory.exists() else []
    assert not active, 'Existing executable Git hooks require their own source review; none are disabled'
    return {'directory': str(directory), 'active': active, 'hooks_disabled': False}


def main():
    assert sys.argv[1:] == ['--execute-reviewed-cutover']
    assert ROOT.resolve() == ROOT and FIX.resolve() == FIX
    assert state() == {'head': OLD, 'branch': BRANCH, 'tracked_status': ''}
    assert git(FIX, 'rev-parse', 'HEAD').decode().strip() == NEW
    assert git(FIX, 'status', '--porcelain=v1', '--untracked-files=no').strip() == b''
    assert git(FIX, 'rev-parse', NEW + '^').decode().strip() == OLD
    raw = BUNDLE.read_bytes()
    assert len(raw) == 6489 and sha(raw) == BUNDLE_SHA
    advertised = git(ROOT, 'bundle', 'list-heads', str(BUNDLE)).decode().strip()
    assert advertised.split() == [NEW, FIX_BRANCH]
    verified = git(ROOT, 'bundle', 'verify', str(BUNDLE))
    names = git(FIX, 'diff-tree', '--no-commit-id', '--name-only', '-r', NEW).decode().splitlines()
    assert sorted(names) == sorted(PINS)
    for name, expected in PINS.items():
        assert sha(git(FIX, 'show', NEW + ':' + name)) == expected
    product = next(n for n in PINS if n.endswith('PasteboardHelper.swift'))
    before_product = git(FIX, 'show', OLD + ':' + product)
    after_product = git(FIX, 'show', NEW + ':' + product)
    old_call = b'PropertyListSerialization.propertyList(from: data, format: nil)'
    new_call = b'PropertyListSerialization.propertyList(from: data, options: [], format: nil)'
    assert before_product.count(old_call) == 1 and after_product == before_product.replace(old_call, new_call)
    assert (ROOT / product).read_bytes() == before_product
    register = 'docs/architecture/UPSTREAM_EXCEPTION_REGISTER.md'
    previous_register = git(FIX, 'show', OLD + ':' + register)
    assert len(previous_register) == 93575
    assert git(FIX, 'show', NEW + ':' + register).startswith(previous_register)
    guards_raw = (OUT / 'UNCHANGED_ORIGINAL_GUARDS.json').read_bytes()
    assert sha(guards_raw) == GUARDS_SHA
    guards = json.loads(guards_raw)['original_files']
    assert len(guards) == 17
    for row in guards:
        b = (ROOT / row['path']).read_bytes()
        assert len(b) == row['bytes'] and sha(b) == row['sha256']
        assert b == git(FIX, 'show', NEW + ':' + row['path'])
    recipe_raw = (OUT / 'FRESH_RUN_COMMANDS.json').read_bytes()
    assert sha(recipe_raw) == RECIPE_SHA
    recipe = json.loads(recipe_raw)
    assert recipe['source_sha'] == NEW
    for value in recipe['fresh_paths'].values():
        p = Path(value)
        assert not os.path.lexists(p) and p.is_relative_to(ROOT / 'build')
    for ref in (PRESERVE_REF, REVIEW_REF):
        exists = subprocess.run(['/usr/bin/git', '-C', str(ROOT), 'show-ref', '--verify', '--quiet', ref])
        assert exists.returncode == 1, 'Planned new reference already exists'
    hooks = require_no_active_hooks()
    process_guard = quiet_sdk()
    free = shutil.disk_usage(ROOT).free
    assert free >= 2415919104 + 1048576
    pre = {'status': 'REVIEWED_EXACT_SIX_FILE_CUTOVER_PRECHECK', 'utc': utc(),
           'source_before': state(), 'candidate': NEW, 'candidate_parent': OLD,
           'exact_changed_files': names, 'file_sha256': PINS, 'bundle_sha256': BUNDLE_SHA,
           'new_preservation_ref': PRESERVE_REF, 'new_review_ref': REVIEW_REF,
           'original_guard_count': len(guards), 'fresh_output_paths_absent': recipe['fresh_paths'],
           'hook_observation': hooks, 'process_guard': process_guard,
           'free_before': free, 'source_mutated': False, 'builds_run': 0,
           'script_sha256': sha(Path(__file__).read_bytes())}
    pre_receipt = save('CUTOVER_PRECHECK.json', pre)
    steps = []
    try:
        assert state() == pre['source_before']
        quiet_sdk()
        commands = [
            ['update-ref', PRESERVE_REF, OLD, '0' * 40],
            ['fetch', '--no-tags', '--no-recurse-submodules', str(BUNDLE), FIX_BRANCH + ':' + REVIEW_REF],
            ['merge', '--ff-only', '--no-edit', REVIEW_REF],
        ]
        for number, args in enumerate(commands, 1):
            if number == 3:
                assert git(ROOT, 'rev-parse', REVIEW_REF).decode().strip() == NEW
                assert git(ROOT, 'rev-parse', REVIEW_REF + '^').decode().strip() == OLD
                assert state() == pre['source_before']
                quiet_sdk()
            run = subprocess.run(['/usr/bin/git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
                                  '-C', str(ROOT), *args], capture_output=True, timeout=60)
            save('CUTOVER_' + str(number) + '.stdout.log', run.stdout)
            save('CUTOVER_' + str(number) + '.stderr.log', run.stderr)
            steps.append({'argv': args, 'exit': run.returncode})
            assert run.returncode == 0, 'Original Git cutover step failed; no destructive rollback'
        assert state() == {'head': NEW, 'branch': BRANCH, 'tracked_status': ''}
        assert git(ROOT, 'rev-parse', PRESERVE_REF).decode().strip() == OLD
        assert (ROOT / product).read_bytes() == after_product
        for row in guards:
            assert sha((ROOT / row['path']).read_bytes()) == row['sha256']
        for value in recipe['fresh_paths'].values():
            assert not os.path.lexists(value)
        result = {**pre, 'status': 'EXACT_REVIEWED_SOURCE_FAST_FORWARDED_NO_BUILD', 'finished_at': utc(),
                  'source_mutated': True, 'source_after': state(), 'steps': steps,
                  'preserved_old_head': OLD, 'precheck_sha256': pre_receipt['sha256'],
                  'free_after': shutil.disk_usage(ROOT).free, 'builds_run': 0}
    except BaseException as error:
        result = {**pre, 'status': 'SDK_SOURCE_CUTOVER_ERROR_NO_ROLLBACK', 'finished_at': utc(),
                  'source_after': state(), 'steps': steps, 'error': repr(error),
                  'precheck_sha256': pre_receipt['sha256'], 'builds_run': 0}
        save('CUTOVER_RESULT.json', result)
        raise
    receipt = save('CUTOVER_RESULT.json', result)
    print(json.dumps({'status': result['status'], 'receipt': receipt, 'source_after': result['source_after'], 'builds_run': 0}))


if __name__ == '__main__':
    main()
