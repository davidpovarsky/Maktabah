import hashlib
import json
import pathlib
import re
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = 'f7c110da7f35a1043c1ad6da777cb89fa6d07460'
SDK = 'e00498e33f106cc43be0476ffa2e09329c8ca300'
ARCHIVE_SHA = '9ae66dcefa94594a75ed3a189a5b9ab8819821777f855021ab1c1c244e0c4c19'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (ROOT / name).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


raw = (ROOT / '14603534090.zip').read_bytes()
assert len(raw) == 216219 and digest(raw) == ARCHIVE_SHA
archive = zipfile.ZipFile(ROOT / '14603534090.zip')
assert len(archive.infolist()) == 46 and archive.testzip() is None
read = lambda name: json.loads(archive.read(name))
main = read('ui-acceptance-typecheck.json')
assert main['sourceSHA'] == SOURCE and main['status'] == 'SDK_COMPILE_PASS'
assert main['aggregateSDKStatus'] == main['appMembershipStatus'] == 'PASS'
assert main['toolbarSDKStatus'] == 'SDK_COMPILE_PASS'
assert main['includesCodeGeneration'] is True and main['nativeUITestsExecuted'] == 0
declarations = main['nativeDeclarationPreflight']
assert declarations['selectedCount'] == 92 and declarations['nativeUITestsExecuted'] == 0
assert declarations['compilerRegressionExitCode'] == 0
declared = declarations['declarations']['suites']
assert len(declared) == 92 and all(row['status'] == 'DECLARATIONS_MATCH' for row in declared)
assert len({row['selection'] for row in declared}) == 92

sdk = read('ui-acceptance-typecheck.hanlin-sdk-inputs.json')
api = json.loads((ROOT / 'hanlin-sdk-api-tree-projection.json').read_bytes())
assert sdk['sha'] == api['requestedCommit'] == SDK
assert api['recursiveTreeTruncated'] is False
expected_blobs = {entry['path']: entry['sha'] for entry in api['selectedBlobs']}
assert sdk['verified_files'] == len(sdk['git_blobs']) == len(expected_blobs) == 424
assert sdk['git_blobs'] == expected_blobs

groups = []
leaves = {}
for name, count, expected_key, passed_key in [
    ('hanlin-api12-host', 48, 'expected_tests', 'passed_tests'),
    ('hanlin-consumer-store', 11, 'expected', 'passed'),
    ('hanlin-navigation-contract', 8, 'expected', 'passed'),
]:
    report = read(f'ui-acceptance-typecheck.{name}-RESULT.json')
    text = archive.read(f'ui-acceptance-typecheck.{name}-swift-test.log').decode('utf-8')
    actual = re.findall(r"Test Case '-\[[^ ]+ ([^\]]+)\]' passed \(", text)
    failed = re.findall(r"Test Case '.*' (?:failed|skipped)", text)
    assert report['exit_code'] == 0 and report['warnings'] == 0 and not failed
    assert len(actual) == len(set(actual)) == len(report[expected_key]) == count
    assert sorted(actual) == sorted(report[expected_key]) == sorted(report[passed_key])
    assert re.search(rf'Executed {count} tests, with 0 failures', text)
    leaves[name] = actual
    groups.append({'name': name, 'count': count, 'kind': 'executed macOS XCTest leaves',
                   'failed': 0, 'skipped': 0, 'warnings': 0, 'boundary': report['boundary']})

annotation = read('ui-acceptance-typecheck.annotation-exchange-RESULT.json')
assert annotation['source_sha'] == SOURCE and annotation['compile_exit'] == annotation['execute_exit'] == 0
assert len(annotation['cases']) == 28 and len({c['name'] for c in annotation['cases']}) == 28
assert all(c['status'] == 'PASS' for c in annotation['cases'])
assert len(annotation['process_termination_checks']) == 2
assert {c['phase'] for c in annotation['process_termination_checks']} == {'before', 'after'}
assert all(c['status'] == 'PASS' and c['terminated_exit'] == c['expected_terminated_exit'] == 73
           and c['verify_exit'] == 0 for c in annotation['process_termination_checks'])
assert annotation['source_files_before'] == annotation['source_files_after']
assert annotation['source_bytes_unchanged_during_run'] and annotation['cloudkit_queue_bytes_unchanged']
assert annotation['live_capability_enabled'] is False
leaves['annotation-exchange'] = [c['name'] for c in annotation['cases']]
groups.append({'name': 'annotation-exchange', 'count': 28, 'kind': 'real SQLite component cases',
               'failed': 0, 'additionalWALProcessExitAndReopenControls': 2, 'capabilityEnabled': False,
               'annotationRepositoryRuntime': False, 'CloudKitRuntime': False, 'AnytypeRuntime': False})

for name, count in [('book-page-cache', 26), ('inspector-owner', 17)]:
    report = read(f'ui-acceptance-typecheck.{name}-RESULT.json')
    assert report['compile_exit'] == report['test_exit'] == 0 and report['status'] == 'PASS'
    assert len(report['passed']) == len(set(report['passed'])) == count and report['failed'] == []
    leaves[name] = report['passed']
    groups.append({'name': name, 'count': count, 'kind': 'source-bound macOS portable cases', 'failed': 0})

hebrew = read('ui-acceptance-typecheck.hebrew-ranges-RESULT.json')
assert hebrew['compile_exit'] == hebrew['test_exit'] == 0
assert hebrew['actual']['tests'] == hebrew['actual']['passed'] == 15 and hebrew['actual']['failed'] == 0
assert len(hebrew['actual']['cases']) == 15 and all(c['passed'] for c in hebrew['actual']['cases'])
leaves['hebrew-ranges'] = [c['name'] for c in hebrew['actual']['cases']]
groups.append({'name': 'hebrew-ranges', 'count': 15, 'kind': 'real Swift/Foundation source-range cases', 'failed': 0})

sqlite = read('ui-acceptance-typecheck.sqlite-RESULT.json')
assert sqlite['source_sha'] == SOURCE and sqlite['compile_exit'] == sqlite['execute_exit'] == 0
assert sqlite['sqlite_is_real'] and sqlite['real_source_readonly_count'] == 0
cases = sqlite['actual_sqlite']['cases']
assert len(cases) == 25 and len({c['name'] for c in cases}) == 25 and all(c['passed'] for c in cases)
assert 'ACTUAL_SQLITE 25 cases; 0 failures; version 3.54.0' in archive.read('ui-acceptance-typecheck.sqlite-tests.log').decode()
leaves['sqlite'] = [c['name'] for c in cases]
groups.append({'name': 'sqlite', 'count': 25, 'kind': 'actual SQLite 3.54.0 source cases', 'failed': 0,
               'fullSourceDatabaseCountExecuted': 0, 'decompressorExecuted': False})

workspace = archive.read('workspace-test-results.log').decode('utf-8')
assert workspace.strip() == 'PASS: 89 workspace persistence/migration/rollback/scene/semantic-location checks'
groups.append({'name': 'workspace', 'count': 89, 'kind': 'portable assertions; not XCTest case count'})

references = {}
def add(path, value, source):
    if not path.startswith(('Source/', 'Tests/', 'Scripts/', 'tools/', 'Maktabah-iOSUITests/')):
        return
    assert re.fullmatch('[a-f0-9]{64}', value), (path, value)
    if path in references:
        assert references[path]['sha256'] == value, path
        references[path]['evidence'].append(source)
    else:
        references[path] = {'sha256': value, 'evidence': [source]}

def source_walk(value, context):
    if not isinstance(value, dict):
        return
    for key in ['sourceHashes', 'source_files', 'source_files_before', 'source_files_after']:
        for path, item in value.get(key, {}).items():
            if isinstance(item, str):
                add(path, item, context + ':' + key)
    if 'source_path' in value and 'source_sha256' in value:
        add(value['source_path'], value['source_sha256'], context)
    for key, child in value.items():
        if isinstance(child, dict):
            source_walk(child, context + ':' + key)

for name in archive.namelist():
    if not name.endswith('.json'):
        continue
    obj = read(name)
    source_walk(obj, name)
    if name.endswith('-inputs.json'):
        for path, item in obj.items():
            if isinstance(item, dict) and isinstance(item.get('sha256'), str):
                original = item.get('source', path)
                if not original.startswith(SDK + ':') and 'source_commit' not in item:
                    add(original, item['sha256'], name + ':' + path)

write('SOURCE_HASH_REFERENCES.json', references)
write('NAMED_EXECUTED_CASES.json', leaves)
result = {
    'status': 'AUTHENTIC_ARTIFACT_AUDITED', 'run': 44676266509, 'artifact': 14603534090,
    'checkoutSource': SOURCE, 'applicationSource': '34c7ab5ae026a0d3d08f02a2c97ddf4b38e1a56c',
    'zipBytes': len(raw), 'zipSHA256': ARCHIVE_SHA, 'all46ZipCRCsVerified': True,
    'toolchain': {'xcode': main['xcode'], 'swift': main['swift'], 'sdk': main['sdk'], 'target': main['target']},
    'sdkCompilation': {'uiAcceptanceCodeGeneration': main['status'], 'nativeRoutingHost': main['nativeRoutingHost']['status'],
                       'nativeSidebarSearch': main['sidebarNativeSearch']['status'], 'sidebarSplitAdapter': main['sidebarAdapterSDK']['status'],
                       'readerTextVisibility': main['nativeReaderTextVisibilitySDK']['status'], 'toolbar': main['toolbarSDKStatus'],
                       'originalAppMembership': main['appMembershipStatus'], 'reportedMainWarningCount': main['warningCount']},
    'sourceScopesStillRequiringFullAppBuild': {key: main[key] for key in ['appComposedSidebar', 'appComposedGlobalSearchField']},
    'nativeDeclarationsChecked': 92, 'nativeUICasesExecuted': 0, 'groups': groups,
    'originalSDK': {'repository': sdk['repository'], 'commit': SDK, 'all424ReportedBlobsMatchIndependentGitHubTree': True,
                    'packageManifestSHA256': sdk['manifest_sha256']},
    'applicationSourceHashReferences': len(references), 'sourceHashVerificationAgainstGit': 'NEXT_STEP',
    'annotationSourceBeforeAfterUnchanged': True,
    'boundaries': ['Registry OFF in this early source; candidate ON requires its own validation',
                   'No complete app build or simulator launch in this job', 'No Native UI or physical device acceptance',
                   'No d5 occurrence runtime or new full-v32 acceptance probe executed here',
                   'Later background AppIntent, TOC acknowledgement, qualified registry and full-v32 probe changes receive no credit from this run'],
}
write('ARTIFACT_REVIEW.json', result)
print(json.dumps({'groups': groups, 'sourceHashReferences': len(references), 'SDKBlobs': len(expected_blobs),
                  'artifactReviewSHA256': digest((ROOT / 'ARTIFACT_REVIEW.json').read_bytes())}, ensure_ascii=False, indent=2))
