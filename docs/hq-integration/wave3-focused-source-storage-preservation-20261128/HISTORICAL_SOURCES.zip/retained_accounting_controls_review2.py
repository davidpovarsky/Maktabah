"""NEW focused accounting controls over only the exclusive synthetic fixture.

No original retained scope, Native116 tree, authenticated API, production
prepare/publish path, or SDK is opened. Each test imports the exact controller
under a non-main name, then explicitly substitutes closed fixture paths/content
pins. All accounting and no-follow functions themselves remain verbatim.
"""
if not __debug__:
    raise RuntimeError('Optimized controls refused')

import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time
import types
import unittest

CONTROL_ROOT = Path('/home/ubuntu/otzaria-wave3-native116-v3-focused-controls-20261128')
FLOOR = 1593835520
CAP = 4*1024**2
PINS = {
    'oracle_controller.py': (60775, 'd1ee5da71d8ffdbdc650b8a32b53b20179e32557daba904131eab8d2ecb85588'),
    'stream_format.py': (26543, 'c9496f69ebb2992732c5144697c5e6ff44e39724ea5045a733815310527cd0a2'),
    'mac_producer.py': (22948, '4e98ae9088ef26d4df8da3c8317539b9e13ffceefbb776093c8636b64c1b2ce4'),
    'reviewed_runtime.py': (8447, 'ac8ed682ade9d74f0b74b3bf90e3dafdc38e144a4b4048e6b5b115d986648f80'),
}
SOURCES = {}
DEADLINE = None
EXPECTED_PARENT = None
COUNTERFACTUAL = False
OBSERVED = []

def demand(value, message):
    if not value:
        raise RuntimeError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)+'\n').encode('ascii')

def scope_allocation():
    """Every directory and leaf in this one closed scope; no symlink traversal."""
    demand(CONTROL_ROOT.resolve(strict=True)==CONTROL_ROOT, 'Exact fixed controls root')
    root = CONTROL_ROOT.lstat()
    demand(stat.S_ISDIR(root.st_mode) and root.st_dev==os.stat('/').st_dev, 'Controls on rootfs')
    total = root.st_blocks*512
    pending = [(CONTROL_ROOT, 0)]; count = 1
    while pending:
        directory, depth = pending.pop()
        demand(depth <= 5, 'Closed fixture maximum depth')
        for entry in os.scandir(directory):
            count += 1; demand(count <= 1200, 'Closed fixture maximum entries')
            s = entry.stat(follow_symlinks=False)
            demand(s.st_dev==root.st_dev, 'No cross-device control entry')
            total += s.st_blocks*512
            if stat.S_ISDIR(s.st_mode):
                pending.append((Path(entry.path),depth+1))
            else:
                demand(stat.S_ISREG(s.st_mode) or stat.S_ISLNK(s.st_mode),
                       'Only explicitly tested ordinary fixture files/links')
    return total

def guard(addition=0):
    demand(time.monotonic()<DEADLINE and os.getppid()==EXPECTED_PARENT, 'Owned controls lifetime')
    v=os.statvfs(CONTROL_ROOT)
    demand(v.f_bavail*v.f_frsize >= FLOOR+CAP, 'Root floor plus complete focused reserve')
    demand(scope_allocation()+addition<=CAP, 'Focused allocated bytes including directories')

def mkdir(path):
    demand(path.is_relative_to(CONTROL_ROOT), 'Only owned focused-control descendants')
    guard(8192)
    os.mkdir(path,0o700)
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)

def write(path, body, replace=False):
    demand(path.is_relative_to(CONTROL_ROOT), 'Only owned focused-control leaves')
    guard(len(body)+8192)
    flags=os.O_WRONLY|os.O_NOFOLLOW|(os.O_TRUNC if replace else os.O_CREAT|os.O_EXCL)
    fd=os.open(path,flags,0o600)
    try:
        demand(stat.S_ISREG(os.fstat(fd).st_mode) and os.fstat(fd).st_nlink==1,
               'Only single-link owned fixture write')
        remaining=memoryview(body)
        while remaining:
            n=os.write(fd,remaining); demand(n>0,'Short fixture write'); remaining=remaining[n:]
        os.fsync(fd)
    finally: os.close(fd)
    guard()

def load_controller():
    raw=SOURCES['oracle_controller.py']
    if COUNTERFACTUAL:
        line=b'              (PRIOR_V3_PROPOSAL, set(PRIOR_V3_PROPOSAL_FILES), PRIOR_V3_PROPOSAL_FILES),\n'
        demand(raw.count(line)==1,'Exactly one explicit counterfactual scope removal')
        raw=raw.replace(line,b'',1)
    module=types.ModuleType('native116_accounting_fixture')
    module.__file__='<pinned-accounting-controller>'
    exec(compile(raw,module.__file__,'exec'),module.__dict__)
    demand(module.CONTROL_CAP==48*1024**2 and module.FOCUSED_CONTROL_RESERVE==CAP
           and module.ROOT_FLOOR==FLOOR,'Unchanged controller caps')
    return module, sha(raw)

class Family:
    """70 small synthetic leaves, nine original inventory scopes, real stat/FDs."""
    def __init__(self, label, existing=False):
        self.c, self.loaded_sha=load_controller()
        self.root=CONTROL_ROOT/'fixtures'/label
        self.existing=existing
        self.records={}
        self.scope_pins={}
        self.created_dirs=[]
        self.bodies={}
        if not self.existing:
            if not (CONTROL_ROOT/'fixtures').exists(): mkdir(CONTROL_ROOT/'fixtures')
            mkdir(self.root)
        else:
            demand(self.root.is_dir() and self.root.resolve()==self.root,'Exact retained synthetic family')
        c=self.c
        original_names={key:list(getattr(c,key)) for key in (
            'PRIOR_TOOL_FILES','PRIOR_JOURNAL_FILES','PRIOR_V2_TOOL_FILES',
            'PRIOR_V2_JOURNAL_FILES','PRIOR_V3_PROPOSAL_FILES','PRIOR_V3_REVIEW2_PROPOSAL_FILES')}
        mappings={
            'PRIOR_BASE':self.root/'v1-control',
            'PRIOR_TOOLS':self.root/'v1-tools',
            'PRIOR_V2_BASE':self.root/'v2-control',
            'PRIOR_V2_TOOLS':self.root/'v2-tools',
            'PRIOR_V3_PROPOSAL':self.root/'proposal-first',
            'PRIOR_V3_REVIEW2_PROPOSAL':self.root/'proposal-review2',
            'PRIOR_PROPOSAL':self.root/'proposal-review3',
            'BASE':self.root/'current-base',
        }
        for k,v in mappings.items(): setattr(c,k,v)
        for key in ('PRIOR_BASE','PRIOR_TOOLS','PRIOR_V2_BASE','PRIOR_V2_TOOLS',
                    'PRIOR_V3_PROPOSAL','PRIOR_V3_REVIEW2_PROPOSAL','PRIOR_PROPOSAL'):
            self.directory(getattr(c,key))
        self.directory(c.PRIOR_BASE/'prepare')
        self.directory(c.PRIOR_V2_BASE/'prepare')
        closures=(
            (c.PRIOR_TOOLS,'PRIOR_TOOL_FILES'),
            (c.PRIOR_BASE/'prepare','PRIOR_JOURNAL_FILES'),
            (c.PRIOR_V2_TOOLS,'PRIOR_V2_TOOL_FILES'),
            (c.PRIOR_V2_BASE/'prepare','PRIOR_V2_JOURNAL_FILES'),
            (c.PRIOR_V3_PROPOSAL,'PRIOR_V3_PROPOSAL_FILES'),
            (c.PRIOR_V3_REVIEW2_PROPOSAL,'PRIOR_V3_REVIEW2_PROPOSAL_FILES'),
        )
        for directory,key in closures:
            pins={}
            for name in original_names[key]:
                body=('Synthetic owned content: '+directory.name+'/'+name+'\n').encode('ascii')
                self.leaf(directory/name,body)
                pins[name]={'bytes':len(body),'sha256':sha(body)}
            setattr(c,key,pins)
            self.scope_pins[directory]=pins
        for name in c.PROPOSAL_FILE_NAMES:
            self.leaf(c.PRIOR_PROPOSAL/name,('Current synthetic proposal: '+name+'\n').encode('ascii'))
        self.current_manifest(c.PROPOSAL_CAP, initial=True)
        c.SOURCE_BYTES=dict(SOURCES)
        c.PRIOR_OWNED=None
        self.inventory_scopes=[
            c.PRIOR_BASE,c.PRIOR_TOOLS,c.PRIOR_BASE/'prepare',
            c.PRIOR_V2_BASE,c.PRIOR_V2_TOOLS,c.PRIOR_V2_BASE/'prepare',
            c.PRIOR_V3_PROPOSAL,c.PRIOR_V3_REVIEW2_PROPOSAL,c.PRIOR_PROPOSAL]
        demand(len(self.bodies)==70,'Fixture exactly represents 31 old leaves plus 3x13 proposals')
        demand(len(set(self.inventory_scopes))==9,'Exact unique synthetic inventory directories')
    def directory(self,path):
        if not self.existing: mkdir(path)
        else: demand(path.is_dir() and path.resolve()==path,'Retained synthetic directory')
        self.created_dirs.append(path)
    def leaf(self,path,body):
        if self.existing:
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
            try:
                s=os.fstat(fd)
                demand(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size==len(body),'Retained synthetic file identity')
                actual=os.read(fd,len(body)+1)
                demand(actual==body,'Exact retained synthetic content')
            finally: os.close(fd)
        else:
            write(path,body)
        self.bodies[path]=body
    def current_manifest(self,cap,initial=False):
        c=self.c
        pins={name:{'bytes':len(self.bodies[c.PRIOR_PROPOSAL/name]),
                    'sha256':sha(self.bodies[c.PRIOR_PROPOSAL/name])} for name in c.PROPOSAL_FILE_NAMES}
        value={'schema':'otzaria.native116-v3-proposal-pin/1','proposalRoot':str(c.PRIOR_PROPOSAL),
               'files':pins,'proposalMaxBytes':cap}
        pinraw=c.canonical(value)
        seal={'schema':'synthetic-accounting-boundary-only','proposalPinSHA256':sha(pinraw)}
        sealraw=c.canonical(seal)
        for name,body in (('PROPOSAL_PIN.json',pinraw),('SOURCE_SEAL.json',sealraw)):
            path=c.PRIOR_PROPOSAL/name
            if initial:
                self.leaf(path,body)
            else:
                write(path,body,replace=True); self.bodies[path]=body
        c.SEAL=seal; c.SEAL_RAW=sealraw; c.SEAL_SHA=sha(sealraw)
    def expected_blocks(self):
        return sum(p.lstat().st_blocks*512 for p in self.inventory_scopes)+sum(p.lstat().st_blocks*512 for p in self.bodies)
    def summary(self):
        return {'root':str(self.root),'leaves':len(self.bodies),'inventoryDirectories':len(self.inventory_scopes),
                'fixturePinsBoundary':'Synthetic exact size/SHA maps; not historical source metadata replay',
                'controllerLoadedSHA256':self.loaded_sha}

class Native116RetainedAccountingFocus(unittest.TestCase):
    def setUp(self):
        guard()
        label=self._testMethodName.removeprefix('test_')
        if COUNTERFACTUAL:
            demand(label=='all_three_proposals_and_both_failures_counted','Single closed counterfactual method')
        self.family=Family(label,existing=COUNTERFACTUAL)
        self.c=self.family.c
        OBSERVED.append(self.family.summary())
    def test_all_three_proposals_and_both_failures_counted(self):
        inventory,contents=self.c.prior_owned_inventory(True)
        self.assertEqual(len(inventory['files']),70)
        self.assertEqual(len(inventory['directories']),9)
        self.assertEqual(set(inventory['files']),set(map(str,self.family.bodies)))
        self.assertEqual(set(contents),set(map(str,self.family.bodies)))
        self.assertEqual(inventory['allocatedBytes'],self.family.expected_blocks())
        self.c.capture_prior_owned()
        self.assertEqual(self.c.prior_owned_allocated_bytes(),self.family.expected_blocks())
    def test_representative_content_pin_from_each_scope_is_enforced(self):
        scopes=list(self.family.scope_pins)
        scopes.append(self.c.PRIOR_PROPOSAL)
        for directory in scopes:
            with self.subTest(scope=directory.name):
                self.c.prior_owned_inventory(True)
                candidates=[p for p in self.family.bodies if p.parent==directory and p.name not in ('PROPOSAL_PIN.json','SOURCE_SEAL.json')]
                path=sorted(candidates)[0]
                before=self.family.bodies[path]
                after=bytes([before[0]^1])+before[1:]
                write(path,after,replace=True)
                with self.assertRaisesRegex(RuntimeError,'Pinned prior evidence bytes changed'):
                    self.c.prior_owned_inventory(True)
                write(path,before,replace=True)
                self.c.prior_owned_inventory(True)
    def test_same_bytes_replacement_revokes_captured_identity(self):
        self.c.capture_prior_owned()
        path=self.c.PRIOR_V3_REVIEW2_PROPOSAL/'stream_format.py'
        old=path.lstat()
        replacement=self.family.root/'replacement'
        write(replacement,self.family.bodies[path])
        guard(); os.replace(replacement,path); guard()
        self.assertNotEqual(path.lstat().st_ino,old.st_ino)
        with self.assertRaisesRegex(RuntimeError,'Pinned prior evidence/allocation changed'):
            self.c.prior_owned_allocated_bytes()
    def test_unexpected_leaf_is_refused(self):
        self.c.capture_prior_owned()
        write(self.c.PRIOR_V2_TOOLS/'unexpected',b'owned negative fixture\n')
        with self.assertRaisesRegex(RuntimeError,'Exact retained prior scope changed'):
            self.c.prior_owned_allocated_bytes()
    def test_symlink_leaf_is_refused_without_following(self):
        path=self.c.PRIOR_V3_PROPOSAL/'stream_format.py'
        target=self.family.root/'symlink-target'
        write(target,self.family.bodies[path])
        guard(); os.unlink(path); os.symlink('../symlink-target',path); guard()
        with self.assertRaisesRegex(RuntimeError,'single-link regular leaf'):
            self.c.prior_owned_inventory(True)
    def test_hardlinked_leaf_is_refused(self):
        path=self.c.PRIOR_V3_PROPOSAL/'stream_format.py'
        alias=self.family.root/'hardlink-alias'
        guard(8192); os.link(path,alias,follow_symlinks=False); guard()
        self.assertEqual(path.lstat().st_ino,alias.lstat().st_ino)
        with self.assertRaisesRegex(RuntimeError,'single-link regular leaf'):
            self.c.prior_owned_inventory(True)
    def test_second_capture_cannot_rearm(self):
        self.c.capture_prior_owned()
        before=self.c.PRIOR_OWNED
        with self.assertRaisesRegex(RuntimeError,'cannot be refreshed'):
            self.c.capture_prior_owned()
        self.assertIs(self.c.PRIOR_OWNED,before)
    def test_old_proposal_seals_are_independent_of_current_seal(self):
        self.c.prior_owned_inventory(True)
        for root,key in ((self.c.PRIOR_V3_PROPOSAL,'PRIOR_V3_PROPOSAL_FILES'),
                         (self.c.PRIOR_V3_REVIEW2_PROPOSAL,'PRIOR_V3_REVIEW2_PROPOSAL_FILES')):
            with self.subTest(scope=root.name):
                path=root/'SOURCE_SEAL.json'
                original=self.family.bodies[path]
                self.assertNotEqual(getattr(self.c,key)['SOURCE_SEAL.json']['sha256'],self.c.SEAL_SHA)
                write(path,self.c.SEAL_RAW,replace=True)
                with self.assertRaises(RuntimeError):
                    self.c.prior_owned_inventory(True)
                write(path,original,replace=True)
                self.c.prior_owned_inventory(True)
    def test_proposal_logical_and_allocated_bounds_are_separate(self):
        pins=self.c.proposal_retained_pins()
        logical=sum(p['bytes'] for p in pins.values())
        allocated=self.c.PRIOR_PROPOSAL.lstat().st_blocks*512+sum(
            (self.c.PRIOR_PROPOSAL/name).lstat().st_blocks*512 for name in pins)
        self.assertLess(logical,allocated)
        intermediate=(logical+allocated)//2
        self.c.PROPOSAL_CAP=intermediate
        self.family.current_manifest(intermediate)
        self.c.proposal_retained_pins()
        with self.assertRaisesRegex(RuntimeError,'Retained proposal allocated-byte cap'):
            self.c.prior_owned_inventory(True)
        tiny=max(len(self.family.bodies[self.c.PRIOR_PROPOSAL/n]) for n in self.c.PROPOSAL_FILE_NAMES)+1
        self.c.PROPOSAL_CAP=tiny
        self.family.current_manifest(tiny)
        with self.assertRaisesRegex(RuntimeError,'Proposal logical size cap'):
            self.c.proposal_retained_pins()
    def test_unconditional_focused_reserve_before_and_after_phases(self):
        self.c.capture_prior_owned()
        expected=self.family.expected_blocks()+sum(map(len,SOURCES.values()))+len(self.c.SEAL_RAW)+CAP
        self.assertFalse(self.c.BASE.exists())
        self.assertEqual(self.c.aggregate_bytes(),expected)
        mkdir(self.c.BASE); mkdir(self.c.BASE/'prepare')
        payload=self.c.BASE/'prepare'/'fixture.log'
        write(payload,b'owned focused log\n')
        self.assertEqual(self.c.aggregate_bytes(),expected+payload.lstat().st_blocks*512)
        self.assertEqual(self.c.FOCUSED_CONTROL_RESERVE,CAP)
    def test_closed_phase_membership_and_existing_base_refusal(self):
        self.c.capture_prior_owned()
        mkdir(self.c.BASE)
        # The actual unchanged prepare admission executes before its mkdir.
        # This case naturally requires its original ROOT_FLOOR+CONTROL_CAP free.
        with self.assertRaises(FileExistsError):
            self.c.prepare()
        mkdir(self.c.BASE/'focused-controls')
        with self.assertRaisesRegex(RuntimeError,'Unknown control child'):
            self.c.aggregate_bytes()

def failure_record(error):
    frames=[]
    tb=error[2]
    while tb is not None:
        frames.append({'file':tb.tb_frame.f_code.co_filename,'function':tb.tb_frame.f_code.co_name,'line':tb.tb_lineno})
        tb=tb.tb_next
    text=str(error[1])
    return {'errorType':error[0].__name__,'message':text[:2048],
            'messageTruncated':len(text)>2048,'frames':frames}


def emit_checkpoint(kind,record,completed=0):
    event={'kind':kind,'name':record['name'],'status':record.get('status','ACTIVE'),
           'completedMethodCount':completed,
           'subcaseFailureCount':len(record.get('subcaseFailures',[])),
           'errorType':record.get('errorType')}
    raw=json.dumps(event,separators=(',',':'),ensure_ascii=True)
    demand(len(raw.encode('ascii'))<=384,'Bounded method checkpoint')
    sys.stdout.write(raw+'\n'); sys.stdout.flush()

class EvidenceResult(unittest.TestResult):
    def __init__(self):
        super().__init__(); self.records=[]; self.active=None
    def startTest(self,test):
        self.active={'name':test.id(),'status':'ACTIVE','subcaseFailures':[]}
        emit_checkpoint('METHOD_STARTED',self.active)
        guard(); super().startTest(test)
    def addSuccess(self,test):
        self.active['status']='PASS'
    def addFailure(self,test,error):
        self.failures.append((test,'recorded')); self.active.update(status='FAIL',**failure_record(error))
    def addError(self,test,error):
        self.errors.append((test,'recorded')); self.active.update(status='ERROR',**failure_record(error))
    def addSubTest(self,test,subtest,error):
        if error is None: return
        status='FAIL' if issubclass(error[0],test.failureException) else 'ERROR'
        (self.failures if status=='FAIL' else self.errors).append((subtest,'recorded'))
        self.active['status']=status
        self.active['subcaseFailures'].append({'name':str(subtest),**failure_record(error)})
    def stopTest(self,test):
        self.active.setdefault('status','ERROR')
        self.records.append(self.active)
        emit_checkpoint('METHOD_COMPLETED',self.active,len(self.records))
        self.active=None
        super().stopTest(test); guard()

def bounded_report(value):
    """Retain every method status/count even when diagnostic text is reduced."""
    raw=json.dumps(value,separators=(',',':'),ensure_ascii=True).encode('ascii')
    if len(raw)<=48000:
        return value
    value['diagnosticsReducedFor48KBFinalOutput']=True
    value['diagnosticBytesBeforeReduction']=len(raw)
    def small(error):
        if not isinstance(error,dict): return error
        out={k:v for k,v in error.items() if k not in ('frames','message','subcaseFailures')}
        if 'message' in error:
            out['message']=error['message'][:160]
            out['messageTruncated']=True
        if 'frames' in error:
            out['frames']=error['frames'][-3:]
            out['framesTruncated']=len(error['frames'])>3
        if 'subcaseFailures' in error:
            out['subcaseFailures']=[small(x) for x in error['subcaseFailures']]
        return out
    value['methodRecords']=[small(r) for r in value.get('methodRecords',[])]
    if value.get('activeRecord') is not None: value['activeRecord']=small(value['activeRecord'])
    if value.get('terminalAbort') is not None: value['terminalAbort']=small(value['terminalAbort'])
    raw=json.dumps(value,separators=(',',':'),ensure_ascii=True).encode('ascii')
    if len(raw)>48000:
        # Fixed planned method identities/counts are kept; no oversized report
        # may be promoted to success by throwing away a failed method.
        value['successful']=False
        value['status']='REPORT_DIAGNOSTICS_OVERSIZE'
        value['methodRecords']=[{'name':r['name'],'status':r.get('status','ERROR'),
                                 'errorType':r.get('errorType'),
                                 'subcaseFailureCount':len(r.get('subcaseFailures',[]))}
                                for r in value['methodRecords']]
        value['terminalAbort']={'stage':'REPORT_SERIALIZATION','errorType':'BoundedReportRefusal'}
        value['diagnosticsOmittedForLimit']=True
    demand(len(json.dumps(value,separators=(',',':'),ensure_ascii=True).encode('ascii'))<=48000,
           'Fixed bounded method report')
    return value

def partial_state(result,names,abort):
    records=[] if result is None else result.records
    completed={r['name'].rsplit('.',1)[-1] for r in records}
    active=None if result is None or result.active is None else dict(result.active)
    if active is not None:
        active['status']=('COMPLETED_REPORTING_INTERRUPTED' if active['name'].rsplit('.',1)[-1] in completed
                          else 'INCOMPLETE_TERMINAL_ABORT')
    unfinished=[n for n in names if n not in completed]
    return {'methodRecords':records,'completedMethodCount':len(records),
            'activeRecord':active,'unfinishedMethods':unfinished,
            'unfinishedMethodCount':len(unfinished),'terminalAbort':abort,
            'testsRun':0 if result is None else result.testsRun,
            'failures':0 if result is None else len(result.failures),
            'errors':0 if result is None else len(result.errors)}

def reporting_reservation(value,mode):
    """Parent has allocated these exact raw/terminal slots before fixtures run."""
    phase='accounting-candidate' if mode=='candidate' else 'accounting-omit-first'
    demand(type(value) is dict and set(value)=={'phase','slots'} and value['phase']==phase,
           'Exact reporting reservation envelope')
    expected={
        str(CONTROL_ROOT/'runs'/phase/'worker.stdout'):65536,
        str(CONTROL_ROOT/'runs'/phase/'worker.stderr'):65536,
        str(CONTROL_ROOT/'runs'/phase/'worker.TERMINAL.json'):16384,
        str(CONTROL_ROOT/'runs'/phase/'DISPATCH_RESULT.json'):16384,
        str(CONTROL_ROOT/'CONTROLS_CLOSED.json'):65536,
    }
    demand(type(value['slots']) is list and len(value['slots'])==len(expected),
           'All exact reporting slots required')
    seen=set()
    for row in value['slots']:
        demand(type(row) is dict and set(row)=={'path','device','inode','reservedBytes'},
               'Typed reporting slot identity')
        path=Path(row['path'])
        demand(str(path) in expected and str(path) not in seen
               and row['reservedBytes']==expected[str(path)],'Closed reporting slot path/size')
        demand(path.resolve(strict=True)==path,'No reporting slot symlink')
        s=path.lstat()
        demand(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_dev==row['device']
               and s.st_ino==row['inode'] and s.st_size==row['reservedBytes']
               and s.st_blocks*512>=row['reservedBytes'],'Full allocated reporting slot')
        seen.add(str(path))
    demand(seen==set(expected),'Exact complete reporting reservation')
    return {'phase':phase,'slotsVerified':len(seen),'inSame4MiBScope':True}


def run(envelope):
    global SOURCES,DEADLINE,EXPECTED_PARENT,COUNTERFACTUAL
    names=unittest.defaultTestLoader.getTestCaseNames(Native116RetainedAccountingFocus)
    mode=envelope.get('mode') if type(envelope) is dict else None
    if mode=='omit_first_proposal': names=['test_all_three_proposals_and_both_failures_counted']
    result=None; abort=None; stage='ADMISSION'; final_allocated=None; reservation=None
    try:
        demand(sys.flags.isolated==1 and sys.dont_write_bytecode,'Use python3 -I -B')
        demand(sys.platform=='linux','Real rootfs fixture accounting runs on Oracle')
        demand(set(envelope)=={'mode','sources','reportingReservation'} and mode in ('candidate','omit_first_proposal'),
               'Closed focused-accounting mode')
        COUNTERFACTUAL=mode=='omit_first_proposal'
        demand(set(envelope['sources'])==set(PINS),'Exact four source inputs')
        stage='SOURCE_ENVELOPE'
        for name,(length,pin) in PINS.items():
            raw=base64.b64decode(envelope['sources'][name],validate=True)
            demand(len(raw)==length and sha(raw)==pin,'Exact reviewed source bytes')
            SOURCES[name]=raw
        EXPECTED_PARENT=os.getppid(); DEADLINE=time.monotonic()+180
        guard()
        stage='REPORTING_RESERVATION'
        reservation=reporting_reservation(envelope['reportingReservation'],mode)
        stage='SUITE_BUILD'
        all_names=unittest.defaultTestLoader.getTestCaseNames(Native116RetainedAccountingFocus)
        demand(len(all_names)==11,'Exactly eleven new accounting methods')
        suite=unittest.TestSuite(Native116RetainedAccountingFocus(n) for n in names)
        result=EvidenceResult()
        stage='SUITE_RUN'
        suite.run(result)
        stage='POST_SUITE_GUARD'
        guard(); final_allocated=scope_allocation()
        stage='RESULT_BINDING'
        completed=[r['name'].rsplit('.',1)[-1] for r in result.records]
        demand(result.testsRun==len(names) and sorted(completed)==sorted(names),
               'Complete exact named control method membership')
    except BaseException as error:
        abort={'stage':stage,'beforeResultCreation':result is None,
               **failure_record((type(error),error,error.__traceback__))}
    partial=partial_state(result,names,abort)
    success=(abort is None and result is not None and result.wasSuccessful()
             and partial['completedMethodCount']==len(names) and not partial['unfinishedMethods'])
    value={'schema':'otzaria.native116-retained-accounting-focused-result/2',
           'suite':'Native116RetainedAccountingFocus','mode':mode,
           'status':'TERMINAL_ABORT' if abort is not None else ('PASS' if success else 'TEST_FAILURE'),
           'runtime':{'python':sys.version,'executable':sys.executable,'platform':sys.platform},
           'sourcePins':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in SOURCES.items()},
           'expectedMethods':names,'expectedMethodCount':len(names),'successful':success,
           'fixtureFamilies':OBSERVED,'controlsAllocatedBytes':final_allocated,
           'reportingReservation':reservation,
           'focusedReserveBytes':CAP,'allOriginalRetainedScopesReadOrModified':False,
           'productionPreparePublishInvoked':False,'syntheticExistingBasePrepareOnly':not COUNTERFACTUAL,
           'realNativeEnumeration':0,'authenticatedActions':0,'legacy25Rerun':False,
           'physicalAccountingQualification':'Production current-tool/seal logical charging remains unchanged; this suite does not prove complete physical allocation accounting.',
           **partial}
    return bounded_report(value)
