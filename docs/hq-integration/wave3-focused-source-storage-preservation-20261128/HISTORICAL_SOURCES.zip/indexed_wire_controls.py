"""NEW named indexed-wire controls. No automatic execution or Native116 access.

The existing producer is imported only by run(), on the actual admitted Darwin
runtime. That import qualifies one fixed SDK header; it does not call main(),
open_root(), capture(), or enumerate the real source. The enumeration control
uses the exact original function code with an explicit synthetic OS boundary.
"""
if not __debug__:
    raise RuntimeError('Optimized controls refused')

import base64
import binascii
import contextlib
import copy
import gzip
import hashlib
import io
import json
import os
import platform
import stat
import sys
import time
import traceback
import types
import unittest

PINS = {
    'candidate': {
        'stream_format.py': (26543, 'c9496f69ebb2992732c5144697c5e6ff44e39724ea5045a733815310527cd0a2'),
        'mac_producer.py': (22948, '4e98ae9088ef26d4df8da3c8317539b9e13ffceefbb776093c8636b64c1b2ce4'),
    },
    'review_findings_baseline': {
        'stream_format.py': (25603, '9a592f2bc2e3eb0db9ba32fb7c9c5b34e658c73ed7239e0f468926b5bf34b6b9'),
        'mac_producer.py': (22935, '3c7422905a4e48f0ec68005a580a6c7b1696e19c12b8e115a5f9b5a9b196f488'),
    },
}
HEADER = '/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.0.sdk/usr/include/sys/fcntl.h'
F = P = None
DEADLINE = None
EXPECTED_PARENT = None
BOUNDARY_EVENTS = []

def demand(value, message):
    if not value:
        raise RuntimeError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def guard():
    demand(time.monotonic() < DEADLINE, 'Focused-control deadline')
    demand(os.getppid() == EXPECTED_PARENT, 'Focused-control parent detached')
    v = os.statvfs('/System/Volumes/Data')
    demand(v.f_bavail * v.f_frsize >= 2415919104, 'Original Mac live floor')

def compressed(raw):
    out = io.BytesIO()
    with gzip.GzipFile(fileobj=out, mode='wb', filename='', mtime=0, compresslevel=6) as z:
        z.write(raw)
    return out.getvalue()

def wire_body(value):
    return compressed(F.canonical(value))

@contextlib.contextmanager
def globals_boundary(module, **values):
    before = {k: module.__dict__.get(k) for k in values}
    missing = {k for k in values if k not in module.__dict__}
    module.__dict__.update(values)
    try:
        yield
    finally:
        for k, v in before.items():
            if k in missing:
                del module.__dict__[k]
            else:
                module.__dict__[k] = v

def rich_snapshot():
    """Synthetic metadata; historical hashes are copied as pins, not file reads."""
    stamp = 1795825680123456789
    def row(path, kind, inode, size=0, payload=None):
        mode = {'directory': stat.S_IFDIR | 0o700,
                'file': stat.S_IFREG | 0o640,
                'symlink': stat.S_IFLNK | 0o777}[kind]
        v = {'pathBase64': F.b64(path), 'kind': kind, 'device': F.SOURCE_DEVICE,
             'inode': inode, 'mode': mode, 'uid': 501, 'gid': 20, 'nlink': 1,
             'bytes': size, 'allocatedBytes': 4096 if size and kind == 'file' else 0,
             'mtimeNS': str(stamp-17), 'ctimeNS': str(stamp),
             'atimeNS': str(stamp+31), 'birthtimeNS': str(stamp-999999),
             'flags': 0, 'rdev': 0, 'xattrs': [], 'acl': None}
        if kind == 'file':
            v['sha256'] = payload
        elif kind == 'symlink':
            v['targetBase64'] = F.b64(b'../unresolved-\xfc/\xff')
        return v
    rows = [row(b'', 'directory', F.SOURCE_INODE, 96),
            row(b'a', 'directory', 70001, 64),
            row(b'z', 'directory', 70002, 64),
            row(b'z/nested', 'directory', 70003, 64)]
    sample = b'closed synthetic fixture\x00payload'
    content = sha(sample)
    for i, name in enumerate((b'a/alias-\xfe', b'a/raw-\xff')):
        r = row(name, 'file', 80001, len(sample), content)
        r['nlink'] = 3
        r['ctimeNS'] = '-9007199254741999'
        r['mtimeNS'] = '-9007199254742005'
        r['atimeNS'] = str(9007199254741007+i)
        r['birthtimeNS'] = '-18014398509483999'
        attrs = [(b'com.apple.fixture', b'\x00\xffexact'),
                 (b'user.\xff', b'')]
        r['xattrs'] = [{'nameBase64': F.b64(n), 'valueBase64': F.b64(b),
                        'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(attrs)]
        acl = b'!#acl 1\nsynthetic:transport-only\n'
        r['acl'] = {'textBase64': F.b64(acl), 'bytes': len(acl), 'sha256': sha(acl)}
        rows.append(r)
    rows.append(row(b'a!', 'file', 80002, len(sample), content))
    rows.append(row(b'z/nested/item', 'file', 80003, len(sample), content))
    target = b'../unresolved-\xfc/\xff'
    rows.append(row(b'link-\xfd', 'symlink', 90001, len(target)))
    for i, (name, (length, pin)) in enumerate(sorted(F.HISTORICAL_FILES.items())):
        rows.append(row(name.encode('ascii'), 'file', 81000+i, length, pin))
    rows.sort(key=F.relative_bytes)
    files = [r for r in rows if r['kind'] == 'file']
    payloads = {r['sha256']: r['bytes'] for r in files}
    hard_key = str(F.SOURCE_DEVICE) + ':80001'
    hard_paths = [r['pathBase64'] for r in rows if r['inode'] == 80001]
    links = [r['pathBase64'] for r in rows if r['kind'] == 'symlink']
    return {'schema': 'otzaria.native116-stream-snapshot/1',
            'sourceRoot': F.SOURCE_ROOT, 'rootDevice': F.SOURCE_DEVICE,
            'rootInode': F.SOURCE_INODE, 'capturedUTC': '2000-01-01T00:00:00+00:00',
            'runtime': {'fixture': 'RichSnapshot; no original file read'},
            'entries': rows, 'logicalBytes': sum(r['bytes'] for r in files),
            'uniquePayloads': len(payloads), 'uniquePayloadBytes': sum(payloads.values()),
            'hardlinkGroups': {hard_key: hard_paths},
            'unresolvedExternalHardlinkCounts': {hard_key: 1},
            'symlinkEntries': links,
            'dependencyReferences': [{'kind': 'synthetic-unresolved-symlink', 'pathBase64': links[0],
                                      'resolvedOrFollowed': False}],
            'historicalWindowsReferences': {k: {'bytes': v[0], 'sha256': v[1]}
                                            for k, v in F.HISTORICAL_FILES.items() if 'relocation' in k},
            'selfContained': False, 'fullTreeRestorePerformed': False,
            'externalReferencesVerifiedNow': False, 'windowsDependenciesVerifiedNow': False,
            'metadataOmissions': [], 'specialFilesOmitted': False,
            'physicalExtentOrCloneTopologyPreserved': False}

class OneRootOS:
    """Explicit finite OS/record boundary for the original enumeration code."""
    def __init__(self, rows):
        self.rows = {F.relative_bytes(r): copy.deepcopy(r) for r in rows}
        self.fds = {400: b''}
        self.next_fd = 401
        self.events = []
        self.guard_calls = 0
    def new(self, path):
        demand(path in self.rows and self.rows[path]['kind'] == 'directory', 'Fixture directory only')
        fd = self.next_fd; self.next_fd += 1; self.fds[fd] = path
        self.events.append(('open', fd, F.b64(path)))
        return fd
    def info(self, path):
        r = self.rows[path]
        return types.SimpleNamespace(st_dev=r['device'], st_ino=r['inode'], st_mode=r['mode'],
            st_uid=r['uid'], st_gid=r['gid'], st_nlink=r['nlink'], st_size=r['bytes'],
            st_mtime_ns=int(r['mtimeNS']), st_ctime_ns=int(r['ctimeNS']),
            st_flags=r['flags'], st_rdev=r['rdev'])
    def fstat(self, fd):
        return self.info(self.fds[fd])
    def stat(self, name, *, dir_fd, follow_symlinks):
        demand(follow_symlinks is False, 'Verbatim enumeration must not follow links')
        parent = self.fds[dir_fd]
        path = parent if name == b'.' else parent + (b'/' if parent else b'') + name
        return self.info(path)
    def open(self, name, flags, *, dir_fd):
        demand(flags == P.FLAGS, 'Verbatim original directory flags')
        parent = self.fds[dir_fd]
        path = parent if name == b'.' else parent + (b'/' if parent else b'') + name
        return self.new(path)
    def close(self, fd):
        demand(fd in self.fds and fd != 400, 'Exact fixture descriptor close')
        self.events.append(('close', fd)); del self.fds[fd]
    def listdir(self, fd):
        path = self.fds[fd]
        prefix = path + b'/' if path else b''
        return [p[len(prefix):] for p in self.rows
                if p.startswith(prefix) and p != path and b'/' not in p[len(prefix):]]
    @staticmethod
    def fsencode(value):
        demand(type(value) is bytes, 'Fixture names remain raw bytes')
        return value
    def open_parts(self, root, parts):
        demand(root == 400, 'Exact synthetic root descriptor')
        return self.new(b'/'.join(parts))
    def record(self, _parent, _name, relative, _before, full):
        value = copy.deepcopy(self.rows[relative])
        if value['kind'] == 'file' and not full:
            del value['sha256']
        self.events.append(('record', F.b64(relative), full))
        return value
    def guard(self):
        self.guard_calls += 1
        demand(self.guard_calls <= 100, 'Finite synthetic enumeration')

class Native116IndexedWireFocus(unittest.TestCase):
    def setUp(self):
        guard()
        self.snapshot = rich_snapshot()
        self.wire = F.snapshot_wire(self.snapshot)
        self.index = {F.relative_bytes(r): i for i, r in enumerate(self.snapshot['entries'])}
    def refuse(self, value, pattern=None):
        context = self.assertRaisesRegex(RuntimeError, pattern) if pattern else self.assertRaises((RuntimeError, ValueError, binascii.Error))
        with context:
            F.decode_snapshot(wire_body(value))
    def test_rich_metadata_and_raw_path_roundtrip(self):
        encoded = F.encode_snapshot(self.snapshot)
        decoded = F.decode_snapshot(encoded)
        self.assertEqual(decoded, self.snapshot)
        self.assertEqual(F.canonical(decoded), F.canonical(self.snapshot))
        self.assertIn(b'a/raw-\xff', [F.relative_bytes(r) for r in decoded['entries']])
        self.assertEqual(decoded['unresolvedExternalHardlinkCounts'], self.snapshot['unresolvedExternalHardlinkCounts'])
        self.assertFalse(decoded['selfContained'])
        self.assertFalse(decoded['windowsDependenciesVerifiedNow'])
        self.assertEqual(F.encode_snapshot(decoded), encoded)
    def test_oversized_integer_lexeme_refused_before_conversion(self):
        v = copy.deepcopy(self.wire); v['runtime']['boundedIntegerProbe'] = 'LEXEME_PROBE'
        raw = F.canonical(v)
        self.assertEqual(raw.count(b'"LEXEME_PROBE"'), 1)
        raw = raw.replace(b'"LEXEME_PROBE"', b'9' * 2048)
        with self.assertRaisesRegex(RuntimeError, 'Bounded wire integer lexeme'):
            F.decode_snapshot(compressed(raw))
        calls = []
        def monitored_int(text):
            calls.append(text)
            return int(text)
        g = dict(F.parse_wire_integer.__globals__); g['int'] = monitored_int
        original = types.FunctionType(F.parse_wire_integer.__code__, g)
        with self.assertRaises(RuntimeError):
            original('9' * 2048)
        self.assertEqual(calls, [])
        self.assertEqual(original('9007199254740997'), 9007199254740997)
        self.assertEqual(calls, ['9007199254740997'])
    def test_float_and_nonstandard_constants_refused(self):
        for token in (b'1.5', b'1e30', b'NaN', b'Infinity', b'-Infinity'):
            with self.subTest(token=token.decode()):
                v = copy.deepcopy(self.wire); v['runtime']['probe'] = 'NUMBER_PROBE'
                raw = F.canonical(v).replace(b'"NUMBER_PROBE"', token)
                with self.assertRaisesRegex(RuntimeError, 'Floating-point/constants'):
                    F.decode_snapshot(compressed(raw))
    def test_parent_index_type_range_and_cycle_refusals(self):
        i = self.index[b'z/nested/item']
        for parent in (True, None, '0', -1, i, i+1, len(self.wire['entries'])):
            with self.subTest(parent=parent):
                v = copy.deepcopy(self.wire); v['entries'][i][0] = parent; self.refuse(v)
        v = copy.deepcopy(self.wire); v['entries'][0][0] = 0; self.refuse(v)
    def test_parent_must_be_earlier_directory(self):
        v = copy.deepcopy(self.wire)
        v['entries'][self.index[b'z/nested/item']][0] = self.index[b'a!']
        self.refuse(v, 'Parent must be an earlier captured directory')
    def test_duplicate_paths_and_unsafe_basenames_refused(self):
        target = self.index[b'a/raw-\xff']
        other = self.index[b'a/alias-\xfe']
        v = copy.deepcopy(self.wire); v['entries'][target][1] = v['entries'][other][1]
        self.refuse(v, 'Duplicate reconstructed original path')
        for raw in (b'', b'.', b'..', b'/absolute', b'a/b', b'a\x00b'):
            with self.subTest(raw=repr(raw)):
                v = copy.deepcopy(self.wire); v['entries'][target][1] = F.b64(raw); self.refuse(v)
    def test_typed_stat_profiles_and_uint_bounds(self):
        for field in range(1, len(F.STAT_COLUMNS)):
            for invalid in (True, -1, 1 << 64, '1'):
                with self.subTest(field=field, value=invalid):
                    v = copy.deepcopy(self.wire); v['statProfiles'][0][field] = invalid; self.refuse(v)
        v = copy.deepcopy(self.wire); v['statProfiles'][0][0] = 'socket'; self.refuse(v)
        v = copy.deepcopy(self.wire); v['entries'][0][3] = True; self.refuse(v)
    def test_exact_payload_digest_size_and_index_contract(self):
        for value in ([F.b64(b'a'*31), 1], [F.b64(b'a'*32), True],
                      [F.b64(b'a'*32), -1], [F.b64(b'a'*32), F.MAX_LOGICAL_BYTES+1]):
            v = copy.deepcopy(self.wire); v['payloads'][0] = value; self.refuse(v)
        i = self.index[b'a!']
        for invalid in (True, -1, len(self.wire['payloads']), '0'):
            v = copy.deepcopy(self.wire); v['entries'][i][4] = invalid; self.refuse(v)
        v = copy.deepcopy(self.wire); extra = copy.deepcopy(v['payloads'][0]); extra[1] += 1
        v['payloads'].append(extra); self.refuse(v, 'duplicate or conflicting payload')
    def test_unused_duplicate_and_reordered_tables_refused(self):
        v = copy.deepcopy(self.wire); v['statProfiles'].append(copy.deepcopy(v['statProfiles'][0])); self.refuse(v)
        v = copy.deepcopy(self.wire); unused = copy.deepcopy(v['statProfiles'][0]); unused[3] += 123
        v['statProfiles'].append(unused); self.refuse(v, 'Exact full typed wire roundtrip')
        v = copy.deepcopy(self.wire); v['payloads'].append([F.b64(b'\xab'*32), 8]); self.refuse(v)
        for table, column in (('statProfiles', 2), ('payloads', 4)):
            v = copy.deepcopy(self.wire); v[table][0], v[table][1] = v[table][1], v[table][0]
            for i, r in enumerate(v['entries']):
                if table == 'payloads' and self.snapshot['entries'][i]['kind'] != 'file':
                    continue
                if r[column] in (0, 1): r[column] = 1-r[column]
            self.refuse(v, 'Exact full typed wire roundtrip')
    def test_timestamp_deltas_and_original_decimal_forms(self):
        self.assertEqual(F.decode_snapshot(F.encode_snapshot(self.snapshot)), self.snapshot)
        for value in ('01', '+1', '-0', ' 1', '1.0', '1'*33, True):
            with self.subTest(value=value):
                v = copy.deepcopy(self.snapshot); v['entries'][0]['ctimeNS'] = value
                with self.assertRaises((RuntimeError, ValueError)):
                    F.encode_snapshot(v)
        for value in (True, 1 << 109, -(1 << 109), '0'):
            v = copy.deepcopy(self.wire); v['entries'][0][5] = value; self.refuse(v)
        v = copy.deepcopy(self.wire); v['timestampBaseNS'] = '9'*32; v['entries'][0][5] = 1
        self.refuse(v)
    def test_canonical_base64_and_exact_original_row_keys(self):
        v = copy.deepcopy(self.wire); v['entries'][self.index[b'a']][1] = 'YR=='
        self.refuse(v, 'Canonical original basename')
        v = copy.deepcopy(self.snapshot); v['entries'][0]['unrecognizedMetadata'] = 'must not be dropped'
        with self.assertRaisesRegex(RuntimeError, 'Exact source row fields'):
            F.encode_snapshot(v)
        for key in ('acl', 'birthtimeNS', 'xattrs'):
            v = copy.deepcopy(self.snapshot); del v['entries'][0][key]
            with self.assertRaisesRegex(RuntimeError, 'Exact source row fields'):
                F.encode_snapshot(v)
    def test_inline_xattr_acl_and_symlink_metadata_integrity(self):
        i = self.index[b'a/raw-\xff']
        v = copy.deepcopy(self.wire); v['entries'][i][10][0]['bytes'] += 1; self.refuse(v)
        v = copy.deepcopy(self.wire); v['entries'][i][11]['sha256'] = '0'*64; self.refuse(v)
        v = copy.deepcopy(self.wire); v['entries'][i][10].reverse(); self.refuse(v)
        v = copy.deepcopy(self.wire); v['entries'][self.index[b'link-\xfd']][9] = F.b64(b'bad\x00target'); self.refuse(v)
        self.assertEqual(F.decode_snapshot(F.encode_snapshot(self.snapshot))['entries'][i]['acl'],
                         self.snapshot['entries'][i]['acl'])
    def test_incremental_prefix_charge_and_actual_refusal_counters(self):
        prefix = F.IndexedRows()
        prefix.add(self.snapshot['entries'][0])
        charged = sum(len(F.canonical(x)) for x in prefix.entries + prefix.profiles + prefix.payloads)
        self.assertEqual(prefix.fragment_bytes, charged)
        accepted = prefix.count
        with globals_boundary(F, SNAPSHOT_CAP=charged):
            with self.assertRaises(RuntimeError) as failure:
                prefix.add(self.snapshot['entries'][1])
        detail = json.loads(str(failure.exception))
        self.assertEqual(detail['scope'], 'observed-prefix-only')
        self.assertEqual(detail['entriesObserved'], accepted+1)
        self.assertEqual(detail['entriesAcceptedBeforeRefusal'], accepted)
        self.assertFalse(detail['completeTreeCountKnown'])
        self.assertEqual(detail['code'], 'INDEXED_METADATA_FRAGMENT_CAP')
        self.assertGreater(detail['canonicalRowAndTableFragmentBytes'], detail['limitBytes'])
        self.assertEqual(prefix.count, accepted)
    def test_reconstructed_path_bound_before_concatenation(self):
        with globals_boundary(F, MAX_EXPANDED_PATH_BYTES=0):
            with self.assertRaisesRegex(RuntimeError, 'before allocation'):
                F.expand_indexed_rows(self.wire)
        self.assertEqual(F.MAX_EXPANDED_PATH_BYTES, 24*1024**2)
    def test_traversal_prefix_and_final_sorted_wire_join(self):
        rows = copy.deepcopy(self.snapshot['entries'])
        bypath = {F.relative_bytes(r): r for r in rows}
        traversal = [b'', b'a', b'a/alias-\xfe', b'a/raw-\xff', b'a!']
        traversal += [p for p in sorted(bypath) if p not in traversal]
        self.assertNotEqual(traversal, sorted(traversal))
        indexed = F.IndexedRows(collect=False)
        for path in traversal:
            indexed.add(bypath[path])
        self.assertEqual(indexed.count, len(rows))
        self.assertEqual(indexed.entries, [])
        self.assertEqual(indexed.path_bytes, sum(map(len, bypath)))
        self.assertEqual(F.decode_snapshot(F.encode_snapshot(self.snapshot)), self.snapshot)
    def test_actual_producer_import_resolves_indexed_rows(self):
        self.assertIs(P.IndexedRows, F.IndexedRows)
        self.assertIsNone(P.ROOT_FD)
        self.assertEqual(P.NATIVE_METADATA_ABI['headerSHA256'],
                         '9aca8ca87031ab7b670617e5af8b15a0cad8f34f7ab3bdb5dd799eb153b3ad0e')
        self.assertEqual(P.NATIVE_METADATA_ABI['symlinkFlag'], 0x00200000)
    def test_verbatim_enumeration_on_closed_synthetic_os_boundary(self):
        for full in (True, False):
            fake = OneRootOS(self.snapshot['entries'])
            globals_copy = dict(P.enumerate_source.__globals__)
            globals_copy.update(os=fake, ROOT_FD=400, open_root=lambda: fake.new(b''),
                                open_parts=fake.open_parts, record=fake.record, guard=fake.guard)
            function = types.FunctionType(P.enumerate_source.__code__, globals_copy,
                                          P.enumerate_source.__name__)
            result = function(full)
            expected = copy.deepcopy(self.snapshot['entries'])
            if not full:
                for r in expected:
                    if r['kind'] == 'file': del r['sha256']
            self.assertEqual(result, expected)
            self.assertEqual(fake.fds, {400: b''})
            self.assertEqual(len([e for e in fake.events if e[0] == 'record']), len(expected))
            BOUNDARY_EVENTS.append({'full': full, 'entries': len(expected),
                                    'openEvents': len([e for e in fake.events if e[0] == 'open']),
                                    'remainingSyntheticDescriptors': list(fake.fds)})

def failure_record(error):
    # Record real frame identities without linecache opening source paths after
    # the import fence; these nonsecret control errors never contain API tokens.
    frames = []; tb = error[2]
    while tb is not None:
        frames.append({'file': tb.tb_frame.f_code.co_filename,
                       'function': tb.tb_frame.f_code.co_name, 'line': tb.tb_lineno})
        tb = tb.tb_next
    message = str(error[1])
    return {'errorType': error[0].__name__, 'message': message[:2048],
            'messageTruncated': len(message)>2048, 'frames': frames}

class EvidenceResult(unittest.TestResult):
    def __init__(self):
        super().__init__(); self.records = []; self.active = None
    def startTest(self, test):
        guard(); super().startTest(test); self.active = {'name': test.id(), 'subcaseFailures': []}
    def addSuccess(self, test):
        self.active['status'] = 'PASS'
    def addFailure(self, test, error):
        self.failures.append((test, 'recorded'))
        self.active.update(status='FAIL', **failure_record(error))
    def addError(self, test, error):
        self.errors.append((test, 'recorded'))
        self.active.update(status='ERROR', **failure_record(error))
    def addSubTest(self, test, subtest, error):
        if error is None:
            return
        status = 'FAIL' if issubclass(error[0], test.failureException) else 'ERROR'
        (self.failures if status=='FAIL' else self.errors).append((subtest, 'recorded'))
        self.active['subcaseFailures'].append({'name': str(subtest), **failure_record(error)})
        self.active['status'] = status
    def stopTest(self, test):
        self.active.setdefault('status', 'ERROR')
        self.records.append(self.active); self.active = None
        super().stopTest(test); guard()

def run(envelope):
    """Future approved caller supplies only exact pinned nonsecret source bytes."""
    global F, P, DEADLINE, EXPECTED_PARENT
    demand(sys.flags.isolated == 1 and sys.dont_write_bytecode, 'Use python3 -I -B')
    demand(sys.platform == 'darwin' and sys.version_info[:3] == (3, 9, 6),
           'This suite specifically qualifies the observed actual Darwin Python3.9.6')
    mode = envelope['mode']
    demand(mode in PINS and set(envelope) == {'mode', 'sources'}, 'Closed control envelope')
    demand(set(envelope['sources']) == set(PINS[mode]), 'Exact two source inputs')
    EXPECTED_PARENT = os.getppid(); DEADLINE = time.monotonic()+120
    guard()
    # Imports of dependencies occur before the audit fence. They are standard
    # Python/runtime loading, not any original Native116 file or account access.
    raw_sources = {}
    for name, (length, expected) in PINS[mode].items():
        raw = base64.b64decode(envelope['sources'][name], validate=True)
        demand(len(raw)==length and sha(raw)==expected, 'Exact pinned source bytes')
        raw_sources[name] = raw
    import ctypes, datetime, errno, pwd, signal, struct, tarfile, zlib, posixpath
    import difflib, pprint, linecache, tokenize
    audit_open_events = []
    def audit(event, args):
        if event == 'open':
            path, access, flags = args
            demand(type(path) is str and path == HEADER and type(flags) is int
                   and not flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND),
                   'Focused import may open only the pinned header read-only')
            audit_open_events.append(path)
        elif event in ('os.listdir', 'os.scandir', 'os.system', 'subprocess.Popen',
                       'socket.connect', 'os.remove', 'os.rename', 'os.mkdir', 'os.rmdir',
                       'os.link', 'os.symlink', 'os.chdir', 'os.truncate', 'os.chmod',
                       'os.chown', 'os.utime'):
            raise RuntimeError('Focused runtime does not enumerate/write/spawn/connect')
    sys.addaudithook(audit)
    for name in ('stream_format.py', 'mac_producer.py'):
        module = types.ModuleType(name[:-3]); module.__file__ = '<pinned-'+name+'>'
        sys.modules[name[:-3]] = module
        exec(compile(raw_sources[name], module.__file__, 'exec'), module.__dict__)
        if name == 'stream_format.py': F = module
        else: P = module
    guard()
    demand(P.ROOT_FD is None and audit_open_events == [HEADER],
           'Only actual pinned-header import, no Native116 root open')
    all_names = unittest.defaultTestLoader.getTestCaseNames(Native116IndexedWireFocus)
    demand(len(all_names)==17, 'Exactly seventeen new indexed-wire methods')
    names = all_names if mode=='candidate' else [
        'test_oversized_integer_lexeme_refused_before_conversion',
        'test_verbatim_enumeration_on_closed_synthetic_os_boundary']
    suite = unittest.TestSuite(Native116IndexedWireFocus(name) for name in names)
    result = EvidenceResult(); suite.run(result)
    guard()
    value = {'schema':'otzaria.native116-indexed-wire-focused-result/1',
             'suite':'Native116IndexedWireFocus', 'mode':mode,
             'runtime':{'python':sys.version, 'executable':sys.executable, 'platform':sys.platform},
             'sourcePins':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in raw_sources.items()},
             'testsRun':result.testsRun, 'methodRecords':result.records,
             'failures':len(result.failures), 'errors':len(result.errors),
             'successful':result.wasSuccessful(), 'headerReadOnlyEvents':audit_open_events,
             'syntheticEnumerationEvents':BOUNDARY_EVENTS,
             'actualNative116Enumeration':0, 'originalPayloadReads':0, 'nativeOrSDKRun':0,
             'legacy25Rerun':False, 'noActualTreeFitClaim':True}
    demand(len(json.dumps(value,separators=(',',':')).encode())<=65536, 'Bounded focused result')
    return value
