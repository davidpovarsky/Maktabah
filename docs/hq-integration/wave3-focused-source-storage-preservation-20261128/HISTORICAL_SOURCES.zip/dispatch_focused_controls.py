#!/usr/bin/env python3
"""Reviewed-only focused-control dispatcher; no Native116/auth/prepare API.

Each explicit phase is one exclusive journal. Original process_identity and
stop_owned are loaded byte-exact from the reviewed runtime. Reporting slots
are fully allocated before Popen/fixture creation, inside the same 4 MiB scope.
No automatic retry or phase progression.
"""
if not __debug__:
    raise RuntimeError('Optimized dispatcher refused before actions')
import argparse
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import selectors
import stat
import subprocess
import sys
import time
import types

ROOT=Path('/home/ubuntu/otzaria-wave3-native116-v3-focused-controls-20261128')
PROPOSAL=Path('/home/ubuntu/otzaria-wave3-native116-compact-v3-review3-proposal-20261128')
FLOOR=1593835520
CAP=4*1024**2
OUTPUT_LIMIT=65536
CLOSURE_CAP=65536
ALIAS_SLOT_SIZES={'DISPATCH_RESULT.json':4096,'worker.TERMINAL.json':4096,
                  'worker.PROCESS.json':4096,'worker.stdout':16384,'worker.stderr':4096}
SLOT_SIZES={'DISPATCH_RESULT.json':16384,'worker.TERMINAL.json':16384,
            'worker.PROCESS.json':4096,'worker.stdout':65536,'worker.stderr':65536}
PHASES={
 'accounting-candidate':('retained_accounting_controls_review2.py','candidate','Native116RetainedAccountingFocus',11),
 'accounting-omit-first':('retained_accounting_controls_review2.py','omit_first_proposal','Native116RetainedAccountingFocus',1),
 'mac-baseline':('indexed_wire_controls_review2.py','review_findings_baseline','Native116IndexedWireFocus',2),
 'mac-candidate':('indexed_wire_controls_review2.py','candidate','Native116IndexedWireFocus',17),
}
SSH=['sudo','-u','ubuntu','-H','ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',
     '-o','StrictHostKeyChecking=yes','-o','IdentitiesOnly=yes','-o','UpdateHostKeys=no',
     '-o','ControlMaster=no','-o','ControlPath=none','-T','scaleway-mac',
     '/usr/bin/python3','-I','-B','-']
R=None
DEADLINE=None
ORIGINAL_PARENT=None
SEALED={}
INITIAL_ROOT=None

def require(ok,message):
    if not ok: raise RuntimeError(message)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode('ascii')
def identity(s):
    return {'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'nlink':s.st_nlink,
            'bytes':s.st_size,'mtimeNS':str(s.st_mtime_ns),'ctimeNS':str(s.st_ctime_ns)}
def read_fixed(path,limit,single=True):
    require(path.resolve(strict=True)==path,'No source-path symlink')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        before=os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and (before.st_nlink==1 or not single)
                and before.st_size<=limit,'Bounded exact regular source')
        out=bytearray()
        while True:
            chunk=os.read(fd,min(65536,limit+1-len(out)))
            if not chunk: break
            out.extend(chunk); require(len(out)<=limit,'Exact read cap')
        require(identity(before)==identity(os.fstat(fd))==identity(path.lstat()),'Input changed')
        return bytes(out)
    finally: os.close(fd)
def scope_rows(hashes=False):
    s=ROOT.lstat()
    require(stat.S_ISDIR(s.st_mode) and ROOT.resolve()==ROOT
            and s.st_dev==os.stat('/').st_dev,'Fixed rootfs controls root')
    if INITIAL_ROOT is not None:
        require((s.st_dev,s.st_ino)==INITIAL_ROOT,'Controls root replacement')
    rows=[]; pending=[(ROOT,0)]; count=0; total=0
    while pending:
        path,depth=pending.pop(); require(depth<=5,'Focused depth bound')
        info=path.lstat(); count+=1; require(count<=1200,'Focused entry bound')
        require(info.st_dev==s.st_dev,'No cross-device control entry')
        total+=info.st_blocks*512
        row={'path':str(path.relative_to(ROOT)),'identity':identity(info),
             'uid':info.st_uid,'gid':info.st_gid,'atimeNSBeforeHash':str(info.st_atime_ns),
             'allocatedBytes':info.st_blocks*512}
        if stat.S_ISDIR(info.st_mode):
            row['kind']='directory'
            pending.extend((p,depth+1) for p in path.iterdir())
        elif stat.S_ISREG(info.st_mode):
            row['kind']='file'
            if hashes and path.name!='CONTROLS_CLOSED.json':
                raw=read_fixed(path,1024**2,single=False)
                row['sha256']=sha(raw)
        elif stat.S_ISLNK(info.st_mode):
            row['kind']='symlink'
            row['targetBase64']=base64.b64encode(os.fsencode(os.readlink(path))).decode('ascii')
        else: raise RuntimeError('Unexpected focused entry type')
        rows.append(row)
    if hashes:
        # Check the complete captured path set again after content hashing.
        # Reading may advance atime; stable identity excludes only that field.
        actual=set(); pending=[(ROOT,0)]
        while pending:
            path,depth=pending.pop(); require(depth<=5,'Focused final depth bound')
            relative=str(path.relative_to(ROOT)); actual.add(relative)
            require(len(actual)<=1200,'Focused final entry bound')
            current=path.lstat()
            if stat.S_ISDIR(current.st_mode): pending.extend((p,depth+1) for p in path.iterdir())
        require(actual=={r['path'] for r in rows},'Closure path membership changed')
        for row in rows:
            path=ROOT/row['path']; current=path.lstat()
            require(identity(current)==row['identity'] and current.st_uid==row['uid']
                    and current.st_gid==row['gid'] and current.st_blocks*512==row['allocatedBytes'],
                    'Closure member identity changed')
            if row['kind']=='symlink':
                require(base64.b64encode(os.fsencode(os.readlink(path))).decode('ascii')==row['targetBase64'],
                        'Closure symlink target changed')
    return sorted(rows,key=lambda r:r['path']),total
def guard(addition=0):
    require(time.monotonic()<DEADLINE and os.getppid()==ORIGINAL_PARENT,'Owned dispatch lifetime')
    v=os.statvfs(ROOT)
    require(v.f_bavail*v.f_frsize>=FLOOR+CAP,'Root floor plus complete controls reserve')
    _,used=scope_rows()
    require(used+addition<=CAP,'All source/log/fixture/directory allocations <=4MiB')
    return used
def fsync_dir(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)
def mkdir(path):
    guard(8192)
    require(path.parent.resolve()==path.parent and path.is_relative_to(ROOT),'Owned directory only')
    os.mkdir(path,0o700); fsync_dir(path.parent)

class Slot:
    def __init__(self,path,capacity,existing=False):
        self.path,self.capacity=path,capacity
        self.fd=None; self.filled=False
        require(path.is_relative_to(ROOT) and path.parent.resolve()==path.parent,'Fixed reporting path')
        if not existing: guard(capacity+8192)
        flags=os.O_RDWR|os.O_NOFOLLOW
        if not existing: flags|=os.O_CREAT|os.O_EXCL
        fd=os.open(path,flags,0o600)
        try:
            s=os.fstat(fd)
            require(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'Single-link reporting slot')
            if not existing:
                remaining=capacity
                while remaining:
                    data=b'\0'*min(65536,remaining)
                    n=os.write(fd,data); require(n>0,'Short reporting reservation')
                    remaining-=n
                os.fsync(fd); fsync_dir(path.parent)
            s=os.fstat(fd)
            require(s.st_size==capacity and s.st_blocks*512>=capacity,'Fully allocated reporting slot')
            require(os.pread(fd,capacity+1,0)==b'\0'*capacity,'Exclusive unused reporting slot')
            self.initial=identity(s); self.allocated=s.st_blocks*512; self.fd=fd
        except BaseException:
            os.close(fd); raise
    def descriptor(self):
        return {'path':str(self.path),'device':self.initial['device'],'inode':self.initial['inode'],
                'reservedBytes':self.capacity}
    def fill(self,raw):
        # This bounded overwrite uses only already allocated, pinned extents.
        # It is allowed after a guard abort; it cannot create a new file/grow.
        require(not self.filled and self.fd is not None and len(raw)<=self.capacity,'One bounded reporting fill')
        current=os.fstat(self.fd)
        require(identity(current)==identity(self.path.lstat())
                and current.st_dev==self.initial['device'] and current.st_ino==self.initial['inode']
                and stat.S_ISREG(current.st_mode) and current.st_nlink==1
                and current.st_size==self.capacity and current.st_blocks*512==self.allocated,
                'Pinned unused reporting slot changed')
        os.lseek(self.fd,0,os.SEEK_SET); remaining=memoryview(raw)
        while remaining:
            n=os.write(self.fd,remaining); require(n>0,'Short reserved evidence write'); remaining=remaining[n:]
        os.ftruncate(self.fd,len(raw)); os.fsync(self.fd); fsync_dir(self.path.parent)
        after=os.fstat(self.fd)
        require(after.st_size==len(raw) and after.st_blocks*512<=self.allocated,
                'Reporting grew beyond reserved allocation')
        require(os.pread(self.fd,len(raw)+1,0)==raw,'Reserved full evidence readback')
        self.filled=True
        return {'path':str(self.path),'bytes':len(raw),'sha256':sha(raw),'identity':identity(after)}
    def close(self):
        if self.fd is not None: os.close(self.fd); self.fd=None

def failure(error,stage):
    return {'stage':stage,'errorType':type(error).__name__,'message':str(error)[:1024]}

def validate_seal(expected):
    global R,INITIAL_ROOT
    require(sys.flags.isolated==1 and sys.dont_write_bytecode,'Use python3 -I -B')
    require(type(expected) is str and len(expected)==64
            and all(c in '0123456789abcdef' for c in expected),'Exact reviewed seal digest')
    s=ROOT.lstat(); INITIAL_ROOT=(s.st_dev,s.st_ino)
    guard()
    raw=read_fixed(ROOT/'SOURCE_SEAL_REVIEW2.json',65536)
    require(sha(raw)==expected,'Root-reviewed focused seal')
    value=json.loads(raw)
    require(value['schema']=='otzaria.native116-focused-control-reporting-seal/2'
            and value['root']==str(ROOT),'Fixed focused reporting seal')
    expected_files={
        'indexed_wire_controls_review2.py','retained_accounting_controls_review2.py',
        'dispatch_focused_controls.py','FOCUSED_CONTROLS_PLAN_REVIEW2.json',
        'REPORTING_REVIEW2.patch','REPORTING_SOURCE_PRESERVATION.json'}
    require(set(value['files'])==expected_files,'Closed revised source/proof set')
    for name,pin in {**value['originalSix'],**value['files']}.items():
        require(Path(name).name==name,'Flat sealed source leaf')
        body=read_fixed(ROOT/name,1024**2)
        require(len(body)==pin['bytes'] and sha(body)==pin['sha256'],'Exact focused source pin')
        SEALED[name]=body
    SEALED['SOURCE_SEAL_REVIEW2.json']=raw
    require(SEALED['dispatch_focused_controls.py']==read_fixed(Path(__file__),65536),
            'Exact dispatched controller source')
    plan=json.loads(SEALED['FOCUSED_CONTROLS_PLAN_REVIEW2.json'])
    inputs=json.loads(SEALED['INPUT_PINS.json'])
    runtime_pin=inputs['candidate']['reviewed_runtime.py']
    body=read_fixed(Path(runtime_pin['path']),65536)
    require(len(body)==8447 and sha(body)=='ac8ed682ade9d74f0b74b3bf90e3dafdc38e144a4b4048e6b5b115d986648f80',
            'Exact original owned-process cleanup helper')
    R=types.ModuleType('focused_reviewed_process_runtime')
    R.__file__='<pinned-reviewed-runtime>'
    exec(compile(body,R.__file__,'exec'),R.__dict__)
    return plan,inputs
def recheck_sources():
    for name,body in SEALED.items():
        require(read_fixed(ROOT/name,1024**2)==body,'Frozen source changed during controls')

def worker_bootstrap(worker,worker_pin,envelope,expected):
    payload={'worker':base64.b64encode(worker).decode('ascii'),'workerPin':worker_pin,
             'envelope':envelope,'expectedMethods':expected}
    encoded=base64.b64encode(canonical(payload)).decode('ascii')
    text="""if not __debug__: raise RuntimeError('Optimized focused bootstrap refused')
import base64,hashlib,json,sys,types
v=json.loads(base64.b64decode(%r,validate=True))
stage='WORKER_SOURCE'
try:
 b=base64.b64decode(v['worker'],validate=True)
 if len(b)!=v['workerPin']['bytes'] or hashlib.sha256(b).hexdigest()!=v['workerPin']['sha256']: raise RuntimeError('Worker source pin')
 print(json.dumps({'kind':'WORKER_STARTED','expectedMethodCount':len(v['expectedMethods'])},separators=(',',':')),flush=True)
 m=types.ModuleType('focused_worker');m.__file__='<pinned-focused-worker>'
 stage='WORKER_IMPORT';exec(compile(b,m.__file__,'exec'),m.__dict__)
 stage='WORKER_RUN';result=m.run(v['envelope'])
 print(json.dumps({'kind':'FINAL_RESULT','result':result},separators=(',',':'),ensure_ascii=True),flush=True)
except BaseException as e:
 result={'schema':'otzaria.native116-focused-bootstrap-abort/1','status':'SETUP_OR_RUNTIME_ABORT',
         'mode':v['envelope'].get('mode'),'successful':False,'testsRun':0,
         'methodRecords':[],'completedMethodCount':0,'activeRecord':None,
         'expectedMethods':v['expectedMethods'],'unfinishedMethods':v['expectedMethods'],
         'unfinishedMethodCount':len(v['expectedMethods']),
         'terminalAbort':{'stage':stage,'errorType':type(e).__name__,'message':str(e)[:1024]}}
 try: print(json.dumps({'kind':'FINAL_RESULT','result':result},separators=(',',':')),flush=True)
 except BaseException: pass
 sys.exit(1)
""" % encoded
    body=text.encode('ascii')
    require(len(body)<=512*1024,'Bounded nonsecret source bootstrap')
    return body

def execute(argv,input_body,slots,timeout):
    """Only exact unreaped owned leader cleanup; all fallible setup is inside try."""
    original=None; selector=None; out=bytearray(); err=bytearray(); sent=0
    error=None; cleanup_error=None; code=None; stage='FRESH_CHILD_ADMISSION'; output_overflow=None
    try:
        guard(); stage='POPEN'
        process=subprocess.Popen(argv,stdin=subprocess.PIPE if input_body is not None else subprocess.DEVNULL,
                                 stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    except BaseException as exc:
        slots['worker.PROCESS.json'].fill(canonical({'argv':argv,'popenStarted':False,
                                                    'setupAbort':failure(exc,stage)}))
        proofs={n:slots[n].fill(b'') for n in ('worker.stdout','worker.stderr')}
        terminal={'pid':None,'startIdentity':None,'returncode':None,'popenStarted':False,
                  'terminalAbort':failure(exc,stage),'cleanupError':None,
                  'allOwnedChildrenReaped':True,'rawEvidence':proofs,'noRetry':True}
        slots['worker.TERMINAL.json'].fill(canonical(terminal))
        return b'',b'',terminal
    try:
        stage='OWNED_IDENTITY'
        original=R.process_identity(process.pid)
        require(original['pgid']==original['session']==process.pid,'Owned PID/group/session identity')
        slots['worker.PROCESS.json'].fill(canonical({'argv':argv,'identity':original,
             'inputBytes':len(input_body or b''),'inputSHA256':sha(input_body) if input_body is not None else None}))
        stage='PIPE_SETUP'; selector=selectors.DefaultSelector()
        for label,pipe in (('stdout',process.stdout),('stderr',process.stderr)):
            os.set_blocking(pipe.fileno(),False)
            selector.register(pipe.fileno(),selectors.EVENT_READ,label)
        if process.stdin is not None:
            os.set_blocking(process.stdin.fileno(),False)
            selector.register(process.stdin.fileno(),selectors.EVENT_WRITE,'stdin')
        end=min(DEADLINE,time.monotonic()+timeout); stage='PIPE_RUN'
        while selector.get_map():
            guard(); require(time.monotonic()<end,'Bounded focused child deadline')
            for key,_ in selector.select(0.25):
                if key.data=='stdin':
                    try: n=os.write(key.fd,input_body[sent:sent+65536])
                    except BlockingIOError: continue
                    require(n>0,'Owned bootstrap stdin stopped'); sent+=n
                    if sent==len(input_body):
                        selector.unregister(key.fd); process.stdin.close()
                else:
                    try: raw=os.read(key.fd,65536)
                    except BlockingIOError: continue
                    if not raw: selector.unregister(key.fd); continue
                    target=out if key.data=='stdout' else err
                    capacity=slots['worker.'+key.data].capacity
                    room=capacity-len(target); target.extend(raw[:room])
                    if len(raw)>room:
                        output_overflow={'channel':key.data,'capturedBytes':len(target),
                                         'observedAtLeastBytes':len(target)+len(raw)-room}
                        raise RuntimeError('Bounded raw child output exceeded; prefix retained')
        stage='CHILD_WAIT'
        code=process.wait(timeout=max(0.01,min(20,end-time.monotonic())))
        require(input_body is None or sent==len(input_body),'Complete nonsecret bootstrap delivery')
    except BaseException as exc:
        error=failure(exc,stage)
    finally:
        try:
            R.stop_owned(process,original)
        except BaseException as exc:
            cleanup_error=failure(exc,'OWNED_CLEANUP')
        finally:
            # Preserve already-written checkpoint bytes after a parent guard
            # refusal, without waiting for/reaping any foreign process.
            for pipe,target,limit in ((process.stdout,out,slots['worker.stdout'].capacity),
                                      (process.stderr,err,slots['worker.stderr'].capacity)):
                try:
                    os.set_blocking(pipe.fileno(),False)
                    while len(target)<limit:
                        try: data=os.read(pipe.fileno(),limit-len(target))
                        except BlockingIOError: break
                        if not data: break
                        target.extend(data)
                except BaseException:
                    pass
            if selector is not None: selector.close()
            for pipe in (process.stdin,process.stdout,process.stderr):
                if pipe is not None and not pipe.closed: pipe.close()
            raw_proofs={}; reporting_errors=[]
            for name,body in (('worker.stdout',bytes(out)),('worker.stderr',bytes(err))):
                try: raw_proofs[name]=slots[name].fill(body)
                except BaseException as exc: reporting_errors.append(failure(exc,'RESERVED_'+name))
            terminal={'pid':process.pid,'startIdentity':original,'returncode':process.returncode,
                      'inputBytesSent':sent,'stdoutBytes':len(out),'stdoutSHA256':sha(out),
                      'stderrBytes':len(err),'stderrSHA256':sha(err),'terminalAbort':error,
                      'cleanupError':cleanup_error,'reportingErrors':reporting_errors,
                      'outputOverflow':output_overflow,'streamsFullyDrainedBeforeCleanup':error is None,
                      'allOwnedChildrenReaped':process.returncode is not None,
                      'noRetry':True,'rawEvidence':raw_proofs}
            slots['worker.TERMINAL.json'].fill(canonical(terminal))
    return bytes(out),bytes(err),terminal

def parse_worker(raw,expected,mode,suite,expected_sources):
    events=[]; final=None; malformed=False
    for line in raw.splitlines():
        try: event=json.loads(line)
        except Exception: malformed=True; continue
        if type(event) is not dict: malformed=True; continue
        kind=event.get('kind')
        if kind=='FINAL_RESULT':
            if final is not None: malformed=True
            final=event.get('result')
        elif kind in ('WORKER_STARTED','METHOD_STARTED','METHOD_COMPLETED'):
            if final is not None: malformed=True
            events.append(event)
        else: malformed=True
    completed=[e for e in events if e.get('kind')=='METHOD_COMPLETED']
    started=[e for e in events if e.get('kind')=='METHOD_STARTED']
    summary={'finalReportReceived':type(final) is dict,'malformedRawLine':malformed,
             'completedCheckpoints':completed,'lastStartedCheckpoint':started[-1] if started else None,
             'expectedMethodCount':len(expected),'expectedMethods':expected,'complete':False}
    if type(final) is dict:
        records=final.get('methodRecords')
        fields=('testsRun','completedMethodCount','unfinishedMethodCount')
        typed=all(type(final.get(k)) is int for k in fields)
        named=(type(records) is list and all(type(r) is dict and type(r.get('name')) is str for r in records)
               and sorted(r['name'].rsplit('.',1)[-1] for r in records)==sorted(expected))
        required={'schema','suite','mode','testsRun','completedMethodCount','unfinishedMethodCount',
                  'unfinishedMethods','terminalAbort','activeRecord','expectedMethods','expectedMethodCount',
                  'successful','failures','errors','sourcePins','methodRecords','status'}
        checkpoint_names=[e.get('name','').rsplit('.',1)[-1] for e in completed]
        schema=('otzaria.native116-indexed-wire-focused-result/2' if suite=='Native116IndexedWireFocus'
                else 'otzaria.native116-retained-accounting-focused-result/2')
        complete=(required<=set(final) and not malformed and typed and named
                  and final['schema']==schema and final['suite']==suite and final['mode']==mode
                  and type(final['successful']) is bool
                  and type(final['failures']) is int and type(final['errors']) is int
                  and type(final['expectedMethodCount']) is int and final['expectedMethodCount']==len(expected)
                  and type(final['expectedMethods']) is list and sorted(final['expectedMethods'])==sorted(expected)
                  and final['sourcePins']==expected_sources
                  and sorted(checkpoint_names)==sorted(expected)
                  and final['testsRun']==len(expected) and final['completedMethodCount']==len(expected)
                  and final['unfinishedMethodCount']==0 and final['unfinishedMethods']==[]
                  and final['activeRecord'] is None and final['terminalAbort'] is None)
        if final.get('successful') is True:
            complete=complete and final.get('failures')==0 and final.get('errors')==0 and all(
                r.get('status')=='PASS' for r in records)
        summary.update(complete=complete,status=final.get('status'),successful=final.get('successful') is True,
                       actualTestsRun=final.get('testsRun'),completedMethodCount=final.get('completedMethodCount'),
                       unfinishedMethodCount=final.get('unfinishedMethodCount'),
                       activeRecord=final.get('activeRecord'),terminalAbort=final.get('terminalAbort'),
                       failures=final.get('failures'),errors=final.get('errors'),
                       sourcePins=final.get('sourcePins'))
    return summary

def allocate_slots(directory,slots,sizes=SLOT_SIZES):
    # Caller retains every successfully reserved FD if a later reservation
    # fails. The first slot records that setup failure without a new allocation.
    require(not slots and next(iter(sizes))=='DISPATCH_RESULT.json','Dispatch evidence reserves first')
    for name,capacity in sizes.items():
        slots[name]=Slot(directory/name,capacity)

def sources_for(inputs,phase):
    group=inputs['sourceFindingsBaseline'] if phase=='mac-baseline' else inputs['candidate']
    selected=('stream_format.py','mac_producer.py') if phase.startswith('mac-') else tuple(group)
    result={}
    for name in selected:
        pin=group[name]; path=Path(pin['path'])
        raw=read_fixed(path,1024**2)
        require(len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],'Exact underlying source input')
        result[name]=base64.b64encode(raw).decode('ascii')
    return result

def execute_phase(phase,plan,inputs):
    require(phase in PHASES,'Closed phase')
    closed=ROOT/'CONTROLS_CLOSED.json'
    closure=Slot(closed,CLOSURE_CAP,existing=closed.exists())
    slots={}; alias_slots={}
    try:
        runs=ROOT/'runs'
        if not runs.exists(): mkdir(runs)
        require(runs.resolve()==runs and set(p.name for p in runs.iterdir())<=set(PHASES),'Closed run directories')
        directory=runs/phase; require(not directory.exists(),'No overwrite/retry of a focused phase')
        mkdir(directory); allocate_slots(directory,slots)
        worker_name,mode,suite,count=PHASES[phase]
        spec=next(x for x in plan['suites'] if x['name']==suite)
        expected=list(spec['methods'])
        if phase=='mac-baseline': expected=list(spec['baseline']['methods'])
        elif phase=='accounting-omit-first': expected=[spec['counterfactual']['method']]
        require(len(expected)==count,'Exact reviewed method count')
        envelope={'mode':mode,'sources':sources_for(inputs,phase)}
        if not phase.startswith('mac-'):
            envelope['reportingReservation']={'phase':phase,'slots':[
                slots[n].descriptor() for n in ('worker.stdout','worker.stderr','worker.TERMINAL.json','DISPATCH_RESULT.json')
            ]+[closure.descriptor()]}
        else:
            alias=directory/'alias'; mkdir(alias); allocate_slots(alias,alias_slots,ALIAS_SLOT_SIZES)
            argv=['sudo','-u','ubuntu','-H','ssh','-G','-o','StrictHostKeyChecking=yes',
                  '-o','IdentitiesOnly=yes','-o','UpdateHostKeys=no','-o','ControlMaster=no',
                  '-o','ControlPath=none','scaleway-mac']
            raw,_,term=execute(argv,None,alias_slots,15)
            values={}
            for line in raw.decode('utf-8','strict').splitlines():
                key,_,value=line.partition(' ')
                if key in ('hostname','user','port','stricthostkeychecking','identitiesonly'):
                    require(key not in values,'Unique pinned SSH option'); values[key]=value
            require(term['returncode']==0 and term['terminalAbort'] is None and term['cleanupError'] is None
                    and values.get('hostname')=='62.210.195.226' and values.get('user')=='m1'
                    and values.get('port')=='22' and values.get('stricthostkeychecking') in ('true','yes')
                    and values.get('identitiesonly')=='yes','Existing exact pinned SSH identity')
            alias_slots['DISPATCH_RESULT.json'].fill(canonical({'status':'PINNED_ALIAS_VERIFIED','values':values}))
        worker=SEALED[worker_name]
        bootstrap=worker_bootstrap(worker,{'bytes':len(worker),'sha256':sha(worker)},envelope,expected)
        argv=SSH if phase.startswith('mac-') else ['sudo','-u','ubuntu','-H','/usr/bin/python3','-I','-B','-']
        raw,stderr,terminal=execute(argv,bootstrap,slots,150 if phase.startswith('mac-') else 210)
        expected_sources={n:{'bytes':len(base64.b64decode(b)),'sha256':sha(base64.b64decode(b))}
                          for n,b in envelope['sources'].items()}
        parsed=parse_worker(raw,expected,mode,suite,expected_sources)
        recheck_sources()
        accepted_transport=(terminal['returncode']==0 and terminal['terminalAbort'] is None
                            and terminal['cleanupError'] is None and not terminal.get('reportingErrors')
                            and parsed['complete'])
        candidate=phase in ('accounting-candidate','mac-candidate')
        status=('CANDIDATE_PASS' if candidate and accepted_transport and parsed.get('successful')
                else 'NEGATIVE_CONTROL_CAPTURED' if not candidate and accepted_transport
                else 'INCOMPLETE_OR_FAILED_CONTROL')
        if candidate and not parsed.get('successful'): status='INCOMPLETE_OR_FAILED_CONTROL'
        report={'schema':'otzaria.native116-focused-dispatch/2','phase':phase,'status':status,
                'workerSourceSHA256':sha(worker),'sourceInputs':{
                    n:{'bytes':len(base64.b64decode(b)),'sha256':sha(base64.b64decode(b))}
                    for n,b in envelope['sources'].items()},
                'child':terminal,'control':parsed,'originalOrForeignSourceModified':False,
                'authActions':0,'actualNative116Enumeration':0,'separateLegacy25Rerun':False}
        proof=slots['DISPATCH_RESULT.json'].fill(canonical(report))
        return {'status':status,'phase':phase,'proof':proof}
    except BaseException as error:
        report={'schema':'otzaria.native116-focused-dispatch/2','phase':phase,'status':'DISPATCH_ABORT',
                'terminalAbort':failure(error,'DISPATCH_SETUP_OR_VALIDATION'),'successful':False,
                'reservedSlots':{n:s.descriptor() for n,s in slots.items()},
                'allExpectedSlotsReserved':set(slots)==set(SLOT_SIZES),'noRetry':True}
        if 'DISPATCH_RESULT.json' in slots and not slots['DISPATCH_RESULT.json'].filled:
            slots['DISPATCH_RESULT.json'].fill(canonical(report))
        raise
    finally:
        for slot in list(slots.values())+list(alias_slots.values()): slot.close()
        closure.close()

def close_scope():
    closure=Slot(ROOT/'CONTROLS_CLOSED.json',CLOSURE_CAP,existing=True)
    try:
        guard(); recheck_sources()
        rows,allocated=scope_rows(hashes=True)
        require(allocated<=CAP,'Actual closed controls <=4MiB')
        raw=canonical({'entries':rows,'allocatedBytes':allocated})
        output=io.BytesIO()
        with gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0,compresslevel=6) as z: z.write(raw)
        compressed=output.getvalue()
        value={'schema':'otzaria.native116-focused-controls-closed/1','status':'EVIDENCE_FROZEN_NO_NATIVE_QUALIFICATION',
               'entryCount':len(rows),'allocatedBytesBeforeClosureShrink':allocated,
               'manifestBytes':len(raw),'manifestSHA256':sha(raw),
               'manifestGzipBytes':len(compressed),'manifestGzipSHA256':sha(compressed),
               'manifestGzipBase64':base64.b64encode(compressed).decode('ascii'),
               'closureSelfExcludedFromContentHash':True,'closureSelfIdentityIsBeforeFinalShrink':True,
               'atimeCapturedBeforeHashAndExcludedFromStability':True,
               'qualificationRequiresSuccessfulCloseResult':True,'noFurtherScopeWrites':True,
               'original25Rerun':False,'actualNativeTreeFitProven':False}
        envelope=canonical(value)
        require(len(envelope)<=CLOSURE_CAP,'Complete closure envelope exceeds reserved64KiB; no field omission')
        def verify_envelope(body):
            decoded_value=json.loads(body)
            require(canonical(decoded_value)==body and decoded_value==value,'Complete canonical closure envelope')
            encoded=base64.b64decode(decoded_value['manifestGzipBase64'],validate=True)
            require(len(encoded)==decoded_value['manifestGzipBytes'] and sha(encoded)==decoded_value['manifestGzipSHA256'],
                    'Full compressed closure length/hash')
            with gzip.GzipFile(fileobj=io.BytesIO(encoded),mode='rb') as z:
                decoded=z.read(len(raw)+1)
                require(z.read(1)==b'','Complete closure decompression EOF')
            require(len(decoded)==decoded_value['manifestBytes'] and sha(decoded)==decoded_value['manifestSHA256']
                    and decoded==raw,'Full original closure manifest byte equality')
            require(json.loads(decoded)=={'entries':rows,'allocatedBytes':allocated},
                    'Every closure entry and metadata field retained')
        verify_envelope(envelope)
        result=closure.fill(envelope)
        persisted=os.pread(closure.fd,len(envelope)+1,0)
        require(persisted==envelope,'Exact complete reserved closure readback')
        verify_envelope(persisted)
        return {'status':value['status'],'proof':result,'fullDecodedReadbackVerified':True,
                'entryCount':len(rows),'manifestBytes':len(raw),'manifestSHA256':sha(raw)}
    finally: closure.close()

def main():
    global DEADLINE,ORIGINAL_PARENT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-seal-sha256',required=True)
    parser.add_argument('--phase',choices=tuple(PHASES)+('close',),required=True)
    args=parser.parse_args()
    DEADLINE=time.monotonic()+270; ORIGINAL_PARENT=os.getppid()
    plan,inputs=validate_seal(args.source_seal_sha256)
    result=close_scope() if args.phase=='close' else execute_phase(args.phase,plan,inputs)
    print(json.dumps(result,separators=(',',':'),ensure_ascii=True))
    if result['status']=='INCOMPLETE_OR_FAILED_CONTROL': raise SystemExit(1)

if __name__=='__main__':
    main()
