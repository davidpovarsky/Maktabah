from pathlib import Path
import ast
import datetime
import hashlib
import json
import platform
import re
import subprocess
import sys
import time
import zipfile

root = Path(__file__).resolve().parent
archive = root / 'LINUX_SOURCE.zip'
raw = b''.join((root / f'chunk-{i}').read_bytes() for i in range(9))
assert len(raw) == 388072
assert hashlib.sha256(raw).hexdigest() == '0c98cac2c5a94a62309c46829fbca2e1283b67f541780b19f20bf986f9724959'
archive.write_bytes(raw)
source = root / 'source'
source.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    members = z.namelist()
    assert len(members) == len(set(members)) == 87
    for name in members:
        p = Path(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
    z.extractall(source)
manifest = json.loads((source / 'SOURCE_MANIFEST.json').read_text())
assert manifest['sourceCommit'] == 'c10ce8af00fbc1fc62910c1ac06ec7a0f3d79494'
assert set(members) == {row['path'] for row in manifest['files']} | {'SOURCE_MANIFEST.json'}

def verify_inputs():
    result = []
    for row in manifest['files']:
        value = (source / row['path']).read_bytes()
        digest = hashlib.sha256(value).hexdigest()
        assert len(value) == row['bytes'] and digest == row['canonicalSHA256'], row['path']
        result.append({'path': row['path'], 'bytes': len(value), 'sha256': digest})
    return result

before = verify_inputs()
(root / 'INPUTS_BEFORE.json').write_text(json.dumps(before, indent=2) + '\n')
test = 'Scripts/CI/test-runtime27-release-handoff.py'
tree = ast.parse((source / test).read_text())
expected = sorted((node.name, method.name) for node in tree.body if isinstance(node, ast.ClassDef)
                  for method in node.body if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef))
                  and method.name.startswith('test_'))
assert len(expected) == len(set(expected)) == 29
command = [sys.executable, '-X', 'utf8', test]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
monotonic_start = time.monotonic()
timed_out = False
with (root / 'stdout.log').open('wb') as stdout, (root / 'stderr.log').open('wb') as stderr:
    try:
        process = subprocess.run(command, cwd=source, stdout=stdout, stderr=stderr, timeout=90)
        returncode = process.returncode
    except subprocess.TimeoutExpired:
        timed_out = True
        returncode = None
finished = datetime.datetime.now(datetime.timezone.utc).isoformat()
elapsed = time.monotonic() - monotonic_start
after = verify_inputs()
assert after == before
(root / 'INPUTS_AFTER.json').write_text(json.dumps(after, indent=2) + '\n')
stderr = (root / 'stderr.log').read_text().replace('\r', '')
leaves = re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. ok$', stderr, re.MULTILINE)
actual = sorted((qualified.split('.')[-2], method) for method, qualified in leaves)
count = re.search(r'^Ran (\d+) tests in ', stderr, re.MULTILINE)
passed = (not timed_out and returncode == 0 and actual == expected
          and count is not None and count.group(1) == '29'
          and re.search(r'^OK$', stderr, re.MULTILINE) is not None)
report = {
    'status': 'PASS' if passed else 'FAIL',
    'sourceCommit': manifest['sourceCommit'],
    'sourceArchive': {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'CRC': 'PASS'},
    'command': command, 'cwd': str(source), 'platform': platform.platform(),
    'python': sys.version, 'executable': str(Path(sys.executable).resolve()),
    'startedAt': started, 'finishedAt': finished, 'elapsedSeconds': elapsed,
    'timeoutSeconds': 90, 'timedOut': timed_out, 'returncode': returncode,
    'expectedExactCases': expected, 'verifiedPassedCases': actual,
    'executed': int(count.group(1)) if count else None,
    'verifiedPass': len(actual), 'skipped': 0 if passed else 'UNVERIFIED',
    'inputFiles': len(before), 'inputHashesUnchanged': True,
    'sourceProjection': 'Complete exact canonical Git files; no test/source/guard substitution',
    'WindowsPriorAttempt': 'Preserved separately: 26 pass, 2 failures, 1 error; not relabelled',
    'scope': 'Original Python handoff synthetic-file/provenance contracts on Linux POSIX',
    'Apple': 'NOT_RUN', 'NativeUI': 'NOT_RUN', 'productionRelease': 'NOT_RUN'
}
(root / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items()
                  if key not in {'expectedExactCases', 'verifiedPassedCases'}}, indent=2))
if not passed:
    print(stderr)
raise SystemExit(0 if passed else 1)
