#!/usr/bin/env python3
"""Retire ONLY the separately authorized fixed five scopes after durable off-host ACK."""
from pathlib import Path
import base64
import datetime
import gzip
import hashlib
import inspect
import json
import os
import shutil
import stat
import sys
import types

EVIDENCE = Path('/Users/m1/builds/otzaria-wave3-five-scope-preservation-20261127.erim3ayq')
BASE = Path('/Users/m1/builds/otzaria-root-actions-acceptance-20261126.wjQnLNJl')
ROOTS = (BASE / 'session.Fc7x8AFS', BASE / 'session.QSzP0JWQ',
         BASE / 'session.T3iKxkwx', BASE / 'session.o3uwliGJ',
         BASE / 'actual-paired-production-release.Hguhbz1S/Maktabah/build/hq-stage2')
HEADER_SHA = '8a2e85baf405350e77bebb2cab20a4f430c55ceaddc8689893b5e34d831aa007'
PROOF_SHA = 'ef4ab6539a882c68df77ce8d0d349c2eeb83a2167bbb8b260cb6e2777ebc48a0'
SOURCE_SHA = '8726617f8a4af7cd4fbdada202d29b50b118ab2317a8134567d2934f097a0045'


def canonical(value): return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()


def load_module(name, filename, expected):
    p = EVIDENCE / filename; body = p.read_bytes()
    assert hashlib.sha256(body).hexdigest() == expected
    module = types.ModuleType(name); module.__file__ = str(p)
    exec(compile(body, str(p), 'exec'), module.__dict__)
    return module


def dependencies(inventory):
    p = EVIDENCE / 'DEPENDENCY_HOLDS_READONLY.json'
    assert inventory.digest(p) == '80b349aa3bb34aa5bf92835acd86a6d7e91f70e5d55927c198211926616db4a4'
    report = json.loads(p.read_bytes())
    assert report['roots'] == [str(root) for root in ROOTS]
    values = []
    for expected in report['fresh_sdk_dependencies_outside_exact_scopes']:
        path = Path(expected['path']); assert path.resolve() == path and not path.is_symlink()
        info = path.lstat(); assert stat.S_ISDIR(info.st_mode)
        assert info.st_dev == expected['device'] and info.st_ino == expected['inode']
        assert not any(path == root or path in root.parents or root in path.parents for root in ROOTS)
        values.append(dict(expected))
    return values


def main():
    envelope_raw = sys.stdin.buffer.readline(256 * 1024); envelope = json.loads(envelope_raw)
    proof_raw = base64.b64decode(envelope['proof_base64'], validate=True)
    source_raw = base64.b64decode(envelope['source_base64'], validate=True)
    current_raw = base64.b64decode(envelope['current_base64'], validate=True)
    assert hashlib.sha256(proof_raw).hexdigest() == PROOF_SHA
    assert hashlib.sha256(source_raw).hexdigest() == SOURCE_SHA
    assert hashlib.sha256(current_raw).hexdigest() == envelope['current_sha256']
    assert (EVIDENCE / 'COMPLETE_PRESERVATION_VERIFIED.json').read_bytes() == proof_raw
    assert (EVIDENCE / 'SOURCE_REVERIFIED.json').read_bytes() == source_raw
    proof, source, current = json.loads(proof_raw), json.loads(source_raw), json.loads(current_raw)
    assert proof['status'] == 'COMPLETE_FIVE_SCOPE_DIFFERENTIAL_AND_ALL_PRIOR_BINDINGS_VERIFIED_NOT_RETIRED'
    assert source['status'] == 'COMPLETE_FIVE_SCOPE_SOURCE_CONTENT_METADATA_REVERIFIED_PRESERVED_NOT_RETIRED'
    assert current['status'] == 'ALL_CURRENT_ARCHIVE_AND_RECEIPT_IDENTITIES_MATCH'
    assert source['roots'] == current['roots'] == [str(p) for p in ROOTS]
    assert source['complete_preservation_receipt_sha256'] == PROOF_SHA
    assert source['header_sha256'] == proof['header_sha256'] == HEADER_SHA
    assert not source['anything_deleted'] and not proof['anything_deleted']
    assert current['complete_preservation_sha256'] == PROOF_SHA and current['source_reverified_sha256'] == SOURCE_SHA
    assert current['new_archive']['archive_sha256'] == proof['new_archive_sha256']
    assert current['new_archive']['archive_bytes'] == proof['new_archive_bytes']
    assert current['archive_bindings'] == proof['archive_bindings']
    age = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(current['utc'])).total_seconds()
    assert 0 <= age <= 180
    inventory = load_module('fixed_five_inventory', 'five_scope.py',
        'b4763615ddabc8dde73be18a806447d61e096a2fb902093c28ca9409f89119d4')
    reverify = load_module('fixed_five_source_verification', 'reverify_five.py',
        '671463f970e1fcd78113754ff896b4dbbeb45ca4b5198ac3f4459e5c6000fd14')
    assert inventory.ROOTS == ROOTS
    header = inventory.load_header(EVIDENCE, HEADER_SHA); helper = inventory.helper()
    before_use = inventory.no_use(); outside = reverify.preserved_outside()
    assert outside == source['protected_outside_after']
    outside_files = reverify.protected_source_files()
    assert outside_files == source['protected_source_files_after']
    dependency_before = dependencies(inventory)
    heads = inventory.source_heads(); assert heads == header['source_heads'] == source['source_heads_after']
    expected_selected = {}
    for root in ROOTS[:4]:
        for relative in ('Maktabah.xcodeproj/project.pbxproj', 'Source/PrivacyInfo.xcprivacy'):
            path = root / 'runner/_work/Maktabah/Maktabah' / relative
            expected_selected[str(path.relative_to(BASE))] = None
    with gzip.open(EVIDENCE / 'entries.jsonl.gz', 'rb') as f:
        for line in f:
            row = json.loads(line)
            if row['path'] in expected_selected:
                assert row['type'] == 'file'
                expected_selected[row['path']] = row['sha256']
    assert all(expected_selected.values())
    selected = {}
    for relative, expected in expected_selected.items():
        path = BASE / relative; before = path.lstat()
        assert stat.S_ISREG(before.st_mode) and not path.is_symlink()
        selected[relative] = inventory.digest(path)
        assert selected[relative] == expected and helper.identity(before) == helper.identity(path.lstat())
    fresh_hashes = []; counts = []
    for root, scope in zip(ROOTS, header['scopes']):
        assert inventory.root_identity(root) == scope['root_identity']
        sha = hashlib.sha256(); count = 0
        for path, info in inventory.walk(root):
            sha.update(inventory.stat_line(helper, root, path, info)); count += 1
        fresh_hashes.append(sha.hexdigest()); counts.append(count)
    assert fresh_hashes == header['stat_inventory_sha256'] == source['stat_inventory_sha256']
    assert counts == [s['entries'] for s in header['scopes']]
    assert heads == inventory.source_heads() and reverify.preserved_outside() == outside
    after_use = inventory.no_use()
    before = {'status': 'EXACT_FIVE_SCOPE_CURRENT_STATE_VERIFIED_AWAITING_DURABLE_OFFHOST_ACK', 'utc': utc(),
              'roots': [str(p) for p in ROOTS], 'header_sha256': HEADER_SHA,
              'complete_preservation_sha256': PROOF_SHA, 'source_reverified_sha256': SOURCE_SHA,
              'current_archive_bindings_sha256': envelope['current_sha256'],
              'current_archive_bindings': current, 'source_heads': heads,
              'preserved_pbx_privacy_sha256': selected, 'entries_rechecked': counts,
              'stat_inventory_sha256': fresh_hashes, 'protected_outside_before': outside,
              'protected_source_files_before': outside_files, 'protected_sdk_dependencies_before': dependency_before,
              'dependency_hold_receipt_sha256': '80b349aa3bb34aa5bf92835acd86a6d7e91f70e5d55927c198211926616db4a4',
              'open_use_before': before_use, 'open_use_after': after_use,
              'free_before': inventory.capacity(), 'script_sha256': inventory.digest(Path(__file__)),
              'authorization': 'Root explicitly authorized only these five absolute paths after independent review of proofef4ab653, source8726617f and dependency80b349aa; no archive, other scope, held executable, foreign work, source or SDK build is authorized.',
              'anything_deleted': False, 'native_acceptance': 0, 'sdk_retry': False}
    raw = canonical(before); sys.stdout.buffer.write(raw); sys.stdout.buffer.flush()
    acknowledgement = json.loads(sys.stdin.buffer.readline(4096))
    expected_ack = {'ack': 'DURABLE_OFFHOST_EXACT_FIVE_SCOPE_PREDELETE', 'sha256': hashlib.sha256(raw).hexdigest(),
                    'complete_preservation_sha256': PROOF_SHA, 'source_reverified_sha256': SOURCE_SHA,
                    'current_archive_bindings_sha256': envelope['current_sha256']}
    assert acknowledgement == expected_ack
    assert inventory.no_use()['open_paths'] == []
    assert reverify.preserved_outside() == outside and inventory.source_heads() == heads
    assert reverify.protected_source_files() == outside_files and dependencies(inventory) == dependency_before
    for root, scope in zip(ROOTS, header['scopes']): assert inventory.root_identity(root) == scope['root_identity']
    assert shutil.rmtree.avoids_symlink_attacks
    parent_fds = {}
    outside_by_path = {row['path']: row for row in outside}
    for parent_path in {root.parent for root in ROOTS}:
        expected_parent = outside_by_path[str(parent_path)]
        fd = os.open(parent_path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        actual_parent = os.fstat(fd)
        assert (actual_parent.st_dev, actual_parent.st_ino, actual_parent.st_mode,
                actual_parent.st_uid, actual_parent.st_gid) == (
            expected_parent['device'], expected_parent['inode'], expected_parent['mode'],
            expected_parent['uid'], expected_parent['gid'])
        parent_fds[parent_path] = fd
    cwd_fd = os.open('.', os.O_RDONLY | os.O_DIRECTORY)
    removed = []; started = []
    try:
        # Pin EACH exact parent, including paired/Maktabah/build. Never recurse
        # through the compact or paired project parent merely to reach a scope.
        has_dir_fd = 'dir_fd' in inspect.signature(shutil.rmtree).parameters
        for root, scope in zip(ROOTS, header['scopes']):
            parent_fd = parent_fds[root.parent]
            if not has_dir_fd: os.fchdir(parent_fd)
            current_root = os.stat(root.name, dir_fd=parent_fd, follow_symlinks=False)
            original = scope['root_identity']
            assert (current_root.st_dev, current_root.st_ino, current_root.st_mode,
                    current_root.st_uid, current_root.st_gid) == (
                        original['device'], original['inode'], original['mode'], original['uid'], original['gid'])
            started.append(str(root))
            if has_dir_fd: shutil.rmtree(root.name, dir_fd=parent_fd)
            else: shutil.rmtree(root.name)
            try: os.stat(root.name, dir_fd=parent_fd, follow_symlinks=False)
            except FileNotFoundError: pass
            else: raise AssertionError('Authorized root still exists')
            removed.append(str(root))
        os.fchdir(cwd_fd)
        assert all(not os.path.lexists(root) for root in ROOTS)
        after = reverify.preserved_outside(); assert after == outside
        assert reverify.protected_source_files() == outside_files
        assert dependencies(inventory) == dependency_before
        result = {**before, 'status': 'RETIRED_ONLY_EXACT_FIVE_FULLY_PRESERVED_SCOPES', 'finished_at': utc(),
                  'anything_deleted': True, 'removed': removed, 'full_absence_verified': True,
                  'protected_outside_after': after, 'protected_identities_unchanged': True,
                  'protected_source_files_after': reverify.protected_source_files(),
                  'protected_sdk_dependencies_after': dependencies(inventory),
                  'parent_fd_pinned': True, 'fd_based_rmtree': True,
                  'predelete_receipt_sha256': hashlib.sha256(raw).hexdigest(),
                  'free_after': inventory.capacity()}
        result['concurrent_free_delta_bytes'] = result['free_after'] - result['free_before']
        result['free_delta_scope'] = 'Concurrent filesystem observation; not exclusive attribution.'
    except BaseException as error:
        result = {**before, 'status': 'EXACT_FIVE_SCOPE_RETIREMENT_ERROR', 'finished_at': utc(),
                  'anything_deleted': bool(started), 'removal_started': started, 'removed': removed,
                  'error': repr(error), 'roots_still_exist': [os.path.lexists(p) for p in ROOTS],
                  'predelete_receipt_sha256': hashlib.sha256(raw).hexdigest()}
        sys.stdout.buffer.write(canonical(result)); sys.stdout.buffer.flush()
        raise
    finally:
        os.fchdir(cwd_fd); os.close(cwd_fd)
        for fd in parent_fds.values(): os.close(fd)
    sys.stdout.buffer.write(canonical(result)); sys.stdout.buffer.flush()


if __name__ == '__main__': main()
