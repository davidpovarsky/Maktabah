from pathlib import Path
import ast,copy,datetime,hashlib,itertools,json,re,runpy,subprocess,sys,yaml
root=Path.cwd()
out=root/'build/apple55-native116-gates-20261120/final-controls-after-review'
out.mkdir(parents=True,exist_ok=False)
(out/'VALIDATION_SOURCE.py').write_bytes(Path(__file__).read_bytes())
base='f3401ec1597e1d882d2e2c6db9492ed211058712'
build=root/'build/apple55-native116-gates-20261120'
blob=lambda path:subprocess.check_output(['git','show',base+':'+path],cwd=root)
sha=lambda data:hashlib.sha256(data).hexdigest()
gate=runpy.run_path(str(root/'Scripts/CI/sefaria-toc-apple55.py'))
paths=gate['PRODUCTION']+[gate['APPENDIX'],gate['DRIVER'],gate['LANGUAGE_DRIVER'],gate['WRAPPER'],gate['INTERRUPTION_HELPER'],
 'Tests/CI/test_sefaria_toc_apple55.py','.github/workflows/sefaria-embedded-validation.yml',
 '.github/workflows/ios-build.yml','docs/hq-integration/runtime27/R27_CASES.json']
inputs={p:{'rawSHA256':sha((root/p).read_bytes()),'canonicalLFSHA256':sha((root/p).read_bytes().replace(b'\r\n',b'\n')),'bytes':(root/p).stat().st_size} for p in paths}
(out/'INPUTS_BEFORE.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
results=[]
def record(name,condition):
 assert condition,name
 results.append({'name':name,'passed':True})
edits=json.loads((build/'WORKFLOW_EDITS.json').read_text())
for row in edits:
 source=(root/row['path']).read_text(encoding='utf-8')
 if 'edits' in row:
  for old,new,count in reversed(row['edits']):
   assert source.count(new)==count,(row['path'],new)
   source=source.replace(new,old)
 else:
  assert source.count(row['addition'])==1
  source=source.replace(row['addition'],'',1)
 record('exact-inverse.'+row['path'],source.encode()==blob(row['path']))
source=(root/gate['DRIVER']).read_text(encoding='utf-8')
d=json.loads((build/'DRIVER_EDITS.json').read_text())
for old,new in reversed(d['additionalEdits']):
 assert source.count(new)==1
 source=source.replace(new,old)
for old,new in reversed(d['edits']):
 if new:
  assert source.count(new)==1
  source=source.replace(new,old)
 else:
  marker='        result["compile"]={"returncode":r.returncode,"seconds":time.monotonic()-start}\n'
  source=source.replace(marker,marker+old)
record('exact-inverse.transport-driver-hygiene',source.encode()==blob(gate['DRIVER']))
for p in gate['PRODUCTION']+[gate['APPENDIX']]:
 record('unchanged-original-fixture.'+p,(root/p).read_bytes().replace(b'\r\n',b'\n')==blob(p))
native_path='.github/workflows/sefaria-embedded-validation.yml'
before=yaml.safe_load(blob(native_path));after=yaml.safe_load((root/native_path).read_text(encoding='utf-8'))
record('workflow.original-job-set',list(before['jobs'])==list(after['jobs']))
def expression(value,inputs):
 if not isinstance(value,str):return value
 expression=value.strip()
 if expression.startswith('$'+'{{'):expression=expression[3:-2].strip()
 expression=re.sub(r'inputs\.([A-Za-z0-9_]+)',lambda m:repr(inputs.get(m.group(1),'')),expression)
 expression=re.sub(r'needs\.[A-Za-z0-9_-]+\.result',repr('success'),expression)
 expression=expression.replace('&&',' and ').replace('||',' or ')
 expression=re.sub(r'!(?!=)',' not ',expression)
 expression=re.sub(r'\btrue\b','True',expression);expression=re.sub(r'\bfalse\b','False',expression)
 return eval(expression,{'__builtins__':{}},{'always':lambda:True})
comparisons=0
keys=['books_updates_check_only','hq_stage2_focused','ui_sdk_check_only','run_production_release','run_simulator_tests']
for mode in ['off','probe','ui','release']:
 for bits in itertools.product([False,True],repeat=len(keys)):
  for reference in ['', 'a'*40]:
   for diagnostic in ['', 'Suite/testCase']:
    request=dict(zip(keys,bits));request.update(runtime27_mode=mode,source_ref=reference,ui_diagnostic_cases=diagnostic)
    for key,job in before['jobs'].items():
     assert bool(expression(job.get('if',True),request))==bool(expression(after['jobs'][key].get('if',True),request)),(key,request)
     comparisons+=1
    for field in ['timeout-minutes','name']:
     assert expression(before['jobs']['runtime27'][field],request)==expression(after['jobs']['runtime27'][field],request)
record('workflow.all-original-mode-job-admissions-preserved',comparisons==len(before['jobs'])*512)
request={key:False for key in keys};request.update(runtime27_mode='toc-transport',source_ref='',ui_diagnostic_cases='')
active=[key for key,job in after['jobs'].items() if expression(job.get('if',True),request)]
record('workflow.lightweight-only-original-runtime-job',active==['runtime27'])
steps=after['jobs']['runtime27']['steps']
original_next=next(s for s in steps if s.get('name')=='Inspect real Xcode27 tools or execute reviewed native cases')
record('workflow.lightweight-never-invokes-native-executor',not expression(original_next['if'],request))
index_gate=next(i for i,s in enumerate(steps) if s.get('run')=='python3 Scripts/CI/sefaria-toc-apple55.py')
index_native=steps.index(original_next)
record('workflow.gate-before-native-build',index_gate<index_native and 'continue-on-error' not in steps[index_gate])
record('workflow.lightweight-gate-required',expression(steps[index_gate]['if'],request))
conflict=steps[0]['env']['CONFLICT']
record('workflow.valid-lightweight-request-no-conflict',not expression(conflict,request))
request['run_simulator_tests']=True
record('workflow.lightweight-rejects-native-request',expression(conflict,request))
normal_before=yaml.safe_load(blob('.github/workflows/ios-build.yml'))
normal_after=yaml.safe_load((root/'.github/workflows/ios-build.yml').read_text(encoding='utf-8'))
record('normal.original-job-dependency-graph',list(normal_before['jobs'])==list(normal_after['jobs']) and all(normal_before['jobs'][key].get('needs')==normal_after['jobs'][key].get('needs') for key in normal_before['jobs']))
record('normal.both-app-builds-depend-on-gated-job',all('otzaria-framework' in normal_after['jobs'][key]['needs'] for key in ['simulator-build','device-build']))
normal_steps=normal_after['jobs']['otzaria-framework']['steps']
gate_step=next(s for s in normal_steps if s.get('run')=='python3 Scripts/CI/sefaria-toc-apple55.py')
record('normal.gate-cannot-ignore-failure','continue-on-error' not in gate_step and 'if' not in gate_step)
raw_upload=next(s for s in normal_steps if s.get('name')=='Retain complete Apple Foundation transport evidence including failure')
record('normal.raw-evidence-always-retained',raw_upload.get('if')=='always()' and raw_upload['with']['if-no-files-found']=='error')
manifest_path='docs/hq-integration/runtime27/R27_CASES.json'
old=json.loads(blob(manifest_path));new=json.loads((root/manifest_path).read_text(encoding='utf-8'))
added=new['execution_case_ids'][98:];inverse=copy.deepcopy(new)
for key in ['required_nonzero_cases','expected_per_device','scope','selected_scope_reason']:inverse[key]=old[key]
inverse['supplemental_cases']=inverse['supplemental_cases'][:-18]
inverse['execution_case_ids']=inverse['execution_case_ids'][:-18]
for old_group,group in zip(old['execution_groups'],inverse['execution_groups']):
 assert group['case_ids'][:len(old_group['case_ids'])]==old_group['case_ids']
 group['case_ids']=[x for x in group['case_ids'] if x not in set(added)]
del inverse['native116_preparation_20261120']
record('manifest.all98-and-every-prior-field-exact-inverse',inverse==old)
groups=runpy.run_path(str(root/'Scripts/CI/runtime27.py'))['execution_groups'](new)
record('manifest.exact116-seven-groups',len(new['execution_case_ids'])==116 and len(set(new['execution_case_ids']))==116 and len(groups)==7)
record('manifest.original-HID-only-window',[g['label'] for g in groups if g.get('hid_comparison')]==['11-window'])
for relative in ['Scripts/CI/runtime27.py','Scripts/CI/runtime27-release-manifest.json','Scripts/CI/run-faithful-ipad-matrix.py','Scripts/CI/hq-stage2-focused-apple.inputs.json']:
 record('unchanged-original-gate.'+relative,(root/relative).read_bytes().replace(b'\r\n',b'\n')==blob(relative))
command=[sys.executable,'-X','utf8','Tests/CI/test_sefaria_toc_apple55.py']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(command,capture_output=True,timeout=60)
(out/'python-controls.stdout.log').write_bytes(r.stdout);(out/'python-controls.stderr.log').write_bytes(r.stderr)
record('python-controls25-returncode',r.returncode==0)
record('python-controls25-exact-executed-inventory',b'Ran 25 tests' in r.stderr and r.stderr.rstrip().endswith(b'OK'))
after_inputs={p:{'rawSHA256':sha((root/p).read_bytes()),'canonicalLFSHA256':sha((root/p).read_bytes().replace(b'\r\n',b'\n')),'bytes':(root/p).stat().st_size} for p in paths}
record('all-inputs-unchanged-through-validation',inputs==after_inputs)
(out/'INPUTS_AFTER.json').write_text(json.dumps(after_inputs,indent=2),encoding='utf-8')
report={'status':'PASS','startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'command':command,'sourceControls':results,'originalModeAdmissionComparisons':comparisons,'pythonControlsExecuted':25,
 'native116':'NOT_RUN','AppleFoundation55':'NOT_RUN','finalApplicationSource':'PENDING','inputFiles':len(paths)}
(out/'RESULT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='sourceControls'}))
print('SOURCE_CONTROLS',len(results))
