"""Preserve v1; prepare one filesystem-portability assertion and v2 metadata."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / 'annotation-combined-core194-apple-20261120'
CANDIDATE = HERE / 'candidate'
OLD_BRANCH = 'codex/otzaria-annotation-core194-combined-apple-20261120'
NEW_BRANCH = 'codex/otzaria-annotation-core194-combined-apple-v2-20261120'
OLD_WORKFLOW = '.github/workflows/otzaria-annotation-core194-combined-apple.yml'
NEW_WORKFLOW = '.github/workflows/otzaria-annotation-core194-combined-apple-v2.yml'
OLD_DOCS = 'docs/hq-integration/annotation-combined-core194-apple-20261120/'
NEW_DOCS = 'docs/hq-integration/annotation-combined-core194-apple-v2-20261120/'
DRIVER = 'Scripts/CI/annotation-combined-core194-apple.py'
TESTS = 'Scripts/CI/test-annotation-combined-core194-apple.py'
CORE_DRIVER = 'tools/hq-cold-search-core-acceptance.py'
BINDING = 'Scripts/CI/annotation-combined-core194-apple.inputs.json'
CORE_MANIFEST = 'Tests/HQ/cold-search/CORE_INPUTS.json'


def js(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


assert not CANDIDATE.exists(), 'Do not overwrite a prepared candidate'
for name in ('candidate', 'base', 'original'):
    shutil.copytree(PRIOR / name, HERE / name,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
for name in ('MATERIALIZATION.json', 'ORIGINAL_VALIDATOR_BODY_PROOF.json'):
    shutil.copyfile(PRIOR / name, HERE / name)

changes = {}


def replace(relative, edits):
    path = CANDIDATE / relative
    before = path.read_bytes()
    after = before
    for old, new in edits:
        assert after.count(old.encode()) == 1, (relative, old)
        after = after.replace(old.encode(), new.encode(), 1)
    inverse = after
    for old, new in reversed(edits):
        assert inverse.count(new.encode()) == 1, (relative, new)
        inverse = inverse.replace(new.encode(), old.encode(), 1)
    assert inverse == before
    put(path, after)
    changes[relative] = {'before': pin(before), 'after': pin(after), 'whole_inverse_exact': True,
                         'edits': [{'before': old, 'after': new} for old, new in edits]}


replace(DRIVER, [(OLD_BRANCH, NEW_BRANCH), (OLD_WORKFLOW, NEW_WORKFLOW), (OLD_DOCS, NEW_DOCS)])
before_assertion = '            self.assertFalse((directory / "RESULT_after.json").exists())'
after_assertion = '            self.assertNotIn("RESULT_after.json", {entry.name for entry in directory.iterdir()})'
replace(TESTS, [(before_assertion, after_assertion)])
old_test_tree = ast.parse((PRIOR / 'candidate' / TESTS).read_text())
new_test_tree = ast.parse((CANDIDATE / TESTS).read_text())
ids = lambda tree: sorted(node.name for node in ast.walk(tree)
                         if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_'))
assert ids(old_test_tree) == ids(new_test_tree) and len(ids(new_test_tree)) == 40

old_workflow = (CANDIDATE / OLD_WORKFLOW).read_bytes()
assert old_workflow.count(OLD_BRANCH.encode()) == 1
new_workflow = old_workflow.replace(OLD_BRANCH.encode(), NEW_BRANCH.encode())
assert new_workflow.replace(NEW_BRANCH.encode(), OLD_BRANCH.encode()) == old_workflow
put(CANDIDATE / NEW_WORKFLOW, new_workflow)
(CANDIDATE / OLD_WORKFLOW).unlink()
old_reference = CANDIDATE / OLD_DOCS / 'reference/original-cloud-binding.json'
put(CANDIDATE / NEW_DOCS / 'reference/original-cloud-binding.json', old_reference.read_bytes())
old_reference.unlink()

# Reuse the prior authoring programs with only the new route literals. They
# rebind the same finite original metadata and keep every case/body/budget.
metadata_script = (PRIOR / 'prepare_metadata.py').read_text()
assert metadata_script.count(OLD_BRANCH) == metadata_script.count(OLD_WORKFLOW) == 1
metadata_script = metadata_script.replace(OLD_BRANCH, NEW_BRANCH).replace(OLD_WORKFLOW, NEW_WORKFLOW)
put(HERE / 'prepare_metadata.py', metadata_script.encode())
put(HERE / 'prepare_binding.py', (PRIOR / 'prepare_binding.py').read_bytes())
for script in ('prepare_metadata.py', 'prepare_binding.py'):
    result = subprocess.run([sys.executable, '-B', str(HERE / script)], capture_output=True, timeout=60)
    put(HERE / 'evidence' / (script + '.stdout.log'), result.stdout)
    put(HERE / 'evidence' / (script + '.stderr.log'), result.stderr)
    assert result.returncode == 0, (script, result.stderr.decode())

prior_core = (PRIOR / 'candidate' / CORE_DRIVER).read_bytes()
new_core = (CANDIDATE / CORE_DRIVER).read_bytes()
assert new_core.replace(NEW_BRANCH.encode(), OLD_BRANCH.encode()).replace(NEW_WORKFLOW.encode(), OLD_WORKFLOW.encode()) == prior_core
prior_manifest = json.loads((PRIOR / 'candidate' / CORE_MANIFEST).read_bytes())
new_manifest = json.loads((CANDIDATE / CORE_MANIFEST).read_bytes())
prior_support = next(row for row in prior_manifest['support_inputs'] if row['path'] == CORE_DRIVER)
current_support = next(row for row in new_manifest['support_inputs'] if row['path'] == CORE_DRIVER)
restored = json.loads(js(new_manifest))
for row in restored['support_inputs']:
    if row['path'] == CORE_DRIVER:
        row.clear(); row.update(prior_support)
assert restored == prior_manifest
old_core_hash = pin((PRIOR / 'candidate' / CORE_MANIFEST).read_bytes())['sha256']
new_core_hash = pin((CANDIDATE / CORE_MANIFEST).read_bytes())['sha256']
assert new_workflow.count(old_core_hash.encode()) == 1
new_workflow = new_workflow.replace(old_core_hash.encode(), new_core_hash.encode())
assert new_workflow.replace(NEW_BRANCH.encode(), OLD_BRANCH.encode()).replace(new_core_hash.encode(), old_core_hash.encode()) == old_workflow
put(CANDIDATE / NEW_WORKFLOW, new_workflow)

prior_binding = json.loads((PRIOR / 'candidate' / BINDING).read_bytes())
binding = json.loads((CANDIDATE / BINDING).read_bytes())
assert binding['application_source'] == prior_binding['application_source'] == 'bd855c02fcef94a732f584c5992aeacec6b1b21d'
assert binding['application_tree'] == prior_binding['application_tree'] == '3c08a3de2102dd80df64f79dd56035a689d26edb'
inverse_binding = json.loads(js(binding))
inverse_binding['route'] = prior_binding['route']
inverse_binding['source_pins'] = prior_binding['source_pins']
assert inverse_binding == prior_binding
renamed = {NEW_DOCS + 'reference/original-cloud-binding.json': OLD_DOCS + 'reference/original-cloud-binding.json'}
pin_changes = []
for path, item in binding['source_pins'].items():
    old_path = renamed.get(path, path)
    assert old_path in prior_binding['source_pins']
    if path != old_path or item != prior_binding['source_pins'][old_path]: pin_changes.append(path)
assert set(pin_changes) == {CORE_DRIVER, CORE_MANIFEST, NEW_DOCS + 'reference/original-cloud-binding.json'}
assert len(binding['source_pins']) == len(prior_binding['source_pins']) == 114
workflow_replacements = [{'before': OLD_BRANCH, 'after': NEW_BRANCH, 'count': 1},
                         {'before': old_core_hash, 'after': new_core_hash, 'count': 1}]
for relative in (DRIVER, BINDING, TESTS):
    old_hash = pin((PRIOR / 'candidate' / relative).read_bytes())['sha256']
    new_hash = pin((CANDIDATE / relative).read_bytes())['sha256']
    assert new_workflow.count(old_hash.encode()) == 2, relative
    new_workflow = new_workflow.replace(old_hash.encode(), new_hash.encode())
    workflow_replacements.append({'before': old_hash, 'after': new_hash, 'count': 2})
workflow_inverse = new_workflow
for item in reversed(workflow_replacements):
    assert workflow_inverse.count(item['after'].encode()) == item['count']
    workflow_inverse = workflow_inverse.replace(item['after'].encode(), item['before'].encode())
assert workflow_inverse == old_workflow
put(CANDIDATE / NEW_WORKFLOW, new_workflow)

old_files = {p.relative_to(PRIOR / 'candidate').as_posix(): p.read_bytes()
             for p in (PRIOR / 'candidate').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
new_files = {p.relative_to(CANDIDATE).as_posix(): p.read_bytes()
             for p in CANDIDATE.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
changed_common = {p for p in old_files.keys() & new_files.keys() if old_files[p] != new_files[p]}
assert changed_common == {DRIVER, TESTS, CORE_DRIVER, CORE_MANIFEST, BINDING}
assert old_files.keys() - new_files.keys() == {OLD_WORKFLOW, OLD_DOCS + 'reference/original-cloud-binding.json'}
assert new_files.keys() - old_files.keys() == {NEW_WORKFLOW, NEW_DOCS + 'reference/original-cloud-binding.json'}
proof = {'status': 'EXACT_ONE_ASSERTION_PLUS_ROUTE_METADATA_ONLY', 'application_source': binding['application_source'],
         'application_tree': binding['application_tree'], 'branch': NEW_BRANCH, 'workflow': NEW_WORKFLOW,
         'changes': changes, 'workflow_inverse': 'exact branch, Core manifest SHA and three changed bootstrap file hashes only',
         'workflow_replacements': workflow_replacements,
         'workflow_Core_manifest_pin': {'before': old_core_hash, 'after': new_core_hash},
         'Core_driver_inverse': 'exact branch/workflow only', 'Core_manifest_inverse': 'exact one driver self-pin only',
         'binding_changed_only': ['route', 'source_pins'], 'changed_source_pins': sorted(pin_changes),
         'original_control_ids': ids(new_test_tree), 'original_control_count': 40,
         'all_other_candidate_file_bytes_unchanged': True, 'production_or_Swift_source_changed': False,
         'Core_cases_or_classifiers_changed': False, 'budgets_changed': False, 'Swift_executed': 0, 'Native_executed': 0,
         'cause': 'Actual case-insensitive Mac lookup resolves RESULT_after.json to the correctly named RESULT_AFTER.json. Directory-entry strings retain actual spelling.',
         'old_Mac_run': 44821378113, 'old_component_job': 136582815054, 'old_Mac_controls': {'passed': 39, 'failed': 1, 'errors': 0, 'skipped': 0}}
put(HERE / 'V2_INVERSE_PROOF.json', js(proof))
patch = []
for path in sorted(changed_common):
    patch.extend(difflib.unified_diff(old_files[path].decode().splitlines(True), new_files[path].decode().splitlines(True),
                                     'prior-v1/' + path, 'candidate-v2/' + path))
patch.extend(difflib.unified_diff(old_workflow.decode().splitlines(True), new_workflow.decode().splitlines(True),
                                 'prior-v1/' + OLD_WORKFLOW, 'candidate-v2/' + NEW_WORKFLOW))
put(HERE / 'V2_SOURCE.patch', ''.join(patch).encode())
print(json.dumps({'status': proof['status'], 'tests': 40, 'source_pins': 114,
                  'changed_common_files': sorted(changed_common), 'test_after': pin((CANDIDATE / TESTS).read_bytes())}, indent=2))
