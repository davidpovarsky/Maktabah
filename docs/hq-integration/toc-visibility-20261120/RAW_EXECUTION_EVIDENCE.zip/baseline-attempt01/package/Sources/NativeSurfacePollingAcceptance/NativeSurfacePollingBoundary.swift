import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

// Explicit UIKit geometry/lifecycle doubles. This fixture does not render a
// native window. The driver inserts complete production methods below, without
// changing their geometry predicate, observation loop, cancellation or deadline.
@MainActor class UIView {
    var bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
    var convertedBounds = CGRect(x: 120, y: 0, width: 100, height: 100)
    var isHidden = false
    var alpha: CGFloat = 1
    weak var superview: UIView?
    weak var attachedWindow: UIWindow?
    var window: UIWindow? { attachedWindow ?? superview?.window }
    func convert(_ value: CGRect, to window: UIWindow) -> CGRect { convertedBounds }
    func isDescendant(of ancestor: UIView) -> Bool {
        var current: UIView? = self
        while let value = current {
            if value === ancestor { return true }
            current = value.superview
        }
        return false
    }
}
@MainActor final class UIWindow: UIView {
    var windowScene: FixtureWindowScene?
    var rootViewController: UIViewController?
}
@MainActor final class UIViewController {
    let view: UIView
    var presentedViewController: UIViewController?
    init(view: UIView) { self.view = view }
}
@MainActor final class FixtureWindowScene {
    enum Activation: Int { case foregroundActive = 0, background = 2 }
    struct Session { var persistentIdentifier: String }
    var activationState = Activation.foregroundActive
    var session: Session
    init(id: String) { session = .init(persistentIdentifier: id) }
}

enum NativeSurfaceWitness {
    public struct Evidence: Sendable, Equatable {
        public let sceneID: UIStableID
        public let surface: NativeSurfaceState
        public let isVisible: Bool
        public let submissionID: UUID?
    }
}
@MainActor final class FixtureMarker: UIView {
    var surface: NativeSurfaceState?
    var submissionID: UUID?
    var hasAppeared = true
    var diagnose: (@MainActor (String) -> Void)?
    private var previousDiagnostic: String?
    fileprivate func currentEvidence() -> Evidence? {
            guard let window, let scene = window.windowScene,
                  let surface, let id = UIStableID(rawValue: scene.session.persistentIdentifier) else {
                diagnostic("attached=0 appeared=\(hasAppeared)"); return nil
            }
            let target = convert(bounds, to: window), intersection = target.intersection(window.bounds)
            let area = target.width * target.height
            var visible = hasAppeared && scene.activationState == .foregroundActive && !window.isHidden
                && !bounds.isEmpty && area.isFinite && area > 0 && !intersection.isNull
                && intersection.width * intersection.height >= area * 0.98
            var current: UIView? = self
            var effectiveAlpha: CGFloat = 1
            while let view = current {
                visible = visible && !view.isHidden
                effectiveAlpha *= view.alpha
                current = view.superview
            }
            visible = visible && effectiveAlpha >= 0.95
            // Do not acknowledge a background destination under a native modal.
            var top = window.rootViewController
            while let presented = top?.presentedViewController { top = presented }
            if let top, top !== window.rootViewController, !isDescendant(of: top.view) { visible = false }
            diagnostic("attached=1 appeared=\(hasAppeared) activation=\(scene.activationState.rawValue) bounds=\(!bounds.isEmpty) contained=\(!intersection.isNull && intersection.width * intersection.height >= area * 0.98) alpha=\(effectiveAlpha >= 0.95) modal=\(top !== window.rootViewController) visible=\(visible) pending=\(submissionID != nil)")
            return Evidence(sceneID: id, surface: surface, isVisible: visible, submissionID: submissionID)
        }
    private func diagnostic(_ value: String) {
            guard value != previousDiagnostic else { return }
            previousDiagnostic = value; diagnose?(value)
        }
    func readActualEvidence() -> NativeSurfaceWitness.Evidence? { currentEvidence() }
}

@MainActor final class OtzariaFileLogger {
    static let shared = OtzariaFileLogger()
    private(set) var messages: [String] = []
    func log(_ value: String) { messages.append(value) }
}
@MainActor final class FixtureReaderProjection {
    var rendered = true
    func hasRenderedReaderEvidence(sceneID: UIStableID) -> Bool { rendered }
}
@MainActor final class FixtureNoteOwner {
    var visible = true
    func validateVisible() throws {
        guard visible else { throw UIRouteError(.unavailable, "fixture_note_not_visible") }
    }
}

// Boundary state is explicit. Complete actual wait/observe/end methods are
// inserted, while public Core/Registry/Host packages are compiled unchanged.
@MainActor final class PollingSceneFixture {
    let sceneID: UIStableID
    let presentation: NativePresentationObserver
    var submissionID: UUID?
    var mounted = true
    var foreground = true
    var isPresentationReady = true
    var command: UISceneCommand?
    var visible: [UIDestinationID: NativeSurfaceWitness.Evidence] = [:]
    var visibilityChecks: [UIDestinationID: @MainActor () -> NativeSurfaceWitness.Evidence?] = [:]
    let readerProjection = FixtureReaderProjection()
    var project: @MainActor () throws -> FixtureReaderProjection { { self.readerProjection } }
    var noteDraftBinding: FixtureNoteOwner? = FixtureNoteOwner()
    var retainedSearchField: AnyObject?
    var inspectorBinding: AnyObject?
    private(set) var observationRevisions = 0

    init(sceneID: UIStableID) {
        self.sceneID = sceneID
        presentation = NativePresentationObserver(sceneID: sceneID)
    }
    func nativeStateChanged() throws { observationRevisions += 1 }
    func beginFixtureSubmission(_ value: UISceneCommand) throws {
        try presentation.begin(value)
        command = value
        submissionID = value.invocation.requestId
    }
    func observeVisibility(for destination: UIDestinationID, check: @escaping @MainActor () -> NativeSurfaceWitness.Evidence?) {
        visibilityChecks[destination] = check
    }
    func observe(_ evidence: NativeSurfaceWitness.Evidence) {
        guard mounted, evidence.sceneID == sceneID else { return }
        if evidence.isVisible, evidence.surface.destination.rawValue == "native.reader.noteDraft",
           (try? noteDraftBinding?.validateVisible()) == nil {
            if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
            return
        }
        if evidence.isVisible, evidence.surface.destination.rawValue == "native.reader",
           (try? project().hasRenderedReaderEvidence(sceneID: sceneID)) != true {
            if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
            return
        }
        #if DEBUG
        if evidence.submissionID != nil {
            let matches = command.map { evidence.surface.observedRoute(for: $0, backend: $0.invocation.snapshot) == $0.route.route } ?? false
            OtzariaFileLogger.shared.log("[NativeSurfaceObservation] destination=\(evidence.surface.destination.rawValue) visible=\(evidence.isVisible) matches=\(matches)")
        }
        #endif
        let prior = visible[evidence.surface.destination]
        if evidence.isVisible { visible[evidence.surface.destination] = evidence }
        else { visible.removeValue(forKey: evidence.surface.destination) }
        if prior != visible[evidence.surface.destination] { try? nativeStateChanged() }
        guard evidence.isVisible, let requestID = evidence.submissionID else { return }
        presentation.report(.init(sceneID: evidence.sceneID, submissionID: requestID, surface: evidence.surface))
    }
    func waitUntilVisible(_ command: UISceneCommand) async throws -> NativeSurfaceState {
        // A container's deduplicated layout callback can precede TextKit's
        // paint/scroll restoration. Observe that same live UIKit witness only
        // while this original reader request is waiting; never echo the route.
        let readerObservation: Task<Void, Never>?
        if ["native.reader", "native.reader.noteDraft"].contains(command.route.route.destination.rawValue) {
            readerObservation = Task { @MainActor [weak self] in
                while !Task.isCancelled {
                    guard let self, mounted, submissionID == command.invocation.requestId else { return }
                    if let actual = visibilityChecks[command.route.route.destination]?() { observe(actual) }
                    do { try await Task.sleep(for: .milliseconds(33)) } catch { return }
                }
            }
        } else { readerObservation = nil }
        defer { readerObservation?.cancel() }
        do { return try await presentation.wait(for: command).surface }
        catch {
            #if DEBUG
            OtzariaFileLogger.shared.log("[NativePresentationWait] code=\((error as? UIRouteError)?.code ?? (error is CancellationError ? "cancelled" : "unavailable")) mounted=\(mounted) foreground=\(foreground) ready=\(isPresentationReady)")
            #endif
            throw error
        }
    }
    func endObservation(requestID: UUID) {
        guard submissionID == requestID else { return }
        presentation.end(requestID: requestID); submissionID = nil
        // Keep only the independently observed surface. Clear private request
        // metadata after its owner has validated the complete visible receipt.
        command = nil; retainedSearchField = nil; inspectorBinding = nil
    }
}

@MainActor final class SurfacePollingScenario {
    let destination: UIDestinationID
    let sceneID = UIStableID(rawValue: "surface-polling.scene")!
    let session: PollingSceneFixture
    let window = UIWindow()
    let rootView = UIView()
    let ancestor = UIView()
    let marker = FixtureMarker()
    let command: UISceneCommand
    let expected: NativeSurfaceState
    private(set) var reads = 0
    private(set) var callbacks = 0
    var diagnostics: [String] = []

    init(_ raw: String, deadlineMilliseconds: UInt64 = 700) throws {
        destination = UIDestinationID(rawValue: raw)!
        session = PollingSceneFixture(sceneID: sceneID)
        let state = UIStateSpec(workspaceID: .init(rawValue: "original.workspace")!,
                                profileID: .init(rawValue: "original.profile")!)
        let route = RouteSpec(destination: destination, backend: .otzaria, state: state)
        let registry = try UIDestinationRegistry(descriptors: [
            .init(id: destination, title: "Boundary surface", implementation: .implemented,
                  supportedBackends: [.otzaria], presentations: [.currentTab]),
        ])
        let snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 7)
        command = try UISceneCommand(route: registry.validate(route),
            invocation: .init(requestId: route.requestId, snapshot: snapshot,
                              deadlineUptimeNanoseconds: SystemActionClock().now() + deadlineMilliseconds * 1_000_000),
            scene: .init(sceneID: sceneID, revision: 10, backendSnapshot: snapshot))
        // Independent observed model fixture; this is not rebuilt by a poll.
        expected = .init(destination: destination, presentation: .init(), content: nil, state: state, focus: nil)
        window.windowScene = .init(id: sceneID.rawValue)
        rootView.attachedWindow = window
        window.rootViewController = .init(view: rootView)
        ancestor.superview = rootView
        marker.superview = ancestor
        marker.surface = expected
        marker.submissionID = command.invocation.requestId
        marker.diagnose = { [weak self] in self?.diagnostics.append($0) }
        session.observeVisibility(for: destination) { [weak self] in
            guard let self else { return nil }
            reads += 1
            return marker.readActualEvidence()
        }
        try session.beginFixtureSubmission(command)
    }

    func layoutCallback() {
        callbacks += 1
        reads += 1
        if let evidence = marker.readActualEvidence() { session.observe(evidence) }
    }
    func makeGeometryVisible() { marker.convertedBounds = CGRect(x: 0, y: 0, width: 100, height: 100) }
    func startWait() -> Task<NativeSurfaceState, any Error> {
        Task { @MainActor in try await session.waitUntilVisible(command) }
    }
    func finishOriginal() { session.endObservation(requestID: command.invocation.requestId) }
}
