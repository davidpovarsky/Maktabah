from pathlib import Path
import hashlib,json,difflib,datetime
base_root=Path('/workspace/scratch/8c31d602ec0a/native98-profilecolor-20261120')
target=Path('/workspace/scratch/8c31d602ec0a/native98-groups100-root-review-20261120')
target.mkdir(exist_ok=True)
matches=[p for p in base_root.glob('*.swift') if hashlib.sha256(p.read_bytes()).hexdigest()=='a61c37fdb602c466f2e6925f22726feb2c253247007ecaa9ddaf919fba9daeee']
assert len(matches)==1,[str(p) for p in matches]
original=matches[0].read_text()
candidate=original
helper='''@MainActor
private enum GroupStressSnapshot {
    // All attributes below come from one actual XCTest snapshot. No snapshot
    // survives a tap, workspace transition, or predicate evaluation.
    static func descendants(of root: any XCUIElementSnapshot) -> [any XCUIElementSnapshot] {
        var result: [any XCUIElementSnapshot] = []
        for child in root.children {
            result.append(child)
            result.append(contentsOf: descendants(of: child))
        }
        return result
    }

    static func matches(_ element: any XCUIElementSnapshot, identifying name: String) -> Bool {
        // Preserve XCUIElementQuery's string-subscript identifying properties.
        element.identifier == name || element.title == name || element.label == name
            || element.value as? String == name || element.placeholderValue == name
    }

    static func documentCards(under overview: any XCUIElementSnapshot) -> [any XCUIElementSnapshot] {
        @MainActor
        func visit(_ node: any XCUIElementSnapshot, insideCollection: Bool) -> [any XCUIElementSnapshot] {
            var result: [any XCUIElementSnapshot] = []
            for child in node.children {
                if insideCollection, child.elementType == .cell,
                   child.identifier.hasPrefix("tab-switcher-grid-cell-") {
                    result.append(child)
                }
                result.append(contentsOf: visit(child, insideCollection:
                    insideCollection || child.elementType == .collectionView))
            }
            return result
        }
        // The original scope is overview.collectionViews.cells, not all cards
        // anywhere in the app. Visit each descendant once even for nested lists.
        return visit(overview, insideCollection: false)
    }

    static func finitePositive(_ frame: CGRect) -> Bool {
        !frame.isNull && !frame.isInfinite && !frame.isEmpty
            && frame.minX.isFinite && frame.minY.isFinite
            && frame.width.isFinite && frame.height.isFinite
    }
}

'''
anchor='@MainActor\nprivate final class GroupStressNativeObservation {'
assert candidate.count(anchor)==1
candidate=candidate.replace(anchor,helper+anchor,1)
old_observer='''        let overview = application.descendants(matching: .any)["study-groups-overview"]
        guard overview.exists, !application.alerts["לא ניתן לשנות את סביבת הלימוד"].exists else { return nil }
        let segments = application.segmentedControls["study-group-selector"]
        let control = segments.exists ? segments : application.buttons["study-group-selector"]
        guard control.exists, control.isEnabled, control.isHittable,
              control.value as? String == name else { return nil }
        let cards = overview.collectionViews.cells.matching(NSPredicate(
            format: "identifier BEGINSWITH %@", "tab-switcher-grid-cell-"))
        guard cards.count == 1 else { return nil }
        let card = cards.element(boundBy: 0)
        guard card.identifier == "tab-switcher-grid-cell-" + current.document.session.id.uuidString,
              card.isSelected, card.isHittable else { return nil }
'''
new_observer='''        guard let snapshot = try? application.snapshot() else { return nil }
        let elements = GroupStressSnapshot.descendants(of: snapshot)
        let overviews = elements.filter { GroupStressSnapshot.matches($0, identifying: "study-groups-overview") }
        guard overviews.count == 1, let overviewSnapshot = overviews.first,
              !elements.contains(where: {
                  $0.elementType == .alert
                      && GroupStressSnapshot.matches($0, identifying: "לא ניתן לשנות את סביבת הלימוד")
              }) else { return nil }
        let segments = elements.filter {
            $0.elementType == .segmentedControl && GroupStressSnapshot.matches($0, identifying: "study-group-selector")
        }
        let controls = segments.isEmpty ? elements.filter {
            $0.elementType == .button && GroupStressSnapshot.matches($0, identifying: "study-group-selector")
        } : segments
        guard controls.count == 1, let controlSnapshot = controls.first,
              controlSnapshot.isEnabled, controlSnapshot.value as? String == name else { return nil }
        let cards = GroupStressSnapshot.documentCards(under: overviewSnapshot)
        let expectedCardID = "tab-switcher-grid-cell-" + current.document.session.id.uuidString
        guard cards.count == 1, let cardSnapshot = cards.first,
              cardSnapshot.identifier == expectedCardID, cardSnapshot.isSelected else { return nil }

        // Hittability is a live XCUIElement property, not a frame approximation
        // or snapshot attribute. Keep both original real hit-test requirements.
        let overview = application.descendants(matching: .any)["study-groups-overview"]
        let control = controlSnapshot.elementType == .segmentedControl
            ? application.segmentedControls["study-group-selector"]
            : application.buttons["study-group-selector"]
        let card = overview.collectionViews.cells.matching(NSPredicate(
            format: "identifier == %@", expectedCardID)).element
        guard control.isHittable, card.isHittable else { return nil }
'''
assert candidate.count(old_observer)==1
candidate=candidate.replace(old_observer,new_observer,1)
old_select='''        let selector = app.segmentedControls["study-group-selector"]
        if selector.exists {
            XCTAssertTrue(selector.isEnabled)
            let targets = selector.buttons.matching(NSPredicate(format: "label == %@", name))
            XCTAssertEqual(targets.count, 1)
            tap(targets.element(boundBy: 0))
        } else {
'''
new_select='''        guard let snapshot = try? app.snapshot() else {
            XCTFail("Require a fresh actual app snapshot before the original group action")
            return
        }
        let elements = GroupStressSnapshot.descendants(of: snapshot)
        let selectors = elements.filter {
            $0.elementType == .segmentedControl && GroupStressSnapshot.matches($0, identifying: "study-group-selector")
        }
        if !selectors.isEmpty {
            guard selectors.count == 1, let selectorSnapshot = selectors.first,
                  selectorSnapshot.isEnabled else {
                XCTFail("Require the unique enabled original segmented group selector")
                return
            }
            let targets = GroupStressSnapshot.descendants(of: selectorSnapshot).filter {
                $0.elementType == .button && $0.label == name
            }
            guard targets.count == 1, let target = targets.first,
                  let windowSnapshot = elements.first(where: { $0.elementType == .window }),
                  [selectorSnapshot.frame, target.frame, windowSnapshot.frame].allSatisfy({ GroupStressSnapshot.finitePositive($0) }),
                  selectorSnapshot.frame.contains(target.frame),
                  windowSnapshot.frame.contains(target.frame) else {
                XCTFail("Require the exact original group button wholly inside its selector and actual window")
                return
            }
            let selector = app.segmentedControls["study-group-selector"]
            let liveTarget = selector.buttons.matching(NSPredicate(format: "label == %@", name)).element
            let window = app.windows.firstMatch
            guard liveTarget.isHittable, liveTarget.frame == target.frame,
                  window.frame == windowSnapshot.frame else {
                XCTFail("The original group button and window must remain live and match the fresh snapshot")
                return
            }
            // A real XCTest tap at the same validated button midpoint, relative
            // to its original window. Preserve ordinary XCTest idle handling.
            window.coordinate(withNormalizedOffset: CGVector(dx: 0, dy: 0))
                .withOffset(CGVector(dx: target.frame.midX - windowSnapshot.frame.minX,
                                     dy: target.frame.midY - windowSnapshot.frame.minY)).tap()
        } else {
'''
assert candidate.count(old_select)==1
candidate=candidate.replace(old_select,new_select,1)
old_timing='''            selectOriginalStressGroup(named: target.name)
            workspace = try waitForOriginalGroup(named: target.name, at: url,
                                                  sceneID: original.sceneID, afterRevision: workspace.revision)
            let current = try XCTUnwrap(workspace.current)
'''
new_timing='''            selectOriginalStressGroup(named: target.name)
            let selectionReturnedAt = ProcessInfo.processInfo.systemUptime
            workspace = try waitForOriginalGroup(named: target.name, at: url,
                                                  sceneID: original.sceneID, afterRevision: workspace.revision)
            let observationReturnedAt = ProcessInfo.processInfo.systemUptime
            observation["automationSelectionElapsedSeconds"] = selectionReturnedAt - start
            observation["automationObservationElapsedSeconds"] = observationReturnedAt - selectionReturnedAt
            let current = try XCTUnwrap(workspace.current)
'''
assert candidate.count(old_timing)==1
candidate=candidate.replace(old_timing,new_timing,1)
inverse=candidate.replace(new_timing,old_timing,1).replace(new_select,old_select,1).replace(new_observer,old_observer,1).replace(helper+anchor,anchor,1)
assert inverse==original
# These complete regions are explicitly unchanged.
for left,right in [
 ('    private func chooseProfileColor(named name: String)', '\n    private func '),
 ('    private func assertOriginalGroupMembership(', '\n}\n'),
 ('    private func verifiedGroupStressSidecar()', '\n    private func readGroupStressWorkspace'),
 ('    private func captureGroupApplicationMetrics(', '\n    @MainActor\n    private func verifiedGroupStressSidecar')]:
 start=original.index(left);end=original.find(right,start+len(left))
 assert end>start
 assert original[start:end] in candidate,left
assert candidate.count('for step in 1...100')==original.count('for step in 1...100')==1
assert candidate.count('XCTWaiter.wait(for: [ready], timeout: 15)')==original.count('XCTWaiter.wait(for: [ready], timeout: 15)')
import re
assert re.findall(r'func (test\w+)\(',candidate)==re.findall(r'func (test\w+)\(',original)
(target/'Faithful.baseline.swift').write_bytes(original.encode())
(target/'Faithful.candidate.swift').write_bytes(candidate.encode())
patch=''.join(difflib.unified_diff(original.splitlines(True),candidate.splitlines(True),fromfile='a/Maktabah-iOSUITests/FaithfulReaderUIAcceptanceTests.swift',tofile='b/Maktabah-iOSUITests/FaithfulReaderUIAcceptanceTests.swift'))
(target/'PROPOSED.patch').write_bytes(patch.encode())
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':'0a493e0a362e88405fabe7a08ff60fb51820496f','baseline_sha256':hashlib.sha256(original.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'exact_inverse':True,'same_test_ids':True,'original_100_transitions_and_membership_and_cold_oracles':True,'shared_tap_unchanged':True,'profile_color_candidate_preserved':True,'production_source_changes':0,'timeouts_changed':0,'native_rerun':'NOT_RUN','apple_typecheck':'NOT_RUN','syntax_parse':'NOT_RUN','scope':'One fresh real AX snapshot per observation/selection; exact scoped ownership, both live post-state hittability checks, real window-relative midpoint tap, and passive automation phase timing only'}
(target/'CANDIDATE_SOURCE_CHECK.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result))

