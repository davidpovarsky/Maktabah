import Foundation
@main struct DiagnosticControls {
    @MainActor static func surface() async throws -> SefariaEmbeddedSurfaceAcceptanceEvidence {
        Boundary.surfaceCalls += 1
        let epoch = SefariaJSRPCBridge.shared.sessionEpoch
        return .init(nativeReceiptID: UUID(), nativeSceneID: "synthetic-scene", nativeHostToken: UUID(),
            runtimeRevision: 1, originalSurface: .init(contract: "chavrusa.original-rn-surface.v1",
            component: "ReaderApp", upstreamSHA: "2fd173a5a3bd32d94a9ba1222e4e32a37f6bd23c",
            surfaceID: UUID(), mountID: UUID(), sceneID: "synthetic-scene", epoch: epoch, nonce: UUID(),
            layout: .init(width: 800, height: 600, revision: 1)))
    }
    #if CANDIDATE_DIAGNOSTIC
    @MainActor static func reader(_ locator: TextLocator, _ epoch: UInt64) async throws -> SefariaEmbeddedAcceptanceDiagnosticRunner.ReaderEvidence {
        Boundary.nativeCalls += 1; Boundary.nativeLocators.append(locator)
        if Boundary.scenario == "native_provider_error" { throw SefariaRPCError(code: "NATIVE_PROVIDER_UNAVAILABLE", message: "Synthetic native route failure") }
        if Boundary.scenario == "reader_epoch_changed" { SefariaJSRPCBridge.shared.sessionEpoch += 1 }
        if Boundary.scenario == "reader_backend_changed" { BackendCoordinator.shared.activeBackendID = .otzaria }
        let foreign = TextLocator(backend: .otzaria, workKey: "Other", position: .canonicalRef("Other 1:1"))
        return .init(nativeRequestID: UUID(),
            nativeSceneID: Boundary.scenario == "reader_empty_scene" ? "" : "synthetic-scene",
            backendID: "sefariaEmbedded",
            sessionEpoch: Boundary.scenario == "reader_stale_epoch" ? epoch - 1 : epoch,
            backendGeneration: 2, basedOnSceneRevision: 10,
            appliedSceneRevision: Boundary.scenario == "reader_unadvanced_revision" ? 10 : 11,
            requestedLocator: Boundary.scenario == "reader_wrong_locator" ? foreign : locator,
            sectionLocator: .init(backend: .sefariaEmbedded, workKey: "Exodus", position: .canonicalRef("Exodus 2")),
            focusLocator: Boundary.scenario == "reader_foreign_focus" ? foreign : locator,
            displayRef: "Exodus 2",
            segmentCount: Boundary.scenario == "reader_empty_segments" ? 0 : 1)
    }
    #endif
    @MainActor static func main() async {
        let cases: [(String, String, String?)] = [
            ("healthy", "SUCCESS", nil),
            ("wrong_current_epoch", "FAILURE", "GENERATION_CHECK_FAILED"),
            ("stale_accepted", "FAILURE", "STALE_GENERATION_ACCEPTED"),
            ("stale_other_error", "FAILURE", "TIMEOUT"),
            ("search_error", "FAILURE", "REMOTE_UNAVAILABLE"),
            ("search_cancelled", "FAILURE", "UNKNOWN_ERROR"),
            ("empty_search", "FAILURE", "SEARCH_LIVE_NO_VALID_HIT"),
            ("invalid_total", "FAILURE", "SEARCH_LIVE_NO_VALID_HIT"),
            ("wrong_backend_hit", "FAILURE", "SEARCH_LIVE_NO_VALID_HIT"),
            ("empty_work_hit", "FAILURE", "SEARCH_LIVE_NO_VALID_HIT"),
            ("search_epoch_changed", "FAILURE", "SEARCH_SOURCE_CHANGED"),
            ("search_backend_changed", "FAILURE", "SEARCH_SOURCE_CHANGED"),
            ("native_provider_error", "FAILURE", "NATIVE_PROVIDER_UNAVAILABLE"),
            ("reader_wrong_locator", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("reader_empty_scene", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("reader_stale_epoch", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("reader_unadvanced_revision", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("reader_empty_segments", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("reader_foreign_focus", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("reader_epoch_changed", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("reader_backend_changed", "FAILURE", "SEARCH_OPEN_RECEIPT_INVALID"),
            ("require_native_provider_once", "SUCCESS", nil)
        ]
        var rows: [[String: Any]] = []
        for (name, status, code) in cases {
            Boundary.reset(name)
            #if CANDIDATE_DIAGNOSTIC
            let report = await SefariaEmbeddedAcceptanceDiagnosticRunner.run(
                visibleSurfaceProvider: surface, nativeReaderProvider: reader,
                backendRegressionProvider: { (true, nil) })
            #else
            let report = await SefariaEmbeddedAcceptanceDiagnosticRunner.run(
                visibleSurfaceProvider: surface, backendRegressionProvider: { (true, nil) })
            #endif
            var passed = report.status == status && report.failedStage == code
            if name == "require_native_provider_once" {
                passed = passed && Boundary.nativeCalls == 1 && Boundary.nativeLocators == [Boundary.hit]
                    && Boundary.textLoads.count == 2 && Boundary.staleCalls == 1
            }
            if name.hasPrefix("search_") || ["empty_search", "invalid_total", "wrong_backend_hit", "empty_work_hit"].contains(name) {
                passed = passed && report.stages["searchLive"]?.passed == false
                    && Boundary.nativeCalls == 0 && Boundary.surfaceCalls == 0
            }
            if name.hasPrefix("reader_") || name == "native_provider_error" {
                passed = passed && report.stages["searchOpenResult"]?.passed == false && Boundary.surfaceCalls == 0
            }
            rows.append(["name": name, "passed": passed, "actualStatus": report.status,
                "failedStage": report.failedStage ?? "", "expectedStatus": status, "expectedCode": code ?? "",
                "nativeProviderCalls": Boundary.nativeCalls, "staleGenerationCalls": Boundary.staleCalls,
                "surfaceProviderCalls": Boundary.surfaceCalls, "textAdapterCalls": Boundary.textLoads.count])
        }
        let summary: [String: Any] = ["boundary": "synthetic runtime/library/native providers; original full diagnostic/RPC models/surface contract",
            "caseCount": rows.count, "passed": rows.filter { $0["passed"] as? Bool == true }.count,
            "failed": rows.filter { $0["passed"] as? Bool != true }.count, "cases": rows,
            "nativeAppAcceptance": "NOT_RUN", "appleSDKTypecheck": "NOT_RUN"]
        let bytes = try! JSONSerialization.data(withJSONObject: summary, options: [.prettyPrinted, .sortedKeys])
        print(String(data: bytes, encoding: .utf8)!)
        if rows.contains(where: { $0["passed"] as? Bool != true }) { exit(1) }
    }
}
