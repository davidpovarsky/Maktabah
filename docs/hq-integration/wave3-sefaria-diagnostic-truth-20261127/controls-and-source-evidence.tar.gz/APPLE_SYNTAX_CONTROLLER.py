import subprocess,json,pathlib,hashlib
read_code="""import pathlib,base64,json,hashlib
r=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-integration-20261127')
names=['Source/SefariaEmbedded/Testing/SefariaEmbeddedAcceptanceDiagnosticRunner.swift','Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift','Source/UI/iOS/Views/iOSMainView.swift']
v={}
for n in names:
 b=(r/n).read_bytes();v[n]={'data':base64.b64encode(b).decode(),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}
print(json.dumps(v))
"""
proc=subprocess.run(['ssh','-o','BatchMode=yes','torah-social','python3','-'],input=read_code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45,check=True)
payload=json.loads(proc.stdout)
mac_code="""import pathlib,base64,json,hashlib,subprocess,tempfile,time,shutil
payload=json.loads(__PAYLOAD__)
root=pathlib.Path(tempfile.mkdtemp(prefix='otzaria-wave3-diagnostic-parse-20261127.',dir='/Users/m1/builds'))
rows=[]
for n,item in payload.items():
 b=base64.b64decode(item['data']);assert len(b)==item['size'] and hashlib.sha256(b).hexdigest()==item['sha256']
 p=root/pathlib.Path(n).name;p.write_bytes(b)
 cmd=['xcrun','swiftc','-frontend','-parse',str(p)]
 q=subprocess.run(cmd,capture_output=True)
 (root/(p.stem+'.parse.log')).write_bytes(q.stdout+q.stderr)
 rows.append({'path':n,'sha256':item['sha256'],'bytes':len(b),'command':cmd,'exit':q.returncode,'output':(q.stdout+q.stderr).decode(errors='replace')})
result={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'root':str(root),'rows':rows,'swiftVersion':subprocess.run(['xcrun','swiftc','--version'],capture_output=True,text=True).stdout,'free':shutil.disk_usage(root).free,'scope':'Apple syntax only; no typecheck/full app build/native runtime'}
data=(json.dumps(result,indent=2)+'\\n').encode();(root/'RESULT.json').write_bytes(data)
print(json.dumps({'result':result,'resultSHA256':hashlib.sha256(data).hexdigest()}))
""".replace('__PAYLOAD__',repr(json.dumps(payload)))
q=subprocess.run(['ssh','-o','BatchMode=yes','scaleway-mac','/usr/bin/python3','-'],input=mac_code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
print(q.stdout.decode(errors='replace'))
if q.returncode:print(q.stderr.decode(errors='replace'))
raise SystemExit(q.returncode)
