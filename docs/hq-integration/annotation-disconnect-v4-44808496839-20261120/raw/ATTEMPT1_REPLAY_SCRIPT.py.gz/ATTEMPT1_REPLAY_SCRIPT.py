#!/usr/bin/env python3
"""Replay unchanged retained validators without launching a compiler/binary."""
import hashlib,importlib.util,json,math,os,pathlib,sqlite3,traceback
HERE=pathlib.Path(__file__).resolve().parent;H=HERE.parent;ROOT=pathlib.Path('/Users/runner/work/Maktabah/Maktabah')
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def module(p,name):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
owner=load(ROOT/'PROJECTION_OWNERSHIP.json');assert owner['source_run']==44808496839 and owner['owner']=='hanlin_api_integration'
after=load(ROOT/'build/annotation-disconnect-route/after.json');observed=after['source'];expected=observed['files'];before={p:sha(ROOT/p) for p in expected}
assert all(before[p]==v['sha256'] for p,v in expected.items())
gate=module(ROOT/'Scripts/CI/annotation-disconnect-apple.py','unchanged_disconnect_gate')
result={'status':'INCOMPLETE','scope':'independent read-only evidence qualification, not new Swift/Native execution','source_run':44808496839,'source_head':observed['identity']['head_sha'],'source_inputs':len(before),'offline_swift_executed':0,'offline_native_executed':0,'steps':{},'errors':[]}
def step(name,fn):
 try:
  value=fn();result['steps'][name]={'status':'PASS','result':value};return value
 except Exception as error:
  result['steps'][name]={'status':'FAIL','error':repr(error),'traceback':traceback.format_exc()};result['errors'].append(name);return None
selector=load(ROOT/'build/local-annotation-cloud-route/toolchain.json')
# This is the recorded environment value required by the unchanged read-only
# comparison, not an installed/selected Linux Xcode or a toolchain execution.
os.environ['DEVELOPER_DIR']=selector['selected']['developer_dir']
result['recorded_DEVELOPER_DIR_for_receipt_comparison_only']=os.environ['DEVELOPER_DIR']
def original_gates():
 value=gate.verify_original_gates(ROOT,observed,after['outcomes']);assert value==after['original_gates'];return value
step('unchanged_complete_original_cloud_local_exchange_gate',original_gates)
race=module(ROOT/gate.DRIVER,'unchanged_repository_race_driver');output=ROOT/gate.RACE_OUTPUT;report=load(output/'RESULT.json');owned=race.owned_directory(output,pathlib.Path(report['owned_directory']));fixtures=owned/'fixtures';cloud=race.load_cloud(ROOT)
def source_and_copies():
 copies=race.verify_copies(owned,report['compiled_copies_before']);assert copies==report['compiled_copies_before']==report['compiled_copies_after']
 gate.source_report(report,observed,set(cloud.source_provenance(ROOT))|{gate.DRIVER,gate.FIXTURE})
 paths=cloud.SOURCES[:-1]+[gate.FIXTURE]
 for target,pins in copies.items():
  assert set(pins)==set(paths)|{'generated:exact_original_fixture_prefix'}
  for path in paths:
   original=observed['original_repository'] if path==gate.REPOSITORY_SOURCE and target=='DisconnectBaseline' else observed['files'][path]
   assert pins[path]==original
  prefix=cloud.fixture_prefix(ROOT);assert pins['generated:exact_original_fixture_prefix']=={'sha256':hashlib.sha256(prefix).hexdigest(),'bytes':len(prefix)}
 return {'targets':list(copies),'source_counts':{k:len(v) for k,v in copies.items()},'whole_source_and_fixture_prefix_exact':True,'source_report_exact':True}
step('unchanged_race_source_report_and_compiled_copies',source_and_copies)
commands=report['commands'];labels=['compile','binary-path',race.BASELINE_NAME,*race.CASES]
def process_receipts():
 assert [r['label'] for r in commands]==labels
 assert all(r['exit_code']==0 and r['timed_out'] is False and r['reaped'] and r['process_group_gone'] for r in commands[:2])
 exes=report['executables'];assert len(exes)==2 and exes==report['executables_after']
 assert {pathlib.Path(p).name for p in exes}=={'DisconnectBaseline','DisconnectCandidate'}
 assert all(not pathlib.Path(p).exists() for p in exes),'Unexpected local executable; never run it'
 exepaths={pathlib.Path(p).name:p for p in exes}
 pids=[r['pid'] for r in commands[2:]];assert all(type(p) is int and p>0 for p in pids) and len(set(pids))==11
 for i,r in enumerate(commands[2:]):
  executable='DisconnectBaseline' if i==0 else 'DisconnectCandidate';name=race.BASELINE_NAME if i==0 else race.CASES[i-1]
  assert r['command']==[exepaths[executable],name,str(fixtures/name)]
  assert r['timeout_seconds']==(race.BASELINE_TIMEOUT if i==0 else race.CASE_TIMEOUT)
  assert type(r['seconds']) in (int,float) and math.isfinite(r['seconds']) and r['seconds']>=0 and r['process_group']==r['pid']
 for r in commands:
  assert load(output/(r['label']+'.command.json'))==r
  for field in ['stdout','stderr']:
   assert r[field]==r['label']+'.'+field+'.log' and sha(output/r[field])==r[field+'_sha256']
 assert commands[2]['seconds']>=race.BASELINE_TIMEOUT
 return {'distinct_execution_PIDs':pids,'actual_baseline_seconds':commands[2]['seconds'],'baseline_timeout_seconds':race.BASELINE_TIMEOUT,'candidate_timeout_seconds':race.CASE_TIMEOUT,'raw_command_and_log_matches':len(commands),'reported_actual_CI_executable_hashes':exes,'executables_retained_in_artifact':False,'full_verify_race_offline':'NOT_REPLAYABLE: two required Apple binaries absent; no validator alteration or substituted binary','actual_CI_full_verify_race_gate':after['race_gates']}
step('bounded_raw_process_receipts_and_actual_CI_binary_gate_scope',process_receipts)
def baseline_check():
 value=race.verify_baseline(fixtures/race.BASELINE_NAME,commands[2]);expected=dict(report['baseline']);expected.pop('cold');assert value==expected
 assert value=={k:v for k,v in load(output/'BASELINE_RED.json').items() if k!='cold'}
 return value
step('unchanged_verify_baseline_five_markers_and_expected_owned_timeout',baseline_check)
def candidate_checks():
 rows=[]
 for name,command,expected in zip(race.CASES,commands[3:],report['cases'],strict=True):
  value=race.verify_candidate(fixtures/name,name,command);assert value=={k:v for k,v in expected.items() if k!='cold'};rows.append(value)
 assert [r['name'] for r in rows]==list(race.CASES) and load(output/'CASES.json')==report['cases'] and report['verified_green_cases']==10 and report['expected_original_red'] is True
 return rows
step('unchanged_verify_candidate_all10_results_and_original_boundary_markers',candidate_checks)
def cold_checks():
 rows=[]
 for name,expected in [(race.BASELINE_NAME,report['baseline']),*[(row['name'],row) for row in report['cases']]]:
  actual=race.cold_read(fixtures/name,name);old=expected['cold'];keys=set(actual)|set(old);diff={k:{'CI':old.get(k),'offline':actual.get(k)} for k in keys if actual.get(k)!=old.get(k)}
  assert set(diff)<={'sqlite_version'}
  rows.append({'case':name,'unchanged_cold_read_result':actual,'differences_from_actual_CI_receipt':diff,'all_semantic_fields_equal':True})
 return {'actual_offline_read_only_SQLite_checks':len(rows),'local_sqlite_version':sqlite3.sqlite_version,'CI_reader_sqlite_version':report['baseline']['cold']['sqlite_version'],'records':rows,'comparison_scope':'same original unchanged SQL/refusal checks; engine-version observation may differ and is retained, not overwritten'}
step('unchanged_cold_read_actual11_DBs',cold_checks)
end={p:sha(ROOT/p) for p in expected};assert before==end
result['source_before_after_identical']=True
result['status']='PASS_SCOPED_UNCHANGED_READ_ONLY_VALIDATORS' if not result['errors'] else 'SCOPED_REPLAY_HAS_FAILURES'
(HERE/'REPLAY_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'steps':{k:v['status'] for k,v in result['steps'].items()},'source_inputs_unchanged':len(end),'offline_Swift':0,'offline_Native':0},indent=2))
raise SystemExit(0 if not result['errors'] else 1)
