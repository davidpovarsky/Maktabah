// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "LocalAnnotationCloudOwnershipAcceptance",
    platforms: [.macOS(.v15)],
    dependencies: [.package(path: "/Users/runner/work/Maktabah/Maktabah/Source/Otzaria/Actions")],
    targets: [.executableTarget(name: "LocalAnnotationEditorAcceptance",
                dependencies: [.product(name: "OtzariaActionCore", package: "actions")],
                swiftSettings: [.unsafeFlags(["-strict-concurrency=complete"])],
                linkerSettings: [.linkedLibrary("sqlite3")]),
        .executableTarget(name: "LocalAnnotationCloudOwnershipAcceptance",
                dependencies: [.product(name: "OtzariaActionCore", package: "actions")],
                swiftSettings: [.unsafeFlags(["-strict-concurrency=complete"])],
                linkerSettings: [.linkedLibrary("sqlite3")])], swiftLanguageModes: [.v6])
