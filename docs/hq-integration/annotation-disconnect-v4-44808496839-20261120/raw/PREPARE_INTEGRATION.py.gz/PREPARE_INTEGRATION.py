#!/usr/bin/env python3
import difflib,hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent;H=HERE.parent;TOP=H.parent;ROOT=pathlib.Path('/Users/runner/work/Maktabah/Maktabah');C=H/'integration-candidate';BASE=H/'integration-base'
M='1146a249fdd94c345371c67a8d763f16223017ee'
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
def load(p):return json.loads(p.read_bytes())
def api(p):return json.loads(load(p)['structuredContent']['content'])
current=api(TOP/'active-checkpoint-20261120/ROOT_2010_ACTUAL_TREE.json');tested=api(TOP/'annotation-disconnect-apple-v4-20261120/ROOT_SOURCE_ACTUAL_0.json')
assert current['sha']=='13d91ed50ac92ef4355fb430a0be8b13fc480ce1' and not current['truncated'] and not tested['truncated']
a={r['path']:r for r in current['tree']};b={r['path']:r for r in tested['tree']};original=load(TOP/'local-annotation-cloudkit-owner-20261120/evidence/SOURCE_PUBLICATION_INDEX.json')
paths=[r['path'] for r in original['files']]+['Source/Features/Annotations/Database/AnnotationRepository.swift','Tests/HQ/annotation-disconnect/AnnotationRepositoryDisconnectAcceptance.swift','tools/hq-annotation-disconnect-acceptance.py']
assert len(paths)==len(set(paths))==15
rows=[];patch=[]
for path in paths:
 data=(ROOT/path).read_bytes();assert blob(data)==b[path]['sha'] and b[path]['mode']=='100644'
 old=None
 if path in a:
  oldpath=TOP/'local-annotation-cloudkit-owner-20261120/base'/path
  if oldpath.is_file() and blob(oldpath.read_bytes())==a[path]['sha']:old=oldpath.read_bytes()
  elif path=='Source/Features/Annotations/Database/AnnotationRepository.swift':old=(ROOT/'original-baseline/AnnotationRepository.swift').read_bytes()
  assert old is not None and blob(old)==a[path]['sha'] and a[path]['mode']=='100644',path
  out=BASE/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(old)
 out=C/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 rows.append({'path':path,'mode':'100644','type':'blob','bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'tested_source_commit':'c1e0d33117154d578206195ef021d41fc2fa2b12','base_git_blob':a[path]['sha'] if path in a else None,'base_sha256':sha(old) if old is not None else None,'change':'modify' if old is not None else 'add'})
 patch.extend(difflib.unified_diff((old or b'').decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+path if old is not None else '/dev/null',tofile='b/'+path))
# Compute the entire original Merkle tree, then replace only the fifteen exact
# admitted leaves. This proves all unrelated modes/IDs are retained by proposal.
def trees(leaves):
 trie={}
 for path,row in leaves.items():
  target=trie
  parts=path.split('/')
  for component in parts[:-1]:target=target.setdefault(component,{})
  assert parts[-1] not in target
  target[parts[-1]]=(row['mode'],row['sha'])
 hashes={}
 def build(tree,prefix=''):
  entries=[]
  for name,child in tree.items():
   if isinstance(child,dict):
    sub=build(child,prefix+name+'/');entries.append((name,'40000',sub,True));hashes[prefix+name]=sub
   else:entries.append((name,child[0].lstrip('0'),child[1],False))
  body=b''.join(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(digest) for name,mode,digest,directory in sorted(entries,key=lambda r:(r[0]+'/' if r[3] else r[0]).encode()))
  return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()
 root=build(trie);return root,hashes
leaves={p:r for p,r in a.items() if r['type']!='tree'};oldroot,oldtrees=trees(leaves);assert oldroot==current['sha']
updated=dict(leaves)
for row in rows:updated[row['path']]={'path':row['path'],'sha':row['git_blob'],'mode':row['mode'],'type':row['type']}
newroot,newtrees=trees(updated)
protected=['Source/Otzaria/Actions','Source/Features/Reader','Source/ChavrusaText/UIRoutingHost','Source/UI','Source/Otzaria/Search','Maktabah-iOSUITests','Vendor','Scripts']
assert all(oldtrees[p]==newtrees[p] for p in protected)
project=next(row for row in rows if row['path']=='Maktabah.xcodeproj/project.pbxproj');old=(BASE/project['path']).read_text();new=(C/project['path']).read_text();d=list(difflib.ndiff(old.splitlines(True),new.splitlines(True)));removed=[r[2:] for r in d if r.startswith('- ')];added=[r[2:] for r in d if r.startswith('+ ')];assert not removed and len(added)==16 and all('AnnotationLocalEditorCloud' in line for line in added)
proof={'status':'READY_ISOLATED_SOURCE_PROPOSAL_ONLY','base_commit':M,'base_tree':current['sha'],'tested_source_commit':'c1e0d33117154d578206195ef021d41fc2fa2b12','tested_F':'5bf1ddfc4a4b04dede8e8bdcaecabf3a7a5dddcd','source_files':rows,'changed_path_count':len(rows),'additions':sum(r['change']=='add' for r in rows),'replacements':sum(r['change']=='modify' for r in rows),'original_leaf_count':len(leaves),'proposed_leaf_count':len(updated),'proposed_product_only_tree':newroot,'proposed_product_subtrees':{p:newtrees[p] for p in ['Source','Tests','tools','Maktabah.xcodeproj']},'unchanged_protected_subtrees':{p:oldtrees[p] for p in protected},'project':{'base_blob':project['base_git_blob'],'tested_proposed_blob':project['git_blob'],'only16CloudMembershipAdditions':True,'original_lines_removed':0,'added_lines':added},'all_other_leaves_modes_preserved':True,'no_integration_ref_changed':True,'no_newCI_activated':True,'whole_new_application_Apple_or_Native_qualification':'NOT_RUN; actual v4 qualified whole-source components on its older Core5d closure, not current Core194 or new SideSheet'}
(HERE/'INTEGRATION_PROPOSAL.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');(HERE/'INTEGRATION.patch').write_text(''.join(patch));print(json.dumps({k:proof[k] for k in ['status','changed_path_count','additions','replacements','base_commit','proposed_product_only_tree','unchanged_protected_subtrees']},indent=2))
