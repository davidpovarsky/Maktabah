#!/usr/bin/env python3
import base64,datetime,hashlib,json,pathlib,stat,tarfile,zipfile
HERE=pathlib.Path(__file__).resolve().parent; H=HERE.parent
F='5bf1ddfc4a4b04dede8e8bdcaecabf3a7a5dddcd'; M='c1e0d33117154d578206195ef021d41fc2fa2b12'
ROOT=pathlib.Path('/Users/runner/work/Maktabah/Maktabah')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def api(p):return json.loads(load(p)['structuredContent']['content'])
def safe(name):
 p=pathlib.PurePosixPath(name);assert name==str(p) and not p.is_absolute() and '..' not in p.parts and '\\' not in name,name;return p
run=api(H/'RUN.json'); jobs=api(H/'TERMINAL_CHECK_0.json')['jobs']; artifacts=api(H/'TERMINAL_CHECK_1.json')['artifacts']
assert run['id']==44808496839 and run['head_sha']==F and run['run_attempt']==1 and run['event']=='push' and run['status']=='completed' and run['conclusion']=='success'
assert len(jobs)==len(artifacts)==1
job=jobs[0]; art=artifacts[0]
assert job['id']==136538641362 and job['run_id']==run['id'] and job['head_sha']==F and job['run_attempt']==1 and job['conclusion']=='success'
assert art['id']==14664188280 and art['size_in_bytes']==1742796 and art['expired'] is False
assert art['workflow_run']['id']==run['id'] and art['workflow_run']['head_sha']==F and art['workflow_run']['repository_id']==1280062128
raw=(H/'evidence.zip').read_bytes();digest=sha(raw);assert len(raw)==art['size_in_bytes'] and art['digest']=='sha256:'+digest and digest=='cd309d6806f1b0591b017564cbb807531114bf0564c7db63991a006f6a0f68fb'
ziprows=[]
with zipfile.ZipFile(H/'evidence.zip') as z:
 infos=z.infolist();assert len(infos)==569 and len({i.filename for i in infos})==569 and z.testzip() is None
 for i in infos:
  name=safe(i.filename);assert not i.is_dir() and stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG)
  data=z.read(i);assert len(data)==i.file_size and (H/'raw'/name).read_bytes()==data
  ziprows.append({'path':str(name),'bytes':len(data),'sha256':sha(data),'crc32':f'{i.CRC:08x}'})
frozen=api(H.parent/'annotation-disconnect-apple-v4-20261120/ROOT_FROZEN_ACTUAL_0.json');assert frozen['truncated'] is False and frozen['sha']=='b9c57c6d231e4a42a262d4806bb1451d6f632116';tree={x['path']:x for x in frozen['tree']}
before=load(H/'raw/annotation-disconnect-route/before.json');after=load(H/'raw/annotation-disconnect-route/after.json');observed=after['source']
assert before['status']=='SOURCE_BOUND_NOT_EXECUTED' and after['status']=='PASS_APPLE_REPOSITORY_RED10_LOCAL43_COLD2_CLOUD48_EXCHANGE28_CRASH2'
assert before['source']==observed and observed['identity']['head_sha']==F and observed['identity']['run_id']==run['id'] and observed['identity']['run_attempt']==1 and observed['application_source']==M
assert len(observed['files'])==102 and all(v=='success' for v in after['outcomes'].values())
api_baseline=load(HERE/'BASELINE_REPOSITORY_API.json');data=api_baseline['content'].encode();normalization='none'
if blob(data)!=api_baseline['sha']:
 assert data.endswith(b'\n') and blob(data[:-1])==api_baseline['sha'];data=data[:-1];normalization='connector-added final LF removed only after exact Git blob match'
assert api_baseline['sha']==observed['original_repository']['git_blob']=='86512a8286560aedb248da4abea1a41f5c96ea0e'
assert sha(data)==observed['original_repository']['sha256'] and len(data)==observed['original_repository']['bytes']
archives={}; contents={}
for phase,report in [('before',before),('after',after)]:
 path=H/'raw/annotation-disconnect-route'/f'source-{phase}.tar.gz';b=path.read_bytes();pin=report['source_archive'];assert len(b)==pin['bytes'] and sha(b)==pin['sha256'] and pin['members']==103
 with tarfile.open(path) as t:
  members=t.getmembers();assert len(members)==len({x.name for x in members})==103
  archive={}
  for member in members:
   p=safe(member.name);assert member.isfile() and not member.issym() and not member.islnk() and member.mode==0o644
   value=t.extractfile(member).read();assert len(value)==member.size
   if member.name=='original-baseline/AnnotationRepository.swift':assert value==data
   else:
    record=observed['files'][member.name];entry=tree[member.name]
    assert len(value)==record['bytes'] and sha(value)==record['sha256'] and blob(value)==record['git_blob']==entry['sha'] and entry['mode']=='100644' and entry['type']=='blob'
   archive[member.name]=value
  assert set(archive)==set(observed['files'])|{'original-baseline/AnnotationRepository.swift'}
  if contents:assert archive==contents
  contents=archive;archives[phase]={'sha256':sha(b),'bytes':len(b),'members':103,'all102_Git_blobs_match_F':True}
proof={'status':'PASS_AUTHENTIC_ARCHIVE_AND_GIT_SOURCE_ONLY','run':{k:run[k] for k in ['id','head_sha','head_branch','run_attempt','status','conclusion','event']},'job':{k:job[k] for k in ['id','started_at','completed_at','status','conclusion']},'artifact':{k:art[k] for k in ['id','name','size_in_bytes','digest']},'ZIP_members':569,'ZIP_crc_verified':569,'ZIP_files_match_retained_extraction':True,'source_before_after_identical':True,'source_files':102,'source_tree':frozen['sha'],'source_archives':archives,'baseline_repository_api':{'commit':'7af3a06d48ccbe77acef180cb99d120971c3804e','git_blob':api_baseline['sha'],'sha256':sha(data),'bytes':len(data),'connector_normalization':normalization},'original_CI_after_gate':after['status'],'offline_Swift_executed':0,'offline_Native_executed':0}
(HERE/'AUTHENTIC_SOURCE_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');(HERE/'ZIP_FILES.json').write_text(json.dumps(ziprows,indent=2)+'\n')
# Fresh absence admission, no overwrite of an existing CI-named workspace.
assert not ROOT.exists() and not ROOT.is_symlink(),'CI-named path already exists; inspect, do not overwrite'
for parent in ROOT.parents:assert not parent.is_symlink(),'symlinked ancestor'
ROOT.mkdir(parents=True,exist_ok=False)
owner={'owner':'hanlin_api_integration','purpose':'read-only unchanged v4 result validator projection','source_run':run['id'],'source_head':F,'created_from_verified_artifact':art['id'],'artifact_sha256':digest}
(ROOT/'PROJECTION_OWNERSHIP.json').write_text(json.dumps(owner,indent=2)+'\n')
for name,value in contents.items():
 out=ROOT/safe(name);out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('xb') as f:f.write(value)
for row in ziprows:
 source=H/'raw'/row['path'];out=ROOT/'build'/row['path'];out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('xb') as f:f.write(source.read_bytes())
(HERE/'OWNED_PROJECTION.json').write_text(json.dumps({'root':str(ROOT),'fresh_absence_verified':True,**owner,'source_members':103,'evidence_members':569},indent=2)+'\n')
print(json.dumps({'source_Git102':'PASS','archives103_before_after':'PASS','zip_CRC569':'PASS','owned_projection':str(ROOT),'offline_Swift':0},indent=2))
