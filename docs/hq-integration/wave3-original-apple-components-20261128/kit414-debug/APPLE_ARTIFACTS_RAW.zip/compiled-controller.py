if not __debug__:
    raise SystemExit("Optimized Python is refused before imports or actions.")

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import struct
import subprocess
import sys
import time

BASE = Path("/Users/m1/builds/otzaria-wave3-inspector-kit414-apple-package-20261128")
SOURCE = BASE / "source"
OUT = BASE / "apple-sdk-debug-attempt-1"
BUILD_CONFIGURATION = "debug"
MANIFEST_SHA256 = "42ca6741b449867a8b83f9d31ba990cbc285e694cdeba3bd34e5f1f9da78a16c"
SOURCE_BASE = "414e0d3e95d53509381d233a23fcdd28ef24167a"
SOURCE_TREE = "294f57e29cdb414df4647358221755c3e2ebcf99"
ADMISSION_FREE_BYTES = 3_221_225_472
LIVE_FREE_BYTES = 2_415_919_104
WORK_SECONDS = 600
CLEANUP_SECONDS = 50
OUTER_SECONDS = 675
EXPECTED_INPUT_FILES = 169
EXPECTED_INPUT_BYTES = 984_255
EXPECTED_SDK = "/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk"
EXPECTED_COUNTS = {"TorahInspectorCore": 8, "TorahInspectorUI": 15}
PACKAGE_PATHS = {
    "TorahInspectorCore": "Sources/TorahInspectorCore/",
    "TorahInspectorUI": "Sources/TorahInspectorUI/",
}
RESOURCE_ACCESSORS = {"TorahInspectorCore": 0, "TorahInspectorUI": 1}
RESOURCE_BUNDLE = "TorahInspectorKit_TorahInspectorUI.bundle"
LOG_LIMIT_BYTES = 16 * 1024 * 1024
_active = None
_started = None
_deadline = None
_out_created = False
_state = {"schema": 1, "status": "NOT_STARTED", "scope": "Original complete TorahInspectorKit414 Apple package compile only",
          "sourceBase": SOURCE_BASE, "sourceTree": SOURCE_TREE, "configuration": BUILD_CONFIGURATION,
          "completeOriginalTrackedFiles": EXPECTED_INPUT_FILES, "sourceReplacements": 0, "stubs": 0,
          "fullAppBuilds": 0, "nativeExecutions": 0, "testsRun": 0, "fullAppGateUnchanged": 15_032_385_536,
          "admissionFreeBytes": ADMISSION_FREE_BYTES, "liveFreeBytes": LIVE_FREE_BYTES,
          "workDeadlineSeconds": WORK_SECONDS, "cleanupBudgetSeconds": CLEANUP_SECONDS,
          "hardOuterSeconds": OUTER_SECONDS, "commands": []}

class Stop(Exception):
    pass

class CommandFailure(Stop):
    pass

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def remaining():
    if _deadline is None:
        return float(WORK_SECONDS)
    return _deadline - time.monotonic()

def check_time():
    if remaining() <= 0:
        raise Stop("Original-package proposal work deadline reached")

def checked_regular(path, single_link=True):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or (single_link and before.st_nlink != 1):
            raise Stop("Expected a single-link regular file: " + str(path))
        data = stream.read()
        after = os.fstat(stream.fileno())
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise Stop("File changed while reading: " + str(path))
    if len(data) != before.st_size:
        raise Stop("Short file read: " + str(path))
    return data

def source_files():
    found = set()
    for directory, dirs, names in os.walk(SOURCE, followlinks=False):
        check_time()
        for name in dirs:
            p = Path(directory) / name
            if p.is_symlink():
                raise Stop("Source directory symlink: " + str(p))
        for name in names:
            p = Path(directory) / name
            if p.is_symlink():
                raise Stop("Source file symlink: " + str(p))
            found.add(p.relative_to(SOURCE).as_posix())
    return found

def verify_source():
    check_time()
    if BASE.is_symlink() or SOURCE.is_symlink() or not SOURCE.is_dir():
        raise Stop("Original source root must be an actual directory")
    raw = checked_regular(SOURCE / "INPUT_MANIFEST.json")
    if hashlib.sha256(raw).hexdigest() != MANIFEST_SHA256:
        raise Stop("Exact prospective input manifest changed")
    manifest = json.loads(raw)
    if manifest["sourceBase"] != SOURCE_BASE or manifest["sourceTree"] != SOURCE_TREE:
        raise Stop("Source attribution changed")
    rows = manifest["files"]
    if len(rows) != EXPECTED_INPUT_FILES or sum(x["bytes"] for x in rows) != EXPECTED_INPUT_BYTES:
        raise Stop("Input count or logical-byte total changed")
    # Reject an unexpected/symlinked source tree before opening row paths.
    initial_leaves = source_files()
    names = set()
    counts = {name: 0 for name in EXPECTED_COUNTS}
    for row in rows:
        check_time()
        rel = row["path"]
        parts = Path(rel).parts
        if not parts or Path(rel).is_absolute() or ".." in parts or "." in parts or rel in names:
            raise Stop("Noncanonical or duplicate source path")
        names.add(rel)
        data = checked_regular(SOURCE / rel)
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            raise Stop("Source input changed: " + rel)
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if blob != row["gitBlob"] or row["origin"] != "published_git":
            raise Stop("Published Git blob attribution changed: " + rel)
        if stat.S_IMODE(os.lstat(SOURCE / rel).st_mode) != int(row["mode"], 8):
            raise Stop("Source mode changed: " + rel)
        for module, prefix in PACKAGE_PATHS.items():
            if rel.startswith(prefix) and rel.endswith(".swift"):
                counts[module] += 1
    if counts != EXPECTED_COUNTS:
        raise Stop("Actual original package Swift source count changed")
    if initial_leaves != names | {"INPUT_MANIFEST.json"} or source_files() != initial_leaves:
        raise Stop("Unexpected or missing source leaf")
    return manifest

def short_read(command, timeout=10):
    check_time()
    completed = subprocess.run(command, capture_output=True, text=True,
                               timeout=min(timeout, max(0.05, remaining())), check=True)
    return completed.stdout.strip()

def free_bytes():
    output = short_read(["/bin/df", "-k", "/System/Volumes/Data"])
    lines = output.splitlines()
    if len(lines) != 2:
        raise Stop("Unexpected original df output")
    return int(lines[1].split()[3]) * 1024

def live_guard():
    check_time()
    free = free_bytes()
    _state["minimumFreeObserved"] = min(free, _state.get("minimumFreeObserved", free))
    if free < LIVE_FREE_BYTES:
        raise Stop("Shared free below original 2 GiB + 256 MiB reserve")
    return free

def journal():
    if not _out_created:
        return
    path = OUT / "STATUS.json"
    payload = (json.dumps(_state, indent=2, sort_keys=True) + "\n").encode()
    temporary = OUT / "STATUS.next"
    with temporary.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)

def signal_owned(process, sig):
    # Only an unreaped owned leader pins this numeric process/session identity.
    # No poll/wait or other reap occurs between these identity reads and killpg.
    if process.poll() is not None:
        return False
    try:
        if os.getpgid(process.pid) != process.pid or os.getsid(process.pid) != process.pid:
            raise Stop("Owned unreaped leader lost its exact session/group identity")
        os.killpg(process.pid, sig)
    except ProcessLookupError:
        return False
    return True

def cleanup_owned(process):
    if process is None:
        return
    if process.poll() is None:
        signal_owned(process, signal.SIGINT)
        try:
            process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            signal_owned(process, signal.SIGTERM)
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                signal_owned(process, signal.SIGKILL)
                process.wait(timeout=5)
    if process.poll() is None:
        raise Stop("Owned leader did not terminate within bounded cleanup")
    # The leader has been reaped. A surviving numeric group may now be foreign.
    # Probe only; never signal it or claim ownership from this number.
    observation = "numeric_group_exists_after_leader_reaped"
    try:
        os.killpg(process.pid, 0)
    except ProcessLookupError:
        return
    except PermissionError:
        observation = "numeric_group_probe_denied_after_leader_reaped"
    _state.setdefault("unresolvedGroups", []).append({
        "reapedLeaderPID": process.pid, "leaderExit": process.returncode,
        "observation": observation, "remainingOwnershipEstablished": False,
        "signalsSentAfterLeaderReaped": 0,
    })
    raise Stop("Unresolved numeric group after owned leader was reaped; no signal sent")

def interrupted(signum, frame):
    raise Stop("Controller interrupted by signal " + str(signum))

def hard_outer(signum, frame):
    # Last-resort bound includes cleanup. An absent final receipt is a failure,
    # never a successful package result.
    if _active is not None:
        try:
            signal_owned(_active, signal.SIGKILL)
        except BaseException:
            pass
    os._exit(124)

def owned(command, name, timeout_seconds):
    global _active
    live_guard()
    so_path, se_path = OUT / (name + ".stdout.log"), OUT / (name + ".stderr.log")
    started = time.monotonic()
    end = min(_deadline, started + timeout_seconds)
    row = {"name": name, "command": command, "started_at": utc()}
    _state["commands"].append(row)
    process = None
    with so_path.open("xb") as stdout, se_path.open("xb") as stderr:
        try:
            process = subprocess.Popen(command, stdout=stdout, stderr=stderr,
                                       start_new_session=True, cwd=SOURCE)
            _active = process
            row.update(pid=process.pid, pgid=process.pid)
            journal()
            while process.poll() is None:
                live_guard()
                if time.monotonic() >= end:
                    raise Stop("Owned command deadline: " + name)
                if so_path.stat().st_size + se_path.stat().st_size > LOG_LIMIT_BYTES:
                    raise Stop("Owned output bound exceeded: " + name)
                time.sleep(min(2, max(0.05, end - time.monotonic())))
            row["exit"] = process.returncode
        except BaseException as error:
            row["failure"] = type(error).__name__ + ": " + str(error)
            raise
        finally:
            try:
                cleanup_owned(process)
            finally:
                # Preserve an unresolved-group failure and the real exit even
                # when cleanup refuses; never bypass finish()/RESULT reporting.
                _active = None
                row["finished_at"] = utc()
                row["durationSeconds"] = time.monotonic() - started
                if process is not None:
                    row["exit"] = process.returncode
                journal()
    live_guard()
    # A command can finish between two live polls; its final output must still
    # satisfy the same bound rather than bypassing it by exiting quickly.
    if so_path.stat().st_size + se_path.stat().st_size > LOG_LIMIT_BYTES:
        raise Stop("Owned final output bound exceeded: " + name)
    if row["exit"] != 0:
        raise CommandFailure("Owned command returned nonzero: " + name)
    return so_path

def file_record(path):
    data = checked_regular(path, single_link=False)
    return {"path": path.relative_to(OUT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}

def observe_artifacts(manifest):
    scratch = OUT / "swift-build"
    rows = manifest["files"]
    records, lists = [], {}
    for module, prefix in PACKAGE_PATHS.items():
        candidates = list(scratch.rglob(module + ".SwiftFileList"))
        if len(candidates) != 1:
            raise Stop("Expected one actual compiler source list for " + module)
        p = candidates[0]
        lines = checked_regular(p).decode().splitlines()
        if len(lines) != len(set(lines)):
            raise Stop("Duplicate actual compiler source")
        actual = set()
        derived = []
        for line in lines:
            item = Path(line)
            try:
                actual.add(item.relative_to(SOURCE).as_posix())
            except ValueError:
                if item.name != "resource_bundle_accessor.swift" or not item.is_relative_to(scratch):
                    raise Stop("Unattributed compiler source: " + line)
                derived.append(line)
        expected = {r["path"] for r in rows if r["path"].startswith(prefix) and r["path"].endswith(".swift")}
        if actual != expected or len(actual) != EXPECTED_COUNTS[module]:
            raise Stop("Actual compiler source membership differs: " + module)
        if len(derived) != RESOURCE_ACCESSORS[module]:
            raise Stop("Generated resource accessor count differs: " + module)
        lists[module] = {"originalCount": len(actual), "generatedResourceAccessors": derived, **file_record(p)}
        modules = [p for p in scratch.rglob("*") if p.is_file() and
                   (p.name == module + ".swiftmodule" or
                    (p.name == "arm64-apple-ios-simulator.swiftmodule" and p.parent.name == module + ".swiftmodule"))]
        if not modules:
            raise Stop("Actual compiled module absent: " + module)
        records.extend(file_record(p) for p in modules)
    object_proofs = []
    for module, filename, symbol in [
        ("TorahInspectorCore", "Models.o", "TorahTextRequest"),
        ("TorahInspectorUI", "TorahInspectorNavigationSurface.o", "TorahInspectorNavigationRetention"),
        ("TorahInspectorUI", "TorahInspectorView.o", "TorahInspectorView"),
        ("TorahInspectorUI", "TorahSegmentDetailView.o", "TorahSegmentDetailView"),
    ]:
        objects = list(scratch.rglob(filename))
        if len(objects) != 1:
            raise Stop("Expected unique genuine Apple object: " + filename)
        obj = objects[0]
        name = filename.removesuffix(".o")
        file_path = owned(["/usr/bin/file", str(obj)], name + ".file", 15)
        if "Mach-O 64-bit object arm64" not in checked_regular(file_path).decode():
            raise Stop("Expected real arm64 Apple object: " + filename)
        vtool_path = owned(["xcrun", "vtool", "-show-build", str(obj)], name + ".vtool", 15)
        if "IOSSIMULATOR" not in checked_regular(vtool_path).decode():
            raise Stop("Expected iOS Simulator build metadata: " + filename)
        nm_path = owned(["xcrun", "nm", str(obj)], name + ".symbols", 15)
        if symbol not in checked_regular(nm_path).decode():
            raise Stop("Expected genuine compiled original symbol: " + symbol)
        raw = checked_regular(obj, single_link=False)
        if len(raw) < 32:
            raise Stop("Truncated Mach-O header")
        magic, cpu, subtype, filetype, count, size, flags, reserved = struct.unpack_from("<8I", raw)
        if (magic, cpu, filetype) != (0xfeedfacf, 0x0100000c, 1) or 32 + size > len(raw):
            raise Stop("Object must be actual MH_OBJECT arm64")
        offset, build_versions = 32, []
        for _ in range(count):
            if offset + 8 > 32 + size:
                raise Stop("Truncated Mach-O command")
            command, command_size = struct.unpack_from("<2I", raw, offset)
            if command_size < 8 or offset + command_size > 32 + size:
                raise Stop("Invalid Mach-O command bounds")
            if command == 0x32:
                if command_size < 24:
                    raise Stop("Truncated LC_BUILD_VERSION")
                platform, minimum, sdk_version, tools = struct.unpack_from("<4I", raw, offset + 8)
                if command_size != 24 + tools * 8 or platform != 7:
                    raise Stop("Expected actual IOSSIMULATOR LC_BUILD_VERSION")
                build_versions.append({"platform": platform, "minimumOS": minimum, "sdk": sdk_version})
            offset += command_size
        if offset != 32 + size or len(build_versions) != 1:
            raise Stop("Expected one complete Simulator build-version command")
        record = file_record(obj)
        records.append(record)
        object_proofs.append({"module": module, "object": record, "requiredSymbol": symbol,
                              "cpuType": cpu, "fileType": filetype, "buildVersion": build_versions[0],
                              "fileLog": file_record(file_path), "vtoolLog": file_record(vtool_path),
                              "symbolLog": file_record(nm_path)})
    resource_proofs = []
    for language in ("en", "he"):
        original = SOURCE / ("Sources/TorahInspectorUI/Resources/" + language + ".lproj/Localizable.strings")
        built = [p for p in scratch.rglob("Localizable.strings")
                 if p.parent.name == language + ".lproj" and p.parent.parent.name == RESOURCE_BUNDLE]
        if len(built) != 1:
            raise Stop("Expected one actual original resource for " + language)
        before = owned(["/usr/bin/plutil", "-convert", "json", "-o", "-", str(original)],
                       language + ".original-strings", 15)
        after = owned(["/usr/bin/plutil", "-convert", "json", "-o", "-", str(built[0])],
                      language + ".compiled-strings", 15)
        expected, actual = json.loads(checked_regular(before)), json.loads(checked_regular(after))
        if (not isinstance(expected, dict) or not expected or actual != expected
                or any(not isinstance(k, str) or not isinstance(v, str) for k, v in expected.items())):
            raise Stop("Original localized resource semantics changed: " + language)
        resource_proofs.append({"language": language, "originalPath": original.relative_to(SOURCE).as_posix(),
                                "originalSHA256": hashlib.sha256(checked_regular(original)).hexdigest(),
                                "compiled": file_record(built[0]), "entries": len(expected),
                                "originalPlutil": file_record(before), "compiledPlutil": file_record(after)})
    return {"fileLists": lists, "artifacts": records, "machOObjects": object_proofs,
            "originalResources": resource_proofs}


def run():
    global _started, _deadline, _out_created
    if sys.argv[1:] != ["--execute-reviewed-kit-debug"]:
        raise Stop("Separate Root admission and the exact execution argument are required.")
    _started = time.monotonic()
    _deadline = _started + WORK_SECONDS
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGALRM, hard_outer)
    signal.setitimer(signal.ITIMER_REAL, OUTER_SECONDS)
    if OUT.exists() or OUT.is_symlink():
        raise Stop("Original attempt must be absent; no overwrite or retry.")
    manifest = verify_source()
    available = free_bytes()
    if available < ADMISSION_FREE_BYTES:
        raise Stop("Insufficient original bounded component compile admission")
    sdk = short_read(["xcrun", "--sdk", "iphonesimulator", "--show-sdk-path"])
    if sdk != EXPECTED_SDK:
        raise Stop("The exact original iPhoneSimulator27.0 SDK is not selected")
    version = short_read(["xcrun", "swift", "--version"])
    xcode = short_read(["xcodebuild", "-version"])
    # The archived proposal is unexecuted. A future invocation requires
    # separate Root admission; the historical attempt is never reused.
    output_admission = free_bytes()
    if output_admission < ADMISSION_FREE_BYTES:
        raise Stop("Original admission lost before owned output creation")
    OUT.mkdir(exist_ok=False)
    _out_created = True
    _state.update(status="RUNNING", started_at=utc(), freeBefore=available, sdk=sdk,
                  swiftVersion=version, xcodeVersion=xcode, pythonVersion=sys.version,
                  freeAtOutputAdmission=output_admission, inputFiles=len(manifest["files"]),
                  manifestSHA256=MANIFEST_SHA256, originalSwiftCounts=EXPECTED_COUNTS)
    journal()
    command = ["xcrun", "swift", "build", "--package-path", str(SOURCE),
               "--scratch-path", str(OUT / "swift-build"), "--configuration", BUILD_CONFIGURATION,
               "--triple", "arm64-apple-ios27.0-simulator", "--sdk", sdk,
               "--target", "TorahInspectorUI", "--jobs", "2"]
    owned(command, "build", WORK_SECONDS)
    verify_source()
    live_guard()
    _state["observation"] = observe_artifacts(manifest)
    verify_source()
    _state.update(status="PASS_COMPONENT_APPLE_SDK_ONLY", freeAfter=live_guard(), finished_at=utc())

def finish(error=None):
    if error is not None:
        _state.update(status="FAIL_COMPONENT_APPLE_SDK_ONLY" if isinstance(error, CommandFailure) else "NOT_COMPLETE",
                      failure=type(error).__name__ + ": " + str(error), finished_at=utc())
    if _out_created:
        _state["logs"] = [file_record(p) for p in sorted(OUT.glob("*.log"))]
        journal()
        with (OUT / "RESULT.json").open("xb") as stream:
            stream.write((json.dumps(_state, indent=2, sort_keys=True) + "\n").encode())
            stream.flush()
            os.fsync(stream.fileno())
    print(json.dumps(_state, sort_keys=True))
    signal.setitimer(signal.ITIMER_REAL, 0)

if __name__ == "__main__":
    failure = None
    try:
        run()
    except BaseException as error:
        failure = error
    finally:
        if _active is not None:
            cleanup_owned(_active)
        finish(failure)
    raise SystemExit(0 if failure is None and _state["status"] == "PASS_COMPONENT_APPLE_SDK_ONLY" else 1)
