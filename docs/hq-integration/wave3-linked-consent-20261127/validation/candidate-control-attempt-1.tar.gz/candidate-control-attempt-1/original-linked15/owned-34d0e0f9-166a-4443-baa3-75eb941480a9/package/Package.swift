// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "AnnotationExchangeAcceptance",
    platforms: [.macOS(.v14)],
    dependencies: [.package(path: "/Users/m1/builds/otzaria-wave3-linked-consent-20261127/candidate-source/Source/Otzaria/Actions")],
    targets: [
        
        .executableTarget(name: "ExchangeAcceptance",
            dependencies: [.product(name: "OtzariaActionCore", package: "actions")],
            swiftSettings: [.unsafeFlags(["-strict-concurrency=complete"])],
            linkerSettings: [.linkedLibrary("sqlite3")])
    ], swiftLanguageModes: [.v6])
