import os,json,hashlib,subprocess,shlex
from pathlib import Path
P=Path("/home/ubuntu/otzaria-wave3-native116-stage-leaf-retirement-proposal-20261128/commit")
def sha(b):return hashlib.sha256(b).hexdigest()
files={};texts={}
for p in sorted(P.iterdir()):
 assert not p.is_symlink()
 if p.is_file():
  b=p.read_bytes();files[p.name]={"bytes":len(b),"sha256":sha(b)}
  if p.name in ["FINAL_RESULT.json","TERMINAL.json"]:texts[p.name]=json.loads(b)
  if p.name=="mac-collector.stdout":texts["events"]=[json.loads(x)for x in b.splitlines()]
assert files["FINAL_RESULT.json"]=={"bytes":10573,"sha256":"da2ceb8bcc621d2c939708939c1ea599630b2c8524b14eb209d67c14ca16bab2"}
q=texts["FINAL_RESULT.json"];assert q["status"]=="EXACT_STAGE_LEAF_RETIREMENT_COMPLETE"and q["removed"]is True and q["failure"]is None
t=q["childTerminal"];assert t["returncode"]==0 and t["cleanupFailure"]is None and t["ownedLeaderReaped"] and t["stdoutSHA256"]==files["mac-collector.stdout"]["sha256"]and t["stdoutBytes"]==files["mac-collector.stdout"]["bytes"]and files["mac-collector.stderr"]["bytes"]==0
r=q["remoteResult"];assert r["parentFsyncAfterUnlink"]and r["unlinkAttempted"]and r["unlinkReturned"]and not r["descriptorCloseErrors"]
post=r["postUnlink"];assert post["retainedOriginalFD"]["inode"]==80215400and post["retainedOriginalFD"]["nlink"]==0 and post["archiveNameAbsent"]and post["terminalImmutableMetadataPreserved"]
mac='import os,json,stat,hashlib,datetime\nfrom pathlib import Path\np=Path("/Users/m1/otzaria-native116-staged-archive-20261128")\na=p/"native116-remaining-original-evidence.tar.gz"\nassert not os.path.lexists(a)\nassert sorted(x.name for x in p.iterdir())==["STAGE_TERMINAL.json"]\nf=p/"STAGE_TERMINAL.json";s=f.lstat();assert stat.S_ISREG(s.st_mode)and s.st_ino==80215399and s.st_nlink==1and(s.st_uid,s.st_gid,s.st_mode)==(501,20,33152)\nb=f.read_bytes();assert len(b)==65536and hashlib.sha256(b).hexdigest()=="f60435ce1d4ada723f3afe44ca17fd006564c02cbbee74e48c2ab34368f9db35"\nassert p.lstat().st_ino==80215398\nv=os.statvfs("/System/Volumes/Data")\nprint(json.dumps({"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"stageArchiveAbsent":True,"parentInode":p.lstat().st_ino,"onlyOriginalTerminalRemains":True,"terminalBytes":len(b),"terminalSHA256":hashlib.sha256(b).hexdigest(),"MacDataFreeBytes":v.f_bavail*v.f_frsize,"reclaimedAmountNotInferred":True}))\n'
ssh=["sudo","-n","-u","ubuntu","-H","ssh","-T","-o","BatchMode=yes","-o","StrictHostKeyChecking=yes","-o","IdentitiesOnly=yes","-o","UpdateHostKeys=no","-o","ControlMaster=no","-o","ControlPath=none","-o","ConnectTimeout=8","scaleway-mac"]
z=subprocess.run(ssh+[shlex.join(["python3","-B","-c",mac])],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
assert z.returncode==0 and not z.stderr,(z.returncode,z.stderr.decode(errors="replace")[:1000])
checks=[x["value"]for x in texts["events"]if x["event"]=="CONSUMER_CHECK"];assert len(checks)==2and all(x["complete"]and x["matchingOtherOpenRecords"]==0for x in checks)
print(json.dumps({"files":files,"terminal":texts["TERMINAL.json"],"postUnlink":post,"freshChecks":checks,"independentMacObservation":json.loads(z.stdout),"rootFullEvidenceReadback":True,"status":"INDEPENDENT_EXACT_STAGE_RETIREMENT_CONFIRMED"},sort_keys=True))
