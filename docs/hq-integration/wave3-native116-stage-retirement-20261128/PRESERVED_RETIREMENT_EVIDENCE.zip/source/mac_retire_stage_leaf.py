#!/usr/bin/env python3
"""Exact staged-archive prepare/acknowledged one-leaf retirement.
All original Native tree, references, Git and Windows dependencies are excluded.
Only the Root-reviewed pinned Oracle launcher may supply this closed request.
"""
if not __debug__:
    raise RuntimeError("OPTIMIZED_PYTHON_REFUSED")
import base64
import ctypes
import datetime
import errno
import hashlib
import json
import os
import selectors
import signal
import stat
import struct
import subprocess
import sys
import time

STAGE_ROOT = "/Users/m1/otzaria-native116-staged-archive-20261128"
ARCHIVE_NAME = "native116-remaining-original-evidence.tar.gz"
ARCHIVE_PATH = STAGE_ROOT + "/" + ARCHIVE_NAME
ARCHIVE_BYTES = 1272863810
ARCHIVE_SHA256 = "f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556"
SOURCE_DEVICE = 16777232
PARENT_PIN = {"device": 16777232, "inode": 80215398, "uid": 501, "gid": 20, "mode": 16832}
LEAF_PIN = {"device": 16777232, "inode": 80215400, "uid": 501, "gid": 20,
            "mode": 33024, "nlink": 1, "bytes": ARCHIVE_BYTES, "flags": 0,
            "mtimeNS": "1795845337662706536", "ctimeNS": "1795845386291328289"}
HISTORICAL_NAMES = {ARCHIVE_NAME, "STAGE_TERMINAL.json"}
MAC_RESERVE = 2415919104
MAX_XATTR = 2 * 1024**2
MAX_SIBLINGS = 64
MAX_METADATA_CAPTURE = 128 * 1024
MAX_STDOUT = 512 * 1024
TERMINAL_RESERVE = 16 * 1024
PROBE_STDOUT_CAP = 64 * 1024
PROBE_STDERR_CAP = 16 * 1024
BLOCK = 1024**2
STARTED = time.monotonic()
DEADLINE = STARTED + 1200
ORIGINAL_PARENT_PID = os.getppid()
OUTPUT_BYTES = 0
SEQUENCE = 0
CURRENT_STAGE = "START"
NATIVE_METADATA_ABI = None
NATIVE_FCNTL_HEADER = "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.0.sdk/usr/include/sys/fcntl.h"
NATIVE_FCNTL_HEADER_BYTES = 27609
NATIVE_FCNTL_HEADER_SHA256 = "9aca8ca87031ab7b670617e5af8b15a0cad8f34f7ab3bdb5dd799eb153b3ad0e"
SYMLINK_FLAG = 0x00200000
PYTHON_SYMLINK_FLAG = getattr(os, "O_SYMLINK", None)

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def b64(raw):
    return base64.b64encode(raw).decode("ascii")

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def error_record(error, stage):
    return {"stage": stage, "type": type(error).__name__,
            "errno": error.errno if isinstance(error, OSError) else None,
            "detail": str(error)[:240] if type(error) is RuntimeError else None}

def guard():
    require(time.monotonic() < DEADLINE, "OWNED_COLLECTOR_DEADLINE")
    require(os.getppid() == ORIGINAL_PARENT_PID, "ORIGINAL_SSH_PARENT_DETACHED")
    v = os.statvfs("/System/Volumes/Data")
    require(v.f_bavail * v.f_frsize >= MAC_RESERVE, "UNCHANGED_MAC_LIVE_RESERVE")

def alarm(_signal, _frame):
    raise RuntimeError("OWNED_COLLECTOR_ALARM")

def emit(kind, value, terminal=False):
    global OUTPUT_BYTES, SEQUENCE
    SEQUENCE += 1
    raw = canonical({"sequence": SEQUENCE, "event": kind, "utc": utc(), "value": value}) + b"\n"
    require(len(raw) <= (TERMINAL_RESERVE if terminal else MAX_STDOUT - TERMINAL_RESERVE),
            "FINITE_EVENT_BOUND")
    require(OUTPUT_BYTES + len(raw) <= (MAX_STDOUT if terminal else MAX_STDOUT - TERMINAL_RESERVE),
            "FINITE_TRANSCRIPT_BOUND")
    view = memoryview(raw)
    while view:
        n = os.write(1, view)
        require(n > 0, "STDOUT_SHORT_WRITE")
        view = view[n:]
    OUTPUT_BYTES += len(raw)
    return {"bytes": len(raw), "sha256": digest(raw)}

def identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid, s.st_nlink,
            s.st_size, str(s.st_mtime_ns), str(s.st_ctime_ns), s.st_flags, s.st_rdev)

class AttrList(ctypes.Structure):
    _fields_ = [('count', ctypes.c_uint16), ('reserved', ctypes.c_uint16),
                ('common', ctypes.c_uint32), ('vol', ctypes.c_uint32),
                ('directory', ctypes.c_uint32), ('file', ctypes.c_uint32), ('fork', ctypes.c_uint32)]


LIB = ctypes.CDLL(None, use_errno=True)
LIB.openat.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
LIB.openat.restype = ctypes.c_int
LIB.flistxattr.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
LIB.flistxattr.restype = ctypes.c_ssize_t
LIB.fgetxattr.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.c_int]
LIB.fgetxattr.restype = ctypes.c_ssize_t
LIB.acl_get_fd_np.argtypes = [ctypes.c_int, ctypes.c_int]
LIB.acl_get_fd_np.restype = ctypes.c_void_p
LIB.acl_to_text.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ssize_t)]
LIB.acl_to_text.restype = ctypes.c_void_p
LIB.acl_free.argtypes = [ctypes.c_void_p]
LIB.acl_free.restype = ctypes.c_int
LIB.fgetattrlist.argtypes = [ctypes.c_int, ctypes.POINTER(AttrList), ctypes.c_void_p, ctypes.c_size_t, ctypes.c_ulong]
LIB.fgetattrlist.restype = ctypes.c_int

def qualify_native_metadata_abi():
    # This small read qualifies the same installed header for every producer
    # launch. It grants no access to source data and never writes SDK files.
    fd = os.open(NATIVE_FCNTL_HEADER, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size == NATIVE_FCNTL_HEADER_BYTES,
                'Installed native header type/size changed')
        raw = bytearray()
        while len(raw) <= NATIVE_FCNTL_HEADER_BYTES:
            block = os.read(fd, NATIVE_FCNTL_HEADER_BYTES + 1 - len(raw))
            if not block: break
            raw.extend(block)
        require(len(raw) == NATIVE_FCNTL_HEADER_BYTES and
                digest(raw) == NATIVE_FCNTL_HEADER_SHA256,
                'Installed native header byte identity changed')
        definitions = [line.split()[:3] for line in bytes(raw).splitlines()
                       if line.split()[:2] == [b'#define', b'O_SYMLINK']]
        require(definitions == [[b'#define', b'O_SYMLINK', b'0x00200000']],
                'Installed O_SYMLINK definition changed')
        require(identity(os.fstat(fd)) == identity(before) and
                identity(os.stat(NATIVE_FCNTL_HEADER, follow_symlinks=False)) == identity(before),
                'Installed native header replaced during qualification')
    finally:
        os.close(fd)
    return {'headerPath': NATIVE_FCNTL_HEADER, 'headerBytes': NATIVE_FCNTL_HEADER_BYTES,
            'headerSHA256': NATIVE_FCNTL_HEADER_SHA256, 'symlinkFlag': SYMLINK_FLAG,
            'pythonExposesSymlinkFlag': PYTHON_SYMLINK_FLAG is not None,
            'metadataOpen': 'native libc openat with pinned parent and single final component'}

def extended_metadata(parent_fd, name, before):
    # Darwin O_SYMLINK opens the link itself. Ordinary entries use O_NOFOLLOW.
    # Every native metadata call consumes this verified descriptor directly;
    # there is no /dev/fd path spelling or re-resolution of a source ancestor.
    flags = os.O_RDONLY | (SYMLINK_FLAG if stat.S_ISLNK(before.st_mode) else os.O_NOFOLLOW)
    if stat.S_ISDIR(before.st_mode): flags |= os.O_DIRECTORY
    raw_name = os.fsencode(name)
    require(raw_name and raw_name != b'..' and b'/' not in raw_name and b'\0' not in raw_name,
            'Native metadata open requires one exact final component')
    fd = LIB.openat(parent_fd, raw_name, flags)
    if fd < 0: raise OSError(ctypes.get_errno(), 'Native metadata openat failed')
    try:
        os.set_inheritable(fd, False)
        require(identity(os.fstat(fd)) == identity(before), 'Metadata descriptor identity mismatch')
        value = descriptor_metadata(fd, before)
        require(identity(os.fstat(fd)) == identity(before), 'Metadata descriptor changed')
        require(identity(os.stat(name, dir_fd=parent_fd, follow_symlinks=False)) == identity(before),
                'Metadata source name replaced')
        return value
    finally:
        os.close(fd)

def descriptor_metadata(fd, before):
    options = 0x0020  # XATTR_SHOWCOMPRESSION; fd already identifies the link itself.
    size = LIB.flistxattr(fd, None, 0, options)
    require(0 <= size <= MAX_XATTR, 'xattr name list unavailable/over bound')
    names = ctypes.create_string_buffer(max(1, size))
    require(LIB.flistxattr(fd, names, size, options) == size, 'xattr names changed')
    attributes = []
    for attribute in sorted(x for x in names.raw[:size].split(b'\0') if x):
        guard(); n = LIB.fgetxattr(fd, attribute, None, 0, 0, options)
        require(0 <= n <= MAX_XATTR, 'xattr payload unavailable/over bound')
        value = ctypes.create_string_buffer(max(1, n))
        require(LIB.fgetxattr(fd, attribute, value, n, 0, options) == n, 'xattr changed')
        raw = value.raw[:n]
        attributes.append({'nameBase64': b64(attribute), 'valueBase64': b64(raw),
                           'bytes': n, 'sha256': digest(raw)})
    ctypes.set_errno(0)
    acl = LIB.acl_get_fd_np(fd, 0x00000100)
    acl_value = None
    if not acl:
        require(ctypes.get_errno() == errno.ENOENT, 'ACL inspection failed')
    else:
        length = ctypes.c_ssize_t()
        text = LIB.acl_to_text(acl, ctypes.byref(length))
        try:
            require(text and 0 <= length.value <= MAX_XATTR, 'ACL text unavailable/over bound')
            raw = ctypes.string_at(text, length.value)
            acl_value = {'textBase64': b64(raw), 'bytes': len(raw), 'sha256': digest(raw)}
        finally:
            if text: LIB.acl_free(text)
            LIB.acl_free(acl)
    attrs = AttrList(5, 0, 0x00000200, 0, 0, 0, 0)
    output = ctypes.create_string_buffer(64)
    require(LIB.fgetattrlist(fd, ctypes.byref(attrs), output, 64, 0) == 0, 'Exact birthtime unavailable')
    require(struct.unpack_from('=I', output.raw, 0)[0] == 20, 'Birthtime layout mismatch')
    seconds, ns = struct.unpack_from('=qq', output.raw, 4)
    require(0 <= ns < 10**9 and abs(seconds - int(before.st_birthtime)) <= 1, 'Birthtime check')
    return {'xattrs': attributes, 'acl': acl_value, 'birthtimeNS': str(seconds * 10**9 + ns)}

def record(parent_fd, name, relative, before, full):
    guard()
    kind = 'file' if stat.S_ISREG(before.st_mode) else 'directory' if stat.S_ISDIR(before.st_mode) else 'symlink'
    require(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode) or stat.S_ISLNK(before.st_mode), 'Unsupported special source entry')
    require(before.st_dev == SOURCE_DEVICE, 'Cross-device source entry')
    metadata = extended_metadata(parent_fd, name, before)
    row = {'pathBase64': b64(relative), 'kind': kind, 'device': before.st_dev,
           'inode': before.st_ino, 'mode': before.st_mode, 'uid': before.st_uid,
           'gid': before.st_gid, 'nlink': before.st_nlink, 'bytes': before.st_size,
           'allocatedBytes': before.st_blocks * 512, 'mtimeNS': str(before.st_mtime_ns),
           'ctimeNS': str(before.st_ctime_ns), 'atimeNS': str(before.st_atime_ns),
           'flags': before.st_flags, 'rdev': before.st_rdev, **metadata}
    if kind == 'file' and full:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
        try:
            require(identity(os.fstat(fd)) == identity(before), 'File replaced before read')
            h, count = hashlib.sha256(), 0
            while True:
                guard(); block = os.read(fd, BLOCK)
                if not block: break
                count += len(block); require(count <= before.st_size, 'Source grew during hash'); h.update(block)
            require(count == before.st_size and identity(os.fstat(fd)) == identity(before), 'File changed during hash')
            row['sha256'] = h.hexdigest()
        finally:
            os.close(fd)
    elif kind == 'symlink':
        row['targetBase64'] = b64(os.fsencode(os.readlink(name, dir_fd=parent_fd)))
    require(identity(os.stat(name, dir_fd=parent_fd, follow_symlinks=False)) == identity(before), 'Source path identity changed')
    require(extended_metadata(parent_fd, name, before) == metadata, 'Source extended metadata changed')
    return row

def open_stage_root():
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in STAGE_ROOT.split("/")[1:]:
            guard()
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        s = os.fstat(fd)
        value = {"device": s.st_dev, "inode": s.st_ino, "uid": s.st_uid,
                 "gid": s.st_gid, "mode": s.st_mode}
        require(value == PARENT_PIN, "EXACT_HISTORICAL_STAGE_PARENT")
        require(identity(os.stat(STAGE_ROOT, follow_symlinks=False)) == identity(s),
                "STAGE_PARENT_NAME_FD_JOIN")
        return fd
    except BaseException:
        os.close(fd)
        raise

def stable_metadata(value):
    # atime can change because of this read-only inspection. All other captured
    # fields, including exact nanosecond birthtime, xattrs and ACL stay fenced.
    return {k: v for k, v in value.items() if k != "atimeNS"}

def stat_pin(s):
    return {"device": s.st_dev, "inode": s.st_ino, "mode": s.st_mode,
            "uid": s.st_uid, "gid": s.st_gid, "nlink": s.st_nlink,
            "bytes": s.st_size, "flags": s.st_flags,
            "mtimeNS": str(s.st_mtime_ns), "ctimeNS": str(s.st_ctime_ns)}

def check_leaf_pin(s):
    require(stat.S_ISREG(s.st_mode) and stat_pin(s) == LEAF_PIN,
            "EXACT_HISTORICAL_REGULAR_SINGLE_LINK_STAGE_LEAF")

def list_names(fd):
    names = sorted((os.fsencode(n) for n in os.listdir(fd)))
    require(len(names) <= MAX_SIBLINGS and len(names) == len(set(names)), "SIBLING_COUNT_BOUND")
    for name in names:
        require(name and name not in (b".", b"..") and b"/" not in name and b"\0" not in name,
                "EXACT_SINGLE_COMPONENT_SIBLING")
    return names

def capture_metadata(fd, label):
    # The first fstat happens before listdir. No regular-file contents are read.
    parent_stat = os.fstat(fd)
    require(stat.S_ISDIR(parent_stat.st_mode), "PINNED_PARENT_DIRECTORY")
    parent = record(fd, b".", b"", parent_stat, False)
    names = list_names(fd)
    rows = []
    for name in names:
        guard()
        before = os.stat(name, dir_fd=fd, follow_symlinks=False)
        row = record(fd, name, name, before, False)
        rows.append(row)
        require(len(canonical({"parent": parent, "siblings": rows})) <= MAX_METADATA_CAPTURE,
                "COMPLETE_METADATA_CAPTURE_BOUND")
    require(list_names(fd) == names, "SIBLING_SET_CHANGED_DURING_METADATA")
    require(identity(os.fstat(fd)) == identity(parent_stat), "PARENT_CHANGED_DURING_METADATA")
    value = {"label": label, "parent": parent, "siblings": rows,
             "siblingCount": len(rows), "allImmediateSiblingsCaptured": True,
             "regularContentReads": 0, "recursiveTraversal": False,
             "historicalMembershipUnchanged": set(os.fsdecode(n) for n in names) == HISTORICAL_NAMES}
    require(len(canonical(value)) <= MAX_METADATA_CAPTURE, "COMPLETE_METADATA_CAPTURE_BOUND")
    emit("METADATA_CAPTURE", value)
    return value

def require_same_capture(before, after):
    require(stable_metadata(before["parent"]) == stable_metadata(after["parent"]),
            "PARENT_METADATA_CHANGED")
    old = {r["pathBase64"]: r for r in before["siblings"]}
    new = {r["pathBase64"]: r for r in after["siblings"]}
    require(set(old) == set(new), "SIBLING_MEMBERSHIP_CHANGED")
    for path in old:
        require(stable_metadata(old[path]) == stable_metadata(new[path]), "SIBLING_METADATA_CHANGED")
    return {"parent": {"before": before["parent"]["atimeNS"], "after": after["parent"]["atimeNS"]},
            "siblings": [{"pathBase64": k, "before": old[k]["atimeNS"], "after": new[k]["atimeNS"]}
                         for k in sorted(old)]}

def stop_owned_mac(process, identity_value, cleanup):
    if process.returncode is not None:
        return
    # No poll/reap before the signal decision. Only this unreaped Popen leader
    # and the group/session created by start_new_session=True may be signalled.
    pgid, sid = os.getpgid(process.pid), os.getsid(process.pid)
    require(pgid == sid == process.pid, "OWNED_PROBE_GROUP_IDENTITY")
    if identity_value is not None:
        require(identity_value == {"pid": process.pid, "pgid": pgid, "session": sid},
                "OWNED_PROBE_IDENTITY_CHANGED")
    os.killpg(process.pid, signal.SIGTERM)
    cleanup.append({"signal": "TERM", "pid": process.pid, "pgid": pgid})
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        require(os.getpgid(process.pid) == os.getsid(process.pid) == process.pid,
                "OWNED_PROBE_GROUP_CHANGED")
        os.killpg(process.pid, signal.SIGKILL)
        cleanup.append({"signal": "KILL", "pid": process.pid, "pgid": pgid})
        process.wait(timeout=5)

def run_probe(argv, label, seconds):
    process = None
    process_identity_value = None
    selector = None
    out, err = bytearray(), bytearray()
    failure, cleanup = None, []
    started = time.monotonic()
    try:
        guard()
        process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, close_fds=True, start_new_session=True)
        # Immediate protected cleanup after Popen, including identity/setup failure.
        try:
            process_identity_value = {"pid": process.pid, "pgid": os.getpgid(process.pid),
                                      "session": os.getsid(process.pid)}
            require(process_identity_value["pgid"] == process_identity_value["session"] == process.pid,
                    "OWNED_PROBE_SESSION")
            selector = selectors.DefaultSelector()
            for name, stream in (("stdout", process.stdout), ("stderr", process.stderr)):
                os.set_blocking(stream.fileno(), False)
                selector.register(stream.fileno(), selectors.EVENT_READ, name)
            until = min(DEADLINE, started + seconds)
            while selector.get_map():
                guard()
                require(time.monotonic() < until, "BOUNDED_CONSUMER_INSPECTION_DEADLINE")
                for key, _ in selector.select(0.1):
                    try:
                        raw = os.read(key.fd, 16384)
                    except BlockingIOError:
                        continue
                    if not raw:
                        selector.unregister(key.fd)
                        continue
                    buffer, cap = (out, PROBE_STDOUT_CAP) if key.data == "stdout" else (err, PROBE_STDERR_CAP)
                    remaining = cap - len(buffer)
                    buffer.extend(raw[:remaining])
                    require(len(raw) <= remaining, "BOUNDED_CONSUMER_INSPECTION_OUTPUT")
            process.wait(timeout=max(0.01, min(5, until - time.monotonic())))
        finally:
            try:
                stop_owned_mac(process, process_identity_value, cleanup)
            finally:
                if selector is not None:
                    selector.close()
                for stream in (process.stdout, process.stderr):
                    if stream is not None:
                        stream.close()
    except BaseException as error:
        failure = error_record(error, label)
    value = {"label": label, "argv": argv, "identity": process_identity_value,
             "returncode": process.returncode if process else None,
             "ownedLeaderReaped": process is not None and process.returncode is not None,
             "descendantExtinctionClaimed": False, "seconds": time.monotonic() - started,
             "stdoutBase64": b64(out), "stderrBase64": b64(err),
             "stdoutBytes": len(out), "stderrBytes": len(err),
             "stdoutSHA256": digest(out), "stderrSHA256": digest(err),
             "failure": failure, "cleanup": cleanup, "automaticRetries": 0}
    emit("CONSUMER_PROBE", value)
    return value, bytes(out), bytes(err)

def parse_lsof(raw, archive_fd):
    # Closed requested fields only. The NUL machine format is retained raw.
    # A known open read-only descriptor in this collector is a required positive
    # witness that this exact leaf was inspected; an empty query never proves no-use.
    process_info, file_info = None, None
    files = []
    def flush_file():
        nonlocal file_info
        if file_info is not None:
            require(process_info is not None, "LSOF_FILE_WITHOUT_PROCESS")
            files.append({"process": dict(process_info), "file": dict(file_info)})
            file_info = None
    for token in raw.split(b"\0"):
        token = token.lstrip(b"\n")
        if not token:
            continue
        field, value = token[:1], token[1:]
        require(field in (b"p", b"c", b"u", b"f", b"a", b"t", b"D", b"i", b"s", b"n"),
                "LSOF_UNEXPECTED_FIELD")
        if field == b"p":
            flush_file()
            require(value.isdigit() and len(value) <= 10, "LSOF_PID")
            process_info = {"p": value}
        elif field in (b"c", b"u"):
            require(process_info is not None and file_info is None, "LSOF_PROCESS_FIELD_ORDER")
            require(field.decode() not in process_info, "LSOF_DUPLICATE_PROCESS_FIELD")
            process_info[field.decode()] = value
        elif field == b"f":
            flush_file()
            require(process_info is not None, "LSOF_FD_WITHOUT_PROCESS")
            file_info = {"f": value}
        else:
            require(file_info is not None and field.decode() not in file_info, "LSOF_FILE_FIELD_ORDER")
            file_info[field.decode()] = value
    flush_file()
    require(0 < len(files) <= 256, "LSOF_FINITE_POSITIVE_FILE_SET")
    own, other = [], []
    for entry in files:
        p, f = entry["process"], entry["file"]
        require(set(p) == {"p", "c", "u"} and set(f) == {"f", "a", "t", "D", "i", "s", "n"},
                "LSOF_COMPLETE_REQUESTED_FIELDS")
        require(p["u"].isdigit() and len(p["u"]) <= 10, "LSOF_UID")
        require(f["i"].isdigit() and len(f["i"]) <= 20 and
                f["s"].isdigit() and len(f["s"]) <= 20, "LSOF_NUMERIC_FIELDS")
        d = f["D"]
        require(0 < len(d) <= 18 and
                ((d.startswith(b"0x") and all(c in b"0123456789abcdefABCDEF" for c in d[2:]))
                 or d.isdigit()), "LSOF_DEVICE_FORMAT")
        device = int(d, 16) if d.startswith(b"0x") else int(d, 10)
        require(device == SOURCE_DEVICE and int(f["i"]) == LEAF_PIN["inode"] and
                int(f["s"]) == ARCHIVE_BYTES and f["t"] == b"REG" and
                f["n"] == os.fsencode(ARCHIVE_PATH), "LSOF_EXACT_LEAF_JOIN")
        is_own = (int(p["p"]) == os.getpid() and int(p["u"]) == 501
                  and f["f"] == str(archive_fd).encode() and f["a"] == b"r")
        (own if is_own else other).append(entry)
    require(len(own) == 1, "LSOF_KNOWN_DESCRIPTOR_POSITIVE_WITNESS")
    return {"positiveOwnReadFD": archive_fd, "ownReaderPID": os.getpid(),
            "matchingOtherOpenRecords": len(other), "noOtherOpenRecordsObserved": not other,
            "coverage": "One privileged lsof query for the exact file; no future-consumer or lease claim",
            "otherRecordIdentities": [{"pid": int(x["process"]["p"]), "uid": int(x["process"]["u"]),
                                      "commBase64": b64(x["process"]["c"]),
                                      "fdBase64": b64(x["file"]["f"]),
                                      "accessBase64": b64(x["file"]["a"])} for x in other]}

def consumer_check(label, archive_fd, root_probe_ok):
    if not root_probe_ok:
        value = {"label": label, "complete": False, "noOtherOpenRecordsObserved": False,
                 "inspectionError": {"type": "PrivilegeQualificationUnavailable"},
                 "scope": "Exact staged leaf only"}
        emit("CONSUMER_CHECK", value)
        return value
    argv = ["/usr/bin/sudo", "-n", "/usr/sbin/lsof", "-nP", "-l",
            "-F0pcufaDtisn", "--", ARCHIVE_PATH]
    probe, out, err = run_probe(argv, label, 20)
    try:
        require(probe["failure"] is None and probe["returncode"] == 0 and not err,
                "PRIVILEGED_LSOF_INSPECTION_INCOMPLETE")
        result = parse_lsof(out, archive_fd)
        result.update({"label": label, "complete": True, "inspectionError": None})
    except BaseException as error:
        result = {"label": label, "complete": False, "noOtherOpenRecordsObserved": False,
                  "inspectionError": error_record(error, label)}
    emit("CONSUMER_CHECK", result)
    return result

def full_hash(fd, parent):
    require(identity(os.fstat(fd)) == identity(os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False)),
            "ARCHIVE_FD_NAME_BEFORE_HASH")
    check_leaf_pin(os.fstat(fd))
    os.lseek(fd, 0, os.SEEK_SET)
    h, count = hashlib.sha256(), 0
    while True:
        guard()
        check_leaf_pin(os.fstat(fd))
        check_leaf_pin(os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False))
        raw = os.read(fd, BLOCK)
        if not raw:
            break
        count += len(raw)
        require(count <= ARCHIVE_BYTES, "ARCHIVE_SIZE_GREW")
        h.update(raw)
    require(count == ARCHIVE_BYTES and h.hexdigest() == ARCHIVE_SHA256, "FULL_ARCHIVE_SHA256")
    check_leaf_pin(os.fstat(fd))
    check_leaf_pin(os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False))
    return {"bytes": count, "sha256": h.hexdigest(), "regularPayloadsHashed": 1}

TERMINAL_GRACE_SECONDS = 15
FULL_NATIVE_SHA256 = "e9242bcf55ad96d02f5d5ad876dc65813a40699258406b360ead957cf5cda702"
POINTER_SHA256 = "59b453bc05306e26f76ab4b557c5831b1f26386988bc42a1edb5556dcd787983"
RESTORER_SEAL_SHA256 = "2ac9a9125dbc680664e68a0ca53661ca569416ff8bdc003e306997e542f0d755"
EXPECTED=json.loads("{\"parent\":{\"acl\":null,\"allocatedBytes\":0,\"atimeNS\":\"1795845249365515805\",\"birthtimeNS\":\"1795845188978746795\",\"bytes\":128,\"ctimeNS\":\"1795845188979074585\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215398,\"kind\":\"directory\",\"mode\":16832,\"mtimeNS\":\"1795845188979074585\",\"nlink\":4,\"pathBase64\":\"\",\"rdev\":0,\"uid\":501,\"xattrs\":[]},\"terminal\":{\"acl\":null,\"allocatedBytes\":65536,\"atimeNS\":\"1795845386429359912\",\"birthtimeNS\":\"1795845188978882252\",\"bytes\":65536,\"ctimeNS\":\"1795845386291846079\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215399,\"kind\":\"file\",\"mode\":33152,\"mtimeNS\":\"1795845386291846079\",\"nlink\":1,\"pathBase64\":\"U1RBR0VfVEVSTUlOQUwuanNvbg==\",\"rdev\":0,\"uid\":501,\"xattrs\":[]},\"archive\":{\"acl\":null,\"allocatedBytes\":1272864768,\"atimeNS\":\"1795845385698193451\",\"birthtimeNS\":\"1795845188979067835\",\"bytes\":1272863810,\"ctimeNS\":\"1795845386291328289\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215400,\"kind\":\"file\",\"mode\":33024,\"mtimeNS\":\"1795845337662706536\",\"nlink\":1,\"pathBase64\":\"bmF0aXZlMTE2LXJlbWFpbmluZy1vcmlnaW5hbC1ldmlkZW5jZS50YXIuZ3o=\",\"rdev\":0,\"uid\":501,\"xattrs\":[]}}")

def terminal_alarm(_signal, _frame):
    os._exit(124)

def exact_sha(value):
    require(type(value) is str and len(value) == 64 and
            all(x in "0123456789abcdef" for x in value), "EXACT_SHA256")
    return value

def validate_request(request):
    require(type(request) is dict and set(request) == {
        "schema", "phase", "retirementSourceSealSHA256", "rootDurableProofSHA256",
        "pointerSHA256", "qualificationSHA256", "restorerSourceSealSHA256", "predeleteSHA256", "prepared"},
        "CLOSED_ROOT_RETIREMENT_REQUEST")
    require(request["schema"] == "otzaria.native116-stage-leaf-retirement-request/1"
            and request["phase"] in ("prepare", "commit")
            and request["pointerSHA256"] == POINTER_SHA256
            and request["qualificationSHA256"] == FULL_NATIVE_SHA256
            and request["restorerSourceSealSHA256"] == RESTORER_SEAL_SHA256,
            "EXACT_ROOT_RETIREMENT_BINDING")
    for key in ("retirementSourceSealSHA256", "rootDurableProofSHA256"):
        exact_sha(request[key])
    if request["phase"] == "prepare":
        require(request["predeleteSHA256"] is None and request["prepared"] is None,
                "PREPARE_HAS_NO_UNLINK_ACK")
    else:
        exact_sha(request["predeleteSHA256"])
        p = request["prepared"]
        require(type(p) is dict and p["schema"] == "otzaria.native116-stage-leaf-predelete-capture/1"
                and p["archivePath"] == ARCHIVE_PATH and p["removed"] is False
                and p["pointerSHA256"] == POINTER_SHA256
                and p["qualificationSHA256"] == FULL_NATIVE_SHA256
                and p["restorerSourceSealSHA256"] == RESTORER_SEAL_SHA256
                and p["rootDurableProofSHA256"] == request["rootDurableProofSHA256"]
                and p["retirementSourceSealSHA256"] == request["retirementSourceSealSHA256"],
                "ROOT_ACK_EXACT_PREPARE_BINDING")
    return request["phase"]

def exact_capture(value):
    require(value["historicalMembershipUnchanged"] is True and value["siblingCount"] == 2
            and value["allImmediateSiblingsCaptured"] is True, "EXACT_TWO_STAGE_NAMES")
    rows = {r["pathBase64"]: r for r in value["siblings"]}
    require(set(rows) == {EXPECTED["archive"]["pathBase64"], EXPECTED["terminal"]["pathBase64"]},
            "EXACT_STAGE_LEAF_AND_TERMINAL")
    require(stable_metadata(value["parent"]) == stable_metadata(EXPECTED["parent"]),
            "ORIGINAL_STAGE_PARENT_METADATA")
    require(stable_metadata(rows[EXPECTED["archive"]["pathBase64"]]) == stable_metadata(EXPECTED["archive"]),
            "ORIGINAL_STAGE_ARCHIVE_METADATA")
    require(stable_metadata(rows[EXPECTED["terminal"]["pathBase64"]]) == stable_metadata(EXPECTED["terminal"]),
            "ORIGINAL_STAGE_TERMINAL_METADATA")
    return rows

def terminal_hash(parent):
    name = b"STAGE_TERMINAL.json"
    before = os.stat(name, dir_fd=parent, follow_symlinks=False)
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
            and before.st_ino == EXPECTED["terminal"]["inode"] and before.st_dev == SOURCE_DEVICE
            and before.st_uid == 501 and before.st_gid == 20
            and before.st_mode == 33152 and before.st_size == 65536,
            "EXACT_PROTECTED_TERMINAL_LEAF")
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
    try:
        require(identity(os.fstat(fd)) == identity(before), "TERMINAL_FD_NAME_JOIN")
        h = hashlib.sha256();count = 0
        while True:
            guard()
            raw = os.read(fd, min(16384, 65537-count))
            if not raw:break
            count += len(raw);require(count <= 65536, "BOUNDED_TERMINAL_BYTES");h.update(raw)
        require(count == 65536 and identity(os.fstat(fd)) == identity(before)
                and identity(os.stat(name, dir_fd=parent, follow_symlinks=False)) == identity(before),
                "TERMINAL_CONTENT_READ_FENCE")
        return {"bytes": count, "sha256": h.hexdigest(), "inode": before.st_ino,
                "device": before.st_dev}
    finally:
        os.close(fd)

def require_clean_consumer(value):
    require(value["complete"] is True and value["inspectionError"] is None
            and value["noOtherOpenRecordsObserved"] is True
            and value["matchingOtherOpenRecords"] == 0, "COMPLETE_NO_OTHER_OPEN_USE_REQUIRED")

def immediate_unlink_join(parent, archive, before):
    # Fixed descriptor/name checks only after the final privileged lsof completes.
    guard()
    require(identity(os.stat(STAGE_ROOT, follow_symlinks=False)) == identity(os.fstat(parent)),
            "PINNED_PARENT_NAME_FD_IMMEDIATE_JOIN")
    require(stat_pin(os.fstat(parent)) == {
        k: before["parent"][k] for k in ("device", "inode", "mode", "uid", "gid",
                                        "nlink", "bytes", "flags", "mtimeNS", "ctimeNS")},
        "PARENT_NAMESPACE_UNCHANGED_BEFORE_UNLINK")
    check_leaf_pin(os.fstat(archive))
    named = os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False)
    check_leaf_pin(named)
    require(identity(named) == identity(os.fstat(archive)), "SAME_PARENTFD_FINAL_LEAF_JOIN")
    require(list_names(parent) == sorted([os.fsencode(ARCHIVE_NAME), b"STAGE_TERMINAL.json"]),
            "NO_ADDED_STAGE_SIBLING")
    terminal = next(r for r in before["siblings"] if r["pathBase64"] == EXPECTED["terminal"]["pathBase64"])
    require(stat_pin(os.stat("STAGE_TERMINAL.json", dir_fd=parent, follow_symlinks=False)) == {
        k: terminal[k] for k in ("device", "inode", "mode", "uid", "gid",
                                "nlink", "bytes", "flags", "mtimeNS", "ctimeNS")},
        "PROTECTED_TERMINAL_FINAL_IDENTITY")

def unlinked_fd_proof(archive):
    s = os.fstat(archive)
    require(stat.S_ISREG(s.st_mode) and s.st_nlink == 0
            and s.st_dev == SOURCE_DEVICE and s.st_ino == 80215400
            and s.st_uid == 501 and s.st_gid == 20 and s.st_mode == 33024
            and s.st_size == ARCHIVE_BYTES and s.st_flags == 0
            and str(s.st_mtime_ns) == EXPECTED["archive"]["mtimeNS"],
            "SAME_ORIGINAL_INODE_UNLINKED_ON_RETAINED_FD")
    extra = descriptor_metadata(archive, s)
    require(extra["xattrs"] == [] and extra["acl"] is None
            and extra["birthtimeNS"] == EXPECTED["archive"]["birthtimeNS"],
            "UNLINKED_FD_ORIGINAL_EXTENDED_METADATA")
    return {"device": s.st_dev, "inode": s.st_ino, "nlink": s.st_nlink,
            "uid": s.st_uid, "gid": s.st_gid, "mode": s.st_mode, "bytes": s.st_size,
            "flags": s.st_flags, "mtimeNS": str(s.st_mtime_ns), "ctimeNS": str(s.st_ctime_ns),
            "atimeNS": str(s.st_atime_ns), "allocatedBytesObservedBeforeOwnClose": s.st_blocks*512,
            **extra, "privateAPFSReclaimClaimed": False}

def post_unlink_join(parent, archive, before, terminal_before_hash):
    try:
        os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False)
    except FileNotFoundError:
        pass
    else:
        raise RuntimeError("ARCHIVE_NAME_PRESENT_AFTER_ONE_UNLINK")
    require(list_names(parent) == [b"STAGE_TERMINAL.json"], "ONLY_TERMINAL_SIBLING_REMAINS")
    fdproof = unlinked_fd_proof(archive)
    after = capture_metadata(parent, "AFTER_EXACT_ARCHIVE_UNLINK")
    require(after["siblingCount"] == 1 and len(after["siblings"]) == 1
            and stable_metadata(after["siblings"][0]) == stable_metadata(EXPECTED["terminal"]),
            "TERMINAL_IMMUTABLE_METADATA_PRESERVED")
    permitted_namespace_fields = {"atimeNS","mtimeNS","ctimeNS","bytes","nlink","allocatedBytes"}
    require({k:v for k,v in before["parent"].items() if k not in permitted_namespace_fields} ==
            {k:v for k,v in after["parent"].items() if k not in permitted_namespace_fields},
            "RETAINED_PARENT_IDENTITY_AND_EXTENDED_METADATA")
    terminal_after_hash = terminal_hash(parent)
    require(terminal_after_hash == terminal_before_hash, "FULL_TERMINAL_BYTES_PRESERVED")
    # Recheck immutable sibling metadata after its final bounded read.
    terminal_stat = os.stat("STAGE_TERMINAL.json", dir_fd=parent, follow_symlinks=False)
    terminal_row = record(parent, b"STAGE_TERMINAL.json", b"STAGE_TERMINAL.json", terminal_stat, False)
    require(stable_metadata(terminal_row) == stable_metadata(EXPECTED["terminal"]),
            "TERMINAL_POST_HASH_METADATA")
    require(identity(os.stat(STAGE_ROOT, follow_symlinks=False)) == identity(os.fstat(parent)),
            "RETAINED_PARENT_NAME_FD_AFTER_UNLINK")
    return {"archiveNameAbsent": True, "retainedOriginalFD": fdproof,
            "terminalHashBeforeAndAfter": terminal_after_hash,
            "terminalImmutableMetadataPreserved": True,
            "terminalAtimeBefore": next(r["atimeNS"] for r in before["siblings"] if r["pathBase64"] == EXPECTED["terminal"]["pathBase64"]),
            "terminalAtimeAfter": terminal_row["atimeNS"],
            "parentBefore": before["parent"], "parentAfter": after["parent"],
            "parentNamespaceChangesExplicit": True, "allOtherNamesUntouched": True}

def main(request):
    global CURRENT_STAGE, NATIVE_METADATA_ABI
    parent = archive = None;phase = None
    failure = None;unlink_attempted = False;unlink_returned = False;parent_synced = False
    result = {"schema":"otzaria.native116-exact-stage-leaf-retirement/1",
              "status":"INCOMPLETE","archivePath":ARCHIVE_PATH,"removed":False}
    signal.signal(signal.SIGALRM, alarm);signal.alarm(1200)
    try:
        phase = validate_request(request)
        require(sys.platform == "darwin" and ctypes.sizeof(ctypes.c_void_p) == 8
                and sys.flags.isolated and sys.dont_write_bytecode and os.geteuid() == 501,
                "QUALIFIED_ISOLATED_ORIGINAL_M1_RUNTIME")
        require(PYTHON_SYMLINK_FLAG is None or
                (type(PYTHON_SYMLINK_FLAG) is int and PYTHON_SYMLINK_FLAG == SYMLINK_FLAG),
                "PYTHON_NATIVE_SYMLINK_FLAG_DISAGREEMENT")
        guard()
        emit("START",{"phase":phase,"pid":os.getpid(),"parentPID":ORIGINAL_PARENT_PID,
              "rootDurableProofSHA256":request["rootDurableProofSHA256"],
              "pointerSHA256":POINTER_SHA256,"qualificationSHA256":FULL_NATIVE_SHA256,
              "retirementSourceSealSHA256":request["retirementSourceSealSHA256"],
              "predeleteSHA256":request["predeleteSHA256"],"macLiveFloor":MAC_RESERVE,
              "bodyDeadlineSeconds":1200,"terminalGraceSeconds":TERMINAL_GRACE_SECONDS})
        CURRENT_STAGE = "NATIVE_METADATA_ABI"
        NATIVE_METADATA_ABI = qualify_native_metadata_abi();emit("NATIVE_METADATA_ABI",NATIVE_METADATA_ABI)
        CURRENT_STAGE = "CAPTURE_BEFORE_CONTENT"
        parent = open_stage_root()
        before = capture_metadata(parent,"BEFORE_ANY_STAGE_CONTENT_READ");exact_capture(before)
        archive = os.open(ARCHIVE_NAME,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=parent)
        check_leaf_pin(os.fstat(archive))
        require(not os.get_inheritable(archive),"PRIVATE_NONINHERITABLE_ARCHIVE_FD")
        CURRENT_STAGE = "PRIVILEGED_CONSUMER_CAPABILITY"
        privilege,raw,err = run_probe(["/usr/bin/sudo","-n","/usr/bin/id","-u"],
                                     "privileged-inspection-capability",10)
        root_ok = privilege["failure"] is None and privilege["returncode"] == 0 and raw == b"0\n" and not err
        first = consumer_check("before-content-hash",archive,root_ok);require_clean_consumer(first)
        CURRENT_STAGE = "COMPLETE_ARCHIVE_AND_TERMINAL_HASHES"
        archive_hash = full_hash(archive,parent);emit("ARCHIVE_HASH",archive_hash)
        sibling_hash = terminal_hash(parent);emit("PROTECTED_TERMINAL_HASH",sibling_hash)
        after_hash = capture_metadata(parent,"AFTER_COMPLETE_CONTENT_HASHES")
        exact_capture(after_hash);atimes = require_same_capture(before,after_hash)
        if phase == "commit":
            prepared = request["prepared"]
            require_same_capture(prepared["metadata"],after_hash)
            require(prepared["archiveHash"] == archive_hash and prepared["terminalHash"] == sibling_hash,
                    "CURRENT_BYTES_MATCH_ROOT_ACKNOWLEDGED_PREDELETE")
        CURRENT_STAGE = "FINAL_COMPLETE_PRIVILEGED_NO_USE"
        final_use = consumer_check("immediately-before-predelete-or-unlink",archive,root_ok)
        require_clean_consumer(final_use)
        immediate_unlink_join(parent,archive,after_hash)
        if phase == "prepare":
            predelete = {"schema":"otzaria.native116-stage-leaf-predelete-capture/1",
                "archivePath":ARCHIVE_PATH,"metadata":after_hash,"archiveHash":archive_hash,
                "terminalHash":sibling_hash,"finalNoUse":final_use,"removed":False,
                "pointerSHA256":POINTER_SHA256,"qualificationSHA256":FULL_NATIVE_SHA256,
                "restorerSourceSealSHA256":RESTORER_SEAL_SHA256,
                "rootDurableProofSHA256":request["rootDurableProofSHA256"],
                "retirementSourceSealSHA256":request["retirementSourceSealSHA256"],
                "inspectionIsPointInTime":True,"futureConsumerClosureNotInferred":True,
                "readAtimeComparisons":atimes}
            emit("PREDELETE_CAPTURE",predelete)
            result.update(status="STAGE_LEAF_PREDELETE_CAPTURED",preparedSHA256=digest(canonical(predelete)),
                          fullArchiveHash=archive_hash,terminalHash=sibling_hash,
                          freshCompleteNoOtherOpenUse=True,sourceWrites=False)
        else:
            CURRENT_STAGE = "ONE_EXACT_SAME_PARENTFD_UNLINK"
            unlink_attempted = True;result["removed"] = None
            os.unlink(ARCHIVE_NAME,dir_fd=parent)
            unlink_returned = True;result["removed"] = True
            os.fsync(parent);parent_synced = True
            CURRENT_STAGE = "POST_UNLINK_FD_PARENT_AND_TERMINAL_PROOF"
            result["postUnlink"] = post_unlink_join(parent,archive,after_hash,sibling_hash)
            result.update(status="EXACT_STAGE_ARCHIVE_LEAF_RETIRED",
                          fullArchiveHash=archive_hash,terminalHash=sibling_hash,
                          freshCompleteNoOtherOpenUse=True,sourceWrites=True)
    except BaseException as error:
        failure = error_record(error,CURRENT_STAGE)
        result["status"] = "RETIREMENT_PHASE_FAILED_PRESERVE_PARTIAL_STATE"
    finally:
        signal.signal(signal.SIGALRM,terminal_alarm);signal.alarm(TERMINAL_GRACE_SECONDS)
        close_errors = []
        if parent is not None and unlink_attempted:
            try:os.fsync(parent)
            except BaseException as error:close_errors.append(error_record(error,"PARENT_FSYNC_FINALLY"))
        for fd in (archive,parent):
            if fd is not None:
                try:os.close(fd)
                except BaseException as error:close_errors.append(error_record(error,"CLOSE_OWN_DESCRIPTOR"))
        if close_errors:result["status"] = "RETIREMENT_PHASE_FAILED_PRESERVE_PARTIAL_STATE"
        result.update(phase=phase,failure=failure,descriptorCloseErrors=close_errors,
            unlinkAttempted=unlink_attempted,unlinkReturned=unlink_returned,parentFsyncAfterUnlink=parent_synced,
            seconds=time.monotonic()-STARTED,finalStage=CURRENT_STAGE,terminalGraceSeconds=TERMINAL_GRACE_SECONDS,
            exactlyOneFixedLeafUnlinkAtMost=True,noAutomaticRetry=True,noAutomaticPayloadCleanup=True,
            originalNativeTreeVisited=False,externalReferencesGitWindowsUntouched=True,
            foreignProcessesSignalled=False,privateAPFSReclaimClaimed=False,
            pointerSHA256=POINTER_SHA256,qualificationSHA256=FULL_NATIVE_SHA256,
            restorerSourceSealSHA256=RESTORER_SEAL_SHA256,
            retirementSourceSealSHA256=request.get("retirementSourceSealSHA256") if isinstance(request,dict) else None,
            rootDurableProofSHA256=request.get("rootDurableProofSHA256") if isinstance(request,dict) else None,
            predeleteSHA256=request.get("predeleteSHA256") if isinstance(request,dict) else None)
        emit("FINAL_RESULT",result,terminal=True)
        signal.alarm(0)
    return 0 if result["status"] in ("STAGE_LEAF_PREDELETE_CAPTURED","EXACT_STAGE_ARCHIVE_LEAF_RETIRED") else 2

if __name__ == "__main__":
    raise RuntimeError("PINNED_ORACLE_REQUEST_REQUIRED")
