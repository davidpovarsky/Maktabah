# Exact Native116 staged archive retirement — source only

## Scope and current status

This packet contains a two-phase, one-leaf procedure for
`/Users/m1/otzaria-native116-staged-archive-20261128/native116-remaining-original-evidence.tar.gz`.
No phase, SSH request, live Mac inspection, API request, GET, unlink, restoration, test or compiler has run from this packet.

The original Native116 tree, its five external references, its Git references and Windows dependencies remain outside the procedure. The containing stage directory and its `STAGE_TERMINAL.json` sibling remain. This procedure neither regenerates nor extracts the archive.

The archive is exactly 1,272,863,810 bytes with SHA256
`f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556`.
Its immutable private preservation asset is 803618998 in draft release 461304898 of private repository 1474927804. Existing full readback result `e9242bcf...` and actual job `job_a02eee978d8f` qualified all bytes and every original payload member. This is preservation evidence; it grants no native product or SDK acceptance.

## Required Root durable proof

Before either phase, Root must create exactly one file in this packet's otherwise absent `admission` directory: `ROOT_DURABLE_GIT_PROOF.json`. Its complete SHA256 is supplied on the command line. The dispatcher does not fabricate this proof or perform a Git/API request. It trusts the explicitly pinned Root proof as the approval/evidence adapter after Root has completed the actual durable publication and full remote byte readback.

Required fields are enforced by `verify_restoration_and_durable_proof`:

- `schema`: `otzaria.native116-stage-restoration-durable-root-proof/1`.
- `status`: `ROOT_REVIEWED_REMOTE_GIT_BYTES_EQUAL`; `commit`: the actual 40-hex commit.
- `pointerSHA256`: `59b453bc05306e26f76ab4b557c5831b1f26386988bc42a1edb5556dcd787983`.
- `sourceSealSHA256`: the restorer seal `2ac9a9125dbc680664e68a0ca53661ca569416ff8bdc003e306997e542f0d755`.
- `completeRemoteReadback`: true.
- `preservedRestorerFiles`: the exact seven-name bytes/SHA mapping in the controller's `RESTORER_PINS`, including `admission/RESTORATION_POINTER.json`.
- `preservedHistoricalSourceSeals`: the controller's exact three `{path, sourceSeal}` entries, without allocation fields.
- `allRequiredRestorerSourceFamiliesPreserved`: true only after the complete referenced source families are durably recoverable; preserving merely three seal JSON files is insufficient.
- `fullReadbackResultSHA256`: `e9242bcf55ad96d02f5d5ad876dc65813a40699258406b360ead957cf5cda702`.
- `retirementSourceSealSHA256`: this packet's actual final source seal.
- `authorizedExactRetirementPath`: the exact full archive pathname above.
- `rootOwnedStageClosed` and `stageHasNoRemainingRequiredConsumers`: true only after Root's actual ownership/dependency closure.

The last two fields are Root's explicit closed-ownership prerequisite. A point-in-time open-file observation cannot prove that a future writer will never open the leaf. Root must maintain source/consumer exclusion through the two admitted phases. No absence, age, UID alone, hypothetical free space or failed prior upload supplies approval.

The dispatcher reads the existing pinned Native full receipt, exact two-line actual job output and source-before/source-after receipts, plus all seven executable restorer/pointer files. It reuses the restorer's complete qualification function byte for byte, including all three complete assets, the preserved starter, full member checks and original source checks. It rechecks these inputs after the remote phase. Existing raw private API journals are not copied or printed.

## Future invocation order

Root first supplies the durable proof and reviews this complete source/seal. Run under the existing ubuntu account with isolated Python and bytecode disabled:

```text
/usr/bin/sudo -u ubuntu -H /usr/bin/python3 -I -B /home/ubuntu/otzaria-wave3-native116-stage-leaf-retirement-proposal-20261128/retire_stage_leaf.py --source-seal-sha256 <actual-source-seal> --durable-proof-sha256 <actual-proof-sha> prepare
```

The prepare phase creates an exclusive local `prepare` journal. It captures the exact Mac parent and both siblings before content reads; hashes the entire archive and the bounded terminal sibling; uses the qualified native FD metadata and complete privileged lsof parser; and retains full raw output. Success yields a fsynced, fully read-back `prepare/PREDELETE.json`, followed by terminal success. It performs no unlink. Root must inspect both the full PREDELETE and actual successful terminal.

Only then may Root explicitly acknowledge that exact PREDELETE SHA:

```text
/usr/bin/sudo -u ubuntu -H /usr/bin/python3 -I -B /home/ubuntu/otzaria-wave3-native116-stage-leaf-retirement-proposal-20261128/retire_stage_leaf.py --source-seal-sha256 <same-source-seal> --durable-proof-sha256 <same-proof-sha> --predelete-sha256 <actual-reviewed-predelete-sha> commit
```

Commit requires the successful prepare's full raw/terminal joins. It uses a separate exclusive `commit` journal. It repeats full current archive/terminal hashes and descriptor metadata. After fresh complete privileged no-use evidence, it rechecks the pinned parent descriptor, fixed name, original inode 80215400, device 16777232, uid501/gid20, mode0400, nlink1 and namespace. There is exactly one fixed `os.unlink(ARCHIVE_NAME, dir_fd=parent)` call in the Mac source. No other name is an unlink target.

Commit fsyncs the retained parent, proves the still-open original descriptor has nlink0, observes the archive name absent, and rehashes/rechecks the original terminal sibling. It records parent namespace timestamp/size/link/allocation changes explicitly. Read-related atime differences are reported rather than silently restored or claimed equal. It closes only its own descriptors.

A failure around unlink can have an indeterminate effect: `removed: null` is preserved until the call is known to have returned. A returned unlink followed by failed fsync, proof or reporting remains a failure with its partial effect retained. No failed phase may be retried automatically, and no failed artifact or payload is cleaned up.

## Bounds and ownership

This retirement operation has a separate explicit budget; it does not change or consume the restorer's four-family 2 MiB contract:

| Family | Allocated-byte maximum |
| --- | ---: |
| This source packet, including its root directory | 131,072 |
| Future Root durable-proof admission directory | 196,608 |
| Exclusive prepare journal | 1,048,576 |
| Exclusive commit journal | 1,048,576 |
| Complete retirement operation | 2,424,832 |

Every allocation and phase retains Root's 1,593,835,520-byte reserve. The Mac retains the original 2,415,919,104-byte live floor. The Oracle invocation has a 1,300-second overall deadline; the owned SSH child is bounded at 1,215 seconds. The Mac body remains 1,200 seconds, with a 15-second self-only terminal grace through fsync, descriptor closure and final output. A bootstrap self alarm also bounds source setup. No foreign process is signalled.

Raw Mac stdout is capped at 512 KiB, stderr at 64 KiB. Final/terminal/ledger/PREDELETE slots are physically reserved before the remote phase. The unchanged launcher process helper records and reaps only its own unreaped leader/group; local leader reaping is not proof of arbitrary remote descendant extinction. Inspection errors, missing positive own-FD lsof evidence, unavailable privilege, identity changes or low capacity fail closed.

The observed archive allocation and nlink0 proof do not establish private APFS extents or actual reclaimed volume capacity. Root must use a later actual volume observation for that. The 15,032,385,536-byte SDK admission, original build recipe and product/test gates remain unchanged.

## Source evidence

`SOURCE_PROOF.json` records exact original source pins and byte-level reuse of the qualified metadata/hash/lsof functions, owned process helpers and full readback qualifier. Only the new finite preparation, acknowledgement, unlink and result composition are new. Static AST parsing and byte joins during materialization are source checks, not controller imports or runtime qualification. Original source and all historical failure evidence remain intact.
