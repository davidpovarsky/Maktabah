#!/usr/bin/env python3
"""Root-admitted two-phase retirement of exactly one preserved Native116 stage leaf.
Source-only until separate Root durable-proof admission and explicit PREDELETE ACK.
No API, credential, GET, original-tree traversal, archive creation or automatic retry.
"""
if not __debug__:
    raise RuntimeError("OPTIMIZED_PYTHON_REFUSED")
from pathlib import Path
import argparse,base64,datetime,hashlib,json,os,selectors,signal,stat,subprocess,sys,time

FAMILY=Path("/home/ubuntu/otzaria-wave3-native116-stage-leaf-retirement-proposal-20261128")
ADMISSION=FAMILY/"admission"
RUN=None
ROOT_FLOOR=1593835520
MAC_FLOOR=2415919104
SOURCE_CAP=131072
ADMISSION_CAP=196608
PHASE_CAP=1048576
OPERATION_CAP=SOURCE_CAP+ADMISSION_CAP+2*PHASE_CAP
OVERALL_SECONDS=1300
MAC_BYTES=43383
MAC_SHA256="af5c73920345cdf6e34e12e6abd0a29bd1cce5f8cdfbcaa188b58044701a888d"
ARCHIVE_PATH="/Users/m1/otzaria-native116-staged-archive-20261128/native116-remaining-original-evidence.tar.gz"
ARCHIVE_BYTES=1272863810
ARCHIVE_SHA="f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556"
FULL_NATIVE_SHA="e9242bcf55ad96d02f5d5ad876dc65813a40699258406b360ead957cf5cda702"
POINTER_SHA="59b453bc05306e26f76ab4b557c5831b1f26386988bc42a1edb5556dcd787983"
RESTORER_SEAL_SHA="2ac9a9125dbc680664e68a0ca53661ca569416ff8bdc003e306997e542f0d755"
RESTORER=Path("/home/ubuntu/otzaria-wave3-native116-stage-leaf-restore-execution-20261128")
REPOSITORY_ID=1474927804
REPOSITORY="davidpovarsky/Maktabah-preserved-evidence"
RELEASE_ID=461304898
ASSET_ID=803618998
SNAPSHOT_SHA="424c2e2f95b3616e39b51cbacc621678dc2899ceba857a2dd42b72b0a0597cc4"
MANIFEST_SHA="a8faa73411de67ead8f98856fe25cb3a368d5adb91f1d51f5e3103c9795299c0"
READBACK_SOURCE_SEAL="c37abe5dacd65b785c6d6fd0e0aded3d3eac3b5fff1a640691495bc3cb3776fc"
READBACK_RESULT_PATH="/home/ubuntu/otzaria-wave3-native116-readback-dependencies-20261128/readback/FINAL_RESULT.json"
FIXED_INPUTS=json.loads("{\"FULL_READBACK_RESULT.json\":{\"path\":\"/home/ubuntu/otzaria-wave3-native116-readback-dependencies-20261128/readback/FINAL_RESULT.json\",\"bytes\":65536,\"sha256\":\"e9242bcf55ad96d02f5d5ad876dc65813a40699258406b360ead957cf5cda702\"},\"FULL_READBACK_JOB.json\":{\"path\":\"/home/ubuntu/otzaria-wave3-native116-stage-leaf-restore-readback-binding-proposal-20261128/ACTUAL_READBACK_JOB.json\",\"bytes\":1103,\"sha256\":\"43ed9879a39e364bb7aa88c82b40e9cd4a62c5baaded8b2e361c5667aa07214f\"},\"SOURCE_BEFORE.json\":{\"path\":\"/home/ubuntu/otzaria-wave3-native116-readback-dependencies-20261128/readback/pre-readback-original-full-source.SOURCE_EQUAL.json\",\"bytes\":453,\"sha256\":\"6ab2854a42fc296b3d289a7f37bd2044ad236e43869a0157d59a0d075bfdaadb\"},\"SOURCE_AFTER.json\":{\"path\":\"/home/ubuntu/otzaria-wave3-native116-readback-dependencies-20261128/readback/post-readback-original-full-source.SOURCE_EQUAL.json\",\"bytes\":455,\"sha256\":\"90050ebe2cbb3037f52e789da04e3a32019d83c9ebdbd441e4284db899dd6656\"},\"ACTUAL_ROOT_ADMISSION.json\":{\"path\":\"/home/ubuntu/otzaria-wave3-native116-stage-leaf-restore-readback-binding-proposal-20261128/ACTUAL_ROOT_ADMISSION.json\",\"bytes\":1650,\"sha256\":\"3ad47febd3d652c8e8ff707b665ec5fe457e704800373fbaa06042622d6c6ac1\"}}")
RESTORER_PINS=json.loads("{\"HANDOFF.json\":{\"bytes\":6658,\"sha256\":\"3a93e1082aadd84f41a6f4db436dcd13829c397702cda5d7be4a7b67cdd7ada4\"},\"RESULT.json\":{\"bytes\":1138,\"sha256\":\"0bfce8e87445ac195617df429bdf7043b74284c87d1a3b128546e40b3296c502\"},\"SOURCE_DIFFS.json.gz\":{\"bytes\":2324,\"sha256\":\"6d229d7dd26df16b5eb56535d2dfe132dcbf49f074927f42db68d45c42850537\"},\"SOURCE_SEAL.json\":{\"bytes\":2047,\"sha256\":\"2ac9a9125dbc680664e68a0ca53661ca569416ff8bdc003e306997e542f0d755\"},\"admission/RESTORATION_POINTER.json\":{\"bytes\":3304,\"sha256\":\"59b453bc05306e26f76ab4b557c5831b1f26386988bc42a1edb5556dcd787983\"},\"mac_restore_stage_leaf.py\":{\"bytes\":23551,\"sha256\":\"e3c66535982b23080c4d10d89fb1a9f55f6c0b4ab786f47b5624d4af6bb452be\"},\"restore_stage_leaf.py\":{\"bytes\":52679,\"sha256\":\"72292b70581bf62d40b42dbf1e2829be05eada8eb4b173d23025cf5e3ebc37b0\"}}")
EXPECTED=json.loads("{\"parent\":{\"acl\":null,\"allocatedBytes\":0,\"atimeNS\":\"1795845249365515805\",\"birthtimeNS\":\"1795845188978746795\",\"bytes\":128,\"ctimeNS\":\"1795845188979074585\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215398,\"kind\":\"directory\",\"mode\":16832,\"mtimeNS\":\"1795845188979074585\",\"nlink\":4,\"pathBase64\":\"\",\"rdev\":0,\"uid\":501,\"xattrs\":[]},\"terminal\":{\"acl\":null,\"allocatedBytes\":65536,\"atimeNS\":\"1795845386429359912\",\"birthtimeNS\":\"1795845188978882252\",\"bytes\":65536,\"ctimeNS\":\"1795845386291846079\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215399,\"kind\":\"file\",\"mode\":33152,\"mtimeNS\":\"1795845386291846079\",\"nlink\":1,\"pathBase64\":\"U1RBR0VfVEVSTUlOQUwuanNvbg==\",\"rdev\":0,\"uid\":501,\"xattrs\":[]},\"archive\":{\"acl\":null,\"allocatedBytes\":1272864768,\"atimeNS\":\"1795845385698193451\",\"birthtimeNS\":\"1795845188979067835\",\"bytes\":1272863810,\"ctimeNS\":\"1795845386291328289\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215400,\"kind\":\"file\",\"mode\":33024,\"mtimeNS\":\"1795845337662706536\",\"nlink\":1,\"pathBase64\":\"bmF0aXZlMTE2LXJlbWFpbmluZy1vcmlnaW5hbC1ldmlkZW5jZS50YXIuZ3o=\",\"rdev\":0,\"uid\":501,\"xattrs\":[]}}")
SLOTS={"FINAL_RESULT.json":32768,"SSH_ALIAS.json":4096,"ssh-alias.stderr":16384,
       "mac-collector.stdout":524288,"mac-collector.stderr":65536,
       "PROCESS_LEDGER.json":16384,"TERMINAL.json":16384,"PREDELETE.json":32768}
STARTED=time.monotonic()
DEADLINE=STARTED+OVERALL_SECONDS
ORIGINAL_PARENT=os.getppid()
PROCESS_LEDGER=[]
FIXED_IDENTITIES={}
SOURCE_SEAL_SHA=None

def require(value,code):
    if not value:raise RuntimeError(code)

def canonical(value):
    return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=True)+"\n").encode("ascii")

def compact(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode("ascii")

def digest(raw):return hashlib.sha256(raw).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def stable(s):
    return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)

def error_record(error,stage):
    return {"stage":stage,"type":type(error).__name__,
            "errno":error.errno if isinstance(error,OSError) else None,
            "detail":str(error)[:240] if type(error) is RuntimeError else None}

def checked_sha(value):
    require(type(value) is str and len(value)==64
            and all(c in "0123456789abcdef" for c in value),"EXACT_SHA256")
    return value

def free():
    v=os.statvfs("/")
    return v.f_bavail*v.f_frsize

def allocation_detail():
    require(FAMILY.resolve(strict=True)==FAMILY,"OWNED_FAMILY_NO_SYMLINK")
    used={"source":0,"admission":0,"prepare":0,"commit":0}
    pending=[(FAMILY,"",0)];entries=0;rootdev=os.stat("/").st_dev
    while pending:
        path,rel,depth=pending.pop();s=path.lstat();entries+=1
        require(entries<=80 and depth<=2 and s.st_dev==rootdev
                and s.st_uid==s.st_gid==1001,"BOUNDED_OWNED_ROOTFS_OPERATION")
        part=rel.split("/",1)[0]
        family=part if part in ("admission","prepare","commit") else "source"
        used[family]+=s.st_blocks*512
        if stat.S_ISDIR(s.st_mode):
            require(rel=="" or (depth==1 and family!="source"),"ONLY_CLOSED_PHASE_DIRECTORIES")
            with os.scandir(path) as it:
                pending.extend((Path(x.path),x.name if not rel else rel+"/"+x.name,depth+1) for x in it)
        else:
            require(stat.S_ISREG(s.st_mode) and s.st_nlink==1,"REGULAR_SINGLE_LINK_OPERATION_FILES")
    require(used["source"]<=SOURCE_CAP and used["admission"]<=ADMISSION_CAP
            and used["prepare"]<=PHASE_CAP and used["commit"]<=PHASE_CAP,
            "SEPARATE_SOURCE_ADMISSION_PHASE_CAPS")
    require(sum(used.values())<=OPERATION_CAP,"SEPARATE_COMPLETE_RETIREMENT_OPERATION_CAP")
    return {"allocatedBytes":sum(used.values()),"families":used,"entries":entries,
            "operationCap":OPERATION_CAP,"restorerFourFamilyCapUntouched":2097152}

def allocation():return allocation_detail()["allocatedBytes"]

def guard(addition=0):
    require(time.monotonic()<DEADLINE,"OWNED_LAUNCHER_DEADLINE")
    require(os.getppid()==ORIGINAL_PARENT,"ORIGINAL_LAUNCH_PARENT_DETACHED")
    require(free()-addition>=ROOT_FLOOR,"UNCHANGED_ROOT_RESERVE")
    a=allocation_detail()
    require(a["allocatedBytes"]+addition<=OPERATION_CAP,"SEPARATE_OPERATION_ALLOCATION_GUARD")
    if RUN is not None:
        require(a["families"][RUN.name]+addition<=PHASE_CAP,"ONE_PHASE_ALLOCATION_GUARD")

def read_source(path,maximum):
    path=Path(path)
    require(path.resolve(strict=True)==path,"FIXED_INPUT_NO_SYMLINK")
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    try:
        before=os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_nlink==1
                and before.st_uid==1001 and before.st_size<=maximum,"SEALED_SOURCE_REGULAR_OWNER_BOUND")
        raw=bytearray()
        while True:
            block=os.read(fd,min(65536,maximum+1-len(raw)))
            if not block:break
            raw.extend(block);require(len(raw)<=maximum,"SOURCE_READ_BOUND")
        require(stable(os.fstat(fd))==stable(before)
                and stable(os.stat(path,follow_symlinks=False))==stable(before),"SOURCE_READ_IDENTITY_FENCE")
        key=str(path)
        if key in FIXED_IDENTITIES:
            require(FIXED_IDENTITIES[key]==stable(before),"FIXED_INPUT_REPLACED_SINCE_ADMISSION")
        else:FIXED_IDENTITIES[key]=stable(before)
        return bytes(raw)
    finally:os.close(fd)

def pinned_read(path,pin):
    raw=read_source(path,pin["bytes"])
    require(len(raw)==pin["bytes"] and digest(raw)==pin["sha256"],"FULL_FIXED_INPUT_BYTE_PIN")
    return raw

def verify_seal(expected):
    global SOURCE_SEAL_SHA
    require(os.getuid()==os.geteuid()==1001 and os.getgid()==1001
            and sys.flags.isolated and sys.dont_write_bytecode,"UBUNTU_PYTHON_I_B_REQUIRED")
    require(Path(__file__).absolute()==FAMILY/"retire_stage_leaf.py","EXACT_REAL_SOURCE_ENTRYPOINT")
    raw=read_source(FAMILY/"SOURCE_SEAL.json",65536)
    require(digest(raw)==checked_sha(expected),"EXPLICIT_ROOT_REVIEWED_SOURCE_SEAL")
    seal=json.loads(raw)
    require(seal["schema"]=="otzaria.native116-stage-leaf-retirement-source/1"
            and seal["status"]=="SOURCE_ONLY_UNRUN" and seal["familyPath"]==str(FAMILY)
            and seal["sourceCap"]==SOURCE_CAP and seal["admissionCap"]==ADMISSION_CAP
            and seal["phaseCap"]==PHASE_CAP and seal["operationCap"]==OPERATION_CAP
            and seal["restorerFourFamilyCapUnchanged"]==2097152,"CLOSED_RETIREMENT_SOURCE_AND_CAPS")
    names=set(seal["files"])|{"SOURCE_SEAL.json"}
    actual={x.name for x in FAMILY.iterdir() if x.name not in ("admission","prepare","commit")}
    require(actual==names,"EXACT_RETIREMENT_SOURCE_MEMBERSHIP")
    for name,pin in seal["files"].items():
        require(name not in ("",".","..") and "/" not in name and "\\" not in name,"SEALED_FLAT_SOURCE_LEAF")
        pinned_read(FAMILY/name,pin)
    require(seal["files"]["mac_retire_stage_leaf.py"]=={"bytes":MAC_BYTES,"sha256":MAC_SHA256},
            "EXACT_REVIEWED_MAC_SOURCE")
    allocation_detail();SOURCE_SEAL_SHA=expected
    return seal

def evidence(name,admission):
    require(admission is None and name in FIXED_INPUTS,"ONLY_PREEXISTING_FIXED_QUALIFICATION_INPUT")
    pin=FIXED_INPUTS[name]
    return pinned_read(Path(pin["path"]),pin)


def verify_full_qualification(admission):
    raw=evidence("FULL_READBACK_RESULT.json",admission)
    require(len(raw)==65536,"ORIGINAL_COMPLETE_RESULT_SLOT")
    outer=json.loads(raw)
    require(outer["requestedName"]=="VERIFIED_POST_TIMEOUT_READBACK","ACTUAL_READBACK_FINAL_MARKER")
    q=outer["value"]
    require(q["schema"]=="otzaria.native116-readback-1800/1"
            and q["status"]=="THREE_COMPLETE_PAYLOADS_FULLY_READ_BACK_AFTER_PRESERVED_TIMEOUT"
            and q["proposalSealSHA256"]==READBACK_SOURCE_SEAL
            and q["repository"]=={"id":REPOSITORY_ID,"full_name":REPOSITORY,"private":True}
            and q["release"]["id"]==RELEASE_ID and q["release"]["draft"] is True
            and q["allAssetIDs"]==[803254522,803254562,803257093,803618998]
            and q["completeAuthenticatedPayloadCount"]==3 and q["preservedIncompleteAssetCount"]==1
            and q["fullTarMemberVerification"] is True and q["originalSourceRetained"] is True
            and q["sourceModified"] is False and q["uploadAttempted"] is False
            and q["partialPrefixReused"] is False and q["postCalls"]==0
            and q["retirementAuthorized"] is False,"FULL_QUALIFICATION_BOUNDARY")
    expected={803254522:(7106913,SNAPSHOT_SHA),803254562:(160216,MANIFEST_SHA),
              ASSET_ID:(ARCHIVE_BYTES,ARCHIVE_SHA)}
    require(type(q["fullReadbacks"]) is list and len(q["fullReadbacks"])==3,"ALL_THREE_ACTUAL_READBACKS")
    seen=set()
    for proof in q["fullReadbacks"]:
        aid=proof["asset"]["id"];require(aid in expected and aid not in seen,"EXACT_DISTINCT_READBACK_ASSET")
        seen.add(aid);size,sha=expected[aid]
        require(proof["completeAuthenticatedReadback"]=={"bytes":size,"sha256":sha,"exit":0},
                "FULL_GET_SIZE_SHA_AND_CLEAN_EXIT")
        if aid==ASSET_ID:
            mv=proof["memberVerification"]
            require(mv["membersVerified"]==65011 and mv["uniquePayloadsVerified"]==65010
                    and mv["originalEntries"]==112092 and mv["snapshotSHA256"]==SNAPSHOT_SHA
                    and mv["everyOriginalRegularFileMapsToVerifiedPayload"] is True
                    and mv["fullTreeRestorePerformed"] is False and mv["selfContained"] is False,
                    "COMPLETE_ORIGINAL_MEMBER_VERIFICATION")
        else:require(proof["memberVerification"] is None,"SMALL_PAYLOAD_VERIFIED_AS_BYTES")
    for side,name in (("sourceBefore","SOURCE_BEFORE.json"),("sourceAfter","SOURCE_AFTER.json")):
        body=evidence(name,admission);pin=q[side]
        require(pin["bytes"]==len(body) and pin["sha256"]==digest(body),"ORIGINAL_SOURCE_RESULT_PIN")
        value=json.loads(body)
        require(value["mode"]=="reverify" and value["status"]=="SOURCE_VERIFIED_READ_ONLY"
                and value["snapshotSHA256"]==SNAPSHOT_SHA and value["fullCurrentSourceEqual"] is True
                and value["sourceModified"] is False,"ORIGINAL_FULL_SOURCE_BOUNDARY")
    jb=evidence("FULL_READBACK_JOB.json",admission);job=json.loads(jb)["job"]
    require(job["host"]=="host_299cf75f6b338ecd" and job["status"]=="succeeded" and job["exit_code"]==0
            and job["output_truncated"] is False,"ACTUAL_SUCCESSFUL_READBACK_JOB")
    require(job["id"]=="job_a02eee978d8f" and type(job["output"]) is str,
            "EXACT_COMPLETED_READBACK_JOB")
    output_raw=job["output"].encode("utf-8")
    require(len(output_raw)==571
            and digest(output_raw)=="de67fe8cf8fa16ae0fbd1d3f75d6888f7262fa35adbc5104012efdafb9fd2d00",
            "EXACT_TWO_LINE_ACTUAL_JOB_OUTPUT")
    lines=job["output"].split("\n")
    require(len(lines)==2,"EXACT_ADMISSION_AND_FINAL_LINES")
    require(json.loads(lines[0])=={
        "rootAdmission":"/home/ubuntu/otzaria-wave3-native116-readback-dependencies-root-admission-20261128/ADMISSION.json",
        "bytes":1650,"sha256":"3ad47febd3d652c8e8ff707b665ec5fe457e704800373fbaa06042622d6c6ac1",
        "runtimeOwnerUID":1001,"all14InverseAnd12DependenciesExact":True},
        "ACTUAL_READBACK_ROOT_ADMISSION_PREFIX")
    require(digest(raw)=="e9242bcf55ad96d02f5d5ad876dc65813a40699258406b360ead957cf5cda702",
            "EXACT_COMPLETED_FULL_READBACK_RESULT")
    output=json.loads(lines[1])
    require(output=={"status":q["status"],"receipt":{"path":READBACK_RESULT_PATH,
            "bytes":len(raw),"sha256":digest(raw)}},"ACTUAL_JOB_OUTPUT_JOINS_THE_FULL_RESULT")
    return q,digest(raw),job["id"]


HISTORICAL_SOURCE_SEALS=json.loads("[{\"path\":\"/home/ubuntu/otzaria-wave3-native116-stage-leaf-preflight-proposal-20261128\",\"sourceSeal\":{\"bytes\":1869,\"sha256\":\"8390416645ed999d535df0e623f3e89dad40a070bc6067a238a01c8fd0c0c746\"}},{\"path\":\"/home/ubuntu/otzaria-wave3-native116-stage-leaf-restore-proposal-20261128\",\"sourceSeal\":{\"bytes\":3877,\"sha256\":\"f35f15423c1db350b26741131aa7c340cda2d5f58f994b9e31f39a71f114e817\"}},{\"path\":\"/home/ubuntu/otzaria-wave3-native116-stage-leaf-restore-readback-binding-proposal-20261128\",\"sourceSeal\":{\"bytes\":1573,\"sha256\":\"11d28e6b1c20abee6cac8ffd273e2f15fa8ab9e83f0f68ed5456cfb37fc96ff0\"}}]")

def verify_restoration_and_durable_proof(expected):
    proof_path=ADMISSION/"ROOT_DURABLE_GIT_PROOF.json"
    require(ADMISSION.resolve(strict=True)==ADMISSION,"FIXED_ROOT_PROOF_ADMISSION")
    require({x.name for x in ADMISSION.iterdir()}=={"ROOT_DURABLE_GIT_PROOF.json"},
            "ONLY_EXACT_ROOT_DURABLE_PROOF_INPUT")
    raw=read_source(proof_path,65536)
    require(digest(raw)==checked_sha(expected),"EXPLICIT_ROOT_DURABLE_PROOF_SHA")
    d=json.loads(raw)
    q,qsha,qjob=verify_full_qualification(None)
    evidence("ACTUAL_ROOT_ADMISSION.json",None)
    for name,pin in RESTORER_PINS.items():
        pinned_read(RESTORER/name,pin)
    pointer=json.loads(pinned_read(RESTORER/"admission/RESTORATION_POINTER.json",
                                  RESTORER_PINS["admission/RESTORATION_POINTER.json"]))
    require(pointer["schema"]=="otzaria.native116-stage-opaque-restoration-pointer/1"
            and pointer["sourceSealSHA256"]==RESTORER_SEAL_SHA
            and pointer["fullReadbackResultSHA256"]==qsha
            and pointer["destination"]==ARCHIVE_PATH and pointer["originalMetadata"]==EXPECTED
            and pointer["asset"]=={"repositoryID":REPOSITORY_ID,"repository":REPOSITORY,
                "releaseID":RELEASE_ID,"id":ASSET_ID,
                "name":"native116-remaining-original-evidence-staged-20261128.tar.gz",
                "bytes":ARCHIVE_BYTES,"sha256":ARCHIVE_SHA}
            and pointer["restoresOriginalInodeCtimeBirthtimeOrAllocation"] is False
            and pointer["extractsOriginalTree"] is False,"EXACT_RUNNABLE_OPAQUE_RESTORATION_POINTER")
    for prior in HISTORICAL_SOURCE_SEALS:
        pinned_read(Path(prior["path"])/"SOURCE_SEAL.json",prior["sourceSeal"])
    require(d["schema"]=="otzaria.native116-stage-restoration-durable-root-proof/1"
            and d["status"]=="ROOT_REVIEWED_REMOTE_GIT_BYTES_EQUAL"
            and d["pointerSHA256"]==POINTER_SHA and d["sourceSealSHA256"]==RESTORER_SEAL_SHA
            and d["completeRemoteReadback"] is True
            and d["preservedRestorerFiles"]==RESTORER_PINS
            and d["preservedHistoricalSourceSeals"]==HISTORICAL_SOURCE_SEALS
            and d["allRequiredRestorerSourceFamiliesPreserved"] is True
            and d["fullReadbackResultSHA256"]==qsha
            and d["retirementSourceSealSHA256"]==SOURCE_SEAL_SHA
            and d["authorizedExactRetirementPath"]==ARCHIVE_PATH
            and d["rootOwnedStageClosed"] is True
            and d["stageHasNoRemainingRequiredConsumers"] is True,
            "ROOT_DURABLE_RESTORATION_AND_EXACT_CLOSED_STAGE_AUTHORITY")
    require(type(d["commit"]) is str and len(d["commit"])==40
            and all(c in "0123456789abcdef" for c in d["commit"]),"ACTUAL_DURABLE_GIT_COMMIT")
    # This exact CLI-pinned Root proof is an explicit approval/evidence adapter.
    # No local assertion substitutes for Root's future full remote Git readback.
    # Fresh privileged open-use inspection and the explicit PREDELETE ACK remain required.
    return {"proofSHA256":digest(raw),"commit":d["commit"],"pointerSHA256":POINTER_SHA,
            "qualificationSHA256":qsha,"qualificationJob":qjob,
            "restorerSourceSealSHA256":RESTORER_SEAL_SHA}

def stable_metadata(row):
    return {k:v for k,v in row.items() if k!="atimeNS"}

def validate_transcript(raw,phase,request):
    require(raw and raw.endswith(b"\n"),"COMPLETE_NDJSON_TRANSCRIPT")
    lines=raw.splitlines();require(0<len(lines)<=32,"FINITE_RETIREMENT_EVENTS")
    events=[]
    for i,line in enumerate(lines,1):
        e=json.loads(line)
        require(set(e)=={"sequence","event","utc","value"} and type(e["sequence"]) is int
                and e["sequence"]==i,"STRICT_RETIREMENT_EVENT_SEQUENCE")
        events.append(e)
    finals=[e for e in events if e["event"]=="FINAL_RESULT"]
    require(len(finals)==1 and finals[0] is events[-1],"EXACT_LAST_TERMINAL_EVENT")
    r=finals[0]["value"]
    require(r["schema"]=="otzaria.native116-exact-stage-leaf-retirement/1"
            and r["phase"]==phase and r["archivePath"]==ARCHIVE_PATH
            and r["pointerSHA256"]==POINTER_SHA and r["qualificationSHA256"]==FULL_NATIVE_SHA
            and r["restorerSourceSealSHA256"]==RESTORER_SEAL_SHA
            and r["retirementSourceSealSHA256"]==request["retirementSourceSealSHA256"]
            and r["rootDurableProofSHA256"]==request["rootDurableProofSHA256"]
            and r["predeleteSHA256"]==request["predeleteSHA256"],
            "ACTUAL_REMOTE_PHASE_AND_APPROVAL_JOIN")
    require(r["failure"] is None and not r["descriptorCloseErrors"]
            and r["exactlyOneFixedLeafUnlinkAtMost"] is True and r["noAutomaticRetry"] is True
            and r["noAutomaticPayloadCleanup"] is True and r["originalNativeTreeVisited"] is False
            and r["externalReferencesGitWindowsUntouched"] is True
            and r["foreignProcessesSignalled"] is False and r["privateAPFSReclaimClaimed"] is False,
            "NO_SUCCESS_FROM_PARTIAL_REMOTE_PHASE")
    require(r["fullArchiveHash"]=={"bytes":ARCHIVE_BYTES,"sha256":ARCHIVE_SHA,"regularPayloadsHashed":1}
            and r["freshCompleteNoOtherOpenUse"] is True,"FULL_FRESH_HASH_AND_NO_USE")
    captures=[e["value"] for e in events if e["event"]=="METADATA_CAPTURE"]
    checks=[e["value"] for e in events if e["event"]=="CONSUMER_CHECK"]
    require(len(checks)==2 and all(v["complete"] is True and v["inspectionError"] is None
            and v["matchingOtherOpenRecords"]==0 and v["noOtherOpenRecordsObserved"] is True for v in checks),
            "BOTH_PRIVILEGED_COMPLETE_CURRENT_NO_USE_CHECKS")
    require(len(captures)==(2 if phase=="prepare" else 3)
            and captures[0]["label"]=="BEFORE_ANY_STAGE_CONTENT_READ"
            and captures[1]["label"]=="AFTER_COMPLETE_CONTENT_HASHES","ORIGINAL_METADATA_BEFORE_CONTENT_AND_AFTER_HASH")
    for capture in captures[:2]:
        rows={x["pathBase64"]:x for x in capture["siblings"]}
        require(capture["siblingCount"]==2 and capture["allImmediateSiblingsCaptured"] is True
                and capture["historicalMembershipUnchanged"] is True
                and set(rows)=={EXPECTED["archive"]["pathBase64"],EXPECTED["terminal"]["pathBase64"]}
                and stable_metadata(capture["parent"])==stable_metadata(EXPECTED["parent"])
                and stable_metadata(rows[EXPECTED["archive"]["pathBase64"]])==stable_metadata(EXPECTED["archive"])
                and stable_metadata(rows[EXPECTED["terminal"]["pathBase64"]])==stable_metadata(EXPECTED["terminal"]),
                "EXACT_ORIGINAL_PARENT_TWO_SIBLINGS_AND_METADATA")
    terminal_hashes=[e["value"] for e in events if e["event"]=="PROTECTED_TERMINAL_HASH"]
    require(len(terminal_hashes)==1 and terminal_hashes[0]==r["terminalHash"]
            and r["terminalHash"]["bytes"]==65536 and r["terminalHash"]["inode"]==80215399
            and r["terminalHash"]["device"]==16777232,"PROTECTED_FULL_TERMINAL_HASH")
    checked_sha(r["terminalHash"]["sha256"])
    if phase=="prepare":
        p=[e["value"] for e in events if e["event"]=="PREDELETE_CAPTURE"]
        require(len(p)==1 and r["status"]=="STAGE_LEAF_PREDELETE_CAPTURED"
                and r["removed"] is False and r["unlinkAttempted"] is False
                and r["unlinkReturned"] is False and r["sourceWrites"] is False,
                "PREPARE_NEVER_UNLINKS")
        p=p[0]
        require(p["schema"]=="otzaria.native116-stage-leaf-predelete-capture/1"
                and p["archivePath"]==ARCHIVE_PATH and p["metadata"]==captures[1]
                and p["archiveHash"]==r["fullArchiveHash"] and p["terminalHash"]==r["terminalHash"]
                and p["finalNoUse"]==checks[-1] and p["removed"] is False
                and p["pointerSHA256"]==POINTER_SHA and p["qualificationSHA256"]==FULL_NATIVE_SHA
                and p["restorerSourceSealSHA256"]==RESTORER_SEAL_SHA
                and p["rootDurableProofSHA256"]==request["rootDurableProofSHA256"]
                and p["retirementSourceSealSHA256"]==request["retirementSourceSealSHA256"]
                and digest(compact(p))==r["preparedSHA256"],"EXACT_PREDELETE_EVENT_HASH_AND_FULL_FIELDS")
        return r,p
    require(not any(e["event"]=="PREDELETE_CAPTURE" for e in events)
            and r["status"]=="EXACT_STAGE_ARCHIVE_LEAF_RETIRED" and r["removed"] is True
            and r["unlinkAttempted"] is True and r["unlinkReturned"] is True
            and r["parentFsyncAfterUnlink"] is True and r["sourceWrites"] is True,
            "ONE_RETURNED_AND_DURABLE_UNLINK_REQUIRED")
    post=r["postUnlink"];fd=post["retainedOriginalFD"]
    require(post["archiveNameAbsent"] is True and post["terminalImmutableMetadataPreserved"] is True
            and post["terminalHashBeforeAndAfter"]==r["terminalHash"]
            and post["parentNamespaceChangesExplicit"] is True and post["allOtherNamesUntouched"] is True
            and fd["device"]==16777232 and fd["inode"]==80215400 and fd["nlink"]==0
            and fd["uid"]==501 and fd["gid"]==20 and fd["mode"]==33024
            and fd["bytes"]==ARCHIVE_BYTES and fd["flags"]==0 and fd["xattrs"]==[] and fd["acl"] is None
            and fd["mtimeNS"]==EXPECTED["archive"]["mtimeNS"]
            and fd["birthtimeNS"]==EXPECTED["archive"]["birthtimeNS"]
            and fd["privateAPFSReclaimClaimed"] is False,"ACTUAL_UNLINKED_ORIGINAL_FD_AND_PROTECTED_SIBLING")
    after=captures[2]
    require(after["label"]=="AFTER_EXACT_ARCHIVE_UNLINK" and after["siblingCount"]==1
            and len(after["siblings"])==1
            and stable_metadata(after["siblings"][0])==stable_metadata(EXPECTED["terminal"])
            and post["parentBefore"]==captures[1]["parent"] and post["parentAfter"]==after["parent"],
            "ACTUAL_POST_UNLINK_PARENT_AND_TERMINAL_CAPTURE")
    return r,None

def prepare_ack(expected,proof):
    directory=FAMILY/"prepare"
    require(directory.resolve(strict=True)==directory,"EXACT_PRIOR_PREPARE_DIRECTORY")
    raw=read_source(directory/"PREDELETE.json",SLOTS["PREDELETE.json"])
    require(digest(raw)==checked_sha(expected),"EXPLICIT_ROOT_PREDELETE_SHA_ACKNOWLEDGEMENT")
    p=json.loads(raw)
    require(p["schema"]=="otzaria.native116-stage-leaf-predelete/1"
            and p["status"]=="PREPARED_NOT_REMOVED" and p["removed"] is False
            and p["sourceSealSHA256"]==SOURCE_SEAL_SHA
            and p["rootDurableProofSHA256"]==proof["proofSHA256"]
            and p["durableGitCommit"]==proof["commit"] and p["pointerSHA256"]==POINTER_SHA
            and p["qualificationSHA256"]==FULL_NATIVE_SHA,"EXACT_PRIOR_PREDELETE_BINDINGS")
    final=json.loads(read_source(directory/"FINAL_RESULT.json",SLOTS["FINAL_RESULT.json"]))
    terminal=json.loads(read_source(directory/"TERMINAL.json",SLOTS["TERMINAL.json"]))
    transcript=read_source(directory/"mac-collector.stdout",SLOTS["mac-collector.stdout"])
    stderr=read_source(directory/"mac-collector.stderr",SLOTS["mac-collector.stderr"])
    pin={"path":str(directory/"PREDELETE.json"),"bytes":len(raw),"sha256":digest(raw)}
    require(final["schema"]=="otzaria.native116-stage-leaf-retirement-dispatch/1"
            and final["status"]=="STAGE_LEAF_PREPARE_COMPLETE" and final["phase"]=="prepare"
            and final["failure"] is None and final["predelete"]==pin
            and final["sourceSealSHA256"]==SOURCE_SEAL_SHA and final["durableProof"]==proof
            and terminal["status"]==final["status"] and terminal["failure"] is None,
            "PRIOR_PREPARE_MUST_HAVE_TERMINAL_SUCCESS_NOT_AN_INTERMEDIATE_RECORD")
    child=final["childTerminal"]
    require(child["returncode"]==0 and child["failure"] is None and child["cleanupFailure"] is None
            and child["ownedLeaderReaped"] is True and child["stdoutBytes"]==len(transcript)
            and child["stdoutSHA256"]==digest(transcript) and child["stderrBytes"]==0
            and child["stderrSHA256"]==digest(b"") and not stderr,"PRIOR_PREPARE_RAW_AND_CHILD_TERMINAL")
    request={"schema":"otzaria.native116-stage-leaf-retirement-request/1","phase":"prepare",
        "retirementSourceSealSHA256":SOURCE_SEAL_SHA,"rootDurableProofSHA256":proof["proofSHA256"],
        "pointerSHA256":POINTER_SHA,"qualificationSHA256":FULL_NATIVE_SHA,
        "restorerSourceSealSHA256":RESTORER_SEAL_SHA,"predeleteSHA256":None,"prepared":None}
    result,prepared=validate_transcript(transcript,"prepare",request)
    require(p["prepared"]==prepared and final["remoteResult"]==result,"WHOLE_ACKNOWLEDGED_PREPARE_TRANSCRIPT_JOIN")
    return p


def process_identity(pid):
    raw = Path('/proc/%d/stat' % pid).read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    assert len(fields) >= 20
    return {'pid': pid, 'pgid': int(fields[2]), 'session': int(fields[3]),
            'startTicks': fields[19]}

def stop_owned(process, original):
    # Never poll/reap before a signal decision. An unreaped Popen leader cannot
    # have its PID reused. Every child was started in its own session/group.
    if process.returncode is not None:
        return
    current = process_identity(process.pid)
    assert current['pgid'] == current['session'] == process.pid
    assert original is None or current == original
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        current = process_identity(process.pid)
        assert current['pgid'] == current['session'] == process.pid
        assert original is None or current == original
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=20)

class ReservedFiles:
    def __init__(self):
        self.fd = None
        self.files = {}
        self.closed = set()
        self.reserved = set()

    def create(self):
        require(not RUN.exists() and not RUN.is_symlink(), "EXCLUSIVE_ATTEMPT_MUST_BE_ABSENT")
        guard(sum(SLOTS.values()) + (len(SLOTS) + 4) * 4096)
        parent = os.open(FAMILY, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.mkdir(RUN.name, 0o700, dir_fd=parent)
            os.fsync(parent)
            self.fd = os.open(RUN.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        finally:
            os.close(parent)
        # FINAL_RESULT is allocated first. Every later failure can be recorded
        # using its already allocated bytes, without a new file after refusal.
        for name, size in SLOTS.items():
            guard(size + 4096)
            fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=self.fd)
            self.files[name] = fd
            remaining = size
            while remaining:
                raw = b"\0" * min(65536, remaining)
                n = os.write(fd, raw)
                require(n > 0, "REPORT_SLOT_SHORT_ALLOCATION")
                remaining -= n
            os.fsync(fd)
            require(os.fstat(fd).st_blocks * 512 >= size, "REPORT_SLOT_MUST_BE_ALLOCATED")
            self.reserved.add(name)
        os.fsync(self.fd)

    def write(self, name, raw, shrink=True):
        require(name in self.reserved and name not in self.closed and len(raw) <= SLOTS[name],
                "RESERVED_REPORT_BOUND")
        fd = self.files[name]
        s = os.fstat(fd)
        named = os.stat(name, dir_fd=self.fd, follow_symlinks=False)
        require(stable(named) == stable(s) and s.st_nlink == 1 and stat.S_ISREG(s.st_mode),
                "RESERVED_REPORT_FD_NAME")
        offset = 0
        while offset < len(raw):
            n = os.pwrite(fd, raw[offset:], offset)
            require(n > 0, "RESERVED_REPORT_SHORT_WRITE")
            offset += n
        if shrink:
            os.ftruncate(fd, len(raw))
            self.closed.add(name)
        os.fsync(fd)
        if shrink:
            actual = os.pread(fd, len(raw) + 1, 0)
            require(actual == raw, "RESERVED_REPORT_FULL_READBACK")
        os.fsync(self.fd)
        return {"path": str(RUN / name), "bytes": len(raw), "sha256": digest(raw)}

    def close(self):
        for fd in self.files.values():
            os.close(fd)
        if self.fd is not None:
            os.close(self.fd)

def save_process_ledger(slots):
    slots.write("PROCESS_LEDGER.json", canonical(PROCESS_LEDGER), shrink=False)

def run_owned(argv, label, input_body, stdout_cap, stderr_cap, seconds, slots, stdout_slot, stderr_slot):
    process = None
    identity_value = None
    selector = None
    out, err = bytearray(), bytearray()
    failure, cleanup_failure = None, None
    sent = 0
    code = None
    started = time.monotonic()
    guard()
    process = subprocess.Popen(argv, stdin=subprocess.PIPE if input_body is not None else subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               close_fds=True, start_new_session=True)
    # Immediate protected lifetime after Popen; no fallible setup precedes it.
    try:
        identity_value = process_identity(process.pid)
        require(identity_value["pgid"] == identity_value["session"] == process.pid, "OWNED_SSH_SESSION")
        PROCESS_LEDGER.append({"label": label, "identity": identity_value, "argv": argv,
                               "inputBytes": len(input_body or b""),
                               "inputSHA256": digest(input_body) if input_body is not None else None,
                               "startedUTC": utc()})
        save_process_ledger(slots)
        selector = selectors.DefaultSelector()
        for channel, pipe in (("stdout", process.stdout), ("stderr", process.stderr)):
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe.fileno(), selectors.EVENT_READ, channel)
        if process.stdin is not None:
            os.set_blocking(process.stdin.fileno(), False)
            selector.register(process.stdin.fileno(), selectors.EVENT_WRITE, "stdin")
        until = min(DEADLINE, started + seconds)
        while selector.get_map():
            guard()
            require(time.monotonic() < until, "OWNED_SSH_OR_ALIAS_DEADLINE")
            for key, _ in selector.select(0.25):
                if key.data == "stdin":
                    try:
                        n = os.write(key.fd, input_body[sent:sent + 65536])
                    except BlockingIOError:
                        continue
                    require(n > 0, "SSH_SOURCE_STDIN_CLOSED")
                    sent += n
                    if sent == len(input_body):
                        selector.unregister(key.fd)
                        process.stdin.close()
                    continue
                try:
                    raw = os.read(key.fd, 16384)
                except BlockingIOError:
                    continue
                if not raw:
                    selector.unregister(key.fd)
                    continue
                buffer, cap = (out, stdout_cap) if key.data == "stdout" else (err, stderr_cap)
                remaining = cap - len(buffer)
                buffer.extend(raw[:remaining])
                # Persist bounded partial output into already allocated slots.
                target = stdout_slot if key.data == "stdout" else stderr_slot
                if target is not None:
                    slots.write(target, bytes(buffer), shrink=False)
                require(len(raw) <= remaining, "OWNED_SSH_OUTPUT_BOUND")
        code = process.wait(timeout=max(0.01, min(20, until - time.monotonic())))
        require(input_body is None or sent == len(input_body), "WHOLE_MAC_SOURCE_DELIVERED")
    except BaseException as error:
        failure = error_record(error, label)
    finally:
        try:
            stop_owned(process, identity_value)
        except BaseException as error:
            cleanup_failure = error_record(error, label + "-cleanup")
        finally:
            if selector is not None:
                selector.close()
            for stream in (process.stdin, process.stdout, process.stderr):
                if stream is not None and not stream.closed:
                    stream.close()
            if stdout_slot is not None:
                slots.write(stdout_slot, bytes(out))
            if stderr_slot is not None:
                slots.write(stderr_slot, bytes(err))
            terminal = {"label": label, "pid": process.pid, "identity": identity_value,
                        "returncode": process.returncode, "stdoutBytes": len(out),
                        "stdoutSHA256": digest(out), "stderrBytes": len(err),
                        "stderrSHA256": digest(err), "seconds": time.monotonic() - started,
                        "failure": failure, "cleanupFailure": cleanup_failure,
                        "ownedLeaderReaped": process.returncode is not None,
                        "descendantExtinctionClaimed": False, "automaticRetries": 0}
            PROCESS_LEDGER.append({"terminal": terminal})
            save_process_ledger(slots)
    require(cleanup_failure is None, "OWNED_SSH_CLEANUP_REFUSED")
    return terminal, bytes(out), bytes(err)

def pinned_alias(slots):
    argv = ["/usr/bin/ssh", "-G", "-o", "StrictHostKeyChecking=yes",
            "-o", "IdentitiesOnly=yes", "-o", "UpdateHostKeys=no",
            "-o", "ControlMaster=no", "-o", "ControlPath=none", "scaleway-mac"]
    terminal, raw, err = run_owned(argv, "existing-pinned-ssh-alias", None, 65536, 16384,
                                   15, slots, None, "ssh-alias.stderr")
    require(terminal["failure"] is None and terminal["returncode"] == 0, "SSH_ALIAS_COMMAND_FAILED")
    values = {}
    for line in raw.decode("utf-8", "strict").splitlines():
        key, _, value = line.partition(" ")
        if key in ("hostname", "user", "port", "stricthostkeychecking", "identitiesonly"):
            require(key not in values, "DUPLICATE_PINNED_SSH_OPTION")
            values[key] = value
    require(values.get("hostname") == "62.210.195.226" and values.get("user") == "m1"
            and values.get("port") == "22" and values.get("stricthostkeychecking") in ("true", "yes")
            and values.get("identitiesonly") == "yes", "EXISTING_PINNED_SSH_ALIAS_MISMATCH")
    return slots.write("SSH_ALIAS.json", canonical({"allowedFields": values,
                         "rawConfigurationSHA256": digest(raw), "rawConfigurationNotPersisted": True,
                         "stderrSHA256": digest(err), "terminal": terminal}))



def main():
    global RUN
    parser=argparse.ArgumentParser()
    parser.add_argument("--source-seal-sha256",required=True)
    parser.add_argument("--durable-proof-sha256",required=True)
    parser.add_argument("--predelete-sha256")
    parser.add_argument("phase",choices=("prepare","commit"))
    args=parser.parse_args()
    require((args.phase=="commit")==bool(args.predelete_sha256),"COMMIT_REQUIRES_EXPLICIT_PREDELETE_ACK_ONLY")
    RUN=FAMILY/args.phase
    slots=ReservedFiles()
    outcome={"schema":"otzaria.native116-stage-leaf-retirement-dispatch/1",
             "status":"INCOMPLETE","phase":args.phase,"sourceSealSHA256":args.source_seal_sha256,
             "macSourceSHA256":MAC_SHA256,"archivePath":ARCHIVE_PATH,
             "removed":False if args.phase=="prepare" else None,
             "automaticRetries":0,"restorerFourFamilyCapUntouched":2097152,
             "separateRetirementOperationCap":OPERATION_CAP}
    failure=None;stage="SOURCE_AND_DURABLE_PROOF";prepared=None
    try:
        verify_seal(args.source_seal_sha256)
        require(free()>=ROOT_FLOOR+OPERATION_CAP,"ROOT_RESERVE_PLUS_SEPARATE_OPERATION_ADMISSION")
        guard()
        proof=verify_restoration_and_durable_proof(args.durable_proof_sha256)
        outcome["durableProof"]=proof
        ack=prepare_ack(args.predelete_sha256,proof) if args.phase=="commit" else None
        require(not RUN.exists() and not RUN.is_symlink(),"EXCLUSIVE_PHASE_NO_RETRY")
        stage="RESERVE_PHASE_REPORTS";slots.create()
        stage="PINNED_SSH_ALIAS";outcome["sshAlias"]=pinned_alias(slots)
        source=read_source(FAMILY/"mac_retire_stage_leaf.py",MAC_BYTES)
        require(len(source)==MAC_BYTES and digest(source)==MAC_SHA256,"FRESH_EXACT_MAC_SOURCE_BYTES")
        request={"schema":"otzaria.native116-stage-leaf-retirement-request/1","phase":args.phase,
            "retirementSourceSealSHA256":SOURCE_SEAL_SHA,"rootDurableProofSHA256":proof["proofSHA256"],
            "pointerSHA256":POINTER_SHA,"qualificationSHA256":FULL_NATIVE_SHA,
            "restorerSourceSealSHA256":RESTORER_SEAL_SHA,"predeleteSHA256":args.predelete_sha256,
            "prepared":ack["prepared"] if ack is not None else None}
        request_raw=compact(request)
        require(len(request_raw)<=16384,"FINITE_EXACT_ROOT_REQUEST")
        # Literal bytes are smaller than base64 and keep the same bounded stdin
        # envelope. Source/request hashes are verified before any Mac source runs.
        bootstrap=(b"if not __debug__: raise RuntimeError('OPTIMIZED_REFUSED')\n"
            b"import hashlib,json,os,signal,sys\n"
            b"if not sys.flags.isolated or not sys.dont_write_bytecode: raise RuntimeError('ISOLATION_REQUIRED')\n"
            b"s="+repr(source).encode("ascii")+b"\n"
            b"r="+repr(request_raw).encode("ascii")+b"\n"
            b"if hashlib.sha256(s).hexdigest()!="+repr(MAC_SHA256).encode("ascii")+
            b" or hashlib.sha256(r).hexdigest()!="+repr(digest(request_raw)).encode("ascii")+
            b": raise RuntimeError('EXACT_SOURCE_REQUEST_HASH')\n"
            b"signal.signal(signal.SIGALRM,lambda a,b: os._exit(124));signal.alarm(1200)\n"
            b"n={'__name__':'reviewed_native116_stage_leaf_retirement'}\n"
            b"exec(compile(s,'<reviewed-native116-stage-leaf-retirement>','exec'),n)\n"
            b"sys.exit(n['main'](json.loads(r)))\n")
        require(len(bootstrap)<=65536,"UNCHANGED_BOUNDED_IN_MEMORY_SOURCE_ENVELOPE")
        argv=["/usr/bin/ssh","-o","BatchMode=yes","-o","ConnectTimeout=8",
              "-o","StrictHostKeyChecking=yes","-o","IdentitiesOnly=yes",
              "-o","UpdateHostKeys=no","-o","ControlMaster=no","-o","ControlPath=none",
              "-T","scaleway-mac","/usr/bin/python3","-I","-B","-"]
        stage="EXACT_REMOTE_PHASE"
        terminal,raw,err=run_owned(argv,"exact-stage-leaf-"+args.phase,bootstrap,
            524288,65536,1215,slots,"mac-collector.stdout","mac-collector.stderr")
        outcome["childTerminal"]=terminal
        outcome["transcript"]={"path":str(RUN/"mac-collector.stdout"),"bytes":len(raw),"sha256":digest(raw)}
        # Preserve a bounded terminal report even when the remote outcome failed.
        # Its success is accepted only by the complete strict validator below.
        if raw:
            try:
                last=json.loads(raw.splitlines()[-1])
                if last.get("event")=="FINAL_RESULT":
                    outcome["observedRemoteTerminal"]=last.get("value")
                    outcome["removed"]=last.get("value",{}).get("removed")
            except (ValueError,TypeError,AttributeError):pass
        require(terminal["failure"] is None and terminal["cleanupFailure"] is None
                and terminal["returncode"]==0 and terminal["ownedLeaderReaped"] is True and not err,
                "REMOTE_PHASE_AND_OWNED_LEADER_TERMINAL_REQUIRED")
        result,prepared=validate_transcript(raw,args.phase,request)
        outcome["remoteResult"]=result;outcome["removed"]=result["removed"]
        stage="REJOIN_SEALED_SOURCE_AND_DURABLE_PROOF"
        verify_seal(args.source_seal_sha256)
        require(verify_restoration_and_durable_proof(args.durable_proof_sha256)==proof,
                "DURABLE_RESTORATION_PROOF_CHANGED_DURING_PHASE")
        if args.phase=="prepare":
            value={"schema":"otzaria.native116-stage-leaf-predelete/1",
                   "status":"PREPARED_NOT_REMOVED","removed":False,
                   "sourceSealSHA256":SOURCE_SEAL_SHA,"macSourceSHA256":MAC_SHA256,
                   "rootDurableProofSHA256":proof["proofSHA256"],"durableGitCommit":proof["commit"],
                   "pointerSHA256":POINTER_SHA,"qualificationSHA256":FULL_NATIVE_SHA,
                   "prepared":prepared,"transcript":outcome["transcript"],
                   "explicitFutureRootSHAAcknowledgementRequired":True}
            outcome["predelete"]=slots.write("PREDELETE.json",canonical(value))
            outcome["status"]="STAGE_LEAF_PREPARE_COMPLETE"
        else:
            slots.write("PREDELETE.json",canonical({"inputAcknowledgedSHA256":args.predelete_sha256,
                "path":str(FAMILY/"prepare/PREDELETE.json"),"newPredeleteProduced":False}))
            outcome["acknowledgedPredeleteSHA256"]=args.predelete_sha256
            outcome["status"]="EXACT_STAGE_LEAF_RETIREMENT_COMPLETE"
    except BaseException as error:
        failure=error_record(error,stage)
        outcome["status"]="RETIREMENT_DISPATCH_FAILED_PRESERVE_PARTIAL_STATE"
    finally:
        outcome.update(failure=failure,seconds=time.monotonic()-STARTED,finalStage=stage,
            originalNativeTreeVisited=False,externalReferencesGitWindowsUntouched=True,
            privateAPFSReclaimClaimed=False,noAutomaticPayloadCleanup=True,
            localLeaderReapingIsNotRemoteDescendantExtinction=True)
        try:
            if "PROCESS_LEDGER.json" in slots.reserved and "PROCESS_LEDGER.json" not in slots.closed:
                slots.write("PROCESS_LEDGER.json",canonical(PROCESS_LEDGER))
            if "TERMINAL.json" in slots.reserved:
                slots.write("TERMINAL.json",canonical({"utc":utc(),"failure":failure,"status":outcome["status"],
                    "rootFreeBytes":free(),"allocation":allocation_detail(),"phase":args.phase}))
            if "FINAL_RESULT.json" in slots.reserved:
                outcome["report"]=slots.write("FINAL_RESULT.json",canonical(outcome))
            else:outcome["failureBeforeReservedReport"]=True
        except BaseException as error:
            outcome["reportFailure"]=error_record(error,"RESERVED_FINAL_REPORT")
            outcome["status"]="RETIREMENT_DISPATCH_FAILED_PRESERVE_PARTIAL_STATE"
        finally:
            try:slots.close()
            except BaseException as error:
                outcome["reportCloseFailure"]=error_record(error,"OWNED_REPORT_DESCRIPTORS")
                outcome["status"]="RETIREMENT_DISPATCH_FAILED_PRESERVE_PARTIAL_STATE"
        print(json.dumps(outcome,sort_keys=True,ensure_ascii=True))
    return 0 if outcome["status"] in ("STAGE_LEAF_PREPARE_COMPLETE","EXACT_STAGE_LEAF_RETIREMENT_COMPLETE") else 2

if __name__=="__main__":
    sys.exit(main())
