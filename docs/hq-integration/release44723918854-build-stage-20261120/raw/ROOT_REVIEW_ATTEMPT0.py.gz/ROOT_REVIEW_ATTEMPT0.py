import pathlib,subprocess,json,hashlib,datetime,zipfile,gzip
root=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-occurrence-app-20261120");out=root/"build/release44723918854-build-evidence-20261120";e=out/"extracted";sha="60a57972acb28739ec738565083bf17fb7503028";app="87b783ac3f0257e8461762e0ea9dfa5248dd06e8"
def git(*a):return subprocess.check_output(["git","-c","gc.auto=0","-c","maintenance.auto=false",*a],cwd=root)
def digest(b):return hashlib.sha256(b).hexdigest()
archive=(out/"artifact.zip").read_bytes();assert len(archive)==1618660 and digest(archive)=="42978dc266c442eae2023c01b6ff944d752f052a5cf60b76588b441d9c16447a"
download=json.loads((out/"DOWNLOAD_VERIFIED.json").read_text());assert len(download["files"])==82
with zipfile.ZipFile(out/"artifact.zip") as z:
 assert z.testzip() is None
 for row in download["files"]:
  raw=z.read(row["path"]);assert len(raw)==row["bytes"] and digest(raw)==row["sha256"] and (e/row["path"]).read_bytes()==raw
r=json.loads((e/"artifacts/runtime27/release-build-result.json").read_text());h=json.loads((e/"hq-stage2/result.json").read_text())
assert r["status"]=="RELEASE_BUILD_ONLY_PASS" and r["release_stage"]=="build" and r["checkout_sha"]==sha and r["test_source_commit"]==app and r["requested_ui_case_count"]==r["ui_not_run"]==96
assert r["executed_ui_pass"]==r["executed_ui_fail"]==r["executed_ui_skip"]==0 and r["full_release_acceptance"] is False and r["distribution"] is False
assert h["status"]=="SIMULATOR_BUILD_FOR_REAL_UI_PASS" and h["application_source_sha"]==app and h["checkout_sha"]==sha and h["device"]==h["runtime"]=="NOT_RUN"
assert any("build-for-testing" in cmd and cmd[cmd.index("-configuration")+1]=="Debug" for cmd in h["commands"] if "-configuration" in cmd)
for path,oid in h["application_trees"].items():assert git("rev-parse",sha+":"+path).decode().strip()==git("rev-parse",app+":"+path).decode().strip()==oid
assert git("rev-parse",sha+":Maktabah-iOSUITests").decode().strip()==r["test_tree"]
sources=json.loads((e/"artifacts/runtime27/after-release-build-inputs/actual-source-inputs.json").read_text());assert len(sources)==996
queries=[sha+":"+p for p in sources];batch=subprocess.run(["git","cat-file","--batch-check"],cwd=root,input=("\n".join(queries)+"\n").encode(),capture_output=True,check=True).stdout.decode().splitlines();assert len(batch)==996
for (path,oid),line in zip(sources.items(),batch):
 fields=line.split();assert fields[0]==oid and fields[1]=="blob",(path,line,oid)
for kind,count in [("test_inputs_sha256",18),("helper_inputs_sha256",21)]:
 assert len(r[kind])==count
 for path,expected in r[kind].items():assert digest(git("show",sha+":"+path))==expected,(kind,path)
before=(e/"hq-stage2/hanlin-sdk-inputs.json").read_bytes();after=(e/"hq-stage2/hanlin-sdk-inputs-after.json").read_bytes();assert before==after
assert h["hanlin_gitlink"]==h["hanlin_sdk_source"]["sha"]=="e00498e33f106cc43be0476ffa2e09329c8ca300"
assert h["package_resolved_sha256"]==h["package_resolved_after_sha256"] and len(h["package_pins"])==len(h["actual_package_checkouts"])==17
assert "** BUILD SUCCEEDED **" in (e/"artifacts/runtime27/release-prototype-build.log").read_text(errors="replace")
prototype=json.loads((e/"artifacts/prototype-reference-manifest.json").read_text());assert prototype["configuration"]=="Debug" and prototype["productionTargetMembership"] is False
receipt={"verified_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"status":"SOURCE_BOUND_DEBUG_BUILD_STAGE_PASS_ONLY","run_id":44723918854,"checkout":sha,"application_source":app,"artifact_id":14626257677,"artifact_bytes":len(archive),"artifact_sha256":digest(archive),"archive_entries_verified":82,"source_git_blob_inputs_verified":996,"test_sha256_inputs_verified":18,"helper_sha256_inputs_verified":21,"sdk_before_after_byte_equal":True,"sdk_pin":h["hanlin_gitlink"],"package_lock_before_after_equal":True,"reported_package_pins":17,"configuration":"Debug","original_app_build_for_testing":"PASS","prototype_debug_build":"PASS","actual_ui_tests_verified_in_this_stage":0,"release_ui96":"NOT_RUN_IN_THIS_STAGE","prototype_oracle2":"NOT_RUN_IN_THIS_STAGE","production_release":"NOT_RUN_IN_THIS_STAGE","larger_binary_handoff_downloaded_by_root":False,"full_release_acceptance":False}
(out/"ROOT_REVIEW.json").write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps(receipt))
