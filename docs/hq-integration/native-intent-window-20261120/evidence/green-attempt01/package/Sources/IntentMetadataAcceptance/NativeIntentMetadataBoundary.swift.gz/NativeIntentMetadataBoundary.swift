import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

// Explicit OS/UI/DI boundaries. No AppIntents, UIKit, live catalog, visible UI,
// or native effect is supplied by this portable reproduction.
extension String { var localized: String { self } }
@MainActor final class OtzariaFileLogger {
    static let shared = OtzariaFileLogger()
    func log(_ value: String) {}
}
public struct NativeDestinationEntity: Equatable, Sendable {
    public let id: String
    public let title: String
    public init(id: String, title: String) { self.id = id; self.title = title }
}
@MainActor final class AppDependencyManager {
    static let shared = AppDependencyManager()
    var native: NativeIntentService?
    func add<T>(dependency: T) { if let value = dependency as? NativeIntentService { native = value } }
}
@MainActor final class FixtureReaderWindowQuery {
    let service: NativeIntentService
    init(service: NativeIntentService) { self.service = service }
    public func entities(for identifiers: [String]) async throws -> [NativeDestinationEntity] {
        try await service.readerWindows(identifiers: identifiers).filter { $0.destination.rawValue == "native.library" }
            .map { .init(id: $0.id, title: $0.title) }
    }
public func entities(matching string: String) async throws -> [NativeDestinationEntity] {
        try await service.readerWindows(matching: string).filter { $0.destination.rawValue == "native.library" }
            .map { .init(id: $0.id, title: $0.title) }
    }
public func suggestedEntities() async throws -> [NativeDestinationEntity] {
        try await service.readerWindows().filter { $0.destination.rawValue == "native.library" }
            .map { .init(id: $0.id, title: $0.title) }
    }
}
enum FixtureBoundaryError: Error { case unexpectedNativeExecution }
@MainActor final class FixturePresentation {
    var revoked = 0
    func revoke() { revoked += 1 }
}
@MainActor final class FixtureManager {}
@MainActor final class MaktabahNativeSceneSession {
    struct Presentation { let inspectorAvailable: Bool }
    let sceneID: UIStableID
    let directory: NativeSceneDirectory
    var foreground: Bool
    var mounted = true
    var isPresentationReady = true
    var lease: NativeSceneDirectory.Lease?
    let presentation = FixturePresentation()
    init(sceneID: UIStableID, directory: NativeSceneDirectory, foreground: Bool) {
        self.sceneID = sceneID; self.directory = directory; self.foreground = foreground
    }
    func windowLabel(number: Int) -> String { "Window \(number)" }
    func isRootAvailable(_ id: UIDestinationID) -> Bool {
        ["native.library", "native.history", "native.search", "native.annotations"].contains(id.rawValue)
    }
    func publicBindingPresentation() throws -> Presentation { .init(inspectorAvailable: false) }
    func mount(validateLifetime: @escaping NativeSceneDirectory.ValidateLifetime) throws {
        lease = try directory.mount(sceneID: sceneID, observe: { [self] in
            .init(isForeground: foreground, isMounted: mounted, visibleRoute: nil)
        }, validateLifetime: validateLifetime)
    }
    func nativeStateChanged() throws {
        guard let lease else { throw UIRouteError(.staleState, "scene_lifetime_changed") }
        try directory.invalidate(lease)
    }
}
@MainActor final class FixtureBackend: ActionSynchronousBackendStatePort {
    var value: ActionBackendSnapshot
    var snapshotCalls = 0
    var synchronousReads = 0
    var onSynchronousRead: (@MainActor (Int) throws -> Void)?
    var onNextSnapshot: (@MainActor () throws -> Void)?
    init(_ backend: ActionBackendID) {
        value = .init(backend: backend, generation: 1, rpcEpoch: backend == .sefariaEmbedded ? 7 : nil)
    }
    func currentBackendSnapshot() throws -> ActionBackendSnapshot {
        synchronousReads += 1
        try onSynchronousRead?(synchronousReads)
        return value
    }
    func snapshot() async throws -> ActionBackendSnapshot {
        snapshotCalls += 1
        let action = onNextSnapshot; onNextSnapshot = nil
        try action?()
        try Task.checkCancellation()
        return value
    }
    func report(for backend: ActionBackendID) async throws -> ActionBackendReport { .init(id: backend, operations: [:]) }
    func assess(action: String, arguments: ActionObject, invocation: ActionPortInvocation) async throws -> ActionCapabilityAssessment {
        .init(registered: false, supported: false, availableNow: false)
    }
}
struct FixturePorts: ActionResolverPort, ActionSearchPort {
    func resolveWork(_ query: ActionResolveWorkQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionWorkRef> { throw FixtureBoundaryError.unexpectedNativeExecution }
    func resolveReference(_ query: ActionResolveReferenceQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionTextRef> { throw FixtureBoundaryError.unexpectedNativeExecution }
    func validateDestination(_ destination: ActionReaderDestination, invocation: ActionPortInvocation) async throws -> ActionReaderDestination { throw FixtureBoundaryError.unexpectedNativeExecution }
    func search(_ query: ActionSearchQuery, invocation: ActionPortInvocation) async throws -> ActionSearchPage { throw FixtureBoundaryError.unexpectedNativeExecution }
}
@MainActor final class FixtureSink: ActionUICommandSink {
    func open(_ command: ActionOpenReaderCommand) async throws -> ActionUIAcknowledgement { throw FixtureBoundaryError.unexpectedNativeExecution }
}
@MainActor final class MaktabahNativeRoutingComposition: UIDestinationEligibilityPort {
    let backend: FixtureBackend
    let authority: NativeNavigationAuthority
    let directory: NativeSceneDirectory
    let core: ActionExecutor
    let registry: UIDestinationRegistry
    struct Registration {
        let managerID: ObjectIdentifier
        let session: MaktabahNativeSceneSession
        let lease: NativeNavigationAuthority.Lease
        let windowNumber: Int
        var publicBinding: (any UIPublicNavigationEligibilityPort)? = nil
    }
    struct MountWaiter { let token: UUID; let continuation: CheckedContinuation<UIStableID, any Error> }
    var scenes: [UIStableID: Registration] = [:]
    var contexts: [UIStableID: ActionExecutionContext] = [:]
    var mountWaiters: [ObjectIdentifier: MountWaiter] = [:]
    var managers: [FixtureManager] = []
    var intentsInstalled = false
    var foregroundPreparationCalls = 0
    var nativeEffectCalls = 0
    init(backendID: ActionBackendID = .otzaria) throws {
        backend = FixtureBackend(backendID)
        authority = try NativeNavigationAuthority()
        directory = try NativeSceneDirectory(authority: backend)
        let ports = FixturePorts()
        core = try ActionExecutor(state: backend, resolver: ports, search: ports, ui: FixtureSink(), navigationAuthority: authority)
                func id(_ value: String) -> UIDestinationID { UIDestinationID(rawValue: value)! }
        registry = try UIDestinationRegistry(descriptors: [
            .init(id: id("native.library"), title: "Library".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab], requiredCoreActions: [], allowsPublicRoute: true,
                  publicNavigationV2: .init(rules: [.init(presentation: .currentTab)])),
            .init(id: id("native.reader.toc"), title: "Table of Contents".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab], requiredCoreActions: [], allowsPublicRoute: true,
                  publicNavigationV2: .init(rules: [.init(presentation: .currentTab)])),
            .init(id: id("native.history"), title: "History".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab], requiredCoreActions: [], allowsPublicRoute: true,
                  publicNavigationV2: .init(rules: [.init(presentation: .currentTab)])),
            .init(id: id("native.search"), title: "Search".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab], anchors: [id("native.search.query")],
                  requiredCoreActions: [], allowsPublicRoute: true,
                  publicNavigationV2: .init(rules: [.init(presentation: .currentTab, components: [id("native.search.query")])])),
            .init(id: id("native.search.results"), title: "Search results".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab],
                  requiredCoreActions: ["search.openResults"]),
            .init(id: id("native.annotations"), title: "Annotations".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab], requiredCoreActions: [], allowsPublicRoute: true,
                  publicNavigationV2: .init(rules: [.init(presentation: .currentTab)])),
            .init(id: id("native.settings"), title: "Settings".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.sheet], requiredCoreActions: [],
                  publicNavigationV2: .init(rules: [.init(presentation: .sheet)])),
            .init(id: id("native.reader.inspector"), title: "Study Tools".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.inspector], requiredCoreActions: [],
                  publicNavigationV2: .init(rules: [.init(presentation: .inspector)])),
            .init(id: id("native.reader.noteDraft"), title: "Note Draft".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.sheet],
                  requiredCoreActions: ["notes.prepareDraft"]),
            .init(id: id("native.reader"), title: "Reader".localized, implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab, .newTab],
                  requiredCoreActions: ["reader.open"], requiresContent: true,
                  publicNavigationV2: .init(rules: [.init(presentation: .currentTab), .init(presentation: .newTab)]))
        ])

    }
    @discardableResult func mountFixture(_ rawID: String = "scene.A", foreground: Bool) throws -> MaktabahNativeSceneSession {
        let sceneID = UIStableID(rawValue: rawID)!, manager = FixtureManager()
        managers.append(manager)
        let session = MaktabahNativeSceneSession(sceneID: sceneID, directory: directory, foreground: foreground)
        let lease = try authority.mount(sceneID: sceneID, foreground: foreground)
        try session.mount { [weak self, weak session] context in
                guard let self, let session, session.mounted, contexts[sceneID] == context, context.foregroundSceneID == sceneID.rawValue,
                      context.subjectID == "maktabah.scene:" + sceneID.rawValue else { throw UIRouteError(.staleState, "native_scene_context_changed") }
            }
        scenes[sceneID] = .init(managerID: ObjectIdentifier(manager), session: session, lease: lease, windowNumber: managers.count)
        return session
    }
    func query() throws -> FixtureReaderWindowQuery {
        AppDependencyManager.shared.native = nil
        installIntentDependency()
        guard let service = AppDependencyManager.shared.native else { throw FixtureBoundaryError.unexpectedNativeExecution }
        return .init(service: service)
    }
    func rootID(_ session: MaktabahNativeSceneSession) -> String {
        NativeIntentService.Destination(backend: backend.value.backend, destination: .init(rawValue: "native.library")!, title: "Library", sceneID: session.sceneID).id
    }
    func holdOriginalContext(_ session: MaktabahNativeSceneSession) throws -> ActionExecutionContext {
        let value = context(sceneID: session.sceneID, origin: .appIntent, snapshot: backend.value)
        try issue(value, sceneID: session.sceneID)
        return value
    }
    func releaseOriginalContext(_ value: ActionExecutionContext, session: MaktabahNativeSceneSession) {
        finish(value, sceneID: session.sceneID)
    }
    func invalidateHanlin(sceneID: UIStableID) {}
    func awaitIntentForeground(_ destination: NativeIntentService.Destination) async throws {
        foregroundPreparationCalls += 1; throw FixtureBoundaryError.unexpectedNativeExecution
    }
    func open(destination: NativeIntentService.Destination) async throws -> UISceneAcknowledgement {
        nativeEffectCalls += 1; throw FixtureBoundaryError.unexpectedNativeExecution
    }
    func readerIntentMetadata(_ request: ActionRequest) async throws -> NativeReaderIntentService.CoreObservation {
        throw FixtureBoundaryError.unexpectedNativeExecution
    }
    func openReaderIntent(_ request: NativeReaderIntentService.OpenRequest) async throws -> UISceneAcknowledgement {
        nativeEffectCalls += 1; throw FixtureBoundaryError.unexpectedNativeExecution
    }
    func destinations() async throws -> [NativeIntentService.Destination] {
        var values: [NativeIntentService.Destination] = []
        for (id, entry) in scenes.sorted(by: { $0.key.rawValue < $1.key.rawValue }) where entry.session.foreground {
            let snapshot = try backend.currentBackendSnapshot(), context = context(sceneID: id, origin: .appIntent, snapshot: snapshot)
            try issue(context, sceneID: id)
            defer { finish(context, sceneID: id) }
            let admitted = try authority.admit(context: context, sceneID: id)
            defer { authority.release(admitted) }
            let invocation = ActionPortInvocation(requestId: UUID(), snapshot: snapshot, deadlineUptimeNanoseconds: deadline())
            let scene = try await directory.currentScene(sceneID: id, context: context, invocation: invocation)
            let descriptors = try await registry.discover(scene: scene, context: context, invocation: invocation, core: core, host: self)
            let windowLabel = entry.session.windowLabel(number: entry.windowNumber)
            values += descriptors.map { .init(backend: snapshot.backend, destination: $0.id, title: $0.title + " — " + windowLabel, sceneID: id) }
            if let binding = entry.publicBinding {
                let variants = try await registry.discoverPublicV2(scene: scene, context: context, invocation: invocation,
                                                                  core: core, host: binding)
                for variant in variants where variant.destination.rawValue == "native.search"
                    && variant.presentation == .currentTab && variant.component?.rawValue == "native.search.query" {
                    values.append(.init(backend: snapshot.backend, destination: variant.destination,
                        title: "Search field".localized + " — " + windowLabel, sceneID: id, component: variant.component))
                }
            }
        }
        return values
    }

private func intentEntities() async throws -> [NativeIntentService.Destination] {
        let snapshot = try backend.currentBackendSnapshot()
        var values = try intentRootEntities()
        // General system entities still require live discovery for controls and
        // the Inspector. Reader-window identity resolution does not use this path.
        values += try await destinations().filter { $0.component != nil || $0.destination.rawValue == "native.reader.inspector" }
        guard try backend.currentBackendSnapshot() == snapshot else {
            throw UIRouteError(.staleState, "intent_source_generation_changed")
        }
        return values
    }

func setForeground(_ value: Bool, session: MaktabahNativeSceneSession) throws {
        #if DEBUG
        OtzariaFileLogger.shared.log("[NativeSceneLifecycle] event=foreground pid=\(ProcessInfo.processInfo.processIdentifier) foreground=\(value)")
        #endif
        guard let entry = scenes[session.sceneID], entry.session === session else { throw UIRouteError(.staleState, "scene_lifetime_changed") }
        try authority.setForeground(value, lease: entry.lease); session.foreground = value
        invalidateHanlin(sceneID: session.sceneID)
        contexts.removeValue(forKey: session.sceneID)
        try session.nativeStateChanged()
        if !value { session.presentation.revoke() }
        else { mountWaiters.removeValue(forKey: entry.managerID)?.continuation.resume(returning: session.sceneID) }
    }

private func issue(_ context: ActionExecutionContext, sceneID: UIStableID) throws {
        guard contexts[sceneID] == nil else { throw UIRouteError(.unavailable, "native_scene_busy") }
        contexts[sceneID] = context
    }

private func finish(_ context: ActionExecutionContext, sceneID: UIStableID) {
        if contexts[sceneID] == context { contexts.removeValue(forKey: sceneID) }
    }

private func context(sceneID: UIStableID, origin: ActionOrigin, snapshot: ActionBackendSnapshot) -> ActionExecutionContext {
        // A local system/user navigation entry grants no content read or data
        // mutation. Scope enforcement remains in Core's canonical policy.
        .init(subjectID: "maktabah.scene:" + sceneID.rawValue, origin: origin,
              allowedBackends: [snapshot.backend], scopes: [.navigation, .discovery], foregroundSceneID: sceneID.rawValue)
    }

func currentScene(sceneID: UIStableID, context: ActionExecutionContext, invocation: ActionPortInvocation) async throws -> UISceneSnapshot {
        try await directory.currentScene(sceneID: sceneID, context: context, invocation: invocation)
    }

func assess(_ descriptor: UIDestinationDescriptor, scene: UISceneSnapshot, context: ActionExecutionContext, invocation: ActionPortInvocation) async throws -> UIRouteEligibility {
        let current = try await directory.currentScene(sceneID: scene.sceneID, context: context, invocation: invocation)
        guard current == scene, let entry = scenes[scene.sceneID] else { throw UIRouteError(.staleState, "scene_or_backend_changed") }
        let supported = descriptor.id.rawValue == "native.reader.inspector"
            ? try entry.session.publicBindingPresentation().inspectorAvailable
            : descriptor.id.rawValue == "native.settings" || entry.session.isRootAvailable(descriptor.id)
        return .init(sceneID: scene.sceneID, sceneRevision: current.revision, backendSnapshot: current.backendSnapshot,
                     supported: supported, ready: entry.session.foreground && entry.session.mounted && entry.session.isPresentationReady, allowed: true)
    }

private func deadline() -> UInt64 {
        let (value, overflow) = SystemActionClock().now().addingReportingOverflow(5_000_000_000)
        return overflow ? UInt64.max : value
    }

func installIntentDependency() {
        guard !intentsInstalled else { return }
        let service = NativeIntentService(discover: { [self] in
            do { return try await destinations() }
            catch { logIntentFailure(error, stage: "discovery"); throw error }
        }, resolveEntities: { [self] in
            do { return try await intentEntities() }
            catch { logIntentFailure(error, stage: "entities"); throw error }
        }, resolveReaderWindows: { [self] in
            do { return try intentRootEntities() }
            catch { logIntentFailure(error, stage: "reader_windows"); throw error }
        }, awaitForeground: { [self] in
            do { try await awaitIntentForeground($0) }
            catch { logIntentFailure(error, stage: "foreground"); throw error }
        }, navigate: { [self] in
            do { return try await open(destination: $0) }
            catch { logIntentFailure(error, stage: "navigation"); throw error }
        })
        AppDependencyManager.shared.add(dependency: service)
        let readerService = NativeReaderIntentService(execute: { [self] in
            do { return try await readerIntentMetadata($0) }
            catch { logIntentFailure(error, stage: "reader_metadata"); throw error }
        }, navigate: { [self] in
            do { return try await openReaderIntent($0) }
            catch { logIntentFailure(error, stage: "reader_navigation"); throw error }
        })
        AppDependencyManager.shared.add(dependency: readerService)
        intentsInstalled = true
    }

private func intentRootEntities() throws -> [NativeIntentService.Destination] {
        try Task.checkCancellation()
        let snapshot = try backend.currentBackendSnapshot()
        var values: [NativeIntentService.Destination] = []
        for (id, entry) in scenes.sorted(by: { $0.key.rawValue < $1.key.rawValue }) where entry.session.mounted {
            let windowLabel = entry.session.windowLabel(number: entry.windowNumber)
            for descriptor in registry.descriptors where descriptor.implementation == .implemented
                && descriptor.supportedBackends.contains(snapshot.backend)
                && descriptor.requiredCoreActions.isEmpty && !descriptor.requiresContent
                && !descriptor.mutatesUserData && !descriptor.allowsPrivateState {
                guard descriptor.id.rawValue == "native.settings" || entry.session.isRootAvailable(descriptor.id) else { continue }
                values.append(.init(backend: snapshot.backend, destination: descriptor.id,
                    title: descriptor.title + " — " + windowLabel, sceneID: id))
            }
        }
        try Task.checkCancellation()
        guard try backend.currentBackendSnapshot() == snapshot else {
            throw UIRouteError(.staleState, "intent_source_generation_changed")
        }
        return values
    }

private func logIntentFailure(_ error: any Error, stage: StaticString) {
        #if DEBUG
        // Only fixed internal codes cross this diagnostic boundary. Never log
        // the request, source, scene identity, token, query or error description.
        let route = error as? UIRouteError
        let knownCodes: Set<String> = [
            "native_scene_busy", "native_scene_context_changed", "scene_changed_during_observation",
            "scene_lifetime_changed", "scene_not_foreground", "scene_not_mounted",
            "backend_generation_changed", "intent_source_generation_changed",
            "intent_window_no_longer_available", "intent_window_changed_during_activation",
            "intent_entity_no_longer_available", "deadline_exceeded", "native_effect_uncertain"
        ]
        let code = route.flatMap { knownCodes.contains($0.code) ? $0.code : nil }
            ?? (error is CancellationError ? "cancelled" : "unclassified")
        let status = route?.status.rawValue ?? (error is CancellationError ? "cancelled" : "unclassified")
        OtzariaFileLogger.shared.log("[NativeIntentFailure] stage=\(stage) status=\(status) code=\(code)")
        #endif
    }
}
