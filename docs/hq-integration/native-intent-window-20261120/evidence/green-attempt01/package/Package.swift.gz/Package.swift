// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "IntentMetadataAcceptance", dependencies: [
.package(path: "C:/Users/DAVID/Code/Maktabah-intent-background-20261120/Source/Otzaria/Actions"),
.package(path: "C:/Users/DAVID/Code/Maktabah-intent-background-20261120/Source/Otzaria/UIRouting"),
.package(path: "C:/Users/DAVID/Code/Maktabah-intent-background-20261120/Source/ChavrusaText/UIRoutingHost")
], targets: [.executableTarget(name: "IntentMetadataAcceptance", dependencies: [
    .product(name: "OtzariaActionCore", package: "Actions"),
    .product(name: "OtzariaUIRouting", package: "UIRouting"),
    .product(name: "ChavrusaUIRoutingHost", package: "UIRoutingHost")
])], swiftLanguageModes: [.v6])
