import Foundation
@MainActor final class UnifiedSearchSessionController {
    enum Scope { case exact, advanced }
    var scope: Scope = .advanced
    let otzaria = OtzariaTextSearchViewModel()
    let zayitSession = ZayitSearchSessionController()
    var query = "old"
    var resultKitabFilter = "old"
    func clearFilter() {}
    // The original stopEngineWork calls otzaria.clear(); reproduce that boundary.
    func clearResults() { otzaria.clear() }
    func handleBackendChanged() {
        scope = BackendCoordinator.shared.activeBackendID == .sefariaEmbedded ? .exact : .advanced
        clearFilter()
        clearResults()
        query = ""
        resultKitabFilter = ""
    }
}
