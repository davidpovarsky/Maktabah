import Foundation
@MainActor final class ZayitSearchSessionController {
    enum State: Equatable { case notConfigured, restoring, ready, failed(String) }
    var state: State = .ready
    var configuredStamp: String? = "old"
    var configuredPaths: ZayitSearchDataPaths?
    var pendingStamp: String? = "pending-old"
    var operationGeneration = 4
    let model = ZayitSearchViewModel()
    let folderAccess = ZayitSearchFolderAccess()
    func fixtureStamp(_ database: URL?) -> String { configurationStamp(existingSeforimDB: database) }
    func fixtureRestore(_ database: URL?) async {
        state = .restoring
        await restore(existingSeforimDB: database, generation: operationGeneration,
                      stamp: configurationStamp(existingSeforimDB: database))
    }
    private func configurationStamp(existingSeforimDB: URL?) -> String {
        var urls = [existingSeforimDB, OtzariaMagicDictionaryManager.shared.validatedDatabaseURL].compactMap { $0 }
        if let paths = configuredPaths {
            let index = URL(fileURLWithPath: paths.indexDir, isDirectory: true)
            urls += [URL(fileURLWithPath: paths.seforimDb), URL(fileURLWithPath: paths.lexicalDb),
                     index.appendingPathComponent("meta.json"), index.appendingPathComponent("zayit-index-metadata.json")]
        }
        if let storage = try? ZayitSearchArtifactStorage() {
            urls += [storage.installedManifest, storage.finalIndex.appendingPathComponent("meta.json"),
                     storage.finalIndex.appendingPathComponent("zayit-index-metadata.json")]
        }
        let files = urls.map { url in
            let attributes = try? FileManager.default.attributesOfItem(atPath: url.path)
            return "\(url.path)|\(attributes?[.size] ?? 0)|\(attributes?[.modificationDate] ?? "missing")"
        }
        return ([OtzariaDataProfileRegistry.activeProfileID, String(describing: OtzariaDatabaseAccessController.shared.source),
                 String(ZayitSearchDataController.shared.revision)] + files)
            .joined(separator: "\u{1f}")
    }
    private func restore(existingSeforimDB: URL?, generation: Int, stamp: String) async {
        await model.reset()
        guard operationGeneration == generation else { return }

        do {
            if let database = existingSeforimDB {
                let package = await ZayitSearchArtifactService.shared.status(databaseURL: database)
                guard operationGeneration == generation else { return }
                switch package {
                case .ready:
                    guard let lexical = OtzariaMagicDictionaryManager.shared.validatedDatabaseURL else {
                        if OtzariaDatabaseAccessController.shared.source == .managedInternal {
                            throw ZayitSearchDistributionError.validationFailed("lexical.db אינו זמין; יש לבדוק את נתוני החיפוש.")
                        }
                        break
                    }
                    let storage = try ZayitSearchArtifactStorage()
                    let paths = try ZayitSearchDataValidator.managedPaths(
                        seforimDB: database, lexicalDB: lexical, indexDirectory: storage.finalIndex)
                    try await model.configure(paths: paths)
                    guard operationGeneration == generation else { return }
                    configuredPaths = paths
                    configuredStamp = configurationStamp(existingSeforimDB: existingSeforimDB)
                    state = .ready
                    return
                case .incompatible(let detail):
                    if OtzariaDatabaseAccessController.shared.source == .managedInternal {
                        throw ZayitSearchDistributionError.incompatible(detail)
                    }
                case .repairRequired(let detail), .failed(let detail):
                    if OtzariaDatabaseAccessController.shared.source == .managedInternal {
                        throw ZayitSearchDistributionError.validationFailed(detail)
                    }
                default: break
                }
            }
            guard let folder = try folderAccess.restoreAndActivate() else {
                state = .notConfigured
                return
            }
            try await configure(folder: folder, existingSeforimDB: existingSeforimDB)
            guard operationGeneration == generation else { return }
            configuredStamp = configurationStamp(existingSeforimDB: existingSeforimDB)
            state = .ready
        } catch {
            guard operationGeneration == generation else { return }
            await model.reset()
            guard operationGeneration == generation else { return }
            folderAccess.deactivate()
            state = .failed(error.localizedDescription)
        }
    }
    private func configure(folder: URL, existingSeforimDB: URL?) async throws {
        let paths = try ZayitSearchDataValidator.paths(
            in: folder,
            existingSeforimDB: existingSeforimDB
        )
        try await model.configure(paths: paths)
        configuredPaths = paths
    }
}
