import Foundation

func fixtureWrite<T: Encodable>(_ value: T, to url: URL) throws {
    let encoder = JSONEncoder()
    encoder.dateEncodingStrategy = .iso8601
    encoder.outputFormatting = [.sortedKeys]
    try encoder.encode(value).write(to: url, options: .atomic)
}
func fixtureObject(_ value: some Encodable) throws -> [String: Any] {
    let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
    return try JSONSerialization.jsonObject(with: encoder.encode(value)) as! [String: Any]
}
func fixtureDecode<T: Decodable>(_ type: T.Type, object: [String: Any]) throws -> T {
    let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
    return try decoder.decode(type, from: JSONSerialization.data(withJSONObject: object, options: .sortedKeys))
}
func fixtureUpdateReceipt(preserveTimestamp: Bool = false) throws {
    let url = try OtzariaDatabaseStorage().installationManifestURL
    let old = try FileManager.default.attributesOfItem(atPath: url.path)
    var object = try JSONSerialization.jsonObject(with: Data(contentsOf: url)) as! [String: Any]
    object["releaseID"] = 41
    object["releaseTag"] = "fixture-v41"
    object["assetID"] = 4101
    object["digest"] = "sha256:" + String(repeating: "5", count: 64)
    try JSONSerialization.data(withJSONObject: object, options: .sortedKeys).write(to: url)
    if preserveTimestamp, let modification = old[.modificationDate] {
        try FileManager.default.setAttributes([.modificationDate: modification], ofItemAtPath: url.path)
    }
}

@main @MainActor struct ManagedSourceControls {
    static var cases: [[String: Any]] = []
    static var root: URL!
    static let repository = OtzariaTantivySearchRepository.shared
    static let manager = OtzariaSearchIndexManager.shared

    static func require(_ condition: @autoclosure () throws -> Bool, _ message: String) throws {
        guard try condition() else { throw FixtureFailure.failed(message) }
    }
    static func rejects(_ body: () throws -> Void) -> Bool {
        do { try body(); return false } catch { return true }
    }
    static func run(_ name: String, _ body: () async throws -> Void) async {
        do {
            try await body()
            cases.append(["name": name, "passed": true])
            print("PASS \(name)")
        } catch {
            cases.append(["name": name, "passed": false, "detail": String(describing: error)])
            print("FAIL \(name): \(error)")
        }
        FixtureWorld.searchHook = nil
        FixtureWorld.navigationHook = nil
        FixtureWorld.zayitStatusHook = nil
        FixtureWorld.zayitConfigureHook = nil
    }
    static func reset(_ name: String, mini: Bool = false, oldProducer: Bool = false) throws -> String {
        repository.closeAllEngines()
        FixtureWorld.root = root.appendingPathComponent(name, isDirectory: true)
        try FileManager.default.createDirectory(at: FixtureWorld.root, withIntermediateDirectories: true)
        FixtureWorld.count = 2; FixtureWorld.opens = 0; FixtureWorld.closes = 0; FixtureWorld.searches = 0
        FixtureWorld.compatible = true; FixtureWorld.searchHook = nil; FixtureWorld.navigationHook = nil
        FixtureWorld.zayitStatusHook = nil; FixtureWorld.zayitConfigureHook = nil
        OtzariaDataProfileRegistry.activeProfileID = mini ? "miniTest10" : "production"
        OtzariaDataProfileRegistry.activeVersion = mini ? 6 : 1
        OtzariaDatabaseAccessController.shared.source = .managedInternal
        OtzariaDatabaseAccessController.shared.revision += 1
        try Data(repeating: 65, count: 128).write(to: FixtureWorld.database)
        FixtureWorld.build = .init(
            upstreamRepository: "davidpovarsky/otzaria_search_engine",
            upstreamBranch: "codex/otzaria-exact-occurrences-20261120",
            upstreamCommit: "d5d59d1269bdf87fb0a6901cf31941726a0c699b",
            engineVersion: "0.1.0", indexSchemaVersion: 4, defaultGenerationOrder: 5,
            semanticEnabled: false, semanticSidecarRevision: "e836ea6cac05e695efdb03ef227e78cd1a624149",
            syncedAt: "controlled-source-fixture", adapterVersion: "0.1.0",
            resourceHashes: OtzariaLexicalIndexReadCompatibility.requiredRuntimeResourceHashes)
        var resources = FixtureWorld.build.resourceHashes.mapValues {
            OtzariaSearchArtifactManifest.Resource(version: nil, bytes: 1, sha256: $0)
        }
        resources["Application Support/Otzaria/lexical.db"] = .init(version: "fixture", bytes: 1,
            sha256: "b42e36626802629fed178068e8cf11f0f034d6f24ae3b72ac9999b9311bf299f")
        FixtureWorld.indexManifest = .init(formatVersion: 1, profileID: mini ? "miniTest10" : nil,
            profileVersion: mini ? 6 : nil, artifactIdentity: "controlled-metadata-only-v40",
            sourceDatabase: .init(repository: "Otzaria/SeforimLibrary", releaseTag: "fixture-v40",
                releaseID: 40, assetID: 4001, assetName: "seforim-schema7.db.zst",
                sourceAssetDigest: "sha256:" + String(repeating: "4", count: 64),
                compressedBytes: 64, databaseBytes: 128, databaseSHA256: String(repeating: "a", count: 64),
                bookCount: 1, documentCount: 2),
            lexicalEngine: .init(repository: oldProducer ? "Otzaria/otzaria_search_engine" : FixtureWorld.build.upstreamRepository,
                commit: oldProducer ? "265a14ea54f959a3e266d6e8acfa3a3b98101d68" : FixtureWorld.build.upstreamCommit,
                engineVersion: "0.1.0", indexSchemaVersion: 4, defaultGenerationOrder: 5,
                tantivyVersion: "0.26.1", adapterVersion: "0.1.0",
                semanticSidecarRevision: FixtureWorld.build.semanticSidecarRevision),
            resources: resources,
            lexicalArtifact: .init(documentCount: 2, sourceCount: 1, catalogueHash: "fixture-catalogue-v40",
                extractedBytes: 2, packagedBytes: 1, fileCount: 1, segmentsBeforeOptimize: 1, segmentsAfterOptimize: 1,
                parts: [.init(assetName: "fixture.zst", packagedBytes: 1, sha256: String(repeating: "b", count: 64),
                              destinationPath: "meta.json", destinationOffset: 0, uncompressedBytes: 2, compression: "zstd")]),
            semantic: nil)
        let source = FixtureWorld.indexManifest.sourceDatabase
        var db: [String: Any] = ["repository": source.repository, "releaseID": source.releaseID,
            "releaseTag": source.releaseTag, "assetID": source.assetID, "assetName": source.assetName,
            "compressedSize": source.compressedBytes, "digest": source.sourceAssetDigest,
            "databaseFileSize": 128, "installedAt": "2026-11-27T00:00:00Z"]
        if mini { db["profileID"] = "miniTest10"; db["profileVersion"] = 6 }
        try fixtureWrite(fixtureDecode(OtzariaDatabaseInstallationManifest.self, object: db),
                         to: try OtzariaDatabaseStorage().installationManifestURL)
        try writeIndex(databasePath: FixtureWorld.database.path)
        return FixtureWorld.database.path
    }
    static func writeIndex(databasePath: String) throws {
        let index = manager.indexURL(for: databasePath)
        try FileManager.default.createDirectory(at: index, withIntermediateDirectories: true)
        try Data("{}".utf8).write(to: index.appendingPathComponent("meta.json"))
        try Data("controlled-engine-metadata".utf8).write(to: index.appendingPathComponent("otzaria_index_meta.json"))
        try fixtureWrite(FixtureWorld.indexManifest!, to: index.appendingPathComponent("otzaria_prebuilt_installation.json"))
        let identity = try OtzariaSearchArtifactPolicy.artifactProducerIdentity(manifest: FixtureWorld.indexManifest,
            database: manager.currentFingerprint(databasePath: databasePath),
            requiredResourceNames: Set(FixtureWorld.build.resourceHashes.keys))
        try manager.writeIdentity(identity, indexURL: index)
    }
    static func snapshot(_ directory: URL) throws -> [String: Data] {
        try Dictionary(uniqueKeysWithValues: FileManager.default.contentsOfDirectory(at: directory,
            includingPropertiesForKeys: nil).filter { !$0.lastPathComponent.hasPrefix(".") }
            .map { ($0.lastPathComponent, try Data(contentsOf: $0)) })
    }
    static func zayitManifest() -> ZayitSearchArtifactManifest {
        .init(manifestSchemaVersion: 1, profileID: FixtureWorld.indexManifest.profileID,
            profileVersion: FixtureWorld.indexManifest.profileVersion,
            artifactIdentity: "controlled-zayit-metadata", component: "zayitIndex", version: "fixture",
            requiredDatabase: .init(releaseTag: "fixture-v40", compressedAssetSHA256: String(repeating: "4", count: 64),
                canonicalSHA256: String(repeating: "a", count: 64), bytes: 128),
            engine: .init(indexSchemaVersion: 2, builderVersion: "fixture", builderCommit: "fixture",
                upstreamCommit: "fixture", tantivyVersion: "0.22"),
            counts: .init(books: 1, lines: 2, documents: 2, splitLines: 0),
            stableBookIdentity: .init(field: "book.filePath", fallback: "book.id"),
            sharedLexicalDatabase: .init(version: "fixture", sha256: String(repeating: "b", count: 64), bytes: 1),
            extractedBytes: 2, packagedBytes: 1, parts: [])
    }

    static func main() async throws {
        root = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)

        await run("valid_exact_managed_readiness_cache_hit_and_cold_reopen") {
            let path = try reset("exact")
            try require(try manager.validateCurrentIndex(databasePath: path) == 2, "valid readiness rejected")
            let first = try repository.search(databasePath: path, request: .init(query: "fixture"))
            let opens = FixtureWorld.opens
            let second = try repository.search(databasePath: path, request: .init(query: "fixture"))
            try require(first.results.count == 1 && second.results.count == 1 && FixtureWorld.opens == opens,
                        "valid cache hit reopened or lost results")
            repository.closeAllEngines()
            _ = try repository.search(databasePath: path, request: .init(query: "fixture"))
            try require(FixtureWorld.opens == opens + 1, "cold reopen did not open one admitted engine")
        }
        for mini in [false, true] {
            await run(mini ? "mini_qualified_original_producer_preserved" : "production_qualified_original_producer_preserved") {
                let path = try reset(mini ? "mini-original" : "production-original", mini: mini, oldProducer: true)
                try require(try manager.validateCurrentIndex(databasePath: path) == 2, "qualified producer rejected")
                _ = try repository.search(databasePath: path, request: .init(query: "fixture"))
                try require(manager.storedIdentity(indexURL: manager.indexURL(for: path))?.upstreamCommit
                    == "265a14ea54f959a3e266d6e8acfa3a3b98101d68", "consumer restamped original producer")
            }
        }
        await run("exact_build_identity_alone_cannot_admit_managed_source") {
            let path = try reset("bare-exact")
            let identity = manager.storedIdentity(indexURL: manager.indexURL(for: path))!
            try require(!OtzariaSearchArtifactPolicy.managedIdentityMatchesCanonicalData(identity,
                currentDatabase: manager.currentFingerprint(databasePath: path), build: FixtureWorld.build),
                "same commit and size admitted without trusted source manifest")
        }
        for missing in ["database", "index"] {
            await run("readiness_rejects_missing_\(missing)_manifest_same_commit") {
                let path = try reset("ready-missing-" + missing)
                let url = missing == "database" ? try OtzariaDatabaseStorage().installationManifestURL
                    : manager.indexURL(for: path).appendingPathComponent("otzaria_prebuilt_installation.json")
                try FileManager.default.removeItem(at: url)
                let before = try snapshot(manager.indexURL(for: path))
                try require(rejects { _ = try manager.validateCurrentIndex(databasePath: path) }, "readiness admitted missing manifest")
                try require(try snapshot(manager.indexURL(for: path)) == before, "invalid readiness rewrote retained index")
            }
            await run("cached_query_rejects_missing_\(missing)_manifest_before_ffi") {
                let path = try reset("cache-missing-" + missing)
                _ = try repository.search(databasePath: path, request: .init(query: "fixture"))
                let url = missing == "database" ? try OtzariaDatabaseStorage().installationManifestURL
                    : manager.indexURL(for: path).appendingPathComponent("otzaria_prebuilt_installation.json")
                try FileManager.default.removeItem(at: url)
                let calls = FixtureWorld.searches
                try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "cached stale source admitted")
                try require(FixtureWorld.searches == calls, "stale query reached native boundary")
            }
        }
        for sameSize in [true, false] {
            await run("readiness_rejects_update_\(sameSize ? "same_size" : "different_size")") {
                let path = try reset("ready-update-\(sameSize)")
                try fixtureUpdateReceipt()
                try Data(repeating: 66, count: sameSize ? 128 : 129).write(to: FixtureWorld.database)
                let before = try snapshot(manager.indexURL(for: path))
                try require(rejects { _ = try manager.validateCurrentIndex(databasePath: path) }, "new release admitted old ready index")
                try require(try snapshot(manager.indexURL(for: path)) == before, "rejected index was changed")
            }
            await run("query_rejects_update_\(sameSize ? "same_size" : "different_size")_after_engine_close") {
                let path = try reset("query-update-\(sameSize)")
                _ = try repository.search(databasePath: path, request: .init(query: "fixture"))
                repository.closeAllEngines()
                try fixtureUpdateReceipt()
                try Data(repeating: 66, count: sameSize ? 128 : 129).write(to: FixtureWorld.database)
                let calls = FixtureWorld.searches, opens = FixtureWorld.opens
                try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "cold query admitted retained old index")
                try require(FixtureWorld.searches == calls && FixtureWorld.opens == opens, "stale query opened or searched native boundary")
            }
        }
        await run("cached_query_rejects_receipt_only_same_size_same_mtime_replacement") {
            let path = try reset("receipt-only")
            _ = try repository.search(databasePath: path, request: .init(query: "fixture"))
            let originalDB = try manager.currentFingerprint(databasePath: path)
            try fixtureUpdateReceipt(preserveTimestamp: true)
            try require(try manager.currentFingerprint(databasePath: path) == originalDB, "fixture unexpectedly changed DB fingerprint")
            let calls = FixtureWorld.searches
            try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "receipt-only replacement reused old engine")
            try require(FixtureWorld.searches == calls, "receipt mismatch reached query")
        }
        await run("query_does_not_recover_missing_identity_but_explicit_readiness_can") {
            let path = try reset("recovery-separate")
            let identity = manager.identityURL(indexURL: manager.indexURL(for: path))
            try FileManager.default.removeItem(at: identity)
            try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "query recovered or bypassed absent identity")
            try require(!FileManager.default.fileExists(atPath: identity.path), "query rewrote missing identity")
            try require(try manager.validateCurrentIndex(databasePath: path) == 2, "explicit trusted recovery failed")
            _ = try repository.search(databasePath: path, request: .init(query: "fixture"))
        }
        await run("readiness_rejects_wrong_managed_document_count") {
            let path = try reset("count-mismatch")
            FixtureWorld.count = 1
            try require(rejects { _ = try manager.validateCurrentIndex(databasePath: path) }, "count mismatch admitted ready")
        }
        await run("cold_query_rejects_wrong_managed_document_count") {
            let path = try reset("query-count-mismatch")
            FixtureWorld.count = 1
            try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "query admitted wrong corpus count")
            try require(FixtureWorld.searches == 0, "wrong count reached query")
        }
        await run("query_rejects_catalogue_identity_mismatch_without_repair") {
            let path = try reset("catalogue-mismatch")
            let index = manager.indexURL(for: path)
            var object = try fixtureObject(manager.storedIdentity(indexURL: index)!)
            object["catalogueHash"] = "unrelated-catalogue"
            try fixtureWrite(fixtureDecode(OtzariaIndexBuildIdentity.self, object: object), to: manager.identityURL(indexURL: index))
            let before = try snapshot(index)
            try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "wrong catalogue admitted")
            try require(try snapshot(index) == before, "query repaired identity unexpectedly")
        }
        await run("query_rejects_manifest_change_during_native_boundary") {
            let path = try reset("during-query")
            FixtureWorld.searchHook = { try fixtureUpdateReceipt(preserveTimestamp: true) }
            try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "in-flight source change returned stale page")
        }
        await run("query_publication_rejects_change_after_read_before_main_actor") {
            _ = try reset("before-main")
            let vm = OtzariaTextSearchViewModel()
            FixtureWorld.navigationHook = { try! fixtureUpdateReceipt(preserveTimestamp: true) }
            vm.search(); await vm.currentTask?.value
            try require(vm.results.isEmpty && vm.searchRecords.isEmpty && !vm.isSearching,
                        "old page published after source receipt changed")
            try require(vm.status == .unavailable, "source change left old ready state")
        }
        await run("query_source_error_revokes_ready_status") {
            _ = try reset("source-error-status")
            try FileManager.default.removeItem(at: try OtzariaDatabaseStorage().installationManifestURL)
            let vm = OtzariaTextSearchViewModel()
            vm.search(); await vm.currentTask?.value
            try require(vm.results.isEmpty && !vm.isSearching, "source error published rows")
            guard case .repairRequired = vm.status else { throw FixtureFailure.failed("missing source left ready status") }
        }
        await run("ordinary_query_error_does_not_reclassify_valid_index_identity") {
            _ = try reset("ordinary-query-error")
            FixtureWorld.searchHook = { throw OtzariaSearchError.invalidEngineResponse("controlled query error") }
            let vm = OtzariaTextSearchViewModel()
            vm.search(); await vm.currentTask?.value
            try require(vm.status == .ready(documentCount: 2) && vm.errorMessage != nil,
                        "ordinary query error revoked an otherwise valid source")
        }
        await run("pagination_publication_rejects_change_after_read_before_main_actor") {
            _ = try reset("page-before-main")
            let vm = OtzariaTextSearchViewModel()
            vm.search(); await vm.currentTask?.value
            try require(vm.results.count == 1 && vm.hasMore, "controlled initial page did not publish")
            FixtureWorld.navigationHook = { try! fixtureUpdateReceipt(preserveTimestamp: true) }
            vm.loadNextPage(); await vm.paginationTask?.value
            try require(vm.results.isEmpty && vm.searchRecords.isEmpty && !vm.isLoadingMore,
                        "old next page published after source changed")
        }
        await run("resource_change_revokes_ready_and_pending_status_generation") {
            _ = try reset("status-invalidate")
            let controller = UnifiedSearchSessionController()
            let old = controller.otzaria.statusGeneration
            controller.handleBackendChanged()
            try require(controller.otzaria.status == .unavailable && controller.otzaria.indexStatusDetail == nil,
                        "clear rows retained old ready state")
            try require(controller.otzaria.statusGeneration > old, "pending old status can still publish")
        }
        await run("resource_change_revokes_zayit_ready_and_pending_restore_generation") {
            _ = try reset("zayit-status")
            let controller = UnifiedSearchSessionController()
            let old = controller.zayitSession.operationGeneration
            controller.handleBackendChanged()
            try require(controller.zayitSession.state == .notConfigured && controller.zayitSession.configuredStamp == nil,
                        "Zayit retained old library readiness")
            try require(controller.zayitSession.operationGeneration > old, "pending old Zayit restore can still publish")
        }
        await run("legacy_external_exact_identity_remains_supported_without_managed_manifest") {
            let path = try reset("external")
            OtzariaDatabaseAccessController.shared.source = .externalBookmark
            try writeIndex(databasePath: path)
            try FileManager.default.removeItem(at: try OtzariaDatabaseStorage().installationManifestURL)
            try FileManager.default.removeItem(at: manager.indexURL(for: path).appendingPathComponent("otzaria_prebuilt_installation.json"))
            try require(try manager.validateCurrentIndex(databasePath: path) == 2, "external original identity rejected")
            _ = try repository.search(databasePath: path, request: .init(query: "fixture"))
        }
        await run("legacy_external_changed_database_fingerprint_is_rejected") {
            let path = try reset("external-changed")
            OtzariaDatabaseAccessController.shared.source = .externalBookmark
            try writeIndex(databasePath: path)
            try Data(repeating: 66, count: 129).write(to: FixtureWorld.database)
            try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "external stale fingerprint admitted")
        }
        for mini in [false, true] {
            await run(mini ? "zayit_valid_mini_managed_preserved" : "zayit_valid_production_managed_preserved") {
                _ = try reset(mini ? "zayit-mini" : "zayit-production", mini: mini)
                try ZayitSearchArtifactService().validateCompatibility(zayitManifest(), databaseURL: FixtureWorld.database)
            }
        }
        await run("zayit_managed_missing_manifest_is_rejected") {
            _ = try reset("zayit-missing")
            try FileManager.default.removeItem(at: try OtzariaDatabaseStorage().installationManifestURL)
            try require(rejects { try ZayitSearchArtifactService().validateCompatibility(zayitManifest(), databaseURL: FixtureWorld.database) },
                        "managed Zayit fell through missing manifest")
        }
        await run("zayit_same_size_new_release_is_rejected") {
            _ = try reset("zayit-update")
            try fixtureUpdateReceipt(preserveTimestamp: true)
            try require(rejects { try ZayitSearchArtifactService().validateCompatibility(zayitManifest(), databaseURL: FixtureWorld.database) },
                        "Zayit accepted old package for new release")
        }
        await run("zayit_stamp_changes_for_receipt_bytes_with_preserved_size_mtime") {
            _ = try reset("zayit-stamp")
            let session = ZayitSearchSessionController()
            let url = try OtzariaDatabaseStorage().installationManifestURL
            // Use an exactly representable whole-second timestamp. Roundtripping
            // a fresh nanosecond mtime through Foundation Date can lose a tiny
            // fraction on APFS and would fail to construct the intended control.
            try FileManager.default.setAttributes([.modificationDate: Date(timeIntervalSince1970: 1_700_000_000)],
                                                   ofItemAtPath: url.path)
            let before = session.fixtureStamp(FixtureWorld.database)
            let old = try FileManager.default.attributesOfItem(atPath: url.path)
            try fixtureUpdateReceipt(preserveTimestamp: true)
            let new = try FileManager.default.attributesOfItem(atPath: url.path)
            try require((old[.size] as? NSNumber) == (new[.size] as? NSNumber)
                && (old[.modificationDate] as? Date) == (new[.modificationDate] as? Date), "fixture metadata unexpectedly differs")
            try require(session.fixtureStamp(FixtureWorld.database) != before, "same stat reused Zayit ready configuration")
        }
        await run("zayit_stamp_changes_when_managed_receipt_disappears") {
            _ = try reset("zayit-stamp-missing")
            let session = ZayitSearchSessionController()
            let before = session.fixtureStamp(FixtureWorld.database)
            try FileManager.default.removeItem(at: try OtzariaDatabaseStorage().installationManifestURL)
            try require(session.fixtureStamp(FixtureWorld.database) != before, "missing receipt did not revoke configuration")
        }
        await run("zayit_restore_preserves_valid_unchanged_managed_source") {
            _ = try reset("zayit-valid-restore")
            FixtureWorld.zayitManifest = zayitManifest()
            let session = ZayitSearchSessionController()
            await session.fixtureRestore(FixtureWorld.database)
            try require(session.state == .ready && session.model.configureCalls == 1,
                        "unchanged managed restore did not become ready")
        }
        await run("zayit_restore_rejects_source_change_across_status_await") {
            _ = try reset("zayit-status-race")
            FixtureWorld.zayitManifest = zayitManifest()
            FixtureWorld.zayitStatusHook = { try fixtureUpdateReceipt() }
            let session = ZayitSearchSessionController()
            await session.fixtureRestore(FixtureWorld.database)
            guard case .failed = session.state else { throw FixtureFailure.failed("old package validation published ready for new source") }
            try require(session.model.configureCalls == 0, "source change reached old package configuration")
        }
        await run("zayit_restore_rejects_source_change_across_configure_await") {
            _ = try reset("zayit-configure-race")
            FixtureWorld.zayitManifest = zayitManifest()
            FixtureWorld.zayitConfigureHook = { try fixtureUpdateReceipt() }
            let session = ZayitSearchSessionController()
            await session.fixtureRestore(FixtureWorld.database)
            guard case .failed = session.state else { throw FixtureFailure.failed("old configured engine was relabeled with new receipt") }
            try require(session.model.resetCalls >= 2, "mismatched configured engine was not reset")
        }
        await run("zayit_explicit_external_folder_contract_preserved") {
            _ = try reset("zayit-external")
            OtzariaDatabaseAccessController.shared.source = .externalBookmark
            let external = FixtureWorld.root.appendingPathComponent("external.db")
            try Data(repeating: 65, count: 128).write(to: external)
            try FileManager.default.removeItem(at: try OtzariaDatabaseStorage().installationManifestURL)
            try ZayitSearchArtifactService().validateCompatibility(zayitManifest(), databaseURL: external)
        }
        await run("managed_manifest_metadata_is_bounded_and_retained_on_rejection") {
            let path = try reset("oversized")
            let manifest = manager.indexURL(for: path).appendingPathComponent("otzaria_prebuilt_installation.json")
            try Data(repeating: 32, count: 1_048_577).write(to: manifest)
            let before = try snapshot(manager.indexURL(for: path))
            try require(rejects { _ = try repository.search(databasePath: path, request: .init(query: "fixture")) }, "oversized manifest admitted")
            try require(try snapshot(manager.indexURL(for: path)) == before, "rejection deleted or modified old files")
        }

        let passed = cases.filter { ($0["passed"] as? Bool) == true }.count
        let report: [String: Any] = ["scope": "Actual production source bodies, controlled engine/dictionary/UI boundaries; no real corpus, UI or installer acceptance",
            "passed": passed, "failed": cases.count - passed, "total": cases.count, "cases": cases]
        let data = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
        try data.write(to: root.appendingPathComponent("RESULT.json"))
        print("RESULT \(passed) PASS / \(cases.count - passed) FAIL")
    }
}
