import Foundation
@MainActor final class OtzariaTextSearchViewModel: @unchecked Sendable {
    typealias ResultRecord = OtzariaSearchResultStore<SearchResultItem>.Record
    var query = "fixture"
    var results: [SearchResultItem] = []
    var searchRecords: [ResultRecord] = []
    var enginePage: OtzariaSearchPage?
    var isSearching = false
    var isLoadingMore = false
    var hasMore = false
    var status: OtzariaSearchIndexStatus = .ready(documentCount: 2)
    var errorMessage: String?
    var indexStatusDetail: String? = "old-ready"
    let repository = OtzariaTantivySearchRepository.shared
    var currentTask: Task<Void, Never>?
    var paginationTask: Task<Void, Never>?
    var searchGeneration = 0
    var statusGeneration = 9
    var resultStore = OtzariaSearchResultStore<SearchResultItem>()
    var executedRequest: OtzariaSearchRequest?
    var executedDatabasePath: String?
    var executedBackendGeneration: UInt64?
    var executedProfileID: String?
    func makeSearchRequest(query: String, offset: Int, limit: Int) -> OtzariaSearchRequest {
        OtzariaSearchRequest(query: query, limit: limit, offset: offset)
    }
    private func store(page: OtzariaSearchPage, items: [SearchResultItem], replacing: Bool) throws {
        try resultStore.apply(page: page, items: items, replacing: replacing)
        searchRecords = resultStore.records
        results = searchRecords.map(\.item)
        enginePage = page
        hasMore = page.hasNextPage(consumed: resultStore.consumedCount)
    }
    func search() {
        searchGeneration += 1
        let generation = searchGeneration
        currentTask?.cancel()
        paginationTask?.cancel()
        resultStore.clear()
        searchRecords = []
        results = []
        enginePage = nil
        executedRequest = nil
        executedDatabasePath = nil
        executedProfileID = nil
        isSearching = false
        isLoadingMore = false
        hasMore = false

        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { clear(); return }
        guard let path = OtzariaMaktabahBridge.shared.databasePath else {
            errorMessage = OtzariaSearchError.databaseNotSelected.localizedDescription
            status = .unavailable
            return
        }

        let finalURL = OtzariaSearchIndexManager.shared.indexURL(for: path)
        guard FileManager.default.fileExists(atPath: finalURL.path) else {
            status = .notBuilt
            errorMessage = OtzariaDatabaseAccessController.shared.source == .managedInternal
                ? "האינדקס אינו מוכן. הורד והתקן חבילת חיפוש תואמת לפני החיפוש."
                : "האינדקס אינו מוכן. בנה או המשך את אינדקס אוצריא לפני החיפוש."
            return
        }

        isSearching = true
        errorMessage = nil
        hasMore = false
        let request = makeSearchRequest(query: trimmed, offset: 0, limit: 100)
        executedRequest = request
        executedDatabasePath = path
        let backendGeneration = BackendCoordinator.shared.generation
        let profile = OtzariaDataProfileRegistry.activeProfileID
        executedBackendGeneration = backendGeneration
        executedProfileID = profile

        currentTask = Task.detached(priority: .userInitiated) { [repository] in
            do {
                let page = try repository.search(databasePath: path, request: request)
                let items = repository.navigationItems(from: page)
                try await MainActor.run {
                    guard self.searchGeneration == generation else { return }
                    guard path == OtzariaMaktabahBridge.shared.databasePath,
                          profile == OtzariaDataProfileRegistry.activeProfileID,
                          backendGeneration == BackendCoordinator.shared.generation else {
                        self.clear()
                        return
                    }
                    try self.store(page: page, items: items, replacing: true)
                    #if DEBUG
                    self.nativePageObserver?(request, page, self.searchRecords, self.resultStore.consumedCount)
                    #endif
                    self.isSearching = false
                }
            } catch {
                if Task.isCancelled { return }
                await MainActor.run {
                    guard self.searchGeneration == generation else { return }
                    self.errorMessage = error.localizedDescription
                    self.enginePage = nil
                    self.results = []
                    self.searchRecords = []
                    self.resultStore.clear()
                    self.hasMore = false
                    self.isSearching = false
                }
            }
        }
    }
    func loadNextPage() {
        guard hasMore, !isLoadingMore else { return }
        guard var request = executedRequest, let path = executedDatabasePath,
              path == OtzariaMaktabahBridge.shared.databasePath,
              executedProfileID == OtzariaDataProfileRegistry.activeProfileID,
              executedBackendGeneration == BackendCoordinator.shared.generation else { return }

        errorMessage = nil
        isLoadingMore = true
        let generation = searchGeneration
        request.offset = resultStore.consumedCount
        let nextRequest = request
        let backendGeneration = executedBackendGeneration
        let profile = executedProfileID

        paginationTask = Task.detached(priority: .userInitiated) { [repository] in
            do {
                let page = try repository.search(databasePath: path, request: nextRequest)
                let items = repository.navigationItems(from: page)
                try await MainActor.run {
                    guard self.searchGeneration == generation else { return }
                    guard path == OtzariaMaktabahBridge.shared.databasePath,
                          profile == OtzariaDataProfileRegistry.activeProfileID,
                          backendGeneration == BackendCoordinator.shared.generation else {
                        self.clear()
                        return
                    }
                    try self.store(page: page, items: items, replacing: false)
                    #if DEBUG
                    self.nativePageObserver?(nextRequest, page, self.searchRecords, self.resultStore.consumedCount)
                    #endif
                    self.errorMessage = nil
                    self.isLoadingMore = false
                }
            } catch {
                if Task.isCancelled { return }
                await MainActor.run {
                    guard self.searchGeneration == generation else { return }
                    self.isLoadingMore = false
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
    func clear() {
        searchGeneration += 1
        currentTask?.cancel()
        paginationTask?.cancel()
        query = ""
        results = []
        searchRecords = []
        resultStore.clear()
        executedRequest = nil
        executedDatabasePath = nil
        executedBackendGeneration = nil
        executedProfileID = nil
        enginePage = nil
        errorMessage = nil
        hasMore = false
        isLoadingMore = false
        isSearching = false
    }
}
