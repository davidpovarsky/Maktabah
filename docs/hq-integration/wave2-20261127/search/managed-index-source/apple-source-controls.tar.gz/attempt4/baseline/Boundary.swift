import Foundation

enum FixtureFailure: Error, CustomStringConvertible {
    case failed(String)
    var description: String { switch self { case .failed(let detail): return detail } }
}
enum OtzariaSearchMode: String, Codable, Sendable {
    case advanced, exact, fuzzy
    var engineValue: String { rawValue }
}
enum OtzariaSearchOrder: String, Codable, Sendable { case catalogue }
struct SearchResultItem: Identifiable, Sendable { let id: String }

enum FixtureWorld {
    nonisolated(unsafe) static var root = URL(fileURLWithPath: "/unused")
    nonisolated(unsafe) static var build: OtzariaSearchEngineBuildInfo!
    nonisolated(unsafe) static var count: UInt64 = 2
    nonisolated(unsafe) static var opens = 0
    nonisolated(unsafe) static var closes = 0
    nonisolated(unsafe) static var searches = 0
    nonisolated(unsafe) static var compatible = true
    nonisolated(unsafe) static var searchHook: (() throws -> Void)?
    nonisolated(unsafe) static var navigationHook: (() -> Void)?
    nonisolated(unsafe) static var indexManifest: OtzariaSearchArtifactManifest!
    nonisolated(unsafe) static var zayitManifest: ZayitSearchArtifactManifest!
    nonisolated(unsafe) static var zayitStatusHook: (() throws -> Void)?
    nonisolated(unsafe) static var zayitConfigureHook: (() throws -> Void)?
    static var database: URL { root.appendingPathComponent("seforim.db") }
}
enum ITorahSharedContainer {
    static var sharedRootURL: URL { FixtureWorld.root }
    static var otzariaRootURL: URL { FixtureWorld.root.appendingPathComponent("Otzaria") }
}
enum OtzariaProfileStorage {
    enum Component { case otzariaSearch }
    static func applicationSupportRoot(base: URL, component: Component) -> URL {
        base.appendingPathComponent("Search/" + OtzariaDataProfileRegistry.activeProfileID)
    }
}
enum OtzariaDataProfileRegistry {
    static let productionID = "production"
    nonisolated(unsafe) static var activeProfileID = "production"
    nonisolated(unsafe) static var activeVersion = 1
    static var activeIdentity: (id: String, version: Int) { (activeProfileID, activeVersion) }
}
enum OtzariaDataProfileCompatibility {
    static func matchesActiveProfile(profileID: String?, profileVersion: Int?) -> Bool {
        (profileID ?? "production") == OtzariaDataProfileRegistry.activeProfileID
            && (profileVersion ?? 1) == OtzariaDataProfileRegistry.activeVersion
    }
}
final class OtzariaDatabaseAccessController: @unchecked Sendable {
    enum Source: Equatable, Sendable { case managedInternal, externalBookmark }
    struct SelectionObservation: Equatable, Sendable {
        let url: URL?; let source: Source?; let revision: UInt64
    }
    static let shared = OtzariaDatabaseAccessController()
    var source: Source? = .managedInternal
    var currentURL: URL? { FixtureWorld.database }
    var revision: UInt64 = 1
    func selectionObservation() -> SelectionObservation {
        .init(url: currentURL, source: source, revision: revision)
    }
}
struct OtzariaDatabaseStorage {
    var finalDatabaseURL: URL { FixtureWorld.database }
    var installationManifestURL: URL { FixtureWorld.root.appendingPathComponent("seforim-installation.json") }
    init() throws {}
}
enum OtzariaIndexFileLogger {
    static func log(_ text: String) {}
    static func logError(_ text: String, error: Error) {}
}
final class OtzariaMagicDictionaryManager: Sendable {
    static let shared = OtzariaMagicDictionaryManager()
    var validatedDatabaseURL: URL? { FixtureWorld.root.appendingPathComponent("lexical.db") }
}
final class OtzariaSearchEngineBridge: @unchecked Sendable {
    static func buildInfo() throws -> OtzariaSearchEngineBuildInfo { FixtureWorld.build }
    static func checkCompatibility(indexURL: URL) throws -> OtzariaIndexCompatibility {
        .init(compatible: FixtureWorld.compatible, status: "compatible", foundSchemaVersion: 4,
              requiredSchemaVersion: 4, engineVersion: "0.1.0", metadataPath: indexURL.path, reason: nil)
    }
    init(indexURL: URL) throws { FixtureWorld.opens += 1 }
    convenience init(existingIndexURL: URL) throws {
        guard FileManager.default.fileExists(atPath: existingIndexURL.path), FixtureWorld.compatible else {
            throw FixtureFailure.failed("controlled engine refuses missing/incompatible existing index")
        }
        try self.init(indexURL: existingIndexURL)
    }
    func close() { FixtureWorld.closes += 1 }
    func documentCount() throws -> UInt64 { FixtureWorld.count }
    func search(_ request: OtzariaSearchRequest) throws -> OtzariaSearchPage {
        FixtureWorld.searches += 1
        try FixtureWorld.searchHook?()
        return .init(totalCount: 2, groupCount: nil, truncated: false, results: [
            .init(title: "controlled source", reference: "fixture", text: "fixture",
                  id: UInt64(request.offset + 1), segment: UInt64(request.offset), isPdf: false,
                  filePath: "otzaria-book:1", mergedCount: 0, merged: [])
        ])
    }
}
@MainActor final class OtzariaMaktabahBridge {
    static let shared = OtzariaMaktabahBridge()
    var databasePath: String? { FixtureWorld.database.path }
}
@MainActor final class BackendCoordinator {
    enum Backend { case otzaria, sefariaEmbedded }
    static let shared = BackendCoordinator()
    var generation: UInt64 = 1
    var activeBackendID: Backend = .otzaria
}
struct ZayitSearchDataPaths { let indexDir: String; let seforimDb: String; let lexicalDb: String }
@MainActor final class ZayitSearchDataController {
    static let shared = ZayitSearchDataController()
    var revision: UInt64 = 1
}
struct ZayitSearchArtifactStorage {
    var installedManifest: URL { FixtureWorld.root.appendingPathComponent("zayit-manifest.json") }
    var finalIndex: URL { FixtureWorld.root.appendingPathComponent("ZayitIndex") }
    init() throws {}
}
@MainActor final class ZayitSearchViewModel {
    var resetCalls = 0
    var configureCalls = 0
    func reset() async { resetCalls += 1 }
    func configure(paths: ZayitSearchDataPaths) async throws {
        configureCalls += 1
        try FixtureWorld.zayitConfigureHook?()
    }
}
@MainActor final class ZayitSearchFolderAccess {
    func restoreAndActivate() throws -> URL? { nil }
    func deactivate() {}
}
enum ZayitSearchDataValidator {
    static func managedPaths(seforimDB: URL, lexicalDB: URL, indexDirectory: URL) throws -> ZayitSearchDataPaths {
        .init(indexDir: indexDirectory.path, seforimDb: seforimDB.path, lexicalDb: lexicalDB.path)
    }
    static func paths(in folder: URL, existingSeforimDB: URL?) throws -> ZayitSearchDataPaths {
        .init(indexDir: folder.path, seforimDb: (existingSeforimDB ?? folder.appendingPathComponent("seforim.db")).path,
              lexicalDb: folder.appendingPathComponent("lexical.db").path)
    }
}
