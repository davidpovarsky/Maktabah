import Foundation
final class OtzariaSearchIndexManager: @unchecked Sendable {
    static let shared = OtzariaSearchIndexManager()
    private let identityFileName = "otzaria_search_identity.json"
    private let semanticArtifactFileName = "otzaria_semantic_artifact.json"
    private init() {}
    var indexRootURL: URL {
        OtzariaProfileStorage.applicationSupportRoot(base: ITorahSharedContainer.sharedRootURL, component: .otzariaSearch)
    }
    func indexURL(for databasePath: String) -> URL {
        if OtzariaDatabaseAccessController.shared.source == .managedInternal {
            return indexRootURL.appendingPathComponent("managed-library", isDirectory: true)
        }
        return indexRootURL.appendingPathComponent(stablePathHash(databasePath), isDirectory: true)
    }
    func identityURL(indexURL: URL) -> URL { indexURL.appendingPathComponent(identityFileName) }
    func semanticArtifactURL(for databasePath: String) -> URL {
        indexRootURL.appendingPathComponent("\(stablePathHash(databasePath)).\(semanticArtifactFileName)")
    }
    func currentFingerprint(databasePath: String) throws -> OtzariaIndexFingerprint {
        let url = URL(fileURLWithPath: databasePath)
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
        return OtzariaIndexFingerprint(
            databasePath: databasePath,
            fileSize: UInt64(values.fileSize ?? 0),
            modificationTime: values.contentModificationDate?.timeIntervalSince1970 ?? 0
        )
    }
    func storedIdentity(indexURL: URL) -> OtzariaIndexBuildIdentity? {
        decode(OtzariaIndexBuildIdentity.self, at: identityURL(indexURL: indexURL))
    }
    func writeIdentity(_ identity: OtzariaIndexBuildIdentity, indexURL: URL) throws {
        let publishesActive = indexURL == self.indexURL(for: identity.database.databasePath)
        if publishesActive { OtzariaTantivySearchRepository.shared.invalidate(databasePath: identity.database.databasePath) }
        defer { if publishesActive { OtzariaTantivySearchRepository.shared.invalidate(databasePath: identity.database.databasePath) } }
        try atomicWrite(identity, to: identityURL(indexURL: indexURL))
    }
    func validateCurrentIndex(databasePath: String) throws -> UInt64 {
        if OtzariaDatabaseAccessController.shared.source == .managedInternal {
            do { _ = try recoverTrustedManagedIndex(databasePath: databasePath) }
            catch { OtzariaIndexFileLogger.logError("managed identity recovery failed", error: error) }
        }
        // Recovery may mutate metadata and invalidate cached engines. It must
        // finish before acquiring this read scope, never inside a cache lock.
        let profile = OtzariaDataProfileRegistry.activeProfileID
        return try ITorahStorageLock.withLock(name: "migration-\(profile)") {
            try ITorahStorageLock.withLock(name: "database-mutation-\(profile)") {
                try ITorahStorageLock.withLock(name: "otzaria-search-mutation-\(profile)") {
                    guard profile == OtzariaDataProfileRegistry.activeProfileID else {
                        throw OtzariaSearchArtifactError.incompatible("data profile changed during readiness")
                    }
                    let manifest = try validateCurrentIndexSource(databasePath: databasePath)
                    let finalURL = indexURL(for: databasePath)
                    let compatibility = try OtzariaSearchEngineBridge.checkCompatibility(indexURL: finalURL)
                    guard compatibility.compatible else {
                        throw OtzariaSearchError.invalidEngineResponse(compatibility.reason ?? compatibility.status)
                    }
                    let engine = try OtzariaSearchEngineBridge(indexURL: finalURL)
                    defer { engine.close() }
                    let count = try engine.documentCount()
                    if let manifest, count != manifest.lexicalArtifact.documentCount {
                        throw OtzariaSearchArtifactError.incompatible("managed index document count")
                    }
                    return count
                }
            }
        }
    }
    func trustedManagedReadManifest(
        indexURL: URL,
        databasePath: String,
        build: OtzariaSearchEngineBuildInfo
    ) -> OtzariaSearchArtifactManifest? {
        let selection = OtzariaDatabaseAccessController.shared.selectionObservation()
        let databaseURL = URL(fileURLWithPath: databasePath).standardizedFileURL
        guard selection.source == .managedInternal,
              selection.url?.standardizedFileURL == databaseURL else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let installationURL = databaseURL.deletingLastPathComponent()
            .appendingPathComponent("seforim-installation.json")
        guard let databaseData = try? readValidationMetadata(at: installationURL),
              let database = try? decoder.decode(OtzariaDatabaseInstallationManifest.self, from: databaseData),
              let fingerprint = try? currentFingerprint(databasePath: databasePath),
              let data = try? readValidationMetadata(at: indexURL.appendingPathComponent("otzaria_prebuilt_installation.json")),
              let manifest = try? JSONDecoder().decode(OtzariaSearchArtifactManifest.self, from: data),
              (try? OtzariaSearchArtifactPolicy.validate(
                  manifest, database: database, databaseBytes: Int64(fingerprint.fileSize), build: build
              )) != nil else { return nil }
        guard selection == OtzariaDatabaseAccessController.shared.selectionObservation() else { return nil }
        return manifest
    }
    func recoverTrustedManagedIndex(databasePath: String) throws -> UInt64? {
        guard OtzariaDatabaseAccessController.shared.source == .managedInternal else { return nil }
        let profileID = OtzariaDataProfileRegistry.activeProfileID
        return try ITorahStorageLock.withLock(name: "otzaria-search-mutation-\(profileID)") {
            let fileManager = FileManager.default
            try fileManager.createDirectory(at: indexRootURL, withIntermediateDirectories: true)
            let target = indexURL(for: databasePath)
            var candidates: [URL] = []
            if fileManager.fileExists(atPath: target.path) { candidates.append(target) }
            if let children = try? fileManager.contentsOfDirectory(
                at: indexRootURL,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles]
            ) {
                candidates += children.filter { candidate in
                    candidate != target
                        && !candidate.lastPathComponent.hasSuffix(".building")
                        && !candidate.lastPathComponent.hasSuffix(".installing")
                        && !candidate.lastPathComponent.hasSuffix(".previous")
                        && fileManager.fileExists(
                            atPath: candidate.appendingPathComponent("otzaria_prebuilt_installation.json").path
                        )
                }
            }

            let databaseStorage = try OtzariaDatabaseStorage()
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let databaseManifest = try decoder.decode(
                OtzariaDatabaseInstallationManifest.self,
                from: Data(contentsOf: databaseStorage.installationManifestURL)
            )
            let databaseBytes = Int64(try currentFingerprint(databasePath: databasePath).fileSize)
            let build = try OtzariaSearchEngineBridge.buildInfo()

            for candidate in candidates {
                let trustedURL = candidate.appendingPathComponent("otzaria_prebuilt_installation.json")
                guard let data = try? Data(contentsOf: trustedURL),
                      let manifest = try? JSONDecoder().decode(OtzariaSearchArtifactManifest.self, from: data),
                      (try? OtzariaSearchArtifactPolicy.validate(
                        manifest,
                        database: databaseManifest,
                        databaseBytes: databaseBytes,
                        build: build
                      )) != nil,
                      let compatibility = try? OtzariaSearchEngineBridge.checkCompatibility(indexURL: candidate),
                      compatibility.compatible else { continue }

                let engine = try OtzariaSearchEngineBridge(indexURL: candidate)
                let count: UInt64
                do { count = try engine.documentCount() } catch { engine.close(); continue }
                engine.close()
                guard count == manifest.lexicalArtifact.documentCount else { continue }

                if candidate != target {
                    guard !fileManager.fileExists(atPath: target.path) else { continue }
                    OtzariaTantivySearchRepository.shared.invalidate(databasePath: databasePath)
                    try fileManager.moveItem(at: candidate, to: target)
                    OtzariaTantivySearchRepository.shared.invalidate(databasePath: databasePath)
                }
                let repaired = try OtzariaSearchArtifactPolicy.artifactProducerIdentity(
                    manifest: manifest,
                    database: try currentFingerprint(databasePath: databasePath),
                    requiredResourceNames: Set(build.resourceHashes.keys)
                )
                if storedIdentity(indexURL: target) != repaired {
                    try writeIdentity(repaired, indexURL: target)
                    OtzariaIndexFileLogger.log(
                        "repaired trusted managed index identity artifact=\(manifest.artifactIdentity)"
                    )
                }
                return count
            }
            return nil
        }
    }
    private func atomicWrite<T: Encodable>(_ value: T, to url: URL) throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        try encoder.encode(value).write(to: url, options: .atomic)
    }
    private func decode<T: Decodable>(_ type: T.Type, at url: URL) -> T? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(type, from: data)
    }
    private func stablePathHash(_ value: String) -> String {
        var hash: UInt64 = 1469598103934665603
        for byte in value.utf8 { hash ^= UInt64(byte); hash &*= 1099511628211 }
        return String(hash, radix: 16)
    }
    func validateCurrentIndexSource(databasePath: String) throws -> OtzariaSearchArtifactManifest? {
        let finalURL = indexURL(for: databasePath)
        let currentBuild = try OtzariaSearchEngineBridge.buildInfo()
        let registeredSemantic = decode(
            OtzariaSemanticArtifactIdentity.self,
            at: semanticArtifactURL(for: databasePath)
        ).flatMap {
            currentBuild.semanticEnabled && $0.sidecarRevision == currentBuild.semanticSidecarRevision ? $0 : nil
        }
        let managed = OtzariaDatabaseAccessController.shared.source == .managedInternal
        guard FileManager.default.fileExists(atPath: finalURL.path) else {
            throw OtzariaSearchError.invalidEngineResponse("תיקיית אינדקס אוצריא אינה קיימת.")
        }
        guard let identityData = try? readValidationMetadata(at: identityURL(indexURL: finalURL)),
              let identity = try? JSONDecoder().decode(OtzariaIndexBuildIdentity.self, from: identityData) else {
            throw OtzariaSearchError.invalidEngineResponse("קובץ הזהות המשני של האינדקס חסר או אינו קריא; נתוני הספרים לא השתנו.")
        }
        let currentDatabase = try currentFingerprint(databasePath: databasePath)
        let trustedManifest = managed
            ? trustedManagedReadManifest(indexURL: finalURL, databasePath: databasePath, build: currentBuild)
            : nil
        guard (managed
                  ? OtzariaSearchArtifactPolicy.managedIdentityMatchesCanonicalData(
                      identity,
                      currentDatabase: currentDatabase,
                      build: currentBuild,
                      trustedManifest: trustedManifest
                    )
                  : identity.database == currentDatabase
                      && identity.upstreamCommit == currentBuild.upstreamCommit
                      && identity.engineVersion == currentBuild.engineVersion
                      && identity.indexSchemaVersion == currentBuild.indexSchemaVersion
                      && identity.defaultGenerationOrder == currentBuild.defaultGenerationOrder
                      && identity.adapterVersion == currentBuild.adapterVersion
                      && identity.resourceHashes == currentBuild.resourceHashes),
              (managed || identity.semanticArtifactIdentity == registeredSemantic) else {
            throw OtzariaSearchError.invalidEngineResponse("זהות האינדקס אינה תואמת למסד, למנוע או למשאבים הפעילים.")
        }
        return trustedManifest
    }
    private func readValidationMetadata(at url: URL) throws -> Data {
        let maximum = 1_048_576
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        guard attributes[.type] as? FileAttributeType == .typeRegular,
              let size = attributes[.size] as? NSNumber,
              size.uint64Value <= UInt64(maximum) else {
            throw OtzariaSearchArtifactError.incompatible("missing or oversized source metadata")
        }
        let file = try FileHandle(forReadingFrom: url)
        defer { try? file.close() }
        var data = Data()
        while data.count <= maximum {
            guard let bytes = try file.read(upToCount: maximum + 1 - data.count),
                  !bytes.isEmpty else { return data }
            data.append(bytes)
        }
        throw OtzariaSearchArtifactError.incompatible("oversized source metadata")
    }
}
