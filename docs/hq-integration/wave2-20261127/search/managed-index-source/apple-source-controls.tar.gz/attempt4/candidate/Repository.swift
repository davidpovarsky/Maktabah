import Foundation
final class OtzariaTantivySearchRepository: @unchecked Sendable {
    static let shared = OtzariaTantivySearchRepository()
    private let manager = OtzariaSearchIndexManager.shared
    private var engineCache: [String: OtzariaSearchEngineBridge] = [:]
    private var engineStamps: [String: OpenIndexStamp] = [:]
    private var publicationRevision: UInt64 = 0
    private let revisionLock = NSLock()
    private var indexingDatabasePaths: Set<String> = []
    private let lock = NSRecursiveLock()
    private init() {}
    // Controlled dictionary boundary: no dictionary-loading acceptance claimed.
    @discardableResult static func configureRequiredDictionaries(engine: OtzariaSearchEngineBridge,
        magic: URL?, translation: URL?, acronyms: URL?) throws -> [String: Bool] { [:] }
    // Controlled UI mapping boundary: allows a deterministic change after read,
    // before MainActor publication; no metadata-mapping acceptance is claimed.
    func navigationItems(from page: OtzariaSearchPage) -> [SearchResultItem] {
        FixtureWorld.navigationHook?()
        return page.results.map { SearchResultItem(id: $0.stableHitID) }
    }
    private func readPublicationRevision() -> UInt64 {
        revisionLock.lock(); defer { revisionLock.unlock() }
        return publicationRevision
    }
    private func advancePublicationRevision() {
        revisionLock.lock(); defer { revisionLock.unlock() }
        publicationRevision &+= 1
    }
    func resourceObservation(databasePath: String?) -> (revision: UInt64, fingerprint: Data?) {
        // Synchronous commit guards must not wait behind a long FFI query.
        // This lock protects the source revision only, never an engine/await.
        let before = readPublicationRevision()
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let fingerprint = databasePath.flatMap { path in
            (try? openIndexStamp(databasePath: path)).flatMap { try? encoder.encode($0) }
        }
        let after = readPublicationRevision()
        return (after, before == after ? fingerprint : nil)
    }
    private struct OpenIndexStamp: Codable, Equatable, Sendable {
        let profile: String
        let database: OtzariaIndexFingerprint
        let path: String
        let metadata: Data
        let identity: Data
        // Missing optional manifests preserve legacy/custom-index observations.
        // The occurrence caller requires both, and validates their semantics.
        let indexInstallationManifest: Data?
        let databaseInstallationManifest: Data?
    }
    private func openIndexStamp(databasePath: String) throws -> OpenIndexStamp {
        let url = manager.indexURL(for: databasePath)
        let databaseURL = URL(fileURLWithPath: databasePath)
        return try OpenIndexStamp(profile: OtzariaDataProfileRegistry.activeProfileID,
            database: manager.currentFingerprint(databasePath: databasePath), path: url.path,
            metadata: smallMetadata(at: url.appendingPathComponent("meta.json")),
            identity: smallMetadata(at: manager.identityURL(indexURL: url)),
            indexInstallationManifest: optionalSmallMetadata(
                at: url.appendingPathComponent("otzaria_prebuilt_installation.json")),
            databaseInstallationManifest: optionalSmallMetadata(
                at: databaseURL.deletingLastPathComponent().appendingPathComponent("seforim-installation.json")))
    }
    private func optionalSmallMetadata(at url: URL) throws -> Data? {
        do { return try smallMetadata(at: url) }
        catch let error as CocoaError where error.code == .fileReadNoSuchFile || error.code == .fileNoSuchFile {
            return nil
        }
    }
    private func smallMetadata(at url: URL) throws -> Data {
        let maximum = 1_048_576
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        guard let size = attributes[.size] as? NSNumber,
              size.uint64Value <= UInt64(maximum),
              attributes[.type] as? FileAttributeType == .typeRegular else {
            throw OtzariaSearchError.invalidEngineResponse("Search readiness metadata is missing or oversized")
        }
        // The size check alone does not bound a file that grows while reading.
        // Read at most maximum + 1 bytes and reject that sentinel extra byte.
        let file = try FileHandle(forReadingFrom: url)
        defer { try? file.close() }
        var data = Data()
        while data.count <= maximum {
            guard let chunk = try file.read(upToCount: maximum + 1 - data.count),
                  !chunk.isEmpty else { return data }
            data.append(chunk)
        }
        throw OtzariaSearchError.invalidEngineResponse("Search readiness metadata is oversized")
    }
    func documentCount(databasePath: String) throws -> UInt64 {
        try withSearchReadAccess(databasePath: databasePath) {
            try engine(databasePath: databasePath).documentCount()
        }
    }
    func invalidate(databasePath: String) {
        lock.lock()
        defer { lock.unlock() }
        advancePublicationRevision()
        if let engine = engineCache[databasePath] {
            engine.close()
            engineCache[databasePath] = nil
            engineStamps[databasePath] = nil
        }
        OtzariaIndexFileLogger.log("repository cache invalidated databasePath=\(databasePath)")
    }
    func closeAllEngines() {
        lock.lock()
        defer { lock.unlock() }
        advancePublicationRevision()
        for engine in engineCache.values {
            engine.close()
        }
        engineCache.removeAll()
        engineStamps.removeAll()
        OtzariaIndexFileLogger.log("repository closeAllEngines done")
    }
    func search(databasePath: String, request: OtzariaSearchRequest) throws -> OtzariaSearchPage {
        try withSearchReadAccess(databasePath: databasePath) {
            let engine = try engine(databasePath: databasePath)
            let before = engineStamps[databasePath]
            let page = try engine.search(request)
            guard let before, before == (try? openIndexStamp(databasePath: databasePath)) else {
                invalidate(databasePath: databasePath)
                throw OtzariaSearchArtifactError.incompatible("source changed during search")
            }
            return page
        }
    }
    private func engine(databasePath: String) throws -> OtzariaSearchEngineBridge {
        lock.lock()
        defer { lock.unlock() }
        if indexingDatabasePaths.contains(databasePath) {
            throw OtzariaSearchError.invalidEngineResponse("Otzaria Tantivy indexing is in progress for this database.")
        }
        let before: OpenIndexStamp
        let manifest: OtzariaSearchArtifactManifest?
        do {
            before = try openIndexStamp(databasePath: databasePath)
            manifest = try manager.validateCurrentIndexSource(databasePath: databasePath)
            guard before == (try openIndexStamp(databasePath: databasePath)) else {
                throw OtzariaSearchArtifactError.incompatible("source changed during index admission")
            }
        } catch {
            invalidate(databasePath: databasePath)
            throw OtzariaSearchArtifactError.incompatible(error.localizedDescription)
        }
        if let cached = engineCache[databasePath] {
            if engineStamps[databasePath] == before { return cached }
            invalidate(databasePath: databasePath)
        }
        let indexURL = manager.indexURL(for: databasePath)
        let engine = try OtzariaSearchEngineBridge(existingIndexURL: indexURL)
        do {
            try Self.configureRequiredDictionaries(
                engine: engine,
                magic: OtzariaMagicDictionaryManager.shared.validatedDatabaseURL,
                translation: Bundle.main.url(forResource: "dictionary", withExtension: "json"),
                acronyms: Bundle.main.url(forResource: "Acronyms", withExtension: "json")
            )
            if let manifest, try engine.documentCount() != manifest.lexicalArtifact.documentCount {
                throw OtzariaSearchArtifactError.incompatible("managed index document count")
            }
            guard before == (try openIndexStamp(databasePath: databasePath)) else {
                throw OtzariaSearchArtifactError.incompatible("source changed while opening index")
            }
        } catch {
            engine.close()
            throw error
        }
        engineCache[databasePath] = engine
        engineStamps[databasePath] = before
        return engine
    }
    private func withSearchReadAccess<T>(databasePath: String, _ body: () throws -> T) throws -> T {
        let profile = OtzariaDataProfileRegistry.activeProfileID
        return try ITorahStorageLock.withLock(name: "migration-\(profile)") {
            try ITorahStorageLock.withLock(name: "database-mutation-\(profile)") {
                try ITorahStorageLock.withLock(name: "otzaria-search-mutation-\(profile)") {
                    lock.lock()
                    defer { lock.unlock() }
                    guard profile == OtzariaDataProfileRegistry.activeProfileID else {
                        throw OtzariaSearchArtifactError.incompatible("data profile changed during search")
                    }
                    return try body()
                }
            }
        }
    }
}
