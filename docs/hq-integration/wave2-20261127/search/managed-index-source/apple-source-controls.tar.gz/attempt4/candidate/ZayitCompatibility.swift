import Foundation
struct ZayitSearchArtifactManifest: Codable, Equatable, Sendable {
    static let currentSchemaVersion = 1
    static let currentIndexSchemaVersion = 2

    let manifestSchemaVersion: Int
    var profileID: String? = nil
    var profileVersion: Int? = nil
    let artifactIdentity: String
    let component: String
    let version: String
    let requiredDatabase: RequiredDatabase
    let engine: Engine
    let counts: Counts
    let stableBookIdentity: StableBookIdentity
    let sharedLexicalDatabase: SharedLexicalDatabase
    let extractedBytes: Int64
    let packagedBytes: Int64
    let parts: [Part]

    var effectiveProfileID: String { profileID ?? OtzariaDataProfileRegistry.productionID }
    var effectiveProfileVersion: Int { profileVersion ?? 1 }

    struct RequiredDatabase: Codable, Equatable, Sendable {
        let releaseTag: String
        let compressedAssetSHA256: String
        let canonicalSHA256: String
        let bytes: Int64
    }

    struct Engine: Codable, Equatable, Sendable {
        let indexSchemaVersion: Int
        let builderVersion: String
        let builderCommit: String
        let upstreamCommit: String
        let tantivyVersion: String
    }

    struct Counts: Codable, Equatable, Sendable {
        let books: UInt64
        let lines: UInt64
        let documents: UInt64
        let splitLines: UInt64
    }

    struct StableBookIdentity: Codable, Equatable, Sendable {
        let field: String
        let fallback: String
    }

    struct SharedLexicalDatabase: Codable, Equatable, Sendable {
        let version: String
        let sha256: String
        let bytes: Int64
    }

    struct Part: Codable, Equatable, Sendable {
        let assetName: String
        let packagedBytes: Int64
        let sha256: String
        let destinationPath: String
        let destinationOffset: Int64
        let uncompressedBytes: Int64
        let compression: String
    }
}
enum ZayitSearchPackageState: Equatable, Sendable {
    case notInstalled
    case discovering
    case available(downloadBytes: Int64, installedBytes: Int64)
    case downloading(completed: Int64, total: Int64)
    case installing(completed: Int64, total: Int64)
    case ready(ZayitSearchArtifactManifest)
    case updateAvailable(installed: String, available: String)
    case repairRequired(String)
    case incompatible(String)
    case failed(String)

    var isReady: Bool {
        if case .ready = self { return true }
        return false
    }
}
enum ZayitSearchDistributionError: LocalizedError, Sendable {
    case unavailable
    case malformedManifest(String)
    case incompatible(String)
    case missingPart(String)
    case unsafePath(String)
    case insufficientStorage(required: Int64, available: Int64)
    case invalidResponse(Int)
    case sizeMismatch(String)
    case digestMismatch(String)
    case extractionFailed(String)
    case validationFailed(String)
    case cancelled
    case operationInProgress

    var errorDescription: String? {
        switch self {
        case .unavailable: "אין עדיין חבילה תואמת לגרסת מסד זו"
        case .malformedManifest(let detail): "The Zayit manifest is invalid: \(detail)"
        case .incompatible(let detail): "The Zayit index is incompatible: \(detail)"
        case .missingPart(let name): "The Zayit package is missing \(name)."
        case .unsafePath(let path): "The Zayit package contains an unsafe path: \(path)"
        case .insufficientStorage(let required, let available):
            "Zayit installation requires \(Self.bytes(required)); \(Self.bytes(available)) is available."
        case .invalidResponse(let status): "The Zayit download failed (HTTP \(status))."
        case .sizeMismatch(let name): "The downloaded Zayit part has the wrong size: \(name)."
        case .digestMismatch(let name): "The downloaded Zayit part failed SHA-256 validation: \(name)."
        case .extractionFailed(let detail): "The Zayit index could not be extracted: \(detail)"
        case .validationFailed(let detail): "The Zayit index failed validation: \(detail)"
        case .cancelled: "The Zayit download was cancelled and can be resumed later."
        case .operationInProgress: "A Zayit installation is already in progress. Cancel it before replacing or removing the index."
        }
    }

    private static func bytes(_ value: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: value, countStyle: .file)
    }
}
struct ZayitSearchArtifactService: Sendable {
    static let shared = ZayitSearchArtifactService()
    func status(databaseURL: URL) async -> ZayitSearchPackageState {
        do {
            try validateCompatibility(FixtureWorld.zayitManifest, databaseURL: databaseURL)
            try FixtureWorld.zayitStatusHook?()
            return .ready(FixtureWorld.zayitManifest)
        } catch { return .incompatible(error.localizedDescription) }
    }
    func validateCompatibility(_ manifest: ZayitSearchArtifactManifest, databaseURL: URL) throws {
        guard manifest.component == "zayitIndex",
              manifest.manifestSchemaVersion == ZayitSearchArtifactManifest.currentSchemaVersion,
              manifest.engine.indexSchemaVersion == ZayitSearchArtifactManifest.currentIndexSchemaVersion else {
            throw ZayitSearchDistributionError.incompatible("unsupported manifest or index schema")
        }
        guard OtzariaDataProfileCompatibility.matchesActiveProfile(
            profileID: manifest.profileID, profileVersion: manifest.profileVersion
        ) else {
            throw ZayitSearchDistributionError.incompatible("data profile identity mismatch")
        }
        let bytes = ((try? FileManager.default.attributesOfItem(atPath: databaseURL.path)[.size]) as? NSNumber)?.int64Value ?? 0
        guard bytes == manifest.requiredDatabase.bytes else {
            throw ZayitSearchDistributionError.incompatible("database size/identity mismatch")
        }
        let selection = OtzariaDatabaseAccessController.shared.selectionObservation()
        let installationURL: URL
        if selection.source == .managedInternal {
            guard selection.url?.standardizedFileURL == databaseURL.standardizedFileURL else {
                throw ZayitSearchDistributionError.incompatible("managed database selection changed")
            }
            installationURL = databaseURL.deletingLastPathComponent().appendingPathComponent("seforim-installation.json")
        } else {
            // Preserve the original external-folder contract. A canonical
            // managed installation, however, must never fall through on a
            // missing manifest merely because its byte count happens to match.
            guard let storage = try? OtzariaDatabaseStorage(),
                  databaseURL.standardizedFileURL == storage.finalDatabaseURL.standardizedFileURL,
                  FileManager.default.fileExists(atPath: storage.installationManifestURL.path) else { return }
            installationURL = storage.installationManifestURL
        }
        let maximum = 1_048_576
        let attributes = try FileManager.default.attributesOfItem(atPath: installationURL.path)
        guard attributes[.type] as? FileAttributeType == .typeRegular,
              let size = attributes[.size] as? NSNumber, size.uint64Value <= UInt64(maximum) else {
            throw ZayitSearchDistributionError.incompatible("missing or oversized database installation manifest")
        }
        let file = try FileHandle(forReadingFrom: installationURL)
        defer { try? file.close() }
        guard let data = try file.read(upToCount: maximum + 1),
              data.count == size.intValue, data.count <= maximum else {
            throw ZayitSearchDistributionError.incompatible("incomplete database installation manifest")
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let installed = try (try? decoder.decode(OtzariaDatabaseInstallationManifest.self, from: data))
            ?? JSONDecoder().decode(OtzariaDatabaseInstallationManifest.self, from: data)
        let digest = installed.digest?.replacingOccurrences(of: "sha256:", with: "").lowercased()
        guard selection == OtzariaDatabaseAccessController.shared.selectionObservation(),
              installed.databaseFileSize == bytes,
              installed.releaseTag == manifest.requiredDatabase.releaseTag,
              installed.effectiveProfileID == manifest.effectiveProfileID,
              installed.effectiveProfileVersion == manifest.effectiveProfileVersion,
              digest == manifest.requiredDatabase.compressedAssetSHA256.lowercased() else {
            throw ZayitSearchDistributionError.incompatible("the index was built for a different DB release")
        }
    }
}
