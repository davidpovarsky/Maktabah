import pathlib,subprocess,json,hashlib,datetime
r=pathlib.Path('/Users/m1/builds/otzaria-wave2-search-20261127/managed-index-source-20261127/attempt2')
report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'swift':subprocess.check_output(['xcrun','swiftc','--version'],text=True),'variants':{}}
(r/'RUNNING.json').write_text(json.dumps({'status':'running','startedAt':report['observedAt']}))
for name in ['baseline','candidate']:
 d=r/name;cmd=['xcrun','swiftc','-parse-as-library','-swift-version','6','-strict-concurrency=complete','-j','1',*map(str,sorted(d.glob('*.swift'))),'-o',str(d/'control')]
 x=subprocess.run(cmd,text=True,capture_output=True,timeout=120);(d/'compile.log').write_text(x.stdout+x.stderr);rec={'compileCommand':cmd,'compileExit':x.returncode}
 if x.returncode==0:
  y=subprocess.run([str(d/'control'),str(d/'cases')],text=True,capture_output=True,timeout=45);(d/'run.log').write_text(y.stdout+y.stderr);rec.update(runExit=y.returncode,binarySHA256=hashlib.sha256((d/'control').read_bytes()).hexdigest())
  if (d/'cases/RESULT.json').exists():rec['result']=json.loads((d/'cases/RESULT.json').read_text())
  else:rec['diagnostics']=(y.stdout+y.stderr)[-12000:]
 else:rec['diagnostics']=(x.stdout+x.stderr)[-12000:]
 report['variants'][name]=rec
 (r/'COMPILE_RUN.json').write_text(json.dumps(report,indent=2))
(r/'COMPILE_RUN.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
