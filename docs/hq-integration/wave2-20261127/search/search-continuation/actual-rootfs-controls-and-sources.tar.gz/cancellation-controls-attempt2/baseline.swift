import Foundation
import Glibc
@MainActor final class Leaf {
    var isSearching = false, isLoadingMore = false, isLoading = false, isLoadingMoreBackendResults = false
}
@MainActor final class ZayitOwner { let model = Leaf() }
@MainActor final class OriginalControllerGuardFixture {
    var isSearching = false, isLoadingMore = false, isSefaria = false, isPreparingZayitSearch = false
    enum Scope: Equatable { case advanced, zayit }
    var scope: Scope = .advanced
    let otzaria = Leaf(), zayitSession = ZayitOwner()
    var searchViewModel: Leaf? = Leaf()
    var cancellationRevision = 0, stopCalls = 0
    var results = [11, 12], errorMessage: String? = "previous"
    var hasMore = true, wasCancelled = false, resultsAreDirty = true, configurationInvalidated = false
    // Declared boundary: actual stopEngineWork/model cancellation is not executed.
    // The control exercises the verbatim caller guards against a leaf that has
    // synchronously started before the original queued Unified mirror updates.
    func stopEngineWork() { stopCalls += 1; isSearching = false; isLoadingMore = false }
    func cancelSearch() {
        guard isSearching || isLoadingMore else { return }
        cancellationRevision += 1
        stopEngineWork()
        results = []
        errorMessage = nil
        hasMore = false
        wasCancelled = true
        #if DEBUG
        NSLog("[GlobalSearch] cancel revision=%d generation=%d", cancellationRevision, searchGeneration)
        #endif
    }
    func configurationDidChange() {
        guard resultsAreDirty else { return }
        configurationInvalidated = true
        if isSearching || isLoadingMore { stopEngineWork() }
    }
    private var originalBackendIsBusy: Bool {
        if isSefaria { return searchViewModel.map { $0.isSearching || $0.isLoadingMoreBackendResults } ?? false }
        if scope == .zayit { return isPreparingZayitSearch || zayitSession.model.isLoading || zayitSession.model.isLoadingMore }
        return otzaria.isSearching || otzaria.isLoadingMore
    }
}
@main @MainActor struct GuardControl {
    static func main() throws {
        var rows: [[String: Any]] = []
        func record(_ name: String, _ body: (OriginalControllerGuardFixture) -> Bool) {
            rows.append(["name":name, "passed":body(OriginalControllerGuardFixture())])
        }
        record("Otzaria started before mirror cancellation") { f in
            f.otzaria.isLoadingMore = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled && f.results.isEmpty
        }
        record("Zayit started before mirror cancellation") { f in
            f.scope = .zayit; f.zayitSession.model.isLoadingMore = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled
        }
        record("Sefaria started before mirror cancellation") { f in
            f.isSefaria = true; f.searchViewModel!.isLoadingMoreBackendResults = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled
        }
        record("Zayit preparation before mirror cancellation") { f in
            f.scope = .zayit; f.isPreparingZayitSearch = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1
        }
        record("dirty input stops synchronous leaf before mirror") { f in
            f.otzaria.isSearching = true; f.configurationDidChange()
            return f.configurationInvalidated && f.stopCalls == 1
        }
        record("idle original guard remains a no-op") { f in
            f.cancelSearch(); return f.stopCalls == 0 && f.cancellationRevision == 0 && !f.wasCancelled
        }
        record("published loading cancellation remains original") { f in
            f.isLoadingMore = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled && !f.hasMore
        }
        record("clean configuration guard remains a no-op") { f in
            f.resultsAreDirty = false; f.otzaria.isSearching = true; f.configurationDidChange()
            return !f.configurationInvalidated && f.stopCalls == 0
        }
        let failures = rows.filter { $0["passed"] as? Bool == false }.count
        let result: [String: Any] = ["scope":"VERBATIM_CONTROLLER_GUARDS_WITH_DECLARED_LEAF_AND_STOP_STUBS",
            "appUI":"NOT_RUN", "rows":rows,"passed":rows.count-failures,"failed":failures]
        print(String(decoding: try JSONSerialization.data(withJSONObject:result, options:[.prettyPrinted,.sortedKeys]), as:UTF8.self))
        if failures != 0 { exit(1) }
    }
}
