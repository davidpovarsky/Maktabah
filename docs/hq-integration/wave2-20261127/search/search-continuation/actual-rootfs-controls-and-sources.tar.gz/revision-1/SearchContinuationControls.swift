import Foundation
import Glibc
import OtzariaActionCore
@testable import ChavrusaUIRoutingHost

private enum Failure: Error { case expected(String) }
@MainActor private func require(_ value: @autoclosure () -> Bool, _ label: String = "assertion") throws {
    if !value() { throw Failure.expected(label) }
}
@MainActor private func rejects(_ body: () throws -> Void) throws {
    do { try body() } catch { return }
    throw Failure.expected("expected refusal")
}

@MainActor
private final class Fixture {
    let observation = UUID(), session = UUID(), model = UUID(), hitToken = UUID(), pageToken = UUID()
    let snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 7, rpcEpoch: 12)
    let hitIdentity = Data("original exact locator/version/language/body".utf8)
    var now: UInt64 = 100
    var calls = 0
    var authorityCalls = 0
    var valid = true
    func source(pagination: Int = 0, page: UInt64 = 1, configuration: Data = Data("query/config".utf8),
                generation: UInt64 = 3, revision: UInt64 = 9, scene: String = "scene-1") -> ActionSearchContinuationSource {
        .init(observationID: observation, sceneID: scene, snapshot: snapshot, sessionID: session,
              modelID: model, generation: generation, sourceRevision: revision, submissionRevision: 1,
              cancellationRevision: 0, paginationRevision: pagination, pageRevision: page, configuration: configuration)
    }
    var hit: ActionLoadedSearchHit {
        .init(token: hitToken, stableID: "source-hit-23", locator: "otzaria:book:7/line:23",
              versionTitle: nil, language: "he", identity: hitIdentity)
    }
    func command(_ operation: ActionSearchContinuationOperation? = nil) -> ActionSearchContinuationCommand {
        .init(source: source(), operation: operation ?? .revealLoadedHit(token: hitToken),
              invocation: .init(requestId: UUID(), snapshot: snapshot, deadlineUptimeNanoseconds: 1000))
    }
    func reveal(_ command: ActionSearchContinuationCommand) -> ActionSearchContinuationReceipt {
        .init(requestID: command.invocation.requestId, before: command.source, after: command.source,
              operation: command.operation, effects: [.hitSelectionApplied(hit)],
              visible: .init(witnessID: UUID(), listID: UUID(), rowID: UUID(), layoutRevision: 2, identity: hitIdentity))
    }
    func page(_ command: ActionSearchContinuationCommand, count: Int = 50,
              afterPagination: Int = 1, afterRevision: UInt64 = 2,
              cursor: Int? = 150, owner: UUID? = nil) -> ActionSearchContinuationReceipt {
        let attempt = UUID()
        let page = ActionSearchOriginalPageReceipt(attemptID: attempt, modelID: owner ?? model,
            generation: 3, pageRevision: afterRevision, request: Data("original encoded request".utf8),
            requestOffset: 100, requestLimit: 50, rawRowCount: count, mappedRowCount: count,
            consumedBefore: 100, consumedAfter: 100 + count, cursorBefore: 100,
            rawNextOffset: 100 + count, normalizedNextOffset: cursor, hasMore: cursor != nil, sourceEvidence: nil)
        return .init(requestID: command.invocation.requestId, before: command.source,
                     after: source(pagination: afterPagination, page: afterRevision), operation: command.operation,
                     effects: [.pageRequested(attemptID: attempt), .pageCommitted(page)],
                     visible: .init(witnessID: UUID(), listID: UUID(), rowID: nil, layoutRevision: 4, identity: nil))
    }
    func service(apply: @escaping NativeSearchContinuationService.Apply,
                 validate: @escaping NativeSearchContinuationService.Validate = { _, _ in }) -> NativeSearchContinuationService {
        .init(observe: { [self] scene, _ in
            .init(source: source(scene: scene), loadedHits: [hit], nextPageToken: pageToken)
        }, apply: apply, validate: validate, authority: { [self] _, _ in
            authorityCalls += 1
            guard valid else { throw ActionPortError.staleState }
        }, now: { [self] in now })
    }
}

@main
@MainActor
struct SearchContinuationControls {
    static func main() async throws {
        var results: [[String: Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            do { try await body(); results.append(["name": name, "passed": true]) }
            catch { results.append(["name": name, "passed": false, "error": String(describing: error)]) }
        }

        await run("same source observation reuses current tokens without result cache") {
            let owner = OriginalSearchContinuationClaim(), identity = Data("hit".utf8)
            let first = try owner.observe(source: Data([1]), hitIdentities: [identity], hasNextPage: true)
            let second = try owner.observe(source: Data([1]), hitIdentities: [identity], hasNextPage: true)
            try require(first == second)
        }
        await run("duplicate identity is refused before grouping") {
            let owner = OriginalSearchContinuationClaim()
            try rejects { _ = try owner.observe(source: Data([1]), hitIdentities: [Data([4]), Data([4])], hasNextPage: true) }
        }
        await run("one synchronous claim prevents duplicate immediate dispatch") {
            let owner = OriginalSearchContinuationClaim()
            let o = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            let first = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: o.id, source: o.source)
            try rejects { _ = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: o.id, source: o.source) }
            try require(owner.active == first)
        }
        await run("completed claim cannot replay") {
            let owner = OriginalSearchContinuationClaim()
            let o = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            let c = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: o.id, source: o.source)
            owner.finish(c)
            try rejects { _ = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: o.id, source: o.source) }
        }
        await run("wrong operation cannot reinterpret a hit as cursor") {
            let owner = OriginalSearchContinuationClaim()
            let o = try owner.observe(source: Data([1]), hitIdentities: [Data([4])], hasNextPage: true)
            try rejects { _ = try owner.claim(tokenID: o.hits[0].id, kind: .nextPage, observationID: o.id, source: o.source) }
        }
        await run("foreign source and observation are refused") {
            let owner = OriginalSearchContinuationClaim()
            let o = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            try rejects { _ = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: UUID(), source: o.source) }
            try rejects { _ = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: o.id, source: Data([2])) }
        }
        await run("ABA source cannot revive a retired token") {
            let owner = OriginalSearchContinuationClaim()
            let first = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            _ = try owner.observe(source: Data([2]), hitIdentities: [], hasNextPage: true)
            let third = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            try require(first.id != third.id && first.next != third.next)
            try rejects { _ = try owner.claim(tokenID: first.next!.id, kind: .nextPage, observationID: first.id, source: first.source) }
        }
        await run("invalidation keeps operation exclusion until exact owner finishes") {
            let owner = OriginalSearchContinuationClaim()
            let o = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            let c = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: o.id, source: o.source)
            owner.invalidate()
            try rejects { try owner.validate(c) }
            try rejects { _ = try owner.observe(source: Data([2]), hitIdentities: [], hasNextPage: true) }
            owner.finish(c)
            let next = try owner.observe(source: Data([2]), hitIdentities: [], hasNextPage: true)
            try require(next.id != o.id)
        }
        await run("failed claim requires a fresh changed-source token for retry") {
            let owner = OriginalSearchContinuationClaim()
            let o = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            let c = try owner.claim(tokenID: o.next!.id, kind: .nextPage, observationID: o.id, source: o.source)
            owner.finish(c)
            let same = try owner.observe(source: Data([1]), hitIdentities: [], hasNextPage: true)
            try require(same.next == o.next)
            try rejects { _ = try owner.claim(tokenID: same.next!.id, kind: .nextPage, observationID: same.id, source: same.source) }
            let fresh = try owner.observe(source: Data([2]), hitIdentities: [], hasNextPage: true)
            _ = try owner.claim(tokenID: fresh.next!.id, kind: .nextPage, observationID: fresh.id, source: fresh.source)
        }
        await run("exact source configuration bytes distinguish Unicode normalization") {
            let f = Fixture()
            try require("é" == "e\u{301}")
            try require(f.source(configuration: Data("é".utf8)) != f.source(configuration: Data("e\u{301}".utf8)))
        }
        await run("hit metadata preserves nil versus empty and exact version bytes") {
            let f = Fixture(), token = UUID(), identity = Data([7])
            @MainActor func hit(_ version: String?) -> ActionLoadedSearchHit {
                .init(token: token, stableID: f.hit.stableID, locator: f.hit.locator,
                      versionTitle: version, language: "he", identity: identity)
            }
            try require(hit(nil) != hit("")); try require(hit("é") != hit("e\u{301}"))
        }
        await run("old first-page query still rejects arbitrary offsets") {
            try rejects { _ = try ActionSearchResultsQuery(.init(backend: .otzaria, text: "נפשי", offset: 50)) }
            _ = try ActionSearchResultsQuery(.init(backend: .otzaria, text: "נפשי"))
        }
        await run("exact reveal passes retained validation and live authority") {
            let f = Fixture(), command = f.command()
            let service = f.service(apply: { command, check in
                try! check(); f.calls += 1
                await Task.yield()
                try! check()
                return .acknowledged(f.reveal(command))
            })
            let outcome = await service.continueSearch(command)
            guard case .acknowledged = outcome else { throw Failure.expected("reveal refused") }
            try require(f.calls == 1 && f.authorityCalls >= 5)
        }
        await run("unavailable authority prevents every apply effect") {
            let f = Fixture(); f.valid = false
            let service = f.service(apply: { command, _ in f.calls += 1; return .acknowledged(f.reveal(command)) })
            let outcome = await service.continueSearch(f.command())
            guard case .refused(let failure) = outcome else { throw Failure.expected("unauthorized pass") }
            try require(f.calls == 0 && failure.effects.isEmpty)
        }
        await run("authority loss after await retains actual selection effect") {
            let f = Fixture(), command = f.command()
            let actual = f.reveal(command)
            let service = f.service(apply: { _, check in
                try! check(); await Task.yield(); f.valid = false
                return .acknowledged(actual)
            })
            let outcome = await service.continueSearch(command)
            guard case .refused(let failure) = outcome else { throw Failure.expected("late authority pass") }
            try require(failure.reason == .staleSource && failure.effects == actual.effects)
        }
        await run("deadline after apply retains effects without acknowledgement") {
            let f = Fixture(), command = f.command()
            let actual = f.reveal(command)
            let service = f.service(apply: { _, _ in f.now = 1000; return .acknowledged(actual) })
            let outcome = await service.continueSearch(command)
            guard case .refused(let failure) = outcome else { throw Failure.expected("late pass") }
            try require(failure.reason == .deadlineExceeded && failure.effects == actual.effects)
        }
        await run("retained native validation refusal preserves actual effect") {
            let f = Fixture(), command = f.command(), service = f.service(apply: { command, _ in
                .acknowledged(f.reveal(command))
            }, validate: { _, _ in throw ActionPortError.staleState })
            let outcome = await service.continueSearch(command)
            guard case .refused(let failure) = outcome else { throw Failure.expected("stale native pass") }
            try require(failure.effects == [.hitSelectionApplied(f.hit)])
        }
        await run("empty terminal page uses accepted revision not offset growth") {
            let f = Fixture(), command = f.command(.nextOriginalPage(token: f.pageToken))
            let receipt = f.page(command, count: 0, cursor: nil)
            try NativeSearchContinuationService.validateShape(command, receipt)
        }
        await run("all-deduplicated accepted page keeps raw cursor accounting") {
            let f = Fixture(), command = f.command(.nextOriginalPage(token: f.pageToken))
            try NativeSearchContinuationService.validateShape(command, f.page(command, count: 50, cursor: 150))
        }
        await run("foreign extra page dispatch cannot be one continuation") {
            let f = Fixture(), command = f.command(.nextOriginalPage(token: f.pageToken))
            try rejects { try NativeSearchContinuationService.validateShape(command, f.page(command, afterPagination: 2)) }
        }
        await run("dispatch without accepted page revision is not completion") {
            let f = Fixture(), command = f.command(.nextOriginalPage(token: f.pageToken))
            try rejects { try NativeSearchContinuationService.validateShape(command, f.page(command, afterRevision: 1)) }
        }
        await run("different original model cannot supply page receipt") {
            let f = Fixture(), command = f.command(.nextOriginalPage(token: f.pageToken))
            try rejects { try NativeSearchContinuationService.validateShape(command, f.page(command, owner: UUID())) }
        }
        await run("nonadvancing advertised cursor cannot rearm page") {
            let f = Fixture(), command = f.command(.nextOriginalPage(token: f.pageToken))
            try rejects { try NativeSearchContinuationService.validateShape(command, f.page(command, cursor: 100)) }
        }
        await run("wrong hit version cannot match visible identity") {
            let f = Fixture(), command = f.command(), actual = f.reveal(f.command())
            let wrong = ActionSearchContinuationReceipt(requestID: command.invocation.requestId, before: command.source,
                after: command.source, operation: command.operation, effects: [.hitSelectionApplied(f.hit)],
                visible: .init(witnessID: actual.visible.witnessID, listID: actual.visible.listID,
                               rowID: actual.visible.rowID, layoutRevision: 2, identity: Data("other-version".utf8)))
            try rejects { try NativeSearchContinuationService.validateShape(command, wrong) }
        }
        await run("cancelled task preserves an actual original selection effect") {
            let f = Fixture(), command = f.command()
            var suspended: CheckedContinuation<Void, Never>?
            let service = f.service(apply: { command, check in
                try! check()
                await withCheckedContinuation { suspended = $0 }
                return .acknowledged(f.reveal(command))
            })
            let operation = Task { await service.continueSearch(command) }
            for _ in 0..<1000 where suspended == nil { await Task.yield() }
            guard let suspended else { operation.cancel(); throw Failure.expected("control did not suspend") }
            operation.cancel(); suspended.resume()
            guard case .refused(let failure) = await operation.value else { throw Failure.expected("cancelled task passed") }
            try require(failure.reason == .cancelled && failure.effects == [.hitSelectionApplied(f.hit)])
        }
        await run("source/backend snapshot mismatch prevents apply") {
            let f = Fixture()
            let command = ActionSearchContinuationCommand(source: f.source(), operation: .revealLoadedHit(token: f.hitToken),
                invocation: .init(requestId: UUID(), snapshot: .init(backend: .otzaria, generation: 8, rpcEpoch: 12),
                                  deadlineUptimeNanoseconds: 1000))
            let service = f.service(apply: { command, _ in f.calls += 1; return .acknowledged(f.reveal(command)) })
            guard case .refused(let failure) = await service.continueSearch(command) else { throw Failure.expected("wrong snapshot passed") }
            try require(f.calls == 0 && failure.effects.isEmpty)
        }

        let failed = results.filter { $0["passed"] as? Bool == false }
        let output: [String: Any] = ["scope": "PORTABLE_ORIGINAL_CONTRACT_SERVICE_CLAIM_CONTROLS_ONLY",
            "appUI": "NOT_RUN", "cases": results, "passed": results.count - failed.count,
            "failed": failed.count, "pid": ProcessInfo.processInfo.processIdentifier]
        let data = try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: data, as: UTF8.self))
        if !failed.isEmpty { exit(1) }
    }
}
