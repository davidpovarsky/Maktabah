#!/usr/bin/env python3
"""Targeted follow-up; all writes stay in the previously admitted rootfs root."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
LIMIT = 40 * 1024 * 1024
FLOOR = 1024 * 1024 * 1024


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    args = parser.parse_args()
    root = args.root
    revision = root / "revision-2"
    assert root == root.resolve() and root.stat().st_dev == 2049 and root.stat().st_uid == os.geteuid() == 1001
    assert root.stat().st_mode & 0o777 == 0o700 and Path.cwd() == root
    assert revision.resolve().is_relative_to(root) and revision.stat().st_dev == 2049
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    previous_runner = root / "revision-1/run-rootfs-controls.py"
    assert hashlib.sha256(previous_runner.read_bytes()).hexdigest() == "65fbe56acdeb898f131b2c16f1a882c4c077e168e288efc2440b4c0a1548e6e6"
    spec = importlib.util.spec_from_file_location("retained_rootfs_helpers", previous_runner)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    sha, write, allocation, identity = helper.sha, helper.write, helper.allocation, helper.identity
    assert sha(root / "RESULT-attempt2.json") == "adf3bdfb240436c4b43ce3abea55e12fb4ff36273697568390669abde208983f"
    previous = json.loads((root / "RESULT-attempt2.json").read_text())
    assert previous["status"] == "PORTABLE_COMPONENT_CONTROLS_PASSED_APP_NATIVE_NOT_RUN"
    assert all(p["ownedGroupAbsent"] for p in previous["phases"])
    inputs = json.loads((root / "INPUTS.json").read_text())
    for row in inputs["files"]:
        path = root / row["path"]
        assert path.resolve().is_relative_to(root) and path.stat().st_dev == 2049
        assert path.stat().st_size == row["bytes"] and sha(path) == row["sha256"]
    for row in previous["artifacts"]:
        path = Path(row["path"])
        assert path.resolve().is_relative_to(root / "output")
        assert path.stat().st_size == row["bytes"] and sha(path) == row["sha256"]
    updates = json.loads((revision / "INPUTS.json").read_text())
    for row in updates["files"]:
        path = revision / row["path"]
        assert path.resolve().is_relative_to(revision) and path.stat().st_dev == 2049
        assert path.stat().st_size == row["bytes"] and sha(path) == row["sha256"]
    tool = Path(inputs["compiler"])
    assert str(tool) == "/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc"
    target = tool.resolve(strict=True)
    tool_receipt = {"argv0": str(tool), "resolved": str(target), "sha256": sha(target),
                    "bytes": target.stat().st_size, "device": target.stat().st_dev,
                    "inode": target.stat().st_ino, "mtimeNs": target.stat().st_mtime_ns}
    assert tool_receipt == previous["tool"]
    maximum = allocation(root)
    minimum = os.statvfs(root).f_bavail * os.statvfs(root).f_frsize
    assert maximum <= LIMIT and minimum >= FLOOR
    output, cache, tmp = revision / "output", root / "module-cache", root / "tmp"
    output.mkdir(mode=0o700)
    env = dict(os.environ, TMPDIR=str(tmp), LC_ALL="C", TZ="UTC", GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1")
    write(revision / "ADMISSION.json", {"scope": "TARGETED_ATTRIBUTION_FOLLOWUP_ROOTFS_ONLY", "uid": os.geteuid(),
        "pid": os.getpid(), "root": str(root), "writeDevice": 2049, "dataWrites": False,
        "rootfsMinimumBytes": FLOOR, "aggregateOwnedMaximumBytes": LIMIT, "initialOwned": maximum,
        "initialRootfsFree": minimum, "dataFreeDiagnosticOnly": os.statvfs("/mnt/development").f_bavail * os.statvfs("/mnt/development").f_frsize,
        "tool": tool_receipt, "oldActualResultSHA256": sha(root / "RESULT-attempt2.json"),
        "newInputsSHA256": sha(revision / "INPUTS.json")})
    phases = []

    def limits():
        nonlocal maximum, minimum
        used = allocation(root)
        free = os.statvfs(root).f_bavail * os.statvfs(root).f_frsize
        maximum, minimum = max(maximum, used), min(minimum, free)
        if used > LIMIT or free < FLOOR:
            raise RuntimeError(f"rootfs resource gate: owned={used} free={free}")

    def run(name, argv, expected=0, timeout=150):
        limits()
        row = {"name": name, "argv": argv, "cwd": str(root), "startedUnix": time.time(),
               "expectedExit": expected, "startAttempted": True, "handleReturned": False, "ownedGroupAbsent": False}
        process = owner = failure = None
        stdout, stderr = revision / (name + ".stdout"), revision / (name + ".stderr")
        try:
            with stdout.open("xb") as out, stderr.open("xb") as err:
                process = subprocess.Popen(argv, cwd=root, env=env, stdout=out, stderr=err, start_new_session=True)
                row["handleReturned"] = True
                owner = identity(process.pid)
                assert owner is not None and owner["parent"] == os.getpid() and owner["group"] == process.pid
                row["identity"] = owner
                started = time.monotonic()
                while process.poll() is None:
                    limits()
                    if time.monotonic() - started > timeout:
                        raise TimeoutError(name)
                    time.sleep(0.1)
                row["exit"] = process.returncode
        except BaseException as error:
            failure = error
            row["error"] = repr(error)
        finally:
            if process is not None:
                if process.poll() is None:
                    if owner is not None and identity(process.pid) == owner:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            if process.poll() is None and identity(process.pid) == owner:
                                os.killpg(process.pid, signal.SIGKILL)
                                process.wait(timeout=3)
                    else:
                        row["cleanupOwnershipUnverified"] = True
                if process.poll() is not None:
                    try:
                        os.killpg(process.pid, 0)
                    except ProcessLookupError:
                        row["ownedGroupAbsent"] = True
                    row["exit"] = process.returncode
            row["finishedUnix"] = time.time()
            row["stdout"] = {"path": str(stdout), "bytes": stdout.stat().st_size, "sha256": sha(stdout)}
            row["stderr"] = {"path": str(stderr), "bytes": stderr.stat().st_size, "sha256": sha(stderr)}
            phases.append(row)
            write(revision / (name + ".PHASE.json"), row)
        if failure is not None:
            raise failure
        assert row["ownedGroupAbsent"] and row["exit"] == expected, row
        limits()
        return stdout

    status, error = "FAILED", None
    try:
        common = [str(tool), "-swift-version", "6", "-parse-as-library", "-module-cache-path", str(cache)]
        old = root / "output"
        old_link = ["-I", str(old), "-L", str(old), "-Xlinker", "-rpath", "-Xlinker", str(old)]
        baseline_binary = output / "foreign-outcome-baseline"
        run("compile-old-service-counterexamples", common + old_link + ["-lOtzariaActionCore", "-lChavrusaUIRoutingHost",
            str(revision / "controls/ForeignOutcomeBaselineControls.swift"), "-o", str(baseline_binary)])
        raw = run("old-service-counterexamples", [str(baseline_binary)], expected=1, timeout=20)
        result = json.loads(raw.read_text())
        assert result["passed"] == 0 and result["failed"] == 6 and len(result["cases"]) == 6
        core = [root / row["path"] for row in inputs["files"] if row["role"] == "originalCore"]
        assert len(core) == 28
        candidate = revision / "candidate"
        contract = candidate / "Source/Otzaria/Actions/Sources/OtzariaActionCore/Contracts/ActionSearchContinuation.swift"
        service = candidate / "Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/NativeSearchContinuationService.swift"
        binding = candidate / "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSearchContinuation.swift"
        run("compile-revised-core", common + ["-emit-library", "-emit-module", "-enable-testing", "-module-name", "OtzariaActionCore",
            "-emit-module-path", str(output / "OtzariaActionCore.swiftmodule"), "-o", str(output / "libOtzariaActionCore.so")]
            + [str(p) for p in core] + [str(contract), str(old / "resource_bundle_accessor.swift")])
        link = ["-I", str(output), "-L", str(output), "-Xlinker", "-rpath", "-Xlinker", str(output)]
        run("compile-revised-service", common + link + ["-lOtzariaActionCore", "-emit-library", "-emit-module", "-enable-testing",
            "-module-name", "ChavrusaUIRoutingHost", "-emit-module-path", str(output / "ChavrusaUIRoutingHost.swiftmodule"),
            "-o", str(output / "libChavrusaUIRoutingHost.so"), str(service)])
        binary = output / "foreign-outcome-controls"
        run("compile-attribution-controls", common + link + ["-lOtzariaActionCore", "-lChavrusaUIRoutingHost",
            str(revision / "controls/ForeignOutcomeControls.swift"), "-o", str(binary)])
        raw = run("attribution-controls", [str(binary)], timeout=20)
        result = json.loads(raw.read_text())
        assert result["passed"] == 19 and result["failed"] == 0 and len(result["cases"]) == 19
        run("changed-source-ios-syntax-only", [str(tool), "-frontend", "-parse", "-target", "arm64-apple-ios17.0-simulator",
            str(contract), str(service), str(binding)])
        status = "ATTRIBUTION_CONTROLS_PASSED_APP_NATIVE_NOT_RUN"
    except BaseException as caught:
        error = repr(caught)
    finally:
        artifacts = [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}
                     for path in sorted(output.rglob("*")) if path.is_file()]
        write(revision / "RESULT.json", {"status": status, "error": error, "scope": "ACTUAL_SERVICE_ATTRIBUTION_COMPONENTS_ONLY",
            "appSDKTypecheck": "NOT_RUN", "nativeUI": "NOT_RUN", "old26Controls": "NOT_RERUN_BOUND_TO_PRIOR_SOURCE",
            "controllerControls": "NOT_RERUN_UNCHANGED_SOURCE", "original68Suite": "NOT_RERUN",
            "fullActionCoreOriginalSwiftFiles": 28, "focusedHostModuleSwiftFiles": 1,
            "writeDevice": 2049, "dataWrites": False, "aggregateMaximumOwnedBytes": maximum,
            "minimumRootfsFree": minimum, "tool": tool_receipt, "phases": phases, "artifacts": artifacts,
            "priorResult": {"path": str(root / "RESULT-attempt2.json"), "sha256": sha(root / "RESULT-attempt2.json")},
            "inputsSHA256": sha(revision / "INPUTS.json"), "runner": {"path": str(Path(__file__)), "sha256": sha(Path(__file__))}})
    return 0 if status == "ATTRIBUTION_CONTROLS_PASSED_APP_NATIVE_NOT_RUN" else 1


if __name__ == "__main__":
    sys.exit(main())
