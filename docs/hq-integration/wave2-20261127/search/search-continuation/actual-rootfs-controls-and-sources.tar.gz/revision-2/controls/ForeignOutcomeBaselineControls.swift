import Foundation
import Glibc
import OtzariaActionCore
@testable import ChavrusaUIRoutingHost

private enum Failure: Error { case expected(String) }
@MainActor private func require(_ value: @autoclosure () -> Bool, _ label: String = "assertion") throws {
    if !value() { throw Failure.expected(label) }
}
@MainActor private func rejects(_ body: () throws -> Void) throws {
    do { try body() } catch { return }
    throw Failure.expected("expected refusal")
}

@MainActor
private final class AttributionFixture {
    let observation = UUID(), session = UUID(), model = UUID(), hitToken = UUID(), pageToken = UUID()
    let snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 7, rpcEpoch: 12)
    let hitIdentity = Data("original exact locator/version/language/body".utf8)
    var now: UInt64 = 100
    var calls = 0
    var authorityCalls = 0
    var valid = true
    func source(pagination: Int = 0, page: UInt64 = 1, configuration: Data = Data("query/config".utf8),
                generation: UInt64 = 3, revision: UInt64 = 9, scene: String = "scene-1") -> ActionSearchContinuationSource {
        .init(observationID: observation, sceneID: scene, snapshot: snapshot, sessionID: session,
              modelID: model, generation: generation, sourceRevision: revision, submissionRevision: 1,
              cancellationRevision: 0, paginationRevision: pagination, pageRevision: page, configuration: configuration)
    }
    var hit: ActionLoadedSearchHit {
        .init(token: hitToken, stableID: "source-hit-23", locator: "otzaria:book:7/line:23",
              versionTitle: nil, language: "he", identity: hitIdentity)
    }
    func command(_ operation: ActionSearchContinuationOperation? = nil) -> ActionSearchContinuationCommand {
        .init(source: source(), operation: operation ?? .revealLoadedHit(token: hitToken),
              invocation: .init(requestId: UUID(), snapshot: snapshot, deadlineUptimeNanoseconds: 1000))
    }
    func reveal(_ command: ActionSearchContinuationCommand) -> ActionSearchContinuationReceipt {
        .init(requestID: command.invocation.requestId, before: command.source, after: command.source,
              operation: command.operation, effects: [.hitSelectionApplied(hit)],
              visible: .init(witnessID: UUID(), listID: UUID(), rowID: UUID(), layoutRevision: 2, identity: hitIdentity))
    }
    func page(_ command: ActionSearchContinuationCommand, count: Int = 50,
              afterPagination: Int = 1, afterRevision: UInt64 = 2,
              cursor: Int? = 150, owner: UUID? = nil) -> ActionSearchContinuationReceipt {
        let attempt = UUID()
        let page = ActionSearchOriginalPageReceipt(attemptID: attempt, modelID: owner ?? model,
            generation: 3, pageRevision: afterRevision, request: Data("original encoded request".utf8),
            requestOffset: 100, requestLimit: 50, rawRowCount: count, mappedRowCount: count,
            consumedBefore: 100, consumedAfter: 100 + count, cursorBefore: 100,
            rawNextOffset: 100 + count, normalizedNextOffset: cursor, hasMore: cursor != nil, sourceEvidence: nil)
        return .init(requestID: command.invocation.requestId, before: command.source,
                     after: source(pagination: afterPagination, page: afterRevision), operation: command.operation,
                     effects: [.pageRequested(attemptID: attempt), .pageCommitted(page)],
                     visible: .init(witnessID: UUID(), listID: UUID(), rowID: nil, layoutRevision: 4, identity: nil))
    }
    func service(apply: @escaping NativeSearchContinuationService.Apply,
                 validate: @escaping NativeSearchContinuationService.Validate = { _, _ in }) -> NativeSearchContinuationService {
        .init(observe: { [self] scene, _ in
            .init(source: source(scene: scene), loadedHits: [hit], nextPageToken: pageToken)
        }, apply: apply, validate: validate, authority: { [self] _, _ in
            authorityCalls += 1
            guard valid else { throw ActionPortError.staleState }
        }, now: { [self] in now })
    }
}


// Uses the exact prior compiled Core/service and fixture; no UIKit/provider.
@main
@MainActor
struct ForeignOutcomeBaselineControls {
    static func main() async throws {
        var rows: [[String: Any]] = []
        @MainActor func run(_ name: String, _ make: @MainActor (AttributionFixture, ActionSearchContinuationCommand) -> ActionSearchContinuationOutcome,
                 loseAuthority: Bool = false) async {
            let f = AttributionFixture(), command = f.command()
            let raw = make(f, command)
            let service = f.service(apply: { _, _ in
                if loseAuthority { f.valid = false }
                return raw
            })
            let actual = await service.continueSearch(command)
            let relabelled: Bool
            switch actual {
            case .refused(let failure):
                relabelled = failure.requestID == command.invocation.requestId && !failure.effects.isEmpty
            case .acknowledged: relabelled = true
            }
            rows.append(["name": name, "passed": !relabelled,
                         "currentRequestWasGivenUnjoinedEffects": relabelled])
        }
        await run("foreign request failure cannot donate effects") { f, _ in
            .refused(.init(requestID: UUID(), reason: .cancelled, effects: [.hitSelectionApplied(f.hit)]))
        }
        await run("foreign request acknowledgement cannot donate effects") { f, _ in
            .acknowledged(f.reveal(f.command()))
        }
        await run("same request foreign source acknowledgement cannot donate effects") { f, command in
            let receipt = f.reveal(command)
            return .acknowledged(.init(requestID: receipt.requestID, before: f.source(generation: 88),
                after: f.source(generation: 88), operation: receipt.operation,
                effects: receipt.effects, visible: receipt.visible))
        }
        await run("same request foreign operation acknowledgement cannot donate effects") { f, command in
            let receipt = f.reveal(command)
            return .acknowledged(.init(requestID: receipt.requestID, before: receipt.before,
                after: receipt.after, operation: .revealLoadedHit(token: UUID()),
                effects: receipt.effects, visible: receipt.visible))
        }
        await run("foreign source is joined before late authority refusal", { f, command in
            let receipt = f.reveal(command)
            return .acknowledged(.init(requestID: receipt.requestID, before: f.source(generation: 88),
                after: f.source(generation: 88), operation: receipt.operation,
                effects: receipt.effects, visible: receipt.visible))
        }, loseAuthority: true)
        await run("unattested failure origin is never joined by UUID alone") { f, command in
            .refused(.init(requestID: command.invocation.requestId, reason: .cancelled,
                          effects: [.hitSelectionApplied(f.hit)]))
        }
        let failed = rows.filter { $0["passed"] as? Bool == false }.count
        let result: [String: Any] = ["scope": "PRIOR_ACTUAL_SERVICE_FOREIGN_OUTCOME_COUNTEREXAMPLES_WITH_FIXTURE_RESPONSES",
            "appUI": "NOT_RUN", "passed": rows.count - failed, "failed": failed, "cases": rows,
            "pid": ProcessInfo.processInfo.processIdentifier]
        print(String(decoding: try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys]), as: UTF8.self))
        if failed != 0 { exit(1) }
    }
}
