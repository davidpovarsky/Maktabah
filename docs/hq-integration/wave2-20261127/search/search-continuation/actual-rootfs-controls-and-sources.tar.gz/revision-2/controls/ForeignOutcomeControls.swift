import Foundation
import Glibc
import OtzariaActionCore
@testable import ChavrusaUIRoutingHost

private enum Failure: Error { case expected(String) }
@MainActor private func require(_ value: @autoclosure () -> Bool, _ label: String = "assertion") throws {
    if !value() { throw Failure.expected(label) }
}
@MainActor private func rejects(_ body: () throws -> Void) throws {
    do { try body() } catch { return }
    throw Failure.expected("expected refusal")
}

@MainActor
private final class AttributionFixture {
    let observation = UUID(), session = UUID(), model = UUID(), hitToken = UUID(), pageToken = UUID()
    let snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 7, rpcEpoch: 12)
    let hitIdentity = Data("original exact locator/version/language/body".utf8)
    var now: UInt64 = 100
    var calls = 0
    var authorityCalls = 0
    var valid = true
    func source(pagination: Int = 0, page: UInt64 = 1, configuration: Data = Data("query/config".utf8),
                generation: UInt64 = 3, revision: UInt64 = 9, scene: String = "scene-1") -> ActionSearchContinuationSource {
        .init(observationID: observation, sceneID: scene, snapshot: snapshot, sessionID: session,
              modelID: model, generation: generation, sourceRevision: revision, submissionRevision: 1,
              cancellationRevision: 0, paginationRevision: pagination, pageRevision: page, configuration: configuration)
    }
    var hit: ActionLoadedSearchHit {
        .init(token: hitToken, stableID: "source-hit-23", locator: "otzaria:book:7/line:23",
              versionTitle: nil, language: "he", identity: hitIdentity)
    }
    func command(_ operation: ActionSearchContinuationOperation? = nil) -> ActionSearchContinuationCommand {
        .init(source: source(), operation: operation ?? .revealLoadedHit(token: hitToken),
              invocation: .init(requestId: UUID(), snapshot: snapshot, deadlineUptimeNanoseconds: 1000))
    }
    func reveal(_ command: ActionSearchContinuationCommand) -> ActionSearchContinuationReceipt {
        .init(requestID: command.invocation.requestId, before: command.source, after: command.source,
              operation: command.operation, effects: [.hitSelectionApplied(hit)],
              visible: .init(witnessID: UUID(), listID: UUID(), rowID: UUID(), layoutRevision: 2, identity: hitIdentity))
    }
    func page(_ command: ActionSearchContinuationCommand, count: Int = 50,
              afterPagination: Int = 1, afterRevision: UInt64 = 2,
              cursor: Int? = 150, owner: UUID? = nil) -> ActionSearchContinuationReceipt {
        let attempt = UUID()
        let page = ActionSearchOriginalPageReceipt(attemptID: attempt, modelID: owner ?? model,
            generation: 3, pageRevision: afterRevision, request: Data("original encoded request".utf8),
            requestOffset: 100, requestLimit: 50, rawRowCount: count, mappedRowCount: count,
            consumedBefore: 100, consumedAfter: 100 + count, cursorBefore: 100,
            rawNextOffset: 100 + count, normalizedNextOffset: cursor, hasMore: cursor != nil, sourceEvidence: nil)
        return .init(requestID: command.invocation.requestId, before: command.source,
                     after: source(pagination: afterPagination, page: afterRevision), operation: command.operation,
                     effects: [.pageRequested(attemptID: attempt), .pageCommitted(page)],
                     visible: .init(witnessID: UUID(), listID: UUID(), rowID: nil, layoutRevision: 4, identity: nil))
    }
    func service(apply: @escaping NativeSearchContinuationService.Apply,
                 validate: @escaping NativeSearchContinuationService.Validate = { _, _ in }) -> NativeSearchContinuationService {
        .init(observe: { [self] scene, _ in
            .init(source: source(scene: scene), loadedHits: [hit], nextPageToken: pageToken)
        }, apply: apply, validate: validate, authority: { [self] _, _ in
            authorityCalls += 1
            guard valid else { throw ActionPortError.staleState }
        }, now: { [self] in now })
    }
}


// Calls the actual revised service and contract with declared fixture owner
// responses. This does not instantiate the original UIKit binding or provider.
@main
@MainActor
struct ForeignOutcomeControls {
    static func main() async throws {
        var rows: [[String: Any]] = []
        @MainActor func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            do { try await body(); rows.append(["name": name, "passed": true]) }
            catch { rows.append(["name": name, "passed": false, "error": String(describing: error)]) }
        }
        @MainActor func unqualified(_ actual: ActionSearchContinuationOutcome, _ command: ActionSearchContinuationCommand,
                         _ original: ActionSearchContinuationOutcome) throws {
            guard case .unqualified(let attempted, let retained) = actual else { throw Failure.expected("response was attributed") }
            try require(attempted == command && retained == original, "raw provenance changed")
        }
        @MainActor func joined(_ actual: ActionSearchContinuationOutcome, _ command: ActionSearchContinuationCommand,
                    effects: [ActionSearchContinuationEffect], reason: ActionSearchContinuationRefusal) throws {
            guard case .refused(let failure) = actual else { throw Failure.expected("joined operation was lost") }
            try require(failure.requestID == command.invocation.requestId && failure.source == command.source
                        && failure.operation == command.operation && failure.effects == effects && failure.reason == reason)
        }

        await run("foreign request failure remains untouched and unqualified") {
            let f = AttributionFixture(), command = f.command(), other = f.command()
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: other.invocation.requestId,
                reason: .cancelled, effects: [.hitSelectionApplied(f.hit)], source: other.source, operation: other.operation))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("same UUID foreign source failure remains unqualified") {
            let f = AttributionFixture(), command = f.command()
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .cancelled, effects: [.hitSelectionApplied(f.hit)], source: f.source(generation: 88), operation: command.operation))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("same UUID foreign operation failure remains unqualified") {
            let f = AttributionFixture(), command = f.command()
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .cancelled, effects: [.hitSelectionApplied(f.hit)], source: command.source,
                operation: .revealLoadedHit(token: UUID())))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("nil failure origin is explicitly unqualified") {
            let f = AttributionFixture(), command = f.command()
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .cancelled, effects: [.hitSelectionApplied(f.hit)]))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("partial failure origin does not attest an operation") {
            let f = AttributionFixture(), command = f.command()
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .cancelled, effects: [], source: command.source))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("foreign request acknowledgement remains unqualified") {
            let f = AttributionFixture(), command = f.command()
            let raw = ActionSearchContinuationOutcome.acknowledged(f.reveal(f.command()))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("same UUID foreign source acknowledgement remains unqualified before authority") {
            let f = AttributionFixture(), command = f.command(), r = f.reveal(command)
            let raw = ActionSearchContinuationOutcome.acknowledged(.init(requestID: r.requestID,
                before: f.source(generation: 88), after: f.source(generation: 88), operation: r.operation,
                effects: r.effects, visible: r.visible))
            let service = f.service(apply: { _, _ in f.valid = false; return raw })
            try unqualified(await service.continueSearch(command), command, raw)
        }
        await run("same UUID foreign operation acknowledgement remains unqualified") {
            let f = AttributionFixture(), command = f.command(), r = f.reveal(command)
            let raw = ActionSearchContinuationOutcome.acknowledged(.init(requestID: r.requestID,
                before: r.before, after: r.after, operation: .revealLoadedHit(token: UUID()), effects: r.effects, visible: r.visible))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("foreign after source cannot donate acknowledged effects") {
            let f = AttributionFixture(), command = f.command(), r = f.reveal(command)
            let raw = ActionSearchContinuationOutcome.acknowledged(.init(requestID: r.requestID,
                before: r.before, after: f.source(generation: 88), operation: r.operation, effects: r.effects, visible: r.visible))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("malformed visible identity retains raw outcome without effect attribution") {
            let f = AttributionFixture(), command = f.command(), r = f.reveal(command)
            let raw = ActionSearchContinuationOutcome.acknowledged(.init(requestID: r.requestID, before: r.before,
                after: r.after, operation: r.operation, effects: r.effects,
                visible: .init(witnessID: r.visible.witnessID, listID: r.visible.listID, rowID: r.visible.rowID,
                               layoutRevision: 2, identity: Data("foreign-version".utf8))))
            try unqualified(await f.service(apply: { _, _ in raw }).continueSearch(command), command, raw)
        }
        await run("nested unqualified response preserves all original provenance") {
            let f = AttributionFixture(), command = f.command(), other = f.command()
            let innermost = ActionSearchContinuationOutcome.acknowledged(f.reveal(other))
            let nested = ActionSearchContinuationOutcome.unqualified(command: other, originalResponse: innermost)
            try unqualified(await f.service(apply: { _, _ in nested }).continueSearch(command), command, nested)
        }
        await run("exact joined failure is returned unchanged") {
            let f = AttributionFixture(), command = f.command()
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .providerFailed, effects: [.hitSelectionApplied(f.hit)], source: command.source, operation: command.operation))
            let actual = await f.service(apply: { _, _ in raw }).continueSearch(command)
            try require(actual == raw)
        }
        await run("joined failure retains real A effects after authority loss") {
            let f = AttributionFixture(), command = f.command(), effects: [ActionSearchContinuationEffect] = [.hitSelectionApplied(f.hit)]
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .cancelled, effects: effects, source: command.source, operation: command.operation))
            let service = f.service(apply: { _, _ in f.valid = false; return raw })
            try joined(await service.continueSearch(command), command, effects: effects, reason: .staleSource)
        }
        await run("joined acknowledgement retains real A effects after authority loss") {
            let f = AttributionFixture(), command = f.command(), r = f.reveal(command)
            let service = f.service(apply: { _, _ in f.valid = false; return .acknowledged(r) })
            try joined(await service.continueSearch(command), command, effects: r.effects, reason: .staleSource)
        }
        await run("joined acknowledgement retains real A effects after native layout refusal") {
            let f = AttributionFixture(), command = f.command(), r = f.reveal(command)
            let service = f.service(apply: { _, _ in .acknowledged(r) }, validate: { _, _ in throw ActionPortError.staleState })
            try joined(await service.continueSearch(command), command, effects: r.effects, reason: .staleSource)
        }
        await run("joined acknowledgement retains real A effects after deadline") {
            let f = AttributionFixture(), command = f.command(), r = f.reveal(command)
            let service = f.service(apply: { _, _ in f.now = 1000; return .acknowledged(r) })
            try joined(await service.continueSearch(command), command, effects: r.effects, reason: .deadlineExceeded)
        }
        await run("joined failure retains real A effects after task cancellation") {
            let f = AttributionFixture(), command = f.command(), effects: [ActionSearchContinuationEffect] = [.hitSelectionApplied(f.hit)]
            let raw = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .providerFailed, effects: effects, source: command.source, operation: command.operation))
            var suspended: CheckedContinuation<Void, Never>?
            let service = f.service(apply: { _, _ in
                await withCheckedContinuation { suspended = $0 }
                return raw
            })
            let task = Task { await service.continueSearch(command) }
            for _ in 0..<1000 where suspended == nil { await Task.yield() }
            guard let suspended else { task.cancel(); throw Failure.expected("fixture did not suspend") }
            task.cancel(); suspended.resume()
            try joined(await task.value, command, effects: effects, reason: .cancelled)
        }
        await run("pre-apply refusal explicitly binds current origin and never calls owner") {
            let f = AttributionFixture(), command = f.command(); f.valid = false
            let service = f.service(apply: { command, _ in f.calls += 1; return .acknowledged(f.reveal(command)) })
            try joined(await service.continueSearch(command), command, effects: [], reason: .staleSource)
            try require(f.calls == 0)
        }
        await run("exact joined empty terminal page still acknowledges") {
            let f = AttributionFixture(), command = f.command(.nextOriginalPage(token: f.pageToken))
            let raw = ActionSearchContinuationOutcome.acknowledged(f.page(command, count: 0, cursor: nil))
            let actual = await f.service(apply: { _, _ in raw }).continueSearch(command)
            try require(actual == raw)
        }

        let failed = rows.filter { $0["passed"] as? Bool == false }.count
        let result: [String: Any] = ["scope": "ACTUAL_REVISED_CONTRACT_SERVICE_WITH_FIXTURE_RESPONSES_ONLY",
            "appUI": "NOT_RUN", "passed": rows.count - failed, "failed": failed, "cases": rows,
            "pid": ProcessInfo.processInfo.processIdentifier]
        print(String(decoding: try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys]), as: UTF8.self))
        if failed != 0 { exit(1) }
    }
}
