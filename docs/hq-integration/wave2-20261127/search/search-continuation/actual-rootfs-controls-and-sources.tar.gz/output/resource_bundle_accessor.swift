import Foundation
extension Foundation.Bundle {
    static let module: Bundle = {
        guard let bundle = Bundle(path: "/tmp/otzaria-search-continuation-checks-c7f9cc7d8f1b41e68627c818389a4d42/output/OtzariaActionCore_OtzariaActionCore.resources") else { fatalError("missing original resources") }
        return bundle
    }()
}
