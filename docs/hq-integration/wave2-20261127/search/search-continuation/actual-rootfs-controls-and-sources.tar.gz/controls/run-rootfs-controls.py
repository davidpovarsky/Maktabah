#!/usr/bin/env python3
"""A separate, approved write domain. Never writes the Data filesystem."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

LIMIT = 40 * 1024 * 1024
FLOOR = 1024 * 1024 * 1024


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def allocation(root):
    total = 0
    for parent, directories, files in os.walk(root):
        for name in directories + files:
            path = Path(parent) / name
            info = path.lstat()
            if path.is_symlink():
                # Clang can create an owned cache lock symlink. It may resolve
                # only within this rootfs directory, never to the Data volume.
                if not path.resolve(strict=False).is_relative_to(root):
                    raise RuntimeError("owned output symlink escaped rootfs root")
            total += info.st_blocks * 512
    return total


def identity(pid):
    try:
        value = Path(f"/proc/{pid}/stat").read_text()
    except FileNotFoundError:
        return None
    tail = value[value.rfind(")") + 2:].split()
    return {"pid": pid, "parent": int(tail[1]), "group": int(tail[2]), "startTicks": int(tail[19])}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    args = parser.parse_args()
    root = args.root
    assert root == root.resolve() and root.is_dir() and root.stat().st_dev == 2049
    assert root.stat().st_uid == os.geteuid() == 1001 and root.stat().st_mode & 0o777 == 0o700
    assert Path.cwd() == root, "cwd must stay in owned rootfs directory"
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    inputs = json.loads((root / "INPUTS.json").read_text())
    for item in inputs["files"]:
        path = root / item["path"]
        assert path.is_file() and not path.is_symlink() and path.stat().st_dev == 2049
        assert path.stat().st_size == item["bytes"] and sha(path) == item["sha256"]
    tool = Path(inputs["compiler"])
    assert str(tool) == "/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc"
    tool_target = tool.resolve(strict=True)
    tool_receipt = {"argv0": str(tool), "resolved": str(tool_target), "sha256": sha(tool_target),
                    "bytes": tool_target.stat().st_size, "device": tool_target.stat().st_dev,
                    "inode": tool_target.stat().st_ino, "mtimeNs": tool_target.stat().st_mtime_ns}
    output, cache, tmp = root / "output", root / "module-cache", root / "tmp"
    for path in [output, cache, tmp]:
        path.mkdir(mode=0o700)
    env = dict(os.environ, TMPDIR=str(tmp), LC_ALL="C", TZ="UTC", GIT_OPTIONAL_LOCKS="0")
    phases = []
    max_owned = allocation(root)
    minimum_free = os.statvfs(root).f_bavail * os.statvfs(root).f_frsize
    write(root / "ADMISSION.json", {"scope": "ROOTFS_ONLY_COMPONENT_BUILD_NEW_WRITE_DOMAIN",
          "uid": os.geteuid(), "pid": os.getpid(), "root": str(root), "device": 2049,
          "dataWritesAllowed": False, "rootfsMinimumBytes": FLOOR, "ownedMaximumBytes": LIMIT,
          "initialRootfsFree": minimum_free, "initialOwnedBytes": max_owned,
          "tool": tool_receipt, "initialDataFreeDiagnosticOnly": os.statvfs("/mnt/development").f_bavail * os.statvfs("/mnt/development").f_frsize})

    def limits():
        nonlocal max_owned, minimum_free
        used = allocation(root)
        free = os.statvfs(root).f_bavail * os.statvfs(root).f_frsize
        max_owned = max(max_owned, used)
        minimum_free = min(minimum_free, free)
        if used > LIMIT or free < FLOOR:
            raise RuntimeError(f"rootfs resource gate: owned={used} free={free}")

    def run(name, argv, expected=0, timeout=150):
        limits()
        row = {"name": name, "argv": argv, "cwd": str(root), "startedUnix": time.time(),
               "expectedExit": expected, "startAttempted": True, "handleReturned": False,
               "ownedGroupAbsent": False}
        process = None
        owner = None
        phase_error = None
        stdout, stderr = root / (name + ".stdout"), root / (name + ".stderr")
        try:
            with stdout.open("xb") as out, stderr.open("xb") as err:
                process = subprocess.Popen(argv, cwd=root, env=env, stdout=out, stderr=err,
                                           start_new_session=True)
                row["handleReturned"] = True
                owner = identity(process.pid)
                assert owner is not None and owner["parent"] == os.getpid() and owner["group"] == process.pid
                row["identity"] = owner
                start = time.monotonic()
                while process.poll() is None:
                    limits()
                    if time.monotonic() - start > timeout:
                        raise TimeoutError(name)
                    time.sleep(0.1)
                row["exit"] = process.returncode
        except BaseException as error:
            phase_error = error
            row["error"] = repr(error)
        finally:
            if process is not None:
                if process.poll() is None:
                    current = identity(process.pid)
                    if owner is not None and current == owner:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            if process.poll() is None and identity(process.pid) == owner:
                                os.killpg(process.pid, signal.SIGKILL)
                                process.wait(timeout=3)
                    else:
                        row["cleanupOwnershipUnverified"] = True
                if process.poll() is not None:
                    try:
                        os.killpg(process.pid, 0)
                    except ProcessLookupError:
                        row["ownedGroupAbsent"] = True
                    row["exit"] = process.returncode
            row["finishedUnix"] = time.time()
            row["stdout"] = {"path": str(stdout), "bytes": stdout.stat().st_size, "sha256": sha(stdout)}
            row["stderr"] = {"path": str(stderr), "bytes": stderr.stat().st_size, "sha256": sha(stderr)}
            phases.append(row)
            write(root / (name + ".PHASE.json"), row)
        if phase_error is not None:
            raise phase_error
        assert row["ownedGroupAbsent"] and row["exit"] == expected, row
        limits()
        return stdout

    status = "FAILED"
    error = None
    try:
        run("compiler-version", [str(tool), "--version"], timeout=15)
        core = [root / item["path"] for item in inputs["files"] if item["role"] == "originalCore"]
        assert len(core) == 28
        resources = [item for item in inputs["files"] if item["role"] == "originalResource"]
        bundle = output / "OtzariaActionCore_OtzariaActionCore.resources"
        bundle.mkdir()
        for item in resources:
            destination = bundle / item["resourceRelative"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(root / item["path"], destination)
        accessor = output / "resource_bundle_accessor.swift"
        # The only build-generated interface is normal SwiftPM Bundle.module,
        # pointing at byte-identical original package resources in this root.
        accessor.write_text('import Foundation\nextension Foundation.Bundle {\n'
            + '    static let module: Bundle = {\n'
            + '        guard let bundle = Bundle(path: ' + json.dumps(str(bundle)) + ') else { fatalError("missing original resources") }\n'
            + '        return bundle\n    }()\n}\n')
        common = [str(tool), "-swift-version", "6", "-parse-as-library", "-module-cache-path", str(cache)]
        candidate = root / "candidate"
        contract = candidate / "Source/Otzaria/Actions/Sources/OtzariaActionCore/Contracts/ActionSearchContinuation.swift"
        service = candidate / "Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/NativeSearchContinuationService.swift"
        claim = candidate / "Source/ChavrusaText/SearchContinuation/OriginalSearchContinuationClaim.swift"
        run("compile-core", common + ["-emit-library", "-emit-module", "-enable-testing", "-module-name", "OtzariaActionCore",
            "-emit-module-path", str(output / "OtzariaActionCore.swiftmodule"), "-o", str(output / "libOtzariaActionCore.so")]
            + [str(p) for p in core] + [str(contract), str(accessor)])
        link = ["-I", str(output), "-L", str(output), "-Xlinker", "-rpath", "-Xlinker", str(output)]
        run("compile-focused-host-service", common + link + ["-lOtzariaActionCore", "-emit-library", "-emit-module",
            "-enable-testing", "-module-name", "ChavrusaUIRoutingHost", "-emit-module-path", str(output / "ChavrusaUIRoutingHost.swiftmodule"),
            "-o", str(output / "libChavrusaUIRoutingHost.so"), str(service)])
        controls = root / "controls/SearchContinuationControls.swift"
        executable = output / "search-continuation-controls"
        run("compile-portable-controls", common + link + ["-lOtzariaActionCore", "-lChavrusaUIRoutingHost",
            str(claim), str(controls), "-o", str(executable)])
        raw = run("portable-controls", [str(executable)], timeout=20)
        cases = json.loads(raw.read_text())
        assert cases["failed"] == 0 and cases["passed"] == 26 and len(cases["cases"]) == 26
        prepared = root / "cancellation-controls"
        run("prepare-cancellation", [sys.executable, str(root / "controls/prepare-cancellation-control.py"),
            "--baseline", str(root / "baseline/UnifiedSearchSessionController.swift"),
            "--candidate", str(candidate / "Source/ZayitSearch/UnifiedSearchSessionController.swift"), "--output", str(prepared)], timeout=15)
        for variant, expected_exit, expected_passed in [("baseline", 1, 3), ("candidate", 0, 8)]:
            binary = output / ("cancellation-" + variant)
            run("compile-cancellation-" + variant, common + [str(prepared / (variant + ".swift")), "-o", str(binary)])
            raw = run("cancellation-" + variant, [str(binary)], expected=expected_exit, timeout=15)
            result = json.loads(raw.read_text())
            assert result["passed"] == expected_passed and result["failed"] == 8 - expected_passed
        # Syntax parsing with the existing Linux frontend is not an Apple SDK
        # typecheck or App build. It visits the actual iOS conditional source.
        parse_inputs = [str(candidate / item["candidateRelative"]) for item in inputs["files"] if item["role"] == "candidate"]
        run("candidate-ios-syntax-only", [str(tool), "-frontend", "-parse", "-target", "arm64-apple-ios17.0-simulator"] + parse_inputs)
        status = "PORTABLE_COMPONENT_CONTROLS_PASSED_APP_NATIVE_NOT_RUN"
    except BaseException as caught:
        error = repr(caught)
    finally:
        artifacts = []
        for path in sorted(output.rglob("*")):
            if path.is_file():
                artifacts.append({"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)})
        write(root / "RESULT.json", {"status": status, "error": error, "scope": "ROOTFS_ONLY_PORTABLE_COMPONENTS",
            "fullActionCoreOriginalSwiftFiles": 28, "focusedHostModuleSwiftFiles": 1,
            "appSDKTypecheck": "NOT_RUN", "nativeUI": "NOT_RUN", "original68Suite": "NOT_RERUN",
            "writeDevice": 2049, "dataWrites": False, "ownedMaximumBytes": max_owned,
            "minimumRootfsFree": minimum_free, "tool": tool_receipt, "phases": phases,
            "artifacts": artifacts, "inputManifestSHA256": sha(root / "INPUTS.json")})
    return 0 if status == "PORTABLE_COMPONENT_CONTROLS_PASSED_APP_NATIVE_NOT_RUN" else 1


if __name__ == "__main__":
    sys.exit(main())
