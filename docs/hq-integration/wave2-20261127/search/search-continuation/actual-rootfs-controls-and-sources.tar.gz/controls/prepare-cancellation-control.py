#!/usr/bin/env python3
"""Compile boundaries are explicit; no app/UIKit/provider execution is claimed."""
import argparse
import hashlib
import json
from pathlib import Path


def whole_declaration(source: str, marker: str) -> str:
    assert source.count(marker) == 1, marker
    start = source.index(marker)
    first = source.index("{", start)
    depth = 1
    position = first + 1
    quoted = False
    escaped = False
    while depth:
        char = source[position]
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
        position += 1
    return source[start:position]


PRELUDE = '''import Foundation
import Glibc
@MainActor final class Leaf {
    var isSearching = false, isLoadingMore = false, isLoading = false, isLoadingMoreBackendResults = false
}
@MainActor final class ZayitOwner { let model = Leaf() }
@MainActor final class OriginalControllerGuardFixture {
    var isSearching = false, isLoadingMore = false, isSefaria = false, isPreparingZayitSearch = false
    enum Scope: Equatable { case advanced, zayit }
    var scope: Scope = .advanced
    let otzaria = Leaf(), zayitSession = ZayitOwner()
    var searchViewModel: Leaf? = Leaf()
    var cancellationRevision = 0, stopCalls = 0
    var results = [11, 12], errorMessage: String? = "previous"
    var hasMore = true, wasCancelled = false, resultsAreDirty = true, configurationInvalidated = false
    // Declared boundary: actual stopEngineWork/model cancellation is not executed.
    // The control exercises the verbatim caller guards against a leaf that has
    // synchronously started before the original queued Unified mirror updates.
    func stopEngineWork() { stopCalls += 1; isSearching = false; isLoadingMore = false }
'''
TAIL = '''
}
@main @MainActor struct GuardControl {
    static func main() throws {
        var rows: [[String: Any]] = []
        func record(_ name: String, _ body: (OriginalControllerGuardFixture) -> Bool) {
            rows.append(["name":name, "passed":body(OriginalControllerGuardFixture())])
        }
        record("Otzaria started before mirror cancellation") { f in
            f.otzaria.isLoadingMore = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled && f.results.isEmpty
        }
        record("Zayit started before mirror cancellation") { f in
            f.scope = .zayit; f.zayitSession.model.isLoadingMore = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled
        }
        record("Sefaria started before mirror cancellation") { f in
            f.isSefaria = true; f.searchViewModel!.isLoadingMoreBackendResults = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled
        }
        record("Zayit preparation before mirror cancellation") { f in
            f.scope = .zayit; f.isPreparingZayitSearch = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1
        }
        record("dirty input stops synchronous leaf before mirror") { f in
            f.otzaria.isSearching = true; f.configurationDidChange()
            return f.configurationInvalidated && f.stopCalls == 1
        }
        record("idle original guard remains a no-op") { f in
            f.cancelSearch(); return f.stopCalls == 0 && f.cancellationRevision == 0 && !f.wasCancelled
        }
        record("published loading cancellation remains original") { f in
            f.isLoadingMore = true; f.cancelSearch()
            return f.stopCalls == 1 && f.cancellationRevision == 1 && f.wasCancelled && !f.hasMore
        }
        record("clean configuration guard remains a no-op") { f in
            f.resultsAreDirty = false; f.otzaria.isSearching = true; f.configurationDidChange()
            return !f.configurationInvalidated && f.stopCalls == 0
        }
        let failures = rows.filter { $0["passed"] as? Bool == false }.count
        let result: [String: Any] = ["scope":"VERBATIM_CONTROLLER_GUARDS_WITH_DECLARED_LEAF_AND_STOP_STUBS",
            "appUI":"NOT_RUN", "rows":rows,"passed":rows.count-failures,"failed":failures]
        print(String(decoding: try JSONSerialization.data(withJSONObject:result, options:[.prettyPrinted,.sortedKeys]), as:UTF8.self))
        if failures != 0 { exit(1) }
    }
}
'''


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", required=True, type=Path)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), "unique output required"
    args.output.mkdir(parents=True)
    candidates = args.candidate.read_text()
    getter = whole_declaration(candidates, "    private var originalBackendIsBusy: Bool {")
    manifest = {"scope": "EXPLICIT_COMPONENT_BOUNDARY_NOT_APP_BUILD", "variants": {}}
    for variant, path in [("baseline", args.baseline), ("candidate", args.candidate)]:
        data = path.read_bytes()
        source = data.decode()
        declarations = [whole_declaration(source, "    func cancelSearch() {"),
                        whole_declaration(source, "    func configurationDidChange() {")]
        # The candidate getter is a declared leaf-state interface for both
        # harnesses; the unchanged baseline guards never call it.
        text = PRELUDE + "\n".join(declarations + [getter]) + TAIL
        output = args.output / (variant + ".swift")
        output.write_text(text)
        manifest["variants"][variant] = {
            "sourcePath": str(path), "sourceBytes": len(data), "sourceSHA256": hashlib.sha256(data).hexdigest(),
            "verbatimDeclarations": [{"marker": d.splitlines()[0], "bytes": len(d.encode()),
                                       "sha256": hashlib.sha256(d.encode()).hexdigest()} for d in declarations],
            "getterOrigin": "candidate", "getterSHA256": hashlib.sha256(getter.encode()).hexdigest(),
            "compiledFixturePath": str(output), "compiledFixtureSHA256": hashlib.sha256(output.read_bytes()).hexdigest(),
        }
    (args.output / "SOURCE_BOUNDARY.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
