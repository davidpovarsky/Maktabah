from pathlib import Path
import subprocess,json,hashlib,time,datetime,sys,re
p=Path(__file__).resolve().parent
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
r={'schema':'otzaria.independent-foundation-probe-build/1','scope':'compile only; no transport requests, Simulator, PF or launchd operation','source':{'path':str(p/'OfflineTransportProbe.swift'),'bytes':(p/'OfflineTransportProbe.swift').stat().st_size,'sha256':sha(p/'OfflineTransportProbe.swift')},'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'builds':[]}
for kind,sdk,target in [('host','macosx','arm64-apple-macosx27.0'),('simulator','iphonesimulator','arm64-apple-ios27.0-simulator')]:
 sdkpath=subprocess.check_output(['xcrun','--sdk',sdk,'--show-sdk-path'],text=True).strip()
 ver=subprocess.check_output(['xcrun','--sdk',sdk,'--show-sdk-version'],text=True).strip()
 assert ver.split('.')[0]=='27'
 command=['xcrun','--sdk',sdk,'swiftc','-parse-as-library','-swift-version','6','-strict-concurrency=complete','-sdk',sdkpath,'-target',target,'-module-cache-path','/Users/m1/builds/otzaria-wave2-search-20261127/post-update-ui-typecheck/module-cache',str(p/'OfflineTransportProbe.swift'),'-o',str(p/('probe-'+kind))]
 started=time.monotonic();result=subprocess.run(command,capture_output=True,timeout=60)
 (p/(kind+'.stdout.log')).write_bytes(result.stdout);(p/(kind+'.stderr.log')).write_bytes(result.stderr)
 row={'kind':kind,'command':command,'sdkPath':sdkpath,'sdkVersion':ver,'exit':result.returncode,'seconds':time.monotonic()-started,'stdoutSHA256':hashlib.sha256(result.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(result.stderr).hexdigest()}
 if result.returncode==0:
  b=p/('probe-'+kind);row['binary']={'path':str(b),'bytes':b.stat().st_size,'sha256':sha(b)}
  v=subprocess.run(['/usr/bin/codesign','--verify','--strict',str(b)],capture_output=True,text=True,timeout=5);row['codeSignVerify']={'exit':v.returncode,'stdout':v.stdout,'stderr':v.stderr}
 if result.returncode==0:
  platform_run=subprocess.run(['xcrun','vtool','-show-build',str(p/('probe-'+kind))],capture_output=True,text=True,timeout=5)
  row['actualMachOBuildVersion']={'exit':platform_run.returncode,'stdout':platform_run.stdout,'stderr':platform_run.stderr}
  matches=re.findall(r'(?m)^\\s*platform\\s+(\\w+)\\s*
 (p/'BUILD.json').write_text(json.dumps(r,indent=2)+'\n')
 if result.returncode!=0:break
r['status']='COMPILED_ONLY_NO_NETWORK_OR_NATIVE_UI' if len(r['builds'])==2 and all(x['exit']==0 and x['codeSignVerify']['exit']==0 and x['actualPlatform']==('MACOS' if x['kind']=='host' else 'IOSSIMULATOR') for x in r['builds']) else 'COMPILE_FAILED'
r['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p/'BUILD.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
,platform_run.stdout)
  row['actualPlatform']=matches[0] if platform_run.returncode==0 and len(matches)==1 else None
 r['builds'].append(row)
 (p/'BUILD.json').write_text(json.dumps(r,indent=2)+'\n')
 if result.returncode!=0:break
r['status']='COMPILED_ONLY_NO_NETWORK_OR_NATIVE_UI' if len(r['builds'])==2 and all(x['exit']==0 and x['codeSignVerify']['exit']==0 for x in r['builds']) else 'COMPILE_FAILED'
r['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p/'BUILD.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
