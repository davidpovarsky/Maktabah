import XCTest
import CryptoKit
import SQLite3
import Darwin
private enum SearchDataNativeFixtureError: Error { case rejected(String) }

private func requireSearchDataFixture(_ condition: Bool, _ reason: String) throws {
    guard condition else {
        XCTFail(reason)
        throw SearchDataNativeFixtureError.rejected(reason)
    }
}

private func searchDataFileBytes(_ url: URL, maximum: Int = 128 * 1024 * 1024) throws -> Data {
    let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
    try requireSearchDataFixture(values.isRegularFile == true && values.isSymbolicLink == false,
                                 "The owned fixture file must be regular and must not be a symbolic link")
    try requireSearchDataFixture((values.fileSize ?? maximum + 1) <= maximum, "Bound the miniature fixture read")
    return try Data(contentsOf: url)
}

private func searchDataDigest(_ data: Data) -> String {
    SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
}

final class PublishedProductionSearchDataTests: MaktabahUITestBase {
    private let traceNamespace = UUID().uuidString
    private let v40Digest = "8389709c1702753af6f0719ef1c98c09854450e48ebb05fe1f95486b26348b01"
    private let otzariaArtifact = "f8fea8efcac5fc06b272a061b44f0e0ee66d16ae12f1e864f9510e437e929139"
    private let zayitArtifact = "17cabb80e86ac8c2d1a3ce16a4e1457d4351709798f2b91a84120d4dd0c6c480"

    private struct Installation {
        let container: URL
        let root: URL
        let owner: URL
        let ownerBytes: Data
        let manifestBytes: Data
        var database: URL { root.appendingPathComponent("Otzaria/seforim.db") }
        var manifest: URL { root.appendingPathComponent("Otzaria/seforim-installation.json") }
        var otzariaManifest: URL {
            root.appendingPathComponent("Otzaria/TantivySearchIndex/managed-library/otzaria_prebuilt_installation.json")
        }
        var zayitManifest: URL { root.appendingPathComponent("Otzaria/Zayit/zayit-installation.json") }
    }

    private func bytes(_ url: URL, maximum: Int = 1024 * 1024) throws -> Data {
        let info = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        try requireSearchDataFixture(info.isRegularFile == true && info.isSymbolicLink == false
            && url.standardizedFileURL.path == url.resolvingSymlinksInPath().path
            && (info.fileSize ?? maximum + 1) <= maximum, "Require a bounded, regular original file: \(url.lastPathComponent)")
        return try Data(contentsOf: url)
    }

    private func object(_ url: URL) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: bytes(url)) as? [String: Any])
    }

    private func databaseDigest(_ url: URL) throws -> String {
        let info = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        try requireSearchDataFixture(info.isRegularFile == true && info.isSymbolicLink == false
            && info.fileSize == 4_355_063_808
            && url.standardizedFileURL.path == url.resolvingSymlinksInPath().path,
            "Only the exact installed production v40 database is eligible")
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var digest = SHA256()
        var count: Int64 = 0
        while let block = try handle.read(upToCount: 4 * 1024 * 1024), !block.isEmpty {
            digest.update(data: block)
            count += Int64(block.count)
            try requireSearchDataFixture(count <= 4_355_063_808, "The database cannot grow during observation")
        }
        XCTAssertEqual(count, 4_355_063_808)
        return digest.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private func installation() throws -> Installation {
        let supplied = try XCTUnwrap(ProcessInfo.processInfo.environment["PRODUCTION_SEARCH_CONTAINER_PARENT"],
            "Runner must supply this owned Simulator's Containers/Data/Application directory")
        let parent = URL(fileURLWithPath: supplied, isDirectory: true).standardizedFileURL
        let simulatorData = parent.deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
        let udid = try XCTUnwrap(ProcessInfo.processInfo.environment["SIMULATOR_UDID"])
        try requireSearchDataFixture(UUID(uuidString: udid) != nil
            && simulatorData.lastPathComponent == "data"
            && simulatorData.deletingLastPathComponent().lastPathComponent.lowercased() == udid.lowercased()
            && Array(parent.pathComponents.suffix(3)) == ["Containers", "Data", "Application"],
            "Never inspect another Simulator or an external corpus")
        func owners(_ parent: URL, identifier: String) throws -> [(URL, URL, Data)] {
            let children = (try? FileManager.default.contentsOfDirectory(at: parent,
                includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])) ?? []
            try requireSearchDataFixture(children.count <= 256, "Bound original container discovery")
            return try children.compactMap { child in
                let info = try child.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                guard info.isDirectory == true, info.isSymbolicLink == false,
                      UUID(uuidString: child.lastPathComponent) != nil else { return nil }
                let metadata = child.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")
                guard let data = try? bytes(metadata, maximum: 65536),
                      let value = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
                      value["MCMMetadataIdentifier"] as? String == identifier else { return nil }
                return (child, metadata, data)
            }
        }
        let apps = try owners(parent, identifier: "com.davidpovarsky.chavrusatext")
        try requireSearchDataFixture(apps.count == 1, "Require exactly one original app installation")
        let appOwner = try XCTUnwrap(apps.first)
        let groups = try owners(simulatorData.appendingPathComponent("Containers/Shared/AppGroup"),
                                identifier: "group.com.davidpovarsky.itorah")
        try requireSearchDataFixture(groups.count <= 1, "Ambiguous App Group ownership is a failure")
        let owner = groups.first ?? (appOwner.0.appendingPathComponent("Library/Application Support/Maktabah-Debug"),
                                     appOwner.1, appOwner.2)
        let root = owner.0.standardizedFileURL
        try requireSearchDataFixture(root.pathComponents.starts(with: simulatorData.pathComponents)
            && root.path == root.resolvingSymlinksInPath().path, "Storage must remain inside this exact installation")
        let manifest = root.appendingPathComponent("Otzaria/seforim-installation.json")
        let record = try object(manifest)
        XCTAssertEqual(record["profileID"] as? String ?? "production", "production")
        XCTAssertEqual(record["releaseTag"] as? String, "v40-20261123094345")
        XCTAssertEqual((record["releaseID"] as? NSNumber)?.int64Value, 455_390_662)
        XCTAssertEqual((record["databaseFileSize"] as? NSNumber)?.int64Value, 4_355_063_808)
        return Installation(container: appOwner.0, root: root, owner: owner.1,
                            ownerBytes: owner.2, manifestBytes: try bytes(manifest))
    }

    private func verifyUnchanged(_ value: Installation, hashDatabase: Bool = true) throws {
        XCTAssertEqual(try bytes(value.owner, maximum: 65536), value.ownerBytes, "Retain original storage ownership")
        XCTAssertEqual(try bytes(value.manifest), value.manifestBytes, "Index operations must preserve the installed v40 manifest")
        if hashDatabase { XCTAssertEqual(try databaseDigest(value.database), v40Digest) }
    }

    private func verifyPackages(_ value: Installation) throws {
        let otzaria = try object(value.otzariaManifest)
        let zayit = try object(value.zayitManifest)
        XCTAssertEqual(otzaria["artifactIdentity"] as? String, otzariaArtifact)
        XCTAssertEqual(zayit["artifactIdentity"] as? String, zayitArtifact)
        for manifest in [otzaria, zayit] {
            XCTAssertEqual(manifest["profileID"] as? String ?? "production", "production")
        }
        let source = try XCTUnwrap(otzaria["sourceDatabase"] as? [String: Any])
        XCTAssertEqual(source["releaseTag"] as? String, "v40-20261123094345")
        XCTAssertEqual(source["databaseSHA256"] as? String, v40Digest)
        XCTAssertEqual((source["bookCount"] as? NSNumber)?.intValue, 8259)
        XCTAssertEqual((source["documentCount"] as? NSNumber)?.intValue, 7_925_185)
        let lexical = try XCTUnwrap(otzaria["lexicalArtifact"] as? [String: Any])
        XCTAssertEqual((lexical["documentCount"] as? NSNumber)?.intValue, 7_925_185)
        XCTAssertEqual((lexical["parts"] as? [Any])?.count, 15)
        let required = try XCTUnwrap(zayit["requiredDatabase"] as? [String: Any])
        XCTAssertEqual(required["releaseTag"] as? String, "v40-20261123094345")
        XCTAssertEqual(required["canonicalSHA256"] as? String, v40Digest)
        let counts = try XCTUnwrap(zayit["counts"] as? [String: Any])
        XCTAssertEqual((counts["books"] as? NSNumber)?.intValue, 8259)
        XCTAssertEqual((counts["lines"] as? NSNumber)?.intValue, 7_920_224)
        XCTAssertEqual((counts["documents"] as? NSNumber)?.intValue, 7_930_286)
        XCTAssertEqual((zayit["parts"] as? [Any])?.count, 74)
        for (name, path) in [("otzaria", value.otzariaManifest), ("zayit", value.zayitManifest)] {
            let attachment = XCTAttachment(data: try bytes(path), uniformTypeIdentifier: "public.json")
            attachment.name = "published-v40-" + name + "-actual-installed-manifest"
            attachment.lifetime = .keepAlways
            add(attachment)
        }
    }

    @MainActor
    private func control(_ id: String) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: id).firstMatch
    }

    @MainActor
    @discardableResult
    private func required(_ id: String, timeout: TimeInterval = 30) throws -> XCUIElement {
        let value = control(id)
        try requireSearchDataFixture(value.waitForExistence(timeout: timeout), "Original UI control is absent: " + id)
        return value
    }

    @MainActor
    private func eventually(_ reason: String, timeout: TimeInterval = 90,
                            _ condition: @escaping @MainActor () -> Bool) {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            MainActor.assumeIsolated { condition() }
        }, object: nil)
        XCTAssertEqual(XCTWaiter.wait(for: [expectation], timeout: timeout), .completed, reason)
    }

    @MainActor
    private func capture(_ name: String) {
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = name
        screenshot.lifetime = .keepAlways
        add(screenshot)
        let tree = XCTAttachment(string: app.debugDescription)
        tree.name = name + "-hierarchy"
        tree.lifetime = .keepAlways
        add(tree)
    }

    @MainActor
    private func launchProduction(unitMode: String? = "line") throws {
        for key in ["OTZARIA_SHARED_ROOT_OVERRIDE", "OTZARIA_PRODUCTION_DB_PATH"] {
            try requireSearchDataFixture(ProcessInfo.processInfo.environment[key] == nil,
                "Real managed installation acceptance forbids external storage override " + key)
        }
        XCUIDevice.shared.orientation = .landscapeLeft
        let unitArguments = unitMode.map { ["-otzaria_reader_unit_mode", $0] } ?? []
        launchWithTier(.production, backend: "otzaria", extraArgs: [
            "-GlobalSearchNativeTraceEnabled", "YES", "-GlobalSearchNativeTraceNamespace", traceNamespace,
            "-lastSelectedTab", "0", "-ChavrusaTextFaithfulReaderUIEnabled", "YES"
        ] + unitArguments)
        XCTAssertFalse(app.launchArguments.contains("-smokeBypassBootstrap"))
        XCTAssertFalse(app.launchArguments.contains("-studyWorkspaceTestingNamespace"))
        XCTAssertEqual(app.launchEnvironment["OTZARIA_DATA_PROFILE"], "production")
        let tab = findTabButton(hebrew: "חיפוש", english: "Search")
        try requireSearchDataFixture(tab.waitForExistence(timeout: 120), "Normal production bootstrap must expose Search")
        tab.tap()
        try required("global-search-screen", timeout: 60)
        try required("global-search-query")
    }

    @MainActor
    private func openData() throws {
        try required("global-search-more").tap()
        try required("global-search-data").tap()
        try required("search-data-otzaria-status")
        try required("search-data-zayit-status")
    }

    @MainActor
    private func reachDataAction(_ id: String) throws -> XCUIElement {
        for _ in 0..<8 {
            let value = control(id)
            if value.exists && value.isHittable { return value }
            try required("search-data-screen").swipeUp()
        }
        throw SearchDataNativeFixtureError.rejected("Original action is not reachable: " + id)
    }

    @MainActor
    private func assertReady() {
        eventually("The original UI must recognize both actual installed v40 packages", timeout: 180) {
            self.app.staticTexts["search-data-otzaria-status"].label == "האינדקס מוכן (7925185 מסמכים)"
                && self.app.staticTexts["search-data-zayit-status"].label.hasPrefix("מוכן · ")
        }
    }

    @MainActor
    func testPublishedV40PackagesInstallThroughOriginalSearchDataAndColdReopen() throws {
        try launchProduction()
        let value = try installation()
        try verifyUnchanged(value)
        XCTAssertFalse(FileManager.default.fileExists(atPath: value.otzariaManifest.path),
                       "An existing index cannot be credited as a new UI installation")
        XCTAssertFalse(FileManager.default.fileExists(atPath: value.zayitManifest.path),
                       "An existing Zayit installation cannot be credited as a new UI installation")
        try openData()
        XCTAssertNotEqual(try required("search-data-otzaria-status").label, "האינדקס מוכן (7925185 מסמכים)")
        capture("published-v40-before-original-install")
        try reachDataAction("search-data-install-missing").tap()
        eventually("The original sequential installer must download, validate and activate both published packages",
                   timeout: 5400) {
            let message = self.app.staticTexts["search-data-install-message"]
            return message.exists && message.label == "כל הרכיבים שנבחרו מוכנים."
        }
        try verifyPackages(value)
        try verifyUnchanged(value)
        try required("search-data-screen").swipeDown()
        assertReady()
        capture("published-v40-original-install-ready")
        app.terminate()
        XCTAssertEqual(app.state, .notRunning)
        try launchProduction()
        let reopened = try installation()
        XCTAssertEqual(reopened.root, value.root)
        XCTAssertEqual(reopened.container, value.container)
        try verifyUnchanged(value, hashDatabase: false)
        try verifyPackages(reopened)
        try openData()
        assertReady()
        capture("published-v40-cold-reopen-ready")
    }

    private func events(_ value: Installation) throws -> [[String: Any]] {
        let url = value.container.appendingPathComponent("Documents/OtzariaLogs/search-native-" + traceNamespace + ".jsonl")
        let data = try bytes(url, maximum: 8 * 1024 * 1024)
        let text = try XCTUnwrap(String(data: data, encoding: .utf8))
        return try text.split(separator: "\n").map {
            try XCTUnwrap(JSONSerialization.jsonObject(with: Data($0.utf8)) as? [String: Any])
        }
    }

    private func canonical(_ object: Any) throws -> Data {
        try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
    }

    /// Reads the exact installed production database with SQLite's read-only flag.
    /// Only the test owns this connection; it cannot write or supply app results.
    private func sqlLine(database: OpaquePointer, book: Int, line: Int) throws -> [String: Any] {
        var statement: OpaquePointer?
        let query = "SELECT l.id, l.bookId, l.lineIndex, b.title, COALESCE(l.heRef, '') FROM line l JOIN book b ON b.id=l.bookId WHERE l.bookId=? AND l.lineIndex=?"
        XCTAssertEqual(sqlite3_prepare_v2(database, query, -1, &statement, nil), SQLITE_OK)
        let statementValue = try XCTUnwrap(statement)
        defer { sqlite3_finalize(statementValue) }
        XCTAssertEqual(sqlite3_bind_int64(statementValue, 1, Int64(book)), SQLITE_OK)
        XCTAssertEqual(sqlite3_bind_int64(statementValue, 2, Int64(line)), SQLITE_OK)
        XCTAssertEqual(sqlite3_step(statementValue), SQLITE_ROW, "Every result must address an actual SQL line")
        let title = try XCTUnwrap(sqlite3_column_text(statementValue, 3))
        let reference = try XCTUnwrap(sqlite3_column_text(statementValue, 4))
        let row: [String: Any] = [
            "lineID": sqlite3_column_int64(statementValue, 0),
            "bookID": sqlite3_column_int64(statementValue, 1),
            "lineIndex": sqlite3_column_int64(statementValue, 2),
            "bookTitle": String(cString: title), "reference": String(cString: reference)
        ]
        XCTAssertEqual(sqlite3_step(statementValue), SQLITE_DONE, "SQL position must be unambiguous")
        return row
    }

    @MainActor
    private func chooseEngine(_ engine: String) throws {
        try required("global-search-mode").tap()
        try required("global-search-mode-" + (engine == "zayit" ? "zayit" : "advanced")).tap()
        if engine == "zayit" {
            try required("global-search-options").tap()
            let picker = try required("global-search-zayit-match")
            for _ in 0..<6 {
                if picker.isHittable { break }
                try required("global-search-options-content").swipeUp()
            }
            picker.tap()
            let flexible = app.buttons["גמיש — מרחק 5 מילים"]
            XCTAssertTrue(flexible.waitForExistence(timeout: 20))
            flexible.tap()
            try required("global-search-options-done").tap()
        }
    }

    @MainActor
    private func loadedCount(filtered: Bool) throws -> Int {
        let label = try required("global-search-count").label
        let numbers = label.split { !$0.isNumber }.compactMap { Int($0) }
        if filtered {
            XCTAssertGreaterThanOrEqual(numbers.count, 2)
            XCTAssertEqual(numbers.first, 0)
            return try XCTUnwrap(numbers.dropFirst().first)
        }
        return try XCTUnwrap(numbers.first)
    }

    @MainActor
    private func assertPublishedPages(engine: String, pages: Int, pageSize: Int) throws {
        try launchProduction()
        let value = try installation()
        try verifyUnchanged(value)
        try verifyPackages(value)
        try chooseEngine(engine)
        let field = try required("global-search-query")
        field.tap()
        if let previous = field.value as? String, !previous.isEmpty && previous != field.placeholderValue {
            field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: previous.count))
        }
        field.typeText("בראשית")
        eventually("Original native field must contain the whole submitted query") { field.value as? String == "בראשית" }
        field.typeText("\n")
        let first = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "search-result-preview-toggle-")).firstMatch
        XCTAssertTrue(first.waitForExistence(timeout: 180))
        XCTAssertEqual(try loadedCount(filtered: false), pageSize,
                       "The first visible count must represent the actual first page")
        capture("published-v40-" + engine + "-page-" + String(pageSize))
        try required("global-search-result-filter-toggle").tap()
        let filter = try required("global-search-result-filter")
        let token = "no-production-book-" + UUID().uuidString
        filter.tap()
        filter.typeText(token + "\n")
        try required("global-search-filter-empty")
        XCTAssertEqual(try loadedCount(filtered: true), pageSize)
        for page in 2...pages {
            let more = app.buttons.matching(NSPredicate(format: "label == %@", "Load more results")).firstMatch
            XCTAssertTrue(more.waitForExistence(timeout: 30))
            XCTAssertTrue(more.isHittable)
            more.tap()
            eventually("Original native loaded count must advance to \(page * pageSize)", timeout: 180) {
                (try? self.loadedCount(filtered: true)) == page * pageSize
                    && !self.control("global-search-page-error").exists
                    && !self.control("global-search-cancel").exists
            }
            capture("published-v40-" + engine + "-page-" + String(page * pageSize))
        }
        eventually("Published original model must settle at the visible native count") {
            guard let event = try? self.events(value).last(where: {
                $0["event"] as? String == "published" && $0["engine"] as? String == engine
            }), let items = event["items"] as? [Any] else { return false }
            return items.count == pages * pageSize
        }
        let observed = try events(value).filter { $0["engine"] as? String == engine }
        XCTAssertEqual(Set(observed.compactMap { $0["sessionID"] as? String }).count, 1)
        XCTAssertEqual(Set(observed.compactMap { ($0["processID"] as? NSNumber)?.intValue }).count, 1)
        let provider = observed.filter { $0["event"] as? String == "provider" }
        XCTAssertEqual(provider.count, pages)
        var database: OpaquePointer?
        XCTAssertEqual(sqlite3_open_v2(value.database.path, &database, SQLITE_OPEN_READONLY | SQLITE_OPEN_NOMUTEX, nil), SQLITE_OK)
        let db = try XCTUnwrap(database)
        defer { sqlite3_close(db) }
        var order: [String] = []
        var source: [String: [String: Any]] = [:]
        var sql: [String: [String: Any]] = [:]
        var retainedItems: [String: [String: Any]] = [:]
        for (index, event) in provider.enumerated() {
            XCTAssertEqual(event["namespace"] as? String, traceNamespace)
            XCTAssertEqual(event["profileID"] as? String, "production")
            XCTAssertEqual((event["submissionRevision"] as? NSNumber)?.intValue, 1)
            let request = try XCTUnwrap(event["request"] as? [String: Any])
            XCTAssertEqual(request["querySHA256"] as? String, searchDataDigest(Data("בראשית".utf8)))
            XCTAssertNil(request["query"])
            XCTAssertEqual((request["offset"] as? NSNumber)?.intValue, index * pageSize)
            XCTAssertEqual((request["limit"] as? NSNumber)?.intValue, pageSize)
            let page = try XCTUnwrap(event["page"] as? [String: Any])
            let rows = try XCTUnwrap(page[engine == "zayit" ? "hits" : "results"] as? [[String: Any]])
            XCTAssertEqual(rows.count, pageSize)
            for row in rows {
                let book: Int
                let line: Int
                let id: String
                if engine == "zayit" {
                    book = try XCTUnwrap((row["book_id"] as? NSNumber)?.intValue)
                    line = try XCTUnwrap((row["line_index"] as? NSNumber)?.intValue)
                    id = "zayit:production:\(try XCTUnwrap((row["line_id"] as? NSNumber)?.intValue))"
                } else {
                    let path = try XCTUnwrap(row["filePath"] as? String)
                    XCTAssertTrue(path.hasPrefix("otzaria-book:"))
                    book = try XCTUnwrap(Int(path.dropFirst("otzaria-book:".count)))
                    line = try XCTUnwrap((row["segment"] as? NSNumber)?.intValue)
                    id = "otzaria:\(path):\(try XCTUnwrap((row["id"] as? NSNumber)?.uint64Value)):\(line)"
                }
                let original = try sqlLine(database: db, book: book, line: line)
                XCTAssertEqual(row[engine == "zayit" ? "book_title" : "title"] as? String, original["bookTitle"] as? String)
                if engine == "zayit" {
                    XCTAssertEqual((row["line_id"] as? NSNumber)?.int64Value, (original["lineID"] as? NSNumber)?.int64Value)
                }
                XCTAssertEqual(row["reference"] as? String ?? "", original["reference"] as? String ?? "")
                XCTAssertNil(source[id], "The first real pages must retain unique original identities")
                order.append(id)
                source[id] = row
                sql[id] = original
            }
            XCTAssertEqual((event["nextOffset"] as? NSNumber)?.intValue, (index + 1) * pageSize)
            if engine == "zayit" {
                let accumulated = try XCTUnwrap(event["accumulatedSource"] as? [[String: Any]])
                XCTAssertEqual(accumulated.count, order.count)
                for (id, row) in zip(order, accumulated) {
                    XCTAssertEqual(try canonical(try XCTUnwrap(source[id])), try canonical(row))
                }
            } else {
                let records = try XCTUnwrap(event["retainedRecords"] as? [[String: Any]])
                XCTAssertEqual(records.count, order.count)
                for (id, record) in zip(order, records) {
                    XCTAssertEqual(try canonical(try XCTUnwrap(source[id])), try canonical(try XCTUnwrap(record["metadata"])))
                    let item = try XCTUnwrap(record["item"] as? [String: Any])
                    if let prior = retainedItems[id] { XCTAssertEqual(try canonical(item), try canonical(prior)) }
                    retainedItems[id] = item
                }
            }
        }
        let publication = try XCTUnwrap(observed.last { $0["event"] as? String == "published" })
        let items = try XCTUnwrap(publication["items"] as? [[String: Any]])
        XCTAssertEqual(items.compactMap { $0["id"] as? String }, order)
        XCTAssertEqual(Set(order).count, pages * pageSize)
        for item in items {
            let id = try XCTUnwrap(item["id"] as? String)
            let original = try XCTUnwrap(sql[id])
            let raw = try XCTUnwrap(source[id])
            let book = try XCTUnwrap((original["bookID"] as? NSNumber)?.intValue)
            let line = try XCTUnwrap((original["lineIndex"] as? NSNumber)?.intValue)
            XCTAssertEqual((item["bookID"] as? NSNumber)?.intValue, book)
            XCTAssertEqual((item["lineIndex"] as? NSNumber)?.intValue, line)
            XCTAssertEqual(item["bookTitle"] as? String, original["bookTitle"] as? String)
            XCTAssertEqual(item["reference"] as? String, raw["reference"] as? String ?? "")
            XCTAssertEqual(item["locator"] as? String, "otzaria|book:\(book)|line:\(line)")
            if engine == "zayit" {
                XCTAssertEqual(item["highlightTerms"] as? [String], raw["matched_terms"] as? [String])
            } else {
                XCTAssertEqual(try canonical(item), try canonical(try XCTUnwrap(retainedItems[id])))
            }
        }
        let evidence = XCTAttachment(data: try canonical(["events": observed, "independentSQL": sql]),
                                     uniformTypeIdentifier: "public.json")
        evidence.name = "published-v40-" + engine + "-original-pages-and-independent-sql"
        evidence.lifetime = .keepAlways
        add(evidence)
        XCTAssertEqual(field.value as? String, "בראשית")
        XCTAssertFalse(control("global-search-dirty").exists)
        XCTAssertFalse(control("global-search-page-error").exists)
        try required("global-search-result-filter-done").tap()
        XCTAssertEqual(try loadedCount(filtered: false), pages * pageSize)
        try verifyUnchanged(value, hashDatabase: false)
    }

    @MainActor
    func testPublishedV40ZayitPages50_100_150RetainSQLIdentity() throws {
        try assertPublishedPages(engine: "zayit", pages: 3, pageSize: 50)
    }

    @MainActor
    func testPublishedV40OtzariaPagesRetainCumulativeSQLMetadata() throws {
        try assertPublishedPages(engine: "otzaria", pages: 2, pageSize: 100)
    }
}


// Full text assertions use source-qualified hashes for each complete native Text.
// A provider receipt alone never counts as a visible full-context acceptance.
struct SearchContextExpectedSegment: Decodable {
    let locator: String
    let sourceSHA256: String
    let translationSHA256: String?
    let sourceUTF8Bytes: Int
    let translationUTF8Bytes: Int?
}

private struct SefariaContextSourceReceipt: Decodable {
    struct Section: Decodable {
        let versionTitle: String
        let language: String
        let reference: String
        let stableID: String
        let segments: [SearchContextExpectedSegment]
    }
    struct Page: Decodable {
        struct Row: Decodable {
            let offset: Int
            let ref: String
            let versionTitle: String
            let language: String
        }
        let offset: Int
        let rows: [Row]
    }
    let schema: Int
    let status: String
    let uiExecuted: Bool
    let query: String
    let filters: [String]
    let limit: Int
    let sortOrder: String
    let targetRef: String
    let pages: [Page]
    let sections: [Section]
}

func originalSearchOracleBytes(pathKey: String, digestKey: String) throws -> Data {
    let environment = ProcessInfo.processInfo.environment
    let supplied = try XCTUnwrap(environment[pathKey], "Runner must supply the qualified source oracle " + pathKey)
    let digest = try XCTUnwrap(environment[digestKey], "Runner must seal the exact oracle bytes")
    let url = URL(fileURLWithPath: supplied).standardizedFileURL
    let info = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
    try requireSearchDataFixture(info.isRegularFile == true && info.isSymbolicLink == false
        && url.path == url.resolvingSymlinksInPath().path
        && (info.fileSize ?? 2_000_001) <= 2_000_000 && digest.count == 64,
        "Only a bounded, regular, byte-sealed source oracle is eligible")
    let bytes = try Data(contentsOf: url)
    let actual = SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
    try requireSearchDataFixture(actual == digest, "Reject changed or different-source acceptance inputs")
    return bytes
}

@MainActor
struct OriginalSearchContextUI {
    let app: XCUIApplication
    let test: XCTestCase

    func control(_ id: String) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: id).firstMatch
    }

    @discardableResult
    func require(_ id: String, timeout: TimeInterval = 30) throws -> XCUIElement {
        let value = control(id)
        try requireSearchDataFixture(value.waitForExistence(timeout: timeout), "Original control absent: " + id)
        return value
    }

    func wait(_ reason: String, timeout: TimeInterval = 60,
              _ condition: @escaping @MainActor () -> Bool) throws {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            MainActor.assumeIsolated { condition() }
        }, object: nil)
        try requireSearchDataFixture(XCTWaiter.wait(for: [expectation], timeout: timeout) == .completed, reason)
    }

    func capture(_ name: String) {
        let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screen.name = name; screen.lifetime = .keepAlways; test.add(screen)
        let tree = XCTAttachment(string: app.debugDescription)
        tree.name = name + "-hierarchy"; tree.lifetime = .keepAlways; test.add(tree)
    }

    func dragVisible(_ element: XCUIElement, up: Bool) throws {
        let rect = element.frame.intersection(app.frame)
        try requireSearchDataFixture(rect.width > 40 && rect.height > 100, "The original scroll owner must have a visible viewport")
        let origin = app.coordinate(withNormalizedOffset: CGVector(dx: 0, dy: 0))
        let x = rect.midX - app.frame.minX
        let high = rect.minY + rect.height * 0.22 - app.frame.minY
        let low = rect.minY + rect.height * 0.78 - app.frame.minY
        let start = origin.withOffset(CGVector(dx: x, dy: up ? low : high))
        let end = origin.withOffset(CGVector(dx: x, dy: up ? high : low))
        start.press(forDuration: 0.05, thenDragTo: end)
    }

    func reach(_ id: String, maximumSwipes: Int = 50) throws -> XCUIElement {
        for _ in 0...maximumSwipes {
            let value = control(id)
            if value.exists && value.isHittable && value.frame.intersects(app.frame) { return value }
            try dragVisible(require("global-search-results"), up: true)
        }
        throw SearchDataNativeFixtureError.rejected("Original result not reachable: " + id)
    }

    func loadedCount(filtered: Bool = false) throws -> Int {
        let label = try require("global-search-count").label
        let values = label.split(whereSeparator: { !$0.isNumber }).compactMap { Int($0) }
        try requireSearchDataFixture(!values.isEmpty && (!filtered || values.count >= 2), "Read the original loaded counter: " + label)
        return filtered ? values[1] : values[0]
    }

    func suppressAutomaticPaging() throws {
        try require("global-search-result-filter-toggle").tap()
        let filter = try require("global-search-result-filter")
        filter.tap(); filter.typeText("source-acceptance-no-book-" + UUID().uuidString + "\n")
        try require("global-search-filter-empty")
    }

    func closeResultFilter() throws { try require("global-search-result-filter-done").tap() }

    func expand(_ id: String) throws {
        let toggle = try reach("search-result-preview-toggle-" + id)
        if toggle.value as? String != "Expanded" { toggle.tap() }
        try require("search-result-expanded-preview-" + id)
    }

    func originalPreviewScroll(_ id: String) throws -> XCUIElement {
        let scroll = app.scrollViews.matching(identifier: "search-result-expanded-preview-" + id).firstMatch
        try requireSearchDataFixture(scroll.waitForExistence(timeout: 45),
            "Full context must be the original native scroll view, not a synthetic witness")
        return scroll
    }

    func openCurrentPreview(_ id: String) throws {
        let scroll = try originalPreviewScroll(id)
        for _ in 0..<100 {
            let button = control("search-result-open-" + id)
            if button.exists && button.isHittable { button.tap(); return }
            try dragVisible(scroll, up: true)
        }
        throw SearchDataNativeFixtureError.rejected("Original Open action was not reachable")
    }

    func returnToOriginalSearch() throws {
        // The original TabView has no invented route ID. Scope to its native
        // tab bar, not Reader's separate in-book magnifying-glass button.
        let labels = NSPredicate(format: "label == %@ OR label == %@", "Search", "חיפוש")
        let back = app.navigationBars.buttons.matching(labels)
        if back.count == 1, back.firstMatch.isHittable {
            back.firstMatch.tap()
            if control("global-search-screen").waitForExistence(timeout: 5) { return }
        }
        var tabs = app.tabBars.buttons.matching(labels).allElementsBoundByIndex.filter(\.isHittable)
        if tabs.isEmpty {
            let reader = app.textViews["reader-text"].firstMatch
            try requireSearchDataFixture(reader.waitForExistence(timeout: 15), "Reveal the original Reader chrome")
            reader.tap()
            try wait("Original root Search tab must become visible") {
                self.app.tabBars.buttons.matching(labels).allElementsBoundByIndex.filter(\.isHittable).count == 1
            }
            tabs = app.tabBars.buttons.matching(labels).allElementsBoundByIndex.filter(\.isHittable)
        }
        try requireSearchDataFixture(tabs.count == 1 && tabs[0].frame.intersects(app.frame),
            "Require one visible original root Search tab")
        tabs[0].tap()
        try require("global-search-screen")
    }

    func setReaderTextMode(_ mode: String, fromPreview id: String) throws {
        try openCurrentPreview(id)
        try require("reader-more-menu", timeout: 60).tap()
        try require("reader-text-options").tap()
        for _ in 0..<8 {
            if control("reader-text-mode").exists && control("reader-text-mode").isHittable { break }
            let popover = app.popovers.firstMatch
            try requireSearchDataFixture(popover.waitForExistence(timeout: 10), "Original View Options popover must be present")
            try dragVisible(popover, up: true)
        }
        try require("reader-text-mode").tap()
        try require("reader-text-mode-" + mode).tap()
        try require("reader-options-close").tap()
        try returnToOriginalSearch()
        try require("search-result-expanded-preview-" + id)
    }

    func setReaderUnit(_ mode: String, fromPreview id: String) throws {
        try openCurrentPreview(id)
        try require("reader-more-menu", timeout: 60).tap()
        try require("reader-display-unit-menu").tap()
        try require("reader-display-unit-" + mode).tap()
        try returnToOriginalSearch()
        try require("search-result-expanded-preview-" + id)
    }

    func assertOriginalSearchResize(rtl: Bool, query: String, firstStableID: String) throws {
        let count = try loadedCount()
        let bookLabel = try require("global-search-books").label
        let modeLabel = try require("global-search-mode").label
        for orientation in [UIDeviceOrientation.portrait, .landscapeLeft] {
            XCUIDevice.shared.orientation = orientation
            try wait("The original app must actually change viewport orientation") {
                let frame = self.app.frame
                return orientation == .portrait ? frame.height > frame.width : frame.width > frame.height
            }
            try wait("All persistent header controls must remain usable after actual resize") {
                ["global-search-query", "global-search-options", "global-search-books", "global-search-mode"]
                    .allSatisfy { self.control($0).isHittable && self.control($0).frame.intersects(self.app.frame) }
            }
            let field = try require("global-search-query")
            let options = try require("global-search-options")
            let books = try require("global-search-books")
            let mode = try require("global-search-mode")
            XCTAssertEqual(field.value as? String, query)
            XCTAssertEqual(books.label, bookLabel)
            XCTAssertEqual(mode.label, modeLabel)
            XCTAssertEqual(try loadedCount(), count)
            XCTAssertFalse(field.frame.intersects(options.frame))
            XCTAssertGreaterThanOrEqual(books.frame.minY, field.frame.maxY - 1)
            if rtl {
                XCTAssertLessThanOrEqual(options.frame.maxX, field.frame.minX + 1)
                XCTAssertGreaterThan(books.frame.midX, mode.frame.midX)
            } else {
                XCTAssertGreaterThanOrEqual(options.frame.minX, field.frame.maxX - 1)
                XCTAssertLessThan(books.frame.midX, mode.frame.midX)
            }
            try require("search-result-preview-toggle-" + firstStableID)
            XCTAssertFalse(control("global-search-dirty").exists)
            XCTAssertFalse(control("global-search-error").exists)
            capture("original-search-resize-" + (rtl ? "he-" : "en-") + String(orientation.rawValue))
        }
    }

    func assertCompleteContext(id: String, segments: [SearchContextExpectedSegment], mode: String) throws {
        try requireSearchDataFixture(!segments.isEmpty && Set(segments.map(\.locator)).count == segments.count,
            "Independent source must identify every segment uniquely")
        let scroll = try originalPreviewScroll(id)
        let sourcePrefix = "search-preview-source-" + id + "-"
        let translationPrefix = "search-preview-translation-" + id + "-"
        var expected: [String: (String, Int)] = [:]
        for segment in segments {
            if mode == "source" || mode == "both" {
                expected[sourcePrefix + segment.locator] = (segment.sourceSHA256, segment.sourceUTF8Bytes)
            }
            if mode == "translation" || mode == "both" {
                let hash = try XCTUnwrap(segment.translationSHA256, "Bilingual acceptance requires a real translation slot")
                let count = try XCTUnwrap(segment.translationUTF8Bytes)
                expected[translationPrefix + segment.locator] = (hash, count)
            }
        }
        try wait("The original full body must finish loading", timeout: 90) {
            !self.control("search-preview-loading-" + id).exists
                && self.app.staticTexts.matching(NSPredicate(format: "identifier BEGINSWITH %@ OR identifier BEGINSWITH %@",
                    sourcePrefix, translationPrefix)).count > 0
        }
        let firstID = (mode == "translation" ? translationPrefix : sourcePrefix) + segments[0].locator
        for _ in 0..<(segments.count * 4 + 20) {
            let first = app.staticTexts[firstID].firstMatch
            if first.exists && first.frame.intersects(app.frame) && !first.frame.isEmpty { break }
            try dragVisible(scroll, up: false)
        }
        var seen: [String: String] = [:]
        for step in 0..<(segments.count * 5 + 20) {
            let elements = app.staticTexts.matching(NSPredicate(format: "identifier BEGINSWITH %@ OR identifier BEGINSWITH %@",
                                                               sourcePrefix, translationPrefix)).allElementsBoundByIndex
            try requireSearchDataFixture(Set(elements.map(\.identifier)).count == elements.count,
                "An original segment may not be duplicated in the expanded card")
            for element in elements {
                let wanted = try XCTUnwrap(expected[element.identifier],
                    "The selected language mode must not show an extra source/translation segment")
                let text = element.label
                let hash = SHA256.hash(data: Data(text.utf8)).map { String(format: "%02x", $0) }.joined()
                XCTAssertEqual(hash, wanted.0, "Complete native Text must match independent source: " + element.identifier)
                XCTAssertEqual(text.utf8.count, wanted.1)
                if element.frame.intersects(app.frame) && !element.frame.isEmpty { seen[element.identifier] = hash }
            }
            XCTAssertFalse(control("search-preview-error-" + id).exists)
            if step == 0 { capture("full-context-" + mode + "-first") }
            let open = control("search-result-open-" + id)
            if seen.count == expected.count && open.exists && open.isHittable { break }
            try dragVisible(scroll, up: true)
        }
        XCTAssertEqual(Set(seen.keys), Set(expected.keys), "Every complete original source segment must become visible")
        capture("full-context-" + mode + "-last")
        let receipt = XCTAttachment(data: try JSONSerialization.data(withJSONObject: [
            "stableID": id, "mode": mode, "visibleSegmentHashes": seen,
            "expectedSegmentCount": expected.count
        ], options: [.sortedKeys]), uniformTypeIdentifier: "public.json")
        receipt.name = "actual-native-complete-context-" + mode
        receipt.lifetime = .keepAlways; test.add(receipt)
    }
}

final class SefariaFullSearchContextAcceptanceTests: MaktabahUITestBase {
    @MainActor private var ui: OriginalSearchContextUI { .init(app: app, test: self) }

    private func oracle() throws -> SefariaContextSourceReceipt {
        let bytes = try originalSearchOracleBytes(pathKey: "SEFARIA_SEARCH_CONTEXT_ORACLE",
                                                   digestKey: "SEFARIA_SEARCH_CONTEXT_ORACLE_SHA256")
        let source = try JSONDecoder().decode(SefariaContextSourceReceipt.self, from: bytes)
        XCTAssertEqual(source.schema, 1)
        XCTAssertEqual(source.status, "ACTUAL_SOURCE_ORACLE_ONLY_NOT_UI")
        XCTAssertFalse(source.uiExecuted)
        XCTAssertEqual(source.query, "soul")
        XCTAssertEqual(source.filters, ["Tanakh/Writings/Psalms"])
        XCTAssertEqual(source.limit, 100)
        XCTAssertEqual(source.sortOrder, "canonical")
        XCTAssertEqual(source.targetRef, "Psalms 35:17")
        XCTAssertEqual(source.pages.map(\.offset), [0, 100])
        let target = source.pages.flatMap(\.rows).filter { $0.ref == source.targetRef }
        XCTAssertEqual(target.map(\.offset), [98, 99, 100])
        XCTAssertEqual(target.map(\.versionTitle), source.sections.map(\.versionTitle))
        XCTAssertEqual(Set(source.sections.map { $0.segments.compactMap(\.translationSHA256).joined() }).count, 3,
                       "Three real editions must have distinguishable complete bodies")
        for section in source.sections {
            XCTAssertEqual(section.language, "en")
            XCTAssertEqual(section.segments.count, 28)
            XCTAssertEqual(section.stableID, "sefaria|Psalms|ref:Psalms 35:17|\(section.versionTitle)|en")
        }
        let attachment = XCTAttachment(data: bytes, uniformTypeIdentifier: "public.json")
        attachment.name = "independent-sefaria-pages-and-complete-context-oracle"
        attachment.lifetime = .keepAlways; add(attachment)
        return source
    }

    @MainActor
    private func launchPsalms(_ source: SefariaContextSourceReceipt, language: String) throws {
        for key in ["OTZARIA_SHARED_ROOT_OVERRIDE", "OTZARIA_PRODUCTION_DB_PATH"] {
            XCTAssertNil(ProcessInfo.processInfo.environment[key], "Do not substitute application data")
        }
        XCUIDevice.shared.orientation = .landscapeLeft
        launchWithTier(.production, backend: "sefaria",
            extraArgs: ["-lastSelectedTab", "0", "-ChavrusaTextFaithfulReaderUIEnabled", "YES"],
            language: language, locale: language == "he" ? "he_IL" : "en_US")
        XCTAssertFalse(app.launchArguments.contains("-smokeBypassBootstrap"))
        XCTAssertFalse(app.launchArguments.contains("-studyWorkspaceTestingNamespace"))
        let tab = findTabButton(hebrew: "חיפוש", english: "Search")
        try requireSearchDataFixture(tab.waitForExistence(timeout: 120), "Original Sefaria bootstrap must expose Search")
        tab.tap()
        try ui.require("global-search-screen", timeout: 60)
        try ui.require("global-search-mode").tap()
        try ui.require("global-search-mode-exact").tap()
        try ui.require("global-search-books").tap()
        if ui.control("global-search-book-clear").exists { ui.control("global-search-book-clear").tap() }
        let books = try ui.require("global-search-book-query", timeout: 60)
        books.tap()
        if let clear = books.buttons.allElementsBoundByIndex.first(where: \.isHittable) { clear.tap() }
        books.typeText(language == "he" ? "תהילים\n" : "Psalms\n")
        let psalms = try ui.require("search-book-sefaria|Psalms|ref:Psalms", timeout: 60)
        XCTAssertTrue(psalms.isHittable); psalms.tap()
        if ui.control("global-search-book-done").exists { ui.control("global-search-book-done").tap() }
        let query = try ui.require("global-search-query")
        query.tap()
        if let clear = query.buttons.allElementsBoundByIndex.first(where: \.isHittable) { clear.tap() }
        query.typeText(source.query + "\n")
        try ui.require("global-search-count", timeout: 120)
        try ui.require("global-search-sort").tap()
        try ui.require("global-search-sort-canonical").tap()
        try ui.require("global-search-rerun").tap()
        try ui.wait("The original canonical first page must contain exactly 100 results", timeout: 120) {
            (try? self.ui.loadedCount()) == 100
        }
        try ui.suppressAutomaticPaging()
        XCTAssertEqual(try ui.loadedCount(filtered: true), 100)
        try ui.closeResultFilter()
        let first = try XCTUnwrap(source.pages.first?.rows.first)
        let firstID = "sefaria|Psalms|ref:\(first.ref)|\(first.versionTitle)|\(first.language)"
        try ui.assertOriginalSearchResize(rtl: language == "he", query: source.query, firstStableID: firstID)
    }

    @MainActor
    private func appendSecondPage(_ source: SefariaContextSourceReceipt) throws {
        let group = "search-result-versions-sefaria|Psalms|ref:Psalms 35:17"
        let menu = try ui.reach(group)
        XCTAssertEqual(menu.value as? String, "2", "Only the first two real editions belong to page one")
        menu.tap()
        for section in source.sections.prefix(2) { try ui.require("search-result-version-" + section.stableID) }
        XCTAssertFalse(ui.control("search-result-version-" + source.sections[2].stableID).exists)
        try ui.require("search-result-version-" + source.sections[0].stableID).tap()
        ui.capture("same-source-two-editions-page-one")
        try ui.suppressAutomaticPaging()
        let load = app.buttons.matching(NSPredicate(format: "label == %@", "Load more results")).firstMatch
        try requireSearchDataFixture(load.waitForExistence(timeout: 20) && load.isHittable, "Original explicit paging action must remain reachable")
        load.tap()
        try ui.wait("The original second page must append cumulatively to 200") {
            (try? self.ui.loadedCount(filtered: true)) == 200
        }
        try ui.closeResultFilter()
        let updated = try ui.reach(group)
        XCTAssertEqual(updated.value as? String, "3")
        XCTAssertEqual(app.buttons.matching(identifier: group).count, 1,
            "The later-page edition must merge into one canonical source card")
        ui.capture("same-source-three-editions-across-original-pages")
    }

    @MainActor
    func testThreeActualSefariaEditionsAcrossTwoPagesKeepDistinctCompleteBodies() throws {
        let source = try oracle()
        try launchPsalms(source, language: "en")
        try appendSecondPage(source)
        let first = source.sections[0]
        try ui.expand(first.stableID)
        try ui.setReaderTextMode("translation", fromPreview: first.stableID)
        var activeID = first.stableID
        for section in source.sections {
            // Return to the result header before changing the original version menu.
            let scroll = try ui.originalPreviewScroll(activeID)
            for _ in 0..<80 {
                if ui.control("search-result-versions-sefaria|Psalms|ref:Psalms 35:17").isHittable { break }
                try ui.dragVisible(scroll, up: false)
            }
            try ui.require("search-result-versions-sefaria|Psalms|ref:Psalms 35:17").tap()
            try ui.require("search-result-version-" + section.stableID).tap()
            activeID = section.stableID
            try ui.require("search-result-expanded-preview-" + section.stableID)
            XCTAssertEqual(ui.control("search-result-preview-toggle-" + section.stableID).value as? String, "Expanded")
            try ui.assertCompleteContext(id: section.stableID, segments: section.segments, mode: "translation")
        }
        XCTAssertEqual(try ui.loadedCount(), 200)
    }

    @MainActor
    func testHebrewUIEnglishResultHonorsOriginalSourceTranslationAndBothControls() throws {
        let source = try oracle()
        try launchPsalms(source, language: "he")
        try appendSecondPage(source)
        let section = source.sections[0]
        try ui.expand(section.stableID)
        for mode in ["source", "translation", "both"] {
            try ui.setReaderTextMode(mode, fromPreview: section.stableID)
            try ui.assertCompleteContext(id: section.stableID, segments: section.segments, mode: mode)
        }
        XCTAssertEqual(try ui.require("global-search-query").value as? String, source.query)
        XCTAssertFalse(ui.control("global-search-dirty").exists)
    }

    override func tearDownWithError() throws {
        if let app {
            let tree = XCTAttachment(string: app.debugDescription)
            tree.name = "full-context-final-native-hierarchy"; tree.lifetime = .keepAlways; add(tree)
            let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
            screen.name = "full-context-final-native-screen"; screen.lifetime = .keepAlways; add(screen)
        }
        try super.tearDownWithError()
    }
}


private struct ProductionSearchPreviewSourceReceipt: Decodable {
    struct Target: Decodable {
        struct Anchor: Decodable {
            let lineID: Int64
            let bookID: Int
            let lineIndex: Int
            let heRef: String?
            let text: String
            let textSHA256: String
            let segmentID: String
            let previewPlainText: String
            let previewPlainTextSHA256: String
            let previewUTF16Length: Int
        }
        let bookID: Int
        let bookTitle: String
        let focusLineIndex: Int
        let unitID: String
        let unitMode: String
        let unitStartLineIndex: Int
        let unitEndLineIndex: Int
        let unitRowCount: Int
        let sourceUTF8: String
        let sourceSHA256: String
        let allOriginalAnchorsChecked: Int
        let focusLocator: String
        let anchors: [Anchor]
    }
    let schema: Int
    let status: String
    let corpusProfile: String
    let databaseSHA256: String
    let sourceServiceSHA256: String
    let presentationSourceSHA256: String
    let catalogCompileInputsSHA256: String
    let uiExecuted: Int
    let searchProviderExecuted: Bool
    let targets: [Target]
}

extension PublishedProductionSearchDataTests {
    @MainActor
    private func submitNafshiOriginalFirstPage() throws -> (Installation, [[String: Any]]) {
        try launchProduction(unitMode: nil) // The real UI must be able to persist mode changes.
        let value = try installation()
        try verifyUnchanged(value)
        try verifyPackages(value)
        let ui = OriginalSearchContextUI(app: app, test: self)
        try chooseEngine("otzaria")
        let field = try required("global-search-query")
        field.tap()
        if let clear = field.buttons.allElementsBoundByIndex.first(where: \.isHittable) { clear.tap() }
        field.typeText("נפשי\n")
        try ui.wait("The requested real production query must publish its first 100 results", timeout: 180) {
            (try? self.loadedCount(filtered: false)) == 100
        }
        try ui.suppressAutomaticPaging()
        XCTAssertEqual(try loadedCount(filtered: true), 100)
        try ui.closeResultFilter()
        let observed = try events(value)
        let queryHash = searchDataDigest(Data("נפשי".utf8))
        let providers = observed.filter {
            $0["engine"] as? String == "otzaria" && $0["event"] as? String == "provider"
                && ($0["request"] as? [String: Any])?["querySHA256"] as? String == queryHash
        }
        XCTAssertEqual(providers.count, 1, "Only the original first page of the requested query is eligible")
        let provider = try XCTUnwrap(providers.first)
        XCTAssertEqual(provider["namespace"] as? String, traceNamespace)
        XCTAssertEqual(provider["profileID"] as? String, "production")
        let request = try XCTUnwrap(provider["request"] as? [String: Any])
        XCTAssertEqual(request["querySHA256"] as? String, queryHash)
        XCTAssertNil(request["query"], "Preserve passive trace query privacy")
        XCTAssertEqual((request["offset"] as? NSNumber)?.intValue, 0)
        XCTAssertEqual((request["limit"] as? NSNumber)?.intValue, 100)
        let page = try XCTUnwrap(provider["page"] as? [String: Any])
        let rows = try XCTUnwrap(page["results"] as? [[String: Any]])
        let publication = try XCTUnwrap(observed.last {
            $0["engine"] as? String == "otzaria" && $0["event"] as? String == "published"
                && ($0["items"] as? [[String: Any]])?.count == 100
        })
        let items = try XCTUnwrap(publication["items"] as? [[String: Any]])
        XCTAssertEqual(rows.count, 100)
        XCTAssertEqual(items.count, 100)
        var handle: OpaquePointer?
        XCTAssertEqual(sqlite3_open_v2(value.database.path, &handle, SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX, nil), SQLITE_OK)
        let database = try XCTUnwrap(handle)
        defer { sqlite3_close(database) }
        XCTAssertEqual(sqlite3_db_readonly(database, "main"), 1)
        var sql: [[String: Any]] = []
        for (row, item) in zip(rows, items) {
            let path = try XCTUnwrap(row["filePath"] as? String)
            try requireSearchDataFixture(path.hasPrefix("otzaria-book:"), "Actual source must retain its qualified book identity")
            let book = try XCTUnwrap(Int(path.dropFirst("otzaria-book:".count)))
            let line = try XCTUnwrap((row["segment"] as? NSNumber)?.intValue)
            let id = "otzaria:\(path):\(try XCTUnwrap((row["id"] as? NSNumber)?.uint64Value)):\(line)"
            let actual = try sqlLine(database: database, book: book, line: line)
            XCTAssertEqual(item["id"] as? String, id)
            XCTAssertEqual((item["bookID"] as? NSNumber)?.intValue, book)
            XCTAssertEqual((item["lineIndex"] as? NSNumber)?.intValue, line)
            XCTAssertEqual(item["locator"] as? String, "otzaria|book:\(book)|line:\(line)")
            XCTAssertEqual(item["bookTitle"] as? String, actual["bookTitle"] as? String)
            XCTAssertEqual(row["title"] as? String, actual["bookTitle"] as? String)
            XCTAssertEqual(item["reference"] as? String, row["reference"] as? String ?? "")
            XCTAssertEqual(row["reference"] as? String ?? "", actual["reference"] as? String ?? "")
            sql.append(actual)
        }
        XCTAssertEqual(Set(items.compactMap { $0["id"] as? String }).count, 100)
        XCTAssertEqual(field.value as? String, "נפשי")
        let receipt = XCTAttachment(data: try canonical([
            "scope": "actual original UI query and provider page plus immutable SQL, not full-context acceptance",
            "provider": provider, "publication": publication, "independentSQL": sql
        ]), uniformTypeIdentifier: "public.json")
        receipt.name = "published-v40-nafshi-source-selection-for-independent-context-oracle"
        receipt.lifetime = .keepAlways; add(receipt)
        let firstID = try XCTUnwrap(items.first?["id"] as? String)
        try ui.assertOriginalSearchResize(rtl: true, query: "נפשי", firstStableID: firstID)
        let afterResizeProviders = try events(value).filter {
            $0["engine"] as? String == "otzaria" && $0["event"] as? String == "provider"
                && ($0["request"] as? [String: Any])?["querySHA256"] as? String == queryHash
        }
        XCTAssertEqual(afterResizeProviders.count, providers.count, "Viewport changes must not submit another source request")
        ui.capture("published-v40-nafshi-original-first-page")
        return (value, items)
    }

    @MainActor
    func testPublishedV40NafshiFirstPageForIndependentFullContextOracle() throws {
        let (value, _) = try submitNafshiOriginalFirstPage()
        try verifyUnchanged(value, hashDatabase: false)
    }

    @MainActor
    func testPublishedV40NafshiFullParagraphAndChapterMatchEveryOriginalSourceSegment() throws {
        let oracleBytes = try originalSearchOracleBytes(pathKey: "PRODUCTION_SEARCH_PREVIEW_ORACLE",
                                                        digestKey: "PRODUCTION_SEARCH_PREVIEW_ORACLE_SHA256")
        let oracle = try JSONDecoder().decode(ProductionSearchPreviewSourceReceipt.self, from: oracleBytes)
        XCTAssertEqual(oracle.schema, 1)
        XCTAssertEqual(oracle.status, "ORIGINAL_SOURCE_PREVIEW_CATALOG_ONLY_NOT_SEARCH_OR_UI")
        XCTAssertEqual(oracle.corpusProfile, "full-v40")
        XCTAssertEqual(oracle.databaseSHA256, v40Digest)
        XCTAssertEqual(oracle.uiExecuted, 0)
        XCTAssertFalse(oracle.searchProviderExecuted)
        let environment = ProcessInfo.processInfo.environment
        for (actual, key) in [
            (oracle.sourceServiceSHA256, "PRODUCTION_SEARCH_PREVIEW_SERVICE_SHA256"),
            (oracle.presentationSourceSHA256, "PRODUCTION_SEARCH_PREVIEW_PRESENTATION_SHA256"),
            (oracle.catalogCompileInputsSHA256, "PRODUCTION_SEARCH_PREVIEW_COMPILE_SHA256")
        ] {
            let expected = try XCTUnwrap(environment[key], "Bind the oracle to the independently retained actual source/compile closure")
            XCTAssertEqual(expected.count, 64); XCTAssertEqual(actual, expected)
        }
        let paragraph = try XCTUnwrap(oracle.targets.first { $0.unitMode == "paragraph" })
        let chapter = try XCTUnwrap(oracle.targets.first { $0.unitMode == "chapter" })
        XCTAssertEqual(oracle.targets.filter { $0.unitMode == "paragraph" }.count, 1)
        XCTAssertEqual(oracle.targets.filter { $0.unitMode == "chapter" }.count, 1)
        XCTAssertEqual(paragraph.bookID, chapter.bookID)
        XCTAssertEqual(paragraph.focusLineIndex, chapter.focusLineIndex)
        XCTAssertGreaterThan(chapter.unitRowCount, paragraph.unitRowCount,
            "Select an actual hit whose genuine paragraph and chapter have different complete bounds")
        let (value, items) = try submitNafshiOriginalFirstPage()
        let hit = try XCTUnwrap(items.first {
            ($0["bookID"] as? NSNumber)?.intValue == paragraph.bookID
                && ($0["lineIndex"] as? NSNumber)?.intValue == paragraph.focusLineIndex
        }, "The original submitted page must actually contain the source-qualified target")
        let id = try XCTUnwrap(hit["id"] as? String)
        XCTAssertEqual(hit["locator"] as? String, paragraph.focusLocator)
        let ui = OriginalSearchContextUI(app: app, test: self)
        try ui.expand(id)
        var handle: OpaquePointer?
        XCTAssertEqual(sqlite3_open_v2(value.database.path, &handle, SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX, nil), SQLITE_OK)
        let database = try XCTUnwrap(handle)
        defer { sqlite3_close(database) }
        for target in [paragraph, chapter] {
            XCTAssertEqual(target.focusLocator, "otzaria|book:\(target.bookID)|line:\(target.focusLineIndex)")
            XCTAssertEqual(target.unitRowCount, target.anchors.count)
            XCTAssertEqual(target.allOriginalAnchorsChecked, target.anchors.count)
            XCTAssertEqual(target.sourceSHA256,
                SHA256.hash(data: Data(target.sourceUTF8.utf8)).map { String(format: "%02x", $0) }.joined())
            XCTAssertEqual(Set(target.anchors.map(\.lineID)).count, target.anchors.count)
            var expected: [SearchContextExpectedSegment] = []
            for anchor in target.anchors {
                let row = try sqlLine(database: database, book: anchor.bookID, line: anchor.lineIndex)
                XCTAssertEqual((row["lineID"] as? NSNumber)?.int64Value, anchor.lineID)
                XCTAssertEqual(anchor.bookID, target.bookID)
                XCTAssertEqual(row["bookTitle"] as? String, target.bookTitle)
                XCTAssertEqual(row["reference"] as? String ?? "", anchor.heRef ?? "")
                XCTAssertEqual(anchor.segmentID, "otzaria|book:\(anchor.bookID)|line:\(anchor.lineIndex)")
                XCTAssertEqual(anchor.textSHA256,
                    SHA256.hash(data: Data(anchor.text.utf8)).map { String(format: "%02x", $0) }.joined())
                XCTAssertEqual(anchor.previewPlainTextSHA256,
                    SHA256.hash(data: Data(anchor.previewPlainText.utf8)).map { String(format: "%02x", $0) }.joined())
                XCTAssertEqual(anchor.previewUTF16Length, (anchor.previewPlainText as NSString).length)
                if !anchor.previewPlainText.isEmpty {
                    expected.append(.init(locator: anchor.segmentID, sourceSHA256: anchor.previewPlainTextSHA256,
                        translationSHA256: nil, sourceUTF8Bytes: anchor.previewPlainText.utf8.count,
                        translationUTF8Bytes: nil))
                }
            }
            try ui.setReaderUnit(target.unitMode, fromPreview: id)
            try ui.assertCompleteContext(id: id, segments: expected, mode: "source")
        }
        let receipt = XCTAttachment(data: oracleBytes, uniformTypeIdentifier: "public.json")
        receipt.name = "independent-v40-complete-paragraph-and-chapter-source"
        receipt.lifetime = .keepAlways; add(receipt)
        XCTAssertEqual(try required("global-search-query").value as? String, "נפשי")
        try verifyUnchanged(value, hashDatabase: false)
    }
}


// MARK: - R08: retained v40 indexes after the original Settings update to v41

/// This is a cold, post-update gate. The controller must separately validate the
/// Settings case and the active app-process log interval. A missing success-only
/// JSONL trace is never an accepted negative observation.
private struct ProductionSearchPostUpdateReceipt: Decodable {
    struct FileWitness: Decodable {
        let path: String
        let bytes: Int64
        let sha256: String
    }
    struct RawManifest: Decodable {
        let sourcePath: String
        let rawBase64: String
        let bytes: Int64
        let sha256: String
    }
    struct Database: Decodable {
        let path: String
        let bytes: Int64
        let sha256: String
    }
    struct IndexFile: Codable, Equatable {
        let relativePath: String
        let bytes: Int64
        let inode: Int64
        let mtimeNs: Int64
        let ctimeNs: Int64
    }
    struct Index: Decodable {
        let engine: String
        let storageRoot: String
        let artifactID: String
        let manifest: RawManifest
        let files: [IndexFile]
    }
    struct Snapshot: Decodable {
        let database: Database
        let installationManifest: RawManifest
        let indexes: [Index]
    }
    struct SettingsExecution: Decodable {
        let caseID: String
        let caseStatus: String
        let executedTests: Int
        let skippedTests: Int
        let caseResult: FileWitness
        let zeroSkipResult: FileWitness
        let xcresultPath: String
        let installedAttachment: FileWitness
        let officialTargetAttachment: FileWitness
    }
    struct OfficialTarget: Decodable {
        let releaseID: Int64
        let releaseTag: String
        let repository: String
    }
    struct TraceBaseline: Decodable {
        let namespace: String
        let relativePath: String
        let bytes: Int64
        let sha256: String
        let inode: Int64
        let mtimeNs: Int64
        let ctimeNs: Int64
        let processID: Int
        let caseID: String
        let caseStatus: String
        let xcresultPath: String
        let caseResult: FileWitness
        let sourceAttachment: FileWitness
        let sourceDatabaseManifestSHA256: String
    }
    let schemaVersion: Int
    let status: String
    let simulatorUDID: String
    let bundleID: String
    let checkoutSHA: String
    let dataContainerBefore: String
    let dataContainerAfter: String
    let originalInstallationResult: FileWitness
    let settingsExecution: SettingsExecution
    let before: Snapshot
    let after: Snapshot
    let officialTarget: OfficialTarget
    let traceBaseline: TraceBaseline
}

final class PublishedProductionSearchAfterBooksUpdateTests: MaktabahUITestBase {
    private typealias Receipt = ProductionSearchPostUpdateReceipt
    private let v40Digest = "8389709c1702753af6f0719ef1c98c09854450e48ebb05fe1f95486b26348b01"
    private let bundleID = "com.davidpovarsky.chavrusatext"
    private let otzariaArtifact = "f8fea8efcac5fc06b272a061b44f0e0ee66d16ae12f1e864f9510e437e929139"
    private let zayitArtifact = "17cabb80e86ac8c2d1a3ce16a4e1457d4351709798f2b91a84120d4dd0c6c480"
    @MainActor private var ui: OriginalSearchContextUI { .init(app: app, test: self) }

    private struct FileIdentity: Codable, Equatable {
        let device: Int64
        let inode: Int64
        let bytes: Int64
        let mtimeNs: Int64
        let ctimeNs: Int64
    }

    private func identity(_ url: URL) throws -> FileIdentity {
        try requireSearchDataFixture(url.isFileURL && url.path.hasPrefix("/")
            && url.standardizedFileURL.path == url.resolvingSymlinksInPath().path,
            "Observe only canonical original files, without symbolic-link substitution")
        var value = Darwin.stat()
        let result = url.path.withCString { Darwin.lstat($0, &value) }
        try requireSearchDataFixture(result == 0 && value.st_mode & mode_t(S_IFMT) == mode_t(S_IFREG),
            "Require a present regular file, including the existing positive trace")
        try requireSearchDataFixture(value.st_ino <= UInt64(Int64.max), "Bound the original inode representation")
        return FileIdentity(device: Int64(value.st_dev), inode: Int64(value.st_ino), bytes: value.st_size,
            mtimeNs: Int64(value.st_mtimespec.tv_sec) * 1_000_000_000 + Int64(value.st_mtimespec.tv_nsec),
            ctimeNs: Int64(value.st_ctimespec.tv_sec) * 1_000_000_000 + Int64(value.st_ctimespec.tv_nsec))
    }

    private func bytes(_ url: URL, maximum: Int = 8 * 1024 * 1024) throws -> Data {
        let before = try identity(url)
        try requireSearchDataFixture(before.bytes >= 0 && before.bytes <= maximum, "Bound acceptance metadata reads")
        let data = try Data(contentsOf: url)
        try requireSearchDataFixture(Int64(data.count) == before.bytes && before == identity(url),
            "Reject metadata changed during the read")
        return data
    }

    private func verified(_ witness: Receipt.FileWitness) throws -> Data {
        let data = try bytes(URL(fileURLWithPath: witness.path))
        try requireSearchDataFixture(Int64(data.count) == witness.bytes && searchDataDigest(data) == witness.sha256,
            "Require exact retained controller/XCTest evidence: " + URL(fileURLWithPath: witness.path).lastPathComponent)
        return data
    }

    private func raw(_ manifest: Receipt.RawManifest) throws -> Data {
        let data = try XCTUnwrap(Data(base64Encoded: manifest.rawBase64), "Require original manifest bytes")
        try requireSearchDataFixture(data.count <= 1024 * 1024 && Int64(data.count) == manifest.bytes
            && searchDataDigest(data) == manifest.sha256, "Manifest object equality cannot replace exact source bytes")
        return data
    }

    private func object(_ data: Data) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }

    private func canonical(_ value: Any) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }

    private func inventory(_ root: URL) throws -> [Receipt.IndexFile] {
        try requireSearchDataFixture(root.standardizedFileURL.path == root.resolvingSymlinksInPath().path,
            "The retained package must stay in the original storage root")
        let enumerator = try XCTUnwrap(FileManager.default.enumerator(at: root,
            includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey], options: []))
        var rows: [Receipt.IndexFile] = []
        var visited = 0
        for case let file as URL in enumerator {
            visited += 1
            try requireSearchDataFixture(visited <= 2048 && rows.count <= 1024, "Bound the original package inventory")
            let info = try file.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            try requireSearchDataFixture(info.isSymbolicLink == false, "A retained package cannot hide a substituted symbolic link")
            if info.isDirectory == true { continue }
            try requireSearchDataFixture(file.pathComponents.starts(with: root.pathComponents), "Keep every package member inside its root")
            let relative = file.pathComponents.dropFirst(root.pathComponents.count).joined(separator: "/")
            let value = try identity(file)
            rows.append(.init(relativePath: relative, bytes: value.bytes, inode: value.inode,
                              mtimeNs: value.mtimeNs, ctimeNs: value.ctimeNs))
        }
        try requireSearchDataFixture(!rows.isEmpty && rows.count <= 1024, "An empty or partial package is not retained production data")
        return rows.sorted { $0.relativePath < $1.relativePath }
    }

    private func receipt() throws -> (Receipt, String) {
        let data = try originalSearchOracleBytes(pathKey: "PRODUCTION_SEARCH_POST_UPDATE_RECEIPT",
                                                digestKey: "PRODUCTION_SEARCH_POST_UPDATE_RECEIPT_SHA256")
        let value = try JSONDecoder().decode(Receipt.self, from: data)
        try requireSearchDataFixture(value.schemaVersion == 1 && value.status == "ORIGINAL_SETTINGS_UPDATE_VERIFIED"
            && value.bundleID == bundleID && value.checkoutSHA.count == 40,
            "Only the original controller's completed Settings update is eligible")
        try requireSearchDataFixture(value.settingsExecution.caseID == "Maktabah-iOSUITests/ManagedLibraryUpdateAcceptanceTests/testOrdinarySettingsUpdatePreservesProductionLibraryAndUserState"
            && value.settingsExecution.caseStatus == "Passed"
            && value.settingsExecution.executedTests == 1 && value.settingsExecution.skippedTests == 0,
            "Settings must have one actual passing test and no skip")
        _ = try verified(value.originalInstallationResult)
        _ = try verified(value.settingsExecution.caseResult)
        _ = try verified(value.settingsExecution.zeroSkipResult)
        let installed = try object(verified(value.settingsExecution.installedAttachment))
        let target = try object(verified(value.settingsExecution.officialTargetAttachment))
        let before = try object(raw(value.before.installationManifest))
        let after = try object(raw(value.after.installationManifest))
        try requireSearchDataFixture((before["profileID"] as? String ?? "production") == "production"
            && (after["profileID"] as? String ?? "production") == "production", "Do not substitute miniTest10 or another profile")
        try requireSearchDataFixture(before["releaseTag"] as? String == "v40-20261123094345"
            && (before["releaseID"] as? NSNumber)?.int64Value == 455_390_662
            && value.before.database.sha256 == v40Digest && value.before.database.bytes == 4_355_063_808,
            "Both retained packages must come from the previously admitted full v40 installation")
        try requireSearchDataFixture(value.officialTarget.repository == "Otzaria/SeforimLibrary"
            && value.officialTarget.releaseID == 459_809_828
            && value.officialTarget.releaseTag == "v41-20261126162443"
            && after["releaseTag"] as? String == value.officialTarget.releaseTag
            && (after["releaseID"] as? NSNumber)?.int64Value == value.officialTarget.releaseID
            && value.after.database.sha256.count == 64 && value.after.database.sha256 != v40Digest
            && value.after.database.bytes > 0
            && (after["databaseFileSize"] as? NSNumber)?.int64Value == value.after.database.bytes,
            "This separate gate requires the real v41 installed by Settings; a relabelled v40 is ineligible")
        try requireSearchDataFixture(installed["old_database_sha256"] as? String == value.before.database.sha256
            && installed["new_database_sha256"] as? String == value.after.database.sha256,
            "Bind the database hashes to the actual Settings XCTest attachment")
        XCTAssertEqual(try canonical(try XCTUnwrap(installed["installed_manifest"])), try canonical(after))
        try requireSearchDataFixture((target["release_id"] as? NSNumber)?.int64Value == value.officialTarget.releaseID
            && target["tag"] as? String == value.officialTarget.releaseTag, "Bind the actual official target attachment")
        return (value, searchDataDigest(data))
    }

    private func installation(_ receipt: Receipt) throws -> (container: URL, root: URL) {
        let environment = ProcessInfo.processInfo.environment
        let supplied = try XCTUnwrap(environment["PRODUCTION_SEARCH_CONTAINER_PARENT"])
        let parent = URL(fileURLWithPath: supplied, isDirectory: true).standardizedFileURL
        let simulatorData = parent.deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
        let udid = try XCTUnwrap(environment["SIMULATOR_UDID"])
        try requireSearchDataFixture(UUID(uuidString: udid) != nil && udid.lowercased() == receipt.simulatorUDID.lowercased()
            && Array(parent.pathComponents.suffix(3)) == ["Containers", "Data", "Application"]
            && simulatorData.lastPathComponent == "data"
            && simulatorData.deletingLastPathComponent().lastPathComponent.lowercased() == udid.lowercased(),
            "Only this controller-owned Simulator may supply the updated installation")
        func owners(_ parent: URL, identifier: String) throws -> [URL] {
            let children = try FileManager.default.contentsOfDirectory(at: parent,
                includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            try requireSearchDataFixture(children.count <= 256, "Bound original container discovery")
            return try children.filter { child in
                let info = try child.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                guard info.isDirectory == true && info.isSymbolicLink == false
                    && UUID(uuidString: child.lastPathComponent) != nil else { return false }
                let metadata = child.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")
                guard let data = try? bytes(metadata, maximum: 65536),
                      let object = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any] else { return false }
                return object["MCMMetadataIdentifier"] as? String == identifier
            }
        }
        let apps = try owners(parent, identifier: bundleID)
        try requireSearchDataFixture(apps.count == 1, "Require the sole original app owner")
        let appContainer = try XCTUnwrap(apps.first).standardizedFileURL
        try requireSearchDataFixture(appContainer.path == receipt.dataContainerAfter, "The controller must bind any actual container relocation before this gate")
        let groupParent = simulatorData.appendingPathComponent("Containers/Shared/AppGroup")
        let groups = FileManager.default.fileExists(atPath: groupParent.path)
            ? try owners(groupParent, identifier: "group.com.davidpovarsky.itorah") : []
        try requireSearchDataFixture(groups.count <= 1, "Ambiguous App Group ownership cannot pass")
        let root = (groups.first ?? appContainer.appendingPathComponent("Library/Application Support/Maktabah-Debug")).standardizedFileURL
        try requireSearchDataFixture(root.pathComponents.starts(with: simulatorData.pathComponents)
            && root.path == root.resolvingSymlinksInPath().path, "Keep normal managed storage ownership")
        try requireSearchDataFixture(receipt.after.installationManifest.sourcePath == root.appendingPathComponent("Otzaria/seforim-installation.json").path
            && receipt.after.database.path == root.appendingPathComponent("Otzaria/seforim.db").path,
            "Bind the actual managed database and receipt paths")
        return (appContainer, root)
    }

    private func verifyRetained(_ receipt: Receipt, root: URL) throws {
        XCTAssertEqual(try bytes(URL(fileURLWithPath: receipt.after.installationManifest.sourcePath), maximum: 1024 * 1024),
                       try raw(receipt.after.installationManifest))
        XCTAssertEqual(try identity(URL(fileURLWithPath: receipt.after.database.path)).bytes, receipt.after.database.bytes)
        try requireSearchDataFixture(Set(receipt.before.indexes.map(\.engine)) == ["otzaria", "zayit"]
            && Set(receipt.after.indexes.map(\.engine)) == ["otzaria", "zayit"]
            && receipt.before.indexes.count == 2 && receipt.after.indexes.count == 2, "Require both actual retained packages")
        for index in receipt.after.indexes {
            let original = try XCTUnwrap(receipt.before.indexes.first { $0.engine == index.engine })
            let artifact = index.engine == "otzaria" ? otzariaArtifact : zayitArtifact
            let suffix = index.engine == "otzaria" ? "Otzaria/TantivySearchIndex/managed-library" : "Otzaria/Zayit"
            let expectedRoot = root.appendingPathComponent(suffix, isDirectory: true)
            let manifestName = index.engine == "otzaria" ? "otzaria_prebuilt_installation.json" : "zayit-installation.json"
            try requireSearchDataFixture(index.storageRoot == expectedRoot.path
                && index.manifest.sourcePath == expectedRoot.appendingPathComponent(manifestName).path
                && index.artifactID == artifact && original.artifactID == artifact,
                "A replacement v41 package cannot count as retained v40")
            let metadata = try raw(index.manifest)
            XCTAssertEqual(metadata, try raw(original.manifest), "Settings must preserve each exact original v40 manifest")
            XCTAssertEqual(try bytes(URL(fileURLWithPath: index.manifest.sourcePath), maximum: 1024 * 1024), metadata)
            let manifest = try object(metadata)
            XCTAssertEqual(manifest["artifactIdentity"] as? String, artifact)
            let source = try XCTUnwrap(manifest[index.engine == "otzaria" ? "sourceDatabase" : "requiredDatabase"] as? [String: Any])
            XCTAssertEqual(source["releaseTag"] as? String, "v40-20261123094345")
            XCTAssertEqual(source[index.engine == "otzaria" ? "databaseSHA256" : "canonicalSHA256"] as? String, v40Digest)
            let beforeFiles = original.files.sorted { $0.relativePath < $1.relativePath }
            let afterFiles = index.files.sorted { $0.relativePath < $1.relativePath }
            try requireSearchDataFixture(Set(afterFiles.map(\.relativePath)).count == afterFiles.count
                && !afterFiles.isEmpty && afterFiles.count <= 1024, "Reject duplicate or unbounded retained inventories")
            XCTAssertEqual(afterFiles, beforeFiles, "The Settings update cannot remove or replace old package members")
            XCTAssertEqual(try inventory(expectedRoot), afterFiles, "Require the full actual retained inventory, not only its manifest")
        }
    }

    private func trace(_ receipt: Receipt, container: URL) throws -> (identity: FileIdentity, data: Data) {
        let source = receipt.traceBaseline
        try requireSearchDataFixture(UUID(uuidString: source.namespace) != nil
            && source.relativePath == "Documents/OtzariaLogs/search-native-" + source.namespace + ".jsonl"
            && source.caseStatus == "Passed" && source.processID > 0
            && source.sourceDatabaseManifestSHA256 == receipt.before.installationManifest.sha256,
            "Reuse only the observation namespace of an actual passed v40 page case")
        let expectedEngine: String
        switch source.caseID {
        case "Maktabah-iOSUITests/PublishedProductionSearchDataTests/testPublishedV40OtzariaPagesRetainCumulativeSQLMetadata": expectedEngine = "otzaria"
        case "Maktabah-iOSUITests/PublishedProductionSearchDataTests/testPublishedV40ZayitPages50_100_150RetainSQLIdentity": expectedEngine = "zayit"
        default: throw SearchDataNativeFixtureError.rejected("The trace prefix must come from an exact original v40 page selector")
        }
        _ = try verified(source.caseResult)
        let priorEvidence = try object(verified(source.sourceAttachment))
        let url = container.appendingPathComponent(source.relativePath)
        let data = try bytes(url)
        let observed = try identity(url)
        try requireSearchDataFixture(observed.bytes == source.bytes && observed.inode == source.inode
            && observed.mtimeNs == source.mtimeNs && observed.ctimeNs == source.ctimeNs
            && searchDataDigest(data) == source.sha256, "Bind the existing positive trace's exact identity, bytes and end offset")
        let text = try XCTUnwrap(String(data: data, encoding: .utf8))
        try requireSearchDataFixture(text.hasSuffix("\n"), "Do not admit a truncated original trace")
        let events = try text.split(separator: "\n").map { try object(Data($0.utf8)) }
        try requireSearchDataFixture(!events.isEmpty && events.count <= 4096
            && events.contains { $0["event"] as? String == "provider" }
            && events.contains { $0["event"] as? String == "published" }, "A missing or unexercised trace is never negative proof")
        for event in events {
            try requireSearchDataFixture(event["namespace"] as? String == source.namespace
                && (event["schemaVersion"] as? NSNumber)?.intValue == 1
                && event["profileID"] as? String == "production"
                && event["engine"] as? String == expectedEngine
                && (event["processID"] as? NSNumber)?.intValue == source.processID,
                "Every existing prefix event must retain the actual qualified v40 source identity")
        }
        XCTAssertEqual(try canonical(events), try canonical(try XCTUnwrap(priorEvidence["events"])),
                       "Bind the prefix to the actual page case attachment, not just broad event names")
        return (observed, data)
    }

    @MainActor
    private func launch(_ receipt: Receipt) throws {
        for key in ["OTZARIA_SHARED_ROOT_OVERRIDE", "OTZARIA_PRODUCTION_DB_PATH"] {
            try requireSearchDataFixture(ProcessInfo.processInfo.environment[key] == nil, "No external storage override is eligible")
        }
        XCUIDevice.shared.orientation = .landscapeLeft
        launchWithTier(.production, backend: "otzaria", extraArgs: [
            "-GlobalSearchNativeTraceEnabled", "YES", "-GlobalSearchNativeTraceNamespace", receipt.traceBaseline.namespace,
            "-lastSelectedTab", "0", "-ChavrusaTextFaithfulReaderUIEnabled", "YES"
        ])
        try requireSearchDataFixture(!app.launchArguments.contains("-smokeBypassBootstrap")
            && !app.launchArguments.contains("-studyWorkspaceTestingNamespace")
            && app.launchEnvironment["OTZARIA_DATA_PROFILE"] == "production", "Keep the original production workspace and provider")
        try ui.wait("Normal production bootstrap must expose the original root tabs", timeout: 120) { self.app.tabBars.firstMatch.exists }
        try ui.returnToOriginalSearch()
        try ui.require("global-search-query")
    }

    @MainActor
    private func reachDataControl(_ id: String) throws -> XCUIElement {
        for _ in 0..<8 {
            let value = ui.control(id)
            if value.exists && value.isHittable { return value }
            try ui.require("search-data-screen").swipeUp()
        }
        throw SearchDataNativeFixtureError.rejected("The original Search Data control is not reachable: " + id)
    }

    @MainActor
    private func rejectQuery(engine: String, receipt: Receipt, container: URL) throws -> [String: Any] {
        try ui.require("global-search-mode").tap()
        try ui.require("global-search-mode-" + (engine == "zayit" ? "zayit" : "exact")).tap()
        if engine == "zayit" {
            try ui.require("global-search-options").tap()
            for _ in 0..<6 {
                if ui.control("global-search-zayit-match").isHittable { break }
                try ui.require("global-search-options-content").swipeUp()
            }
            try ui.require("global-search-zayit-match").tap()
            let choice = app.buttons["גמיש — מרחק 5 מילים"]
            try requireSearchDataFixture(choice.waitForExistence(timeout: 15) && choice.isHittable, "Choose an original valid Zayit query option")
            choice.tap()
            try ui.require("global-search-options-done").tap()
        }
        let field = try ui.require("global-search-query")
        field.tap()
        if let old = field.value as? String, old != field.placeholderValue && !old.isEmpty {
            field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old.count))
        }
        let query = "בראשית"
        field.typeText(query)
        try ui.wait("Require the exact original entered query") { field.value as? String == query }
        let before = try trace(receipt, container: container)
        let started = Date().timeIntervalSince1970
        field.typeText("\n")
        let submitted = Date().timeIntervalSince1970
        let mismatch = receipt.after.database.bytes == 4_355_063_808
            ? "the index was built for a different DB release" : "database size/identity mismatch"
        let expected = engine == "otzaria" ? "חבילת חיפוש Otzaria אינה תואמת לספרייה זו."
            : "The Zayit index failed validation: The Zayit index is incompatible: " + mismatch
        let error = try ui.require("global-search-error", timeout: 180)
        let text = error.descendants(matching: .staticText).matching(NSPredicate(format: "label == %@", expected)).firstMatch
        try ui.wait("The original error must disclose this actual library/index mismatch", timeout: 30) {
            text.exists && text.isHittable && !self.ui.control("global-search-loading").exists
        }
        let rejected = Date().timeIntervalSince1970
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "search-result-preview-toggle-"))
        let stale = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            MainActor.assumeIsolated { rows.count > 0 || self.ui.control("global-search-count").exists
                || self.ui.control("global-search-page-error").exists || !text.exists }
        }, object: nil)
        stale.isInverted = true
        XCTAssertEqual(XCTWaiter.wait(for: [stale], timeout: 3), .completed,
                       "The settled rejection must not be replaced by an old page")
        XCTAssertEqual(field.value as? String, query)
        XCTAssertFalse(ui.control("global-search-dirty").exists)
        XCTAssertTrue(ui.control("global-search-retry").isHittable)
        XCTAssertEqual(rows.count, 0)
        let after = try trace(receipt, container: container)
        XCTAssertEqual(after.identity, before.identity)
        XCTAssertEqual(after.data, before.data, "No provider/published page may append after the bound original offset")
        ui.capture("r08-after-books-update-" + engine + "-original-rejection")
        return ["engine": engine, "querySHA256": searchDataDigest(Data(query.utf8)),
                "expectedLogScope": engine == "otzaria" ? "exact" : "zayit",
                "expectedSubmissionRevision": engine == "otzaria" ? 1 : 2,
                "startedAtUnix": started, "submittedAtUnix": submitted, "rejectedAtUnix": rejected,
                "finishedAtUnix": Date().timeIntervalSince1970, "visibleError": expected,
                "traceOffsetBefore": before.identity.bytes, "traceOffsetAfter": after.identity.bytes,
                "traceSHA256Before": searchDataDigest(before.data), "traceSHA256After": searchDataDigest(after.data)]
    }

    @MainActor
    func testOriginalBooksUpdateRetainsV40PackagesButRejectsTheirReadinessAndQueries() throws {
        let (receipt, digest) = try receipt()
        let launchStarted = Date().timeIntervalSince1970
        try launch(receipt)
        let installed = try installation(receipt)
        try verifyRetained(receipt, root: installed.root)
        let baseline = try trace(receipt, container: installed.container)
        try ui.require("global-search-more").tap()
        try ui.require("global-search-data").tap()
        let otzaria = try ui.require("search-data-otzaria-status")
        let zayit = try ui.require("search-data-zayit-status")
        let originalMismatch = "זהות האינדקס אינה תואמת למסד, למנוע או למשאבים הפעילים."
        let zayitMismatch = receipt.after.database.bytes == 4_355_063_808
            ? "the index was built for a different DB release" : "database size/identity mismatch"
        try ui.wait("Both original package statuses must reject the retained v40 source", timeout: 180) {
            otzaria.label == "נדרש תיקון לאינדקס: " + originalMismatch
                && (zayit.label == "אין עדיין חבילה תואמת לגרסת מסד זו"
                    || zayit.label == "נדרש תיקון · The Zayit index is incompatible: " + zayitMismatch)
        }
        XCTAssertEqual(try ui.require("search-data-books-status").label, "מוכן")
        let statusLabels = ["otzaria": otzaria.label, "zayit": zayit.label]
        ui.capture("r08-after-books-update-original-search-data-rejects-v40")
        try reachDataControl("search-data-close").tap()
        try ui.wait("Close original Search Data before using the original query field") { self.ui.control("global-search-query").isHittable }
        var attempts: [[String: Any]] = []
        for engine in ["otzaria", "zayit"] { attempts.append(try rejectQuery(engine: engine, receipt: receipt, container: installed.container)) }
        try verifyRetained(receipt, root: installed.root)
        let final = try trace(receipt, container: installed.container)
        XCTAssertEqual(final.identity, baseline.identity)
        XCTAssertEqual(final.data, baseline.data)
        let proof: [String: Any] = [
            "schemaVersion": 1, "scope": "cold post-Settings original UI; active host process-log verification additionally required",
            "settingsReceiptSHA256": digest, "simulatorUDID": receipt.simulatorUDID, "dataContainer": installed.container.path,
            "storageRoot": installed.root.path, "namespace": receipt.traceBaseline.namespace,
            "sourceProcessID": receipt.traceBaseline.processID, "sourceCaseID": receipt.traceBaseline.caseID,
            "sourceXcresult": receipt.traceBaseline.xcresultPath, "sourceAttachmentSHA256": receipt.traceBaseline.sourceAttachment.sha256,
            "tracePath": installed.container.appendingPathComponent(receipt.traceBaseline.relativePath).path,
            "traceIdentity": try object(JSONEncoder().encode(final.identity)), "traceSHA256": searchDataDigest(final.data),
            "beforeManifestSHA256": receipt.before.installationManifest.sha256,
            "afterManifestSHA256": receipt.after.installationManifest.sha256,
            "launchStartedAtUnix": launchStarted, "finishedAtUnix": Date().timeIntervalSince1970,
            "launchArguments": app.launchArguments, "launchEnvironment": app.launchEnvironment,
            "searchDataLabels": statusLabels, "attempts": attempts,
            "warmSameProcessUpdateVerified": false, "hostProcessLogGateRequired": true
        ]
        let evidence = XCTAttachment(data: try canonical(proof), uniformTypeIdentifier: "public.json")
        evidence.name = "production-search-after-books-update-original-ui-and-trace-boundary"
        evidence.lifetime = .keepAlways
        add(evidence)
    }
}

// Test-only original-control observation around the final ordinary Settings Retry.
// The Settings test owns the two calls and must not terminate/relaunch between them.
@MainActor
struct OriginalSearchDataUpdateReadiness {
    struct Observation {
        fileprivate let sequenceID: String
        fileprivate let processID: Int
        fileprivate let capturedAtUnix: TimeInterval
        fileprivate let hierarchySHA256: String
        fileprivate let statuses: [String: String]
    }

    let app: XCUIApplication
    let test: XCTestCase
    private var ui: OriginalSearchContextUI { OriginalSearchContextUI(app: app, test: test) }

    private func admitOriginalSettingsLaunch() throws {
        for (key, value) in [("-OtzariaDataProfile", "production"), ("-preferredBackend", "otzaria"),
                             ("-AppleLanguages", "(en)"), ("-AppleLocale", "en_US")] {
            let positions = app.launchArguments.indices.filter { app.launchArguments[$0] == key }
            try requireSearchDataFixture(positions.count == 1, "Require the original English production Settings launch")
            let index = try XCTUnwrap(positions.first)
            try requireSearchDataFixture(app.launchArguments.indices.contains(index + 1)
                && app.launchArguments[index + 1] == value, "Unexpected original Settings launch value: " + key)
        }
        try requireSearchDataFixture(app.launchEnvironment["OTZARIA_DATA_PROFILE"] == "production"
            && !app.launchArguments.contains("-smokeBypassBootstrap")
            && !app.launchArguments.contains("-studyWorkspaceTestingNamespace"), "Keep the actual ordinary production workspace")
        for key in ["OTZARIA_SHARED_ROOT_OVERRIDE", "OTZARIA_PRODUCTION_DB_PATH"] {
            try requireSearchDataFixture(app.launchEnvironment[key] == nil
                && app.launchEnvironment["SIMCTL_CHILD_" + key] == nil, "No alternate source is eligible for warm update readiness")
        }
    }

    private func observedProcess(_ name: String) throws -> (id: Int, hierarchySHA256: String) {
        try requireSearchDataFixture(app.state == .runningForeground, "Observe the original foreground application")
        let hierarchy = app.debugDescription
        // XCTest's public original application hierarchy reports its own pid.
        // Require that actual field; never substitute the UI-test runner PID.
        let expression = try NSRegularExpression(pattern: #"(?m)^\s*(?:Attributes:\s*)?(?:→\s*)?Application,[^\r\n]*?\bpid:\s*([0-9]+)\b"#)
        let range = NSRange(hierarchy.startIndex..<hierarchy.endIndex, in: hierarchy)
        let matches = expression.matches(in: hierarchy, range: range)
        let identities = Set(matches.compactMap { match -> Int? in
            guard let value = Range(match.range(at: 1), in: hierarchy) else { return nil }
            return Int(hierarchy[value])
        })
        try requireSearchDataFixture(!matches.isEmpty && identities.count == 1,
            "The original public XCTest hierarchy must identify exactly one application PID")
        let pid = try XCTUnwrap(identities.first)
        try requireSearchDataFixture(pid > 1 && pid != Int(ProcessInfo.processInfo.processIdentifier),
            "A UI-test runner PID is not the observed application")
        let attachment = XCTAttachment(string: hierarchy)
        attachment.name = name + "-actual-application-pid-hierarchy"
        attachment.lifetime = .keepAlways
        test.add(attachment)
        return (pid, searchDataDigest(Data(hierarchy.utf8)))
    }

    private func dismissOriginalSettingsIfPresent() throws {
        let done = ui.control("settings-done-button")
        let updates = app.navigationBars["Library Updates"]
        if updates.exists && !done.isHittable {
            let back = updates.buttons.matching(NSPredicate(format: "label == %@", "Settings"))
                .allElementsBoundByIndex.filter(\.isHittable)
            try requireSearchDataFixture(back.count == 1, "Return through the original Library Updates back action")
            back[0].tap()
        }
        if done.exists {
            try requireSearchDataFixture(done.isHittable, "The original Settings Done action must be usable")
            done.tap()
            try ui.wait("Original Settings must dismiss without relaunch") { !self.ui.control("settings-done-button").exists }
        }
        try requireSearchDataFixture(!updates.exists, "Dismiss the original update presentation before using root Search")
    }

    private func openOriginalSearchData() throws {
        try dismissOriginalSettingsIfPresent()
        try ui.returnToOriginalSearch()
        try ui.require("global-search-more").tap()
        try ui.require("global-search-data").tap()
        try ui.require("search-data-screen")
    }

    private func closeOriginalDataAndReturnToLibrary() throws {
        for _ in 0..<8 {
            if ui.control("search-data-close").isHittable { break }
            try ui.require("search-data-screen").swipeUp()
        }
        let close = try ui.require("search-data-close")
        try requireSearchDataFixture(close.isHittable, "Reach the original Search Data close control")
        close.tap()
        try ui.wait("Original Search Data must dismiss") { !self.ui.control("search-data-screen").exists }
        let tabs = app.tabBars.buttons.matching(NSPredicate(format: "label == %@", "Library"))
            .allElementsBoundByIndex.filter { $0.isHittable && $0.frame.intersects(app.frame) }
        try requireSearchDataFixture(tabs.count == 1, "Require one original root Library tab in the admitted English UI")
        tabs[0].tap()
        try ui.wait("Return to the existing original Library tab without opening a book") { tabs[0].isSelected }
    }

    private func record(_ observation: Observation, previous: Observation?, updatedDatabaseBytes: Int64?) throws {
        let stem = previous == nil ? "settings-update-warm-search-ready-before-final-retry"
            : "settings-update-warm-search-mismatch-after-final-retry"
        var value: [String: Any] = [
            "schemaVersion": 1, "sequenceID": observation.sequenceID,
            "processID": observation.processID, "capturedAtUnix": observation.capturedAtUnix,
            "applicationHierarchySHA256": observation.hierarchySHA256, "statuses": observation.statuses,
            "phase": previous == nil ? "ready-before-final-original-retry" : "mismatch-after-final-original-retry",
            "processIdentitySource": "actual public XCUIApplication.debugDescription Application pid field",
            "launchArguments": app.launchArguments,
            "scope": "same-process original Search Data readiness around the final Settings Retry; no query, download, repair, Reader navigation or localization acceptance"
        ]
        if let previous {
            value["previousProcessID"] = previous.processID
            value["previousCapturedAtUnix"] = previous.capturedAtUnix
            value["previousApplicationHierarchySHA256"] = previous.hierarchySHA256
        }
        if let updatedDatabaseBytes { value["actualUpdatedDatabaseBytes"] = updatedDatabaseBytes }
        let attachment = XCTAttachment(data: try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]),
                                       uniformTypeIdentifier: "public.json")
        attachment.name = stem
        attachment.lifetime = .keepAlways
        test.add(attachment)
    }

    func captureReadyBeforeFinalRetry() throws -> Observation {
        try admitOriginalSettingsLaunch()
        let before = try observedProcess("settings-update-warm-before-navigation")
        try openOriginalSearchData()
        let books = try ui.require("search-data-books-status")
        let otzaria = try ui.require("search-data-otzaria-status")
        let zayit = try ui.require("search-data-zayit-status")
        // These runtime status strings are the exact original Source values,
        // including in en_US; this test does not claim their localization.
        try ui.wait("Both actual installed v40 packages must be Ready in this process before the final update", timeout: 180) {
            books.label == "מוכן" && otzaria.label == "האינדקס מוכן (7925185 מסמכים)"
                && zayit.label == "מוכן · v40-20261123094345"
        }
        let actual = try observedProcess("settings-update-warm-ready")
        try requireSearchDataFixture(actual.id == before.id, "Opening original Search Data must not relaunch the app")
        let observation = Observation(sequenceID: UUID().uuidString, processID: actual.id,
            capturedAtUnix: Date().timeIntervalSince1970, hierarchySHA256: actual.hierarchySHA256,
            statuses: ["books": books.label, "otzaria": otzaria.label, "zayit": zayit.label])
        ui.capture("settings-update-warm-original-search-data-ready")
        try closeOriginalDataAndReturnToLibrary()
        try requireSearchDataFixture(try observedProcess("settings-update-warm-ready-return").id == observation.processID,
            "The final original Retry must start in the process that observed both Ready packages")
        try record(observation, previous: nil, updatedDatabaseBytes: nil)
        return observation
    }

    func captureMismatchAfterFinalRetry(previous: Observation, updatedDatabaseBytes: Int64) throws -> Observation {
        try admitOriginalSettingsLaunch()
        try requireSearchDataFixture(updatedDatabaseBytes > 0, "Use the actual updated database file size")
        let before = try observedProcess("settings-update-warm-after-success-before-navigation")
        try requireSearchDataFixture(before.id == previous.processID,
            "A cold relaunch cannot satisfy same-process update readiness")
        try openOriginalSearchData()
        let books = try ui.require("search-data-books-status")
        let otzaria = try ui.require("search-data-otzaria-status")
        let zayit = try ui.require("search-data-zayit-status")
        let mismatch = updatedDatabaseBytes == 4_355_063_808
            ? "the index was built for a different DB release" : "database size/identity mismatch"
        let otzariaMismatch = "נדרש תיקון לאינדקס: זהות האינדקס אינה תואמת למסד, למנוע או למשאבים הפעילים."
        let zayitMismatches: Set<String> = ["אין עדיין חבילה תואמת לגרסת מסד זו",
                                           "נדרש תיקון · The Zayit index is incompatible: " + mismatch]
        try ui.wait("The same process must revoke both old v40 readiness states after actual Settings success", timeout: 180) {
            books.label == "מוכן" && otzaria.label == otzariaMismatch && zayitMismatches.contains(zayit.label)
        }
        let changed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            MainActor.assumeIsolated { books.label != "מוכן" || otzaria.label != otzariaMismatch
                || !zayitMismatches.contains(zayit.label) }
        }, object: nil)
        changed.isInverted = true
        try requireSearchDataFixture(XCTWaiter.wait(for: [changed], timeout: 3) == .completed,
            "The mismatch must remain settled instead of restoring stale Ready state")
        let actual = try observedProcess("settings-update-warm-mismatch")
        try requireSearchDataFixture(actual.id == previous.processID, "Only the original Ready process can satisfy the warm rejection")
        let observation = Observation(sequenceID: previous.sequenceID, processID: actual.id,
            capturedAtUnix: Date().timeIntervalSince1970, hierarchySHA256: actual.hierarchySHA256,
            statuses: ["books": books.label, "otzaria": otzaria.label, "zayit": zayit.label])
        try requireSearchDataFixture(observation.capturedAtUnix > previous.capturedAtUnix, "The mismatch must follow the actual Ready observation")
        ui.capture("settings-update-warm-original-search-data-mismatch")
        try closeOriginalDataAndReturnToLibrary()
        try requireSearchDataFixture(try observedProcess("settings-update-warm-mismatch-return").id == previous.processID,
            "Return to Library in the same original process before the separate cold final check")
        try record(observation, previous: previous, updatedDatabaseBytes: updatedDatabaseBytes)
        return observation
    }
}
