#!/usr/bin/env python3
"""One existing Catalyst exporter execution; no application/epoch acceptance."""
from pathlib import Path
import hashlib, importlib.util, json, os, platform, shutil, stat, subprocess, sys, time

sys.dont_write_bytecode = True
out = Path(sys.argv[1])
assert out.is_absolute() and out.resolve() == out and out.is_dir()
root = Path('/Users/m1/builds/otzaria-wave2-reader-controls-20261127/sqlite-fetch-wait-20261127T052034Z')
binary = root / 'CatalystControls'
expected_binary = 'daa58a1b273fde2dee7c37c4965d3a9c8bfa1ef009f918cf2bde5d4c39fc4683'
expected_result = '00a7e67662d7b3a92511be1a85d99dfad665e69f02acb80e9ece83391c37a7ee'
expected_helper = '4e2421361013659285c67459601bc705c2d89a2b7abe2313a0a4974b0b34dcee'
helper_path = out / 'study-ui-sqlite-wait.py'
result = {'schema': 1, 'status': 'CLOCK_EXPORTER_COMPONENT_PENDING',
          'helperCommit': 'daccf4096eec0f1851cdb5c7bfd277916e9310c9',
          'originalNativeCommit': '0b445db8a8ee5bc53a1a729c9b65693b51cc88fe',
          'directory': str(out), 'applicationUIExecuted': False,
          'productionCorpusOpened': False, 'epochCoverageGranted': False,
          'performanceAcceptance': False, 'nativeInvocationCount': 0,
          'scope': 'Actual host CPython Mach brackets plus ONE previously compiled Catalyst SQLite fixture companion export only; no original app request, MCM/corpus admission, resource epoch, native UI or PERF acceptance.'}

def witness(path):
    assert path.is_absolute() and path.resolve() == path and not path.is_symlink()
    before = path.stat(); assert stat.S_ISREG(before.st_mode)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''): h.update(data)
    after = path.stat()
    stable = lambda v: (v.st_dev, v.st_ino, v.st_mode, v.st_uid, v.st_gid, v.st_size, v.st_mtime_ns, v.st_ctime_ns)
    assert stable(before) == stable(after)
    return {'path': str(path), 'bytes': before.st_size, 'sha256': h.hexdigest(),
            'device': before.st_dev, 'inode': before.st_ino,
            'mtimeNs': before.st_mtime_ns, 'ctimeNs': before.st_ctime_ns}

def write(name, data):
    with (out / name).open('xb') as stream: stream.write(data)

def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def no_active_native_work(label):
    raw = subprocess.check_output(['ps', '-axo', 'pid=,comm=,args='])
    write(label + '.ps.txt', raw)
    blocked = []
    for line in raw.decode().splitlines():
        pieces = line.strip().split(None, 2)
        if len(pieces) >= 2 and Path(pieces[1]).name in {'swiftc', 'swift-frontend', 'swift-driver', 'xcodebuild', 'xctrace'}:
            blocked.append(line)
    result[label] = {'freeBytes': shutil.disk_usage(out).free, 'activeNativeCommands': blocked,
                     'processSnapshot': witness(out / (label + '.ps.txt'))}
    assert not blocked, 'Another native compiler/trace command is active; component not started'
    assert result[label]['freeBytes'] > 128 * 1024 * 1024, 'No small-control storage allowance'

try:
    no_active_native_work('admission')
    result['python'] = {'version': sys.version, 'executable': sys.executable,
                        'resolvedExecutable': witness(Path(sys.executable).resolve()),
                        'platform': platform.platform()}
    assert sys.platform == 'darwin' and sys.version_info[:2] == (3, 12)
    result['helper'] = witness(helper_path); assert result['helper']['sha256'] == expected_helper
    result['runner'] = witness(Path(__file__).resolve())
    result['originalNativeResult'] = witness(root / 'RESULT.json')
    assert result['originalNativeResult']['sha256'] == expected_result
    prior = json.loads((root / 'RESULT.json').read_bytes())
    result['originalCompile'] = next(row for row in prior['records'] if row['name'] == 'whole-observer-catalyst-compile')
    assert result['originalCompile']['exit'] == 0
    result['actualRetainedCompileInputs'] = {}
    for name, digest in prior['inputSHA256'].items():
        value = witness(root / name); assert value['sha256'] == digest
        result['actualRetainedCompileInputs'][name] = value
    result['binaryBefore'] = witness(binary)
    assert result['binaryBefore']['bytes'] == 600512 and result['binaryBefore']['sha256'] == expected_binary
    spec = importlib.util.spec_from_file_location('actual_clock_collector', helper_path)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    clock = helper.DarwinClock(); result['actualClock'] = clock.record
    no_active_native_work('immediatelyBeforeNative')
    fixture = out / 'fresh-catalyst-fixture'; assert not fixture.exists()
    env = os.environ.copy(); env['CHAVRUSA_FULL_V32_SOURCE_OBSERVATION'] = '1'
    command = [str(binary), 'companion-export', str(fixture)]
    result['nativeCommand'] = command
    result['actualOptIn'] = {'CHAVRUSA_FULL_V32_SOURCE_OBSERVATION': '1'}
    result['beforeNativeStart'] = clock.sample()
    child = subprocess.Popen(command, env=env, cwd=out, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    result['nativeInvocationCount'] = 1; result['childPID'] = child.pid
    try:
        stdout, stderr = child.communicate(timeout=15)
    except subprocess.TimeoutExpired:
        child.kill(); stdout, stderr = child.communicate(); raise
    finally:
        if 'stdout' in locals(): write('native.stdout', stdout)
        if 'stderr' in locals(): write('native.stderr', stderr)
    result['nativeExit'] = child.returncode
    assert child.returncode == 0, stderr.decode(errors='replace')
    native = json.loads(stdout)
    assert native['status'] == 'COMPONENT_CONTROL_PASS_NOT_APP_PERFORMANCE_ACCEPTANCE'
    assert native['case'] == 'companion-export' and native['processID'] == child.pid
    result['nativeComponentResult'] = native
    companion_path = fixture / 'source-request.sqlite-fetch-wait.json'
    raw = helper.read(companion_path, helper.MAX_SNAPSHOT)
    result['afterActualCompanionRead'] = clock.sample()
    snapshot = helper.validate_snapshot(helper.decode(raw), process_id=child.pid)
    helper.canonical_uuid(snapshot['requestID'])
    before = result['beforeNativeStart']['machLowerNs'] - clock.quantum
    after = result['afterActualCompanionRead']['machUpperNs'] + clock.quantum
    assert before <= snapshot['snapshotNanoseconds'] <= after
    assert snapshot['lifetimeStarted'] == snapshot['lifetimeFinished'] == 1
    assert snapshot['lifetimeDropped'] == 0 and snapshot['activeCount'] == 0
    assert len(snapshot['connections']) == 1
    identity = snapshot['connections'][0]['openedFile']
    assert identity['bytes'] == 8192 and identity['path'] == str(fixture / 'original-sqlite-control.db')
    result['actualExportClockBracket'] = {'status': 'ACTUAL_EXISTING_CATALYST_EXPORTER_CLOCK_BRACKET_VALIDATED_COMPONENT_ONLY',
        'lowerNanoseconds': before, 'snapshotNanoseconds': snapshot['snapshotNanoseconds'], 'upperNanoseconds': after,
        'requestID': snapshot['requestID'], 'processID': child.pid,
        'originalAppRequestProtocolExecuted': False, 'epochCoverageGranted': False}
    result['companion'] = witness(companion_path)
    result['fixtureDatabase'] = witness(fixture / 'original-sqlite-control.db')
    result['binaryAfter'] = witness(binary); assert result['binaryAfter'] == result['binaryBefore']
    result['status'] = 'ACTUAL_CLOCK_AND_EXISTING_EXPORTER_COMPONENT_PASS_NOT_UI_OR_EPOCH_COVERAGE'
except Exception as error:
    result['status'] = 'CLOCK_EXPORTER_COMPONENT_FAILED_OR_NOT_ADMITTED'
    result['error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    result['freeBytesAfter'] = shutil.disk_usage(out).free
    write('RESULT.json', json_bytes(result))
    print(json.dumps({'directory': str(out), 'status': result['status'],
                      'nativeInvocationCount': result['nativeInvocationCount'],
                      'result': witness(out / 'RESULT.json'), 'error': result.get('error')}))
sys.exit(0 if result['status'] == 'ACTUAL_CLOCK_AND_EXISTING_EXPORTER_COMPONENT_PASS_NOT_UI_OR_EPOCH_COVERAGE' else 1)
