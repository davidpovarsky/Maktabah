from pathlib import Path
import json,hashlib,importlib.util,datetime,traceback
root=Path(__file__).resolve().parent
source=root/"source"
result={"status":"STARTED_SOURCE_ONLY","nativeUIExecuted":0,"databaseReads":0,"searchProviderExecuted":False,"startedAtUTC":datetime.datetime.now(datetime.timezone.utc).isoformat()}
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
try:
 meta=json.loads((source/"SOURCE_PROVENANCE.json").read_bytes())
 for path,w in meta["files"].items():
  b=(source/path).read_bytes()
  assert len(b)==w["bytes"] and hashlib.sha256(b).hexdigest()==w["sha256"],path
 producer=load(source/"Scripts/CI/prepare-production-search-preview-oracle.py","producer")
 settings=load(source/"Scripts/CI/study-ui-settings-receipts.py","settings")
 cfg=json.loads((source/producer.PROFILE).read_bytes())
 snapshot={"checkoutSHA":meta["sourceCheckout"],"files":{p:{"path":str(source/p),**v} for p,v in meta["files"].items()},"catalogCompiledSources":cfg["catalog_compiled_sources"],"profile":{"path":str(source/producer.PROFILE),**meta["files"][producer.PROFILE]},"nativeUIExecuted":0,"searchProviderExecuted":False}
 receipt,binary=producer.compile_catalog(source,settings,snapshot,cfg,root/"compiled",Path("/Users/m1/builds/otzaria-wave2-library-controls-20261127/inspector-generation-attempt-2/module-cache"))
 result.update(status="ACTUAL_APPLE_ORIGINAL_SOURCE_COMPILE_PASS_ONLY",compileInputs=receipt,nativeExecutable=binary,sourceCheckout=meta["sourceCheckout"],producerSHA256=meta["files"]["Scripts/CI/prepare-production-search-preview-oracle.py"]["sha256"],sourceProvenanceSHA256=hashlib.sha256((source/"SOURCE_PROVENANCE.json").read_bytes()).hexdigest(),scope="Original whole Swift catalog/service/presentation compiled via candidate host compiler function; binary NOT executed, no corpus, provider, app or UI")
except BaseException as e:
 result.update(status="FAILED_SOURCE_ONLY",errorType=type(e).__name__,error=str(e));traceback.print_exc()
result["finishedAtUTC"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(root/"RESULT.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
raise SystemExit(0 if result["status"]=="ACTUAL_APPLE_ORIGINAL_SOURCE_COMPILE_PASS_ONLY" else 1)
