import Foundation

enum AppConfig { static let appSupportDir: URL? = nil }
@MainActor final class OtzariaMaktabahBridge {
    static let shared = OtzariaMaktabahBridge()
    var isEnabled: Bool { false }
    func installDatabase(from url: URL) throws { fatalError("Application bridge outside component scope") }
    func activateManagedDatabase(at url: URL) throws { fatalError("Application bridge outside component scope") }
    func restoreDatabaseIfPossible() throws -> Bool { fatalError("Application bridge outside component scope") }
    func resetConnection() { fatalError("Application bridge outside component scope") }
}
@MainActor final class OtzariaTantivySearchRepository {
    static let shared = OtzariaTantivySearchRepository()
    func closeAllEngines() { fatalError("Search engine outside component scope") }
}
