#!/usr/bin/env python3
"""Source-only historical argv/witness distinction, no compiler execution."""
import ast
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    out = BASE / "compiler-driver-controls"
    out.mkdir(exist_ok=False)
    source = BASE / "candidate/Scripts/CI/study-ui-pending-sql.py"
    spec = importlib.util.spec_from_file_location("pending_original_driver_gate_controls", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    old = gzip.decompress((BASE / "retained-artifact-controls-attempt-3/candidate.py.gz").read_bytes())
    tool = out / "tool-boundary"
    tool.mkdir()
    frontend = tool / "swift-frontend"
    frontend.write_bytes(b"EXPLICIT DUMMY TOOL; NEVER EXECUTE")
    driver = tool / "swiftc"
    driver.symlink_to(frontend)
    library = tool / "libzstd.dylib"
    library.write_bytes(b"EXPLICIT DUMMY DEPENDENCY; NEVER LINK")
    witness = lambda path: {"path": str(path.resolve(strict=True)), "bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
    root = out / "source-boundary"
    directory = out / "output-boundary"
    sources = [module.SERVICE_SOURCE, module.PRESENTATION_SOURCE]
    binary = str(directory / "original-source-catalog")
    args = [str(driver), "-parse-as-library", "-swift-version", "6", "-Xfrontend", "-strict-concurrency=complete", "-O",
            "-sdk", "/explicit-not-mounted/Control.sdk", "-module-cache-path", str(directory / "module-cache"),
            "-L", str(tool), "-lzstd", "-Xlinker", "-rpath", "-Xlinker", str(tool),
            *[str(root / name) for name in sources], str(root / module.SOURCE_PATHS[-1]), "-o", binary]
    compiled = {"command": args, "swiftc": witness(driver), "zstd": witness(library)}
    results, models = [], []

    def require(value):
        if not value:
            raise AssertionError("Original driver distinction control failed")

    def check(name, work):
        try:
            work(); results.append({"name": name, "passed": True})
        except BaseException as error:
            results.append({"name": name, "passed": False, "error": str(error)})

    def control(name, mutate=None, valid=False):
        value = copy.deepcopy(compiled)
        if mutate: mutate(value)
        error = None
        try:
            module.validate_compiler_invocation(value, sources, root, directory, binary)
        except ValueError as caught:
            error = str(caught)
        models.append({"name": name, "input": value, "rejected": error is not None, "error": error,
                       "scope": "EXPLICIT_LOCAL_DUMMY_TOOL_BOUNDARY_NO_COMPILER_EXECUTION"})
        require((error is None) == valid)

    check("prior resolved-witness argv comparison rejects a genuine driver/symlink shape",
          lambda: require(compiled["command"][0] != compiled["swiftc"]["path"] and driver.resolve() == frontend))
    check("original driver argv and resolved executable witness remain distinct",
          lambda: control("driver-preserved", valid=True))
    check("resolved frontend must not replace the actual driver argv zero",
          lambda: control("frontend-as-driver", lambda value: value["command"].__setitem__(0, value["swiftc"]["path"])))
    check("an unrelated executable is not the original compiler driver",
          lambda: control("other-program", lambda value: value["command"].__setitem__(0, "/tmp/other")))
    check("omitting an original service input is rejected",
          lambda: control("missing-source", lambda value: value["command"].remove(str(root / module.SERVICE_SOURCE))))
    check("changed original compile options are rejected",
          lambda: control("changed-options", lambda value: value["command"].__setitem__(value["command"].index("-O"), "-Onone")))
    def declarations(raw):
        tree = ast.parse(raw)
        answer = {}
        for node in tree.body:
            if isinstance(node, ast.FunctionDef): answer[node.name] = ast.dump(node, include_attributes=False)
            if isinstance(node, ast.ClassDef):
                for child in node.body:
                    if isinstance(child, ast.FunctionDef): answer[node.name + "." + child.name] = ast.dump(child, include_attributes=False)
        return answer
    before, after = declarations(old), declarations(source.read_bytes())
    check("all prior runtime/reconstruction/cleanup algorithms remain unchanged except the compiler-command extraction",
          lambda: require(all(after[name] == value for name, value in before.items() if name != "RetainedPendingEvidence.catalog")))
    (out / "source-models.json").write_text(json.dumps(models, sort_keys=True, indent=2) + "\n")
    (out / "candidate.py.gz").write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    (out / "runner.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    report = {"schema": 1, "status": "SOURCE_ORIGINAL_DRIVER_ARGV_CONTROLS_ONLY_NOT_COMPILATION",
        "passed": sum(row["passed"] for row in results), "total": len(results), "results": results,
        "candidateSHA256": sha(source.read_bytes()), "priorSHA256": sha(old),
        "runnerSHA256": sha(Path(__file__).read_bytes()), "modelsSHA256": sha((out / "source-models.json").read_bytes()),
        "swiftCompiles": 0, "nativeUIExecuted": 0, "databaseQueries": 0, "performanceAccepted": False}
    (out / "RESULT.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "total": report["total"], "resultSHA256": sha((out / "RESULT.json").read_bytes()),
                      "failures": [row for row in results if not row["passed"]]}))
    return 0 if report["passed"] == report["total"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
