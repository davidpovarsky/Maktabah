#!/usr/bin/env python3
"""Actual temporary-file ownership controls, with explicit injected failures.

No application, SQLite corpus, simulator, Swift compiler or thread executes.
"""
import errno
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import uuid

BASE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    out = BASE / "request-lifetime-controls"
    out.mkdir(exist_ok=False)
    current = BASE / "candidate/Scripts/CI/study-ui-pending-sql.py"
    oldraw = gzip.decompress((BASE / "interrupted-start-controls/candidate.py.gz").read_bytes())
    assert sha(oldraw) == "ca25743a35cb2182c402c2a5ac2da670154102fd7a08ea07aed6de9813c55089"
    old = out / "prior-ca25743a.py"
    old.write_bytes(oldraw)
    prior = load("pending_prior_request_lifetime", old)
    candidate = load("pending_current_request_lifetime", current)
    wait = load("pending_original_wait_request_controls", BASE.parent / "sqlite-wait-host/study-ui-sqlite-wait.py")
    results, models = [], []

    def require(value):
        if not value:
            raise AssertionError("Actual local filesystem control did not meet its explicit boundary")

    def check(name, work):
        try:
            work()
            results.append({"name": name, "passed": True})
        except BaseException as error:
            results.append({"name": name, "passed": False, "error": type(error).__name__ + ":" + str(error)})

    def fault_capture(module, name):
        folder = out / name
        folder.mkdir()
        (folder / "artifacts").mkdir()
        (folder / "db-boundary.bin").write_bytes(b"NOT_A_DATABASE_SOURCE_ONLY_BOUNDARY")
        (folder / "manifest-boundary.json").write_bytes(b"{}")
        request_path = folder / "app-facing-request.txt"

        def full(*_args, **_kwargs):
            raise OSError(errno.ENOSPC, "Explicit evidence-write failure after earlier source steps")

        boundary_wait = SimpleNamespace(**{name: getattr(wait, name) for name in dir(wait) if not name.startswith("__")})
        boundary_wait.write_new = full
        instance = module.PendingRecorder.__new__(module.PendingRecorder)
        instance.wait = boundary_wait
        instance.out = folder / "artifacts"
        instance.idle = lambda: None
        instance.catalog_allocated_bytes = 0
        instance.request_lifetimes = []
        instance.admission = {
            "database": {"path": str(folder / "db-boundary.bin"), "identity": wait.identity(folder / "db-boundary.bin")},
            "installationManifest": wait.witness(folder / "manifest-boundary.json"),
        }
        instance.clock = SimpleNamespace(sample=lambda: {"explicitClockBoundaryOnly": True})
        state = {"captures": [], "folder": folder / "artifacts", "paths": {"request": request_path}}
        error = None
        try:
            instance._capture(state, "baseline")
        except BaseException as caught:
            error = type(caught).__name__
        value = {"name": name, "exception": error, "requestRemained": request_path.exists(),
                 "requestBody": request_path.read_text() if request_path.exists() else None,
                 "requestLifetimes": instance.request_lifetimes,
                 "boundary": "REAL_LOCAL_FILES; injected ENOSPC; non-database byte file and clock boundary; no capture/app execution"}
        models.append(value)
        return value

    old_value = fault_capture(prior, "prior-real-file-leak")
    check("prior ca257 actual request file survives the pre-guard ENOSPC counterexample",
          lambda: require(old_value["exception"] == "OSError" and old_value["requestRemained"]))
    new_value = fault_capture(candidate, "candidate-evidence-before-request")
    check("candidate evidence failure happens before any app-facing request creation",
          lambda: require(new_value["exception"] == "OSError" and not new_value["requestRemained"] and not new_value["requestLifetimes"]))

    def lifetime(name, action, *, write_fault=False):
        folder = out / name
        folder.mkdir()
        path = folder / "request.txt"
        request_id = str(uuid.uuid4()).upper()
        records = []
        error = None
        original_write = candidate.os.write
        writes = []

        def partial(fd, raw):
            if writes:
                raise OSError(errno.ENOSPC, "Explicit actual partial-write continuation failure")
            written = original_write(fd, raw[:7])
            writes.append(written)
            return written

        try:
            if write_fault:
                with patch.object(candidate.os, "write", partial):
                    with candidate.owned_source_request(wait, path, request_id, records):
                        raise AssertionError("Partial failed write must not reach its body")
            else:
                with candidate.owned_source_request(wait, path, request_id, records):
                    action(path, request_id, folder)
        except BaseException as caught:
            error = type(caught).__name__
        value = {"name": name, "requestID": request_id, "exception": error, "lifetimes": records,
                 "pathExists": path.exists(), "pathIsSymlink": path.is_symlink(),
                 "retainedBody": path.read_text() if path.exists() else None,
                 "scope": "ACTUAL_LOCAL_FILE_OWNERSHIP_WITH_EXPLICIT_INJECTED_BOUNDARY_NOT_APP"}
        models.append(value)
        return value

    normal = lifetime("normal-retirement", lambda *_: None)
    check("normal exact fd inode and UUID body retire and close",
          lambda: require(normal["exception"] is None and not normal["pathExists"]
                          and normal["lifetimes"][0]["retirementVerified"] and normal["lifetimes"][0]["descriptorClosed"]))

    def failure(*_):
        raise OSError(errno.EIO, "Explicit post-creation identity/read failure")

    failed = lifetime("failure-after-creation", failure)
    check("a failure anywhere after creation retires the proven owned request",
          lambda: require(failed["exception"] == "OSError" and not failed["pathExists"]
                          and failed["lifetimes"][0]["retirementVerified"] and failed["lifetimes"][0]["descriptorClosed"]))

    partial = lifetime("partial-known-write", lambda *_: None, write_fault=True)
    check("known exact partial write is retired after ENOSPC without an unknown body",
          lambda: require(partial["exception"] == "OSError" and not partial["pathExists"]
                          and partial["lifetimes"][0]["bytesWritten"] == 7
                          and partial["lifetimes"][0]["retirementVerified"]))

    def replace(path, request_id, folder):
        path.rename(folder / "retained-original.txt")
        path.write_text(request_id)

    replaced = lifetime("same-body-new-inode", replace)
    check("an equal UUID body in a replacement inode is preserved and unverified",
          lambda: require(replaced["exception"] == "ValueError" and replaced["pathExists"]
                          and not replaced["lifetimes"][0]["retirementVerified"]
                          and replaced["lifetimes"][0]["descriptorClosed"]))

    changed = lifetime("changed-owned-body", lambda path, *_: path.write_text("REPLACED-BODY"))
    check("a changed body cannot authorize deletion from the same inode",
          lambda: require(changed["exception"] == "ValueError" and changed["retainedBody"] == "REPLACED-BODY"
                          and not changed["lifetimes"][0]["retirementVerified"]))

    def symlink(path, request_id, folder):
        path.rename(folder / "retained-original.txt")
        (folder / "foreign.txt").write_text(request_id)
        path.symlink_to(folder / "foreign.txt")

    redirected = lifetime("replaced-symlink", symlink)
    check("a redirected replacement remains intact and cannot authorize handoff",
          lambda: require(redirected["exception"] == "ValueError" and redirected["pathIsSymlink"]
                          and not redirected["lifetimes"][0]["retirementVerified"]))

    missing = lifetime("externally-removed-request", lambda path, *_: path.unlink())
    check("unexplained external request removal is conservative and closes the held descriptor",
          lambda: require(missing["exception"] == "ValueError" and not missing["pathExists"]
                          and not missing["lifetimes"][0]["retirementVerified"]
                          and missing["lifetimes"][0]["descriptorClosed"]))

    # The replacement remains an unresolved request even when evidence storage
    # itself fails: the state must be published in memory first.
    record = candidate.PendingSQLHost.__new__(candidate.PendingSQLHost)
    record.core = SimpleNamespace(OUT=out)
    record.cleanup_receipt = None
    record.cleanup_state = None
    record.owned_activity_exited = False
    record.start_attempted = record.started = True
    record.host = SimpleNamespace(ident=1, stop=lambda: None, is_alive=lambda: False,
        pending_sql=SimpleNamespace(active=None, request_lifetimes=replaced["lifetimes"]),
        error=None, active=None, pending_inspector=None, epochs={}, reader_complete=None, inspector_complete=None)

    def full(*_args, **_kwargs):
        raise OSError(errno.ENOSPC, "Explicit cleanup receipt ENOSPC")

    record.wait = SimpleNamespace(seal=full)
    try:
        record.stop()
    except OSError:
        pass
    models.append({"name": "unverified-request-and-enospc", "inMemory": record.cleanup_state,
                   "receipt": record.cleanup_receipt, "ownedActivityExited": record.owned_activity_exited})
    check("an unresolved request keeps in-memory exit false even when cleanup evidence is full",
          lambda: require(record.cleanup_receipt is None and record.owned_activity_exited is False
                          and record.cleanup_state["ownedRequestRetirementVerified"] is False))

    (out / "actual-file-controls-and-injected-boundaries.json").write_text(json.dumps(models, sort_keys=True, indent=2) + "\n")
    report = {"schema": 1, "status": "SOURCE_LOCAL_FILESYSTEM_REQUEST_LIFETIME_CONTROLS_ONLY",
              "passed": sum(row["passed"] for row in results), "total": len(results), "results": results,
              "priorSourceSHA256": sha(oldraw), "candidateSourceSHA256": sha(current.read_bytes()),
              "runnerSHA256": sha(Path(__file__).read_bytes()),
              "modelSHA256": sha((out / "actual-file-controls-and-injected-boundaries.json").read_bytes()),
              "nativeUIExecuted": 0, "swiftCompiles": 0, "databaseQueries": 0, "performanceAccepted": False}
    (out / "RESULT.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    (out / "candidate.py.gz").write_bytes(gzip.compress(current.read_bytes(), mtime=0))
    (out / "runner.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    print(json.dumps({"passed": report["passed"], "total": report["total"], "resultSHA256": sha((out / "RESULT.json").read_bytes()),
                      "failures": [row for row in results if not row["passed"]]}))
    return 0 if report["passed"] == report["total"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
