#!/usr/bin/env python3
"""Linux/source-only negative gates. Synthetic models are never native proof."""
import argparse, copy, gzip, hashlib, importlib.util, json, pathlib, tempfile, threading, types, uuid
P=pathlib.Path
BASE=P(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def digest(raw):return hashlib.sha256(raw).hexdigest()

def uid():return str(uuid.uuid4()).upper()

def main():
    args=argparse.ArgumentParser();args.add_argument('--output',required=True);arg=args.parse_args()
    out=P(arg.output).resolve();out.mkdir(exist_ok=False)
    hostpath=BASE/'candidate/Scripts/CI/study-ui-pending-sql.py'
    waitpath=BASE.parent/'sqlite-wait-host/study-ui-sqlite-wait.py'
    host=load('pending_candidate_controls',hostpath);wait=load('pending_original_collector_controls',waitpath)
    results=[]; evaluations=[]; current_case={}
    def check(name,operation):
        current_case['name']=name
        try:operation();results.append({'name':name,'passed':True})
        except Exception as error:results.append({'name':name,'passed':False,'type':type(error).__name__,'error':str(error)})
    def expect(value,why='control assertion'):
        if not value:raise AssertionError(why)
    def rejects(call):
        try:call()
        except (ValueError,KeyError,TypeError,AssertionError):return
        raise AssertionError('candidate admitted the rejected source-model input')
    def witness(path):raw=path.read_bytes();return {'path':str(path),'bytes':len(raw),'sha256':digest(raw)}
    # One byte-exact actual retained Apple component schema input, consumed as
    # parser compatibility only. It is NOT a production corpus or UI sample.
    rawroot=BASE.parent/'reader-lockwait/retained-run02'
    transfer=json.loads((rawroot/'TRANSFER.json').read_bytes())
    name='catalyst-companion-fixture/source-request.sqlite-fetch-wait.json'
    raw=(rawroot/name).read_bytes();native=json.loads(raw)
    def actual_parser():
        expect(transfer['files'][name]=={'bytes':len(raw),'sha256':digest(raw)})
        wait.validate_snapshot(native,request_id=native['requestID'],process_id=native['processID'])
    check('actual retained Catalyst companion parses unchanged; component schema only',actual_parser)
    (out/'actual-component-companion.json').write_bytes(raw)
    (out/'original-component-transfer.json').write_bytes((rawroot/'TRANSFER.json').read_bytes())
    # Explicit synthetic state models for correlation edge cases. They never
    # replace records from an app/container and contain no real source content.
    conn=uid();op=uid();db={'path':'/source-control-only/seforim.db','identity':{'device':1,'inode':2,'bytes':4355063808,'mtimeNs':3,'ctimeNs':4}}
    connection={'connectionID':conn,'capturedNanoseconds':10,'identityStatus':wait.QUALIFIED_IDENTITY,
                'openedFile':{'path':db['path'],'device':1,'inode':2,'bytes':4355063808,'modifiedNanoseconds':3}}
    active={'sequence':1,'operationID':op,'connectionID':conn,'beginNanoseconds':100,'nativeThreadID':17,'mainThread':False}
    terminal={**active,'waitStartNanoseconds':110,'acquiredNanoseconds':120,'terminalNanoseconds':400,
              'lockAcquisitionWaitSeconds':1e-8,'taskCancelledAtTerminal':False,'returnedNormally':True}
    def snap(stamp,rows,done):
        return {'schema':1,'status':wait.NATIVE_STATUS,'scope':'Synthetic source-control state model, not app or performance evidence',
                'clock':'DispatchTime.uptimeNanoseconds','snapshotNanoseconds':stamp,'observedUptime':stamp/1e9,'requestID':uid(),'processID':99,
                **wait.CAPACITIES,'connections':[copy.deepcopy(connection)],'active':copy.deepcopy(rows),'completed':copy.deepcopy(done),
                'activeCount':len(rows),'completedRetainedCount':len(done),'lifetimeStarted':len(rows)+len(done),'lifetimeFinished':len(done),
                'lifetimeOverwritten':0,'lifetimeDropped':0,'lifetimeDroppedForActiveCapacity':0,'lifetimeDroppedForConnectionCapacity':0,
                'lifetimeUnmatchedCompletions':0,'counterOverflowed':False,'completeLifetimeCoverage':not rows}
    def overview(yes):return {'overviewPresentations':[{'wantsOverview':yes,'isViewLoaded':True,'isInWindow':True,
                'hasHostingController':True,'presentedClass':'SyntheticBoundaryController'}]}
    def capture(stamp,rows,done,visible,mode):
        s=snap(stamp,rows,done);wait.validate_snapshot(s)
        return {'snapshot':s,'viewport':overview(visible),'identity':{'processID':99,'ownerSHA256':'synthetic-owner'},
                'sourceComparison':{'mode':mode,'originalComparison':{'scope':'synthetic source comparator boundary'}} if mode else None,
                'armedOperation':host.operation_identity(active)}
    def model(cohort='overview'):
        a=capture(50,[],[],False,'line')
        early=capture(130,[active],[],False,'line')
        fence=capture(150,[active],[],False,'line')
        changed=capture(200,[active],[],True,'line')
        captures=[early,fence,changed]
        t=copy.deepcopy(terminal)
        if cohort=='unit-supersession':t['taskCancelledAtTerminal']=True;t['returnedNormally']=False
        b=capture(500,[],[t],False,'chapter' if cohort=='overview' else 'line')
        markers=[{'event':'chapter-request','hostObservedBeforeOriginalUIRequest':{'machLowerNs':90,'machUpperNs':92},'armedOperation':None},
                 {'event':'overview-action','hostObservedBeforeOriginalUIRequest':{'machLowerNs':155,'machUpperNs':157},
                  'freshPendingRequestID':fence['snapshot']['requestID'],'armedOperation':host.operation_identity(active)}]
        for index,event in enumerate(host.marker_sequence(cohort)[2:]):
            c=capture(220+20*index,[active],[],True,'line');captures.append(c)
            markers.append({'event':event,'hostObservedBeforeOriginalUIRequest':{'machLowerNs':225+20*index,'machUpperNs':227+20*index},
                            'freshPendingRequestID':c['snapshot']['requestID'],'armedOperation':host.operation_identity(active)})
        return a,captures,b,copy.deepcopy(db),cohort,markers
    success='ACTUAL_PENDING_FETCH_UI_OVERLAP_OBSERVED_NATIVE_SEMANTIC_VERIFICATION_REQUIRED'
    def evaluate(v):
        actual=host.evaluate_overlap(wait,*v)
        evaluations.append({'case':current_case.get('name'),'scope':'EXPLICIT_SYNTHETIC_STATE_MODEL_NOT_NATIVE',
                            'input':copy.deepcopy(v),'output':copy.deepcopy(actual)})
        return actual
    def denied(mutator,cohort='overview'):
        v=list(model(cohort));mutator(v);r=evaluate(v);expect(r['status']=='NOT_QUALIFIED',r)
    for cohort in host.COHORTS:
        check('synthetic complete '+cohort+' correlation remains native-unverified',lambda c=cohort:expect(evaluate(model(c))['status']==success))
    check('qualified correlation never grants performance or SQL stepping',lambda:expect(evaluate(model())['fullPerformanceAcceptance'] is False and evaluate(model())['exactSQLSteppingOrMappingAttribution'].startswith('NOT_QUALIFIED')))
    check('missing baseline cannot qualify',lambda:denied(lambda v:v.__setitem__(0,None)))
    check('missing terminal capture cannot qualify',lambda:denied(lambda v:v.__setitem__(2,None)))
    check('changed final actual process rejected',lambda:denied(lambda v:v[2]['snapshot'].__setitem__('processID',100)))
    check('mid-capture identity mismatch rejected',lambda:denied(lambda v:v[1][0]['identity'].__setitem__('ownerSHA256','other')))
    check('baseline source mode is necessary',lambda:denied(lambda v:v[0].__setitem__('sourceComparison',None)))
    check('wrong final complete mode is rejected',lambda:denied(lambda v:v[2]['sourceComparison'].__setitem__('mode','line')))
    check('prior overview cannot count as changed UI',lambda:denied(lambda v:v[0].__setitem__('viewport',overview(True))))
    check('no changed actual UIKit response rejects post-open credit',lambda:denied(lambda v:[c.__setitem__('viewport',overview(False)) for c in v[1]]))
    check('no independently matched actual source rejects overlap',lambda:denied(lambda v:[c.__setitem__('sourceComparison',None) for c in v[1]]))
    check('an unacquired wait is not active SQL-body evidence',lambda:denied(lambda v:v[2]['snapshot']['completed'][0].__setitem__('acquiredNanoseconds',None)))
    check('changed response before acquisition is rejected',lambda:denied(lambda v:v[2]['snapshot']['completed'][0].__setitem__('acquiredNanoseconds',220)))
    check('response after exact terminal is rejected',lambda:denied(lambda v:v[2]['snapshot']['completed'][0].__setitem__('terminalNanoseconds',190)))
    check('another operation cannot satisfy the active identity',lambda:denied(lambda v:[c['snapshot']['active'][0].__setitem__('operationID',uid()) for c in v[1]]))
    check('unknown native thread cannot qualify SQL overlap',lambda:denied(lambda v:(v[1][0]['armedOperation'].__setitem__('nativeThreadID',None),v[1][0]['snapshot']['active'][0].__setitem__('nativeThreadID',None),v[2]['snapshot']['completed'][0].__setitem__('nativeThreadID',None))))
    check('another opened inode cannot become current full-v40 SQL',lambda:denied(lambda v:v[2]['snapshot']['connections'][0]['openedFile'].__setitem__('inode',7)))
    check('missing operation terminal is rejected',lambda:denied(lambda v:v[2]['snapshot'].__setitem__('completed',[])))
    check('counter overflow cannot establish exhaustive coverage',lambda:denied(lambda v:v[0]['snapshot'].__setitem__('counterOverflowed',True)))
    for key in ('lifetimeDropped','lifetimeDroppedForActiveCapacity','lifetimeDroppedForConnectionCapacity','lifetimeUnmatchedCompletions'):
        check('prior '+key+' cannot hide a still-live untracked fetch',lambda key=key:denied(lambda v:(v[0]['snapshot'].__setitem__(key,1),v[2]['snapshot'].__setitem__(key,1))))
    check('baseline pending fetch is not a quiet original baseline',lambda:denied(lambda v:v[0]['snapshot'].__setitem__('active',[copy.deepcopy(active)])))
    check('pending final fetch cannot be silently omitted',lambda:denied(lambda v:v[2]['snapshot'].__setitem__('active',[copy.deepcopy(active)])))
    check('missing declared marker rejected',lambda:denied(lambda v:v[5].pop()))
    check('marker after actual terminal rejected',lambda:denied(lambda v:v[5][1]['hostObservedBeforeOriginalUIRequest'].__setitem__('machLowerNs',401)))
    check('marker requires fresh same-operation request UUID',lambda:denied(lambda v:v[5][1].__setitem__('freshPendingRequestID',uid())))
    check('reordered tab/backend actions rejected',lambda:denied(lambda v:v[5].__setitem__(slice(2,4),v[5][2:4][::-1]),'backend-and-tab'))
    check('unit supersession needs actual cancelled non-normal terminal',lambda:denied(lambda v:v[2]['snapshot']['completed'][0].__setitem__('taskCancelledAtTerminal',False),'unit-supersession'))
    check('cancel flag alone is not an exception classification',lambda:expect(evaluate(model('unit-supersession'))['cancellationExceptionClassification'].startswith('NOT_AVAILABLE')))
    check('an unseen persisting operation cannot be invented',lambda:denied(lambda v:[c.__setitem__('armedOperation',None) for c in v[1]]))
    check('overview already visible before its action cannot count as its response',lambda:denied(lambda v:v[1][1].__setitem__('viewport',overview(True))))
    check('UI response observed before the declared request is not attributed to that action',lambda:denied(lambda v:v[5][1]['hostObservedBeforeOriginalUIRequest'].update(machLowerNs=210,machUpperNs=212)))
    check('two action requests cannot reuse one purported fresh pending fence',lambda:denied(lambda v:v[5][3].__setitem__('freshPendingRequestID',v[5][2]['freshPendingRequestID']),'backend-and-tab'))
    check('new fetch predating the actual chapter request is not attributed to it',lambda:denied(lambda v:v[5][0]['hostObservedBeforeOriginalUIRequest'].update(machLowerNs=105,machUpperNs=107)))
    check('one observed pending snapshot is not proof of a persisting armed fetch',lambda:denied(lambda v:v[1].pop(0)))
    with tempfile.TemporaryDirectory(prefix='pending-sql-source-only-',dir=out) as tmp:
        directory=P(tmp)
        empty=directory/'empty.log';empty.write_bytes(b'')
        check('actual empty compiler log shape may be valid',lambda:expect(host.verify_log(wait,witness(empty))==b''))
        check('empty log witness cannot excuse nonempty log',lambda:rejects(lambda:host.verify_log(wait,{**witness(empty),'sha256':'0'*64})))
        other=directory/'other.log';other.write_bytes(b'actual controlled log')
        link=directory/'link.log';link.symlink_to(other)
        check('redirected compiler log is rejected',lambda:rejects(lambda:host.verify_log(wait,witness(link))))
        check('changed compile log is rejected',lambda:rejects(lambda:host.verify_log(wait,{**witness(other),'sha256':'0'*64})))
        # Synthetic large raw source solely tests nontruncation/admission math.
        # This file is local, temporary and NEVER admitted as production source.
        rows=[]
        for mode,start,end,text in [('line',26166,26166,'x'),('paragraph',26165,26166,'x\ny'),('chapter',0,52331,'x'*8307947)]:
            name=f'8042-{start}-{end}.source.utf8';(directory/name).write_text(text)
            rows.append({'key':'8042-pending-sql-'+mode,'bookID':8042,'bookTitle':'SOURCE-CONTROL-ONLY',
                         'focusLineIndex':26166,'unitID':'toc:1948815' if mode=='chapter' else 'synthetic',
                         'unitMode':mode,'unitStartLineIndex':start,'unitEndLineIndex':end,'unitRowCount':end-start+1,
                         'allOriginalAnchorsChecked':end-start+1,'anchorsIdentitySHA256':'a'*64,
                         'sectionLocator':f'otzaria|book:8042|line:{start}','focusLocator':'otzaria|book:8042|line:26166',
                         'sourceFile':name,'sourceUTF8Bytes':len(text.encode()),'sourceUTF16Length':len(text),
                         'sourceSHA256':digest(text.encode())})
        catalog={'schema':1,'status':'ORIGINAL_SOURCE_PENDING_SQL_MODES_ONLY_NOT_UI_OR_PERFORMANCE','corpusProfile':'full-v40',
                 'databaseSHA256':wait.DB_SHA,'uiExecuted':0,'searchProviderExecuted':False,'performanceObserved':False,
                 'sourceServiceSHA256':'b'*64,'presentationSourceSHA256':'c'*64,'catalogCompileInputsSHA256':'d'*64,'targets':rows}
        check('synthetic complete catalog metadata validates only shape; no service execution claim',lambda:expect(len(host.admit_pending_catalog(wait,catalog,directory))==3))
        for field,value in [('corpusProfile','full-v32'),('databaseSHA256','0'*64),('uiExecuted',1),('performanceObserved',True),('catalogCompileInputsSHA256','')]:
            check('wrong catalog '+field+' rejected',lambda f=field,v=value:rejects(lambda:host.admit_pending_catalog(wait,{**catalog,f:v},directory)))
        def reject_row(name,value):
            v=copy.deepcopy(catalog);v['targets'][2][name]=value;rejects(lambda:host.admit_pending_catalog(wait,v,directory))
        check('source path escape rejected',lambda:reject_row('sourceFile','../escape.source.utf8'))
        check('chapter prefix cannot replace 8,307,947 UTF16 source',lambda:reject_row('sourceUTF16Length',8307946))
        check('row-count truncation rejected',lambda:reject_row('unitRowCount',1000))
        check('source digest drift rejected',lambda:reject_row('sourceSHA256','0'*64))
        check('missing original all-anchor proof rejected',lambda:reject_row('allOriginalAnchorsChecked',0))
        check('changed canonical focus rejected',lambda:reject_row('focusLocator','otzaria|book:8042|line:0'))
        record=host.PendingRecorder.__new__(host.PendingRecorder)
        record.wait=wait;record.out=directory/'abort-cases';record.out.mkdir();record.results=[];record.active=None
        record.idle=lambda:None
        check('aborted first declared attempt is retained without invented native PID',lambda:expect(record.abort({'cohort':'overview','cohortID':uid(),'nativeFailure':'synthetic native setup failure'})['status']=='ABORTED_NOT_QUALIFIED'))
        check('cannot abort/retry the earlier cohort again',lambda:rejects(lambda:record.abort({'cohort':'overview','cohortID':uid(),'nativeFailure':'synthetic repeated attempt'})))
        check('failed cohort cannot become host completion',lambda:rejects(lambda:record.complete_case({})))
        base=types.SimpleNamespace(handle=lambda self,r,c:None)
        class BoundaryHost:
            def handle(self,request,container):raise AssertionError('Unexpected delegated resource action')
        composed=host.observation_host(BoundaryHost,types.SimpleNamespace(),directory,{})
        instance=composed.__new__(composed)
        check('standalone resource begin is refused',lambda:rejects(lambda:instance.handle({'action':'begin'},directory)))
        check('original Reader completion is not manufactured',lambda:rejects(lambda:instance.handle({'action':'complete_reader'},directory)))
        check('original Inspector completion is not manufactured',lambda:rejects(lambda:instance.handle({'action':'complete_inspector'},directory)))
        check('trace boundary cannot pretend measurement availability',lambda:rejects(lambda:host.RejectResourceTrace().require_running()))
        # The existing link is intentionally outside the new bounded directory.
        regular=directory/'budget-regular';regular.mkdir();(regular/'part').write_bytes(b'x'*8192)
        check('owned regular output allocated bytes are measured',lambda:expect(host.allocated_bytes(regular)>=8192))
        (regular/'alias').symlink_to(other)
        check('artifact-budget alias is rejected',lambda:rejects(lambda:host.allocated_bytes(regular)))
        def close_model(name,*,observer_alive,writer_alive,error,complete=False):
            folder=directory/name;folder.mkdir()
            def stop():
                if error:raise ValueError('synthetic owned shutdown failure')
            actual_host=types.SimpleNamespace(stop=stop,is_alive=lambda:observer_alive,
                 pending_sql=types.SimpleNamespace(active={'worker':types.SimpleNamespace(is_alive=lambda:writer_alive)} if writer_alive else None),
                 error=None,active=None,pending_inspector=None,epochs={},reader_complete=None,inspector_complete=None)
            recorder=host.PendingSQLHost.__new__(host.PendingSQLHost)
            recorder.wait=wait;recorder.core=types.SimpleNamespace(OUT=folder);recorder.host=actual_host
            recorder.cleanup_receipt=None;recorder.owned_activity_exited=False;recorder.started=True
            if not observer_alive and not writer_alive and not error:
                (folder/'pending-fetch-correctness').mkdir()
                wait.seal(folder/'pending-fetch-correctness/RESULT.json',{'status':'INCOMPLETE_NOT_QUALIFIED'})
            rejects(recorder.stop)
            proof=wait.decode(wait.verify_witness(recorder.cleanup_receipt))
            expect(proof['ownedActivityExited']==(not observer_alive and not writer_alive))
            expect(proof['simulatorReleaseOrRetentionAuthorized'] is False)
            expect(proof['nativeTestProcessGroupExit']=='NOT_OWNED_NOT_VERIFIED' and proof['urlTransportHostExit']=='NOT_OWNED_NOT_VERIFIED')
            return proof
        check('live observer keeps simulator handoff unqualified',lambda:close_model('close-live-observer',observer_alive=True,writer_alive=False,error=True))
        check('live passive writer keeps simulator handoff unqualified',lambda:close_model('close-live-writer',observer_alive=False,writer_alive=True,error=True))
        check('shutdown error is retained even after both threads exit',lambda:expect(close_model('close-error',observer_alive=False,writer_alive=False,error=True)['stopError'] is not None))
        check('quiescent incomplete case never becomes native completion',lambda:close_model('close-incomplete',observer_alive=False,writer_alive=False,error=False))
        # Same original Line/Paragraph boundaries are a legitimate source shape.
        # The comparator here is an explicitly synthetic boundary; no service or
        # UIKit execution is attributed to it.
        sourcefile=directory/'same-original-unit.utf8';sourcefile.write_bytes(b'x')
        sample={'requestID':uid(),'fullV32SourceObservation':{'status':'AVAILABLE','sourceUTF16Length':1,'processID':99},
                'nativeSelectionObservation':{'schema':1,'status':'EMPTY','processID':99,'locator':'same'}}
        sample['nativeSelectionObservation']['requestID']=sample['requestID']
        compare=host.PendingRecorder.__new__(host.PendingRecorder);compare.wait=wait;compare.pending_dir=directory
        compare.core=types.SimpleNamespace(exact_source_comparison=lambda directory,target,viewport:{'scope':'synthetic comparator boundary'})
        compare.references={mode:{'target':{'unitMode':mode,'sourceUTF16Length':1,'sectionLocator':'same'},'reference':witness(sourcefile)} for mode in ('line','paragraph')}
        check('identical genuine unit bodies do not invent a Line/Paragraph difference',lambda:expect(compare._source(sample,expected_mode='line')['mode']=='line'))
        check('source equality alone does not identify ambiguous UI mode',lambda:expect(compare._source(sample)['mode'] is None))
    before=(BASE.parent/'perf02-pending-proposal/Build8401SevenDefectsAcceptanceTests.swift').read_bytes()
    candidate=(BASE/'candidate/Maktabah-iOSUITests/Build8401SevenDefectsAcceptanceTests.swift').read_bytes()
    check('existing 102598-byte registered Swift case prefix remains byte exact',lambda:expect(len(before)==102598 and candidate[:len(before)]==before and digest(before)=='ca66d554b22f340366f0a68a7d3e43a4210eb143cbe2550fcdbabbead768b53c'))
    text=candidate[len(before):].decode()
    check('one additive exact registered selector only',lambda:expect(text.count('func testOriginalLargeChapterPendingFetchRemainsInteractiveAndRejectsSupersededContent(')==1 and 'XCTSkip' not in text))
    check('all cohorts may record failures without silencing them or changing the shared base',lambda:expect('continueAfterFailure = true' in text and 'defer { continueAfterFailure = priorContinuation }' in text and 'failures.isEmpty && declarations.count == 3' in text))
    check('native source does not perform SQL writes or seed ordinary workspace',lambda:expect('SQLITE_OPEN_READONLY | SQLITE_OPEN_NOMUTEX' in text and not any(term in text for term in ('INSERT INTO','UPDATE annotations','DELETE FROM','SQLITE_OPEN_READWRITE','-studyWorkspaceTestingNamespace", namespace'))))
    (out/'synthetic-model-inputs-and-results.json').write_text(json.dumps(evaluations,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    (out/'source-controls.py.gz').write_bytes(gzip.compress(P(__file__).read_bytes(),mtime=0))
    report={'schema':1,'status':'SOURCE_CONTROLS_ONLY_NOT_APP_OR_PERFORMANCE','scope':'Linux synthetic correlation/negative admission models plus one byte-exact retained Catalyst component parser input; no Swift compiler, corpus query, simulator, app or performance execution',
            'passed':sum(v['passed'] for v in results),'total':len(results),'results':results,
            'inputs':{'host':witness(hostpath),'waitCollector':witness(waitpath),'nativeCase':witness(BASE/'candidate/Maktabah-iOSUITests/Build8401SevenDefectsAcceptanceTests.swift'),'runner':witness(P(__file__).resolve()),
                      'actualComponent':{'bytes':len(raw),'sha256':digest(raw),'originalMacDirectory':transfer['originalMacDirectory'],'relativePath':name}},
            'nativeUIExecuted':0,'originalSourceCatalogExecuted':0,'performanceAccepted':False}
    (out/'RESULT.json').write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    (out/'candidate.py.gz').write_bytes(gzip.compress(hostpath.read_bytes(),mtime=0))
    (out/'native-addition.swift.gz').write_bytes(gzip.compress(candidate[len(before):],mtime=0))
    print(json.dumps({'passed':report['passed'],'total':report['total'],'result':str(out/'RESULT.json'),'sha256':digest((out/'RESULT.json').read_bytes()),'failures':[v for v in results if not v['passed']]},ensure_ascii=False))
    return 0 if report['passed']==report['total'] else 1

if __name__=='__main__':raise SystemExit(main())
