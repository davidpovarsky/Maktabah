#!/usr/bin/env python3
"""Read-only gate controls on explicitly synthetic retained-file models.

Actual parser/file hashing/clock arithmetic/arming replay/evaluate_overlap run.
Source comparator, native producer, MCM/admission, build and corpus are declared
boundaries here. No full phase is admitted and no native PASS is produced.
"""
import ast
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import uuid

BASE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def uid():
    return str(uuid.uuid4()).upper()


def main():
    out = BASE / "retained-artifact-controls-attempt-3"
    out.mkdir(exist_ok=False)
    path = BASE / "candidate/Scripts/CI/study-ui-pending-sql.py"
    module = load("pending_retained_gate_source_controls", path)
    wait = load("pending_retained_gate_original_wait", BASE.parent / "sqlite-wait-host/study-ui-sqlite-wait.py")
    settings = load("pending_retained_gate_original_attachment_parser", BASE.parent / "settings-post-update-contract/study-ui-settings-receipts.py")
    checks, attempts = [], []
    scope = "EXPLICIT_SYNTHETIC_SOURCE_GATE_MODEL_NOT_APPLICATION_NATIVE_OR_CORPUS_EVIDENCE"
    clock = {"machTimebaseNumer": 1, "machTimebaseDenom": 1, "integerConversionBoundNs": 2,
             "runtimeBrackets": [{"machBeforeTicks": n, "hostMonotonicNs": n + 1,
                 "machAfterTicks": n + 2, "machLowerNs": n, "machUpperNs": n + 2} for n in (1, 4, 7)]}

    def sample(stamp):
        return {"machBeforeTicks": stamp, "hostMonotonicNs": stamp + 1, "machAfterTicks": stamp + 2,
                "machLowerNs": stamp, "machUpperNs": stamp + 2}

    def check(name, work):
        try:
            work()
            checks.append({"name": name, "passed": True})
        except BaseException as error:
            checks.append({"name": name, "passed": False, "error": type(error).__name__ + ": " + str(error)})

    def require(value):
        if not value:
            raise AssertionError("Explicit source gate control failed")

    class EvidenceBoundary:
        def __init__(self, udid):
            self.udid, self.files, self.settings = udid, {}, settings

        def read_witness(self, record, *, maximum=8_000_000, json_value=True):
            raw = settings.verify_witness(record, maximum)
            self.files[record["path"]] = record
            return wait.decode(raw) if json_value else raw

        def read_path(self, path, *, maximum=8_000_000, json_value=True):
            record = settings.witness(path, maximum)
            return record, self.read_witness(record, maximum=maximum, json_value=json_value)

    def comparator(viewport, expected_mode=None):
        # Declared boundary: do not fabricate original service execution.
        mode = expected_mode or viewport["sourceComparatorBoundaryMode"]
        return {"mode": mode, "originalComparison": {"scope": "EXPLICIT_SOURCE_COMPARATOR_BOUNDARY"}}

    def model(name, cohort="overview"):
        phase = out / name
        phase.mkdir()
        target = phase / "pending-fetch-correctness"
        target.mkdir()
        ident, device, basename = uid(), uid(), "full-v32-reader-" + uid()
        folder = target / ident
        folder.mkdir()
        retained = module.RetainedPendingEvidence.__new__(module.RetainedPendingEvidence)
        retained.wait, retained.refs, retained.out, retained.phase_out = wait, {}, target, phase
        retained.evidence = EvidenceBoundary(device)
        retained.clock = copy.deepcopy(clock)
        app = phase / "SYNTHETIC_DEVICE_DATA_CONTAINER"
        retained.admission = {"owner": {"dataContainer": str(app), "storageRoot": str(app)},
            "installationManifest": {"sha256": "a" * 64},
            "installedImages": {"executable": "/synthetic-native-image-not-executed"}}
        retained.database = {"path": "/synthetic-corpus-never-created/seforim.db", "identity": {
            "device": 1, "inode": 2, "bytes": wait.DB_BYTES, "mtimeNs": 3, "ctimeNs": 4}}
        retained.comparator = SimpleNamespace(_source=comparator)
        identity = retained.expected_identity(99)
        connection_id, operation_id = uid(), uid()
        connection = {"connectionID": connection_id, "capturedNanoseconds": 10, "identityStatus": wait.QUALIFIED_IDENTITY,
            "openedFile": {"path": retained.database["path"], "device": 1, "inode": 2, "bytes": wait.DB_BYTES, "modifiedNanoseconds": 3}}
        active = {"sequence": 1, "operationID": operation_id, "connectionID": connection_id, "beginNanoseconds": 100,
                  "nativeThreadID": 17, "mainThread": False}
        terminal = {**active, "waitStartNanoseconds": 110, "acquiredNanoseconds": 120, "terminalNanoseconds": 400,
                    "lockAcquisitionWaitSeconds": 1e-8, "taskCancelledAtTerminal": cohort == "unit-supersession",
                    "returnedNormally": cohort != "unit-supersession"}
        rows = [("baseline", 50, False), ("during-original-ui-actions", 130, False),
                ("during-original-ui-actions", 140, False), ("fresh-before-overview-action", 150, False),
                ("during-original-ui-actions", 200, True)]
        rows += [("fresh-before-" + event, 220 + 20 * i, True) for i, event in enumerate(module.marker_sequence(cohort)[2:])]
        rows.append(("final", 500, False))
        records, values = [], []
        armed = None
        overlap = None
        for label, stamp, visible in rows:
            request = uid()
            capture_dir = folder / request
            capture_dir.mkdir()
            is_active = 100 <= stamp < 400
            done = [terminal] if stamp >= 400 else []
            snapshot = {"schema": 1, "status": wait.NATIVE_STATUS, "scope": scope,
                "clock": "DispatchTime.uptimeNanoseconds", "snapshotNanoseconds": stamp, "observedUptime": stamp / 1e9,
                "requestID": request, "processID": 99, **wait.CAPACITIES,
                "connections": [copy.deepcopy(connection)], "active": [copy.deepcopy(active)] if is_active else [], "completed": copy.deepcopy(done),
                "activeCount": int(is_active), "completedRetainedCount": len(done), "lifetimeStarted": int(is_active or bool(done)),
                "lifetimeFinished": len(done), "lifetimeOverwritten": 0, "lifetimeDropped": 0,
                "lifetimeDroppedForActiveCapacity": 0, "lifetimeDroppedForConnectionCapacity": 0,
                "lifetimeUnmatchedCompletions": 0, "counterOverflowed": False, "completeLifetimeCoverage": not is_active}
            wait.validate_snapshot(snapshot)
            companion = wait.seal(capture_dir / "sqlite-fetch-wait.json", snapshot)
            mode = "chapter" if label == "final" and cohort == "overview" else "line"
            viewport = {"requestID": request, "sourceComparatorBoundaryMode": mode,
                "fullV32SourceObservation": {"status": "AVAILABLE", "processID": 99},
                "overviewPresentations": [{"wantsOverview": visible, "isViewLoaded": True, "isInWindow": True,
                    "hasHostingController": True, "presentedClass": "EXPLICIT_SYNTHETIC_BOUNDARY"}],
                "sqliteFetchWaitObservation": {"schema": 1, "status": "AVAILABLE", "processID": 99, "requestID": request,
                    "snapshotPath": str(app / "Documents" / (basename + ".sqlite-fetch-wait.json")),
                    "bytes": companion["bytes"], "sha256": companion["sha256"],
                    **{key: snapshot[key] for key in ("completeLifetimeCoverage", "activeCount", "completedRetainedCount", "lifetimeDropped", "lifetimeOverwritten")}}}
            viewport_ref = wait.seal(capture_dir / "viewport.json", viewport)
            raw_request = wait.write_new(capture_dir / "request.txt", request.encode())
            capture = {"schema": module.SCHEMA, "label": label, "identity": identity, "snapshot": snapshot, "viewport": viewport,
                "raw": {"request": raw_request, "viewport": viewport_ref, "companion": companion},
                "sourceComparison": comparator(viewport, mode) if label in ("baseline", "final") else None,
                "clock": {"beforeRequestWrite": sample(stamp - 4), "afterCompanionRead": sample(stamp + 1),
                    "lowerNanoseconds": stamp - 6, "upperNanoseconds": stamp + 5},
                "armedOperation": armed}
            record = wait.seal(capture_dir / "CAPTURE.json", capture)
            records.append(record)
            capture = {**capture, "captureReceipt": record}
            if label == "during-original-ui-actions":
                if stamp == 140:
                    armed = module.operation_identity(active)
                capture["armedOperation"] = armed
                if stamp == 200:
                    overlap = record
                wait.seal(folder / (request + ".correlation.json"), {"capture": record, "armedOperation": armed, "changedWhilePending": overlap})
            values.append(capture)
        markers = []
        for event, stamp, index in [("chapter-request", 90, 0), ("overview-action", 155, 3)] + [
                (event, 225 + 20 * i, 5 + i) for i, event in enumerate(module.marker_sequence(cohort)[2:])]:
            marker = {"event": event, "hostObservedBeforeOriginalUIRequest": sample(stamp), "latestActualCapture": records[index],
                      "freshPendingRequestID": values[index]["snapshot"]["requestID"] if event != "chapter-request" else None,
                      "armedOperation": armed if event != "chapter-request" else None, "inputProcessingTimeQualified": False}
            markers.append(marker)
            wait.seal(folder / ("marker-" + event + ".json"), marker)
        for capture in values:
            if capture["sourceComparison"] is None and module.overview_visible(capture["viewport"]):
                comparison = comparator(capture["viewport"])
                wait.seal(folder / (capture["snapshot"]["requestID"] + ".source-comparison.json"), {
                    "capture": capture["captureReceipt"], "comparison": comparison,
                    "scope": "Actual original comparator after outstanding fetch/observation window"})
                capture["sourceComparison"] = comparison
        computed = module.evaluate_overlap(wait, values[0], values, values[-1], retained.database, cohort, markers)
        require(computed["status"].startswith("ACTUAL_PENDING_FETCH_UI_OVERLAP"))
        result = {**computed, "cohortID": ident, "processID": 99, "baseline": records[0], "final": records[-1],
                  "captures": records, "observationError": None, "semanticOutcome": {"scope": scope}}
        reference = wait.seal(folder / "RESULT.json", result)
        return retained, reference, result, values

    def run_model(name, mutation=None, *, accepted=False, cohort="overview"):
        retained, reference, result, captures = model(name, cohort)
        if mutation:
            mutation(retained, reference, result, captures)
        exception = None
        try:
            value = retained.cohort(reference, cohort)
        except (ValueError, KeyError, TypeError, FileNotFoundError, AssertionError) as error:
            exception = {"type": type(error).__name__, "message": str(error)}
            value = None
        attempts.append({"name": name, "scope": scope, "actualBoundaryResult": exception,
                         "inputResult": reference, "acceptedByCohortSubroutine": value is not None,
                         "fullPhaseAdmitted": False, "nativeUIExecuted": 0})
        require((value is not None) == accepted)

    for cohort in module.COHORTS:
        check("synthetic " + cohort + " raw-file reconstruction is internally consistent only",
              lambda cohort=cohort: run_model("consistent-" + cohort, accepted=True, cohort=cohort))

    def rewrite(path, value):
        Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")
        return settings.witness(path)

    def change_capture(retained, reference, result, captures, operation):
        index = 4
        ref = result["captures"][index]
        value = json.loads(Path(ref["path"]).read_bytes())
        operation(value)
        result["captures"][index] = rewrite(ref["path"], value)
        new = rewrite(reference["path"], result)
        reference.clear(); reference.update(new)

    check("changed raw companion cannot be accepted from the stored claimed success",
          lambda: run_model("changed-companion", lambda r, ref, result, c:
              Path(c[4]["raw"]["companion"]["path"]).write_bytes(b"{}")))
    check("absent original companion cannot fall back to the embedded snapshot",
          lambda: run_model("absent-companion", lambda r, ref, result, c:
              Path(c[4]["raw"]["companion"]["path"]).unlink()))
    check("changed metadata cannot substitute another app process",
          lambda: run_model("changed-pid", lambda *args: change_capture(*args, lambda v: v["identity"].update(processID=100))))
    check("foreign raw request path is rejected even when its bytes are unchanged",
          lambda: run_model("escaping-path", lambda *args: change_capture(*args,
              lambda v: v["raw"]["request"].update(path=v["raw"]["viewport"]["path"]))))
    check("unreproducible Mach conversion is rejected",
          lambda: run_model("clock-math", lambda *args: change_capture(*args,
              lambda v: v["clock"]["beforeRequestWrite"].update(machLowerNs=1))))
    check("missing original marker cannot be replaced by RESULT markers",
          lambda: run_model("absent-marker", lambda r, ref, result, c:
              (Path(ref["path"]).parent / "marker-overview-action.json").unlink()))
    check("forged arming derivation cannot replace raw persisting operation evidence",
          lambda: run_model("changed-correlation", lambda r, ref, result, c:
              rewrite(Path(ref["path"]).parent / (c[2]["snapshot"]["requestID"] + ".correlation.json"),
                      {"capture": c[2]["captureReceipt"], "armedOperation": None, "changedWhilePending": None})))
    check("missing original post-window comparison cannot inherit a claimed overlap",
          lambda: run_model("absent-source-comparison", lambda r, ref, result, c:
              (Path(ref["path"]).parent / (c[4]["snapshot"]["requestID"] + ".source-comparison.json")).unlink()))

    def counterfeit_result(r, ref, result, captures):
        result["changedUIOverlapRequests"] = [uid()]
        new = rewrite(ref["path"], result)
        ref.clear(); ref.update(new)

    check("claimed successful result is rejected when fresh evaluate_overlap disagrees",
          lambda: run_model("forged-derived-success", counterfeit_result))
    check("an omitted failed capture remains a rejecting artifact",
          lambda: run_model("unlisted-failure", lambda r, ref, result, c:
              wait.seal(Path(ref["path"]).parent / "REJECTED.json", {"scope": scope, "failed": True})))
    check("redirected retained capture is rejected",
          lambda: run_model("symlink-capture", lambda r, ref, result, c:
              (Path(c[4]["raw"]["request"]["path"]).unlink(),
               Path(c[4]["raw"]["request"]["path"]).symlink_to(c[3]["raw"]["request"]["path"]))))

    # No synthetic native completion is supplied: a host result by itself is
    # rejected before any original exported attachment can be accepted.
    retained, reference, result, captures = model("no-native-completion")
    retained.report = {"pending_sql": {"hostResult": reference}, "scope": scope}
    try:
        retained.join_native([])
        no_native_rejected = False
    except ValueError:
        no_native_rejected = True
    check("host-only synthetic success cannot become an original native completion",
          lambda: require(no_native_rejected))

    continuity_models = []
    for name, change in (
        ("changed immutable connection", lambda rows: rows[1]["snapshot"]["connections"][0]["openedFile"].update(inode=100)),
        ("regressed lifetime counter", lambda rows: rows[3]["snapshot"].update(lifetimeStarted=0)),
        ("reassigned operation sequence", lambda rows: rows[3]["snapshot"]["active"][0].update(operationID=uid())),
        ("changed published terminal", lambda rows: (rows.append(copy.deepcopy(rows[-1])),
            rows[-1]["snapshot"]["completed"][0].update(terminalNanoseconds=401))),
    ):
        values = copy.deepcopy(captures)
        change(values)
        rejected = False
        error_text = None
        try:
            module.validate_capture_continuity(values, wait)
        except ValueError as error:
            rejected = True; error_text = str(error)
        continuity_models.append({"name": name, "scope": scope, "input": values, "rejected": rejected, "error": error_text})
        check("original lifetime replay rejects " + name, lambda rejected=rejected: require(rejected))
    (out / "continuity-models.json").write_text(json.dumps(continuity_models, sort_keys=True, indent=2) + "\n")

    # Metadata copy is actual local bytes. The source pathname deliberately
    # never existed: no historical app data lookup may become a prerequisite.
    metadata = out / "synthetic-admitted-manifest-copy.json"
    metadata.write_text(json.dumps({"scope": scope, "syntheticMetadata": True}) + "\n")
    copy_ref = settings.witness(metadata)
    original_ref = {**copy_ref, "path": "/synthetic-retired-MCM-path-never-created/seforim-installation.json"}
    module.validate_manifest_copy(copy_ref, original_ref, metadata.read_bytes())
    check("immutable exact admitted metadata copy survives an unavailable historical MCM path",
          lambda: require(not Path(original_ref["path"]).exists()))
    changed_rejected = False
    try:
        module.validate_manifest_copy(copy_ref, {**original_ref, "sha256": "0" * 64}, metadata.read_bytes())
    except ValueError:
        changed_rejected = True
    check("relocation does not permit different admitted manifest bytes", lambda: require(changed_rejected))

    # Real status file writes, explicit in-memory worker/retirement boundaries.
    status_root = out / "status-source-writer-boundary"
    status_root.mkdir()
    recorder = module.PendingRecorder.__new__(module.PendingRecorder)
    recorder.request_lifetimes = [{"retirementVerified": False, "descriptorClosed": True}]
    state = {"id": uid(), "name": "overview", "identity": {"processID": 99}, "captures": [],
             "watcherStopped": True, "error": None, "status_path": status_root / "status.json"}
    recorder._write_status(state)
    unretired = json.loads(state["status_path"].read_bytes())
    wait.seal(status_root / "unretired-observed.json", unretired)
    check("loop exit with an unretired request cannot authorize native source writing",
          lambda: require(unretired["watcherStopped"] is False and unretired["ownedRequestRetirementVerified"] is False))
    recorder.request_lifetimes[0]["retirementVerified"] = True
    state["error"] = {"type": "InjectedObservationFailure"}
    recorder._write_status(state)
    failed = json.loads(state["status_path"].read_bytes())
    wait.seal(status_root / "failed-observed.json", failed)
    check("a failed observation cannot advertise a safe source-writer handoff",
          lambda: require(failed["watcherStopped"] is False))
    state["error"] = None
    recorder._write_status(state)
    complete = json.loads(state["status_path"].read_bytes())
    wait.seal(status_root / "retired-observed.json", complete)
    check("successful ended writer exposes its verified actual request retirement",
          lambda: require(complete["watcherStopped"] is True and complete["ownedRequestRetirementVerified"] is True))

    ui = (BASE / "PendingSQLUI.swift").read_text()
    def native_order():
        unit = ui.split('} else if cohort == "unit-supersession" {', 1)[1].split('} else {', 1)[0]
        backend = ui.split('try pendingSwitchBackend("sefaria"', 1)[1].split('try pendingSwitchBackend("otzaria"', 1)[0]
        require(unit.index('"unit-replacement"') < unit.index('try pendingWait(status') < unit.index('try pendingAssertSource('))
        require(backend.index('"backend-change"') < backend.index('try pendingWait(status') < backend.index('try pendingSample('))
        require(unit.count('"ownedRequestRetirementVerified"') == backend.count('"ownedRequestRetirementVerified"') == 1)
    check("native unit/backend final source probes follow the explicit verified-writer fence", native_order)

    oldraw = gzip.decompress((BASE / "request-lifetime-controls/candidate.py.gz").read_bytes())
    def function(raw, name):
        node = next(row for row in ast.parse(raw).body if isinstance(row, ast.FunctionDef) and row.name == name)
        return ast.dump(node, include_attributes=False)
    check("the ten real-file ownership controls still bind the unchanged lifetime algorithm",
          lambda: require(function(oldraw, "owned_source_request") == function(path.read_bytes(), "owned_source_request")))
    original = (BASE.parent / "perf02-pending-proposal/Build8401SevenDefectsAcceptanceTests.swift").read_bytes()
    full = (BASE / "candidate/Maktabah-iOSUITests/Build8401SevenDefectsAcceptanceTests.swift").read_bytes()
    check("complete existing registered native source remains a byte-exact prefix",
          lambda: require(len(original) == 102598 and full == original + ui.encode()))
    (out / "synthetic-control-attempts.json").write_text(json.dumps(attempts, sort_keys=True, indent=2) + "\n")
    report = {"schema": 1, "status": "SOURCE_RETAINED_ARTIFACT_GATE_CONTROLS_ONLY_NOT_NATIVE_OR_PRODUCTION",
        "scope": scope, "passed": sum(row["passed"] for row in checks), "total": len(checks), "results": checks,
        "candidateSHA256": sha(path.read_bytes()), "nativeSourceSHA256": sha(full), "runnerSHA256": sha(Path(__file__).read_bytes()),
        "attemptsSHA256": sha((out / "synthetic-control-attempts.json").read_bytes()),
        "continuityModelsSHA256": sha((out / "continuity-models.json").read_bytes()),
        "boundaries": ["Source comparator explicit stub", "No original admission/build/MCM producer", "No native completion fixture", "No corpus file"],
        "nativeUIExecuted": 0, "databaseQueries": 0, "swiftCompiles": 0, "fullPhaseAdmitted": False, "performanceAccepted": False}
    (out / "RESULT.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    (out / "candidate.py.gz").write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    (out / "native-addition.swift.gz").write_bytes(gzip.compress(ui.encode(), mtime=0))
    (out / "runner.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    print(json.dumps({"passed": report["passed"], "total": report["total"], "resultSHA256": sha((out / "RESULT.json").read_bytes()),
                      "failures": [row for row in checks if not row["passed"]]}))
    return 0 if report["passed"] == report["total"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
