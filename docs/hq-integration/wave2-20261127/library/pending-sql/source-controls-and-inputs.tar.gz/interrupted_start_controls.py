#!/usr/bin/env python3
"""Exact interrupted-thread-start source counterexample; no threads or UI run."""
import ast,gzip,hashlib,importlib.util,json,pathlib,tempfile,types,errno
P=pathlib.Path;BASE=P(__file__).resolve().parent

def digest(raw):return hashlib.sha256(raw).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 out=BASE/'interrupted-start-controls';out.mkdir(exist_ok=False)
 current=BASE/'candidate/Scripts/CI/study-ui-pending-sql.py'
 oldraw=gzip.decompress((BASE/'source-controls-attempt-5-final/candidate.py.gz').read_bytes())
 assert digest(oldraw)=='20859d77a5da9c7e05a1351da0d25b782d3261a8997e8872699c864e2beb51bc'
 old=out/'prior-20859d77.py';old.write_bytes(oldraw)
 prior=load('pending_prior_start_window',old);candidate=load('pending_new_start_window',current)
 wait=load('pending_original_wait_start_control',BASE.parent/'sqlite-wait-host/study-ui-sqlite-wait.py')
 results=[];models=[]
 def require(value):
  if not value:raise AssertionError('source counterexample did not meet its explicit boundary')
 def check(name,fn):
  try:fn();results.append({'name':name,'passed':True})
  except BaseException as e:results.append({'name':name,'passed':False,'error':type(e).__name__+':'+str(e)})
 with tempfile.TemporaryDirectory(prefix='pending-start-source-only-',dir=out) as temp:
  folder=P(temp)
  def model(module,name,*,host_ident=None,attempt=True,worker=None,no_space=False,invoke_start=False):
   root=folder/name;root.mkdir()
   record=module.PendingSQLHost.__new__(module.PendingSQLHost)
   record.core=types.SimpleNamespace(OUT=root);record.cleanup_receipt=None;record.cleanup_state=None
   record.owned_activity_exited=False;record.start_attempted=False if invoke_start else attempt;record.started=False
   def start():
    raise KeyboardInterrupt('synthetic interruption before Python published Thread.ident')
   h=types.SimpleNamespace(ident=host_ident,start=start,stop=lambda:None,is_alive=lambda:False,
        environment=lambda:{},pending_sql=types.SimpleNamespace(active=worker),error=None,active=None,
        pending_inspector=None,epochs={},reader_complete=None,inspector_complete=None)
   record.host=h
   if no_space:
    def full(*args,**kwargs):raise OSError(errno.ENOSPC,'synthetic full evidence device')
    record.wait=types.SimpleNamespace(seal=full,read=wait.read,decode=wait.decode)
   else:record.wait=wait
   start_interrupted=False
   if invoke_start:
    try:record.start()
    except KeyboardInterrupt:start_interrupted=True
   error=None
   try:record.stop()
   except BaseException as e:error=type(e).__name__
   proof=wait.decode(wait.verify_witness(record.cleanup_receipt)) if record.cleanup_receipt is not None else record.cleanup_state
   item={'model':name,'scope':'SYNTHETIC_THREAD_STATE_BOUNDARY_NO_THREAD_UI_OR_APP_EXECUTION',
         'input':{'hostIdent':host_ident,'startAttemptedInput':attempt,'workerStartAttempted':worker.get('worker_start_attempted') if worker else None,
                  'workerIdent':worker['worker'].ident if worker else None,'noSpace':no_space,'invokeStart':invoke_start},
         'startInterrupted':start_interrupted,'actualStartAttemptedState':record.start_attempted,
         'ownedActivityExited':record.owned_activity_exited,'stopException':error,'cleanup':proof,
         'cleanupReceiptRetained':record.cleanup_receipt is not None}
   models.append(item);return item
  old_result=model(prior,'prior-interrupted-host',invoke_start=True)
  check('prior exact source reproduces the false exited claim in interrupted-start gap',lambda:require(old_result['ownedActivityExited'] is True and old_result['startInterrupted']))
  new_result=model(candidate,'candidate-interrupted-host',invoke_start=True)
  check('start attempt is recorded before interrupted Thread.start',lambda:require(new_result['actualStartAttemptedState'] is True and new_result['startInterrupted']))
  check('unknown host start cannot prove exited merely from is_alive false',lambda:require(new_result['ownedActivityExited'] is False and new_result['cleanup']['observerStartVerified'] is False))
  worker=types.SimpleNamespace(ident=None,is_alive=lambda:False,join=lambda **kwargs:(_ for _ in ()).throw(AssertionError('must not join an unverified start')))
  ws={'worker_start_attempted':True,'worker':worker}
  check('unknown probe start cannot prove an exited writer',lambda:require(candidate.writer_exit_verified(ws) is False))
  def rejected_join():
   try:candidate.join_owned_writer(ws)
   except ValueError:return
   raise AssertionError('unknown writer was admitted')
  check('unknown probe start has an explicit failing join boundary',rejected_join)
  wr=model(candidate,'candidate-interrupted-writer',host_ident=17,worker=ws)
  check('unknown writer keeps total owned exit false',lambda:require(wr['ownedActivityExited'] is False and wr['cleanup']['passiveProbeWriterExited'] is False))
  full=model(candidate,'candidate-full-evidence-device',invoke_start=True,no_space=True)
  check('ENOSPC preserves unknown exit in memory before any receipt can be sealed',lambda:require(full['ownedActivityExited'] is False and full['cleanup']['ownedActivityExited'] is False and not full['cleanupReceiptRetained']))
  known=model(candidate,'candidate-known-terminated-thread',host_ident=17,attempt=True)
  check('a known terminated thread remains exited without granting UI or external cleanup',lambda:require(known['ownedActivityExited'] is True and known['cleanup']['simulatorReleaseOrRetentionAuthorized'] is False and known['stopException'] is not None))
  never=model(candidate,'candidate-never-attempted',host_ident=None,attempt=False)
  check('never-attempted host is distinguished from interrupted start',lambda:require(never['ownedActivityExited'] is True and never['cleanup']['observerStartVerified'] is True))
 def functions(raw):
  tree=ast.parse(raw);return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 a,b=functions(oldraw),functions(current.read_bytes())
 check('all earlier top-level producer/correlation/clock/catalog gates are unchanged ASTs',lambda:require(all(b[k]==v for k,v in a.items())))
 ui=(BASE/'candidate/Maktabah-iOSUITests/Build8401SevenDefectsAcceptanceTests.swift').read_bytes();base=(BASE.parent/'perf02-pending-proposal/Build8401SevenDefectsAcceptanceTests.swift').read_bytes()
 check('existing registered Swift source prefix stays exact',lambda:require(ui[:len(base)]==base and len(base)==102598))
 addition=ui[len(base):].decode()
 check('native failure cannot relaunch after an unverified observer abort',lambda:require('let aborted = try pendingHost("pending_sql_abort"' in addition and 'aborted["ownedProbeWriterExited"] as? Bool == true' in addition and '_ = try? pendingHost("pending_sql_abort"' not in addition))
 (out/'synthetic-model-inputs-and-results.json').write_text(json.dumps(models,sort_keys=True,indent=2)+'\n')
 report={'schema':1,'status':'SOURCE_INTERRUPTED_START_CONTROLS_ONLY_NOT_UI_OR_THREADS','passed':sum(r['passed'] for r in results),'total':len(results),'results':results,
         'scope':'No actual thread, Swift compiler, corpus, simulator or application execution; exact prior source counterexample and current lifecycle gate only',
         'priorSourceSHA256':digest(oldraw),'candidateSourceSHA256':digest(current.read_bytes()),'nativeSourceSHA256':digest(ui),
         'modelsSHA256':digest((out/'synthetic-model-inputs-and-results.json').read_bytes()),'runnerSHA256':digest(P(__file__).read_bytes()),
         'actualNewThreads':0,'nativeUIExecuted':0,'performanceAccepted':False}
 (out/'RESULT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
 (out/'candidate.py.gz').write_bytes(gzip.compress(current.read_bytes(),mtime=0))
 (out/'native-addition.swift.gz').write_bytes(gzip.compress(ui[len(base):],mtime=0))
 print(json.dumps({'passed':report['passed'],'total':report['total'],'sha256':digest((out/'RESULT.json').read_bytes()),'failures':[r for r in results if not r['passed']]}))
 return 0 if report['passed']==report['total'] else 1
if __name__=='__main__':raise SystemExit(main())
