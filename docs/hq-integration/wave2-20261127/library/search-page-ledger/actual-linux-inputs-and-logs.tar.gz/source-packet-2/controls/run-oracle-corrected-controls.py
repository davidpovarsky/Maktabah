#!/usr/bin/env python3
"""One bounded Linux Foundation component run; no SDK/provider/native UI."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import sys
import time

FLOOR = 687_865_856
BUDGET = 67_108_864
WORKTREE = Path('/mnt/development/projects/worktrees/Maktabah-wave2-search-page-ledger-20261127')
SWIFTC = Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
FRONTEND = Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swift-frontend')
PATHS = [
    'Source/ChavrusaText/SearchContinuation/OriginalSearchPageLedger.swift',
    'Source/Features/Search/ViewModel/Extensions/Search+Execution.swift',
    'Source/Features/Search/ViewModel/SearchViewModel.swift',
    'Source/Otzaria/Search/OtzariaTextSearchViewModel.swift',
    'Vendor/ZayitSearchPort/Swift/ZayitSearchViewModel.swift',
]


def free():
    v = os.statvfs('/mnt/development')
    return v.f_bavail * v.f_frsize


def witness(path):
    path = Path(path)
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    after = path.lstat()
    assert (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'device': s.st_dev, 'inode': s.st_ino, 'mtimeNs': s.st_mtime_ns}


def write_new(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write('\n')


def allocated(root):
    total = 0
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            p = Path(parent) / name
            s = p.lstat()
            if stat.S_ISLNK(s.st_mode):
                # Swift module caches may contain their own small lock symlink.
                total += s.st_blocks * 512
            else:
                total += s.st_blocks * 512
    return total


def main():
    packet = Path(sys.argv[1]).resolve(strict=True)
    out = Path(sys.argv[2])
    assert not out.exists()
    before = free()
    budget_root = out.parent.resolve(strict=True)
    retained_allocation = allocated(budget_root)
    assert retained_allocation < BUDGET
    remaining_budget = BUDGET - retained_allocation
    assert before >= FLOOR + remaining_budget, ('capacity admission refused', before, remaining_budget)
    out.mkdir(parents=True)
    assert out.resolve(strict=True) == out and not out.is_symlink()
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    cache = budget_root / 'attempt-1/module-cache'
    assert cache.is_dir() and not cache.is_symlink() and cache.resolve(strict=True) == cache
    cache_stat = cache.stat()
    assert cache_stat.st_uid == os.getuid()
    temporary = out / 'tmp'; temporary.mkdir()
    inputs = out / 'inputs'; inputs.mkdir()
    expected = json.loads((packet / 'PACKAGE.json').read_text())
    report = {
        'schema': 1, 'scope': 'LINUX_SOURCE_COMPONENT_AND_APPLE_TARGET_SYNTAX_ONLY_NOT_SDK_OR_UI',
        'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'freeBefore': before, 'reservedFloorBytes': FLOOR, 'ownedOutputBudgetBytes': BUDGET,
        'budgetRoot': str(budget_root), 'retainedAllocatedBefore': retained_allocation,
        'remainingOwnedBudgetAtAdmission': remaining_budget,
        'reusedCache': {'path': str(cache), 'device': cache_stat.st_dev, 'inode': cache_stat.st_ino, 'uid': cache_stat.st_uid},
        'maximumSampledAllocatedBytes': 0, 'minimumSampledFreeBytes': before,
        'commands': [], 'inputs': {}, 'allOwnedProcessGroupsExited': True,
        'runnerPID': os.getpid(), 'runnerProcessGroup': os.getpgrp(),
        'nativeUIExecution': False, 'providerExecution': False,
    }
    env = os.environ.copy()
    env.update({'TMPDIR': str(temporary), 'CLANG_MODULE_CACHE_PATH': str(cache)})
    for rel in PATHS:
        src = WORKTREE / rel
        w = witness(src)
        assert w['sha256'] == expected['candidate'][rel]['sha256'], (rel, w)
        dest = inputs / rel; dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(src.read_bytes())
        report['inputs'][rel] = {'source': w, 'retained': witness(dest)}
    for rel in ['controls/OriginalSearchPageLedgerControls.swift', 'dependencies/ZayitSearchModels.swift']:
        src = packet / rel
        w = witness(src)
        assert w['sha256'] == expected['other'][rel]['sha256']
        dest = inputs / rel; dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(src.read_bytes())
        report['inputs'][rel] = {'source': w, 'retained': witness(dest)}
    report['driver'] = {'argv0': str(SWIFTC), 'resolved': witness(SWIFTC.resolve(strict=True))}
    report['frontend'] = witness(FRONTEND)
    report['processesBefore'] = subprocess.run(['ps', '-eo', 'pid,ppid,pgid,args'], capture_output=True, text=True, check=True).stdout
    write_new(out / 'INPUTS.json', report)

    def sample():
        used, available = allocated(budget_root), free()
        report['maximumSampledAllocatedBytes'] = max(report['maximumSampledAllocatedBytes'], used)
        report['minimumSampledFreeBytes'] = min(report['minimumSampledFreeBytes'], available)
        return used <= BUDGET and available >= FLOOR

    def run(name, argv, timeout):
        assert sample(), 'capacity admission changed before command'
        item = {'name': name, 'argv': [str(x) for x in argv], 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        report['commands'].append(item)
        p = None
        started = time.monotonic()
        with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
            item['startAttempted'] = True
            report['allOwnedProcessGroupsExited'] = False
            p = subprocess.Popen(item['argv'], stdout=stdout, stderr=stderr, env=env, start_new_session=True)
            item['pid'] = p.pid
            item['processGroup'] = os.getpgid(p.pid)
            assert item['processGroup'] == p.pid
            reason = None
            while p.poll() is None:
                if not sample(): reason = 'capacity budget/floor'
                elif time.monotonic() - started > timeout: reason = 'bounded timeout'
                if reason:
                    item['stoppedBecause'] = reason
                    # This unreaped child still owns its just-created group.
                    if p.poll() is None and os.getpgid(p.pid) == p.pid:
                        os.killpg(p.pid, signal.SIGTERM)
                    try: p.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        if p.poll() is None and os.getpgid(p.pid) == p.pid:
                            os.killpg(p.pid, signal.SIGKILL)
                        p.wait(timeout=2)
                    break
                time.sleep(0.05)
            item['exit'] = p.wait()
        item['durationSeconds'] = time.monotonic() - started
        item['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        item['stdout'] = witness(out / (name + '.stdout'))
        item['stderr'] = witness(out / (name + '.stderr'))
        try:
            os.killpg(p.pid, 0)
            item['groupAbsentAfterWait'] = False
            report['allOwnedProcessGroupsExited'] = False
        except ProcessLookupError:
            item['groupAbsentAfterWait'] = True
        report['allOwnedProcessGroupsExited'] = all(
            command.get('groupAbsentAfterWait') is True
            for command in report['commands'] if command.get('startAttempted')
        )
        sample()
        return item['exit'] == 0 and item.get('groupAbsentAfterWait') and not item.get('stoppedBecause')

    try:
        previous_path = budget_root / 'attempt-1/RESULT.json'
        previous = json.loads(previous_path.read_text())
        assert previous['wholeFileSyntaxPassed'] is True
        for rel in PATHS[1:]:
            prior = previous['inputs'][rel]['retained']
            assert witness(prior['path'])['sha256'] == prior['sha256'] == report['inputs'][rel]['retained']['sha256']
        assert previous['driver']['resolved']['sha256'] == report['driver']['resolved']['sha256']
        assert previous['frontend']['sha256'] == report['frontend']['sha256']
        report['unchangedOwnerSyntaxResult'] = witness(previous_path)
        report['unchangedOwnerSyntaxPassed'] = True
        report['changedLedgerSyntaxCoveredByActualCompile'] = True
        binary = out / 'OriginalSearchPageLedgerControls'
        compile_argv = [SWIFTC, '-parse-as-library', '-swift-version', '6',
                        '-strict-concurrency=complete', '-module-cache-path', cache,
                        inputs / PATHS[0], inputs / 'dependencies/ZayitSearchModels.swift',
                        inputs / 'controls/OriginalSearchPageLedgerControls.swift', '-o', binary]
        report['componentCompiled'] = run('component-compile', compile_argv, 25)
        assert report['allOwnedProcessGroupsExited']
        if report['componentCompiled']:
            report['binary'] = witness(binary)
            report['componentPassed'] = run('component-run', [binary], 5)
            if report['componentPassed']:
                report['componentResult'] = json.loads((out / 'component-run.stdout').read_text())
        else:
            report['componentPassed'] = False
        report['status'] = 'PASSED_SOURCE_ONLY' if report['unchangedOwnerSyntaxPassed'] and report['componentPassed'] else 'FAILED_SOURCE_CHECK_RETAINED'
    except BaseException as exc:
        report['status'] = 'FAILED_SOURCE_CHECK_RETAINED'
        report['error'] = repr(exc)
    finally:
        report['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        report['freeAfter'] = free()
        report['allocatedAfterBytes'] = allocated(budget_root)
        report['maximumSampledAllocatedBytes'] = max(report['maximumSampledAllocatedBytes'], report['allocatedAfterBytes'])
        write_new(out / 'RESULT.json', report)
        print(json.dumps({'result': witness(out / 'RESULT.json'), 'status': report['status'],
                          'ownedProcessGroupsExited': report['allOwnedProcessGroupsExited'],
                          'maximumSampledAllocatedBytes': report['maximumSampledAllocatedBytes'],
                          'freeAfter': report['freeAfter']}))
    return 0 if report['status'] == 'PASSED_SOURCE_ONLY' else 1


if __name__ == '__main__':
    raise SystemExit(main())
