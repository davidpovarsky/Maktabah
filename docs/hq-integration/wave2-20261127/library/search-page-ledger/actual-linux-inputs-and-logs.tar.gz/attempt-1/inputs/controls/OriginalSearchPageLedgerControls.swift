import Foundation

enum ControlFailure: Error { case failed(String), encoding }

struct CannotEncode: Encodable {
    func encode(to encoder: Encoder) throws { throw ControlFailure.encoding }
}

@main
struct OriginalSearchPageLedgerControls {
    @MainActor
    static func main() throws {
        var passed: [String] = []
        func check(_ name: String, _ condition: Bool) throws {
            guard condition else { throw ControlFailure.failed(name) }
            passed.append(name)
        }
        func request(_ offset: Int = 0, query: String = "נפשי") -> OriginalSearchPageLedger.Request? {
            let value = ZayitSearchRequest(query: query, near: 5, limit: 50, offset: offset, filters: .init())
            let configuration = ZayitSearchRequest(query: query, near: 5, limit: 50, offset: 0, filters: .init())
            return .encode(value, configuration: configuration, offset: offset, limit: 50)
        }
        func begin(_ ledger: OriginalSearchPageLedger, _ offset: Int, replacing: Bool = false) -> OriginalSearchPageLedger.Attempt? {
            ledger.begin(generation: ledger.generation, request: request(offset), replacing: replacing,
                         consumedBefore: offset, cursorBefore: offset)
        }
        func accept(_ ledger: OriginalSearchPageLedger, _ attempt: OriginalSearchPageLedger.Attempt?,
                    raw: Int, consumed: Int, more: Bool = true, evidence: Data? = nil) {
            ledger.accept(attempt, rawCount: raw, mappedCount: raw, consumedAfter: consumed,
                          cursorAfter: more ? consumed : nil, hasMore: more,
                          rawNextOffset: consumed, sourceEvidence: evidence)
        }

        let ledger = OriginalSearchPageLedger()
        try check("new owner has no accepted page", ledger.snapshot.pageRevision == 0 && ledger.snapshot.lastCommitted == nil)
        let encoded = try require(request(50), "actual typed Zayit request encodes")
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        let actual = ZayitSearchRequest(query: "נפשי", near: 5, limit: 50, offset: 50, filters: .init())
        try check("request bytes equal unchanged original Zayit Encodable output", encoded.bytes == (try encoder.encode(actual)))
        try check("offset-zero configuration is independent of page offset", encoded.configuration == request(0)?.configuration && encoded.bytes != encoded.configuration)

        ledger.invalidate(generation: 1)
        let first = try require(begin(ledger, 0, replacing: true), "first attempt")
        let firstCapture = try require(ledger.captureTerminal(for: first), "first terminal capture")
        try check("same attempt reuses one attached terminal capture", ledger.captureTerminal(for: first) === firstCapture)
        try check("dispatch creates active attempt without accepted-page revision", ledger.snapshot.active == first && ledger.snapshot.pageRevision == 0 && ledger.snapshot.lastCommitted == nil)
        let inFlight = ledger.snapshot
        try check("a concurrent begin cannot replace the active original attempt", begin(ledger, 0, replacing: true) == nil && ledger.snapshot == inFlight)
        let staleBegin = ledger.begin(generation: 0, request: request(), replacing: true, consumedBefore: 0, cursorBefore: 0)
        try check("stale-generation dispatch is a strict no-op", staleBegin == nil && ledger.snapshot == inFlight)
        accept(ledger, first, raw: 50, consumed: 50)
        let firstCommit = try require(ledger.snapshot.lastCommitted, "first commit")
        try check("accepted source page advances page revision exactly once", firstCommit.pageRevision == 1 && firstCommit.attempt == first && ledger.snapshot.active == nil)
        try check("capture freezes the actual accepted terminal exactly once", firstCapture.isClosed && firstCapture.terminal == .accepted(firstCommit))
        let acceptedSnapshot = ledger.snapshot
        accept(ledger, first, raw: 50, consumed: 50)
        ledger.fail(first, cancelled: false)
        try check("replayed terminal callbacks cannot change a committed page", ledger.snapshot == acceptedSnapshot)

        let second = try require(begin(ledger, 50), "second attempt")
        // No displayed-row array enters the ledger: these are the actual facts
        // the original deduplicating owner supplies, not a copied dedup algorithm.
        accept(ledger, second, raw: 50, consumed: 100)
        try check("raw progress remains accepted without a displayed-row count gate", ledger.snapshot.lastCommitted?.consumedAfter == 100 && ledger.snapshot.pageRevision == 2)
        let empty = try require(begin(ledger, 100), "empty terminal attempt")
        accept(ledger, empty, raw: 0, consumed: 100, more: false)
        let terminal = try require(ledger.snapshot.lastCommitted, "terminal commit")
        try check("empty accepted terminal advances page revision without cursor progress", terminal.pageRevision == 3 && terminal.rawCount == 0 && terminal.consumedAfter == 100 && !terminal.hasMore && terminal.cursorAfter == nil && terminal.rawNextOffset == 100)
        try check("missing source evidence stays missing", terminal.sourceEvidence == nil)

        let failing = try require(begin(ledger, 100), "failing attempt")
        ledger.fail(failing, cancelled: false)
        try check("failure preserves prior committed page without page advance", ledger.snapshot.lastTerminal == .failed(failing) && ledger.snapshot.lastCommitted == terminal && ledger.snapshot.pageRevision == 3)
        let retry = try require(begin(ledger, 100), "retry attempt")
        try check("retry has a distinct attempt identity for the same request", retry.id != failing.id && retry.request == failing.request)
        ledger.fail(retry, cancelled: true)
        try check("cancellation is distinct from acceptance and failure", ledger.snapshot.lastTerminal == .cancelled(retry) && ledger.snapshot.lastCommitted == terminal && ledger.snapshot.pageRevision == 3)
        let cancelled = ledger.snapshot
        accept(ledger, retry, raw: 10, consumed: 110)
        try check("late completion after a terminal cancellation is ignored", ledger.snapshot == cancelled)

        let beforeInvalidation = ledger.snapshot.revision
        ledger.invalidate(generation: 1)
        try check("same-generation invalidation changes authority and clears page facts", ledger.snapshot.revision != beforeInvalidation && ledger.snapshot.lastCommitted == nil && ledger.snapshot.lastTerminal == nil)
        let old = try require(begin(ledger, 0, replacing: true), "pre-ABA attempt")
        ledger.invalidate(generation: 1)
        let replacement = try require(begin(ledger, 0, replacing: true), "post-ABA attempt")
        let replacementSnapshot = ledger.snapshot
        accept(ledger, old, raw: 50, consumed: 50)
        ledger.fail(old, cancelled: true)
        try check("equal-generation ABA cannot adopt an earlier callback", ledger.snapshot == replacementSnapshot && old.id != replacement.id)
        let another = OriginalSearchPageLedger()
        another.invalidate(generation: 1)
        let foreign = try require(begin(another, 0, replacing: true), "foreign owner attempt")
        accept(ledger, foreign, raw: 50, consumed: 50)
        try check("another owner's attempt cannot commit this source", ledger.snapshot == replacementSnapshot)
        try check("another owner's attempt cannot acquire a terminal capture", ledger.captureTerminal(for: foreign) == nil)
        ledger.invalidate(generation: 2)
        let generationTwo = ledger.snapshot
        ledger.observationFailed(generation: 1)
        accept(ledger, replacement, raw: 50, consumed: 50)
        try check("old-generation failure and acceptance cannot revoke new authority", ledger.snapshot == generationTwo)

        let failedEncoding = OriginalSearchPageLedger.Request.encode(CannotEncode(), configuration: CannotEncode(), offset: 0, limit: 50)
        try check("throwing original encoding produces unavailable observation input", failedEncoding == nil)
        _ = ledger.begin(generation: 2, request: failedEncoding, replacing: true, consumedBefore: 0, cursorBefore: 0)
        try check("encoding failure has no page authority", ledger.snapshot.revision == nil && ledger.snapshot.pageRevision == nil && ledger.snapshot.active == nil)
        let unavailable = ledger.snapshot
        try check("unavailable epoch cannot silently rearm on a request", begin(ledger, 0, replacing: true) == nil && ledger.snapshot == unavailable)
        ledger.invalidate(generation: 3)
        try check("real source invalidation rearms a bounded encoding failure", ledger.snapshot.revision != nil && begin(ledger, 0, replacing: true) != nil)

        let huge = request(0, query: String(repeating: "q", count: 256 * 1024 + 1))
        try check("oversized original request encoding is bounded", huge == nil)
        let bounded = ledger.snapshot.active
        accept(ledger, bounded, raw: 1, consumed: 1, evidence: Data(repeating: 0, count: 256 * 1024 + 1))
        try check("oversized source evidence revokes observation without a commit", ledger.snapshot.revision == nil && ledger.snapshot.lastCommitted == nil)

        ledger.invalidate(generation: 4)
        let bad = try require(begin(ledger, 50), "regressive observation")
        ledger.accept(bad, rawCount: 1, mappedCount: 1, consumedAfter: 49,
                      cursorAfter: 49, hasMore: true, rawNextOffset: 49, sourceEvidence: nil)
        try check("regressive append facts cannot be accepted", ledger.snapshot.revision == nil && ledger.snapshot.lastCommitted == nil)
        ledger.invalidate(generation: 5)
        let replacing = ledger.begin(generation: 5, request: request(), replacing: true, consumedBefore: 500, cursorBefore: 500)
        accept(ledger, replacing, raw: 5, consumed: 5)
        try check("replacement can reset actual prior pagination counts", ledger.snapshot.lastCommitted?.consumedAfter == 5 && ledger.snapshot.lastCommitted?.attempt.consumedBefore == 500)
        let loop = try require(begin(ledger, 5), "raw normalized cursor example")
        ledger.accept(loop, rawCount: 0, mappedCount: 0, consumedAfter: 5,
                      cursorAfter: nil, hasMore: false, rawNextOffset: -1, sourceEvidence: Data("{}".utf8))
        try check("raw invalid cursor remains distinct from normalized exhaustion", ledger.snapshot.lastCommitted?.rawNextOffset == -1 && ledger.snapshot.lastCommitted?.cursorAfter == nil)

        let effects = OriginalSearchPageLedger()
        effects.invalidate(generation: 1)
        let effectAttempt = try require(begin(effects, 0, replacing: true), "effect attempt")
        let retained = try require(effects.captureTerminal(for: effectAttempt), "retained capture")
        accept(effects, effectAttempt, raw: 50, consumed: 50)
        let effectCommit = try require(effects.snapshot.lastCommitted, "effect commit")
        effects.invalidate(generation: 2)
        try check("accept then invalidate before consumer preserves the actual committed effect", retained.isClosed && retained.terminal == .accepted(effectCommit))
        try check("retained accepted effect does not restore current source authority", effects.snapshot.generation == 2 && effects.snapshot.active == nil && effects.snapshot.lastCommitted == nil && effects.captureTerminal(for: effectAttempt) == nil)
        let revokedAttempt = try require(begin(effects, 0, replacing: true), "revoked attempt")
        let revokedCapture = try require(effects.captureTerminal(for: revokedAttempt), "revoked capture")
        effects.invalidate(generation: 3)
        let revokedSnapshot = effects.snapshot
        accept(effects, revokedAttempt, raw: 50, consumed: 50)
        try check("invalidation before late acceptance closes capture without inventing an effect", revokedCapture.isClosed && revokedCapture.terminal == nil && effects.snapshot == revokedSnapshot)
        let failureAttempt = try require(begin(effects, 0, replacing: true), "captured failure attempt")
        let failureCapture = try require(effects.captureTerminal(for: failureAttempt), "failure capture")
        effects.fail(failureAttempt, cancelled: false)
        effects.invalidate(generation: 4)
        try check("retained failure remains a failure after current facts are cleared", failureCapture.isClosed && failureCapture.terminal == .failed(failureAttempt))

        let report: [String: Any] = [
            "schema": 1,
            "scope": "ACTUAL_FOUNDATION_LEDGER_COMPONENT_ONLY_NOT_BACKEND_PROVIDER_OR_UI",
            "passed": passed.count,
            "checks": passed,
            "overflowBranch": "source-reviewed only; not dynamically reached",
            "providerExecution": false,
            "nativeUIExecution": false
        ]
        print(String(decoding: try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]), as: UTF8.self))
    }

    static func require<T>(_ value: T?, _ message: String) throws -> T {
        guard let value else { throw ControlFailure.failed(message) }
        return value
    }
}
