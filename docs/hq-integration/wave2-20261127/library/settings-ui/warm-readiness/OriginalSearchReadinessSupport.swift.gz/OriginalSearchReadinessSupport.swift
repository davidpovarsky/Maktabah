import XCTest
import CryptoKit
import SQLite3
import Darwin

private enum SearchDataNativeFixtureError: Error { case rejected(String) }

private func requireSearchDataFixture(_ condition: Bool, _ reason: String) throws {
    guard condition else {
        XCTFail(reason)
        throw SearchDataNativeFixtureError.rejected(reason)
    }
}

private func searchDataDigest(_ data: Data) -> String {
    SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
}

struct SearchContextExpectedSegment: Decodable {
    let locator: String
    let sourceSHA256: String
    let translationSHA256: String?
    let sourceUTF8Bytes: Int
    let translationUTF8Bytes: Int?
}

@MainActor
struct OriginalSearchContextUI {
    let app: XCUIApplication
    let test: XCTestCase

    func control(_ id: String) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: id).firstMatch
    }

    @discardableResult
    func require(_ id: String, timeout: TimeInterval = 30) throws -> XCUIElement {
        let value = control(id)
        try requireSearchDataFixture(value.waitForExistence(timeout: timeout), "Original control absent: " + id)
        return value
    }

    func wait(_ reason: String, timeout: TimeInterval = 60,
              _ condition: @escaping @MainActor () -> Bool) throws {
        let expectation = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            MainActor.assumeIsolated { condition() }
        }, object: nil)
        try requireSearchDataFixture(XCTWaiter.wait(for: [expectation], timeout: timeout) == .completed, reason)
    }

    func capture(_ name: String) {
        let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screen.name = name; screen.lifetime = .keepAlways; test.add(screen)
        let tree = XCTAttachment(string: app.debugDescription)
        tree.name = name + "-hierarchy"; tree.lifetime = .keepAlways; test.add(tree)
    }

    func dragVisible(_ element: XCUIElement, up: Bool) throws {
        let rect = element.frame.intersection(app.frame)
        try requireSearchDataFixture(rect.width > 40 && rect.height > 100, "The original scroll owner must have a visible viewport")
        let origin = app.coordinate(withNormalizedOffset: CGVector(dx: 0, dy: 0))
        let x = rect.midX - app.frame.minX
        let high = rect.minY + rect.height * 0.22 - app.frame.minY
        let low = rect.minY + rect.height * 0.78 - app.frame.minY
        let start = origin.withOffset(CGVector(dx: x, dy: up ? low : high))
        let end = origin.withOffset(CGVector(dx: x, dy: up ? high : low))
        start.press(forDuration: 0.05, thenDragTo: end)
    }

    func reach(_ id: String, maximumSwipes: Int = 50) throws -> XCUIElement {
        for _ in 0...maximumSwipes {
            let value = control(id)
            if value.exists && value.isHittable && value.frame.intersects(app.frame) { return value }
            try dragVisible(require("global-search-results"), up: true)
        }
        throw SearchDataNativeFixtureError.rejected("Original result not reachable: " + id)
    }

    func loadedCount(filtered: Bool = false) throws -> Int {
        let label = try require("global-search-count").label
        let values = label.split(whereSeparator: { !$0.isNumber }).compactMap { Int($0) }
        try requireSearchDataFixture(!values.isEmpty && (!filtered || values.count >= 2), "Read the original loaded counter: " + label)
        return filtered ? values[1] : values[0]
    }

    func suppressAutomaticPaging() throws {
        try require("global-search-result-filter-toggle").tap()
        let filter = try require("global-search-result-filter")
        filter.tap(); filter.typeText("source-acceptance-no-book-" + UUID().uuidString + "\n")
        try require("global-search-filter-empty")
    }

    func closeResultFilter() throws { try require("global-search-result-filter-done").tap() }

    func expand(_ id: String) throws {
        let toggle = try reach("search-result-preview-toggle-" + id)
        if toggle.value as? String != "Expanded" { toggle.tap() }
        try require("search-result-expanded-preview-" + id)
    }

    func originalPreviewScroll(_ id: String) throws -> XCUIElement {
        let scroll = app.scrollViews.matching(identifier: "search-result-expanded-preview-" + id).firstMatch
        try requireSearchDataFixture(scroll.waitForExistence(timeout: 45),
            "Full context must be the original native scroll view, not a synthetic witness")
        return scroll
    }

    func openCurrentPreview(_ id: String) throws {
        let scroll = try originalPreviewScroll(id)
        for _ in 0..<100 {
            let button = control("search-result-open-" + id)
            if button.exists && button.isHittable { button.tap(); return }
            try dragVisible(scroll, up: true)
        }
        throw SearchDataNativeFixtureError.rejected("Original Open action was not reachable")
    }

    func returnToOriginalSearch() throws {
        // The original TabView has no invented route ID. Scope to its native
        // tab bar, not Reader's separate in-book magnifying-glass button.
        let labels = NSPredicate(format: "label == %@ OR label == %@", "Search", "חיפוש")
        let back = app.navigationBars.buttons.matching(labels)
        if back.count == 1, back.firstMatch.isHittable {
            back.firstMatch.tap()
            if control("global-search-screen").waitForExistence(timeout: 5) { return }
        }
        var tabs = app.tabBars.buttons.matching(labels).allElementsBoundByIndex.filter(\.isHittable)
        if tabs.isEmpty {
            let reader = app.textViews["reader-text"].firstMatch
            try requireSearchDataFixture(reader.waitForExistence(timeout: 15), "Reveal the original Reader chrome")
            reader.tap()
            try wait("Original root Search tab must become visible") {
                self.app.tabBars.buttons.matching(labels).allElementsBoundByIndex.filter(\.isHittable).count == 1
            }
            tabs = app.tabBars.buttons.matching(labels).allElementsBoundByIndex.filter(\.isHittable)
        }
        try requireSearchDataFixture(tabs.count == 1 && tabs[0].frame.intersects(app.frame),
            "Require one visible original root Search tab")
        tabs[0].tap()
        try require("global-search-screen")
    }

    func setReaderTextMode(_ mode: String, fromPreview id: String) throws {
        try openCurrentPreview(id)
        try require("reader-more-menu", timeout: 60).tap()
        try require("reader-text-options").tap()
        for _ in 0..<8 {
            if control("reader-text-mode").exists && control("reader-text-mode").isHittable { break }
            let popover = app.popovers.firstMatch
            try requireSearchDataFixture(popover.waitForExistence(timeout: 10), "Original View Options popover must be present")
            try dragVisible(popover, up: true)
        }
        try require("reader-text-mode").tap()
        try require("reader-text-mode-" + mode).tap()
        try require("reader-options-close").tap()
        try returnToOriginalSearch()
        try require("search-result-expanded-preview-" + id)
    }

    func setReaderUnit(_ mode: String, fromPreview id: String) throws {
        try openCurrentPreview(id)
        try require("reader-more-menu", timeout: 60).tap()
        try require("reader-display-unit-menu").tap()
        try require("reader-display-unit-" + mode).tap()
        try returnToOriginalSearch()
        try require("search-result-expanded-preview-" + id)
    }

    func assertOriginalSearchResize(rtl: Bool, query: String, firstStableID: String) throws {
        let count = try loadedCount()
        let bookLabel = try require("global-search-books").label
        let modeLabel = try require("global-search-mode").label
        for orientation in [UIDeviceOrientation.portrait, .landscapeLeft] {
            XCUIDevice.shared.orientation = orientation
            try wait("The original app must actually change viewport orientation") {
                let frame = self.app.frame
                return orientation == .portrait ? frame.height > frame.width : frame.width > frame.height
            }
            try wait("All persistent header controls must remain usable after actual resize") {
                ["global-search-query", "global-search-options", "global-search-books", "global-search-mode"]
                    .allSatisfy { self.control($0).isHittable && self.control($0).frame.intersects(self.app.frame) }
            }
            let field = try require("global-search-query")
            let options = try require("global-search-options")
            let books = try require("global-search-books")
            let mode = try require("global-search-mode")
            XCTAssertEqual(field.value as? String, query)
            XCTAssertEqual(books.label, bookLabel)
            XCTAssertEqual(mode.label, modeLabel)
            XCTAssertEqual(try loadedCount(), count)
            XCTAssertFalse(field.frame.intersects(options.frame))
            XCTAssertGreaterThanOrEqual(books.frame.minY, field.frame.maxY - 1)
            if rtl {
                XCTAssertLessThanOrEqual(options.frame.maxX, field.frame.minX + 1)
                XCTAssertGreaterThan(books.frame.midX, mode.frame.midX)
            } else {
                XCTAssertGreaterThanOrEqual(options.frame.minX, field.frame.maxX - 1)
                XCTAssertLessThan(books.frame.midX, mode.frame.midX)
            }
            try require("search-result-preview-toggle-" + firstStableID)
            XCTAssertFalse(control("global-search-dirty").exists)
            XCTAssertFalse(control("global-search-error").exists)
            capture("original-search-resize-" + (rtl ? "he-" : "en-") + String(orientation.rawValue))
        }
    }

    func assertCompleteContext(id: String, segments: [SearchContextExpectedSegment], mode: String) throws {
        try requireSearchDataFixture(!segments.isEmpty && Set(segments.map(\.locator)).count == segments.count,
            "Independent source must identify every segment uniquely")
        let scroll = try originalPreviewScroll(id)
        let sourcePrefix = "search-preview-source-" + id + "-"
        let translationPrefix = "search-preview-translation-" + id + "-"
        var expected: [String: (String, Int)] = [:]
        for segment in segments {
            if mode == "source" || mode == "both" {
                expected[sourcePrefix + segment.locator] = (segment.sourceSHA256, segment.sourceUTF8Bytes)
            }
            if mode == "translation" || mode == "both" {
                let hash = try XCTUnwrap(segment.translationSHA256, "Bilingual acceptance requires a real translation slot")
                let count = try XCTUnwrap(segment.translationUTF8Bytes)
                expected[translationPrefix + segment.locator] = (hash, count)
            }
        }
        try wait("The original full body must finish loading", timeout: 90) {
            !self.control("search-preview-loading-" + id).exists
                && self.app.staticTexts.matching(NSPredicate(format: "identifier BEGINSWITH %@ OR identifier BEGINSWITH %@",
                    sourcePrefix, translationPrefix)).count > 0
        }
        let firstID = (mode == "translation" ? translationPrefix : sourcePrefix) + segments[0].locator
        for _ in 0..<(segments.count * 4 + 20) {
            let first = app.staticTexts[firstID].firstMatch
            if first.exists && first.frame.intersects(app.frame) && !first.frame.isEmpty { break }
            try dragVisible(scroll, up: false)
        }
        var seen: [String: String] = [:]
        for step in 0..<(segments.count * 5 + 20) {
            let elements = app.staticTexts.matching(NSPredicate(format: "identifier BEGINSWITH %@ OR identifier BEGINSWITH %@",
                                                               sourcePrefix, translationPrefix)).allElementsBoundByIndex
            try requireSearchDataFixture(Set(elements.map(\.identifier)).count == elements.count,
                "An original segment may not be duplicated in the expanded card")
            for element in elements {
                let wanted = try XCTUnwrap(expected[element.identifier],
                    "The selected language mode must not show an extra source/translation segment")
                let text = element.label
                let hash = SHA256.hash(data: Data(text.utf8)).map { String(format: "%02x", $0) }.joined()
                XCTAssertEqual(hash, wanted.0, "Complete native Text must match independent source: " + element.identifier)
                XCTAssertEqual(text.utf8.count, wanted.1)
                if element.frame.intersects(app.frame) && !element.frame.isEmpty { seen[element.identifier] = hash }
            }
            XCTAssertFalse(control("search-preview-error-" + id).exists)
            if step == 0 { capture("full-context-" + mode + "-first") }
            let open = control("search-result-open-" + id)
            if seen.count == expected.count && open.exists && open.isHittable { break }
            try dragVisible(scroll, up: true)
        }
        XCTAssertEqual(Set(seen.keys), Set(expected.keys), "Every complete original source segment must become visible")
        capture("full-context-" + mode + "-last")
        let receipt = XCTAttachment(data: try JSONSerialization.data(withJSONObject: [
            "stableID": id, "mode": mode, "visibleSegmentHashes": seen,
            "expectedSegmentCount": expected.count
        ], options: [.sortedKeys]), uniformTypeIdentifier: "public.json")
        receipt.name = "actual-native-complete-context-" + mode
        receipt.lifetime = .keepAlways; test.add(receipt)
    }
}


// Test-only original-control observation around the final ordinary Settings Retry.
// The Settings test owns the two calls and must not terminate/relaunch between them.
@MainActor
struct OriginalSearchDataUpdateReadiness {
    struct Observation {
        fileprivate let sequenceID: String
        fileprivate let processID: Int
        fileprivate let capturedAtUnix: TimeInterval
        fileprivate let hierarchySHA256: String
        fileprivate let statuses: [String: String]
    }

    let app: XCUIApplication
    let test: XCTestCase
    private var ui: OriginalSearchContextUI { OriginalSearchContextUI(app: app, test: test) }

    private func admitOriginalSettingsLaunch() throws {
        for (key, value) in [("-OtzariaDataProfile", "production"), ("-preferredBackend", "otzaria"),
                             ("-AppleLanguages", "(en)"), ("-AppleLocale", "en_US")] {
            let positions = app.launchArguments.indices.filter { app.launchArguments[$0] == key }
            try requireSearchDataFixture(positions.count == 1, "Require the original English production Settings launch")
            let index = try XCTUnwrap(positions.first)
            try requireSearchDataFixture(app.launchArguments.indices.contains(index + 1)
                && app.launchArguments[index + 1] == value, "Unexpected original Settings launch value: " + key)
        }
        try requireSearchDataFixture(app.launchEnvironment["OTZARIA_DATA_PROFILE"] == "production"
            && !app.launchArguments.contains("-smokeBypassBootstrap")
            && !app.launchArguments.contains("-studyWorkspaceTestingNamespace"), "Keep the actual ordinary production workspace")
        for key in ["OTZARIA_SHARED_ROOT_OVERRIDE", "OTZARIA_PRODUCTION_DB_PATH"] {
            try requireSearchDataFixture(app.launchEnvironment[key] == nil
                && app.launchEnvironment["SIMCTL_CHILD_" + key] == nil, "No alternate source is eligible for warm update readiness")
        }
    }

    private func observedProcess(_ name: String) throws -> (id: Int, hierarchySHA256: String) {
        try requireSearchDataFixture(app.state == .runningForeground, "Observe the original foreground application")
        let hierarchy = app.debugDescription
        // XCTest's public original application hierarchy reports its own pid.
        // Require that actual field; never substitute the UI-test runner PID.
        let expression = try NSRegularExpression(pattern: #"(?m)^\s*(?:Attributes:\s*)?(?:→\s*)?Application,[^\r\n]*?\bpid:\s*([0-9]+)\b"#)
        let range = NSRange(hierarchy.startIndex..<hierarchy.endIndex, in: hierarchy)
        let matches = expression.matches(in: hierarchy, range: range)
        let identities = Set(matches.compactMap { match -> Int? in
            guard let value = Range(match.range(at: 1), in: hierarchy) else { return nil }
            return Int(hierarchy[value])
        })
        try requireSearchDataFixture(!matches.isEmpty && identities.count == 1,
            "The original public XCTest hierarchy must identify exactly one application PID")
        let pid = try XCTUnwrap(identities.first)
        try requireSearchDataFixture(pid > 1 && pid != Int(ProcessInfo.processInfo.processIdentifier),
            "A UI-test runner PID is not the observed application")
        let attachment = XCTAttachment(string: hierarchy)
        attachment.name = name + "-actual-application-pid-hierarchy"
        attachment.lifetime = .keepAlways
        test.add(attachment)
        return (pid, searchDataDigest(Data(hierarchy.utf8)))
    }

    private func dismissOriginalSettingsIfPresent() throws {
        let done = ui.control("settings-done-button")
        let updates = app.navigationBars["Library Updates"]
        if updates.exists && !done.isHittable {
            let back = updates.buttons.matching(NSPredicate(format: "label == %@", "Settings"))
                .allElementsBoundByIndex.filter(\.isHittable)
            try requireSearchDataFixture(back.count == 1, "Return through the original Library Updates back action")
            back[0].tap()
        }
        if done.exists {
            try requireSearchDataFixture(done.isHittable, "The original Settings Done action must be usable")
            done.tap()
            try ui.wait("Original Settings must dismiss without relaunch") { !self.ui.control("settings-done-button").exists }
        }
        try requireSearchDataFixture(!updates.exists, "Dismiss the original update presentation before using root Search")
    }

    private func openOriginalSearchData() throws {
        try dismissOriginalSettingsIfPresent()
        try ui.returnToOriginalSearch()
        try ui.require("global-search-more").tap()
        try ui.require("global-search-data").tap()
        try ui.require("search-data-screen")
    }

    private func closeOriginalDataAndReturnToLibrary() throws {
        for _ in 0..<8 {
            if ui.control("search-data-close").isHittable { break }
            try ui.require("search-data-screen").swipeUp()
        }
        let close = try ui.require("search-data-close")
        try requireSearchDataFixture(close.isHittable, "Reach the original Search Data close control")
        close.tap()
        try ui.wait("Original Search Data must dismiss") { !self.ui.control("search-data-screen").exists }
        let tabs = app.tabBars.buttons.matching(NSPredicate(format: "label == %@", "Library"))
            .allElementsBoundByIndex.filter { $0.isHittable && $0.frame.intersects(app.frame) }
        try requireSearchDataFixture(tabs.count == 1, "Require one original root Library tab in the admitted English UI")
        tabs[0].tap()
        try ui.wait("Return to the existing original Library tab without opening a book") { tabs[0].isSelected }
    }

    private func record(_ observation: Observation, previous: Observation?, updatedDatabaseBytes: Int64?) throws {
        let stem = previous == nil ? "settings-update-warm-search-ready-before-final-retry"
            : "settings-update-warm-search-mismatch-after-final-retry"
        var value: [String: Any] = [
            "schemaVersion": 1, "sequenceID": observation.sequenceID,
            "processID": observation.processID, "capturedAtUnix": observation.capturedAtUnix,
            "applicationHierarchySHA256": observation.hierarchySHA256, "statuses": observation.statuses,
            "phase": previous == nil ? "ready-before-final-original-retry" : "mismatch-after-final-original-retry",
            "processIdentitySource": "actual public XCUIApplication.debugDescription Application pid field",
            "launchArguments": app.launchArguments,
            "scope": "same-process original Search Data readiness around the final Settings Retry; no query, download, repair, Reader navigation or localization acceptance"
        ]
        if let previous {
            value["previousProcessID"] = previous.processID
            value["previousCapturedAtUnix"] = previous.capturedAtUnix
            value["previousApplicationHierarchySHA256"] = previous.hierarchySHA256
        }
        if let updatedDatabaseBytes { value["actualUpdatedDatabaseBytes"] = updatedDatabaseBytes }
        let attachment = XCTAttachment(data: try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys]),
                                       uniformTypeIdentifier: "public.json")
        attachment.name = stem
        attachment.lifetime = .keepAlways
        test.add(attachment)
    }

    func captureReadyBeforeFinalRetry() throws -> Observation {
        try admitOriginalSettingsLaunch()
        let before = try observedProcess("settings-update-warm-before-navigation")
        try openOriginalSearchData()
        let books = try ui.require("search-data-books-status")
        let otzaria = try ui.require("search-data-otzaria-status")
        let zayit = try ui.require("search-data-zayit-status")
        // These runtime status strings are the exact original Source values,
        // including in en_US; this test does not claim their localization.
        try ui.wait("Both actual installed v40 packages must be Ready in this process before the final update", timeout: 180) {
            books.label == "מוכן" && otzaria.label == "האינדקס מוכן (7925185 מסמכים)"
                && zayit.label == "מוכן · v40-20261123094345"
        }
        let actual = try observedProcess("settings-update-warm-ready")
        try requireSearchDataFixture(actual.id == before.id, "Opening original Search Data must not relaunch the app")
        let observation = Observation(sequenceID: UUID().uuidString, processID: actual.id,
            capturedAtUnix: Date().timeIntervalSince1970, hierarchySHA256: actual.hierarchySHA256,
            statuses: ["books": books.label, "otzaria": otzaria.label, "zayit": zayit.label])
        ui.capture("settings-update-warm-original-search-data-ready")
        try closeOriginalDataAndReturnToLibrary()
        try requireSearchDataFixture(try observedProcess("settings-update-warm-ready-return").id == observation.processID,
            "The final original Retry must start in the process that observed both Ready packages")
        try record(observation, previous: nil, updatedDatabaseBytes: nil)
        return observation
    }

    func captureMismatchAfterFinalRetry(previous: Observation, updatedDatabaseBytes: Int64) throws -> Observation {
        try admitOriginalSettingsLaunch()
        try requireSearchDataFixture(updatedDatabaseBytes > 0, "Use the actual updated database file size")
        let before = try observedProcess("settings-update-warm-after-success-before-navigation")
        try requireSearchDataFixture(before.id == previous.processID,
            "A cold relaunch cannot satisfy same-process update readiness")
        try openOriginalSearchData()
        let books = try ui.require("search-data-books-status")
        let otzaria = try ui.require("search-data-otzaria-status")
        let zayit = try ui.require("search-data-zayit-status")
        let mismatch = updatedDatabaseBytes == 4_355_063_808
            ? "the index was built for a different DB release" : "database size/identity mismatch"
        let otzariaMismatch = "נדרש תיקון לאינדקס: זהות האינדקס אינה תואמת למסד, למנוע או למשאבים הפעילים."
        let zayitMismatches: Set<String> = ["אין עדיין חבילה תואמת לגרסת מסד זו",
                                           "נדרש תיקון · The Zayit index is incompatible: " + mismatch]
        try ui.wait("The same process must revoke both old v40 readiness states after actual Settings success", timeout: 180) {
            books.label == "מוכן" && otzaria.label == otzariaMismatch && zayitMismatches.contains(zayit.label)
        }
        let changed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            MainActor.assumeIsolated { books.label != "מוכן" || otzaria.label != otzariaMismatch
                || !zayitMismatches.contains(zayit.label) }
        }, object: nil)
        changed.isInverted = true
        try requireSearchDataFixture(XCTWaiter.wait(for: [changed], timeout: 3) == .completed,
            "The mismatch must remain settled instead of restoring stale Ready state")
        let actual = try observedProcess("settings-update-warm-mismatch")
        try requireSearchDataFixture(actual.id == previous.processID, "Only the original Ready process can satisfy the warm rejection")
        let observation = Observation(sequenceID: previous.sequenceID, processID: actual.id,
            capturedAtUnix: Date().timeIntervalSince1970, hierarchySHA256: actual.hierarchySHA256,
            statuses: ["books": books.label, "otzaria": otzaria.label, "zayit": zayit.label])
        try requireSearchDataFixture(observation.capturedAtUnix > previous.capturedAtUnix, "The mismatch must follow the actual Ready observation")
        ui.capture("settings-update-warm-original-search-data-mismatch")
        try closeOriginalDataAndReturnToLibrary()
        try requireSearchDataFixture(try observedProcess("settings-update-warm-mismatch-return").id == previous.processID,
            "Return to Library in the same original process before the separate cold final check")
        try record(observation, previous: previous, updatedDatabaseBytes: updatedDatabaseBytes)
        return observation
    }
}

