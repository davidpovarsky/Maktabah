import gzip,hashlib,io,json,pathlib,re,shutil,subprocess,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='d55f5e6a30b08f9c0a5cd0e467d07c92f0e85937'
DONOR=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-annotations-selection-20261127/editor-controls-repo/source')
SOURCE='503c162f02cceb4185b3d0e5cae3d13f38b8ca2c'
DOCS='f8fbcf66943527367db807c964ab6265129ef804'
DONOR_BASE='b463ffd03a76026cea06c79c608df97d00094152'
BRANCH='codex/otzaria-wave3-integration-20261127'
FOLDER='docs/hq-ui-inventory/wave3-annotation-editor-controls-20261127'
PROOF='docs/hq-integration/wave3-warm-annotation-editor-intake-20261127'
PARSER_SHA256='eff5cf3c0935562f9e9b1bbcd296f192c4daf2922cc9185d8fa5ad0ab3246a18'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True,timeout=90)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failed '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def evidence(p):return show(DOCS,FOLDER+'/'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path')
def capacity():
 values={'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage('/mnt/development').free}
 assert values['rootFree']>=1342177280 and values['dataFree']>=2147483648,values
 return values
def commit(message):
 git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m',message)
 return rev('HEAD')
def function(text,signature):
 start=text.index(signature);pos=text.index('{',start);n=1;end=pos+1
 while n:
  if text[end]=='{':n+=1
  elif text[end]=='}':n-=1
  end+=1
 return text[start:end]
def apply(text,edits,left,right,count):
 for e in edits:
  assert text.count(e[left])==e.get(count,1),(e['path'],e[left][:80],text.count(e[left]))
  text=text.replace(e[left],e[right])
 return text
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');admission=capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',str(DONOR),DOCS)
 assert rev(SOURCE+'^')==DONOR_BASE and rev(DOCS+'^')==SOURCE
 manifest=evidence('MANIFEST.json');assert sha(manifest)=='956eb0a5e1e1a389e7129a039921c650ae900e8b7b415d345d3003a3f0002aeb'
 rows=json.loads(manifest)['files'];assert len(rows)==84
 docsPaths={FOLDER+'/'+r['path']for r in rows}|{FOLDER+'/MANIFEST.json'}
 assert set(git('diff-tree','--no-commit-id','--name-only','-r',DOCS).decode().splitlines())==docsPaths
 for row in rows:pin(evidence(row['path']),row)
 pins=json.loads(evidence('SOURCE_PINS.json'));sources=pins['source'];assert len(sources)==4
 assert set(git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines())=={r['path']for r in sources}
 git('diff','--check',SOURCE+'^',SOURCE)
 for row in sources:
  after=show(SOURCE,row['path']);pin(after,row);assert after==evidence('candidate/'+row['path'])
  if row['before_sha256'] is None:
   assert not git('ls-tree',BASE,'--',row['path']) and not (ROOT/row['path']).exists()
  else:
   before=show(BASE,row['path']);assert sha(before)==row['before_sha256']
   assert before==evidence('baseline/'+row['path'])
 hooks=json.loads(evidence('ORIGINAL_HOOK_EDITS.json'));assert len(hooks['edits'])==37
 for row in hooks['files']:
  before=show(BASE,row['path']);after=show(SOURCE,row['path']);ed=[e for e in hooks['edits']if e['path']==row['path']]
  assert apply(before.decode(),ed,'old','new','occurrences').encode()==after
  assert apply(after.decode(),list(reversed(ed)),'new','old','occurrences').encode()==before
 shared=json.loads(evidence('proposal/SHARED_EDITS.json'));assert len(shared['edits'])==47
 for row in shared['files']:
  before=show(BASE,row['path']);after=evidence('proposal/candidate/'+row['path']);ed=[e for e in shared['edits']if e['path']==row['path']]
  assert len(before)==row['before_bytes']and sha(before)==row['before_sha256']
  assert len(after)==row['after_bytes']and sha(after)==row['after_sha256']
  assert before==evidence('baseline/'+row['path'])
  assert apply(before.decode(),ed,'old','new','count').encode()==after
  assert apply(after.decode(),list(reversed(ed)),'new','old','count').encode()==before
 joins=json.loads(evidence('CURRENT_MODULE_SOURCE_JOIN.json'));assert len(joins['files'])==85 and joins['counts']=={'Core':31,'Host':41,'UI':13}
 for row in joins['files']:
  pin(show(BASE,row['path']),row);pin(pathlib.Path(row['compiled_input']).read_bytes(),row)
 for row in joins['products']:pin(pathlib.Path(row['path']).read_bytes(),row)
 reports=json.loads(evidence('RAW_VERIFICATION.json'))['attempts'];assert len(reports)==4
 rawMembers=0;runtimeJoins=[]
 expected=[(None,None,0,33),(25,0,8,60),(4,0,2,41),(17,0,10,77)]
 for report,counts in zip(reports,expected):
  attempt=report['attempt'];prefix='evidence/'+attempt+'/'
  result=evidence(prefix+'RESULT.json');assert sha(result)==report['result_sha256']
  assert (pathlib.Path(report['remote_scope'])/'RESULT.json').read_bytes()==result
  actual=json.loads(result)
  assert (report['passed'],report['failed'],report['full_swift_syntax'],report['zip_members'])==counts
  assert actual['status']==report['status']and actual['native']==actual['apple_sdk']=='NOT_RUN'
  if report['passed']is not None:
   assert actual['passed']==report['passed']and actual['failed']==0
   assert actual['original_module_counts']==joins['counts']
  archive=evidence(prefix+'RAW.zip');assert sha(archive)==report['raw_sha256']and len(archive)==report['raw_bytes']
  rawManifest=evidence(prefix+'RAW_MANIFEST.json');assert sha(rawManifest)==report['manifest_sha256']
  rawRows=json.loads(rawManifest);assert len(rawRows)==report['raw_files']
  with zipfile.ZipFile(io.BytesIO(archive))as z:
   assert len(z.namelist())==report['zip_members']and set(z.namelist())=={r['path']for r in rawRows}|{'RAW_MANIFEST.json'}
   assert z.read('RAW_MANIFEST.json')==rawManifest
   for row in rawRows:pin(z.read(row['path']),row)
   if report['passed']is not None:
    names=[n for n in z.namelist()if n.endswith('actual-runtime-library-identity.stdout')]
    assert len(names)==1,names
    output=z.read(names[0]).decode()
    for product in joins['products']:
     if product['path'].endswith('.so'):assert product['path']in output
    runtimeJoins.append({'attempt':attempt,'path':names[0],'sha256':sha(output.encode())})
  rawMembers+=report['zip_members']
 extraction=json.loads(evidence('controls/SCENE_EXTRACTION.json'))
 session=evidence('proposal/candidate/Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift')
 assert sha(session)==extraction['session_sha256']
 capsule=evidence('controls/ActualEditorSessionCapsule.swift');assert sha(capsule)==extraction['capsule_sha256']
 for method in extraction['actual_methods']:
  body=function(session.decode(),method['signature']);pin(body.encode(),method)
  assert body in capsule.decode()
 # Use the existing narrow project graph parser, retained byte-for-byte beside this script.
 parserPath=RUN/'verify_source_registration.py'
 assert sha(parserPath.read_bytes())==PARSER_SHA256
 parser={'__name__':'registration_intake'};exec(compile(parserPath.read_bytes(),str(parserPath),'exec'),parser)
 projectPath='Maktabah.xcodeproj/project.pbxproj';projectBefore=show(BASE,projectPath)
 assert sha(projectBefore)=='fc57161817ff43a7f018a942f6511dc3e759e2b832e47eaac691d13ae8527fab'
 old,dups=parser['parse'](projectBefore.decode());objects=old['objects'];phases=parser['target_sources'](old)
 text=projectBefore.decode();insertions=[];ids=[];changed=set()
 def insert(offset,value):
  global text
  text=text[:offset]+value+text[offset:];insertions.append({'offset':offset,'text':value})
 membership=json.loads(evidence('MEMBERSHIP_LOCALIZATION.json'))
 assert len(membership['new_ios_app_source_files'])==2 and membership['new_app_shortcuts']==0
 for path in membership['new_ios_app_source_files']:
  relative=path.removeprefix('Source/ChavrusaText/');name=pathlib.Path(path).name
  ref=sha(('wave3-warm-editor-ref:'+relative).encode())[:24].upper()
  build=sha(('wave3-warm-editor-build:Maktabah-iOS:'+relative).encode())[:24].upper()
  assert ref not in objects and build not in objects
  assert not any(o.get('isa')=='PBXFileReference'and o.get('path')in[path,relative]for o in objects.values())
  ids.extend([ref,build])
  insert(text.index('/* End PBXBuildFile section */'),'\t\t'+build+' /* '+name+' in Sources */ = {isa = PBXBuildFile; fileRef = '+ref+' /* '+name+' */; };\n')
  insert(text.index('/* End PBXFileReference section */'),'\t\t'+ref+' /* '+name+' */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = "'+relative+'"; sourceTree = "<group>"; };\n')
  for key,field,value in [('CFEE00000000000000000001','children','\t\t\t\t'+ref+' /* '+name+' */,\n'),(phases['Maktabah-iOS'][0],'files','\t\t\t\t'+build+' /* '+name+' in Sources */,\n')]:
   start=re.search(r'(?m)^\t\t'+key+r' /\*[^*]+\*/ = \{\n',text).start()
   anchor='\t\t\t'+field+' = (\n';insert(text.index(anchor,start)+len(anchor),value);changed.add(key)
 projectAfter=text.encode();new,newDups=parser['parse'](text);updated=new['objects']
 assert dups==newDups and {k for k in objects if objects[k]!=updated[k]}==changed
 assert set(updated)-set(objects)==set(ids)
 assert {k:v for k,v in old.items()if k!='objects'}=={k:v for k,v in new.items()if k!='objects'}
 for key in changed:
  field='children'if key=='CFEE00000000000000000001'else'files'
  assert {k:v for k,v in objects[key].items()if k!=field}=={k:v for k,v in updated[key].items()if k!=field}
  assert [k for k in updated[key][field]if k in objects[key][field]]==objects[key][field]
 for ref,build in zip(ids[::2],ids[1::2]):
  assert updated['CFEE00000000000000000001']['children'].count(ref)==1
  assert [k for k,(_,members)in parser['target_sources'](new).items()if build in members]==['Maktabah-iOS']
 inverse=text
 for e in reversed(insertions):
  assert inverse[e['offset']:e['offset']+len(e['text'])]==e['text']
  inverse=inverse[:e['offset']]+inverse[e['offset']+len(e['text']):]
 assert inverse.encode()==projectBefore
 catalogPath='Source/Localizable.xcstrings';catalogBefore=show(BASE,catalogPath)
 assert sha(catalogBefore)=='7e832c642eb8fc5eca44e1f4a5296e5fe9f11fd8eee97ccfbd476867c4a2908b'
 catalog=json.loads(catalogBefore);assert (json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()==catalogBefore
 assert len(membership['localization'])==4
 for row in membership['localization']:
  assert row['key']not in catalog['strings']
  catalog['strings'][row['key']]={'localizations':{lang:{'stringUnit':{'state':'translated','value':row[lang]}}for lang in ['en','he']}}
 catalogAfter=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()
 for row in membership['localization']:del catalog['strings'][row['key']]
 assert (json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()==catalogBefore
 protected=['Vendor','Source/UI','Source/Core','Source/LibraryBackend','Source/Otzaria','Scripts','.github','Maktabah-iOSUITests','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 picked=[]
 for donor in [SOURCE,DOCS]:
  git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',donor)
  picked.append({'donor':donor,'intake':rev('HEAD')});assert not git('status','--porcelain')
 for row in shared['files']:(ROOT/row['path']).write_bytes(evidence('proposal/candidate/'+row['path']))
 (ROOT/projectPath).write_bytes(projectAfter);(ROOT/catalogPath).write_bytes(catalogAfter)
 changedSource={r['path']for r in sources}|{r['path']for r in shared['files']}|{catalogPath}
 git('add','--sparse','--',*[r['path']for r in shared['files']],projectPath,catalogPath)
 sharedCommit=commit('Connect the original open Annotation editor to retained native component navigation')
 assert set(git('diff','--name-only',BASE,'HEAD','--','Source').decode().splitlines())==changedSource
 for row in sources:pin(show('HEAD',row['path']),row)
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 (proof/'verify_source_registration.py').write_bytes(parserPath.read_bytes())
 dump(proof/'REGISTRATION.json',{'beforeSHA256':sha(projectBefore),'afterSHA256':sha(projectAfter),'insertions':insertions,'newObjects':ids,'newSources':membership['new_ios_app_source_files'],'target':'Maktabah-iOS','originalObjectsAndOrderPreserved':True,'inheritedDuplicatesPreserved':dups,'inverseByteExact':True})
 dump(proof/'LOCALIZATION.json',{'beforeSHA256':sha(catalogBefore),'afterSHA256':sha(catalogAfter),'added':membership['localization'],'allExistingEntriesUnchanged':True,'newShortcuts':0})
 result={'schema':'otzaria.wave3.warm-annotation-editor-intake.v1','base':BASE,'picked':picked,'sharedCommit':sharedCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'sourceFiles':sources,'originalHookHunks':37,'sharedFiles':shared['files'],'sharedHunks':47,'docsPaths':85,'manifestSHA256':sha(manifest),'rawMembersVerified':rawMembers,'sourceModuleCounts':joins['counts'],'sourceModulePathsRejoined':85,'runtimeLibraries':runtimeJoins,'sourceControlScopes':reports,'finalSessionCapsule':extraction,'membershipSources':2,'localizationKeys':4,'protectedTrees':trees,'admission':admission,'nativeRuns':0,'AppleSDK':'NOT_RUN','sourcePeerReview':{'reviewer':'ui_acceptance','afterDonorDocsCommit':True,'readExactFinalOwnerViewsSheetList':True,'result':'No demonstrated blocker in retained parent before component, callback membership, consumed scroll/focus/report, first exact Tags join, default-nil behavior, plain-editing gate or final onCreated prepublication. Source only; no rerun.'},'limitations':['Warm existing global List editor only; saved-record opening and original filter/sort remain separate.','The25,4,17source control scopes remain separate, with explicit platform boundaries and preserved negative/compiler failures.','No SDK/native/production/physical result is inferred from Linux source controls or syntax parses.','Final genuine owner gate, target merge, Archive, signing and TestFlight remain open.']}
 dump(proof/'RESULT.json',result)
 git('add','--sparse','--',PROOF);final=commit('Preserve verified original Annotation editor source intake and acceptance boundaries')
 assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==final
 terminal={'ok':True,'head':final,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'picked':picked,'sharedCommit':sharedCommit,'projectSHA256':sha(projectAfter),'catalogSHA256':sha(catalogAfter),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage('/mnt/development').free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
