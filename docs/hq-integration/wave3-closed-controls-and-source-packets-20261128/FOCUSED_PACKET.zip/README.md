# Closed focused evidence preservation

This packet preserves all 945 closed focused entries: 821 regular-file payloads, 123 directory records, and one symlink target without following it. It also preserves the exact external closure receipt and verifier.

PACKET.zip contains MANIFEST.json, the byte-exact decoded CLOSURE_MANIFEST.json, and full content-addressed blobs. MANIFEST maps every logical file to its complete payload, preserves full captured stat metadata and xattrs, and records hardlink groups and any unresolved outside link count. No arbitrary extraction or restoration was performed. Original inode, ctime and allocation values are provenance; a later restoration would create new filesystem identities.

The original closure contains its pre-shrink self metadata. The packaging manifest separately captures and verifies the final 58,293-byte closure and 61,440-byte allocation. Original closure atimes remain in the decoded manifest; packaging atimes were captured before each packaging content read and excluded from subsequent stability comparisons. Reading can advance atime. All original payloads, stable metadata, path membership and link targets were compared again after archive readback.

This is preservation of focused evidence only. It does not rerun controls, enumerate Native116, authenticate, upload, qualify an SDK/app, or retire any source. Historical negative results and archived source versions remain unchanged.
