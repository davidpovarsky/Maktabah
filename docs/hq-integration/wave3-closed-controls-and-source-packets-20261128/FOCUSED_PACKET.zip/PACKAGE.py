"""Lossless closed focused-evidence packaging; no tests, Native116, auth, or retirement."""
if not __debug__:
    raise RuntimeError("Optimized packaging refused")
import argparse,base64,datetime,gzip,hashlib,io,json,os,pathlib,shutil,stat,time,zipfile
R=pathlib.Path('/home/ubuntu/otzaria-wave3-native116-v3-focused-controls-20261128')
E=pathlib.Path('/home/ubuntu/otzaria-wave3-native116-focused-external-review-20261128')
O=pathlib.Path('/home/ubuntu/otzaria-wave3-focused-closed-evidence-preservation-20261128')
CAP=8*1024**2;FLOOR=1593835520;FILE_CAP=1024**2;REPORT_CAP=65536
CLOSE_SHA='00a78c8d29416c20af3c4cd40661601b5fad3de78e6e12b3f137196377bce036'
DECODED_SHA='4298d4775f55d8b61bf18967fe7c55072ae766527ae19f8448d7f36b5b1009a0'
EXTERNAL={'EXTERNAL_REVIEW.json':(857,'2439900631482622367a1e3e55b9d8b70a5db47cc57f020f4d39dd07f01de009'),'VERIFY.py':(5836,'adcf18e771bf9652a4b1fa12604bb074a6725824e717bfbbc474a1079aa6b953')}
OUTPUT_NAMES={'PACKAGE.py','RESULT.json','PACKET.zip','MANIFEST.json','CLOSURE_MANIFEST.json','EXTERNAL_REVIEW.json','VERIFY_EXTERNAL.py','README.md'}
DEADLINE=None;PARENT=None;ROOT_ID=None
def need(x,m):
    if not x:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode('ascii')
def ident(s):
    return(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_blocks,s.st_mtime_ns,s.st_ctime_ns)
def meta(s):
    v={'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'nlink':s.st_nlink,
       'bytes':s.st_size,'blocks':s.st_blocks,'blockSize':s.st_blksize,'rdev':s.st_rdev,
       'atimeNS':str(s.st_atime_ns),'mtimeNS':str(s.st_mtime_ns),'ctimeNS':str(s.st_ctime_ns)}
    v['optionalStatFields']={k:getattr(s,k) for k in ('st_flags','st_gen','st_birthtime_ns') if hasattr(s,k)}
    v['unavailableOptionalStatFields']=[k for k in ('st_flags','st_gen','st_birthtime_ns') if not hasattr(s,k)]
    return v
def stable(v):return{k:x for k,x in v.items()if k!='atimeNS'}
def guard(addition=0):
    need(time.monotonic()<DEADLINE and os.getppid()==PARENT,'Owned packaging deadline/parent')
    need(shutil.disk_usage('/').free>=FLOOR+CAP,'Root floor plus full separate8MiB packet reserve')
    before=O.lstat()
    need(O.resolve(strict=True)==O and stat.S_ISDIR(before.st_mode) and (before.st_dev,before.st_ino)==ROOT_ID and before.st_uid==1001 and before.st_gid==1001,'Exact new owned output root')
    used=before.st_blocks*512
    names=os.listdir(O);need(set(names)<=OUTPUT_NAMES,'Closed output leaves')
    for name in names:
        s=(O/name).lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_dev==before.st_dev,'Output regular single same-device only')
        used+=s.st_blocks*512
    need(used+addition+8192<=CAP,'Exact separate8MiB packet allocation cap')
    return used
def fsync_dir(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:os.fsync(fd)
    finally:os.close(fd)
def read_regular(path,limit=FILE_CAP,single=False):
    need(path.resolve(strict=True)==path,'Exact unsymlinked regular path')
    s=path.lstat();need(stat.S_ISREG(s.st_mode) and (not single or s.st_nlink==1) and s.st_size<=limit,'Bounded regular source')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        need(ident(os.fstat(fd))==ident(s),'Regular open identity')
        with os.fdopen(os.dup(fd),'rb')as f:b=f.read(limit+1)
        need(len(b)==s.st_size and ident(os.fstat(fd))==ident(s)==ident(path.lstat()),'Full stable regular source')
    finally:os.close(fd)
    return b,s
def attrs(path,expected):
    need(ident(path.lstat())==ident(expected),'Metadata path identity before xattrs')
    names=sorted(os.listxattr(path,follow_symlinks=False),key=os.fsencode)
    rows=[{'nameBase64':base64.b64encode(os.fsencode(n)).decode('ascii'),'valueBase64':base64.b64encode(os.getxattr(path,n,follow_symlinks=False)).decode('ascii')}for n in names]
    need(len(rows)<=256 and sum(len(r['valueBase64'])for r in rows)<=262144,'Bounded complete xattrs; no omission')
    need(ident(path.lstat())==ident(expected),'Metadata path identity after xattrs')
    return rows
def write_new(name,b):
    need(name in OUTPUT_NAMES and name not in ('PACKAGE.py','RESULT.json'),'Closed new packet leaf')
    guard(((len(b)+4095)//4096)*4096)
    fd=os.open(O/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o640)
    try:
        v=memoryview(b)
        while v:
            n=os.write(fd,v);need(n>0,'Complete packet write');v=v[n:]
        os.fsync(fd)
    finally:os.close(fd)
    fsync_dir(O)
    need(read_regular(O/name,max(len(b),1),True)[0]==b,'Complete packet leaf readback')
    guard()
def source_tree(expected):
    rows=[];payloads={};total=0
    root_before=R.lstat()
    need(R.resolve(strict=True)==R and (root_before.st_dev,root_before.st_ino,root_before.st_uid,root_before.st_gid)==(2049,632142,1001,1001),'Exact focused source root')
    rfd=os.open(R,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    def walk(fd,rel,depth):
        nonlocal total
        need(rel in expected and expected[rel]['kind']=='directory','Only closed manifest directories')
        guard();need(depth<=5 and len(rows)<1200,'Original finite source depth/count')
        path=R if rel=='.'else R/rel;s=os.fstat(fd)
        need(ident(path.lstat())==ident(s) and s.st_dev==root_before.st_dev,'Pinned source directory and named path')
        entry={'scope':'focused','path':rel,'pathBase64':base64.b64encode(os.fsencode(rel)).decode('ascii'),'kind':'directory','metadata':meta(s),'xattrs':attrs(path,s)}
        rows.append(entry)
        names=sorted(os.listdir(fd),key=os.fsencode)
        for name in names:
            need(name not in ('.','..') and '/'not in name and '\0'not in name,'Single source basename')
            child=name if rel=='.'else rel+'/'+name
            need(child in expected,'No read outside exact closed membership')
            p=R/child;before=os.stat(name,dir_fd=fd,follow_symlinks=False)
            need(before.st_dev==root_before.st_dev and ident(p.lstat())==ident(before),'Named same-device child')
            if stat.S_ISDIR(before.st_mode):
                sub=os.open(name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
                try:
                    need(ident(os.fstat(sub))==ident(before),'No-follow child directory identity')
                    walk(sub,child,depth+1)
                finally:os.close(sub)
            else:
                need(len(rows)<1200,'Complete finite source membership')
                a=attrs(p,before)
                row={'scope':'focused','path':child,'pathBase64':base64.b64encode(os.fsencode(child)).decode('ascii'),'metadata':meta(before),'xattrs':a}
                if stat.S_ISREG(before.st_mode):
                    need(before.st_size<=FILE_CAP,'Original verifier per-file bound')
                    f=os.open(name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=fd)
                    try:
                        need(ident(os.fstat(f))==ident(before),'Pinned source file identity')
                        with os.fdopen(os.dup(f),'rb')as h:b=h.read(FILE_CAP+1)
                        need(len(b)==before.st_size and ident(os.fstat(f))==ident(before),'Full stable source payload')
                    finally:os.close(f)
                    digest=sha(b);total+=len(b);need(total<=16*1024**2,'Finite original logical payload bound')
                    if digest in payloads:need(payloads[digest]==b,'No digest collision')
                    payloads[digest]=b
                    row.update(kind='file',content={'bytes':len(b),'sha256':digest,'archiveMember':'blobs/'+digest})
                elif stat.S_ISLNK(before.st_mode):
                    target=os.fsencode(os.readlink(name,dir_fd=fd))
                    need(len(target)<=65536,'Complete bounded symlink target')
                    row.update(kind='symlink',targetBase64=base64.b64encode(target).decode('ascii'),targetFollowed=False)
                else:raise RuntimeError('Unsupported original source type; nothing omitted')
                need(ident(os.stat(name,dir_fd=fd,follow_symlinks=False))==ident(before) and attrs(p,before)==a,'Source leaf metadata stable')
                rows.append(row)
        need(sorted(os.listdir(fd),key=os.fsencode)==names and ident(os.fstat(fd))==ident(s) and attrs(path,s)==entry['xattrs'],'Stable complete directory')
    try:
        need(ident(os.fstat(rfd))==ident(root_before),'Root descriptor identity')
        walk(rfd,'.',0)
    finally:os.close(rfd)
    need(len(rows)==945 and {r['path']for r in rows}==set(expected),'Exact original945 path set')
    for row in rows:
        old=expected[row['path']];m=row['metadata']
        need(row['kind']==old['kind'] and m['uid']==old['uid'] and m['gid']==old['gid'],'Original closure kind/owner')
        actual={'device':m['device'],'inode':m['inode'],'mode':m['mode'],'nlink':m['nlink'],'bytes':m['bytes'],'mtimeNS':m['mtimeNS'],'ctimeNS':m['ctimeNS']}
        if row['path']=='CONTROLS_CLOSED.json':
            need(actual=={'device':2049,'inode':632304,'mode':33152,'nlink':1,'bytes':58293,'mtimeNS':'1795838877715364339','ctimeNS':'1795838877715364339'} and m['blocks']*512==61440,'Exact final closure self identity')
            need(row['content']['sha256']==CLOSE_SHA,'Exact current closure self payload')
        else:
            need(actual==old['identity'] and m['blocks']*512==old['allocatedBytes'],'Original closure metadata preserved')
            if row['kind']=='file':need(row['content']['sha256']==old['sha256'],'Full original closure payload hash')
        if row['kind']=='symlink':need(row['targetBase64']==old['targetBase64'],'Exact original link target')
    need(sum(r['metadata']['blocks']*512 for r in rows)==3932160,'Exact externally verified source allocation')
    kinds={k:sum(r['kind']==k for r in rows)for k in ('file','directory','symlink')}
    need(kinds=={'file':821,'directory':123,'symlink':1},'Exact complete source kinds')
    return sorted(rows,key=lambda r:os.fsencode(r['path'])),payloads,total
def external_capture():
    rows=[];payloads={}
    need(E.resolve(strict=True)==E,'Exact external proof parent')
    before=E.lstat();need(stat.S_ISDIR(before.st_mode)and before.st_uid==1001,'Owned external proof directory')
    for name,(size,digest)in EXTERNAL.items():
        p=E/name;s=p.lstat();a=attrs(p,s);b,now=read_regular(p,65536,True)
        need(ident(s)==ident(now)and len(b)==size and sha(b)==digest and attrs(p,now)==a,'Exact external proof metadata/bytes')
        rows.append({'scope':'external','path':name,'pathBase64':base64.b64encode(os.fsencode(name)).decode('ascii'),'kind':'file','metadata':meta(s),'xattrs':a,'content':{'bytes':size,'sha256':digest,'archiveMember':'blobs/'+digest}})
        payloads[digest]=b
    need(ident(E.lstat())==ident(before),'External parent unchanged')
    return rows,payloads
def make_archive(manifest,decoded,payloads):
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=False)as z:
        members={'MANIFEST.json':manifest,'CLOSURE_MANIFEST.json':decoded,**{'blobs/'+k:v for k,v in payloads.items()}}
        for name,b in sorted(members.items()):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    raw=out.getvalue();need(len(raw)<=6*1024**2,'Bounded complete content-addressed archive')
    with zipfile.ZipFile(io.BytesIO(raw))as z:
        infos=z.infolist();need(len(infos)==len(members)and{n.filename for n in infos}==set(members),'Exact complete archive member set')
        for inf in infos:
            need(not inf.is_dir()and inf.compress_type==zipfile.ZIP_DEFLATED and not inf.flag_bits&1 and stat.S_ISREG(inf.external_attr>>16),'Closed archive encoding')
            b=z.read(inf);need(b==members[inf.filename],'Every full decoded member equals original')
        need(z.read('MANIFEST.json')==manifest and z.read('CLOSURE_MANIFEST.json')==decoded,'Full metadata decode equality')
    return raw,len(members)
def main():
    global DEADLINE,PARENT,ROOT_ID
    parser=argparse.ArgumentParser();parser.add_argument('--source-sha256',required=True);args=parser.parse_args()
    need(sys_flags(),'Original isolated owner runtime')
    DEADLINE=time.monotonic()+120;PARENT=os.getppid()
    root=O.lstat();ROOT_ID=(root.st_dev,root.st_ino)
    need(O.resolve(strict=True)==O and stat.S_ISDIR(root.st_mode)and root.st_uid==1001 and root.st_gid==1001 and set(os.listdir(O))=={'PACKAGE.py'},'Exclusive new packet source-only scope')
    own=pathlib.Path(__file__);need(own==O/'PACKAGE.py','Exact own controller')
    controller,_=read_regular(own,32768,True);need(sha(controller)==args.source_sha256,'Exact controller bytes')
    guard(REPORT_CAP)
    report=os.open(O/'RESULT.json',os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o640)
    try:
        remaining=REPORT_CAP
        while remaining:
            n=os.write(report,bytes(min(4096,remaining)));need(n>0,'Full reserved result allocation');remaining-=n
        os.fsync(report);fsync_dir(O)
    except BaseException:
        os.close(report);raise
    result={'schema':'otzaria.closed-focused-evidence-packet/1','status':'INCOMPLETE','controllerSHA256':sha(controller),'sourceRoot':str(R),'outputRoot':str(O)}
    stage='PINNED_CLOSURE_READ'
    try:
        body,_=read_regular(R/'CONTROLS_CLOSED.json',65536,True)
        need(len(body)==58293 and sha(body)==CLOSE_SHA,'Exact completed closure')
        envelope=json.loads(body);need(canonical(envelope)==body and envelope['noFurtherScopeWrites']and envelope['closureSelfIdentityIsBeforeFinalShrink'],'Original closure boundaries')
        compressed=base64.b64decode(envelope['manifestGzipBase64'],validate=True)
        need(len(compressed)==43200 and sha(compressed)==envelope['manifestGzipSHA256'],'Exact full compressed closure metadata')
        with gzip.GzipFile(fileobj=io.BytesIO(compressed),mode='rb')as z:
            decoded=z.read(381407);need(z.read(1)==b'','Full original manifest EOF')
        need(len(decoded)==381406 and sha(decoded)==DECODED_SHA==envelope['manifestSHA256'],'Exact full decoded closure')
        original=json.loads(decoded);need(canonical(original)==decoded,'Original canonical manifest')
        expected={r['path']:r for r in original['entries']};need(len(expected)==945,'Original exact manifest membership')
        stage='SOURCE_CAPTURE'
        rows,payloads,total=source_tree(expected)
        external,extra=external_capture()
        for digest,b in extra.items():
            if digest in payloads:need(payloads[digest]==b,'Exact shared external digest bytes')
            payloads[digest]=b
        groups={}
        for row in rows+external:
            if row['kind']=='file':
                m=row['metadata'];key=str(m['device'])+':'+str(m['inode'])
                groups.setdefault(key,[]).append(row)
        hardlinks=[]
        for key,group in sorted(groups.items()):
            declared=group[0]['metadata']['nlink']
            need(all(r['metadata']['nlink']==declared and r['content']==group[0]['content']for r in group),'Exact hardlink content/identity join')
            need(declared>=len(group),'Captured hardlink topology')
            if declared>1:
                hardlinks.append({'originalDeviceInode':key,'declaredNlink':declared,'capturedPaths':[r['scope']+'/'+r['path']for r in group],'unresolvedExternalLinkCount':declared-len(group)})
                for r in group:r['hardlinkGroup']=key
        manifest={'schema':'otzaria.lossless-focused-content-addressed-archive/1','controllerSHA256':sha(controller),'sourceRoot':str(R),'externalProofRoot':str(E),
                  'originalClosure':{'bytes':len(body),'sha256':CLOSE_SHA,'decodedManifestBytes':len(decoded),'decodedManifestSHA256':DECODED_SHA},
                  'sourceEntries':rows,'externalProofEntries':external,'hardlinkTopology':hardlinks,
                  'sourceEntryCount':945,'sourceKinds':{'file':821,'directory':123,'symlink':1},'sourceLogicalFileBytes':total,'sourceAllocatedBytes':3932160,
                  'payloads':{k:{'bytes':len(v),'sha256':k,'archiveMember':'blobs/'+k}for k,v in sorted(payloads.items())},
                  'metadataBoundary':{'statIdentitiesCaptured':True,'allXattrsCaptured':True,'atimeCapturedBeforeEachPackagingRead':True,'atimeMayAdvanceFromRead':True,'sourceStabilityExcludesOnlyAtime':True,
                                      'originalClosureSelfMetadataIsBeforeShrink':True,'currentSelfMetadataAndBytesCaptured':True,'externalSymlinkTargetPreservedNotFollowed':True,
                                      'outsideHardlinkNamesNotDiscovered':True,'inodeCtimeAndAllocationAreProvenanceNotNewFilesystemIdentity':True,'unused':None}}
        manifest['metadataBoundary'].pop('unused')
        raw=canonical(manifest);need(len(raw)<=2*1024**2,'Complete metadata bound; no omissions')
        stage='ARCHIVE_GENERATION_AND_FULL_DECODE'
        archive,members=make_archive(raw,decoded,payloads)
        readme=('# Closed focused evidence preservation\n\nThis packet preserves all 945 closed focused entries: 821 regular-file payloads, 123 directory records, and one symlink target without following it. It also preserves the exact external closure receipt and verifier.\n\nPACKET.zip contains MANIFEST.json, the byte-exact decoded CLOSURE_MANIFEST.json, and full content-addressed blobs. MANIFEST maps every logical file to its complete payload, preserves full captured stat metadata and xattrs, and records hardlink groups and any unresolved outside link count. No arbitrary extraction or restoration was performed. Original inode, ctime and allocation values are provenance; a later restoration would create new filesystem identities.\n\nThe original closure contains its pre-shrink self metadata. The packaging manifest separately captures and verifies the final 58,293-byte closure and 61,440-byte allocation. Original closure atimes remain in the decoded manifest; packaging atimes were captured before each packaging content read and excluded from subsequent stability comparisons. Reading can advance atime. All original payloads, stable metadata, path membership and link targets were compared again after archive readback.\n\nThis is preservation of focused evidence only. It does not rerun controls, enumerate Native116, authenticate, upload, qualify an SDK/app, or retire any source. Historical negative results and archived source versions remain unchanged.\n').encode()
        stage='PACKET_WRITES'
        planned=[('PACKET.zip',archive),('MANIFEST.json',raw),('CLOSURE_MANIFEST.json',decoded),('EXTERNAL_REVIEW.json',extra[EXTERNAL['EXTERNAL_REVIEW.json'][1]]),('VERIFY_EXTERNAL.py',extra[EXTERNAL['VERIFY.py'][1]]),('README.md',readme)]
        guard(sum(((len(b)+4095)//4096)*4096 for name,b in planned))
        for name,b in [('PACKET.zip',archive),('MANIFEST.json',raw),('CLOSURE_MANIFEST.json',decoded),('EXTERNAL_REVIEW.json',extra[EXTERNAL['EXTERNAL_REVIEW.json'][1]]),('VERIFY_EXTERNAL.py',extra[EXTERNAL['VERIFY.py'][1]]),('README.md',readme)]:
            write_new(name,b)
        # Verify the persisted archive's full member contents, not only its outer hash.
        persisted,_=read_regular(O/'PACKET.zip',6*1024**2,True)
        need(persisted==archive,'Exact persisted archive')
        with zipfile.ZipFile(io.BytesIO(persisted))as z:
            need(len(z.infolist())==members,'Persisted archive exact membership')
            need(z.read('MANIFEST.json')==raw and z.read('CLOSURE_MANIFEST.json')==decoded,'Persisted full metadata')
            for digest,b in payloads.items():need(z.read('blobs/'+digest)==b,'Persisted full payload member readback')
        stage='FINAL_SOURCE_JOIN'
        again,again_payloads,again_total=source_tree(expected)
        ext_again,ext_payloads=external_capture()
        # Hardlink group labels are derived from already-compared native identities.
        def comparison(rs):return[{k:(stable(v)if k=='metadata'else v)for k,v in r.items()if k!='hardlinkGroup'}for r in rs]
        need(comparison(again)==comparison(rows)and comparison(ext_again)==comparison(external),'All pre/post source metadata/path/link/bytes unchanged except atime')
        need(again_total==total and set(again_payloads)|set(ext_payloads)==set(payloads),'Full final payload membership')
        for digest,b in {**again_payloads,**ext_payloads}.items():need(b==payloads[digest],'Full source equality after archive readback')
        guard()
        result.update(status='FULL_PACKET_AND_SOURCE_VERIFIED',sourceEntryCount=945,sourceRegularFiles=821,sourceDirectories=123,sourceSymlinks=1,
                      externalRegularFiles=2,uniquePayloadMembers=len(payloads),archiveMembers=members,hardlinkGroups=len(hardlinks),
                      unresolvedOutsideHardlinks=sum(g['unresolvedExternalLinkCount']for g in hardlinks),
                      archive={'path':'PACKET.zip','bytes':len(archive),'sha256':sha(archive)},
                      manifest={'path':'MANIFEST.json','bytes':len(raw),'sha256':sha(raw)},
                      originalClosure={'bytes':len(body),'sha256':CLOSE_SHA,'decodedManifestBytes':len(decoded),'decodedManifestSHA256':DECODED_SHA},
                      allFullPayloadAndMetadataMembersVerified=True,fullSourcePrePostJoin=True,sourceBytesAndStableMetadataUnchanged=True,
                      atimeMayAdvanceFromRead=True,sourceRetired=False,testsRun=0,native116Enumeration=False,auth=False,upload=False,
                      sourceAllocatedBytes=3932160,packetAllocatedBeforeResultShrink=guard(),
                      filePins={name:{'bytes':len(b),'sha256':sha(b)}for name,b in [('PACKAGE.py',controller),('PACKET.zip',archive),('MANIFEST.json',raw),('CLOSURE_MANIFEST.json',decoded),('EXTERNAL_REVIEW.json',extra[EXTERNAL['EXTERNAL_REVIEW.json'][1]]),('VERIFY_EXTERNAL.py',extra[EXTERNAL['VERIFY.py'][1]]),('README.md',readme)]})
    except BaseException as error:
        result.update(status='FAILED_PRESERVATION_NO_SOURCE_RETIREMENT',failure={'stage':stage,'type':type(error).__name__,'message':str(error)[:1024]},sourceRetired=False)
    finally:
        result['at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        rb=canonical(result);need(len(rb)<=REPORT_CAP,'Complete bounded terminal result')
        try:
            current=os.fstat(report);named=(O/'RESULT.json').lstat()
            need(stat.S_ISREG(current.st_mode)and current.st_nlink==1 and (current.st_dev,current.st_ino)==(named.st_dev,named.st_ino),'Reserved result identity')
            os.lseek(report,0,os.SEEK_SET);v=memoryview(rb)
            while v:
                n=os.write(report,v);need(n>0,'Complete terminal result');v=v[n:]
            os.ftruncate(report,len(rb));os.fsync(report)
            need(os.pread(report,len(rb)+1,0)==rb,'Full terminal readback')
            fsync_dir(O)
        finally:os.close(report)
        print(json.dumps({'result':result,'resultBytes':len(rb),'resultSHA256':sha(rb),'packetAllocatedBytes':guard()},separators=(',',':')),flush=True)
    need(result['status']=='FULL_PACKET_AND_SOURCE_VERIFIED','Packaging did not qualify; all partial evidence retained')
def sys_flags():
    import sys
    return sys.flags.isolated==1 and sys.dont_write_bytecode and os.geteuid()==1001 and os.getegid()==1001
if __name__=='__main__':main()
