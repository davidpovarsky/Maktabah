import os,pathlib,stat,json,hashlib,base64,gzip,io,datetime,shutil
R=pathlib.Path('/home/ubuntu/otzaria-wave3-native116-v3-focused-controls-20261128')
OUT=pathlib.Path('/home/ubuntu/otzaria-wave3-native116-focused-external-review-20261128')
CAP=4194304
def need(x,m):
 if not x:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(v):return(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode('ascii')
def identity(s):return{'device':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'nlink':s.st_nlink,'bytes':s.st_size,'mtimeNS':str(s.st_mtime_ns),'ctimeNS':str(s.st_ctime_ns)}
def read(p,limit=1048576):
 s=p.lstat();need(stat.S_ISREG(s.st_mode)and s.st_size<=limit,'Bounded file')
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  need(identity(os.fstat(fd))==identity(s),'Open identity')
  with os.fdopen(os.dup(fd),'rb')as f:b=f.read(limit+1)
  need(len(b)==s.st_size and identity(os.fstat(fd))==identity(s),'Stable complete read')
 finally:os.close(fd)
 need(identity(p.lstat())==identity(s),'Stable path')
 return b,s
body,selfstat=read(R/'CONTROLS_CLOSED.json',65536)
need(len(body)==58293 and sha(body)=='00a78c8d29416c20af3c4cd40661601b5fad3de78e6e12b3f137196377bce036','Exact completed closure')
value=json.loads(body);need(canon(value)==body,'Canonical full closure')
need(value['schema']=='otzaria.native116-focused-controls-closed/1'and value['status']=='EVIDENCE_FROZEN_NO_NATIVE_QUALIFICATION'and value['noFurtherScopeWrites'],'Exact closure boundary')
compressed=base64.b64decode(value['manifestGzipBase64'],validate=True)
need(len(compressed)==value['manifestGzipBytes']and sha(compressed)==value['manifestGzipSHA256'],'Complete compressed pin')
with gzip.GzipFile(fileobj=io.BytesIO(compressed),mode='rb')as z:
 raw=z.read(value['manifestBytes']+1);need(z.read(1)==b'','Manifest exact EOF')
need(len(raw)==381406==value['manifestBytes']and sha(raw)==value['manifestSHA256']=='4298d4775f55d8b61bf18967fe7c55072ae766527ae19f8448d7f36b5b1009a0','Complete decompressed manifest')
manifest=json.loads(raw);need(canon(manifest)==raw,'Canonical full metadata')
rows=manifest['entries'];need(len(rows)==945==value['entryCount'],'Exact closed entry count')
expected={r['path']:r for r in rows};need(len(expected)==945,'Unique closed paths')
actual={};pending=[(R,0)]
while pending:
 p,d=pending.pop();need(d<=5 and len(actual)<1200,'Original finite walk')
 s=p.lstat();rel=str(p.relative_to(R));actual[rel]=s
 if stat.S_ISDIR(s.st_mode):pending.extend((q,d+1)for q in p.iterdir())
need(set(actual)==set(expected),'Complete closed membership')
total=0;hashed=0;kinds={};selfrow=expected['CONTROLS_CLOSED.json']
for rel,row in expected.items():
 p=R/rel;s=actual[rel];total+=s.st_blocks*512
 need(s.st_uid==row['uid']and s.st_gid==row['gid'],'Original owner identities')
 if rel=='CONTROLS_CLOSED.json':
  before=row['identity'];now=identity(s)
  need(all(now[k]==before[k]for k in ['device','inode','mode','nlink']),'Same closure file')
  need(now=={"device":2049,"inode":632304,"mode":33152,"nlink":1,"bytes":58293,"mtimeNS":"1795838877715364339","ctimeNS":"1795838877715364339"} and s.st_blocks*512<=row['allocatedBytes'],'Exact final closure identity and declared shrink')
  need('sha256'not in row and value['closureSelfExcludedFromContentHash']and value['closureSelfIdentityIsBeforeFinalShrink'],'Explicit self-hash boundary')
 else:need(identity(s)==row['identity']and s.st_blocks*512==row['allocatedBytes'],'Complete stable member metadata: '+rel)
 kind='directory'if stat.S_ISDIR(s.st_mode)else'file'if stat.S_ISREG(s.st_mode)else'symlink'if stat.S_ISLNK(s.st_mode)else'other'
 need(kind==row['kind'],'Original member type');kinds[kind]=kinds.get(kind,0)+1
 if kind=='file'and rel!='CONTROLS_CLOSED.json':
  b,_=read(p);need(sha(b)==row['sha256'],'Full closed member hash: '+rel);hashed+=1
 if kind=='symlink':need(base64.b64encode(os.fsencode(os.readlink(p))).decode()==row['targetBase64'],'Exact closed symlink target')
need(total<=CAP and total==manifest['allocatedBytes']-(selfrow['allocatedBytes']-selfstat.st_blocks*512),'Complete final allocation accounting')
for rel,s in actual.items():
 now=(R/rel).lstat();need(identity(now)==identity(s)and now.st_uid==s.st_uid and now.st_gid==s.st_gid and now.st_blocks==s.st_blocks,'No member changed during external verification')
need(read(R/'CONTROLS_CLOSED.json',65536)[0]==body,'Closure unchanged after full validation')
need(not OUT.exists()and shutil.disk_usage('/').free>=1593835520+65536,'Exclusive bounded external receipt')
OUT.mkdir(mode=0o750);os.chown(OUT,1001,1001)
result={'schema':'otzaria.focused-controls-external-closure-review/1','status':'FULL_CLOSED_MANIFEST_AND_ALL_MEMBERS_VERIFIED','controlsRoot':str(R),'closureBytes':len(body),'closureSHA256':sha(body),'manifestBytes':len(raw),'manifestSHA256':sha(raw),'entryCount':len(rows),'kinds':kinds,'fileContentHashesVerified':hashed,'allOriginalMetadataExceptDeclaredSelfShrinkAndAtimeVerified':True,'completePathSetVerified':True,'finalAllocatedBytes':total,'fixedControlsReserveBytes':CAP,'actualNative116Enumeration':False,'qualificationBoundary':'Root external closure prerequisite only; no Native116 or product qualification','at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def write(name,b):
 fd=os.open(OUT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o640)
 try:
  v=memoryview(b)
  while v:
   n=os.write(fd,v);need(n>0,'Complete external receipt');v=v[n:]
  os.fsync(fd);os.fchown(fd,1001,1001)
 finally:os.close(fd)
 need(read(OUT/name)[0]==b,'External receipt readback')
rb=canon(result);source=pathlib.Path(__file__).read_bytes()
write('EXTERNAL_REVIEW.json',rb);write('VERIFY.py',source)
print(json.dumps({'result':result,'receiptBytes':len(rb),'receiptSHA256':sha(rb),'verifierBytes':len(source),'verifierSHA256':sha(source)}))
