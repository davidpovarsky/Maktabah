if not __debug__:
    raise RuntimeError('Optimized Python is forbidden before preservation')
import os,stat,pathlib,hashlib,json,base64,io,gzip,tarfile,time,datetime,traceback,sys,zlib
ROOT=pathlib.Path('/home/ubuntu/otzaria-wave3-new-source-packets-preservation-20261128')
CAP=8*1024*1024
FLOOR=1593835520
RESERVE=8*1024*1024
SLOT=32768
CONTROLLER='PRESERVE_NEW_SOURCE_PACKETS.py'
SOURCES=[
 {'name':'toc-query','root':'/home/ubuntu/otzaria-wave3-toc-query-new-source-20261128','files':81,'manifest':'MANIFEST.json','manifestSHA256':'7754f19877c9e8f683447b42cf63721d687d0beaff0f8c996b53abbf05aee0d6','extras':['MANIFEST.json','SOURCE_RAW.zip','HANDOFF.json'],'anchors':{'HANDOFF.json':'81249cbf866cdcdb2fb927b507cd63344e51b4f4f9ac6ddea41c20563eac6359','SOURCE_RAW.zip':'d631adb395471a67c42dfa37c5ebe2ef576ee8137c16862c6261a4384558a1a1'},'newControls':'37 authored; NOT_RUN'},
 {'name':'inspector-source-continuation','root':'/home/ubuntu/otzaria-wave3-actor-control-source-continuation-20261128','files':79,'manifest':'SOURCE_MANIFEST_REVIEW2.json','manifestSHA256':'6b49e624ee4c3f8546e2fcd3edb9989aa70ca4876b1f85155c806edc9ba14d4a','extras':['SOURCE_MANIFEST_REVIEW2.json','STAGING_RESULT_REVIEW2.json'],'anchors':{'STAGING_RESULT_REVIEW2.json':'614fca0802bdea82c80aadbc55bae4f87ad7cd48b5b3ce48f46b3ea5c5079e47'},'newControls':'52 preserved cases; NOT_RUN; missing candidate5 not recovered'},
 {'name':'bookinfo-source-continuation','root':'/home/ubuntu/otzaria-wave3-bookinfo-control-source-continuation-20261128','files':113,'manifest':'SOURCE_MANIFEST.json','manifestSHA256':'640f3bf897d2ce50729a383a2e514879d7efbab29ed56f7679d530299243c98d','extras':['SOURCE_MANIFEST.json','STAGING_RESULT.json'],'anchors':{'STAGING_RESULT.json':'a4268e484beccd862a582566abbbf9973e12308f19c593712daee367fc5703d8'},'newControls':'26+two negatives and23+two negatives prepared; NOT_RUN; original24 unavailable'}
]
START=time.monotonic()
DEADLINE=START+45
slot_identities={}
written=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(obj):return (json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
def pretty(obj):return (json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def snapshot_stat(s):
    result={k:getattr(s,k)for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_atime_ns','st_mtime_ns','st_ctime_ns','st_rdev','st_blocks','st_blksize']}
    result['st_birthtime_ns']=getattr(s,'st_birthtime_ns',None)
    return result
def clock_guard():
    if time.monotonic()>=DEADLINE:raise RuntimeError('bounded preservation deadline')
def allocation():
    root_stat=ROOT.lstat()
    if not stat.S_ISDIR(root_stat.st_mode):raise RuntimeError('owned scope root is no longer a directory')
    value=root_stat.st_blocks*512
    for p in ROOT.rglob('*'):
        s=p.lstat()
        if not(stat.S_ISREG(s.st_mode)or stat.S_ISDIR(s.st_mode)):raise RuntimeError('unknown owned output type')
        value+=s.st_blocks*512
    return value
def guard(addition=0):
    clock_guard()
    s=os.statvfs(ROOT);free=s.f_bavail*s.f_frsize;own=allocation()
    if free<FLOOR+RESERVE or own+addition>CAP:raise RuntimeError('preservation capacity refusal: '+str({'rootFree':free,'allocated':own,'addition':addition}))
    return {'rootFree':free,'allocatedBytes':own}
def noatime_flags(directory=False):
    flags=os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NOATIME
    return flags|(os.O_DIRECTORY if directory else os.O_NONBLOCK)
def metadata(fd):
    before=snapshot_stat(os.fstat(fd));attrs=[]
    names=os.listxattr(fd)
    if len(names)!=len(set(names)):raise RuntimeError('duplicate xattr names')
    for name in sorted(names,key=os.fsencode):
        clock_guard()
        value=os.getxattr(fd,name);raw_name=os.fsencode(name)
        attrs.append({'nameBase64':base64.b64encode(raw_name).decode(),'valueBase64':base64.b64encode(value).decode(),'bytes':len(value),'sha256':sha(value)})
    after=snapshot_stat(os.fstat(fd))
    if before!=after:raise RuntimeError('metadata changed while being captured')
    return {'stat':before,'xattrs':attrs}
def read_fd(fd,size):
    if size<0 or size>32*1024*1024:raise RuntimeError('closed source file size outside bound')
    parts=[];remaining=size
    while remaining:
        clock_guard();chunk=os.read(fd,min(1024*1024,remaining))
        if not chunk:raise RuntimeError('source ended before its captured size')
        parts.append(chunk);remaining-=len(chunk)
    if os.read(fd,1):raise RuntimeError('source grew past captured size')
    return b''.join(parts)
def output_read(name):
    path=ROOT/name
    fd=os.open(path,noatime_flags())
    try:
        s=os.fstat(fd)
        if not stat.S_ISREG(s.st_mode):raise RuntimeError('nonregular owned artifact')
        raw=read_fd(fd,s.st_size)
        if snapshot_stat(os.fstat(fd))!=snapshot_stat(s):raise RuntimeError('owned artifact changed during read')
        return raw
    finally:os.close(fd)
def write(name,raw):
    guard(((len(raw)+4095)//4096)*4096+4096)
    p=ROOT/name
    if p.parent!=ROOT:raise RuntimeError('unexpected output path')
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o640)
    try:
        view=memoryview(raw)
        while view:
            clock_guard();n=os.write(fd,view)
            if n<=0:raise RuntimeError('short output write')
            view=view[n:]
        os.fsync(fd)
    finally:os.close(fd)
    if output_read(name)!=raw:raise RuntimeError('written artifact readback differs')
    written.append(name)
    guard()
def fill_slot(name,obj):
    raw=pretty(obj)
    if len(raw)>SLOT:raise RuntimeError('complete terminal/manifest exceeds reserved slot')
    framed=raw+b' '*(SLOT-len(raw))
    p=ROOT/name
    fd=os.open(p,os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        s=os.fstat(fd)
        if (s.st_dev,s.st_ino,s.st_size)!=slot_identities[name]:raise RuntimeError('owned reserved slot identity changed')
        os.lseek(fd,0,os.SEEK_SET);view=memoryview(framed)
        while view:
            n=os.write(fd,view)
            if n<=0:raise RuntimeError('short reserved-slot write')
            view=view[n:]
        os.fsync(fd)
    finally:os.close(fd)
    if output_read(name)!=framed:raise RuntimeError('reserved receipt readback differs')
    return {'path':name,'bytes':len(framed),'jsonBytes':len(raw),'sha256':sha(framed)}
def capture():
    entries=[];payload={};scope_info=[]
    for source in SOURCES:
        guard()
        root=pathlib.Path(source['root'])
        if root.resolve(strict=True)!=root:raise RuntimeError('source scope contains a root symlink')
        initial=os.stat(root,follow_symlinks=False)
        if not stat.S_ISDIR(initial.st_mode):raise RuntimeError('source root is not an original directory')
        root_fd=os.open(root,noatime_flags(directory=True))
        root_alias=root.name
        before_count=len(entries)
        def visit(fd,relative,expected):
            clock_guard()
            if snapshot_stat(os.fstat(fd))!=snapshot_stat(expected):raise RuntimeError('source identity changed before opened read')
            before=metadata(fd);s=before['stat']
            archive_path=root_alias+(''if relative=='.'else'/'+relative)
            if stat.S_ISDIR(s['st_mode']):
                row={'scope':source['name'],'relative':relative,'archivePath':archive_path,'kind':'directory','metadata':before}
                entries.append(row)
                names=sorted(os.listdir(fd),key=os.fsencode)
                for name in names:
                    guard()
                    raw_name=os.fsencode(name)
                    if name in ('.','..')or'/'in name or'\x00'in name or len(raw_name)>255:raise RuntimeError('unsafe original source name')
                    raw_name.decode('utf-8','strict')
                    child=os.stat(name,dir_fd=fd,follow_symlinks=False)
                    if not(stat.S_ISREG(child.st_mode)or stat.S_ISDIR(child.st_mode)):raise RuntimeError('unknown original source type: '+archive_path+'/'+name)
                    child_fd=os.open(name,noatime_flags(directory=stat.S_ISDIR(child.st_mode)),dir_fd=fd)
                    try:visit(child_fd,name if relative=='.'else relative+'/'+name,child)
                    finally:os.close(child_fd)
                    if snapshot_stat(os.stat(name,dir_fd=fd,follow_symlinks=False))!=snapshot_stat(child):raise RuntimeError('source entry changed after read')
                if sorted(os.listdir(fd),key=os.fsencode)!=names:raise RuntimeError('directory membership changed during capture')
            elif stat.S_ISREG(s['st_mode']):
                raw=read_fd(fd,s['st_size'])
                if archive_path in payload:raise RuntimeError('duplicate archive path')
                payload[archive_path]=raw
                row={'scope':source['name'],'relative':relative,'archivePath':archive_path,'kind':'file','metadata':before,'bytes':len(raw),'sha256':sha(raw)}
                entries.append(row)
            else:raise RuntimeError('unknown source kind')
            if metadata(fd)!=before:raise RuntimeError('source metadata changed across content read')
        try:
            visit(root_fd,'.',initial)
            if snapshot_stat(os.stat(root,follow_symlinks=False))!=snapshot_stat(initial):raise RuntimeError('source root identity changed')
        finally:os.close(root_fd)
        own_rows=entries[before_count:]
        file_rows={x['relative']:x for x in own_rows if x['kind']=='file'}
        if len(file_rows)!=source['files']:raise RuntimeError('closed source file count changed: '+source['name'])
        def raw_at(relative):return payload[root_alias+'/'+relative]
        manifest_raw=raw_at(source['manifest'])
        if sha(manifest_raw)!=source['manifestSHA256']:raise RuntimeError('source manifest anchor differs')
        original_manifest=json.loads(manifest_raw)
        sealed_rows=original_manifest['files']
        expected_members={x['path']for x in sealed_rows}|set(source['extras'])
        if expected_members!=set(file_rows)or len(sealed_rows)!=len({x['path']for x in sealed_rows}):raise RuntimeError('sealed source membership differs')
        for item in sealed_rows:
            actual=file_rows[item['path']]
            if actual['bytes']!=item['bytes']or actual['sha256']!=item['sha256']:raise RuntimeError('sealed source bytes changed: '+source['name']+'/'+item['path'])
            if 'mode'in item:
                sealed_mode=item['mode']
                if type(sealed_mode)is str:sealed_mode=int(sealed_mode,8)
                elif type(sealed_mode)is not int:raise RuntimeError('unsupported sealed source mode type')
                if stat.S_IMODE(actual['metadata']['stat']['st_mode'])!=sealed_mode:raise RuntimeError('sealed source mode changed')
        for name,digest in source['anchors'].items():
            if sha(raw_at(name))!=digest:raise RuntimeError('source terminal/archive anchor differs')
        scope_info.append({'name':source['name'],'root':source['root'],'archiveRoot':root_alias,'files':len(file_rows),'directories':sum(x['kind']=='directory'for x in own_rows),'logicalBytes':sum(x['bytes']for x in own_rows if x['kind']=='file'),'manifestSHA256':source['manifestSHA256'],'newControlExecution':source['newControls']})
    entries.sort(key=lambda x:x['archivePath'].encode())
    if len(payload)!=273:raise RuntimeError('exact273 source files required')
    links={}
    for row in entries:
        if row['kind']=='file':
            s=row['metadata']['stat'];links.setdefault(str(s['st_dev'])+':'+str(s['st_ino']),[]).append(row['archivePath'])
    hardlinks={k:v for k,v in links.items()if len(v)>1}
    snapshot={'schema':'otzaria.closed-new-source.snapshot.v1','scopes':scope_info,'entries':entries,'files':273,'directories':sum(x['kind']=='directory'for x in entries),'hardlinkIdentityGroups':hardlinks,'metadataPolicy':{'fields':['full st_mode','uid','gid','size','dev','inode','nlink','atime_ns','mtime_ns','ctime_ns','rdev','blocks','blksize','birthtime_ns if exposed','all readable FD xattr names/values'],'nanoseconds':'exact integers','readPolicy':'O_NOFOLLOW + O_NOATIME on pinned descriptors; unknown types or unreadable metadata refuse','physicalExtentOrInodeRecreationClaim':False}}
    return snapshot,payload
def ns_string(value):
    seconds,ns=divmod(abs(value),1000000000)
    return ('-'if value<0 else'')+str(seconds)+'.'+str(ns).zfill(9)
def expected_pax(row,snapshot_sha):
    s=row['metadata']['stat']
    return {'path':row['archivePath'],'atime':ns_string(s['st_atime_ns']),'mtime':ns_string(s['st_mtime_ns']),'ctime':ns_string(s['st_ctime_ns']),'Otzaria.snapshot.sha256':snapshot_sha,'Otzaria.metadata.sha256':sha(canonical(row['metadata']))}
def encode_archive(snapshot,payload,snapshot_sha):
    out=io.BytesIO()
    with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0,compresslevel=9)as compressed:
        with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT,encoding='utf-8',errors='strict')as archive:
            for row in snapshot['entries']:
                clock_guard()
                s=row['metadata']['stat'];item=tarfile.TarInfo(row['archivePath'])
                item.type=tarfile.DIRTYPE if row['kind']=='directory'else tarfile.REGTYPE
                item.mode=stat.S_IMODE(s['st_mode']);item.uid=s['st_uid'];item.gid=s['st_gid']
                item.uname='';item.gname='';item.mtime=s['st_mtime_ns']//1000000000
                item.pax_headers=expected_pax(row,snapshot_sha)
                item.size=0 if row['kind']=='directory'else row['bytes']
                archive.addfile(item,None if row['kind']=='directory'else io.BytesIO(payload[row['archivePath']]))
    return out.getvalue()
def verify_archive(raw,snapshot,payload,snapshot_sha):
    rows=[]
    with gzip.GzipFile(fileobj=io.BytesIO(raw),mode='rb')as compressed:
        with tarfile.open(fileobj=compressed,mode='r:',encoding='utf-8',errors='strict')as archive:
            members=archive.getmembers()
            if len(members)!=len(snapshot['entries']):raise RuntimeError('archive member count differs')
            for member,row in zip(members,snapshot['entries']):
                clock_guard();s=row['metadata']['stat']
                if member.name!=row['archivePath']or member.uid!=s['st_uid']or member.gid!=s['st_gid']or member.mode!=stat.S_IMODE(s['st_mode']):raise RuntimeError('archive identity/path/owner/mode differs')
                if member.uname!=''or member.gname!=''or member.linkname!='':raise RuntimeError('unexpected archive identity alias')
                if member.pax_headers!=expected_pax(row,snapshot_sha):raise RuntimeError('exact PAX nanoseconds/metadata binding differs')
                if row['kind']=='directory':
                    if not member.isdir()or member.size!=0:raise RuntimeError('directory archive kind differs')
                    rows.append({'path':member.name,'kind':'directory','metadataSHA256':sha(canonical(row['metadata']))})
                else:
                    if not member.isfile()or member.size!=row['bytes']:raise RuntimeError('file archive kind/length differs')
                    decoded=archive.extractfile(member).read()
                    if decoded!=payload[member.name]or sha(decoded)!=row['sha256']:raise RuntimeError('full decoded source bytes differ')
                    rows.append({'path':member.name,'kind':'file','bytes':len(decoded),'sha256':sha(decoded),'metadataSHA256':sha(canonical(row['metadata']))})
    return {'schema':'otzaria.source-archive.full-readback.v1','sourceFiles':273,'archiveMembers':len(rows),'archiveSHA256':sha(raw),'sourceSnapshotSHA256':snapshot_sha,'decodedBytesEqual':True,'exactMetadataBinding':True,'rows':rows}
def own_file_record(name):
    fd=os.open(ROOT/name,noatime_flags())
    try:
        md=metadata(fd);raw=read_fd(fd,md['stat']['st_size'])
        if metadata(fd)!=md:raise RuntimeError('output metadata changed during final sealing')
        return {'path':name,'bytes':len(raw),'sha256':sha(raw),'metadata':md}
    finally:os.close(fd)
def main():
    if os.geteuid()!=1001 or not hasattr(os,'O_NOATIME'):raise RuntimeError('ubuntu owner and no-atime capability required')
    if ROOT.resolve(strict=True)!=ROOT or os.stat(ROOT).st_dev!=os.stat('/').st_dev:raise RuntimeError('rootfs output scope differs')
    if sorted(p.name for p in ROOT.iterdir())!=sorted([CONTROLLER,'MANIFEST.json','RESULT.json']):raise RuntimeError('new output scope already used')
    for name,status in [('RESULT.json','PREALLOCATED_NOT_RUN'),('MANIFEST.json','UNSEALED')]:
        raw=output_read(name)
        if len(raw)!=SLOT or json.loads(raw)!= {'status':status}:raise RuntimeError('reserved slot is not fresh')
        s=(ROOT/name).lstat();slot_identities[name]=(s.st_dev,s.st_ino,s.st_size)
    initial=guard()
    before,payload=capture()
    snapshot_bytes=canonical(before);snapshot_sha=sha(snapshot_bytes)
    archive_bytes=encode_archive(before,payload,snapshot_sha)
    if encode_archive(before,payload,snapshot_sha)!=archive_bytes:raise RuntimeError('deterministic repeated encoding differs')
    guard(((len(archive_bytes)+4095)//4096)*4096+2*((len(snapshot_bytes)+4095)//4096)*4096+512*1024)
    write('SOURCE_SNAPSHOT_BEFORE.json',snapshot_bytes)
    write('SOURCE_ARCHIVE.tar.gz',archive_bytes)
    written_archive=output_read('SOURCE_ARCHIVE.tar.gz')
    if written_archive!=archive_bytes:raise RuntimeError('on-disk archive differs')
    readback=verify_archive(written_archive,before,payload,snapshot_sha)
    write('ARCHIVE_READBACK.json',canonical(readback))
    after,after_payload=capture()
    after_bytes=canonical(after)
    if after_bytes!=snapshot_bytes or set(after_payload)!=set(payload)or any(after_payload[k]!=payload[k]for k in payload):raise RuntimeError('source pre/post membership/metadata/content changed')
    write('SOURCE_SNAPSHOT_AFTER.json',after_bytes)
    provenance={'schema':'otzaria.closed-new-source.provenance.v1','sourceScopes':SOURCES,'newCompilerOrTests':'NOT_RUN','native':'NOT_RUN','historicalReceipts':'Original historical receipts retain their original scope and are not retagged as newly run.','newCodeLineage':'Fresh TOC and source continuations; no equivalence to missing59f2/cf5/candidate5 and no BookInfo24 recovery.','archivePolicy':{'format':'PAX tar in deterministic gzip','gzipMtime':0,'gzipFilename':'','compressionLevel':9,'entryOrder':'UTF-8 archive path order','Python':sys.version,'zlibVersion':zlib.ZLIB_VERSION,'fullModeUidGidNsAndIdentity':'All are preserved in snapshot records; TAR stores original permissions/uid/gid and exact PAX timestamp strings. Every TAR entry binds its complete metadata hash.','xattrs':'Complete FD-captured base64 names/values in snapshots, bound per TAR member.','originalInodeAndPhysicalExtentRecreation':False},'sourceMutations':0,'sourceCleanup':False,'GitWrites':0,'DataWrites':0,'compilerInvocations':0,'testExecutions':0}
    write('PROVENANCE.json',pretty(provenance))
    before_result=guard()
    result={'schema':'otzaria.new-source-preservation.result.v1','status':'PRESERVED_FULL_READBACK_SOURCE_UNCHANGED','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(ROOT),'sourceFiles':273,'sourceDirectories':before['directories'],'scopes':before['scopes'],'archive':{'path':'SOURCE_ARCHIVE.tar.gz','bytes':len(archive_bytes),'sha256':sha(archive_bytes)},'beforeSnapshotSHA256':snapshot_sha,'afterSnapshotSHA256':sha(after_bytes),'allSourceBytesAndMetadataUnchanged':True,'deterministicEncodingRepeatedExact':True,'decodedReadbackAll273':True,'sourceRootsRemainUntouched':True,'controller':own_file_record(CONTROLLER),'initial':initial,'beforeTerminalReceipt':before_result,'resourcePolicy':{'rootFloor':FLOOR,'unconditionalReserve':RESERVE,'cap':CAP,'overallSeconds':45,'terminalSlotsPreallocatedEach':SLOT},'outputs':[CONTROLLER,'SOURCE_SNAPSHOT_BEFORE.json','SOURCE_ARCHIVE.tar.gz','ARCHIVE_READBACK.json','SOURCE_SNAPSHOT_AFTER.json','PROVENANCE.json','RESULT.json','MANIFEST.json'],'newCompilerOrTestExecutions':0,'GitOrDataWrites':0,'sourceCleanup':False}
    result_pin=fill_slot('RESULT.json',result)
    guard()
    names=sorted(p.name for p in ROOT.iterdir())
    if set(names)!=set(result['outputs']):raise RuntimeError('unexpected final output membership')
    manifest={'schema':'otzaria.new-source-preservation.final-manifest.v1','status':'IMMUTABLE_CLOSED_PACKET','files':[own_file_record(n)for n in names if n!='MANIFEST.json'],'excludeOnly':['MANIFEST.json'],'sourceFiles':273,'allSourceScopeFilesUnchanged':True,'terminalResultSHA256':result_pin['sha256'],'archiveSHA256':sha(archive_bytes),'sourceSnapshotSHA256':snapshot_sha,'newControlsExecution':'NOT_RUN','sourceCleanup':False}
    manifest_pin=fill_slot('MANIFEST.json',manifest)
    final=guard()
    print(json.dumps({'status':result['status'],'root':str(ROOT),'files':len(names),'sourceFiles':273,'sourceDirectories':before['directories'],'archive':result['archive'],'manifest':manifest_pin,'result':result_pin,'snapshotSHA256':snapshot_sha,'final':final,'compilerOrTestExecutions':0,'sourceWrites':0}))
try:main()
except BaseException as error:
    failure={'schema':'otzaria.new-source-preservation.failure.v1','status':'FAILED_PRESERVATION_NOT_ACCEPTED','error':repr(error),'traceback':traceback.format_exc(),'writtenArtifacts':written,'sourceWrites':0,'sourceCleanup':False,'compilerOrTestExecutions':0}
    if 'RESULT.json'in slot_identities:
        try:failure['preservedFailureSlot']=fill_slot('RESULT.json',failure)
        except BaseException as report_error:failure['failureSlotError']=repr(report_error)
    print(json.dumps(failure),file=sys.stderr)
    raise
