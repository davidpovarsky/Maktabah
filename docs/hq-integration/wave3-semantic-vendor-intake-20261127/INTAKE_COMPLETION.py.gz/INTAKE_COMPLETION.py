import pathlib
PREVIOUS=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-semantic-vendor-intake-20261127')
original=(PREVIOUS/'RUN.py').read_text()
assert __import__('hashlib').sha256(original.encode()).hexdigest()=='aabc7b431fa0488bf994350c70324e41933f9529d801aa1d86eaca0fd4a182df'
helpers,separator,_=original.partition("try:\n assert rev('HEAD')")
assert separator
exec(compile(helpers,str(PREVIOUS/'RUN.py'),'exec'),globals())
PICKED='4a02ca900c2ae989681cb89c6068fa06c9fc43c3'
try:
 assert rev('HEAD')==PICKED and rev(PICKED+'^')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 failure=(PREVIOUS/'FAILURE.json').read_bytes();assert sha(failure)=='ccefe47bf9f566ce2c5d5a49b48163106d3715a4db78391e30ae64877f8acf93'
 stderr=(PREVIOUS/'actual-integrated-vendor-source-check.stderr').read_bytes();assert sha(stderr)=='1c461bedb5f45ffe93b85a8d1e147cf376e278c2a530eb085c6dec836bfe1b82'
 assert b'Missing or aliased source admission file: Vendor/SefariaMobile/Integration/JS/ChavrusaRoot.js'in stderr
 contract=json.loads(show(PICKED,'Scripts/CI/reviewed-vendor-semantics.inputs.json'))
 assert sha(show(PICKED,'Scripts/CI/reviewed-vendor-semantics.inputs.json'))=='8423dae0002cce697d48a1a11d43fdae0a2a06f5c143420a56247fae8ed4e208'
 paths=[];materialized=[]
 for row in contract['entries']:
  if row['accepted']['kind']=='commit':continue
  p=ROOT/row['path'];assert row['accepted']['mode']=='100644'and row['accepted']['kind']=='blob'
  assert not p.exists()and not p.is_symlink()and git('ls-files','-t','--',row['path']).decode().startswith('S ')
  pin(show(PICKED,row['path']),row['accepted']);paths.append(row['path'])
 assert len(paths)==8
 sparse=pathlib.Path(git('rev-parse','--git-path','info/sparse-checkout').decode().strip())
 if not sparse.is_absolute():sparse=ROOT/sparse
 sparseBefore=sparse.read_bytes()
 # Materialize exact existing tracked blobs in this owned worktree. This does
 # not change the sparse policy, committed tree, source bytes or validator.
 git('restore','--source=HEAD','--worktree','--ignore-skip-worktree-bits','--',*paths)
 assert sparse.read_bytes()==sparseBefore and not git('status','--porcelain')
 for row in contract['entries']:
  if row['path']not in paths:continue
  p=ROOT/row['path'];assert p.is_file()and not p.is_symlink();b=p.read_bytes();pin(b,row['accepted'])
  materialized.append({'path':row['path'],'bytes':len(b),'sha256':sha(b),'committedObject':row['accepted']['object'],'previouslySparseAbsent':True})
 dump(RUN/'MATERIALIZATION.json',{'source':PICKED,'paths':materialized,'sparsePolicyUnchangedSHA256':sha(sparseBefore),'gitClean':True})
 code="import json,pathlib,runpy,sys; r=pathlib.Path(sys.argv[1]); m=runpy.run_path(str(r/'Scripts/CI/final_integration_source.py')); v=m['verify_reviewed_vendor'](r,sys.argv[2],{'manifest':m['SEMANTIC_REVIEW_PATH'],'sha256':m['SEMANTIC_REVIEW_SHA256']}); print(json.dumps(v,sort_keys=True))"
 run('actual-integrated-vendor-source-check',['/usr/bin/python3','-c',code,str(ROOT),BASE],180)
 actual=json.loads((RUN/'actual-integrated-vendor-source-check.stdout').read_text())
 assert actual['vendor_tree']=='2fb868bdbe5d2d52735e857a24933918ff658cef'and actual['native_qualified']is False
 assert actual['new_app_build_required']is True and actual['new_metro_bundle_required']is True
 preserve=json.loads(show(SOURCE,D+'/SOURCE_PRESERVATION.json'));sourceResult=json.loads(show(SOURCE,D+'/RESULT.json'))
 protected=['Source','Vendor','Maktabah.xcodeproj','Maktabah-iOSUITests','.github','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected}
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 assert rev('HEAD')==PICKED and not git('status','--porcelain');capacity()
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE_COMPLETION.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 (proof/'preserved-first-attempt').mkdir()
 for name in ['RUN.py','EVENTS.json','FAILURE.json','STEPS.json','actual-integrated-vendor-source-check.stdout','actual-integrated-vendor-source-check.stderr']:
  (proof/'preserved-first-attempt'/(name+'.gz')).write_bytes(gzip.compress((PREVIOUS/name).read_bytes(),mtime=0))
 for name in ['STEPS.json','MATERIALIZATION.json','actual-integrated-vendor-source-check.stdout','actual-integrated-vendor-source-check.stderr']:(proof/name).write_bytes((RUN/name).read_bytes())
 dump(proof/'SOURCE_FUNCTION_PRESERVATION.json',{'originalCount':24,'unchanged':preserve['unchanged_original_functions'],'changed':preserve['changed_original_functions'],'new':preserve['new_functions'],'BINDING_FIELDS':'byte-identical; verified before the preserved first actual-checkout attempt'})
 report={'schema':'otzaria.wave3.semantic-vendor-intake.v1','base':BASE,'donor':SOURCE,'picked':PICKED,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'productPaths':3,'docsPaths':22,'artifactRowsVerifiedBeforeFirstAttempt':21,'rawArchiveMembersVerifiedBeforeFirstAttempt':110,'sourcePreservation':preserve,'observedSourceTests':sourceResult,'actualCurrentCheckoutSourceVerification':actual,'steps':steps,'sparseMaterialization':materialized,'preservedFirstFailureSHA256':sha(failure),'firstFailureReason':'Actual source verifier correctly rejected absent sparse physical source; exact eight already committed blobs materialized before the same verifier rerun. No gate or source change.','newTestExecutions':0,'protectedTrees':trees,'nativeRuns':0,'AppleSDK':'NOT_RUN','Metro':'NOT_RUN','finalManifest':'NOT_GENERATED','open':['Fresh original Metro and native bridge build','Final app source/build/test manifest and all original production entry points','Actual app/production/native/owner/target merge/TestFlight']}
 dump(proof/'RESULT.json',report)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Verify semantic Vendor transition on exact materialized integrated source')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':PICKED,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free};dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc(),'steps':steps});raise
