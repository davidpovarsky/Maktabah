import ast,gzip,hashlib,io,json,os,pathlib,shutil,signal,subprocess,tarfile,time,traceback
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='b463ffd03a76026cea06c79c608df97d00094152'
SOURCE='6eb250e863877fb9ae49c52cf860a50c6ffbb360'
PARENT='947f6f531b5a927919d60e365f806286ce564ca4'
DONOR='/mnt/development/projects/worktrees/Maktabah-wave3-vendor-admission-private-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127'
D='docs/hq-integration/wave3-rn-semantic-vendor-admission-20261127'
PROOF='docs/hq-integration/wave3-semantic-vendor-intake-20261127'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[];steps=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def capacity():assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
def run(name,args,timeout):
 capacity();step={'name':name,'argv':args,'started':time.time()};steps.append(step)
 with (RUN/(name+'.stdout')).open('wb')as out,(RUN/(name+'.stderr')).open('wb')as err:
  p=subprocess.Popen(args,stdout=out,stderr=err,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});step['pid']=p.pid
  step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21];deadline=time.time()+timeout
  while p.poll()is None:
   try:capacity();assert time.time()<deadline
   except BaseException:
    step['stopped']='owned capacity/deadline';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
  step['exit']=p.returncode
 step['finished']=time.time();step['logs']={s:{'bytes':(RUN/(name+s)).stat().st_size,'sha256':sha((RUN/(name+s)).read_bytes())}for s in ['.stdout','.stderr']};dump(RUN/'STEPS.json',steps);assert step['exit']==0,name
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,SOURCE);assert rev(SOURCE+'^')==PARENT
 artifactRaw=show(SOURCE,D+'/ARTIFACTS.json');assert sha(artifactRaw)=='b402d318498bb3266a6c5a61d2e862b8aac80527f2bbf8a291ba9e51842168c3'
 rows=json.loads(artifactRaw)['files'];assert len(rows)==21
 for row in rows:pin(show(SOURCE,D+'/'+row['path']),row)
 preserve=json.loads(show(SOURCE,D+'/SOURCE_PRESERVATION.json'));assert len(preserve['files'])==3
 paths=git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines()
 assert len(paths)==25 and set(paths)=={r['path']for r in preserve['files']}|{D+'/'+r['path']for r in rows}|{D+'/ARTIFACTS.json'}
 for row in preserve['files']:
  p=row['path'];pin(show(SOURCE,p),row['after'])
  if row['before']is None:assert not git('ls-tree',BASE,'--',p)
  else:pin(show(BASE,p),row['before']);assert show(BASE,p)==show(PARENT,p)
 for p,row in preserve['unchanged_files'].items():pin(show(BASE,p),row);assert show(BASE,p)==show(SOURCE,p)
 validator='Scripts/CI/final_integration_source.py';before=show(BASE,validator).decode();after=show(SOURCE,validator).decode()
 oldTree=ast.parse(before);newTree=ast.parse(after)
 def functions(tree,text):return {n.name:ast.get_source_segment(text,n)for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 old=functions(oldTree,before);new=functions(newTree,after);assert len(old)==24
 assert {name for name in old if old[name]!=new[name]}==set(preserve['changed_original_functions'])
 assert set(new)-set(old)==set(preserve['new_functions'])
 assert [name for name in old if old[name]==new[name]]==preserve['unchanged_original_functions']
 def assignment(tree,text,name):
  return [ast.get_source_segment(text,n)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets)]
 assert assignment(oldTree,before,'BINDING_FIELDS')==assignment(newTree,after,'BINDING_FIELDS')
 archive=show(SOURCE,D+'/validation/source-controls.tar.gz');index=json.loads(show(SOURCE,D+'/validation/ARCHIVE_MEMBERS.json'))
 assert len(archive)==483328==index['bytes']and sha(archive)==index['sha256']and index['member_count']==110
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tar:
  members=index['members'];assert len(members)==110 and {m.name for m in tar.getmembers()if m.isfile()}=={r['path']for r in members}
  for row in members:pin(tar.extractfile(row['path']).read(),row)
 result=json.loads(show(SOURCE,D+'/RESULT.json'))
 assert result['original39']=={'tests':39,'failures':0,'errors':0}and result['actual_root50_preserved']=={'tests':50,'failures':2,'errors':0,'failing_method_count':1}
 assert result['focused_original3']=={'methods':1,'routes':3,'failures':0,'errors':0,'controller_exit':0}and not result['full_final50_rerun']
 rawResults=[]
 for p,digest,tests,failures in [('validation/ORIGINAL39_RESULT.json','322533601b8470c3b453b97dd7ab9fe3c6bc39b31f04129a962511193a34cdf2',39,0),('validation/ROOT50_FAILED_RESULT.json','d16bbe90730068c5595456fb19ccd85202b9d2c44f7d5e71e590d85b473fd422',50,2),('validation/ORIGINAL3_RESULT.json','d9a4645c2c44d18861ff1986de79b7846537f50c886d32c770448f6cbbce4363',None,0)]:
  b=show(SOURCE,D+'/'+p);assert sha(b)==digest;r=json.loads(b);assert r['failures']==failures and r['errors']==0
  if tests is not None:assert r['tests']==tests
  else:
   loads=r['three_actual_original_validator_loads'];assert r['methods']==1 and len(loads)==3
   assert all(row['bytes']==27814 and row['sha256']=='35e15ef68d8498e907aab1c3e5cde9ed52c54530f9d6c8ebf9351ba5896d4f72'for row in loads)
  rawResults.append({'path':p,'sha256':digest,'tests':tests,'failures':failures})
 patch=gzip.decompress(show(SOURCE,D+'/validation/FIXTURE_ONLY.patch.gz'));identity=json.loads(show(SOURCE,D+'/validation/FIXTURE_ONLY_IDENTITY.json'))
 assert len(patch)==identity['raw_bytes']and sha(patch)==identity['raw_sha256']
 git('diff','--check',PARENT,SOURCE)
 protected=['Source','Vendor','Maktabah.xcodeproj','Maktabah-iOSUITests','.github','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',SOURCE)
 picked=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 # This is the real source-identity entry point against the actual integrated
 # checkout. It does not execute tests, Metro, SDK/app builds or final admission.
 code="import json,pathlib,runpy,sys; r=pathlib.Path(sys.argv[1]); m=runpy.run_path(str(r/'Scripts/CI/final_integration_source.py')); v=m['verify_reviewed_vendor'](r,sys.argv[2],{'manifest':m['SEMANTIC_REVIEW_PATH'],'sha256':m['SEMANTIC_REVIEW_SHA256']}); print(json.dumps(v,sort_keys=True))"
 run('actual-integrated-vendor-source-check',['/usr/bin/python3','-c',code,str(ROOT),BASE],180)
 actual=json.loads((RUN/'actual-integrated-vendor-source-check.stdout').read_text())
 assert actual['vendor_tree']=='2fb868bdbe5d2d52735e857a24933918ff658cef'and actual['native_qualified']is False
 assert actual['new_app_build_required']is True and actual['new_metro_bundle_required']is True
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 dump(proof/'SOURCE_FUNCTION_PRESERVATION.json',{'originalCount':24,'unchanged':preserve['unchanged_original_functions'],'changed':preserve['changed_original_functions'],'new':preserve['new_functions'],'BINDING_FIELDS':'byte-identical'})
 for name in ['STEPS.json','actual-integrated-vendor-source-check.stdout','actual-integrated-vendor-source-check.stderr']:(proof/name).write_bytes((RUN/name).read_bytes())
 report={'schema':'otzaria.wave3.semantic-vendor-intake.v1','base':BASE,'donor':SOURCE,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'productPaths':3,'docsPaths':22,'artifactRows':21,'rawArchiveMembers':110,'sourcePreservation':preserve,'observedSourceTests':result,'rawResults':rawResults,'actualCurrentCheckoutSourceVerification':actual,'steps':steps,'newTestExecutions':0,'protectedTrees':trees,'nativeRuns':0,'AppleSDK':'NOT_RUN','Metro':'NOT_RUN','finalManifest':'NOT_GENERATED','open':['Fresh original Metro and native bridge build','Final app source/build/test manifest and all original production entry points','Actual app/production/native/owner/target merge/TestFlight']}
 dump(proof/'RESULT.json',report)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Verify semantic Vendor transition on the actual integrated source')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free};dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc(),'steps':steps});raise
