import Foundation

// Explicit UIKit/SwiftUI, navigation-manager and Action/UI DTO boundaries.
// The real Library models, render model, content coordinator, destination resolver,
// entire surface() method, and current-work source method are compiled unchanged.
struct UIStableID: RawRepresentable, Hashable {
    let rawValue: String
    init?(rawValue: String) { guard !rawValue.isEmpty else { return nil }; self.rawValue = rawValue }
}
typealias UIDestinationID = UIStableID
typealias ActionTextRef = TextLocator
struct UIStateSpec: Equatable {
    var workspaceID: UIStableID? = nil
    var profileID: UIStableID? = nil
    var selectedItemID: UIStableID? = nil
    var inspectorVisible: Bool? = nil
}
enum PresentationMode { case sameTab, newTab }
struct ActionReaderDestination: Equatable {
    let sectionLocator: TextLocator
    let focusLocator: TextLocator?
    let presentationMode: PresentationMode
}
struct NativeSurfaceState {
    struct Presentation {
        enum Kind { case currentTab, newTab, sheet, inspector }
        var kind: Kind = .currentTab
        var tabID: UIStableID? = nil
    }
    let destination: UIDestinationID
    let presentation: Presentation
    let content: ActionReaderDestination?
    let state: UIStateSpec
    let focus: String?
}
enum ActionAppIdentityBridge {
    static func actionRef(_ value: TextLocator) throws -> TextLocator { value }
}
enum ReaderScrollTarget: Equatable, Sendable { case top, bottom }
enum SefariaRef {
    static func canonicalInput(_ value: String) -> String { preconditionFailure("Unexecuted Sefaria boundary") }
    static func sectionAncestors(of value: String) -> [String] { preconditionFailure("Unexecuted Sefaria boundary") }
}
enum iOSTab { case viewer, history, search, annotations
    var canonical: Self { self }
    var appMode: Self { self }
}
enum NavigationSplitViewVisibility { case all, doubleColumn, detailOnly }
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    var activeBackendID: BackendID = .otzaria
}
@MainActor final class BooksData {
    let id: Int
    var backendLocator: TextLocator?
    init(id: Int, backendLocator: TextLocator?) { self.id = id; self.backendLocator = backendLocator }
}
@MainActor final class ReaderViewModel {
    enum State { case loaded, loading, error }
    var state: State = .loaded
    var currentBook: BooksData?
    var currentDestination: LibraryReaderDestination?
    var backendSection: LibraryTextSection?
    var backendRenderModel: LibraryReaderRenderModel?
    var contentText = ""
    var readerInspectorVisible = false
    let contentLoadCoordinator = ReaderContentLoadCoordinator()
}
@MainActor final class iOSNavigationManager {
    struct ReaderTab {
        let id: UUID
        let book: BooksData
        let viewModel: ReaderViewModel
    }
    final class Search {
        var hasSubmitted = false, isSearching = false, resultsAreDirty = false
        var errorMessage: String?
    }
    var activeTabId: UUID?
    var openTabs: [ReaderTab] = []
    var currentMode: iOSTab = .viewer
    var selectedBook: BooksData?
    let unifiedSearchSession = Search()
}
@MainActor final class HistoryViewModel {
    static let shared = HistoryViewModel()
    var searchText = ""
}
@MainActor enum MaktabahApp { static var isIpad = true }
@MainActor final class ReaderSidebarPageCoordinator {
    enum Page { case library, contents }
    var page: Page = .library
}
@MainActor final class StudyWorkspaceNavigationAdapter {
    struct Selection { let groupID: UUID; let profileID: UUID }
    var selection: Selection?
    func hasCommittedNativeReader(tabID: UUID) -> Bool { false }
}
@MainActor enum MaktabahNativeRootDestination: String {
    case search = "native.search", annotations = "native.annotations"
    var isAvailable: Bool { true }
    var tab: iOSTab { self == .search ? .search : .annotations }
}
@MainActor enum MaktabahNativeSceneBindings {
    static func hasOriginalTableOfContents(_ manager: iOSNavigationManager) -> Bool {
        preconditionFailure("Unexecuted TOC boundary")
    }
}
@MainActor enum MaktabahNativeInspectorBinding {
    static func currentReader(in manager: iOSNavigationManager) -> ReaderViewModel? {
        preconditionFailure("Unexecuted Inspector boundary")
    }
}
@MainActor struct MaktabahNativeSceneProjection {
    enum Surface { case library, tableOfContents, reader, history, search, searchResults, annotations, settings, inspector, noteDraft }
    let manager: iOSNavigationManager
    var selectedTab: iOSTab = .viewer
    var columnVisibility: NavigationSplitViewVisibility = .all
    var settingsPresented = false
    var sidebar: ReaderSidebarPageCoordinator? = nil
    var workspace: StudyWorkspaceNavigationAdapter? = nil
    private var activeTab: iOSNavigationManager.ReaderTab? {
        guard let id = manager.activeTabId else { return nil }
        return manager.openTabs.first { $0.id == id }
    }
    private func stable(_ id: UUID?) -> UIStableID? { id.flatMap { UIStableID(rawValue: $0.uuidString) } }
    private func id(_ value: String) -> UIDestinationID { UIDestinationID(rawValue: value)! }
    func surface(_ surface: Surface) throws -> NativeSurfaceState? {
        let state = UIStateSpec(workspaceID: stable(workspace?.selection?.groupID),
            profileID: stable(workspace?.selection?.profileID), selectedItemID: nil)
        switch surface {
        case .settings:
            guard settingsPresented else { return nil }
            return .init(destination: id("native.settings"), presentation: .init(kind: .sheet), content: nil, state: state, focus: nil)
        case .history:
            guard !settingsPresented, selectedTab.canonical == .history, manager.currentMode == .history,
                  HistoryViewModel.shared.searchText.isEmpty else { return nil }
            return .init(destination: id("native.history"), presentation: .init(), content: nil, state: state, focus: nil)
        case .searchResults:
            let search = manager.unifiedSearchSession
            guard !settingsPresented, MaktabahNativeRootDestination.search.isAvailable,
                  selectedTab.canonical == .search, manager.currentMode == .search,
                  search.hasSubmitted, !search.isSearching, !search.resultsAreDirty,
                  search.errorMessage == nil else { return nil }
            return .init(destination: id("native.search.results"), presentation: .init(),
                         content: nil, state: state, focus: nil)
        case .search, .annotations:
            let root: MaktabahNativeRootDestination = surface == .search ? .search : .annotations
            guard !settingsPresented, root.isAvailable,
                  selectedTab.canonical == root.tab, manager.currentMode == root.tab.appMode else { return nil }
            // Existing private query/note state remains in its original owner.
            // Opening a root never submits a query, creates a draft or writes data.
            return .init(destination: id(root.rawValue), presentation: .init(), content: nil, state: state, focus: nil)
        case .library, .tableOfContents:
            guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer else { return nil }
            if let sidebar {
                let page: ReaderSidebarPageCoordinator.Page = surface == .library ? .library : .contents
                guard sidebar.page == page,
                      columnVisibility == .all || columnVisibility == .doubleColumn else { return nil }
                if surface == .tableOfContents {
                    guard MaktabahNativeSceneBindings.hasOriginalTableOfContents(manager) else { return nil }
                }
            } else {
                // Original compact Library is a NavigationStack root; its
                // pushed Reader must be gone before this surface can be visible.
                guard surface == .library, !MaktabahApp.isIpad, manager.selectedBook == nil else { return nil }
            }
            let destination = surface == .library ? "native.library" : "native.reader.toc"
            // Public v2 already defines currentTab roots. No new wire format,
            // private tab identity, or guessed sidebar state is introduced.
            // The exact original page plus its independent UIKit witness must
            // actually be visible before it can acknowledge this root.
            return .init(destination: id(destination), presentation: .init(),
                         content: nil, state: state, focus: nil)
        case .noteDraft:
            guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer,
                  MaktabahNativeInspectorBinding.currentReader(in: manager) != nil else { return nil }
            // The session additionally requires its exact unsaved original
            // editor binding, live UITextView and independent UIKit witness.
            return .init(destination: id("native.reader.noteDraft"), presentation: .init(kind: .sheet),
                content: nil, state: state, focus: nil)
        case .inspector:
            guard !settingsPresented, selectedTab.canonical == .viewer,
                  let reader = MaktabahNativeInspectorBinding.currentReader(in: manager),
                  reader.readerInspectorVisible else { return nil }
            return .init(destination: id("native.reader.inspector"), presentation: .init(kind: .inspector),
                content: nil, state: .init(workspaceID: state.workspaceID, profileID: state.profileID,
                                          inspectorVisible: true), focus: nil)
        case .reader:
            guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer,
                  let tab = activeTab, let destination = tab.viewModel.currentDestination,
                  let actual = tab.viewModel.backendSection?.locator,
                  actual == destination.sectionLocator,
                  actual.backend == BackendCoordinator.shared.activeBackendID,
                  tab.book.backendLocator?.workKey == actual.workKey,
                  !tab.viewModel.contentText.isEmpty else { return nil }
            let newlyCreated = workspace?.hasCommittedNativeReader(tabID: tab.id) == true
            let content = ActionReaderDestination(sectionLocator: try ActionAppIdentityBridge.actionRef(actual),
                focusLocator: try destination.focusLocator.map(ActionAppIdentityBridge.actionRef),
                presentationMode: newlyCreated ? .newTab : .sameTab)
            let actualState = UIStateSpec(workspaceID: state.workspaceID, profileID: state.profileID,
                                          inspectorVisible: tab.viewModel.readerInspectorVisible)
            // This describes model state only. The scene session separately
            // requires its original TextKit text/viewport witness before an
            // observation can acknowledge this content or focused segment.
            return .init(destination: id("native.reader"), presentation: .init(kind: newlyCreated ? .newTab : .currentTab, tabID: stable(tab.id)),
                         content: content, state: actualState, focus: nil)
        }
    }
    struct HanlinCurrentWorkReadSource: Equatable {
        let readerOwner: ObjectIdentifier
        let requestToken: ReaderContentRequestToken
        let requested: LibraryReaderDestination
        let loaded: LibraryReaderDestination
    }
func hanlinCurrentWorkReadSource() throws -> HanlinCurrentWorkReadSource? {
        try Task.checkCancellation()
        guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer,
              BackendCoordinator.shared.activeBackendID == .otzaria,
              let activeID = manager.activeTabId else { return nil }
        let tabs = manager.openTabs.filter { $0.id == activeID }
        guard tabs.count == 1, let tab = tabs.first,
              MaktabahApp.isIpad || manager.selectedBook === tab.book,
              let book = tab.book.backendLocator, book.backend == .otzaria,
              tab.viewModel.currentBook?.id == tab.book.id,
              tab.viewModel.currentBook?.backendLocator == book,
              case .loaded = tab.viewModel.state,
              let requested = tab.viewModel.currentDestination,
              requested.sectionLocator.backend == book.backend,
              requested.sectionLocator.workKey == book.workKey,
              let section = tab.viewModel.backendSection,
              section.locator.backend == book.backend, section.locator.workKey == book.workKey,
              let render = tab.viewModel.backendRenderModel, !render.text.isEmpty,
              (render.text as NSString).isEqual(to: tab.viewModel.contentText),
              let token = tab.viewModel.contentLoadCoordinator.currentRequestToken(),
              token.backend == book.backend, token.workKey == book.workKey,
              token.sectionLocator == requested.sectionLocator,
              section.segments.allSatisfy({
                  $0.locator.backend == book.backend && $0.locator.workKey == book.workKey
              }) else { return nil }

        func containsRenderedSource(_ locator: TextLocator) -> Bool {
            let source = section.segments.filter { $0.locator == locator }
            let rendered = render.renderedSegments.filter { $0.locator == locator }
            return source.count == 1 && rendered.count == 1
                && rendered[0].segment == source[0] && rendered[0].visualRange.length > 0
        }
        if requested.sectionLocator != section.locator {
            guard case .legacyLine(let requestedLine) = requested.sectionLocator.position, requestedLine >= 0,
                  case .legacyLine(let loadedLine) = section.locator.position, loadedLine >= 0,
                  containsRenderedSource(requested.sectionLocator) else { return nil }
        }
        if let focus = requested.focusLocator {
            guard focus.backend == book.backend, focus.workKey == book.workKey,
                  containsRenderedSource(focus) else { return nil }
        }
        guard tab.viewModel.contentLoadCoordinator.canApplyContent(token: token, currentBookLocator: book) else { return nil }
        return .init(readerOwner: ObjectIdentifier(tab.viewModel), requestToken: token, requested: requested,
            loaded: .init(sectionLocator: section.locator, focusLocator: requested.focusLocator))
    }
}

struct ObservedReadSource: Equatable {
    let readerOwner: ObjectIdentifier
    let requested: LibraryReaderDestination
    let loaded: LibraryReaderDestination
    let requestToken: ReaderContentRequestToken?
}
@MainActor func observe(_ projection: MaktabahNativeSceneProjection) throws -> ObservedReadSource? {
    guard let value = try projection.hanlinCurrentWorkReadSource() else { return nil }
    return .init(readerOwner: value.readerOwner, requested: value.requested, loaded: value.loaded,
        requestToken: value.requestToken)
}
