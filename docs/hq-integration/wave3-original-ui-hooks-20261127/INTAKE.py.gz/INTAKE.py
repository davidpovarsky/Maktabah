import gzip,hashlib,io,json,pathlib,re,shutil,subprocess,time,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='f8a09c9327f7a8ad714130b2d0e89f19e10c45f6'
BRANCH='codex/otzaria-wave3-integration-20261127'
SHARED=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-shared-ui-original-hooks-20261127')
REGISTRATION_ZIP=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-annotation-selector-registration-20261127.zip')
PROOF='docs/hq-integration/wave3-original-ui-hooks-20261127'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def capacity():assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
def commit(message):
 git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m',message);return rev('HEAD')
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 sharedRaw=(SHARED/'RESULT.json').read_bytes();assert sha(sharedRaw)=='af44179a1284763defea5d9eb7d29259a671e861e39dca6784c11c3cc6428365'
 shared=json.loads(sharedRaw);assert shared['wholeFileParses']==6 and shared['nativeRuns']==0 and shared['AppleSDK']=='NOT_RUN'
 assert [(s['mode'],s['exit'])for s in shared['steps']]==[('Debug',0),('Release',0)]
 book=json.loads((SHARED/'input/bookinfo/SOURCE_EDITS.json').read_bytes());assert len(book['files'])==2
 sourceFiles=[]
 for row in book['files']:
  old=show(BASE,row['path']);candidate=(SHARED/'input/bookinfo/candidate'/row['path']).read_bytes();pin(old,row['before']);pin(candidate,row['after'])
  assert (SHARED/'input/bookinfo/before'/row['path']).read_bytes()==old and len(row['edits'])==2
  transformed=old.decode()
  for e in row['edits']:assert transformed.count(e['before'])==1;transformed=transformed.replace(e['before'],e['after'],1)
  assert transformed.encode()==candidate
  for e in reversed(row['edits']):assert transformed.count(e['after'])==1;transformed=transformed.replace(e['after'],e['before'],1)
  assert transformed.encode()==old
  sourceFiles.append({'path':row['path'],'before':row['before'],'after':row['after'],'candidatePath':str(SHARED/'input/bookinfo/candidate'/row['path']),'scope':'Only original UITextView alignment and dynamic font scaling; exact unchanged original load/content/selection/persistence bodies.'})
 inspector=json.loads((SHARED/'input/inspector/READER_INSPECTOR_PUBLICATION.json').read_bytes())
 old=show(BASE,inspector['path']);new=(SHARED/'input/inspector/candidate'/inspector['path']).read_bytes();pin(old,inspector['before']);pin(new,inspector['after'])
 assert (SHARED/'input/inspector/before'/inspector['path']).read_bytes()==old
 before='    var readerInspectorVisible: Bool = false\n'
 after='''    @ObservationIgnored
    private(set) var nativeInspectorPresentationRevision: UInt64? = 0
    var readerInspectorVisible: Bool = false {
        willSet {
            // Passive original publication metadata. Equal writes count too;
            // exhaustion is permanent and no observer callback is invoked.
            if let revision = nativeInspectorPresentationRevision {
                nativeInspectorPresentationRevision = revision == .max ? nil : revision + 1
            }
        }
    }
'''
 assert old.decode().count(before)==1 and old.decode().replace(before,after,1).encode()==new
 assert new.decode().count(after)==1 and new.decode().replace(after,before,1).encode()==old
 sourceFiles.append({'path':inspector['path'],'before':inspector['before'],'after':inspector['after'],'candidatePath':str(SHARED/'input/inspector/candidate'/inspector['path']),'scope':inspector['scope']})
 assert {r['path']for r in shared['files']}=={r['path']for r in sourceFiles}
 for r in shared['files']:pin(pathlib.Path(r['candidate']).read_bytes(),r['after']);pin(show(BASE,r['path']),r['before'])
 capsule=REGISTRATION_ZIP.read_bytes();assert sha(capsule)=='0160b173f5029acf518a2adba8c60aba8336e99b6c4b7e00ad0ca914196de3bc'
 registration=RUN/'registration';registration.mkdir(exist_ok=False)
 with zipfile.ZipFile(io.BytesIO(capsule))as z:
  for n in z.namelist():assert not pathlib.PurePosixPath(n).is_absolute()and'..'not in pathlib.PurePosixPath(n).parts
  z.extractall(registration)
 test=json.loads((registration/'SOURCE.json').read_bytes());old=show(BASE,test['path']);new=(registration/'candidate'/test['path']).read_bytes();pin(old,test['before']);pin(new,test['after'])
 assert (registration/'before'/test['path']).read_bytes()==old
 pattern=r'    @MainActor func (test\w+)\(\) async throws \{\n(.*?)\n    \}\n'
 oldMethods={name:body for name,body in re.findall(pattern,old.decode(),re.S)}
 newMethods={name:body for name,body in re.findall(pattern,new.decode(),re.S)}
 assert len(oldMethods)==6 and oldMethods==newMethods
 assert b'final class NativeAnnotationSelectionAcceptanceTests'not in new
 assert new.count(b'extension NativeRoutingAcceptanceTests {')==new.count(b'extension NativeRoutingPhoneAcceptanceTests {')==1
 compiler='/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc'
 assert sha(pathlib.Path(compiler).read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 steps=[]
 for mode in ['Debug','Release']:
  capacity();argv=[compiler,'-frontend','-parse','-target','arm64-apple-ios27.0']+(['-D','DEBUG']if mode=='Debug'else[])+[str(registration/'candidate'/test['path'])]
  start=time.time();p=subprocess.run(argv,capture_output=True,timeout=20)
  (RUN/(mode+'.stdout')).write_bytes(p.stdout);(RUN/(mode+'.stderr')).write_bytes(p.stderr)
  steps.append({'mode':mode,'argv':argv,'started':start,'finished':time.time(),'exit':p.returncode,'stdoutSHA256':sha(p.stdout),'stderrSHA256':sha(p.stderr)})
  dump(RUN/'REGISTRATION_SYNTAX.json',steps);assert p.returncode==0
 protected=['Source/Otzaria','Source/ChavrusaText','Source/Core','Source/UI','Source/LibraryBackend','Vendor','Scripts','.github','docs/architecture','Maktabah.xcodeproj']
 trees={p:rev(BASE+':'+p)for p in protected};helper='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift';helperBefore=show(BASE,helper)
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 for row in sourceFiles[:2]:(ROOT/row['path']).write_bytes(pathlib.Path(row['candidatePath']).read_bytes())
 git('add','--sparse','--',*[r['path']for r in sourceFiles[:2]])
 bookCommit=commit('Respect natural writing direction and Dynamic Type in original Book Info text views')
 row=sourceFiles[2];(ROOT/row['path']).write_bytes(pathlib.Path(row['candidatePath']).read_bytes());git('add','--sparse','--',row['path'])
 inspectorCommit=commit('Record every original Inspector visibility publication without changing its authority')
 (ROOT/test['path']).write_bytes(new);git('add','--sparse','--',test['path'])
 testCommit=commit('Register original Annotation journeys on existing Pad and Phone test owners')
 assert set(git('diff','--name-only',BASE,'HEAD','--','Source').decode().splitlines())=={r['path']for r in sourceFiles}
 assert git('diff','--name-only',BASE,'HEAD','--','Maktabah-iOSUITests').decode().splitlines()==[test['path']]
 assert show('HEAD',helper)==helperBefore
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 (proof/'ORIGINAL_UI_SOURCE.zip').write_bytes(pathlib.Path(str(SHARED)+'.zip').read_bytes())
 (proof/'ANNOTATION_REGISTRATION_SOURCE.zip').write_bytes(capsule)
 (proof/'WHOLE_FILE_SYNTAX.json').write_bytes(sharedRaw)
 dump(proof/'ANNOTATION_REGISTRATION_SYNTAX.json',steps)
 pending={'state':'WRITE_OUTCOME_UNCONFIRMED','toolError':'Asana add_comment and readback get_task returned MCP -32603 Internal error on both tasks. Check existing comments before resubmission.','taskIDs':['1220103384037482','1220763167870295'],'milestone':'409d28b2d5c3c72665081465ab628e53528645c6: original hidden-active-phone Group/Profile correction integrated;22/0 on current31Core13UI41Host; baseline0/4 andnegative0/3 retained;proof21e26d08. Later native selector joinf8a09c9327f7a8ad714130b2d0e89f19e10c45f6,proof6e92007a,6declarations notrun. All original native/production/owner/TestFlight gates remain open.'}
 dump(proof/'PENDING_ASANA_MILESTONE.json',pending)
 result={'schema':'otzaria.wave3.original-ui-hooks-intake.v1','base':BASE,'commits':{'bookInfo':bookCommit,'inspectorPublication':inspectorCommit,'annotationDeclarationOwners':testCommit},'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'sourceFiles':sourceFiles,'wholeFileInverse':True,'bookInfoOriginalHunks':4,'inspectorOriginalPropertyHunks':1,'wholeFileSyntaxParses':8,'sourceSyntaxEvidenceSHA256':sha(sharedRaw),'annotationRegistration':test,'nativeHelperUnchangedSHA256':sha(helperBefore),'protectedTrees':trees,'nativeRuns':0,'AppleSDK':'NOT_RUN','open':['Actual UIKit Dynamic Type, natural direction and VoiceOver verification','Inspector typed caller integration, exact warm/cold parent and current visibility proof','Actual platform discovery and six Annotation system journeys','Full original Native116/Release114+2 production acceptance, genuine owner signatures, final target merge and TestFlight'],'asanaUpdate':'Pending verified readback after connector Internal errors'}
 dump(proof/'RESULT.json',result)
 git('add','--sparse','--',PROOF);proofCommit=commit('Preserve exact original UI hook and Annotation registration evidence')
 assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==proofCommit
 terminal={'ok':True,'head':proofCommit,'commits':result['commits'],'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free};dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
