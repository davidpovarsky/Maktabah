/// Shared by the actual sidebar host and its portable, non-UI tests.
enum ReaderSidebarPolicy {
    static let minimumReaderWidth = 430.0
    static let minimumSidebarWidth = 220.0
    static let dividerAllowance = 1.0

    static func canTile(availableWidth: Double, sidebarWidth: Double, isCompact: Bool, readerWidth: Double = 430) -> Bool {
        !isCompact && availableWidth.isFinite && sidebarWidth.isFinite && readerWidth.isFinite
            && availableWidth >= max(minimumSidebarWidth, sidebarWidth) + max(minimumReaderWidth, readerWidth) + dividerAllowance
    }

    /// nil leaves the active page alone; vertical native scrolling stays with
    /// the original list. Body and page-control strip share this direction rule.
    static func swipeSelectsContents(horizontal: Double, vertical: Double, isRTL: Bool) -> Bool? {
        guard horizontal.isFinite, vertical.isFinite,
              abs(horizontal) >= 44, abs(horizontal) > abs(vertical) * 1.25 else { return nil }
        return isRTL ? horizontal > 0 : horizontal < 0
    }

    /// Avoids trapping on finite values outside `Int` bounds in debug breadcrumbs.
    static func debugRounded(_ value: Double) -> String {
        if let rounded = Int(exactly: value.rounded()) {
            return String(rounded)
        }
        return String(describing: value)
    }
}


import SwiftUI
import UIKit
private struct ReaderSidebarSplitConfiguration: UIViewControllerRepresentable {
    let onBodySwipe: @MainActor (Double, Double) -> Void
    #if DEBUG
    var onDiagnostic: (@MainActor (String) -> Void)? = nil
    #endif

    func makeUIViewController(context: Context) -> ReaderSidebarSplitConfigurationController {
        let controller = ReaderSidebarSplitConfigurationController()
        controller.onBodySwipe = onBodySwipe
        #if DEBUG
        controller.onDiagnostic = onDiagnostic
        #endif
        return controller
    }

    func updateUIViewController(_ controller: ReaderSidebarSplitConfigurationController, context: Context) {
        controller.onBodySwipe = onBodySwipe
        #if DEBUG
        controller.onDiagnostic = onDiagnostic
        #endif
        controller.configureExistingSplit()
    }

    static func dismantleUIViewController(_ controller: ReaderSidebarSplitConfigurationController, coordinator: ()) {
        controller.restoreConfiguration()
    }
}

private final class ReaderSidebarSplitConfigurationController: UIViewController, UIGestureRecognizerDelegate {
    var onBodySwipe: (@MainActor (Double, Double) -> Void)?
    #if DEBUG
    var onDiagnostic: (@MainActor (String) -> Void)?
    #endif
    private weak var bodySwipeHost: UIView?
    private weak var bodyTouchWindow: UIWindow?
    private var bodyTouchOrigin: CGPoint?
    private lazy var bodyPan = UIPanGestureRecognizer(target: self, action: #selector(bodyPanEnded(_:)))
    private weak var configuredSplit: UISplitViewController?
    private var originalBehavior: UISplitViewController.SplitBehavior?
    private var originalButtonVisibility: UISplitViewController.DisplayModeButtonVisibility?

    override func loadView() {
        view = UIView()
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = false
        view.isAccessibilityElement = false
    }

    override func didMove(toParent parent: UIViewController?) {
        super.didMove(toParent: parent)
        configureExistingSplit()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        configureExistingSplit()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        configureExistingSplit()
    }

    func configureExistingSplit() {
        guard let split = splitViewController, split.style == .doubleColumn else { return }
        if configuredSplit !== split {
            restoreConfiguration()
            configuredSplit = split
            originalBehavior = split.preferredSplitBehavior
            originalButtonVisibility = split.displayModeButtonVisibility
        }
        #if DEBUG
        var attachedHost: UIView?
        #endif
        if let primary = split.viewController(for: .primary)?.viewIfLoaded,
           view.isDescendant(of: primary), bodySwipeHost !== primary {
            bodySwipeHost?.removeGestureRecognizer(bodyPan)
            bodyPan.maximumNumberOfTouches = 1
            bodyPan.delegate = self
            primary.addGestureRecognizer(bodyPan)
            bodySwipeHost = primary
            #if DEBUG
            attachedHost = primary
            #endif
        }

        let availableWidth = split.view.safeAreaLayoutGuide.layoutFrame.width
        let primaryWidth = split.viewController(for: .primary)?.viewIfLoaded?.bounds.width ?? 0
        // A collapsed primary can occupy the whole window. It is not the
        // sidebar's width after expansion; use the native primary constraints.
        let constrainedWidth = max(split.minimumPrimaryColumnWidth, min(320, split.maximumPrimaryColumnWidth))
        let measuredWidth = !split.isCollapsed && primaryWidth > 0 && primaryWidth < availableWidth
            ? primaryWidth : constrainedWidth
        let sidebarWidth = max(constrainedWidth, measuredWidth)
        let readerWidth = UIFontMetrics.default.scaledValue(for: 430, compatibleWith: split.traitCollection)
        let tiles = ReaderSidebarPolicy.canTile(
            availableWidth: Double(availableWidth),
            sidebarWidth: Double(sidebarWidth),
            isCompact: split.traitCollection.horizontalSizeClass == .compact,
            readerWidth: Double(readerWidth)
        )
        #if DEBUG
        if let attachedHost {
            onDiagnostic?("attach host=\(Self.debugTypeName(attachedHost)) viewBounds=\(Self.debugRounded(view.bounds.width))x\(Self.debugRounded(view.bounds.height)) hostBounds=\(Self.debugRounded(attachedHost.bounds.width))x\(Self.debugRounded(attachedHost.bounds.height)) collapsed=\(split.isCollapsed) tiles=\(tiles)")
        }
        #endif
        let behavior = tiles ? UISplitViewController.SplitBehavior.tile : (originalBehavior ?? .automatic)
        if split.preferredSplitBehavior != behavior {
            split.preferredSplitBehavior = behavior
        }
        // On 27 the original reader intentionally supplies no manual fallback.
        // Explicitly request the existing system button; do not manufacture a
        // second toolbar item or infer its presence from the OS version alone.
        if #available(iOS 27.0, *) {
            if split.displayModeButtonVisibility != .always {
                split.displayModeButtonVisibility = .always
            }
        }
    }

    func restoreConfiguration() {
        #if DEBUG
        if bodySwipeHost != nil || configuredSplit != nil {
            onDiagnostic?("restore hadHost=\(bodySwipeHost != nil) hadSplit=\(configuredSplit != nil)")
        }
        #endif
        bodySwipeHost?.removeGestureRecognizer(bodyPan)
        bodySwipeHost = nil
        bodyTouchOrigin = nil
        bodyTouchWindow = nil
        if let split = configuredSplit {
            if let originalBehavior { split.preferredSplitBehavior = originalBehavior }
            if let originalButtonVisibility { split.displayModeButtonVisibility = originalButtonVisibility }
        }
        configuredSplit = nil
        originalBehavior = nil
        originalButtonVisibility = nil
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        guard gestureRecognizer === bodyPan else { return false }
        guard let window = view.window else {
            #if DEBUG
            onDiagnostic?("shouldReceive eligible=false hasWindow=false")
            #endif
            return false
        }
        // Exclude native navigation/search controls, page dots and the reader.
        let location = touch.location(in: view)
        let inBounds = view.bounds.contains(location)
        let eligible = !view.isHidden && view.alpha > 0 && inBounds
        // UIKit may defer this pan behind a native TOC row recognizer until
        // lift-off. Its began/end callbacks can then both report zero
        // translation. Keep the actual touch-down in a stable window space;
        // recognition, direction and minimum-distance guards still apply.
        if eligible {
            bodyTouchOrigin = touch.location(in: window)
            bodyTouchWindow = window
        }
        #if DEBUG
        onDiagnostic?("shouldReceive eligible=\(eligible) hasWindow=true hidden=\(view.isHidden) alphaPositive=\(view.alpha > 0) inBounds=\(inBounds) loc=\(Self.debugRounded(location.x)),\(Self.debugRounded(location.y)) bounds=\(Self.debugRounded(view.bounds.width))x\(Self.debugRounded(view.bounds.height)) touchView=\(Self.debugTypeName(touch.view))")
        #endif
        return eligible
    }

    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        guard gestureRecognizer === bodyPan else { return false }
        let velocity = bodyPan.velocity(in: view)
        let allowed = velocity.x.isFinite && velocity.y.isFinite && abs(velocity.x) > abs(velocity.y) * 1.25
        #if DEBUG
        let dir = !velocity.x.isFinite ? "nonFinite" : (velocity.x > 0 ? "right" : (velocity.x < 0 ? "left" : "zero"))
        onDiagnostic?("shouldBegin allowed=\(allowed) vx=\(Self.debugRounded(velocity.x)) vy=\(Self.debugRounded(velocity.y)) dir=\(dir)")
        #endif
        return allowed
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                           shouldBeRequiredToFailBy otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        guard gestureRecognizer === bodyPan, otherGestureRecognizer is UIPanGestureRecognizer,
              let host = bodySwipeHost, let otherView = otherGestureRecognizer.view else { return false }
        // Dynamic failure priority, rather than simultaneous recognition:
        // the page/list pan waits for this horizontal-only recognizer to fail.
        // No scroll view is disabled and no permanent dependency is installed.
        let inHost = otherView === host || otherView.isDescendant(of: host)
        #if DEBUG
        if otherGestureRecognizer !== bodyPan {
            onDiagnostic?("requireFail result=\(inHost) other=\(Self.debugTypeName(otherGestureRecognizer)) otherView=\(Self.debugTypeName(otherView)) inHost=\(inHost) enabled=\(otherGestureRecognizer.isEnabled) state=\(Self.debugStateName(otherGestureRecognizer.state))")
        }
        #endif
        return inHost
    }

    @objc private func bodyPanEnded(_ sender: UIPanGestureRecognizer) {
        #if DEBUG
        if sender.state != .changed {
            let translation = sender.translation(in: view)
            onDiagnostic?("panState state=\(Self.debugStateName(sender.state)) hasWindow=\(view.window != nil) dx=\(Self.debugRounded(translation.x)) dy=\(Self.debugRounded(translation.y))")
        }
        #endif
        guard sender.state == .ended || sender.state == .cancelled || sender.state == .failed else { return }
        defer {
            bodyTouchOrigin = nil
            bodyTouchWindow = nil
        }
        guard sender.state == .ended,
              let window = bodyTouchWindow, view.window === window,
              let origin = bodyTouchOrigin else { return }
        let end = sender.location(in: window)
        let displacement = CGPoint(x: end.x - origin.x, y: end.y - origin.y)
        #if DEBUG
        onDiagnostic?("bodyDisplacement dx=\(Self.debugRounded(displacement.x)) dy=\(Self.debugRounded(displacement.y))")
        #endif
        onBodySwipe?(Double(displacement.x), Double(displacement.y))
    }

    #if DEBUG
    private static func debugRounded(_ value: CGFloat) -> String {
        ReaderSidebarPolicy.debugRounded(Double(value))
    }

    private static func debugTypeName(_ object: Any?) -> String {
        object.map { String(describing: type(of: $0)) } ?? "nil"
    }

    private static func debugStateName(_ state: UIGestureRecognizer.State) -> String {
        switch state {
        case .possible: "possible"
        case .began: "began"
        case .changed: "changed"
        case .ended: "ended"
        case .cancelled: "cancelled"
        case .failed: "failed"
        @unknown default: "unknown(\(state.rawValue))"
        }
    }
    #endif
}
