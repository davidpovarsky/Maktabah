"""Complete read-only inspection of the authenticated original Zayit archive.

Reuse the stream parser; recognize a legacy iOS minimum-version command only
where architecture establishes device (arm64) or Simulator (x86_64). arm64
Simulator objects still require the explicit modern Simulator platform.
No extraction, execution or build is performed.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import plistlib
import re
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("original_stream", ROOT / "verify-framework-stream.py")
PARSER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PARSER)
ARCHIVE = ROOT / "14595389912.zip"
EXPECTED_SHA = "64f4ba7b8d6cfced525732699fd1958ca0cc5ec836369dcf839d91df855914d7"
OUTPUT = ROOT / "14595389912-stream-inspection-legacy.json"

actual = hashlib.file_digest(ARCHIVE.open("rb"), "sha256").hexdigest()
assert actual == EXPECTED_SHA
result = {"artifactID": 14595389912, "archiveSHA256": actual,
          "archiveBytes": ARCHIVE.stat().st_size, "libraries": {}, "headers": {}, "smallFiles": {}}
with zipfile.ZipFile(ARCHIVE) as archive:
    assert len(archive.infolist()) == 1
    entry = archive.infolist()[0]
    with archive.open(entry) as source:
        stream = PARSER.Reader(source)
        with tarfile.open(fileobj=stream, mode="r|") as tar:
            for member in tar:
                assert not member.issym() and not member.islnk()
                if not member.isfile():
                    continue
                content = tar.extractfile(member)
                if member.name.endswith(".a"):
                    result["libraries"][member.name] = PARSER.library(content, member.size)
                else:
                    assert member.size < 1024 * 1024
                    data = content.read()
                    row = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                    if member.name.endswith(".h"):
                        row["content"] = data.decode("utf-8")
                        result["headers"][member.name] = row
                    else:
                        if member.name.endswith("Info.plist"):
                            row["plist"] = plistlib.loads(data)
                        result["smallFiles"][member.name] = row
        while stream.read(1024 * 1024):
            pass
        assert stream.pos == entry.file_size
        result["tarSHA256"] = stream.sha.hexdigest()

headers = list(result["headers"].values())
assert len(headers) == 2 and headers[0]["sha256"] == headers[1]["sha256"]
declarations = {"_" + name for name in re.findall(r"\b(mzayit_[a-z_]+)\s*\(", headers[0]["content"])}
assert declarations and len(result["libraries"]) == 2
proofs = []
for name, library in result["libraries"].items():
    simulator = "simulator" in name
    expected_platform = 7 if simulator else 2
    expected_arches = {0x1000007, 0x100000C} if simulator else {0x100000C}
    actual_arches = set()
    for slice in library["slices"]:
        assert declarations <= slice["definedExports"].keys()
        for symbol in sorted(declarations):
            info = slice["definedExports"][symbol]
            cpu = info["cpuType"]
            actual_arches.add(cpu)
            modern, legacy = info["buildVersions"], info["legacyMinimumVersions"]
            if modern:
                assert all(row["platform"] == expected_platform for row in modern)
                method = "EXPLICIT_LC_BUILD_VERSION"
            else:
                # LC_VERSION_MIN_IPHONEOS is iOS, without a Simulator field.
                # x86_64 disambiguates Simulator; arm64 is not sufficient to
                # admit a legacy arm64 Simulator binary.
                assert legacy and all(row["command"] == 0x25 for row in legacy)
                assert (simulator and cpu == 0x1000007) or (not simulator and cpu == 0x100000C)
                method = "LEGACY_IOS_COMMAND_WITH_ARCHITECTURE_AND_XCFRAMEWORK_SLICE"
            proofs.append({"library": name, "symbol": symbol, "cpuType": cpu,
                           "expectedPlatform": expected_platform, "method": method})
    assert actual_arches == expected_arches

result.update(status="AUTHENTIC_ARCHIVE_STATIC_DEFINED_EXPORT_AND_PLATFORM_VERIFIED",
              declaredExports=sorted(declarations), platformProof=proofs,
              libraryExtracted=False, binaryExecuted=False, appleRuntimeTestsRun=False)
assert not OUTPUT.exists()
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"status": result["status"], "artifactID": 14595389912,
                  "declaredExports": len(declarations), "sliceExportProofs": len(proofs),
                  "platformMethods": sorted({p["method"] for p in proofs}),
                  "resultSHA256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest()}))
