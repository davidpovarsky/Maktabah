"""Inspect authenticated XCFramework tar members without extracting libraries.

BSD archive symbol tables identify defined exports and their actual Mach-O
objects; LC_BUILD_VERSION binds those objects to device/simulator platforms.
No Apple binary is executed and no build is performed.
"""
import hashlib
import json
from pathlib import Path
import plistlib
import re
import struct
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
NEEDLES = {
    "consumerCommitD5": b"d5d59d1269bdf87fb0a6901cf31941726a0c699b",
    "originalUpstreamBase265": b"265a14ea54f959a3e266d6e8acfa3a3b98101d68",
    "consumerRepository": b"davidpovarsky/otzaria_search_engine",
    "consumerBranch": b"codex/otzaria-exact-occurrences-20261120",
}
NEW_EXPORTS = {
    "_otzaria_search_engine_occurrence_request_new",
    "_otzaria_search_engine_occurrence_request_cancel",
    "_otzaria_search_engine_occurrence_request_release",
    "_otzaria_search_engine_count_occurrences_json",
}


class Reader:
    def __init__(self, source, size=None):
        self.source, self.size = source, size
        self.pos, self.sha = 0, hashlib.sha256()
        self.scope = None
        self.tail = b""

    def read(self, count):
        if self.size is not None:
            assert 0 <= count <= self.size - self.pos
        data = self.source.read(count)
        if self.size is not None:
            assert len(data) == count
        self.pos += len(data)
        self.sha.update(data)
        if self.scope is not None:
            window = self.tail + data
            for key, needle in NEEDLES.items():
                if needle in window:
                    self.scope.add(key)
            self.tail = window[-128:]
        return data

    def discard(self, count):
        while count:
            n = min(count, 1024 * 1024)
            self.read(n)
            count -= n


def symbol_table(data, name, archive_size):
    width = 8 if "_64" in name else 4
    for endian in ("little", "big"):
        get = lambda offset: int.from_bytes(data[offset:offset + width], endian)
        table_bytes = get(0)
        strings_at = width + table_bytes
        if table_bytes % (2 * width) or strings_at + width > len(data):
            continue
        strings_bytes = get(strings_at)
        strings = data[strings_at + width:strings_at + width + strings_bytes]
        if len(strings) != strings_bytes:
            continue
        selected, valid, count = {}, True, 0
        for offset in range(width, strings_at, width * 2):
            string_offset, object_offset = get(offset), get(offset + width)
            if string_offset >= len(strings) or object_offset >= archive_size:
                valid = False
                break
            end = strings.find(b"\0", string_offset)
            if end < 0:
                valid = False
                break
            symbol = strings[string_offset:end].decode("utf-8")
            count += 1
            if symbol.startswith(("_otzaria_search_engine_", "_mzayit_")):
                assert symbol not in selected
                selected[symbol] = object_offset
        if valid:
            return selected, {"symbols": count, "entryWidth": width, "endianness": endian,
                              "stringTableSHA256": hashlib.sha256(strings).hexdigest()}
    raise AssertionError("Unrecognized BSD archive symbol table")


def macho_header(reader, length):
    first = reader.read(min(length, 32))
    magic = first[:4]
    formats = {b"\xcf\xfa\xed\xfe": ("<", 32), b"\xfe\xed\xfa\xcf": (">", 32),
               b"\xce\xfa\xed\xfe": ("<", 28), b"\xfe\xed\xfa\xce": (">", 28)}
    if magic not in formats:
        reader.discard(length - len(first))
        return {"magic": magic.hex(), "machO": False}
    endian, header_size = formats[magic]
    cpu, subtype, filetype, commands, command_bytes = struct.unpack_from(endian + "IIIII", first, 4)
    assert commands <= 10000 and command_bytes <= 16 * 1024 * 1024
    assert header_size + command_bytes <= length
    consumed_commands = first[header_size:]
    payload = consumed_commands + reader.read(command_bytes - len(consumed_commands))
    platforms, legacy, offset = [], [], 0
    for _ in range(commands):
        command, size = struct.unpack_from(endian + "II", payload, offset)
        assert size >= 8 and offset + size <= len(payload)
        if command == 0x32:
            platform, minimum, sdk = struct.unpack_from(endian + "III", payload, offset + 8)
            platforms.append({"platform": platform, "minimumOS": minimum, "sdk": sdk})
        elif command in (0x24, 0x25, 0x2F, 0x30):
            minimum, sdk = struct.unpack_from(endian + "II", payload, offset + 8)
            legacy.append({"command": command, "minimumOS": minimum, "sdk": sdk})
        offset += size
    assert offset == len(payload)
    reader.discard(length - header_size - command_bytes)
    return {"machO": True, "cpuType": cpu, "cpuSubtype": subtype, "fileType": filetype,
            "buildVersions": platforms, "legacyMinimumVersions": legacy}


def static_archive(reader, size, initial=b"", cpu=None):
    start = reader.pos - len(initial)
    assert initial + reader.read(8 - len(initial)) == b"!<arch>\n"
    end, symbols, selected_objects, tables = start + size, {}, {}, []
    members = 0
    observed = set()
    reader.scope, reader.tail = observed, b""
    while reader.pos < end:
        offset = reader.pos - start
        header = reader.read(60)
        assert header[58:60] == b"`\n"
        name = header[:16].decode("ascii").strip()
        length = int(header[48:58].decode("ascii").strip())
        assert reader.pos + length <= end
        payload_length = length
        if name.startswith("#1/"):
            name_length = int(name[3:])
            assert name_length <= length and name_length < 4096
            name = reader.read(name_length).rstrip(b"\0").decode("utf-8")
            payload_length -= name_length
        if name.startswith("__.SYMDEF"):
            assert payload_length <= 32 * 1024 * 1024
            new_symbols, description = symbol_table(reader.read(payload_length), name, size)
            assert not (symbols.keys() & new_symbols.keys())
            symbols.update(new_symbols)
            tables.append(description)
        else:
            metadata = macho_header(reader, payload_length)
            declared = sorted(symbol for symbol, position in symbols.items() if position == offset)
            if declared:
                assert metadata["machO"] and metadata["fileType"] == 1
                if cpu is not None:
                    assert metadata["cpuType"] == cpu
                for symbol in declared:
                    selected_objects[symbol] = dict(metadata, archiveMember=name, archiveMemberOffset=offset)
        if length % 2:
            assert reader.read(1) == b"\n"
        members += 1
    assert reader.pos == end and tables
    assert symbols and set(symbols) == set(selected_objects)
    reader.scope = None
    return {"bytes": size, "cpuTypeFromFatHeader": cpu, "archiveMembers": members,
            "symbolTables": tables, "definedExports": selected_objects,
            "embeddedExactProvenanceStrings": sorted(observed)}


def library(source, size):
    reader = Reader(source, size)
    magic = reader.read(8)
    if magic == b"!<arch>\n":
        slices = [static_archive(reader, size, initial=magic)]
    else:
        assert magic[:4] == b"\xca\xfe\xba\xbe", magic.hex()
        count = int.from_bytes(magic[4:], "big")
        assert 1 <= count <= 8
        descriptions = [struct.unpack(">IIIII", reader.read(20)) for _ in range(count)]
        slices = []
        for cpu, subtype, offset, length, alignment in sorted(descriptions, key=lambda x: x[2]):
            assert offset >= reader.pos and offset + length <= size
            reader.discard(offset - reader.pos)
            slices.append(static_archive(reader, length, cpu=cpu))
        reader.discard(size - reader.pos)
    assert reader.pos == size
    return {"bytes": size, "sha256": reader.sha.hexdigest(), "slices": slices}


def inspect(artifact, expected_sha, occurrence):
    path = ROOT / (str(artifact) + ".zip")
    actual = hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
    assert actual == expected_sha
    result = {"artifactID": artifact, "archiveSHA256": actual, "archiveBytes": path.stat().st_size,
              "libraries": {}, "headers": {}, "smallFiles": {}}
    with zipfile.ZipFile(path) as archive:
        assert len(archive.infolist()) == 1
        entry = archive.infolist()[0]
        with archive.open(entry) as source:
            stream = Reader(source)
            with tarfile.open(fileobj=stream, mode="r|") as tar:
                for member in tar:
                    assert not member.issym() and not member.islnk()
                    if not member.isfile():
                        continue
                    content = tar.extractfile(member)
                    if member.name.endswith(".a"):
                        result["libraries"][member.name] = library(content, member.size)
                    else:
                        assert member.size < 1024 * 1024
                        data = content.read()
                        row = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                        if member.name.endswith(".h"):
                            row["content"] = data.decode("utf-8")
                            result["headers"][member.name] = row
                        elif member.name.endswith("Info.plist"):
                            row["plist"] = plistlib.loads(data)
                            result["smallFiles"][member.name] = row
                        else:
                            result["smallFiles"][member.name] = row
            while stream.read(1024 * 1024):
                pass
            assert stream.pos == entry.file_size
            result["tarSHA256"] = stream.sha.hexdigest()
    headers = list(result["headers"].values())
    assert len(headers) == 2 and headers[0]["sha256"] == headers[1]["sha256"]
    declarations = {"_" + name for name in re.findall(r"\b((?:otzaria_search_engine_|mzayit_)[a-z_]+)\s*\(", headers[0]["content"])}
    assert len(result["libraries"]) == 2
    for name, lib in result["libraries"].items():
        expected_platform = 7 if "simulator" in name else 2
        expected_arches = {0x1000007, 0x100000C} if "simulator" in name else {0x100000C}
        actual_arches = set()
        for slice in lib["slices"]:
            assert declarations <= slice["definedExports"].keys()
            if occurrence:
                assert NEW_EXPORTS <= slice["definedExports"].keys()
                assert set(NEEDLES) <= set(slice["embeddedExactProvenanceStrings"])
            for symbol in declarations:
                object_info = slice["definedExports"][symbol]
                actual_arches.add(object_info["cpuType"])
                assert object_info["buildVersions"] and all(row["platform"] == expected_platform for row in object_info["buildVersions"])
        assert actual_arches == expected_arches
    result.update(status="AUTHENTIC_ARCHIVE_STATIC_DEFINED_EXPORT_AND_PLATFORM_VERIFIED",
                  declaredExports=sorted(declarations), occurrenceExports=sorted(NEW_EXPORTS) if occurrence else [],
                  libraryExtracted=False, binaryExecuted=False, appleRuntimeTestsRun=False)
    out = ROOT / (str(artifact) + "-stream-inspection.json")
    assert not out.exists()
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"artifactID": artifact, "status": result["status"], "headerSHA256": headers[0]["sha256"],
                      "libraries": {name:{"bytes":lib["bytes"],"sha256":lib["sha256"],
                          "slices":[{"cpuTypeFromFatHeader":s["cpuTypeFromFatHeader"],"exportCount":len(s["definedExports"]),
                                     "newExportsPresent":NEW_EXPORTS <= s["definedExports"].keys() if occurrence else None,
                                     "embeddedProvenance":s["embeddedExactProvenanceStrings"]} for s in lib["slices"]]}
                                    for name,lib in result["libraries"].items()},
                      "resultSHA256":hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__ == "__main__":
    inspect(14596463166, "efc73de90d74fdd380ffecfa334fe9dcece38519832b89cf3fb2a5741dcc25ad", True)
    inspect(14595389912, "64f4ba7b8d6cfced525732699fd1958ca0cc5ec836369dcf839d91df855914d7", False)
