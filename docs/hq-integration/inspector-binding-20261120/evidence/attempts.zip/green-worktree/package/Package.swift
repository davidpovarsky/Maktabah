// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "InspectorBindingAcceptance", dependencies: [
        .package(path: "C:/Users/DAVID/Code/Maktabah-inspector-binding-20261120/Source/Otzaria/Actions"),
        .package(path: "C:/Users/DAVID/Code/Maktabah-inspector-binding-20261120/Source/Otzaria/UIRouting"),
        .package(path: "C:/Users/DAVID/Code/Maktabah-inspector-binding-20261120/Source/ChavrusaText/UIRoutingHost")
], targets: [.executableTarget(name: "InspectorBindingAcceptance", dependencies: [
    .product(name: "OtzariaActionCore", package: "Actions"),
    .product(name: "OtzariaUIRouting", package: "UIRouting"),
    .product(name: "ChavrusaUIRoutingHost", package: "UIRoutingHost")
])], swiftLanguageModes: [.v6])
