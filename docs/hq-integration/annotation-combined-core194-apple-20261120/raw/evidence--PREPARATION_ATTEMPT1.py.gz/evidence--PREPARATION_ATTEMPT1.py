#!/usr/bin/env python3
"""Prepare the authorized metadata-only rebindings, keeping historical inputs."""
from pathlib import Path
import copy
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE / "base"
ROOT = HERE / "candidate"
M = "bd855c02fcef94a732f584c5992aeacec6b1b21d"
CORE = "a89104250c1aedf75e6aa95ed3f111a4dc597217"
BRANCH = "codex/otzaria-annotation-core194-combined-apple-20261120"
WORKFLOW = ".github/workflows/otzaria-annotation-core194-combined-apple.yml"


def js(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()


def pin(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def replace(relative, edits):
    before = (BASE / relative).read_bytes()
    after = before
    for old, new in edits:
        assert after.count(old) == 1, (relative, old)
        after = after.replace(old, new, 1)
    (ROOT / relative).write_bytes(after)
    inverse = after
    for old, new in reversed(edits):
        assert inverse.count(new) == 1
        inverse = inverse.replace(new, old, 1)
    assert inverse == before
    return {"before": pin(before), "after": pin(after), "exact_inverse": True,
            "edits": [{"old": a.decode(), "new": b.decode()} for a, b in edits]}


proof = {}
relative = "tools/hq-annotation-disconnect-acceptance.py"
proof[relative] = replace(relative, [(b'CORE_TREE = "5d0ee482c8f10726fe3863792dac94c18e94d792"',
                                       ('CORE_TREE = "' + CORE + '"').encode()),
                                      (b'This gate qualifies original Core5d0 only', b'This gate requires the reviewed combined Core tree')])
relative = "tools/hq-cold-search-core-acceptance.py"
proof[relative] = replace(relative, [
    (b'WORKFLOW = ".github/workflows/otzaria-cold-search-core-validation.yml"', ('WORKFLOW = "' + WORKFLOW + '"').encode()),
    (b'BRANCH = "refs/heads/codex/otzaria-cold-search-core-apple-v2-20261120"', ('BRANCH = "refs/heads/' + BRANCH + '"').encode())])
relative = "Tests/HQ/cold-search/CORE_INPUTS.json"
old = json.loads((BASE / relative).read_bytes())
new = copy.deepcopy(old)
for row in new["support_inputs"]:
    if row["path"] == "tools/hq-cold-search-core-acceptance.py":
        row.update(pin((ROOT / row["path"]).read_bytes()))
inverse = copy.deepcopy(new)
inverse["support_inputs"] = old["support_inputs"]
assert inverse == old and sum(a != b for a, b in zip(old["support_inputs"], new["support_inputs"], strict=True)) == 1
(ROOT / relative).write_bytes(js(new))
proof[relative] = {"before": pin((BASE / relative).read_bytes()), "after": pin(js(new)),
                   "semantic_inverse": True, "changed_only": "support_inputs[tools/hq-cold-search-core-acceptance.py]"}
relative = "Scripts/CI/hq-stage2-otzaria-test-additions.json"
old = json.loads((BASE / relative).read_bytes())
old_project = old["excluded_build_inputs"]["Maktabah.xcodeproj/project.pbxproj"]
new_project = pin((ROOT / "Maktabah.xcodeproj/project.pbxproj").read_bytes())["git_blob"]
assert new_project == "eaf385c363750e04688a4cda181f40597f22f315"
proof[relative] = replace(relative, [(old_project.encode(), new_project.encode())])
relative = "Scripts/CI/hq-stage2-focused-apple.inputs.json"
old = json.loads((BASE / relative).read_bytes())
new = copy.deepcopy(old)
new["application_source_sha"] = M
new["application_trees"] = {"Source": "efeee8e2366dfa1155f9c029cff1de5c6441f39b",
                             "Vendor": "4065c0e62af325e83a65fe0c70270985229807ae",
                             "Maktabah.xcodeproj": "d2a88b3624cfab55682ea68e2634f4b6a7d5533f"}
new["otzaria_test_additions_sha256"] = pin((ROOT / "Scripts/CI/hq-stage2-otzaria-test-additions.json").read_bytes())["sha256"]
inverse = copy.deepcopy(new)
for key in ("application_source_sha", "application_trees", "otzaria_test_additions_sha256"):
    inverse[key] = old[key]
assert inverse == old
(ROOT / relative).write_bytes(js(new))
proof[relative] = {"before": pin((BASE / relative).read_bytes()), "after": pin(js(new)), "semantic_inverse": True,
                   "changed_only": ["application_source_sha", "application_trees", "otzaria_test_additions_sha256"]}

relative = "Scripts/CI/local-annotation-cloud-apple.inputs.json"
old = json.loads((HERE / "original" / relative).read_bytes())
new = copy.deepcopy(old)
new["reviewed_source_sha"] = M
new["core_tree_sha"] = CORE
tree = json.loads((HERE.parent / "annotation-cloud-api-compatibility-20261120/publication/ROOT_ACTUAL_TREE.json").read_bytes())
tree = json.loads(tree["structuredContent"]["content"]) if "structuredContent" in tree else tree
entries = {row["path"]: row for row in tree["tree"]}
new["application_trees"] = {path: entries[path]["sha"] for path in old["application_trees"]}
for path in new["source_pins"]:
    new["source_pins"][path] = pin((ROOT / path).read_bytes())
inverse = copy.deepcopy(new)
for key in ("reviewed_source_sha", "core_tree_sha", "application_trees", "source_pins"):
    inverse[key] = old[key]
assert inverse == old
(ROOT / relative).write_bytes(js(new))
proof[relative] = {"historical_before": pin((HERE / "original" / relative).read_bytes()), "after": pin(js(new)),
                   "semantic_inverse": True, "changed_only": ["reviewed_source_sha", "core_tree_sha", "application_trees", "source_pins"],
                   "changed_input_pins": sorted(path for path in old["source_pins"] if old["source_pins"][path] != new["source_pins"][path])}
(HERE / "METADATA_INVERSes.json").write_bytes(js(proof))
patch = []
for relative in proof:
    source = BASE / relative
    if not source.exists(): source = HERE / "original" / relative
    patch.extend(difflib.unified_diff(source.read_text().splitlines(True), (ROOT / relative).read_text().splitlines(True),
                                      fromfile="a/" + relative, tofile="b/" + relative))
(HERE / "METADATA.patch").write_text("".join(patch))
print(json.dumps({"status": "PASS_METADATA_INVERSES_ONLY", "files": len(proof),
                  "current_core_tree": CORE, "production_and_Swift_tests_changed": 0}, indent=2))
