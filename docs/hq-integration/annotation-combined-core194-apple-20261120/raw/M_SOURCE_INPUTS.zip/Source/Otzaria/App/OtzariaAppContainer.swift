import Foundation
import SQLite3

struct OtzariaDatabaseToken: Hashable, Equatable, Sendable {
    let generation: UInt64
    let id: UUID

    init(generation: UInt64 = 0, id: UUID = UUID()) {
        self.generation = generation
        self.id = id
    }
}

@MainActor
final class OtzariaAppContainer: ObservableObject {
    @Published private(set) var repositories: OtzariaAppRepositories?
    @Published private(set) var databaseURL: URL?
    @Published private(set) var databaseToken = OtzariaDatabaseToken()
    @Published var databaseError: String?
    @Published var isOpeningDatabase = false

    private var tokenGeneration: UInt64 = 0
    private let accessController = OtzariaDatabaseAccessController.shared
    private var connection: OtzariaSQLiteConnection?

    private func bumpDatabaseToken() {
        tokenGeneration &+= 1
        databaseToken = OtzariaDatabaseToken(generation: tokenGeneration)
    }

    deinit {
        connection?.close()
    }

    func restoreDatabaseIfPossible() async {
        do {
            guard let url = try accessController.restoreIfNeeded() else {
                if repositories != nil || databaseURL != nil {
                    resetConnection()
                    OtzariaMaktabahBridge.shared.resetConnection()
                    repositories = nil
                    databaseURL = nil
                    bumpDatabaseToken()
                }
                return
            }
            guard repositories == nil || databaseURL != url else { return }
            await openDatabase(at: url)
        } catch {
            databaseError = error.localizedDescription
        }
    }

    func openPickedDatabase(at url: URL) async {
        isOpeningDatabase = true
        databaseError = nil
        defer { isOpeningDatabase = false }

        resetConnection()
        OtzariaMaktabahBridge.shared.resetConnection()
        repositories = nil
        databaseURL = nil

        do {
            let selectedURL = try accessController.selectExternalDatabase(url)
            try await establishConnection(at: selectedURL)
        } catch {
            databaseError = error.localizedDescription
        }
    }

    func forgetDatabase() {
        resetConnection()
        OtzariaMaktabahBridge.shared.resetConnection()
        accessController.clearSelection()
        repositories = nil
        databaseURL = nil
        databaseError = nil
        bumpDatabaseToken()
    }

    private func openDatabase(at url: URL) async {
        isOpeningDatabase = true
        databaseError = nil
        defer { isOpeningDatabase = false }

        resetConnection()
        OtzariaMaktabahBridge.shared.resetConnection()
        repositories = nil

        do {
            try await establishConnection(at: url)
        } catch {
            databaseError = error.localizedDescription
        }
    }

    private func establishConnection(at url: URL) async throws {
        let newConnection = try OtzariaSQLiteConnection.openReadOnly(url: url)
        try await newConnection.read { db in
            try OtzariaSchemaValidator.validate(db)
        }

        connection = newConnection
        repositories = OtzariaAppRepositories(
            library: OtzariaSQLiteLibraryRepository(database: newConnection),
            bookText: OtzariaSQLiteBookTextRepository(database: newConnection),
            sources: OtzariaSQLiteSourceRepository(database: newConnection)
        )
        databaseURL = url
        bumpDatabaseToken()
    }

    private func resetConnection() {
        connection?.close()
        connection = nil
    }
}

struct OtzariaAppRepositories {
    let library: any OtzariaLibraryRepository
    let bookText: any OtzariaBookTextRepository
    let sources: any OtzariaSourceRepository
}

final class OtzariaMaktabahBridge: @unchecked Sendable {
    static let shared = OtzariaMaktabahBridge()

    private let accessController = OtzariaDatabaseAccessController.shared
    private let unitModeKey = "otzaria_reader_unit_mode"
    private let lock = NSRecursiveLock()
    private(set) var dbGeneration: UInt64 = 0
    func generationSnapshot() -> UInt64 { lock.withLock { dbGeneration } }
    /// A storage-lock holder must not wait for this owner: openIfNeeded can
    /// hold it while waiting for the original legacy-migration lock.
    func tryGenerationSnapshot() -> UInt64? {
        guard lock.try() else { return nil }
        defer { lock.unlock() }
        return dbGeneration
    }
    private var database: SQLiteDatabase?
    private var openedDatabaseURL: URL?
    private var readingUnitService: OtzariaReadingUnitService?

    private init() {}

    var isEnabled: Bool { accessController.currentURL != nil }

    var databasePath: String? { accessController.currentURL?.path }

    var databaseURL: URL? { accessController.currentURL }

    func installDatabase(from sourceURL: URL) throws {
        resetConnection()
        _ = try accessController.selectExternalDatabase(sourceURL)
        _ = try openIfNeeded()
    }

    func activateManagedDatabase(at url: URL) throws {
        // Prove that the promoted file can be reopened before changing the
        // persisted selection or discarding an external bookmark.
        let candidate = try SQLiteDatabase(
            path: url.path,
            flags: SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX
        )
        _ = try accessController.activateManagedDatabase(at: url)
        lock.lock()
        dbGeneration &+= 1
        clearAllCaches()
        database = candidate
        openedDatabaseURL = url
        readingUnitService = nil
        lock.unlock()
    }

    @discardableResult
    func restoreDatabaseIfPossible() throws -> Bool {
        guard try accessController.restoreIfNeeded() != nil else { return false }
        return try openIfNeeded()
    }

    func forgetDatabase() {
        resetConnection()
        accessController.clearSelection()
    }

    func close() {
        resetConnection()
    }

    func clearAllCaches() {
        clearReadingUnitCache()
        readingUnitService?.clearCaches()
        Self.clearCategoryCache()
        BookPageCache.shared.removeAll()
    }

    func resetConnection() {
        lock.lock()
        dbGeneration &+= 1
        clearAllCaches()
        database = nil
        openedDatabaseURL = nil
        readingUnitService = nil
        lock.unlock()
    }

    @discardableResult
    func openIfNeeded() throws -> Bool {
        lock.lock()
        defer { lock.unlock() }

        guard let url = try accessController.restoreIfNeeded() else { return false }
        if database != nil, openedDatabaseURL == url { return true }
        dbGeneration &+= 1
        clearAllCaches()
        database = nil
        openedDatabaseURL = nil
        database = try SQLiteDatabase(path: url.path, flags: SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX)
        openedDatabaseURL = url
        readingUnitService = nil
        return true
    }

    private func requireDatabase() throws -> SQLiteDatabase {
        _ = try openIfNeeded()
        guard let database else {
            throw NSError(domain: "Otzaria", code: 2, userInfo: [NSLocalizedDescriptionKey: "Otzaria database is not selected"])
        }
        return database
    }

    var currentReadingUnitMode: OtzariaUnitMode {
        get {
            OtzariaUnitMode(
                storageValue: UserDefaults.standard.string(forKey: unitModeKey) ?? OtzariaUnitMode.paragraph.storageValue
            )
        }
        set {
            UserDefaults.standard.set(newValue.storageValue, forKey: unitModeKey)
        }
    }

    func withReadingUnitService<T>(_ work: (OtzariaReadingUnitService) -> T) -> T? {
        let (service, gen) = lock.withLock { () -> (OtzariaReadingUnitService?, UInt64) in
            guard let db = try? requireDatabase() else { return (nil, dbGeneration) }
            if readingUnitService == nil {
                readingUnitService = OtzariaReadingUnitService(database: db)
            }
            return (readingUnitService, dbGeneration)
        }
        guard let service else { return nil }
        let result = work(service)
        guard lock.withLock({ dbGeneration == gen }) else { return nil }
        return result
    }

    /// Publish reader payloads under the same generation guard as the DB lease.
    /// SQL/decode and cost estimation remain outside the bridge lock.
    func withCachedReadingUnit(_ work: (OtzariaReadingUnitService) throws -> OtzariaReadingUnit?) rethrows -> OtzariaReadingUnit? {
        guard !Task.isCancelled else { return nil }
        let snapshot = lock.withLock { () -> (OtzariaReadingUnitService, UInt64)? in
            guard let db = try? requireDatabase() else { return nil }
            if readingUnitService == nil {
                readingUnitService = OtzariaReadingUnitService(database: db)
            }
            guard let service = readingUnitService else { return nil }
            return (service, dbGeneration)
        }
        guard let (service, generation) = snapshot,
              let unit = try work(service), !Task.isCancelled else { return nil }
        let cost = OtzariaReadingUnitSideCache.retainedCost(of: unit)
        return lock.withLock {
            guard generation == dbGeneration, !Task.isCancelled else { return nil }
            OtzariaReadingUnitSideCache.shared.set(unit, mode: unit.mode, cost: cost)
            return unit
        }
    }

    func withDatabase<T>(_ work: (SQLiteDatabase) throws -> T) throws -> T {
        let (db, gen) = try lock.withLock {
            let db = try requireDatabase()
            return (db, dbGeneration)
        }
        let result = try work(db)
        guard lock.withLock({ dbGeneration == gen }) else {
            throw CancellationError()
        }
        return result
    }

    func fetchCategories() throws -> [CategoryData] {
        let (db, gen) = try lock.withLock {
            let db = try requireDatabase()
            return (db, dbGeneration)
        }

        let result = try db.fetch(query: """
            SELECT id, parentId, title, level, orderIndex
            FROM category
            ORDER BY COALESCE(parentId, id), orderIndex, title
        """) { row in
            CategoryData(
                id: row.int(at: 0),
                name: row.string(at: 2) ?? "Untitled",
                level: row.int(at: 3),
                order: row.int(at: 4),
                parentId: row.isNull(at: 1) ? nil : row.int(at: 1)
            )
        }
        guard lock.withLock({ dbGeneration == gen }) else {
            throw CancellationError()
        }
        return result
    }

    func fetchAllBooks() throws -> [BooksData] {
        let (db, gen) = try lock.withLock {
            let db = try requireDatabase()
            return (db, dbGeneration)
        }
        let schema = try OtzariaBookSchemaCompatibility.projection(in: db)

        let result = try db.fetch(query: """
            SELECT b.id, b.title, b.categoryId, b.orderIndex, b.totalLines, b.heShortDesc,
                   \(schema.filePath), \(schema.fileType),
                   COALESCE((SELECT ba.authorId FROM book_author ba WHERE ba.bookId = b.id ORDER BY ba.authorId LIMIT 1), 0) AS firstAuthorId
            FROM book b
            WHERE \(schema.eligiblePredicate)
            ORDER BY b.categoryId, b.orderIndex, b.title
        """) { row -> BooksData in
            let shortDescription = row.string(at: 5) ?? ""
            let filePath = row.string(at: 6) ?? ""
            let bookId = row.int(at: 0)
            let workKey = !filePath.isEmpty ? filePath : "book:\(bookId)"
            let locator = TextLocator(backend: .otzaria, workKey: workKey, position: .legacyLine(0))
            let book = BooksData(
                id: bookId,
                book: row.string(at: 1) ?? "Untitled",
                archive: 0,
                muallif: row.int(at: 8),
                bithoqoh: shortDescription,
                info: shortDescription.isEmpty ? filePath : shortDescription,
                backendLocator: locator,
                backendSearchPath: filePath.isEmpty ? nil : filePath
            )
            book.catId = row.int(at: 2)
            book.orderIndex = row.isNull(at: 3) ? nil : row.int(at: 3)
            book.totalLines = row.isNull(at: 4) ? nil : row.int(at: 4)
            book.pdfCs = 4
            return book
        }
        guard lock.withLock({ dbGeneration == gen }) else {
            throw CancellationError()
        }
        return result
    }

    func fetchBooksGroupedByCategory() throws -> [Int: [BooksData]] {
        Dictionary(grouping: try fetchAllBooks()) { $0.catId ?? 0 }
    }

    func fetchAuthors() throws -> [(id: Int, muallif: Muallif)] {
        let (db, gen) = try lock.withLock {
            let db = try requireDatabase()
            return (db, dbGeneration)
        }

        let result = try db.fetch(query: """
            SELECT id, name
            FROM author
            ORDER BY name
        """) { row in
            (id: row.int(at: 0), muallif: Muallif(nama: row.string(at: 1) ?? "", info: "", namaLengkap: ""))
        }
        guard lock.withLock({ dbGeneration == gen }) else {
            throw CancellationError()
        }
        return result
    }

    func fetchOtzariaAuthorsWithBookCounts() throws -> [OtzariaAuthor] {
        let (db, gen) = try lock.withLock {
            let db = try requireDatabase()
            return (db, dbGeneration)
        }
        let schema = try OtzariaBookSchemaCompatibility.projection(in: db)

        let result = try db.fetch(query: """
            SELECT a.id, a.name, COUNT(DISTINCT b.id) AS bookCount
            FROM author a
            JOIN book_author ba ON ba.authorId = a.id
            JOIN book b ON b.id = ba.bookId
            WHERE \(schema.eligiblePredicate)
            GROUP BY a.id, a.name
            HAVING COUNT(DISTINCT b.id) > 0
            ORDER BY a.name, a.id
        """) { row in
            OtzariaAuthor(
                id: row.int(at: 0),
                name: row.string(at: 1) ?? "",
                bookCount: row.int(at: 2)
            )
        }
        guard lock.withLock({ dbGeneration == gen }) else {
            throw CancellationError()
        }
        return result
    }

    func fetchBooksForOtzariaAuthor(authorId: Int) throws -> [BooksData] {
        let (db, gen) = try lock.withLock {
            let db = try requireDatabase()
            return (db, dbGeneration)
        }
        let schema = try OtzariaBookSchemaCompatibility.projection(in: db)

        let result = try db.fetch(query: """
            SELECT b.id, b.title, b.categoryId, b.orderIndex, b.totalLines, b.heShortDesc,
                   \(schema.filePath), \(schema.fileType),
                   COALESCE((SELECT ba2.authorId FROM book_author ba2 WHERE ba2.bookId = b.id ORDER BY ba2.authorId LIMIT 1), 0) AS firstAuthorId
            FROM book_author ba
            JOIN book b ON b.id = ba.bookId
            WHERE ba.authorId = ?
              AND \(schema.eligiblePredicate)
            ORDER BY b.orderIndex, b.title
        """, parameters: [authorId]) { row -> BooksData in
            let shortDescription = row.string(at: 5) ?? ""
            let filePath = row.string(at: 6) ?? ""
            let bookId = row.int(at: 0)
            let workKey = !filePath.isEmpty ? filePath : "book:\(bookId)"
            let locator = TextLocator(backend: .otzaria, workKey: workKey, position: .legacyLine(0))
            let book = BooksData(
                id: bookId,
                book: row.string(at: 1) ?? "Untitled",
                archive: 0,
                muallif: row.int(at: 8),
                bithoqoh: shortDescription,
                info: shortDescription.isEmpty ? filePath : shortDescription,
                backendLocator: locator,
                backendSearchPath: filePath.isEmpty ? nil : filePath
            )
            book.catId = row.int(at: 2)
            book.orderIndex = row.isNull(at: 3) ? nil : row.int(at: 3)
            book.totalLines = row.isNull(at: 4) ? nil : row.int(at: 4)
            book.pdfCs = 4
            return book
        }
        guard lock.withLock({ dbGeneration == gen }) else {
            throw CancellationError()
        }
        return result
    }

    func fetchAuthorMapForBooks() throws -> [Int: [Muallif]] {
        lock.lock()
        defer { lock.unlock() }
        let db = try requireDatabase()

        let rows = try db.fetch(query: """
            SELECT ba.bookId, a.name
            FROM book_author ba
            JOIN author a ON a.id = ba.authorId
            ORDER BY ba.bookId, a.name
        """) { row in
            (bookId: row.int(at: 0), author: Muallif(nama: row.string(at: 1) ?? "", info: "", namaLengkap: ""))
        }

        var result: [Int: [Muallif]] = [:]
        for row in rows {
            result[row.bookId, default: []].append(row.author)
        }
        return result
    }

    func authorName(forBookId bookId: Int) -> String? {
        lock.lock()
        defer { lock.unlock() }
        guard let db = try? requireDatabase() else { return nil }
        return try? db.fetch(query: """
            SELECT a.name
            FROM book_author ba
            JOIN author a ON a.id = ba.authorId
            WHERE ba.bookId = ?
            ORDER BY a.name
            LIMIT 1
        """, parameters: [bookId]) { row in
            row.string(at: 0)
        }.first.flatMap { $0 }
    }

    func fetchBook(byId bookId: Int) throws -> BooksData? {
        lock.lock()
        defer { lock.unlock() }
        let db = try requireDatabase()
        let schema = try OtzariaBookSchemaCompatibility.projection(in: db)

        return try db.fetch(query: """
            SELECT b.id, b.title, b.categoryId, b.heShortDesc, b.orderIndex, b.totalLines,
                   \(schema.filePath),
                   COALESCE((SELECT ba.authorId FROM book_author ba WHERE ba.bookId = b.id ORDER BY ba.authorId LIMIT 1), 0) AS firstAuthorId
            FROM book b
            WHERE b.id = ?
            LIMIT 1
        """, parameters: [bookId]) { row -> BooksData in
            let shortDescription = row.string(at: 3) ?? ""
            let filePath = row.string(at: 6) ?? ""
            let workKey = !filePath.isEmpty ? filePath : "book:\(bookId)"
            let locator = TextLocator(backend: .otzaria, workKey: workKey, position: .legacyLine(0))
            let book = BooksData(
                id: row.int(at: 0),
                book: row.string(at: 1) ?? "Untitled",
                archive: 0,
                muallif: row.int(at: 7),
                bithoqoh: shortDescription,
                info: shortDescription.isEmpty ? filePath : shortDescription,
                backendLocator: locator,
                backendSearchPath: filePath.isEmpty ? nil : filePath
            )
            book.catId = row.int(at: 2)
            book.orderIndex = row.isNull(at: 4) ? nil : row.int(at: 4)
            book.totalLines = row.isNull(at: 5) ? nil : row.int(at: 5)
            book.pdfCs = 4
            return book
        }.first
    }

    func resolveBook(stableKey: String, expectedBookId: Int) throws -> BooksData? {
        let normalizedKey = stableKey.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanPath = normalizedKey.hasPrefix("/") ? String(normalizedKey.dropFirst()) : normalizedKey
        let parsedId = normalizedKey.hasPrefix("book:")
            ? Int(normalizedKey.dropFirst("book:".count))
            : Int(normalizedKey)
        let effectiveExpected = expectedBookId > 0 ? expectedBookId : parsedId

        let resolvedID: Int? = try withDatabase { database in
            let schema = try OtzariaBookSchemaCompatibility.projection(in: database)
            let rows = try database.fetch(query: """
                SELECT b.id
                FROM book b
                WHERE NULLIF(TRIM(\(schema.filePath)), '') = ?
                   OR LTRIM(NULLIF(TRIM(\(schema.filePath)), ''), '/') = ?
                   OR 'book:' || b.id = ?
                   OR b.id = ?
                LIMIT 2
            """, parameters: [normalizedKey, cleanPath, "book:\(effectiveExpected ?? -1)", effectiveExpected ?? -1]) { row in row.int(at: 0) }
            guard rows.count == 1 else { return nil }
            if let effectiveExpected, rows[0] != effectiveExpected { return nil }
            return rows[0]
        }
        guard let resolvedID else { return nil }
        return try fetchBook(byId: resolvedID)
    }

    func fetchBookInfo(for book: BooksData) {
        lock.lock()
        defer { lock.unlock() }
        guard let db = try? requireDatabase() else { return }
        guard let schema = try? OtzariaBookSchemaCompatibility.projection(in: db) else { return }

        if let info = try? db.fetch(query: """
            SELECT COALESCE(b.heShortDesc, ''), COALESCE(\(schema.filePath), ''), COALESCE(s.name, ''),
                   COALESCE(\(schema.fileType), ''), COALESCE(\(schema.volume), ''),
                   COALESCE(\(schema.pages), ''), COALESCE(b.totalLines, 0),
                   COALESCE((
                       SELECT group_concat(a.name, ', ')
                       FROM book_author ba
                       JOIN author a ON a.id = ba.authorId
                       WHERE ba.bookId = b.id
                   ), '')
            FROM book b
            LEFT JOIN source s ON s.id = b.sourceId
            WHERE b.id = ?
            LIMIT 1
        """, parameters: [book.id], mapping: { row -> (String, String) in
            let shortDescription = row.string(at: 0) ?? ""
            let filePath = row.string(at: 1) ?? ""
            let sourceName = row.string(at: 2) ?? ""
            let fileType = row.string(at: 3) ?? ""
            let volume = row.string(at: 4) ?? ""
            let pages = row.string(at: 5) ?? ""
            let totalLines = row.int(at: 6)
            let authors = row.string(at: 7) ?? ""

            var parts: [String] = []
            if !shortDescription.isEmpty { parts.append(shortDescription) }
            if !authors.isEmpty { parts.append("Authors: \(authors)") }
            if !sourceName.isEmpty { parts.append("Source: \(sourceName)") }
            if !fileType.isEmpty { parts.append("Type: \(fileType)") }
            if !volume.isEmpty { parts.append("Volume: \(volume)") }
            if !pages.isEmpty { parts.append("Pages: \(pages)") }
            if totalLines > 0 { parts.append("Lines: \(totalLines)") }
            if !filePath.isEmpty { parts.append("Path: \(filePath)") }

            return (shortDescription, parts.joined(separator: "\n"))
        }).first {
            book.bithoqoh = info.0
            book.info = info.1
        }
    }

    func bookMetadata(for bookId: Int) -> LibraryWorkMetadata? {
        workMetadata(for: bookId)
    }

    func workMetadata(for bookId: Int) -> LibraryWorkMetadata? {
        lock.lock()
        defer { lock.unlock() }
        guard let db = try? requireDatabase() else { return nil }
        guard let schema = try? OtzariaBookSchemaCompatibility.projection(in: db) else { return nil }

        return try? db.fetch(query: """
            SELECT b.title,
                   COALESCE(b.heShortDesc, ''),
                   COALESCE(\(schema.filePath), ''),
                   COALESCE(s.name, ''),
                   COALESCE(\(schema.fileType), ''),
                   COALESCE(\(schema.volume), ''),
                   COALESCE(\(schema.pages), ''),
                   COALESCE(b.totalLines, 0),
                   COALESCE((
                       SELECT group_concat(a.name, ', ')
                       FROM book_author ba
                       JOIN author a ON a.id = ba.authorId
                       WHERE ba.bookId = b.id
                   ), ''),
                   COALESCE((
                       SELECT c.title
                       FROM category c
                       WHERE c.id = b.categoryId
                   ), '')
            FROM book b
            LEFT JOIN source s ON s.id = b.sourceId
            WHERE b.id = ?
            LIMIT 1
        """, parameters: [bookId], mapping: { row -> LibraryWorkMetadata in
            let title = row.string(at: 0) ?? ""
            let shortDescription = row.string(at: 1) ?? ""
            let sourceName = row.string(at: 3) ?? ""
            let fileType = row.string(at: 4) ?? ""
            let volume = row.string(at: 5) ?? ""
            let pages = row.string(at: 6) ?? ""
            let totalLines = row.int(at: 7)
            let authorsString = row.string(at: 8) ?? ""
            let categoryName = row.string(at: 9) ?? ""

            let authorsList = authorsString.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
            var fields: [LibraryMetadataField] = []
            if !authorsString.isEmpty {
                fields.append(LibraryMetadataField(key: "authors", label: "מחבר", value: authorsString))
            }
            if !categoryName.isEmpty {
                fields.append(LibraryMetadataField(key: "category", label: "קטגוריה", value: categoryName))
            }
            if !sourceName.isEmpty {
                fields.append(LibraryMetadataField(key: "source", label: "מקור", value: sourceName))
            }
            if !volume.isEmpty {
                fields.append(LibraryMetadataField(key: "volume", label: "כרך", value: volume))
            }
            if !pages.isEmpty {
                fields.append(LibraryMetadataField(key: "pages", label: "עמודים", value: pages))
            }
            if totalLines > 0 {
                fields.append(LibraryMetadataField(key: "lines", label: "שורות", value: "\(totalLines)"))
            }
            if !fileType.isEmpty {
                fields.append(LibraryMetadataField(key: "fileType", label: "סוג קובץ", value: fileType))
            }

            return LibraryWorkMetadata(
                workKey: "book:\(bookId)",
                title: title,
                heTitle: title,
                authors: authorsList,
                description: shortDescription.isEmpty ? nil : shortDescription,
                categories: categoryName.isEmpty ? [] : [categoryName],
                factualFields: fields
            )
        }).first
    }

    func getContent(bookId: Int, contentId: Int) -> BookContent? {
        getReadingUnit(
            bookId: bookId,
            containingLineIndex: contentId,
            mode: currentReadingUnitMode
        ).map { makeBookContent(from: $0) }
    }

    func getFirstContent(bookId: Int) -> BookContent? {
        getFirstReadingUnit(bookId: bookId, mode: currentReadingUnitMode).map { makeBookContent(from: $0) }
    }

    func getNextContent(bookId: Int, after contentId: Int) -> BookContent? {
        getNextReadingUnit(bookId: bookId, afterLineIndex: contentId, mode: currentReadingUnitMode).map { makeBookContent(from: $0) }
    }

    func getPreviousContent(bookId: Int, before contentId: Int) -> BookContent? {
        getPreviousReadingUnit(bookId: bookId, beforeLineIndex: contentId, mode: currentReadingUnitMode).map { makeBookContent(from: $0) }
    }

    private func lineContent(bookId: Int, whereClause: String, parameters: [Any], orderClause: String = "") -> BookContent? {
        lock.lock()
        defer { lock.unlock() }
        guard let db = try? requireDatabase() else { return nil }
        guard let capabilities = try? OtzariaDatabaseCapabilities(database: db),
              let decoder = try? OtzariaLineContentDecoder(database: db, capabilities: capabilities) else {
            return nil
        }
        let content = OtzariaLineContentCompatibility.projection(capabilities: capabilities)

        let sql = """
            SELECT l.id, l.lineIndex, \(content.expression), l.heRef
            FROM line l \(content.join)
            WHERE l.bookId = ? AND \(whereClause)
            \(orderClause)
            LIMIT 1
        """

        var allParameters: [Any] = [bookId]
        allParameters.append(contentsOf: parameters)

        return try? db.fetch(query: sql, parameters: allParameters) { row -> BookContent in
            let lineIndex = row.int(at: 1)
            let content = try decoder.decode(row: row, at: 2).otsariaPlainText
            let ref = row.string(at: 3) ?? ""
            return BookContent(id: lineIndex, nash: content, page: lineIndex, part: 1, heRef: ref.isEmpty ? nil : ref)
        }.first
    }

    func getTOCEntries(for book: BooksData) -> [TOC] {
        lock.lock()
        defer { lock.unlock() }
        guard let db = try? requireDatabase() else { return [] }
        guard let schema = try? OtzariaTOCSchemaCompatibility.projection(in: db) else { return [] }

        return (try? db.fetch(query: """
            SELECT te.id, te.parentId, te.level, COALESCE(\(schema.resolvedLineIndex), 0) AS resolvedLineIndex, tt.text
            FROM tocEntry te
            JOIN tocText tt ON tt.id = te.textId
            LEFT JOIN line ln ON ln.id = te.lineId
            WHERE te.bookId = ?
            ORDER BY resolvedLineIndex, te.id
        """, parameters: [book.id]) { row -> TOC in
            TOC(
                bab: (row.string(at: 4) ?? "").otsariaPlainText,
                level: max(row.int(at: 2), 1),
                sub: 0,
                id: row.int(at: 3),
                parentId: row.isNull(at: 1) ? nil : row.int(at: 1),
                entryId: row.int(at: 0)
            )
        }) ?? []
    }

    func search(
        query: String,
        selectedBookIds: Set<Int>? = nil,
        offset: Int = 0,
        limit: Int? = 200,
        mode: SearchMode = .phrase,
        nearDistance: Int = 10
    ) -> [SearchResultItem] {
        lock.lock()
        defer { lock.unlock() }
        guard let db = try? requireDatabase() else { return [] }
        guard let capabilities = try? OtzariaDatabaseCapabilities(database: db),
              let decoder = try? OtzariaLineContentDecoder(database: db, capabilities: capabilities) else {
            return []
        }
        let content = OtzariaLineContentCompatibility.projection(capabilities: capabilities)

        let normalizedQuery = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalizedQuery.isEmpty else { return [] }

        let terms = FtsQueryParser.extractKeywords(query: normalizedQuery, mode: mode)
        guard !terms.isEmpty else { return [] }

        let matchQuery = FtsQueryParser.buildFtsQuery(
            query: normalizedQuery,
            mode: mode,
            nearDistance: nearDistance
        )
        guard !matchQuery.isEmpty else { return [] }
        let maxResults = limit ?? 200

        func bookFilterSQL(parameters: inout [Any]) -> String {
            guard let selectedBookIds, !selectedBookIds.isEmpty else { return "" }
            let ids = selectedBookIds.sorted()
            parameters.append(contentsOf: ids)
            return " AND l.bookId IN (" + Array(repeating: "?", count: ids.count).joined(separator: ",") + ")"
        }

        func mapRows(_ rows: [(Int, Int, Int, String, String, String)]) -> [SearchResultItem] {
            rows.map { row in
                let cleaned = row.4.otsariaPlainText
                let snippet: String
                let highlighted: NSAttributedString
                if mode == .near {
                    snippet = cleaned.snippetNear(
                        keywords: terms,
                        nearDistance: nearDistance,
                        contextLength: 60
                    )
                    highlighted = snippet.highlightedAttributedText(
                        keywords: terms,
                        nearDistance: nearDistance
                    )
                } else {
                    snippet = cleaned.snippetAround(keywords: terms, contextLength: 60)
                    highlighted = snippet.highlightedAttributedText(keywords: terms)
                }
                let locator = TextLocator(
                    backend: .otzaria,
                    workKey: "book:\(row.1)",
                    position: .legacyLine(row.2)
                )
                return SearchResultItem(
                    archive: "Otzaria",
                    tableName: "otzaria:\(row.1)",
                    bookId: row.1,
                    bookTitle: row.5,
                    page: row.2,
                    part: 1,
                    attributedText: highlighted,
                    backendLocator: locator,
                    locationDisplayText: row.3.isEmpty ? nil : row.3,
                    highlightTerms: terms
                )
            }
        }

        var ftsParameters: [Any] = [matchQuery]
        let ftsBookFilter = bookFilterSQL(parameters: &ftsParameters)
        ftsParameters.append(maxResults)
        ftsParameters.append(max(0, offset))
        let ftsSQL = """
            SELECT l.id, l.bookId, l.lineIndex, COALESCE(l.heRef, ''), \(content.expression), b.title
            FROM line_fts_with_nikud f
            JOIN line l ON l.id = f.rowid
            \(content.join)
            JOIN book b ON b.id = l.bookId
            WHERE line_fts_with_nikud MATCH ?\(ftsBookFilter)
            ORDER BY rank
            LIMIT ? OFFSET ?
        """

        if let rows = try? db.fetch(query: ftsSQL, parameters: ftsParameters, mapping: { row in
            (row.int(at: 0), row.int(at: 1), row.int(at: 2), row.string(at: 3) ?? "", try decoder.decode(row: row, at: 4), row.string(at: 5) ?? "")
        }), !rows.isEmpty {
            return mapRows(rows)
        }

        // Schema 6 stores zstd-compressed line bodies and is searched by the
        // native Otzaria index. SQL LIKE cannot inspect those blobs safely.
        guard !capabilities.hasSplitLineContent else { return [] }

        var likeParameters: [Any] = []
        let likeClauses = terms.map { term -> String in
            likeParameters.append("%\(term)%")
            return "\(content.expression) LIKE ?"
        }
        let joiner = mode == .or ? " OR " : " AND "
        let likeCondition = likeClauses.joined(separator: joiner)
        let likeBookFilter = bookFilterSQL(parameters: &likeParameters)
        likeParameters.append(maxResults)
        likeParameters.append(max(0, offset))
        let likeSQL = """
            SELECT l.id, l.bookId, l.lineIndex, COALESCE(l.heRef, ''), \(content.expression), b.title
            FROM line l \(content.join)
            JOIN book b ON b.id = l.bookId
            WHERE (\(likeCondition))\(likeBookFilter)
            ORDER BY l.bookId, l.lineIndex
            LIMIT ? OFFSET ?
        """

        let rows = (try? db.fetch(query: likeSQL, parameters: likeParameters, mapping: { row in
            (row.int(at: 0), row.int(at: 1), row.int(at: 2), row.string(at: 3) ?? "", try decoder.decode(row: row, at: 4), row.string(at: 5) ?? "")
        })) ?? []
        return mapRows(rows)
    }

    func getTotalParts(bookId: Int) -> Int { 1 }

    func getMinPage(bookId: Int) -> Int { 0 }

    func getMaxPage(bookId: Int) -> Int {
        lock.lock()
        defer { lock.unlock() }
        guard let db = try? requireDatabase() else { return 0 }
        return (try? db.fetch(query: """
            SELECT COALESCE(
                (SELECT totalLines FROM book WHERE id = ?),
                (SELECT MAX(lineIndex) + 1 FROM line WHERE bookId = ?),
                0
            )
        """, parameters: [bookId, bookId]) { row in
            row.int(at: 0)
        }.first) ?? 0
    }
}
