import os,pathlib,hashlib,json,shutil,stat,datetime,gzip
base=pathlib.Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-oracle-capacity-relocation-20261127')
raw=(base/'PLAN.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='6f71038b317ccc710dfe7d166786114faf2c629694ff614f8de210b12a2d13d8'
plan=json.loads(raw);report={'schema':'otzaria.wave3.oracle-relocation-copy.v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':hashlib.sha256(raw).hexdigest(),'status':'COPYING_NO_SOURCE_MUTATION','scopes':[]}
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def check(p,row,original=False):
 s=p.lstat()
 assert stat.S_IMODE(s.st_mode)==row['mode'] and s.st_uid==row['uid'] and s.st_gid==row['gid'] and s.st_mtime_ns==row['mtime_ns'],str(p)
 if original:assert s.st_ino==row['ino'] and s.st_dev==row['dev'] and s.st_nlink==row['nlink'],str(p)
 if row['kind']=='file':assert stat.S_ISREG(s.st_mode) and s.st_size==row['bytes'] and digest(p)==row['sha256'],str(p)
 elif row['kind']=='symlink':assert stat.S_ISLNK(s.st_mode) and os.readlink(p)==row['target'],str(p)
 else:assert stat.S_ISDIR(s.st_mode),str(p)
def relative_paths(root):
 v=[]
 for d,ds,fs in os.walk(root,followlinks=False):
  v.append(pathlib.Path(d).relative_to(root).as_posix())
  v.extend((pathlib.Path(d)/n).relative_to(root).as_posix() for n in ds if (pathlib.Path(d)/n).is_symlink())
  v.extend((pathlib.Path(d)/n).relative_to(root).as_posix() for n in fs)
 return sorted(v)
try:
 for scope in plan['scopes']:
  src=pathlib.Path(scope['source']);dst=pathlib.Path(scope['destination'])
  assert src.is_dir() and not src.is_symlink() and not dst.exists()
  assert relative_paths(src)==[x['path']for x in scope['rows']]
  for row in scope['rows']:check(src/row['path'],row,True)
  remaining=sum(x['logical_bytes'] for x in plan['scopes'] if not pathlib.Path(x['destination']).exists())
  assert shutil.disk_usage('/home/ubuntu').free-remaining-32*1024*1024>=plan['home_floor']
  shutil.copytree(src,dst,symlinks=True,copy_function=shutil.copy2)
  for row in reversed(scope['rows']):
   p=dst/row['path'];os.chown(p,row['uid'],row['gid'],follow_symlinks=False);shutil.copystat(src/row['path'],p,follow_symlinks=False)
  assert relative_paths(dst)==[x['path']for x in scope['rows']]
  attrs=[]
  for row in scope['rows']:
   a=src/row['path'];b=dst/row['path'];check(a,row,True);check(b,row)
   an=sorted(os.listxattr(a,follow_symlinks=False));bn=sorted(os.listxattr(b,follow_symlinks=False));assert an==bn,str(a)
   if an:
    for n in an:assert os.getxattr(a,n,follow_symlinks=False)==os.getxattr(b,n,follow_symlinks=False),str(a)
    attrs.append({'path':row['path'],'names':an})
  report['scopes'].append({k:v for k,v in scope.items()if k!='rows'}|{'all_source_and_copy_bytes_metadata_verified':True,'xattr_paths':attrs})
 report.update(status='ALL_COPIES_VERIFIED_ORIGINALS_UNCHANGED',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),disks={p:shutil.disk_usage(p)._asdict()for p in ['/mnt/development','/home/ubuntu']})
 b=(json.dumps(report,indent=2)+'\n').encode();p=base/'COPY_VERIFIED.json'
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 os.chown(p,1001,1001)
 with (base/'PLAN.json.gz').open('xb')as f:f.write(gzip.compress(raw,mtime=0));f.flush();os.fsync(f.fileno())
 print(json.dumps({'receipt':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'report':report}))
except BaseException as e:
 report.update(status='FAILED_SOURCE_RETAINED',error=type(e).__name__+': '+str(e))
 (base/'COPY_FAILURE.json').write_text(json.dumps(report,indent=2)+'\n')
 raise
