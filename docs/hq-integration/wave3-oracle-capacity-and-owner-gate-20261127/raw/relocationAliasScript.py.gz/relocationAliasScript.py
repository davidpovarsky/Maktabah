import os,pathlib,json,hashlib,stat,shutil,datetime,subprocess
base=pathlib.Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-oracle-capacity-relocation-20261127')
raw=(base/'PLAN.json').read_bytes();assert hashlib.sha256(raw).hexdigest()=='6f71038b317ccc710dfe7d166786114faf2c629694ff614f8de210b12a2d13d8'
cp=(base/'COPY_VERIFIED.json').read_bytes();assert hashlib.sha256(cp).hexdigest()=='40523599885378ec971b3341d6256ce1090df74932aa11b140604ad0c764d881'
plan=json.loads(raw);assert json.loads(cp)['status']=='ALL_COPIES_VERIFIED_ORIGINALS_UNCHANGED'
roots=[pathlib.Path(x['source'])for x in plan['scopes']]
def h(p):
 q=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):q.update(b)
 return q.hexdigest()
def paths(root):
 out=[]
 for d,ds,fs in os.walk(root,followlinks=False):
  out.append(pathlib.Path(d).relative_to(root).as_posix())
  out.extend((pathlib.Path(d)/n).relative_to(root).as_posix()for n in ds if(pathlib.Path(d)/n).is_symlink())
  out.extend((pathlib.Path(d)/n).relative_to(root).as_posix()for n in fs)
 return sorted(out)
for x in plan['scopes']:
 src=pathlib.Path(x['source']);dst=pathlib.Path(x['destination'])
 assert not src.is_symlink() and not dst.is_symlink()
 assert paths(src)==paths(dst)==[r['path']for r in x['rows']]
 for r in x['rows']:
  for root,original in [(src,True),(dst,False)]:
   p=root/r['path'];s=p.lstat()
   assert (stat.S_IMODE(s.st_mode),s.st_uid,s.st_gid,s.st_mtime_ns)==(r['mode'],r['uid'],r['gid'],r['mtime_ns'])
   if original:assert(s.st_dev,s.st_ino,s.st_nlink)==(r['dev'],r['ino'],r['nlink'])
   if r['kind']=='file':assert stat.S_ISREG(s.st_mode)and s.st_size==r['bytes']and h(p)==r['sha256']
   elif r['kind']=='symlink':assert stat.S_ISLNK(s.st_mode)and os.readlink(p)==r['target']
   else:assert stat.S_ISDIR(s.st_mode)
  a=src/r['path'];b=dst/r['path'];an=sorted(os.listxattr(a,follow_symlinks=False));bn=sorted(os.listxattr(b,follow_symlinks=False));assert an==bn
  for n in an:assert os.getxattr(a,n,follow_symlinks=False)==os.getxattr(b,n,follow_symlinks=False)
refs=[]
for proc in pathlib.Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:
  cmd=(proc/'cmdline').read_bytes()
  if any(str(p).encode()in cmd for p in roots):refs.append({'pid':int(proc.name),'kind':'argv','sha256':hashlib.sha256(cmd).hexdigest()})
  links=[proc/'cwd',proc/'exe']+list((proc/'fd').iterdir())
  for p in links:
   try:
    s=os.readlink(p)
    if any(s==str(r)or s.startswith(str(r)+'/')for r in roots):refs.append({'pid':int(proc.name),'kind':'open_reference','path':s})
   except(FileNotFoundError,PermissionError):pass
  maps=(proc/'maps').read_text(errors='replace')
  if any(str(p)in maps for p in roots):refs.append({'pid':int(proc.name),'kind':'mapping'})
 except(FileNotFoundError,ProcessLookupError,PermissionError):pass
assert not refs,refs
assert shutil.disk_usage('/home/ubuntu').free>=plan['home_floor']+16777216
report={'schema':'otzaria.wave3.oracle-relocation-result.v1','status':'FRESH_COPIES_VERIFIED_BEFORE_ALIAS','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':hashlib.sha256(raw).hexdigest(),'copy_sha256':hashlib.sha256(cp).hexdigest(),'fresh_all_content_metadata_xattrs_equal':True,'open_references':refs,'before':{p:shutil.disk_usage(p)._asdict()for p in ['/mnt/development','/home/ubuntu']},'scopes':[],'source_or_git_changes':False}
def save(name):
 b=(json.dumps(report,indent=2)+'\n').encode()
 with(base/name).open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
 return hashlib.sha256(b).hexdigest()
pre=save('PRE_ALIAS.json')
assert shutil.rmtree.avoids_symlink_attacks
for x in plan['scopes']:
 src=pathlib.Path(x['source']);dst=pathlib.Path(x['destination']);rootrow=next(r for r in x['rows']if r['path']=='.')
 fd=os.open(src.parent,os.O_DIRECTORY|os.O_RDONLY)
 backup=src.name+'.relocation-held-original';link=src.name+'.relocation-new-alias'
 try:
  assert not (src.parent/backup).exists()and not(src.parent/link).exists()
  s=os.stat(src.name,dir_fd=fd,follow_symlinks=False);assert(s.st_dev,s.st_ino)==(rootrow['dev'],rootrow['ino'])
  os.rename(src.name,backup,src_dir_fd=fd,dst_dir_fd=fd)
  try:
   os.symlink(str(dst),link,dir_fd=fd);os.chown(link,rootrow['uid'],rootrow['gid'],dir_fd=fd,follow_symlinks=False)
   os.rename(link,src.name,src_dir_fd=fd,dst_dir_fd=fd);os.fsync(fd)
  except BaseException:
   if not os.path.lexists(src):os.rename(backup,src.name,src_dir_fd=fd,dst_dir_fd=fd)
   raise
  assert src.is_symlink()and os.readlink(src)==str(dst)
  s=os.stat(backup,dir_fd=fd,follow_symlinks=False);assert(s.st_dev,s.st_ino)==(rootrow['dev'],rootrow['ino'])
  shutil.rmtree(backup,dir_fd=fd);os.fsync(fd)
  assert not(src.parent/backup).exists()
  assert paths(src)==[r['path']for r in x['rows']]
  report['scopes'].append({'source':str(src),'destination':str(dst),'original_path_alias_verified':True,'held_original_absent':True,'entries':x['entries'],'files':x['files'],'logical_bytes':x['logical_bytes']})
 finally:os.close(fd)
report.update(status='RELOCATED_ALL_BYTES_PRESERVED_ORIGINAL_PATHS_ACCESSIBLE',pre_alias_sha256=pre,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),after={p:shutil.disk_usage(p)._asdict()for p in ['/mnt/development','/home/ubuntu']})
report['development_floor_recovered']=report['after']['/mnt/development']['free']>=plan['development_target_floor']
report['home_floor_preserved']=report['after']['/home/ubuntu']['free']>=plan['home_floor']
digest=save('RESULT.json');print(json.dumps({'sha256':digest,'result':report}))
