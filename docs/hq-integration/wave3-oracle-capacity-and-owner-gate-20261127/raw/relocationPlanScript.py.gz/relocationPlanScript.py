import os,pathlib,stat,hashlib,json,shutil,datetime,subprocess
base=pathlib.Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-oracle-capacity-relocation-20261127')
roots=[
pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127/build/history-record-controls-20261127'),
pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-records-20261127/build/history-record-filtered-controls-20261127'),
pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-ui-contracts-20261127')]
assert not base.exists()
assert shutil.disk_usage('/home/ubuntu').free>1342177280+600*1024*1024
for p in roots:assert p.is_dir() and not p.is_symlink()
def inside(value):return any(value==str(r) or value.startswith(str(r)+'/') for r in roots)
refs=[]
for proc in pathlib.Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:
  args=(proc/'cmdline').read_bytes()
  if any(str(r).encode() in args for r in roots):refs.append({'pid':int(proc.name),'kind':'argv','argv_sha256':hashlib.sha256(args).hexdigest()})
  for d in ['cwd','exe']:
   try:
    v=os.readlink(proc/d)
    if inside(v):refs.append({'pid':int(proc.name),'kind':d,'path':v})
   except (FileNotFoundError,PermissionError):pass
  for fd in (proc/'fd').iterdir():
   try:
    v=os.readlink(fd)
    if inside(v):refs.append({'pid':int(proc.name),'kind':'fd','path':v})
   except (FileNotFoundError,PermissionError):pass
  maps=(proc/'maps').read_text(errors='replace')
  if any(str(r) in maps for r in roots):refs.append({'pid':int(proc.name),'kind':'mapping'})
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
assert not refs,refs
def scan(root):
 rows=[]
 for d,ds,fs in os.walk(root,followlinks=False):
  ds.sort();fs.sort()
  for p in [pathlib.Path(d)]+[pathlib.Path(d)/n for n in ds if (pathlib.Path(d)/n).is_symlink()]+[pathlib.Path(d)/n for n in fs]:
   s=p.lstat();row={'path':p.relative_to(root).as_posix(),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'dev':s.st_dev,'ino':s.st_ino,'nlink':s.st_nlink,'allocated':s.st_blocks*512}
   if stat.S_ISREG(s.st_mode):
    h=hashlib.sha256()
    with p.open('rb') as f:
     for b in iter(lambda:f.read(1048576),b''):h.update(b)
    after=p.lstat()
    assert (after.st_size,after.st_mtime_ns,after.st_ino)==(s.st_size,s.st_mtime_ns,s.st_ino)
    row.update(kind='file',bytes=s.st_size,sha256=h.hexdigest())
   elif stat.S_ISLNK(s.st_mode):row.update(kind='symlink',target=os.readlink(p))
   elif stat.S_ISDIR(s.st_mode):row.update(kind='directory')
   else:raise RuntimeError('Unsupported file kind '+str(p))
   rows.append(row)
 rows.sort(key=lambda x:x['path']);return rows
plans=[]
for i,root in enumerate(roots):
 rows=scan(root);files=[x for x in rows if x['kind']=='file'];links={}
 for x in files:links.setdefault((x['dev'],x['ino']),[]).append(x)
 external=[{'path':v[0]['path'],'nlink':v[0]['nlink'],'inside':len(v)} for v in links.values() if v[0]['nlink']>len(v)]
 assert not external,external[:10]
 plans.append({'source':str(root),'destination':str(base/('data-'+str(i+1))),'rows':rows,'entries':len(rows),'files':len(files),'logical_bytes':sum(x['bytes']for x in files),'allocated_bytes':sum(v[0]['allocated']for v in links.values()),'internal_hardlink_groups':len([v for v in links.values() if len(v)>1]),'external_hardlinks':external})
total=sum(x['logical_bytes'] for x in plans)
assert total<560*1024*1024
assert shutil.disk_usage('/home/ubuntu').free-total-32*1024*1024>=1342177280
pins={
'history-record-controls-20261127/cache-restoration/RESTORE_RESULT.json':'fe4547d12573b3264fa624f6f291f7fe26315d611a8f50391149be4004732894',
'history-record-controls-20261127/cache-restoration/MANIFEST.json':'77f3f6fc38e792c6c70824dcff40ca3f2893568da95256338aff016881ce35ff',
'history-record-controls-20261127/service-attempt-3/RESULT.json':'0bcb6903cbaada854cd1da972c09f9e1b3ac0361399509139a05fefa131ee9aa',
'history-record-controls-20261127/binding-attempt-1/RESULT.json':'40e35de992c7c48da73496c1477fecab3e0503a0c0a464f39b9b3b52c7f16e53',
'history-record-filtered-controls-20261127/suite-attempt-1/RESULTS.json':'f4dba5f298ff8d7f91692175fcceb4aed72a2030a287d709ac52dc18a486bead',
'history-record-filtered-controls-20261127/suite-attempt-1/candidate/RESULT.json':'30caeee351f74c4871e823e00beca761f608145a19e1fc4c3a5bb64c5f400c4a'}
for rel,expected in pins.items():
 p=roots[0].parent/rel
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,rel
result={'schema':'otzaria.wave3.oracle-relocation-plan.v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PLANNED_ONLY_NO_SOURCE_MUTATION','source_refs':refs,'home_floor':1342177280,'development_target_floor':687865856,'disks':{p:shutil.disk_usage(p)._asdict()for p in ['/mnt/development','/home/ubuntu']},'owner_release':'ui_acceptance explicitly released both generated history build subtrees; root controls old UI contracts diagnostics; no active writer/reference found','pins':pins,'scopes':plans}
base.mkdir(parents=True);os.chown(base,1001,1001)
b=(json.dumps(result,indent=2)+'\n').encode();(base/'PLAN.json').write_bytes(b);os.chown(base/'PLAN.json',1001,1001)
print(json.dumps({'plan':str(base/'PLAN.json'),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'scopes':[{k:v for k,v in x.items()if k!='rows'} for x in plans],'disks':result['disks'],'source_mutation':False}))
