import os,subprocess,json,hashlib,datetime,re,time,shutil
from pathlib import Path
r=Path(r"C:\Users\DAVID\Code\Maktabah-semantic-compound-20261120");out=r/"build"/"semantic-compound-20261120";case=out/"candidate-core-attempt3-complete-red"
case.mkdir(parents=True,exist_ok=False)
swift=Path(r"C:\Users\DAVID\AppData\Local\Programs\Swift\Toolchains\6.3.3+Asserts\usr\bin\swift.exe")
runtime=Path(r"C:\Users\DAVID\AppData\Local\Programs\Swift\Runtimes\6.3.3\usr\bin")
env=os.environ.copy();env["PATH"]=str(swift.parent)+os.pathsep+str(runtime)+os.pathsep+env.get("PATH","")
package=r/"Source"/"Otzaria"/"Actions";cache=out/"core-cache"
files=[p for p in package.rglob("*") if p.is_file() and p.suffix in [".swift",".json"] and ".build" not in p.parts]
files.append(r/"docs/hq-actions-bridge/embedded-handler-fixtures.json")
before={str(p.relative_to(r)).replace("\\","/"):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
cmd=[str(swift),"test","--package-path",str(package),"--scratch-path",str(cache),"--jobs","1","--disable-swift-testing"]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,obj):(case/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
write("INPUTS.json",{"source":"c6542e412fb5b052d182aacbea685c62bdf8440c","command":cmd,"cwd":str(r),"startedAt":now(),"sha256":before,"note":"Candidate source recorded by whole-input hashes; original Core XCTest suite plus32 fixed-journey controls and four continuation controls; Windows portable only."})
started=time.monotonic()
with (case/"test.log").open("w",encoding="utf-8") as log:
 p=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 write("PROCESS.json",{"pid":p.pid,"startedAt":now(),"command":cmd})
 try:code=p.wait(timeout=600);timeout=False
 except subprocess.TimeoutExpired:
  timeout=True;subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],stdout=subprocess.PIPE,stderr=subprocess.PIPE);code=p.wait(timeout=20)
text=(case/"test.log").read_text(encoding="utf-8",errors="replace")
cases=re.findall(r"Test Case '([^']+)' (passed|failed) \(",text)
summary={"exitCode":code,"timedOut":timeout,"endedAt":now(),"durationSeconds":time.monotonic()-started,"declaredFilter":"all original Core tests plus32 compound controls","executed":len(cases),"passed":sum(x[1]=="passed" for x in cases),"failed":sum(x[1]=="failed" for x in cases),"cases":cases,"sourceUnchanged":all(p.exists() and before[str(p.relative_to(r)).replace("\\","/")]==hashlib.sha256(p.read_bytes()).hexdigest() for p in files),"freeBytes":shutil.disk_usage(r).free,"warnings":len(re.findall(r"\bwarning:",text)),"logSHA256":hashlib.sha256((case/"test.log").read_bytes()).hexdigest()}
write("RESULT.json",summary);print(json.dumps(summary,ensure_ascii=False),flush=True);print("\n".join(line for line in text.splitlines() if ": error:" in line or " error:" in line or "Test Suite " in line or "Executed " in line)[-12000:],flush=True)
