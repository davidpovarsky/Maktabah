import os,subprocess,json,datetime,hashlib
from pathlib import Path
r=Path(r"C:\Users\DAVID\Code\Maktabah-semantic-compound-20261120")
root=r/"build/semantic-compound-20261120";out=root/"host-attempt3-projection-green"
swift=Path(r"C:\Users\DAVID\AppData\Local\Programs\Swift\Toolchains\6.3.3+Asserts\usr\bin\swiftc.exe")
runtime=Path(r"C:\Users\DAVID\AppData\Local\Programs\Swift\Runtimes\6.3.3\usr\bin")
env=os.environ.copy();env["PATH"]=str(swift.parent)+os.pathsep+str(runtime)+os.pathsep+env.get("PATH","")
cmd=["python",str(r/"tools/hq-semantic-journey-host.py"),"--repo",str(r),"--core-cache",str(root/"core-cache"),"--core-evidence",str(root/"candidate-core-attempt5-green"),"--output",str(out),"--swiftc",str(swift)]
p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,text=True,encoding="utf-8",timeout=290)
(root/"host-attempt3-projection-green-launch.log").write_text(p.stdout+p.stderr,encoding="utf-8")
print("driverExit="+str(p.returncode))
result=out/"RESULT.json"
if result.exists():
 data=json.loads(result.read_text(encoding="utf-8"));print(json.dumps({k:v for k,v in data.items() if k not in ["cases"]}));print("FAILED_CASES="+json.dumps([name for status,name in data.get("cases",[]) if status=="FAIL"]))
 if p.returncode!=0:
  for name in ["compile.log","runtime.log"]:
   path=out/name
   if path.exists():print(name+"\n"+path.read_text(encoding="utf-8",errors="replace")[-10000:])
else:print((p.stdout+p.stderr)[-10000:])
parseOut=root/"composition-projection-parse"
parseOut.mkdir(exist_ok=False)
source=r/"Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift"
sha=hashlib.sha256(source.read_bytes()).hexdigest()
parsecmd=[str(swift),"-frontend","-parse","-target","arm64-apple-ios27.0-simulator",str(source)]
q=subprocess.run(parsecmd,cwd=r,env=env,capture_output=True,text=True,encoding="utf-8",timeout=45)
(parseOut/"parse.log").write_text(q.stdout+q.stderr,encoding="utf-8")
info={"command":parsecmd,"exitCode":q.returncode,"scope":"SYNTAX_ONLY_NOT_APPLE_TYPECHECK","sourceSHA256":sha,"sourceUnchanged":sha==hashlib.sha256(source.read_bytes()).hexdigest(),"endedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"logSHA256":hashlib.sha256((parseOut/"parse.log").read_bytes()).hexdigest()}
(parseOut/"RESULT.json").write_text(json.dumps(info,indent=2)+"\n",encoding="utf-8");print(json.dumps(info));print(q.stderr[-3000:])
