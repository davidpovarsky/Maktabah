#!/usr/bin/env python3
"""Verify sealed bytes, actual XCTest/Host cases, and immutable source binding."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    repo = args.repo or root.parents[2]
    manifest = json.loads((root / "SHA256SUMS.json").read_text(encoding="utf-8"))
    for path, item in manifest.items():
        data = (root / path).read_bytes()
        assert len(data) == item["bytes"] and sha(data) == item["sha256"], path
        if item.get("rawSHA256"):
            assert sha(gzip.decompress(data)) == item["rawSHA256"], path + " uncompressed"
    evidence = json.loads((root / "EVIDENCE.json").read_text(encoding="utf-8"))

    def read(path):
        return gzip.decompress((root / "raw" / (path + ".gz")).read_bytes())

    for attempt in evidence["coreAttempts"]:
        result = json.loads(read(attempt["name"] + "/RESULT.json"))
        text = read(attempt["name"] + "/test.log").decode("utf-8", errors="replace")
        actual = re.findall(r"Test Case '([^']+)' (passed|failed) \(", text)
        assert actual == [tuple(x) for x in result["cases"]], attempt["name"]
        assert len(actual) == attempt["completed"] == result["executed"]
        assert sum(x[1] == "passed" for x in actual) == attempt["passed"] == result["passed"]
        assert sum(x[1] == "failed" for x in actual) == attempt["failedCompleted"] == result["failed"]
        assert result["sourceUnchanged"] and not result["timedOut"]
        assert sha(read(attempt["name"] + "/test.log")) == result["logSHA256"]
    green = json.loads(read("candidate-core-attempt5-green/RESULT.json"))
    assert green["exitCode"] == 0 and green["executed"] == green["passed"] == 174
    assert len({x[0] for x in green["cases"]}) == 174
    preservation = json.loads(read("PRESERVATION.json"))
    assert len(preservation["originalCaseNames"]) == 137
    assert set(preservation["originalCaseNames"]) <= {x[0] for x in green["cases"] if x[1] == "passed"}
    red = json.loads(read("candidate-core-attempt4-lifetime-red/RESULT.json"))
    assert {x[0] for x in red["cases"] if x[1] == "failed"} == set(evidence["lifetimeRedCases"])
    host = json.loads(read("host-attempt1/RESULT.json"))
    host_text = read("host-attempt1/runtime.log").decode("utf-8")
    host_cases = re.findall(r"^(PASS|FAIL) ([A-Za-z0-9_]+)(?: .*)?$", host_text, re.M)
    assert host_cases == [tuple(x) for x in host["cases"]]
    assert host["success"] and host["sourceUnchanged"] and host["caseInventoryExact"]
    assert len(host_cases) == host["passed"] == 40 and all(x[0] == "PASS" for x in host_cases)
    assert sha(read("host-attempt1/runtime.log")) == host["runtime"]["logSHA256"]
    source = json.loads(read("SOURCE_BINDING.json"))
    for path, item in source["inputs"].items():
        blob = subprocess.check_output(["git", "show", evidence["sourceCommit"] + ":" + path], cwd=repo)
        assert sha(blob) == item["gitBlobSHA256"], path
        assert item["normalizedWorkingBytesEqualGitBlob"], path
    assert evidence["nativeCompound"] == evidence["appleTypecheck"] == "NOT_RUN"
    print(json.dumps({"status": "PASS_EVIDENCE_VERIFICATION_ONLY", "sourceCommit": evidence["sourceCommit"],
                      "sealedFiles": len(manifest), "corePassed": 174, "originalCorePreserved": 137,
                      "hostPassed": 40, "nativeCompound": "NOT_RUN", "appleTypecheck": "NOT_RUN"}, indent=2))


if __name__ == "__main__":
    main()
