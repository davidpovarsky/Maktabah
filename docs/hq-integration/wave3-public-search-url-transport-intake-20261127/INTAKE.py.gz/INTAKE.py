import base64,gzip,hashlib,json,pathlib,shutil,subprocess,traceback

ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be'
DONOR='a4ed8f199091f00f7ade3c51ae93badefa5ba487';PARENT='a27694faab405399b9c99c3b76074d70ecc1b7c0'
D='docs/ui-routing/wave3-public-search-url-transport-20261127'
PROOF='docs/hq-integration/wave3-public-search-url-transport-intake-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127';RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest();events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,r):assert len(b)==r['bytes']and sha(b)==r['sha256'],r['path']

try:
 assert rev('HEAD')==BASE and not git('status','--porcelain')and shutil.disk_usage(ROOT).free>=1342177280
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head','/home/ubuntu/.codex/worktrees/Maktabah-wave3-public-search-entry-20261127',DONOR)
 assert rev(DONOR+'^')==PARENT
 paths=git('diff-tree','--no-commit-id','--name-only','-r',DONOR).decode().splitlines();assert len(paths)==11
 raw=show(DONOR,D+'/ARTIFACTS.json');assert sha(raw)=='0038fbf48e5080a258f3bc1697cfdb55125dcfb481e2f4032fecadb0f31b8c9d'
 manifest=json.loads(raw);assert len(manifest['files'])==10
 assert set(paths)=={r['path']for r in manifest['files']}|{D+'/ARTIFACTS.json'}
 for row in manifest['files']:pin(show(DONOR,row['path']),row)
 assert manifest['actualNewTests']==8 and manifest['unchangedOriginalTests']==18 and manifest['baselineFailures']==6 and manifest['nativeRuns']==0
 driver='Scripts/CI/runtime27-url-delivery.py';old_tests='Scripts/CI/test-runtime27-url-delivery.py';new_tests='Scripts/CI/test-runtime27-public-search-url-delivery.py'
 before=show(BASE,driver);after=show(DONOR,driver)
 assert len(before)==6244 and sha(before)=='b2abff73996b5e01bcd73aa4057438c014f8ee7e42214b63476711d947590a80'
 assert before==show(PARENT,driver)
 replacements=[
  (r'|v2/native\.search\.(?:result|nextPage)', ''),
  (r'(?:history|library|search\.(?:result|nextPage))', r'(?:history|library)')]
 inverse=after.decode()
 for addition,original in replacements:
  assert inverse.count(addition)==1;inverse=inverse.replace(addition,original)
 assert inverse.encode()==before
 assert len(before.splitlines())==len(after.splitlines())and sum(a!=b for a,b in zip(before.splitlines(),after.splitlines()))==2
 assert show(BASE,old_tests)==show(DONOR,old_tests)and sha(show(BASE,old_tests))=='4469d13c99c4591dc810880e2ee7c0da714a21537dcbe922ea379b9a53efb723'
 assert not git('ls-tree',BASE,'--',new_tests)
 packed=show(DONOR,D+'/RAW_CONTROLS.json.gz');index=json.loads(show(DONOR,D+'/RAW_CONTROLS.json.gz.manifest.json'))
 assert len(packed)==index['gzipBytes']and sha(packed)==index['gzipSHA256']
 raw=gzip.decompress(packed);assert len(raw)==index['rawBytes']and sha(raw)==index['rawSHA256']
 capsule=json.loads(raw);assert len(capsule['files'])==len(index['files'])==13
 expected={r['path']:r for r in index['files']};assert len(expected)==13
 decoded={}
 for row in capsule['files']:
  b=base64.b64decode(row['base64'],validate=True);pin(b,row);pin(b,expected[row['path']]);decoded[row['path']]=b
 for path in [driver,old_tests,new_tests]:
  assert decoded['candidate/'+path]==show(DONOR,path)
  assert decoded['baseline/'+path]==(show(BASE,path)if path!=new_tests else show(DONOR,path))
 assert decoded['evidence/RESULT.json']==show(DONOR,D+'/RESULT.json')
 result=json.loads(decoded['evidence/RESULT.json']);assert [s['exit']for s in result['steps']]==[1,0,0]
 assert result['sourceChangedLines']==2 and result['oldTestsUnchanged']is True and result['nativeRuns']==0
 for step in result['steps']:
  for suffix in ['stdout','stderr']:assert sha(decoded['evidence/'+step['label']+'.'+suffix])==step[suffix]
 assert b'Ran 8 tests' in decoded['evidence/candidate-test-runtime27-public-search-url-delivery.stderr']
 assert decoded['evidence/candidate-test-runtime27-public-search-url-delivery.stderr'].endswith(b'OK\n')
 assert b'Ran 18 tests' in decoded['evidence/candidate-test-runtime27-url-delivery.stderr']
 assert decoded['evidence/candidate-test-runtime27-url-delivery.stderr'].endswith(b'OK\n')
 assert b'FAILED (failures=6)' in decoded['evidence/baseline-test-runtime27-public-search-url-delivery.stderr']
 protected=['Source','Vendor','Maktabah.xcodeproj','Maktabah-iOSUITests','.github','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected}
 for p in protected:assert rev(DONOR+':'+p)==rev(PARENT+':'+p)
 git('diff','--check',PARENT,DONOR)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',DONOR)
 intake=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 report={'schema':'otzaria.wave3.finite-public-search-transport-intake.v1','base':BASE,'donor':DONOR,'intake':intake,'commitPaths':11,'artifactRows':10,'rawFilesVerified':13,
  'driverBeforeSHA256':sha(before),'driverAfterSHA256':sha(after),'changedLines':2,'wholeDriverInverseExact':True,'originalTestsByteExact':True,
  'reusedActualPythonSourceControls':{'newPassed':8,'originalPassed':18,'originalNewSuiteFailures':6},'subprocessAndOSDelivery':'Explicit double; no native delivery',
  'oldGuardsPreserved':'Original token, nonce, simulator, age, size/budget, exact origin/path, argv, timeout, schema and redaction unchanged.',
  'protectedTrees':trees,'nativeRuns':0,'AppleSDK':'NOT_RUN','production':'NOT_RUN'}
 dump(proof/'RESULT.json',report)
 (proof/'README.md').write_text('# Finite public Search transport prerequisite\n\nThe exact two-line original-driver addition permits only native.search.result and native.search.nextPage in v2 on the existing debug scheme and verified HTTPS origin. Its exact inverse restores all6244 original bytes. No app parser, Core permission, source owner, old assertion or other request guard changed.\n\nAll11 commit paths,10 manifest rows and13 lossless raw files were independently joined. The actual Python run passed eight new and eighteen unchanged original controls, with six original-source assertion failures preserved. The subprocess/system delivery is an explicit double; this supplies a prerequisite for the separate eight native selectors, not native or Universal Link acceptance.\n')
 git('add','--sparse','--',PROOF)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record finite public Search URL transport source admission')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'intake':intake,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'freeBytes':shutil.disk_usage(ROOT).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
