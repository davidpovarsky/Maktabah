import gzip,hashlib,json,pathlib,shutil,subprocess,traceback

ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='aee6fdd1cd635323f6a773f6559a9d0bf717f6b4'
BRANCH='codex/otzaria-wave3-integration-20261127'
PROOF='docs/hq-integration/wave3-history-capacity-evidence-intake-20261127'
RUN=pathlib.Path(__file__).parent
ITEMS=[
 ('9b69c8c06826ad64c5802d8587bd21ff91fbac4e','a65cc9b3b1f802d3fe4b9e0bd57b9e073109d28f','docs/ui-routing/wave3-history-composition-control-20261127','493cc2e2ac542d761520e3f0b6971f6213931cd7e2d4092824f449a383a2c4e6',9),
 ('279b5f62674ccc1cb54a48f6a0ba04b34b267e55','a7be0e1fbe915a385c698acaef50b34cbc4b0986','docs/hq-integration/wave3-runner-capacity-readonly-20261127','8ab4e67509844fdf427cfd045b968edb32ef600091e9ccdfc6c89af5b3f562f7',11),
 ('1b6d6408413afe2b8731d80f6424c69fe6c36741','279b5f62674ccc1cb54a48f6a0ba04b34b267e55','docs/hq-integration/wave3-held-symbol-compact-closure-20261127','afa2a019eecf688fde084e1668d5ab7692ca52919f52a2b6d2916bcd95c16011',28),
]
events=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 row={'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')}
 if len(p.stdout)<4096 and a[0]not in ['show','cat-file']:row['stdout']=p.stdout.decode(errors='replace')
 events.append(row);dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure: '+repr(a))
 return p.stdout
def rev(ref):return git('rev-parse',ref).decode().strip()
def show(ref,path):return git('show',ref+':'+path)

try:
 assert rev('HEAD')==BASE and git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 assert not git('status','--porcelain') and shutil.disk_usage(ROOT).free>=1342177280
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 protected=['Source','Vendor','Maktabah.xcodeproj','Maktabah-iOSUITests','Scripts/CI','.github','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected};all_paths=[];deliveries=[]
 for ref,parent,d,expected,count in ITEMS:
  assert rev(ref+'^')==parent
  paths=git('diff-tree','--no-commit-id','--name-only','-r',ref).decode().splitlines()
  assert len(paths)==count and all(p.startswith(d+'/')for p in paths)
  raw=show(ref,d+'/ARTIFACTS.json');assert sha(raw)==expected
  records=json.loads(raw)['files'];assert len(records)==count-1
  assert set(paths)=={d+'/'+r['path']for r in records}|{d+'/ARTIFACTS.json'}
  for row in records:
   b=show(ref,d+'/'+row['path']);assert len(b)==row['bytes']and sha(b)==row['sha256']
   assert git('ls-tree',ref,'--',d+'/'+row['path']).decode().startswith('100644 blob ')
  for p in protected:assert rev(ref+':'+p)==rev(parent+':'+p)
  git('diff','--check',parent,ref)
  deliveries.append({'donor':ref,'parent':parent,'path':d,'commitPaths':count,'artifactRows':len(records),'artifactsSHA256':expected})
  all_paths+=paths
 ref,_,d,_,_=ITEMS[0]
 e=json.loads(show(ref,d+'/EVIDENCE.json'));packed=show(ref,d+'/evidence.json.gz')
 assert len(packed)==e['gzipBytes']and sha(packed)==e['gzipSHA256']
 raw=gzip.decompress(packed);assert len(raw)==e['bytes']and sha(raw)==e['sha256']
 capsule=json.loads(raw);files=capsule['files'];assert len(files)==len(e['files'])==31
 index={f['path']:f for f in e['files']};assert len(index)==31
 for f in files:
  b=f['text'].encode();row=index[f['path']]
  assert len(b)==row['bytes']==f['bytes']and sha(b)==row['sha256']==f['sha256']
 assert e['resultSHA256']=='ff86706f76b180b1552159def78a1e95c9a688c72415e70a422630373a72555d'
 assert index['RESULT.json']['sha256']==e['resultSHA256']
 ref,_,d,_,_=ITEMS[2]
 capacity=json.loads(show(ref,d+'/RESULT.json'))
 assert all(capacity[k]==0 for k in ['mac_writes','deletions','process_signals','builds','native_runs','held_executable_payload_bytes_read'])
 assert capacity['complete_preservation_performed']is False and capacity['retirement_authorized']is False
 observations=[]
 for row in capacity['observations']:
  packed=show(ref,d+'/'+row['gzip_path']);assert len(packed)==row['gzip_bytes']and sha(packed)==row['gzip_sha256']
  raw=gzip.decompress(packed);assert len(raw)==row['raw_bytes']and sha(raw)==row['raw_sha256']
  original=pathlib.Path(row['original_path']);assert original.read_bytes()==raw
  transport=json.loads(show(ref,d+'/evidence/'+row['label']+'_TRANSPORT.json'))
  assert transport['output']['bytes']==row['raw_bytes']and transport['output']['sha256']==row['raw_sha256']
  assert transport['exit']==0 and transport['mac_writes']==0
  observations.append({'label':row['label'],'bytes':len(raw),'sha256':sha(raw),'rejoinedActualOriginalReceipt':True})
 assert len(observations)==7 and len(all_paths)==48
 for ref,parent,d,expected,count in ITEMS:
  git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',ref)
  next(r for r in deliveries if r['donor']==ref)['integrated']=rev('HEAD')
 assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 result={'schema':'otzaria.wave3.history-capacity-evidence-intake.v1','base':BASE,'deliveries':deliveries,
  'commitPaths':48,'artifactRows':45,'historyCapsuleMembers':31,'historyMethodControls':{'candidatePassed':16,'candidateFailed':0,'initialPassed':8,'initialFailed':8,'resultSHA256':e['resultSHA256']},
  'capacityOriginalReceipts':observations,'protectedTreesUnchanged':trees,'macActions':0,
  'capacityConclusion':'No adequate safe reclaim established; whole compact root has external common-Git consumers. No deletion or process action authorized by this evidence.',
  'newSharedHistoryWiring':'PENDING_ROOT_SOURCE_INTAKE','AppleSDK':'NOT_RUN','native':'NOT_RUN','release':'OPEN'}
 dump(proof/'RESULT.json',result)
 (proof/'README.md').write_text('# History method and original Mac capacity evidence intake\n\nThree documentation-only handoffs were individually cherry-picked after48-path,45-artifact and unchanged-source verification. The31-member History capsule preserves both actual compiles and16/16 candidate controls versus8/16 initial controls; the original generic-open/app/window interfaces are explicit fixtures, so no Core execution or native acceptance is claimed. The exact method bytes were joined to the separate combined source proposal.\n\nThe seven capacity observations were losslessly decompressed and compared with their original Oracle receipts. They are read-only Mac metadata and original build receipts: no process signal, payload read, deletion, build or capacity-reclaim claim. The compact root still supplies the common Git store for two external worktrees; its raw allocated bytes are not a safe cleanup budget. All original packaging failures remain included.\n')
 git('add','--sparse','--',PROOF)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Preserve verified History method and Mac capacity evidence')
 head=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 assert git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'deliveries':deliveries,'sourceTree':trees['Source'],'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'freeBytes':shutil.disk_usage(ROOT).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
