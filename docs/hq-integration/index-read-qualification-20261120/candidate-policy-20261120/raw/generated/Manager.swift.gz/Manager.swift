import Foundation
final class OtzariaSearchIndexManager: @unchecked Sendable {
// Included inside the fixture manager; actual methods are extracted separately.
static let shared = OtzariaSearchIndexManager()
var indexRootURL: URL { FixtureWorld.root.appendingPathComponent("indexes") }
func indexURL(for path: String) -> URL { indexRootURL.appendingPathComponent("managed-library") }
func buildingIndexURL(for path: String) -> URL { indexURL(for: path).appendingPathExtension("building") }
func previousIndexURL(for path: String) -> URL { indexURL(for: path).appendingPathExtension("previous") }
func sentinelURL(for path: String) -> URL { indexRootURL.appendingPathComponent("building-sentinel") }
func identityURL(indexURL: URL) -> URL { indexURL.appendingPathComponent("otzaria_search_identity.json") }
func checkpointURL(indexURL: URL) -> URL { indexURL.appendingPathComponent("checkpoint.json") }
func semanticArtifactURL(for path: String) -> URL { indexRootURL.appendingPathComponent("semantic.json") }
func preflightStorage(databasePath: String) throws {}
func semanticCorpusIdentity(database: OtzariaIndexFingerprint, catalogueHash: String) -> String { "fixture" }
func decode<T: Decodable>(_ type: T.Type, at url: URL) -> T? {
    guard let data = try? Data(contentsOf: url) else { return nil }
    return try? JSONDecoder().decode(type, from: data)
}
func atomicWrite<T: Encodable>(_ value: T, to url: URL) throws {
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.sortedKeys]
    try encoder.encode(value).write(to: url, options: .atomic)
    FixtureWorld.writes += 1
}
func fixtureCanSeed(from url: URL, identity: OtzariaIndexBuildIdentity) -> Bool {
    canSeedBuildingIndex(from: url, for: identity)
}
    func currentFingerprint(databasePath: String) throws -> OtzariaIndexFingerprint {
        let url = URL(fileURLWithPath: databasePath)
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
        return OtzariaIndexFingerprint(
            databasePath: databasePath,
            fileSize: UInt64(values.fileSize ?? 0),
            modificationTime: values.contentModificationDate?.timeIntervalSince1970 ?? 0
        )
    }
    func makeIdentity(databasePath: String, catalogueHash: String) throws -> OtzariaIndexBuildIdentity {
        let build = try OtzariaSearchEngineBridge.buildInfo()
        let fingerprint = try currentFingerprint(databasePath: databasePath)
        let semantic = decode(
            OtzariaSemanticArtifactIdentity.self,
            at: semanticArtifactURL(for: databasePath)
        )
        let expectedCorpus = semanticCorpusIdentity(database: fingerprint, catalogueHash: catalogueHash)
        let validatedSemantic = semantic.flatMap {
            build.semanticEnabled
                && $0.sidecarRevision == build.semanticSidecarRevision
                && $0.corpusIdentity == expectedCorpus ? $0 : nil
        }
        return OtzariaIndexBuildIdentity(
            database: fingerprint,
            upstreamCommit: build.upstreamCommit,
            engineVersion: build.engineVersion,
            indexSchemaVersion: build.indexSchemaVersion,
            defaultGenerationOrder: build.defaultGenerationOrder,
            adapterVersion: build.adapterVersion,
            resourceHashes: build.resourceHashes,
            catalogueHash: catalogueHash,
            semanticArtifactIdentity: validatedSemantic
        )
    }
    func storedIdentity(indexURL: URL) -> OtzariaIndexBuildIdentity? {
        decode(OtzariaIndexBuildIdentity.self, at: identityURL(indexURL: indexURL))
    }
    func writeIdentity(_ identity: OtzariaIndexBuildIdentity, indexURL: URL) throws {
        let publishesActive = indexURL == self.indexURL(for: identity.database.databasePath)
        if publishesActive { OtzariaTantivySearchRepository.shared.invalidate(databasePath: identity.database.databasePath) }
        defer { if publishesActive { OtzariaTantivySearchRepository.shared.invalidate(databasePath: identity.database.databasePath) } }
        try atomicWrite(identity, to: identityURL(indexURL: indexURL))
    }
    func checkpoint(indexURL: URL) -> OtzariaIndexCheckpoint? {
        decode(OtzariaIndexCheckpoint.self, at: checkpointURL(indexURL: indexURL))
    }
    func writeCheckpoint(_ checkpoint: OtzariaIndexCheckpoint, indexURL: URL) throws {
        try atomicWrite(checkpoint, to: checkpointURL(indexURL: indexURL))
    }
    func prepareOrResumeBuildingIndex(
        databasePath: String,
        identity: OtzariaIndexBuildIdentity
    ) throws -> (url: URL, checkpoint: OtzariaIndexCheckpoint?) {
        let fileManager = FileManager.default
        let buildingURL = buildingIndexURL(for: databasePath)
        try fileManager.createDirectory(at: indexRootURL, withIntermediateDirectories: true)

        if fileManager.fileExists(atPath: buildingURL.path) {
            let checkpoint = checkpoint(indexURL: buildingURL)
            let storedIdentity = storedIdentity(indexURL: buildingURL) ?? checkpoint?.identity
            let compatibility = try? OtzariaSearchEngineBridge.checkCompatibility(indexURL: buildingURL)
            let canResume = storedIdentity == identity
                && checkpoint?.identity == identity
                && compatibility?.compatible == true
            if canResume {
                try preflightStorage(databasePath: databasePath)
                try Data(databasePath.utf8).write(to: sentinelURL(for: databasePath), options: .atomic)
                return (buildingURL, checkpoint)
            }

            // Exact targets were resolved above: only an incompatible or
            // identity-mismatched replacement build is discarded.
            try fileManager.removeItem(at: buildingURL)
        }

        try preflightStorage(databasePath: databasePath)

        let finalURL = indexURL(for: databasePath)
        if canSeedBuildingIndex(from: finalURL, for: identity) {
            do {
                try fileManager.copyItem(at: finalURL, to: buildingURL)
                try? fileManager.removeItem(at: checkpointURL(indexURL: buildingURL))
                OtzariaIndexFileLogger.log("incremental build seeded from compatible final index")
            } catch {
                if fileManager.fileExists(atPath: buildingURL.path) {
                    try? fileManager.removeItem(at: buildingURL)
                }
                try fileManager.createDirectory(at: buildingURL, withIntermediateDirectories: true)
                OtzariaIndexFileLogger.logError("incremental seed failed; starting empty build", error: error)
            }
        } else {
            try fileManager.createDirectory(at: buildingURL, withIntermediateDirectories: true)
        }
        try writeIdentity(identity, indexURL: buildingURL)
        try Data(databasePath.utf8).write(to: sentinelURL(for: databasePath), options: .atomic)
        return (buildingURL, nil)
    }
    func validateCurrentIndex(databasePath: String) throws -> UInt64 {
        if OtzariaDatabaseAccessController.shared.source == .managedInternal {
            do { _ = try recoverTrustedManagedIndex(databasePath: databasePath) }
            catch { OtzariaIndexFileLogger.logError("managed identity recovery failed", error: error) }
        }
        let finalURL = indexURL(for: databasePath)
        let currentBuild = try OtzariaSearchEngineBridge.buildInfo()
        let registeredSemantic = decode(
            OtzariaSemanticArtifactIdentity.self,
            at: semanticArtifactURL(for: databasePath)
        ).flatMap {
            currentBuild.semanticEnabled && $0.sidecarRevision == currentBuild.semanticSidecarRevision ? $0 : nil
        }
        let managed = OtzariaDatabaseAccessController.shared.source == .managedInternal
        guard FileManager.default.fileExists(atPath: finalURL.path) else {
            throw OtzariaSearchError.invalidEngineResponse("תיקיית אינדקס אוצריא אינה קיימת.")
        }
        guard let identity = storedIdentity(indexURL: finalURL) else {
            throw OtzariaSearchError.invalidEngineResponse("קובץ הזהות המשני של האינדקס חסר או אינו קריא; נתוני הספרים לא השתנו.")
        }
        let currentDatabase = try currentFingerprint(databasePath: databasePath)
        let trustedManifest = managed && identity.upstreamCommit != currentBuild.upstreamCommit
            ? trustedManagedReadManifest(indexURL: finalURL, databasePath: databasePath, build: currentBuild)
            : nil
        guard (managed
                  ? OtzariaSearchArtifactPolicy.managedIdentityMatchesCanonicalData(
                      identity,
                      currentDatabase: currentDatabase,
                      build: currentBuild,
                      trustedManifest: trustedManifest
                    )
                  : identity.database == currentDatabase
                      && identity.upstreamCommit == currentBuild.upstreamCommit
                      && identity.engineVersion == currentBuild.engineVersion
                      && identity.indexSchemaVersion == currentBuild.indexSchemaVersion
                      && identity.defaultGenerationOrder == currentBuild.defaultGenerationOrder
                      && identity.adapterVersion == currentBuild.adapterVersion
                      && identity.resourceHashes == currentBuild.resourceHashes),
              (managed || identity.semanticArtifactIdentity == registeredSemantic) else {
            throw OtzariaSearchError.invalidEngineResponse("זהות האינדקס אינה תואמת למסד, למנוע או למשאבים הפעילים.")
        }
        let compatibility = try OtzariaSearchEngineBridge.checkCompatibility(indexURL: finalURL)
        guard compatibility.compatible else {
            throw OtzariaSearchError.invalidEngineResponse(compatibility.reason ?? compatibility.status)
        }
        let engine = try OtzariaSearchEngineBridge(indexURL: finalURL)
        defer { engine.close() }
        return try engine.documentCount()
    }
    func recoverTrustedManagedIndex(databasePath: String) throws -> UInt64? {
        guard OtzariaDatabaseAccessController.shared.source == .managedInternal else { return nil }
        let profileID = OtzariaDataProfileRegistry.activeProfileID
        return try ITorahStorageLock.withLock(name: "otzaria-search-mutation-\(profileID)") {
            let fileManager = FileManager.default
            try fileManager.createDirectory(at: indexRootURL, withIntermediateDirectories: true)
            let target = indexURL(for: databasePath)
            var candidates: [URL] = []
            if fileManager.fileExists(atPath: target.path) { candidates.append(target) }
            if let children = try? fileManager.contentsOfDirectory(
                at: indexRootURL,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles]
            ) {
                candidates += children.filter { candidate in
                    candidate != target
                        && !candidate.lastPathComponent.hasSuffix(".building")
                        && !candidate.lastPathComponent.hasSuffix(".installing")
                        && !candidate.lastPathComponent.hasSuffix(".previous")
                        && fileManager.fileExists(
                            atPath: candidate.appendingPathComponent("otzaria_prebuilt_installation.json").path
                        )
                }
            }

            let databaseStorage = try OtzariaDatabaseStorage()
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let databaseManifest = try decoder.decode(
                OtzariaDatabaseInstallationManifest.self,
                from: Data(contentsOf: databaseStorage.installationManifestURL)
            )
            let databaseBytes = Int64(try currentFingerprint(databasePath: databasePath).fileSize)
            let build = try OtzariaSearchEngineBridge.buildInfo()

            for candidate in candidates {
                let trustedURL = candidate.appendingPathComponent("otzaria_prebuilt_installation.json")
                guard let data = try? Data(contentsOf: trustedURL),
                      let manifest = try? JSONDecoder().decode(OtzariaSearchArtifactManifest.self, from: data),
                      (try? OtzariaSearchArtifactPolicy.validate(
                        manifest,
                        database: databaseManifest,
                        databaseBytes: databaseBytes,
                        build: build
                      )) != nil,
                      let compatibility = try? OtzariaSearchEngineBridge.checkCompatibility(indexURL: candidate),
                      compatibility.compatible else { continue }

                let engine = try OtzariaSearchEngineBridge(indexURL: candidate)
                let count: UInt64
                do { count = try engine.documentCount() } catch { engine.close(); continue }
                engine.close()
                guard count == manifest.lexicalArtifact.documentCount else { continue }

                if candidate != target {
                    guard !fileManager.fileExists(atPath: target.path) else { continue }
                    OtzariaTantivySearchRepository.shared.invalidate(databasePath: databasePath)
                    try fileManager.moveItem(at: candidate, to: target)
                    OtzariaTantivySearchRepository.shared.invalidate(databasePath: databasePath)
                }
                let repaired = try OtzariaSearchArtifactPolicy.artifactProducerIdentity(
                    manifest: manifest,
                    database: try currentFingerprint(databasePath: databasePath),
                    requiredResourceNames: Set(build.resourceHashes.keys)
                )
                if storedIdentity(indexURL: target) != repaired {
                    try writeIdentity(repaired, indexURL: target)
                    OtzariaIndexFileLogger.log(
                        "repaired trusted managed index identity artifact=\(manifest.artifactIdentity)"
                    )
                }
                return count
            }
            return nil
        }
    }
    private func canSeedBuildingIndex(from finalURL: URL, for identity: OtzariaIndexBuildIdentity) -> Bool {
        guard FileManager.default.fileExists(atPath: finalURL.path),
              let stored = storedIdentity(indexURL: finalURL),
              stored.upstreamCommit == identity.upstreamCommit,
              stored.engineVersion == identity.engineVersion,
              stored.indexSchemaVersion == identity.indexSchemaVersion,
              stored.defaultGenerationOrder == identity.defaultGenerationOrder,
              stored.adapterVersion == identity.adapterVersion,
              stored.resourceHashes == identity.resourceHashes,
              stored.semanticArtifactIdentity == identity.semanticArtifactIdentity,
              let compatibility = try? OtzariaSearchEngineBridge.checkCompatibility(indexURL: finalURL),
              compatibility.compatible else { return false }
        return true
    }
    func trustedManagedReadManifest(
        indexURL: URL,
        databasePath: String,
        build: OtzariaSearchEngineBuildInfo
    ) -> OtzariaSearchArtifactManifest? {
        guard OtzariaDatabaseAccessController.shared.source == .managedInternal else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        guard let storage = try? OtzariaDatabaseStorage(),
              let databaseData = try? Data(contentsOf: storage.installationManifestURL),
              let database = try? decoder.decode(OtzariaDatabaseInstallationManifest.self, from: databaseData),
              let fingerprint = try? currentFingerprint(databasePath: databasePath),
              let data = try? Data(contentsOf: indexURL.appendingPathComponent("otzaria_prebuilt_installation.json")),
              let manifest = try? JSONDecoder().decode(OtzariaSearchArtifactManifest.self, from: data),
              (try? OtzariaSearchArtifactPolicy.validate(
                  manifest, database: database, databaseBytes: Int64(fingerprint.fileSize), build: build
              )) != nil else { return nil }
        return manifest
    }
}
