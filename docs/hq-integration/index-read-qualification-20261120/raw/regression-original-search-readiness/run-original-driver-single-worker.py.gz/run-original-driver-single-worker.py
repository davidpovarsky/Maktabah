import hashlib,json,pathlib,runpy,subprocess,sys,time
ROOT=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-index-read-compatibility-20261120")
OUT=pathlib.Path(sys.argv[1])
OUT.mkdir(parents=True,exist_ok=True)
driver=ROOT/"tools/hq-search-tests.py"
original_run=subprocess.run
sequence=0
def run(args,*pos,**kwargs):
    global sequence
    original_args=list(args) if isinstance(args,(list,tuple)) else args
    actual=list(args) if isinstance(args,(list,tuple)) else args
    is_compile=isinstance(actual,list) and pathlib.Path(str(actual[0])).name.lower() in ("swiftc","swiftc.exe") and "--version" not in actual
    if is_compile:
        assert "-j" not in actual
        actual[1:1]=["-j","1"]
    sequence+=1
    record={"sequence":sequence,"originalArgs":[str(a) for a in original_args],"actualArgs":[str(a) for a in actual],"cwd":str(kwargs.get("cwd","")),"onlySchedulingChanged":is_compile,"sourceSHA256":{}}
    if is_compile:
        for a in actual[1:]:
            p=pathlib.Path(str(a))
            if p.suffix==".swift" and p.is_file():
                record["sourceSHA256"][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
    path=OUT/("command-%02d.json"%sequence)
    path.write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
    started=time.monotonic()
    result=original_run(actual,*pos,**kwargs)
    record["exit"]=result.returncode
    record["seconds"]=round(time.monotonic()-started,3)
    path.write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
    return result
subprocess.run=run
sys.argv=[str(driver)]
print("Original driver SHA256: "+hashlib.sha256(driver.read_bytes()).hexdigest(),flush=True)
print("Only execution scheduling override: swiftc -j 1; no source, fixture, assertion or branch change",flush=True)
runpy.run_path(str(driver),run_name="__main__")
