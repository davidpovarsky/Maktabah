import pathlib,subprocess,json,hashlib,datetime
r=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-native98-index-metadata-20261120");out=r/"build/native98-index-metadata-20261120";swift=pathlib.Path(r"C:\Users\DAVID\AppData\Local\Programs\Swift\Toolchains\6.3.3+Asserts\usr\bin\swiftc.exe")
path=r/"Maktabah-iOSUITests/GlobalSearchNativeAcceptanceTests.swift";source=path.read_bytes()
start=b"// MARK: - Original engine metadata after an explicit fixture reinstallation";end=b"// MARK: - Complete owned index payload inventory"
assert source.count(start)==source.count(end)==1
span=source[source.index(start):source.index(end)+len(end)]+b"\n\n"
helper=(out/"METADATA_HELPER.swift").read_bytes();assert helper==b"import Foundation\n\n"+span
harness=r'''
private struct MetadataCheck: Codable {
    let name: String
    let expectedAcceptance: Bool
    let actualAcceptance: Bool
    let passed: Bool
    let detail: String
}

@main
private struct MetadataBoundaryControls {
    static func main() throws {
        let before = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
        let after = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[2]))
        let text = String(decoding: after, as: UTF8.self)
        var checks: [MetadataCheck] = []
        func mutated(_ from: String, _ to: String) -> Data {
            precondition(text.components(separatedBy: from).count == 2)
            return Data(text.replacingOccurrences(of: from, with: to).utf8)
        }
        func check(_ name: String, _ candidate: Data, accepted: Bool,
                   start: TimeInterval = 1795181730.25, end: TimeInterval = 1795181745.75,
                   original: Data? = nil) {
            var actual = false
            var detail = ""
            do {
                try searchDataVerifyRegeneratedEngineMetadata(
                    original: original ?? before, repaired: candidate,
                    reinstallationStartedAt: Date(timeIntervalSince1970: start),
                    observedAt: Date(timeIntervalSince1970: end))
                actual = true
            } catch { detail = String(describing: error) }
            checks.append(MetadataCheck(name: name, expectedAcceptance: accepted,
                actualAcceptance: actual, passed: actual == accepted, detail: detail))
        }
        check("actual-native-hash-matched-regenerated-metadata", after, accepted: true)
        check("creation-second-at-observation-lower-bound", after, accepted: true,
              start: 1795181732.99, end: 1795181745.75)
        check("creation-second-at-observation-upper-bound", after, accepted: true,
              start: 1795181730.25, end: 1795181732.01)
        check("same-second-reinstall-does-not-require-byte-change", before, accepted: true,
              start: 1795181380.0, end: 1795181380.99)
        check("format-change-rejected", mutated("otzaria-search-index", "foreign-index"), accepted: false)
        check("schema-change-rejected", mutated("\"schema_version\": 4", "\"schema_version\": 3"), accepted: false)
        check("engine-version-change-rejected", mutated("\"engine_version\": \"0.1.0\"", "\"engine_version\": \"0.2.0\""), accepted: false)
        check("tantivy-version-change-rejected", mutated("0.26.1", "0.27.0"), accepted: false)
        check("extra-metadata-field-rejected", mutated("\n}", ",\n  \"extra\": true\n}"), accepted: false)
        check("missing-metadata-field-rejected", mutated("  \"tantivy_version\": \"0.26.1\",\n", ""), accepted: false)
        check("duplicate-creation-field-rejected",
              mutated("\n}", ",\n  \"created_at_unix_seconds\": 1795181732\n}"), accepted: false)
        check("duplicate-format-field-rejected",
              mutated("\n}", ",\n  \"format\": \"otzaria-search-index\"\n}"), accepted: false)
        check("every-other-byte-including-whitespace-retained",
              mutated("\"format\": ", "\"format\" : "), accepted: false)
        check("timestamp-serialization-spacing-retained",
              mutated("\"created_at_unix_seconds\": ", "\"created_at_unix_seconds\" : "), accepted: false)
        check("before-real-tap-window-rejected",
              mutated("1795181732", "1795181729"), accepted: false)
        check("after-real-observation-window-rejected",
              mutated("1795181732", "1795181746"), accepted: false)
        check("creation-cannot-move-backward",
              mutated("1795181732", "1795181379"), accepted: false,
              start: 1795181378, end: 1795181380)
        check("zero-creation-rejected", mutated("1795181732", "0"), accepted: false)
        check("negative-creation-rejected", mutated("1795181732", "-1"), accepted: false)
        check("boolean-creation-rejected", mutated("1795181732", "true"), accepted: false)
        check("fractional-creation-rejected", mutated("1795181732", "1795181732.5"), accepted: false)
        check("integral-floating-serialization-rejected", mutated("1795181732", "1795181732.0"), accepted: false)
        check("overflow-creation-rejected", mutated("1795181732", "18446744073709551616"), accepted: false)
        check("string-creation-rejected", mutated("1795181732", "\"1795181732\""), accepted: false)
        check("malformed-json-rejected", Data("{not-json".utf8), accepted: false)
        check("empty-json-rejected", Data(), accepted: false)
        check("non-object-json-rejected", Data("[]".utf8), accepted: false)
        check("invalid-utf8-rejected", Data([0xff, 0xfe]), accepted: false)
        check("nan-window-rejected", after, accepted: false, start: .nan)
        check("infinite-window-rejected", after, accepted: false, end: .infinity)
        check("reversed-window-rejected", after, accepted: false,
              start: 1795181746, end: 1795181730)
        check("nonpositive-window-rejected", after, accepted: false, start: 0)
        check("overflow-window-rejected", after, accepted: false, end: Double(UInt64.max))
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let passed = checks.filter(\.passed).count
        struct Result: Codable {
            let scope: String
            let passed: Int
            let failed: Int
            let checks: [MetadataCheck]
        }
        let result = Result(scope: "actual unchanged Foundation metadata-validation helper only; not Apple or Native",
                            passed: passed, failed: checks.count - passed, checks: checks)
        print(String(decoding: try encoder.encode(result), as: UTF8.self))
        if passed != checks.count { exit(1) }
    }
}
'''
combined=helper+harness.encode();(out/"BoundaryControls.swift").write_bytes(combined)
beforehash=hashlib.sha256(source).hexdigest()
records=[]
def run(name,args,timeout=120):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run([str(swift),*args],cwd=r,capture_output=True,timeout=timeout)
 (out/(name+".stdout.log")).write_bytes(p.stdout);(out/(name+".stderr.log")).write_bytes(p.stderr)
 result={"name":name,"command":[str(swift),*args],"started_at":started,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"returncode":p.returncode,"stdout_sha256":hashlib.sha256(p.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(p.stderr).hexdigest()}
 records.append(result);(out/(name+".json")).write_bytes((json.dumps(result,indent=2)+"\n").encode())
 return p
p=run("PARSE_FULL_NATIVE_FILE",["-frontend","-parse",str(path)])
if p.returncode:print(json.dumps({"status":"SYNTAX_FAIL","records":records}));raise SystemExit(1)
exe=out/"BoundaryControls.exe"
p=run("COMPILE_METADATA_CONTROLS",["-parse-as-library",str(out/"BoundaryControls.swift"),"-o",str(exe)])
if p.returncode:print(json.dumps({"status":"COMPILE_FAIL","records":records}));raise SystemExit(1)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run([str(exe),str(out/"SOURCE_DERIVED_MATCH_before.json"),str(out/"SOURCE_DERIVED_MATCH_after.json")],cwd=r,capture_output=True,timeout=60)
(out/"RUN_CONTROLS.stdout.json").write_bytes(p.stdout);(out/"RUN_CONTROLS.stderr.log").write_bytes(p.stderr)
result=json.loads(p.stdout);assert result["failed"]==0 and p.returncode==0
receipt={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"status":"PASS_METADATA_HELPER_ONLY","source_sha256":beforehash,"source_unchanged":path.read_bytes()==source,"helper_sha256":hashlib.sha256(helper).hexdigest(),"helper_exact_source_span":True,"syntax":records[0],"compile":records[1],"execution_started":started,"execution_returncode":p.returncode,"passed":result["passed"],"failed":result["failed"],"apple_native":"NOT_RUN","original_native_failure":"RETAINED_FAIL"}
assert receipt["source_unchanged"]
(out/"RESULT.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode());print(json.dumps(receipt))
