import Foundation

// MARK: - Original engine metadata after an explicit fixture reinstallation

private struct SearchDataNativeEngineMetadata: Decodable {
    let format: String
    let schema_version: UInt32
    let engine_version: String
    let tantivy_version: String
    let created_at_unix_seconds: UInt64
}

private enum SearchDataNativeMetadataError: Error { case rejected(String) }

/// The original miniTest10 artifact contains seven Tantivy files, not this
/// sidecar. The unchanged Rust engine creates it when opening a fresh install.
/// Only that original creation second may change during an explicit reinstall;
/// every other byte and the complete nine-file inventory remain checked.
private func searchDataVerifyRegeneratedEngineMetadata(
    original: Data,
    repaired: Data,
    reinstallationStartedAt: Date,
    observedAt: Date
) throws {
    func require(_ valid: Bool, _ reason: String) throws {
        if !valid { throw SearchDataNativeMetadataError.rejected(reason) }
    }
    let keys: Set<String> = [
        "format", "schema_version", "engine_version", "tantivy_version", "created_at_unix_seconds"
    ]
    func decode(_ data: Data) throws -> (SearchDataNativeEngineMetadata, String) {
        guard let text = String(data: data, encoding: .utf8),
              let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw SearchDataNativeMetadataError.rejected("Original engine metadata must be a UTF-8 JSON object")
        }
        try require(Set(object.keys) == keys, "Retain exactly the original five metadata fields")
        for key in keys {
            try require(text.components(separatedBy: "\"" + key + "\"").count == 2,
                        "Each original metadata field must occur exactly once")
        }
        let value = try JSONDecoder().decode(SearchDataNativeEngineMetadata.self, from: data)
        try require(value.format == "otzaria-search-index" && value.schema_version == 4
            && value.engine_version == "0.1.0" && value.tantivy_version == "0.26.1"
            && value.created_at_unix_seconds > 0,
            "Require the original source-pinned miniTest10 v6 engine metadata")
        return (value, text)
    }
    let (before, beforeText) = try decode(original)
    let (after, afterText) = try decode(repaired)
    let start = reinstallationStartedAt.timeIntervalSince1970
    let end = observedAt.timeIntervalSince1970
    try require(start.isFinite && end.isFinite && start > 0 && end >= start
        && end < Double(UInt64.max), "Require an actual bounded observation interval")
    let lower = UInt64(start.rounded(.down))
    let upper = UInt64(end.rounded(.down))
    try require(after.created_at_unix_seconds >= before.created_at_unix_seconds
        && (lower...upper).contains(after.created_at_unix_seconds),
        "The original engine creation second must fall within this real reinstallation")
    let beforeField = "\"created_at_unix_seconds\": \(before.created_at_unix_seconds)"
    let afterField = "\"created_at_unix_seconds\": \(after.created_at_unix_seconds)"
    try require(beforeText.components(separatedBy: beforeField).count == 2
        && afterText.components(separatedBy: afterField).count == 2,
        "Require the original engine's exact metadata field serialization")
    try require(afterText.replacingOccurrences(of: afterField, with: beforeField) == beforeText,
                "Every metadata byte except the bounded creation second must remain identical")
}

// MARK: - Complete owned index payload inventory


private struct MetadataCheck: Codable {
    let name: String
    let expectedAcceptance: Bool
    let actualAcceptance: Bool
    let passed: Bool
    let detail: String
}

@main
private struct MetadataBoundaryControls {
    static func main() throws {
        let before = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
        let after = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[2]))
        let text = String(decoding: after, as: UTF8.self)
        var checks: [MetadataCheck] = []
        func mutated(_ from: String, _ to: String) -> Data {
            precondition(text.components(separatedBy: from).count == 2)
            return Data(text.replacingOccurrences(of: from, with: to).utf8)
        }
        func check(_ name: String, _ candidate: Data, accepted: Bool,
                   start: TimeInterval = 1795181730.25, end: TimeInterval = 1795181745.75,
                   original: Data? = nil) {
            var actual = false
            var detail = ""
            do {
                try searchDataVerifyRegeneratedEngineMetadata(
                    original: original ?? before, repaired: candidate,
                    reinstallationStartedAt: Date(timeIntervalSince1970: start),
                    observedAt: Date(timeIntervalSince1970: end))
                actual = true
            } catch { detail = String(describing: error) }
            checks.append(MetadataCheck(name: name, expectedAcceptance: accepted,
                actualAcceptance: actual, passed: actual == accepted, detail: detail))
        }
        check("actual-native-hash-matched-regenerated-metadata", after, accepted: true)
        check("creation-second-at-observation-lower-bound", after, accepted: true,
              start: 1795181732.99, end: 1795181745.75)
        check("creation-second-at-observation-upper-bound", after, accepted: true,
              start: 1795181730.25, end: 1795181732.01)
        check("same-second-reinstall-does-not-require-byte-change", before, accepted: true,
              start: 1795181380.0, end: 1795181380.99)
        check("format-change-rejected", mutated("otzaria-search-index", "foreign-index"), accepted: false)
        check("schema-change-rejected", mutated("\"schema_version\": 4", "\"schema_version\": 3"), accepted: false)
        check("engine-version-change-rejected", mutated("\"engine_version\": \"0.1.0\"", "\"engine_version\": \"0.2.0\""), accepted: false)
        check("tantivy-version-change-rejected", mutated("0.26.1", "0.27.0"), accepted: false)
        check("extra-metadata-field-rejected", mutated("\n}", ",\n  \"extra\": true\n}"), accepted: false)
        check("missing-metadata-field-rejected", mutated("  \"tantivy_version\": \"0.26.1\",\n", ""), accepted: false)
        check("duplicate-creation-field-rejected",
              mutated("\n}", ",\n  \"created_at_unix_seconds\": 1795181732\n}"), accepted: false)
        check("duplicate-format-field-rejected",
              mutated("\n}", ",\n  \"format\": \"otzaria-search-index\"\n}"), accepted: false)
        check("every-other-byte-including-whitespace-retained",
              mutated("\"format\": ", "\"format\" : "), accepted: false)
        check("timestamp-serialization-spacing-retained",
              mutated("\"created_at_unix_seconds\": ", "\"created_at_unix_seconds\" : "), accepted: false)
        check("before-real-tap-window-rejected",
              mutated("1795181732", "1795181729"), accepted: false)
        check("after-real-observation-window-rejected",
              mutated("1795181732", "1795181746"), accepted: false)
        check("creation-cannot-move-backward",
              mutated("1795181732", "1795181379"), accepted: false,
              start: 1795181378, end: 1795181380)
        check("zero-creation-rejected", mutated("1795181732", "0"), accepted: false)
        check("negative-creation-rejected", mutated("1795181732", "-1"), accepted: false)
        check("boolean-creation-rejected", mutated("1795181732", "true"), accepted: false)
        check("fractional-creation-rejected", mutated("1795181732", "1795181732.5"), accepted: false)
        check("integral-floating-serialization-rejected", mutated("1795181732", "1795181732.0"), accepted: false)
        check("overflow-creation-rejected", mutated("1795181732", "18446744073709551616"), accepted: false)
        check("string-creation-rejected", mutated("1795181732", "\"1795181732\""), accepted: false)
        check("malformed-json-rejected", Data("{not-json".utf8), accepted: false)
        check("empty-json-rejected", Data(), accepted: false)
        check("non-object-json-rejected", Data("[]".utf8), accepted: false)
        check("invalid-utf8-rejected", Data([0xff, 0xfe]), accepted: false)
        check("nan-window-rejected", after, accepted: false, start: .nan)
        check("infinite-window-rejected", after, accepted: false, end: .infinity)
        check("reversed-window-rejected", after, accepted: false,
              start: 1795181746, end: 1795181730)
        check("nonpositive-window-rejected", after, accepted: false, start: 0)
        check("overflow-window-rejected", after, accepted: false, end: Double(UInt64.max))
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let passed = checks.filter(\.passed).count
        struct Result: Codable {
            let scope: String
            let passed: Int
            let failed: Int
            let checks: [MetadataCheck]
        }
        let result = Result(scope: "actual unchanged Foundation metadata-validation helper only; not Apple or Native",
                            passed: passed, failed: checks.count - passed, checks: checks)
        print(String(decoding: try encoder.encode(result), as: UTF8.self))
        if passed != checks.count { exit(1) }
    }
}
