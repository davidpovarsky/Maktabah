import Foundation

// MARK: - Original engine metadata after an explicit fixture reinstallation

private struct SearchDataNativeEngineMetadata: Decodable {
    let format: String
    let schema_version: UInt32
    let engine_version: String
    let tantivy_version: String
    let created_at_unix_seconds: UInt64
}

private enum SearchDataNativeMetadataError: Error { case rejected(String) }

/// The original miniTest10 artifact contains seven Tantivy files, not this
/// sidecar. The unchanged Rust engine creates it when opening a fresh install.
/// Only that original creation second may change during an explicit reinstall;
/// every other byte and the complete nine-file inventory remain checked.
private func searchDataVerifyRegeneratedEngineMetadata(
    original: Data,
    repaired: Data,
    reinstallationStartedAt: Date,
    observedAt: Date
) throws {
    func require(_ valid: Bool, _ reason: String) throws {
        if !valid { throw SearchDataNativeMetadataError.rejected(reason) }
    }
    let keys: Set<String> = [
        "format", "schema_version", "engine_version", "tantivy_version", "created_at_unix_seconds"
    ]
    func decode(_ data: Data) throws -> (SearchDataNativeEngineMetadata, String) {
        guard let text = String(data: data, encoding: .utf8),
              let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw SearchDataNativeMetadataError.rejected("Original engine metadata must be a UTF-8 JSON object")
        }
        try require(Set(object.keys) == keys, "Retain exactly the original five metadata fields")
        for key in keys {
            try require(text.components(separatedBy: "\"" + key + "\"").count == 2,
                        "Each original metadata field must occur exactly once")
        }
        let value = try JSONDecoder().decode(SearchDataNativeEngineMetadata.self, from: data)
        try require(value.format == "otzaria-search-index" && value.schema_version == 4
            && value.engine_version == "0.1.0" && value.tantivy_version == "0.26.1"
            && value.created_at_unix_seconds > 0,
            "Require the original source-pinned miniTest10 v6 engine metadata")
        return (value, text)
    }
    let (before, beforeText) = try decode(original)
    let (after, afterText) = try decode(repaired)
    let start = reinstallationStartedAt.timeIntervalSince1970
    let end = observedAt.timeIntervalSince1970
    try require(start.isFinite && end.isFinite && start > 0 && end >= start
        && end < Double(UInt64.max), "Require an actual bounded observation interval")
    let lower = UInt64(start.rounded(.down))
    let upper = UInt64(end.rounded(.down))
    try require(after.created_at_unix_seconds >= before.created_at_unix_seconds
        && (lower...upper).contains(after.created_at_unix_seconds),
        "The original engine creation second must fall within this real reinstallation")
    let beforeField = "\"created_at_unix_seconds\": \(before.created_at_unix_seconds)"
    let afterField = "\"created_at_unix_seconds\": \(after.created_at_unix_seconds)"
    try require(beforeText.components(separatedBy: beforeField).count == 2
        && afterText.components(separatedBy: afterField).count == 2,
        "Require the original engine's exact metadata field serialization")
    try require(afterText.replacingOccurrences(of: afterField, with: beforeField).utf8.elementsEqual(beforeText.utf8),
                "Every metadata byte except the bounded creation second must remain identical")
}

// MARK: - Complete owned index payload inventory

