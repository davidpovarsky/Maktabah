import pathlib,subprocess,json,hashlib,datetime,shutil
root=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-occurrence-app-20261120");wt=root.parent/"Maktabah-native98-index-metadata-20261120";base="0f25cb37711cbc1057d34a20ee8552bbcae75903";branch="codex/otzaria-native98-index-metadata-20261120";path="Maktabah-iOSUITests/GlobalSearchNativeAcceptanceTests.swift"
def git(*a,cwd=root):return subprocess.check_output(["git","-c","gc.auto=0","-c","maintenance.auto=false",*a],cwd=cwd)
assert git("rev-parse","HEAD").decode().strip()==base and not wt.exists()
git("-c","core.autocrlf=false","worktree","add","--no-checkout","-b",branch,str(wt),base)
git("sparse-checkout","set","--no-cone","/Maktabah-iOSUITests/","/Tests/HQ/search/Fixtures/","/docs/hq-integration/native98-index-metadata-20261120/",cwd=wt)
git("-c","core.autocrlf=false","checkout",branch,cwd=wt)
assert not git("status","--porcelain",cwd=wt).strip()
old=git("show",base+":"+path).decode()
helper=r'''// MARK: - Original engine metadata after an explicit fixture reinstallation

private struct SearchDataNativeEngineMetadata: Decodable {
    let format: String
    let schema_version: UInt32
    let engine_version: String
    let tantivy_version: String
    let created_at_unix_seconds: UInt64
}

private enum SearchDataNativeMetadataError: Error { case rejected(String) }

/// The original miniTest10 artifact contains seven Tantivy files, not this
/// sidecar. The unchanged Rust engine creates it when opening a fresh install.
/// Only that original creation second may change during an explicit reinstall;
/// every other byte and the complete nine-file inventory remain checked.
private func searchDataVerifyRegeneratedEngineMetadata(
    original: Data,
    repaired: Data,
    reinstallationStartedAt: Date,
    observedAt: Date
) throws {
    func require(_ valid: Bool, _ reason: String) throws {
        if !valid { throw SearchDataNativeMetadataError.rejected(reason) }
    }
    let keys: Set<String> = [
        "format", "schema_version", "engine_version", "tantivy_version", "created_at_unix_seconds"
    ]
    func decode(_ data: Data) throws -> (SearchDataNativeEngineMetadata, String) {
        guard let text = String(data: data, encoding: .utf8),
              let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw SearchDataNativeMetadataError.rejected("Original engine metadata must be a UTF-8 JSON object")
        }
        try require(Set(object.keys) == keys, "Retain exactly the original five metadata fields")
        for key in keys {
            try require(text.components(separatedBy: "\"" + key + "\"").count == 2,
                        "Each original metadata field must occur exactly once")
        }
        let value = try JSONDecoder().decode(SearchDataNativeEngineMetadata.self, from: data)
        try require(value.format == "otzaria-search-index" && value.schema_version == 4
            && value.engine_version == "0.1.0" && value.tantivy_version == "0.26.1"
            && value.created_at_unix_seconds > 0,
            "Require the original source-pinned miniTest10 v6 engine metadata")
        return (value, text)
    }
    let (before, beforeText) = try decode(original)
    let (after, afterText) = try decode(repaired)
    let start = reinstallationStartedAt.timeIntervalSince1970
    let end = observedAt.timeIntervalSince1970
    try require(start.isFinite && end.isFinite && start > 0 && end >= start
        && end < Double(UInt64.max), "Require an actual bounded observation interval")
    let lower = UInt64(start.rounded(.down))
    let upper = UInt64(end.rounded(.down))
    try require(after.created_at_unix_seconds >= before.created_at_unix_seconds
        && (lower...upper).contains(after.created_at_unix_seconds),
        "The original engine creation second must fall within this real reinstallation")
    let beforeField = "\"created_at_unix_seconds\": \(before.created_at_unix_seconds)"
    let afterField = "\"created_at_unix_seconds\": \(after.created_at_unix_seconds)"
    try require(beforeText.components(separatedBy: beforeField).count == 2
        && afterText.components(separatedBy: afterField).count == 2,
        "Require the original engine's exact metadata field serialization")
    try require(afterText.replacingOccurrences(of: afterField, with: beforeField) == beforeText,
                "Every metadata byte except the bounded creation second must remain identical")
}

// MARK: - Complete owned index payload inventory

'''
anchor="private func searchDataIndexInventory("
assert old.count(anchor)==1
new=old.replace(anchor,helper+anchor,1)
new=new.replace("    let indexPayload: [String: String]\n    let documentCount: Int","    let indexPayload: [String: String]\n    let engineMetadataBytes: Data\n    let documentCount: Int",1)
oldblock='''        let result = SearchDataNativeFixture(appContainer: container, root: root, index: index,
            database: database, databaseManifest: databaseManifest, ownerMetadata: owner.1,
            ownerMetadataBytes: owner.2, databaseDigest: digest, databaseManifestBytes: databaseManifestBytes,
            indexPayload: try searchDataIndexInventory(index), documentCount: count)'''
newblock='''        let payload = try searchDataIndexInventory(index)
        let parts = try XCTUnwrap(lexical["parts"] as? [[String: Any]])
        let paths = try parts.map { try XCTUnwrap($0["destinationPath"] as? String) }
        try requireSearchDataFixture(lexical["fileCount"] as? Int == 7 && paths.count == 7
            && Set(paths).count == 7 && paths.contains("meta.json")
            && !paths.contains("otzaria_index_meta.json")
            && Set(payload.keys) == Set(paths).union([
                "otzaria_index_meta.json", "otzaria_prebuilt_installation.json"
            ]), "Require the exact original seven-file artifact and both retained metadata files")
        let engineMetadata = try searchDataFileBytes(
            index.appendingPathComponent("otzaria_index_meta.json"), maximum: 65536)
        try requireSearchDataFixture(searchDataDigest(engineMetadata) == payload["otzaria_index_meta.json"],
                                     "Capture the exact inventoried original engine metadata")
        let metadataAttachment = XCTAttachment(data: engineMetadata, uniformTypeIdentifier: "public.json")
        metadataAttachment.name = "search-data-original-engine-metadata"
        metadataAttachment.lifetime = .keepAlways
        add(metadataAttachment)
        let result = SearchDataNativeFixture(appContainer: container, root: root, index: index,
            database: database, databaseManifest: databaseManifest, ownerMetadata: owner.1,
            ownerMetadataBytes: owner.2, databaseDigest: digest, databaseManifestBytes: databaseManifestBytes,
            indexPayload: payload, engineMetadataBytes: engineMetadata, documentCount: count)'''
assert new.count(oldblock)==1;new=new.replace(oldblock,newblock,1)
oldverify='''    private func verifyRecoveredAndCold(_ value: SearchDataNativeFixture) throws {
        ready(value, named: "search-data-after-recovery", timeout: 180)
        try value.verifyBooksAndOwner()
        XCTAssertEqual(try searchDataIndexInventory(value.index), value.indexPayload)
        try actualQueryAfterClosingData()
        app.terminate()
        try launchSearchDataReader()
        try openSearchData()
        ready(value, named: "search-data-after-repaired-cold-launch")
        try actualQueryAfterClosingData()
        try value.verifyBooksAndOwner()
        XCTAssertEqual(try searchDataIndexInventory(value.index), value.indexPayload)
    }'''
newverify='''    private func verifyRecoveredAndCold(
        _ value: SearchDataNativeFixture,
        reinstallationStartedAt: Date? = nil
    ) throws {
        ready(value, named: "search-data-after-recovery", timeout: 180)
        try value.verifyBooksAndOwner()
        var expectedPayload = value.indexPayload
        if let reinstallationStartedAt {
            let repairedMetadata = try searchDataFileBytes(
                value.index.appendingPathComponent("otzaria_index_meta.json"), maximum: 65536)
            let observedAt = Date()
            let metadataAttachment = XCTAttachment(data: repairedMetadata, uniformTypeIdentifier: "public.json")
            metadataAttachment.name = "search-data-reinstalled-engine-metadata"
            metadataAttachment.lifetime = .keepAlways
            add(metadataAttachment)
            let proof: [String: Any] = [
                "reinstallationStartedAt": reinstallationStartedAt.timeIntervalSince1970,
                "observedAt": observedAt.timeIntervalSince1970,
                "originalSHA256": searchDataDigest(value.engineMetadataBytes),
                "repairedSHA256": searchDataDigest(repairedMetadata),
                "scope": "original engine-generated creation second; every other metadata byte and all nine files remain checked"
            ]
            let attachment = XCTAttachment(
                data: try JSONSerialization.data(withJSONObject: proof, options: [.sortedKeys]),
                uniformTypeIdentifier: "public.json")
            attachment.name = "search-data-reinstallation-metadata-interval"
            attachment.lifetime = .keepAlways
            add(attachment)
            try searchDataVerifyRegeneratedEngineMetadata(
                original: value.engineMetadataBytes, repaired: repairedMetadata,
                reinstallationStartedAt: reinstallationStartedAt, observedAt: observedAt)
            expectedPayload["otzaria_index_meta.json"] = searchDataDigest(repairedMetadata)
        }
        XCTAssertEqual(try searchDataIndexInventory(value.index), expectedPayload)
        try actualQueryAfterClosingData()
        app.terminate()
        try launchSearchDataReader()
        try openSearchData()
        ready(value, named: "search-data-after-repaired-cold-launch")
        try actualQueryAfterClosingData()
        try value.verifyBooksAndOwner()
        XCTAssertEqual(try searchDataIndexInventory(value.index), expectedPayload,
                       "Cold validation must preserve every repaired index and metadata byte")
    }'''
assert new.count(oldverify)==1;new=new.replace(oldverify,newverify,1)
oldtap='''        tap(try dataAction("search-data-repair-otzaria"))
        try verifyRecoveredAndCold(value)'''
newtap='''        let repair = try dataAction("search-data-repair-otzaria")
        let reinstallationStartedAt = Date()
        tap(repair)
        try verifyRecoveredAndCold(value, reinstallationStartedAt: reinstallationStartedAt)'''
assert new.count(oldtap)==2;new=new.replace(oldtap,newtap)
oldretry='''        tap(retry)
        try verifyRecoveredAndCold(value)'''
newretry='''        let reinstallationStartedAt = Date()
        tap(retry)
        try verifyRecoveredAndCold(value, reinstallationStartedAt: reinstallationStartedAt)'''
assert new.count(oldretry)==1;new=new.replace(oldretry,newretry,1)
# Exact inverse of every intended hunk, including unchanged healthy/secondary/failed-attempt and restoration bodies.
inverse=new.replace(newretry,oldretry,1).replace(newtap,oldtap).replace(newverify,oldverify,1).replace(newblock,oldblock,1).replace("    let indexPayload: [String: String]\n    let engineMetadataBytes: Data\n    let documentCount: Int","    let indexPayload: [String: String]\n    let documentCount: Int",1).replace(helper,"",1)
assert inverse==old
(wt/path).write_bytes(new.encode())
e=wt/"build/native98-index-metadata-20261120";e.mkdir(parents=True,exist_ok=True)
(e/"SOURCE_BEFORE.swift").write_bytes(old.encode());(e/"SOURCE_AFTER.swift").write_bytes(new.encode())
(e/"METADATA_HELPER.swift").write_bytes(("import Foundation\n\n"+helper).encode())
(e/"SOURCE.patch").write_bytes(git("diff","--",path,cwd=wt))
for name in ["SOURCE_DERIVED_METADATA_HASH_MATCHES.json","SOURCE_DERIVED_MATCH_before.json","SOURCE_DERIVED_MATCH_after.json","ORIGINAL_ENGINE_READ.json","ENGINE_GIT_TREE.json","original_search_engine_d5.rs","CAPTURE_INDEX_STDOUT_MATCHES.json"]:
 shutil.copy2(root/"build/native98-index-diagnosis-20261120"/name,e/name)
(e/"MINITEST10_ORIGINAL_MANIFEST.json").write_bytes(git("show",base+":Tests/HQ/search/Fixtures/otzaria-miniTest10-v6-manifest.json"))
receipt={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base":base,"branch":branch,"worktree":str(wt),"source_path":path,"source_before_sha256":hashlib.sha256(old.encode()).hexdigest(),"source_after_sha256":hashlib.sha256(new.encode()).hexdigest(),"inverse_exact":True,"changed_paths":git("diff","--name-only",cwd=wt).decode().splitlines(),"explicit_reinstallation_call_sites":3,"native_methods_unchanged":True,"apple_native":"NOT_RUN","test_execution":"NOT_YET_RUN"}
(e/"EDIT.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode());print(json.dumps(receipt))
