from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

base = Path(__file__).parent
out = base / 'git-packet'
out.mkdir(exist_ok=False)
rows = []

def add(rel, path, compressed=False):
    raw = path.read_bytes()
    value = gzip.compress(raw, compresslevel=9, mtime=0) if compressed else raw
    target = out / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as f:
        f.write(value)
    row = {'path': rel, 'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()}
    if compressed:
        assert gzip.decompress(value) == raw
        row.update(encoding='lossless-gzip', raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest())
    rows.append(row)

for name in ['README.md', 'PLAN.json', 'PROVENANCE_READONLY.json', 'RETIREMENT_PROPOSAL.json']:
    add(name, base / name)
for p in sorted((base / 'final-proof').glob('*.json')):
    if p.name != 'TRANSFER_ROWS.json': add('receipts/' + p.name, p)
for p in sorted((base / 'windows-raw').rglob('*')):
    if p.is_file():
        rel = 'windows/' + p.relative_to(base / 'windows-raw').as_posix()
        if p.suffix == '.log': add('raw/' + rel + '.gz', p, True)
        else: add(rel, p)
for name in ['closed_native.py', 'receive_closed_native.py', 'bridge_closed_native.py',
             'seal_complete.py', 'retire_closed_native.py', 'current_closed_archive.py',
             'retire_closed_windows.py', 'seal_git_packet.py']:
    add('raw/scripts/' + name + '.gz', base / name, True)
helper = base.parent / 'qualified-snapshot-preservation/qualified_preservation.py'
assert hashlib.sha256(helper.read_bytes()).hexdigest() == 'f07264ccf70a75f9b74566d24f65cfdcd6e832e5f3b09231cb6311afae06749e'
add('raw/scripts/metadata_helper.py.gz', helper, True)
for name in ['PUBLICATION_ATTEMPT_1.json', 'PUBLICATION_ATTEMPT_2.json']:
    add('raw/cutover-publication/' + name + '.gz', base.parent / 'sdk-pasteboard-fresh-run' / name, True)
index = {'schema': 'otzaria.closed-native-preservation-retirement-git-packet/1',
         'scope': 'Documentation-only; verified lossless preservation and seven exact authorized root removals. No source/build/native acceptance.',
         'files': sorted(rows, key=lambda r: r['path'])}
raw = (json.dumps(index, indent=2, sort_keys=True) + '\n').encode()
(out / 'PACKET_INDEX.json').write_bytes(raw)
archive = base / 'closed-native-git-packet.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for p in sorted(out.rglob('*')):
        if p.is_file():
            b = p.read_bytes(); member = tarfile.TarInfo(p.relative_to(out).as_posix())
            member.size = len(b); member.mode = 0o644; member.mtime = 0
            tar.addfile(member, io.BytesIO(b))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers(); assert len(members) == len(rows) + 1
    for m in members:
        assert tar.extractfile(m).read() == (out / m.name).read_bytes()
print(json.dumps({'archive': str(archive.resolve()), 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'files': len(rows) + 1, 'index_rows': len(rows),
                  'index_sha256': hashlib.sha256(raw).hexdigest(),
                  'raw_gzip_files': sum(x.get('encoding') == 'lossless-gzip' for x in rows),
                  'source_changes': 0}, sort_keys=True))
