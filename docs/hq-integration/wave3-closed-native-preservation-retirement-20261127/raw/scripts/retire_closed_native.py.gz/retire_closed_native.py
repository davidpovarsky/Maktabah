#!/usr/bin/env python3
"""One separately reviewed retirement of seven exact, fully preserved roots."""
from pathlib import Path
import base64
import datetime
import gzip
import hashlib
import inspect
import json
import os
import select
import shutil
import stat
import subprocess
import sys
import time
import types

sys.dont_write_bytecode = True
EVIDENCE = Path('/Users/m1/builds/otzaria-wave3-closed-native-preservation-20261127.o5ye8las')
BASE = Path('/Users/m1/builds/otzaria-root-actions-acceptance-20261126.wjQnLNJl/compact-reader-preview-worktree.5hRb5SYt')
ROOT_NAMES = [
    ('actual-candidate-focused-native.EeUZ35lg', 63374283),
    ('continued-authority-focused.4m2Xqttt', 64487998),
    ('actual-narrow-application-toolbar-focus.n1VgwMQf', 64991034),
    ('actual-phone-and-native-witness.Lj8qFaXi', 64042099),
    ('exact-standalone-reader-release-native.UperJJ5L', 64952991),
    ('actual-reader-publication-note-focus.h1iNTzUP', 65090651),
    ('wave3-native-0db0ab78-20261127', 66843630),
]
ROOTS = [BASE / name for name, _ in ROOT_NAMES]
HEADER_SHA = 'd6b5e2a0d8a403248b7919d4d7fd283df957f2b3524f5239a836f72f364856ee'
PROOF_SHA = 'fc6acb50b51ece3133921d746cbdb06fc8869e0c541f057e4a1240ffe835f6a7'
SOURCE_SHA = '13fd31b5bde07fd7138ac39d9c7db2c0954b42bec0fc711b83cdf333ce790112'
VERIFIED_SHA = '50987d6a7daa36458322f755068f6730609ad470309ab2fa6cd4e96fdcf0720e'
INVENTORY_SHA = '08db63301219a38ad9175702140ded020278c737216461890067f99f1dd3177c'
SDK_SHA = 'd6090c03b9ac4e5760941e34f4c04478db4ae59f'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()

def fixed_directory(path):
    assert path.resolve() == path and not path.is_symlink()
    s = path.lstat()
    assert stat.S_ISDIR(s.st_mode)
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino,
            'mode': s.st_mode, 'uid': s.st_uid, 'gid': s.st_gid}

def file_identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid,
            s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_flags)

def outside(inventory, header):
    protected = [fixed_directory(Path(x['path'])) for x in header['boundary']['protected']]
    assert protected == header['boundary']['protected']
    for row in protected:
        p = Path(row['path'])
        assert all(p != r and r not in p.parents for r in ROOTS)
    assert inventory.git(inventory.SDK, 'rev-parse', 'HEAD').decode().strip() == SDK_SHA
    assert not inventory.git(inventory.SDK, 'status', '--porcelain=v1', '--untracked-files=no').strip()
    assert inventory.digest(inventory.GUARDS) == inventory.GUARDS_SHA
    guards = json.loads(inventory.GUARDS.read_bytes())['original_files']
    assert len(guards) == 17
    for row in guards:
        raw = (inventory.SDK / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert raw == inventory.git(inventory.SDK, 'show', 'HEAD:' + row['path'])
    app = BASE / 'Maktabah'
    app_state = {'head': inventory.git(app, 'rev-parse', 'HEAD').decode().strip(),
                 'tracked_status': inventory.git(app, 'status', '--porcelain=v1', '--untracked-files=no').decode(),
                 'pbx_sha256': inventory.digest(app / 'Maktabah.xcodeproj/project.pbxproj')}
    assert app_state == header['boundary']['app_source']
    files = []
    for p in [app / 'Maktabah.xcodeproj/project.pbxproj', app / 'Source/PrivacyInfo.xcprivacy',
              inventory.SDK / 'Anytype/Sources/ServiceLayer/Block/Pastboard/PasteboardHelper.swift']:
        assert p.resolve() == p and not p.is_symlink()
        s = p.lstat(); assert stat.S_ISREG(s.st_mode)
        actual = inventory.digest(p)
        assert file_identity(s) == file_identity(p.lstat())
        files.append({'path': str(p), 'identity': file_identity(s), 'sha256': actual})
    assert files[-1]['sha256'] == '0eee42f7036e43d74d82088b2bd21696dc3b248f4430e4c9dfc887bbbc1a60d9'
    siblings = []
    with os.scandir(BASE) as entries:
        for entry in sorted(entries, key=lambda x: os.fsencode(x.name)):
            if entry.name in {name for name, _ in ROOT_NAMES}: continue
            s = entry.stat(follow_symlinks=False)
            siblings.append({'name': entry.name, 'device': s.st_dev, 'inode': s.st_ino,
                             'mode': s.st_mode, 'uid': s.st_uid, 'gid': s.st_gid,
                             'symlink_target': os.readlink(entry.path) if stat.S_ISLNK(s.st_mode) else None})
    return {'protected_directories': protected, 'app_source': app_state,
            'sdk_head': SDK_SHA, 'original_guard_sha256': inventory.GUARDS_SHA,
            'protected_files': files, 'all_other_direct_siblings': siblings}

def dependencies(inventory, header):
    assert header['dependency_records'] == [] and header['hardlink_groups'] == {}
    probes = []
    for repo, scopes in [(inventory.SDK, ['Tools/OriginalEditor', 'Tools/Hanlin', '.github']),
                         (BASE / 'Maktabah', ['Scripts/CI'])]:
        argv = ['/usr/bin/git', '--no-optional-locks', '-C', str(repo), 'grep', '-n', '-F']
        for root in ROOTS: argv += ['-e', str(root)]
        r = subprocess.run(argv + ['--'] + scopes, capture_output=True, text=True, timeout=30)
        assert r.returncode == 1 and r.stdout == r.stderr == ''
        probes.append({'repository': str(repo), 'scopes': scopes, 'exit': r.returncode,
                       'stdout': r.stdout, 'stderr': r.stderr})
    assert probes == header['controller_reference_probes']
    return {'symlinks_git_metadata_and_hardlinks': 0, 'controller_probes': probes,
            'external_referrers_exhaustively_excluded': False}

def full_source(inventory, helper, header):
    started = time.monotonic(); count = atime = 0
    stat_hash = hashlib.sha256(); content_hash = hashlib.sha256()
    with gzip.open(EVIDENCE / 'entries.jsonl.gz', 'rb') as entries:
        for root, path, s in inventory.walk():
            raw = entries.readline(); assert raw
            old = json.loads(raw); helper.ROOT = root
            now = helper.entry((path, s)); now['path'] = path.relative_to(BASE).as_posix()
            expected = dict(old); expected.pop('payload', None); expected.pop('allocation_observation', None)
            atime += now['atime_ns'] != expected['atime_ns']
            now.pop('atime_ns'); expected.pop('atime_ns')
            assert now == expected, ('Fresh full source metadata/content mismatch', old['path'])
            stat_hash.update(canonical({'path': now['path'], 'identity': helper.identity(s)}))
            if now['type'] == 'file':
                content_hash.update(canonical({'path': now['path'], 'bytes': now['bytes'], 'sha256': now['sha256']}))
            count += 1
            if count % 1024 == 0: inventory.capacity()
        assert not entries.read(1)
    assert count == header['summary']['entries'] == 37238
    assert stat_hash.hexdigest() == header['path_stat_sha256']
    assert content_hash.hexdigest() == header['regular_content_sha256']
    assert inventory.boundary() == header['boundary']
    return {'entries': count, 'path_stat_sha256': stat_hash.hexdigest(),
            'regular_content_sha256': content_hash.hexdigest(),
            'full_metadata_equal_except_preserved_access_time': True,
            'access_time_changes': atime, 'seconds': time.monotonic() - started}

def path_stat(inventory, helper, header):
    digest = hashlib.sha256(); count = 0
    for _, p, s in inventory.walk():
        digest.update(canonical({'path': p.relative_to(BASE).as_posix(), 'identity': helper.identity(s)}))
        count += 1
    assert count == 37238 and digest.hexdigest() == header['path_stat_sha256']
    return {'entries': count, 'sha256': digest.hexdigest()}

def main():
    assert sys.argv[1:] == ['--execute-root-authorized-seven-roots']
    envelope = json.loads(sys.stdin.buffer.readline(256 * 1024))
    current_raw = base64.b64decode(envelope['current_base64'], validate=True)
    assert hashlib.sha256(current_raw).hexdigest() == envelope['current_sha256']
    current = json.loads(current_raw)
    assert current['status'] == 'CURRENT_SELF_CONTAINED_ARCHIVE_AND_RECEIPTS_REHASHED'
    assert current['complete_preservation_sha256'] == PROOF_SHA
    assert current['source_reverified_sha256'] == SOURCE_SHA
    assert current['archive_verification_sha256'] == VERIFIED_SHA
    age = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(current['utc'])).total_seconds()
    assert 0 <= age <= 180
    proof_raw = (EVIDENCE / 'COMPLETE_PRESERVATION_VERIFIED.json').read_bytes()
    source_raw = (EVIDENCE / 'SOURCE_REVERIFIED.json').read_bytes()
    assert hashlib.sha256(proof_raw).hexdigest() == PROOF_SHA
    assert hashlib.sha256(source_raw).hexdigest() == SOURCE_SHA
    proof, source = json.loads(proof_raw), json.loads(source_raw)
    assert proof['archive'] == current['archive']
    assert proof['archive_stat_at_independent_readback'] == current['archive_identity']
    assert proof['origin_deletions'] == 0 and not source['anything_deleted']
    assert proof['exact_roots'] == source['boundary']['roots']
    assert [x['path'] for x in proof['exact_roots']] == [str(x) for x in ROOTS]
    assert [(Path(x['path']).name, x['inode']) for x in proof['exact_roots']] == ROOT_NAMES
    raw = (EVIDENCE / 'closed_native.py').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == INVENTORY_SHA
    inventory = types.ModuleType('exact_closed_native_inventory')
    inventory.__file__ = str(EVIDENCE / 'closed_native.py')
    exec(compile(raw, inventory.__file__, 'exec'), inventory.__dict__)
    assert inventory.BASE == BASE and inventory.roots() == ROOTS
    header = inventory.load_header(EVIDENCE, HEADER_SHA); helper = inventory.helper()
    assert inventory.boundary() == header['boundary'] == source['boundary']
    assert inventory.digest(Path(__file__)) == envelope['retirement_script_sha256']
    assert not (EVIDENCE / 'RETIREMENT_PREDELETE.json').exists()
    assert not (EVIDENCE / 'RETIREMENT_RESULT.json').exists()
    use_before = inventory.no_use()
    protected = outside(inventory, header); dep = dependencies(inventory, header)
    full = full_source(inventory, helper, header)
    assert outside(inventory, header) == protected
    use_after = inventory.no_use()
    paths = path_stat(inventory, helper, header)
    before = {'status': 'EXACT_SEVEN_ROOTS_VERIFIED_AWAITING_DURABLE_OFFHOST_ACK', 'utc': utc(),
              'roots': [str(x) for x in ROOTS], 'root_identities': proof['exact_roots'],
              'header_sha256': HEADER_SHA, 'complete_preservation_sha256': PROOF_SHA,
              'source_reverified_sha256': SOURCE_SHA, 'archive_verification_sha256': VERIFIED_SHA,
              'current_archive_bindings_sha256': envelope['current_sha256'],
              'current_archive_bindings': current, 'fresh_full_source': full,
              'fresh_path_stat': paths, 'protected_outside_before': protected,
              'dependency_before': dep, 'open_use_before': use_before, 'open_use_after': use_after,
              'free_before': inventory.capacity(), 'script_sha256': inventory.digest(Path(__file__)),
              'owner_process': {'pid': os.getpid(), 'ppid': os.getppid(), 'pgid': os.getpgid(0),
                                'start': subprocess.check_output(['/bin/ps', '-p', str(os.getpid()), '-o', 'lstart='], text=True).strip()},
              'scope': 'Only the seven exact closed diagnostic siblings; all source, archives, SDK, parents and other siblings remain protected.',
              'origin_deletions': 0, 'builds': 0, 'native_runs': 0}
    pre_raw = canonical(before)
    inventory.save(EVIDENCE / 'RETIREMENT_CURRENT_BINDINGS.json', current_raw)
    inventory.save(EVIDENCE / 'RETIREMENT_PREDELETE.json', pre_raw)
    sys.stdout.buffer.write(pre_raw); sys.stdout.buffer.flush()
    ready, _, _ = select.select([sys.stdin.buffer], [], [], 90)
    assert ready, 'No timely durable off-host ACK; origins unchanged'
    acknowledgement = json.loads(sys.stdin.buffer.readline(4096))
    expected_ack = {'ack': 'DURABLE_WINDOWS_ORACLE_EXACT_SEVEN_ROOTS_PREDELETE',
                    'sha256': hashlib.sha256(pre_raw).hexdigest(),
                    'complete_preservation_sha256': PROOF_SHA, 'source_reverified_sha256': SOURCE_SHA,
                    'current_archive_bindings_sha256': envelope['current_sha256']}
    assert acknowledgement == expected_ack
    assert path_stat(inventory, helper, header) == paths
    assert dependencies(inventory, header) == dep
    assert outside(inventory, header) == protected and inventory.boundary() == header['boundary']
    immediate_use = inventory.no_use()
    assert not immediate_use['open_files'] and not immediate_use['process_references']
    assert shutil.rmtree.avoids_symlink_attacks
    parent_fd = os.open(BASE, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    parent = os.fstat(parent_fd)
    expected_parent = header['boundary']['protected'][0]
    assert (parent.st_dev, parent.st_ino, parent.st_mode, parent.st_uid, parent.st_gid) == (
        expected_parent['device'], 61610714, expected_parent['mode'], expected_parent['uid'], expected_parent['gid'])
    cwd_fd = os.open('.', os.O_RDONLY | os.O_DIRECTORY)
    removed = []; removal_started = False
    try:
        has_dir_fd = 'dir_fd' in inspect.signature(shutil.rmtree).parameters
        if not has_dir_fd: os.fchdir(parent_fd)
        for root, expected in zip(ROOTS, proof['exact_roots']):
            assert root.parent == BASE and root.name not in ('.', '..', 'Maktabah')
            actual = os.stat(root.name, dir_fd=parent_fd, follow_symlinks=False)
            assert (actual.st_dev, actual.st_ino, actual.st_mode, actual.st_uid, actual.st_gid) == (
                expected['device'], expected['inode'], expected['mode'], expected['uid'], expected['gid'])
            assert stat.S_ISDIR(actual.st_mode)
            removal_started = True
            if has_dir_fd: shutil.rmtree(root.name, dir_fd=parent_fd)
            else: shutil.rmtree(root.name)
            try: os.stat(root.name, dir_fd=parent_fd, follow_symlinks=False)
            except FileNotFoundError: pass
            else: raise AssertionError('Authorized root is still present')
            removed.append(str(root))
        os.fsync(parent_fd); os.fchdir(cwd_fd)
        assert all(not os.path.lexists(x) for x in ROOTS)
        assert outside(inventory, header) == protected
        result = {**before, 'status': 'RETIRED_ONLY_SEVEN_EXACT_FULLY_PRESERVED_DIAGNOSTIC_ROOTS',
                  'finished_at': utc(), 'removed': removed, 'origin_deletions': len(removed),
                  'full_absence_verified': True, 'parent_fd_pinned': True, 'fd_based_rmtree': True,
                  'predelete_receipt_sha256': hashlib.sha256(pre_raw).hexdigest(),
                  'durable_offhost_acknowledgement': acknowledgement,
                  'immediate_predelete_no_use': immediate_use,
                  'protected_outside_after': outside(inventory, header), 'protected_identities_unchanged': True,
                  'free_after': inventory.capacity()}
        result['concurrent_free_delta_bytes'] = result['free_after'] - result['free_before']
        result['free_delta_scope'] = 'Concurrent filesystem observations; not exclusive attribution, known SDK peak or production-capacity acceptance.'
    except BaseException as error:
        result = {**before, 'status': 'SEVEN_ROOT_RETIREMENT_ERROR', 'finished_at': utc(),
                  'removed': removed, 'origin_deletions': len(removed), 'removal_started': removal_started,
                  'error': repr(error), 'roots_still_present': [str(x) for x in ROOTS if os.path.lexists(x)],
                  'predelete_receipt_sha256': hashlib.sha256(pre_raw).hexdigest()}
        inventory.save(EVIDENCE / 'RETIREMENT_RESULT.json', canonical(result))
        sys.stdout.buffer.write(canonical(result)); sys.stdout.buffer.flush()
        raise
    finally:
        os.fchdir(cwd_fd); os.close(cwd_fd); os.close(parent_fd)
    inventory.save(EVIDENCE / 'RETIREMENT_RESULT.json', canonical(result))
    sys.stdout.buffer.write(canonical(result)); sys.stdout.buffer.flush()

if __name__ == '__main__':
    main()
