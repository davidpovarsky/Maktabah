from pathlib import Path
import base64
import datetime
import hashlib
import json
import os

base = Path(__file__).parent / 'final-proof'
def load(name):
    return json.loads((base / name).read_bytes())
def pin(name):
    p = base / name
    b = p.read_bytes()
    return {'name': name, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

h, s, r, a, b = [load(n) for n in ['HEADER.json', 'STREAM_RESULT.json', 'SOURCE_REVERIFIED.json', 'ARCHIVE_VERIFIED.json', 'BRIDGE_RESULT.json']]
header_sha = pin('HEADER.json')['sha256']
assert all(x['header_sha256'] == header_sha for x in [s, r, a, b])
assert a['archive']['sha256'] == s['archive_sha256']
assert a['archive']['bytes'] == s['archive_bytes']
assert a['archive'] == b['oracle_archive_verification']['archive']
assert pin('ARCHIVE_VERIFIED.json')['sha256'] == b['oracle_archive_verification']['receipt']['sha256']
assert pin('SOURCE_REVERIFIED.json')['sha256'] == b['source_reverified_sha256']
assert pin('STREAM_RESULT.json')['sha256'] == b['mac_stream_receipt_sha256']
assert h['boundary'] == r['boundary']
assert h['path_stat_sha256'] == s['path_stat_sha256'] == r['path_stat_sha256']
assert h['regular_content_sha256'] == r['regular_content_sha256'] == a['full_regular_content_sha256']
assert all(a['source_counts'][k] == h['summary'][k] for k in a['source_counts'])
assert h['summary']['entries'] == r['entries'] == 37238
assert h['summary']['files'] == 34647 and h['summary']['logical_bytes'] == 6249572185
assert h['unique_payloads'] == s['unique_payloads'] == a['unique_payloads'] == 6467
assert a['physical_members'] == h['unique_payloads'] + len(h['metadata']) + 1 == 6475
assert h['unique_payload_bytes'] == s['unique_payload_bytes'] == a['unique_payload_bytes'] == 2764983196
assert h['prior_archive_references'] == a['prior_archive_references'] == 0
assert a['every_source_file_maps_to_verified_member'] and a['complete_metadata_fields_preserved']
assert r['full_metadata_equal_except_access_time'] and r['original_access_times_preserved_in_archive_metadata']
assert b['source_exit'] == b['receiver_exit'] == 0 and b['signals'] == []
assert b['origin_deletions'] == 0 and b['windows_archive_written'] is False
assert len(h['boundary']['roots']) == 7 and h['dependency_records'] == []
assert h['controller_reference_probes'] and all(x['exit'] == 1 and not x['stdout'] and not x['stderr'] for x in h['controller_reference_probes'])
for proof in [h, s, r]:
    for kind in ['open_use_before', 'open_use_after']:
        assert proof[kind]['lsof_exit'] == 0
        assert proof[kind]['open_files'] == proof[kind]['process_references'] == []
for proof in [h, s, r, a]:
    assert proof['anything_deleted'] is False and proof['builds'] == proof['native_runs'] == 0
receipts = [pin(name) for name in ['HEADER.json', 'STREAM_RESULT.json', 'SOURCE_REVERIFIED.json', 'ARCHIVE_VERIFIED.json', 'BRIDGE_RESULT.json']]
result = {
    'schema': 'otzaria.closed-native-complete-preservation/1',
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'COMPLETE_LOSSLESS_ARCHIVE_AND_SOURCE_MAPPING_VERIFIED_ORIGINS_RETAINED',
    'exact_roots': h['boundary']['roots'],
    'source_summary': h['summary'],
    'unique_payloads': h['unique_payloads'],
    'unique_payload_bytes': h['unique_payload_bytes'],
    'physical_archive_members': a['physical_members'],
    'archive': a['archive'],
    'archive_is_self_contained': True,
    'prior_archive_references': 0,
    'full_archive_readback_and_every_member_hash_verified': True,
    'all_original_regular_file_bytes_mapped_to_verified_members': True,
    'metadata_fields': ['type', 'path', 'mode', 'uid', 'gid', 'device', 'inode', 'link_count', 'atime_ns', 'mtime_ns', 'ctime_ns', 'birthtime_ns', 'flags', 'rdev', 'hardlink_group', 'symlink_target', 'ACL', 'xattr_names_values_hashes'],
    'original_access_times_preserved': True,
    'source_read_induced_access_time_changes': r['atime_changes_observed'],
    'all_other_source_metadata_and_content_reverified_equal': True,
    'source_reverification_utc': r['utc'],
    'path_stat_sha256': r['path_stat_sha256'],
    'regular_content_sha256': r['regular_content_sha256'],
    'source_protected_boundary': r['boundary'],
    'current_no_use_receipt': r['open_use_after'],
    'dependency_records': h['dependency_records'],
    'bounded_controller_reference_probes': h['controller_reference_probes'],
    'external_referrers_exhaustively_excluded': False,
    'receipts': receipts,
    'mac_evidence': h['evidence'],
    'oracle_evidence': b['oracle_evidence'],
    'windows_bridge_evidence': b['control'],
    'archive_stat_at_independent_readback': {'device': 2064, 'inode': 405690, 'size': 1463489048, 'mtime_ns': 1795784159496179237, 'ctime_ns': 1795784234152606291},
    'free_observations_are_concurrent_not_attributed_reclaim': {'mac_inventory_before': h['free_before'], 'mac_inventory_after': h['free_after'], 'mac_stream_after': s['free_after'], 'mac_source_reverify_after': r['free_after'], 'oracle_archive_before': a['free_before'], 'oracle_archive_after': a['free_after']},
    'mac_filesystem_restore_executed': False,
    'restoration_scope': 'Verified every archive payload and complete metadata-to-path mapping; no macOS filesystem restoration was run.',
    'retirement_authorized_by_this_receipt': False,
    'required_before_any_separately_authorized_retirement': ['Fresh archive identity/hash binding', 'Fresh exact source path/stat/content/metadata equality', 'Fresh original source and protected-parent/sibling checks', 'Fresh bounded no-use and dependency checks', 'Durable off-host PREDELETE receipt SHA acknowledgement', 'Exact root-only fd-safe symlink-safe removal'],
    'origin_deletions': 0,
    'builds': 0,
    'native_runs': 0,
    'sdk_or_app_qualification': False,
}
raw = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
p = base / 'COMPLETE_PRESERVATION_VERIFIED.json'
with p.open('xb') as f:
    f.write(raw); f.flush(); os.fsync(f.fileno())
rows = []
for name in [x['name'] for x in receipts] + ['COMPLETE_PRESERVATION_VERIFIED.json']:
    row = pin(name); row['base64'] = base64.b64encode((base / name).read_bytes()).decode(); rows.append(row)
(base / 'TRANSFER_ROWS.json').write_text(json.dumps(rows, separators=(',', ':')) + '\n')
print(json.dumps({'proof': pin(p.name), 'rows': len(rows), 'total_bytes': sum(x['bytes'] for x in rows), 'archive': a['archive'], 'source_count': r['entries']}, sort_keys=True))
