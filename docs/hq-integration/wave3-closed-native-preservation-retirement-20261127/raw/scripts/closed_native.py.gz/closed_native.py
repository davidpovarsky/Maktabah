#!/usr/bin/env python3
"""Complete preservation of seven fixed inactive diagnostic packets. No deletion."""
from pathlib import Path, PurePosixPath
import argparse
import ctypes
import datetime
import gzip
import hashlib
import json
import os
import shutil
import stat
import struct
import subprocess
import sys
import tarfile
import tempfile
import time
import types

sys.dont_write_bytecode = True
CONTROL = Path(__file__).resolve().parent
PLAN_SHA = 'a7020841dad500e79cbda84f1ee85b7eb88225d9153c70d882266c801d97a8cc'
PROVENANCE_SHA = '3c200d7b6ee48b3c75dcc4388ef5a686fd2928fa0dda2ac6ffb3edee19f94d74'
HELPER = Path('/Users/m1/builds/otzaria-wave3-qualified-snapshot-preservation-20261127.2117vow6/qualified_preservation.py')
HELPER_SHA = 'f07264ccf70a75f9b74566d24f65cfdcd6e832e5f3b09231cb6311afae06749e'
SDK = Path('/Users/m1/builds/otzaria-wave1-sdk-20261127/source')
SDK_SHA = 'd6090c03b9ac4e5760941e34f4c04478db4ae59f'
GUARDS = Path('/Users/m1/builds/otzaria-wave3-sdk-pasteboard-plan-20261127.mr4u8199/UNCHANGED_ORIGINAL_GUARDS.json')
GUARDS_SHA = '0094fe3ec56924a9181863c47cf6664f87c7d38797dd62155aa8c04288ff3171'
BASE = Path('/Users/m1/builds/otzaria-root-actions-acceptance-20261126.wjQnLNJl/compact-reader-preview-worktree.5hRb5SYt')
PARENT_INODE = 61610714
MAC_RESERVE = 2415919104
MAX_ARCHIVE = 8589934592
MAX_METADATA_FILE = 67108864

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def capacity(extra=0):
    free = shutil.disk_usage('/System/Volumes/Data').free
    assert free - extra >= MAC_RESERVE, ('Mac reserve', free, extra)
    return free

def save(path, value):
    raw = value if isinstance(value, bytes) else canonical(value)
    capacity(len(raw))
    with path.open('xb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)
    return {'name': path.name, 'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def helper():
    raw = HELPER.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == HELPER_SHA
    h = types.ModuleType('verified_metadata_only_helper'); h.__file__ = str(HELPER)
    exec(compile(raw, str(HELPER), 'exec'), h.__dict__)
    return h

def plan():
    assert digest(CONTROL / 'PLAN.json') == PLAN_SHA
    assert digest(CONTROL / 'PROVENANCE_READONLY.json') == PROVENANCE_SHA
    return json.loads((CONTROL / 'PLAN.json').read_bytes())

def roots():
    return [Path(row['path']) for row in plan()['source_roots']]

def git(root, *args):
    return subprocess.check_output(['/usr/bin/git', '--no-optional-locks', '-C', str(root), *args])

def boundary():
    p = BASE.lstat()
    assert BASE.resolve() == BASE and stat.S_ISDIR(p.st_mode) and p.st_ino == PARENT_INODE
    got = []
    for row in plan()['source_roots']:
        root = Path(row['path']); s = root.lstat()
        assert root.parent == BASE and root.resolve() == root and not root.is_symlink()
        assert stat.S_ISDIR(s.st_mode) and s.st_uid == os.getuid()
        assert s.st_dev == row['device'] and s.st_ino == row['inode']
        got.append({'path': str(root), 'device': s.st_dev, 'inode': s.st_ino,
                    'mode': s.st_mode, 'uid': s.st_uid, 'gid': s.st_gid})
    assert git(SDK, 'rev-parse', 'HEAD').decode().strip() == SDK_SHA
    assert not git(SDK, 'status', '--porcelain=v1', '--untracked-files=no').strip()
    assert digest(GUARDS) == GUARDS_SHA
    guard_rows = json.loads(GUARDS.read_bytes())['original_files']; assert len(guard_rows) == 17
    for row in guard_rows:
        b = (SDK / row['path']).read_bytes()
        assert len(b) == row['bytes'] and hashlib.sha256(b).hexdigest() == row['sha256']
        assert b == git(SDK, 'show', 'HEAD:' + row['path'])
    protected = []
    for q in [BASE, BASE / 'Maktabah', SDK, SDK / 'Dependencies/Middleware', SDK / 'Dependencies/Hanlin',
              Path('/Users/m1/builds/otzaria-shared-agent1-20261126/anytype-formal-original-swift-abi-9bc6420f/source')]:
        s = q.lstat()
        protected.append({'path': str(q), 'device': s.st_dev, 'inode': s.st_ino,
                          'mode': s.st_mode, 'uid': s.st_uid, 'gid': s.st_gid})
    app = BASE / 'Maktabah'
    app_state = {'head': git(app, 'rev-parse', 'HEAD').decode().strip(),
                 'tracked_status': git(app, 'status', '--porcelain=v1', '--untracked-files=no').decode(),
                 'pbx_sha256': digest(app / 'Maktabah.xcodeproj/project.pbxproj')}
    return {'roots': got, 'protected': protected, 'sdk_head': SDK_SHA,
            'original_guard_sha256': GUARDS_SHA, 'app_source': app_state}

def no_use():
    rr = roots()
    process = subprocess.run(['/usr/sbin/lsof', '-nP', '-Fpcfn'], capture_output=True, text=True, timeout=40)
    assert process.returncode in (0, 1)
    hits = []; pid = command = fd = None
    for line in process.stdout.splitlines():
        if line.startswith('p'): pid = line[1:]
        elif line.startswith('c'): command = line[1:]
        elif line.startswith('f'): fd = line[1:]
        elif line.startswith('n') and any(line[1:] == str(r) or line[1:].startswith(str(r) + '/') for r in rr):
            hits.append({'pid': pid, 'command': command, 'fd': fd, 'path': line[1:]})
    ps = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,lstart=,args='], text=True)
    refs = []
    for line in ps.splitlines():
        if any(str(r) in line for r in rr) and int(line.split()[0]) not in (os.getpid(), os.getppid()):
            f = line.split(None, 7)
            refs.append({'pid': int(f[0]), 'ppid': int(f[1]), 'start': ' '.join(f[2:7]),
                         'scope_paths': [str(r) for r in rr if str(r) in line]})
    result = {'utc': utc(), 'open_files': hits, 'process_references': refs,
              'lsof_exit': process.returncode, 'lsof_stderr': process.stderr}
    assert not hits and not refs, result
    return result

def walk():
    for root in roots():
        pending = [root]
        while pending:
            p = pending.pop(); s = p.lstat()
            assert s.st_dev == root.lstat().st_dev
            assert stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode) or stat.S_ISLNK(s.st_mode), str(p)
            yield root, p, s
            if stat.S_ISDIR(s.st_mode):
                with os.scandir(p) as it:
                    pending.extend(sorted((Path(x.path) for x in it), key=os.fsencode, reverse=True))

def private_size(h, p):
    a = h.AttrList(5, 0, 0x80000000, 0, 0, 0, 0x1108); b = ctypes.create_string_buffer(128)
    assert h.LIB.getattrlist(os.fsencode(p), ctypes.byref(a), b, len(b), 0x21) == 0
    assert struct.unpack_from('=I', b.raw, 0)[0] == 44
    assert struct.unpack_from('=IIIII', b.raw, 4) == (0x80000000, 0, 0, 0, 0x1108)
    pv, clone, refs = struct.unpack_from('=qQI', b.raw, 24)
    return {'private_bytes': pv, 'clone_id': clone, 'clone_refcount': refs}

def owner():
    return {'pid': os.getpid(), 'ppid': os.getppid(), 'pgid': os.getpgid(0),
            'start': subprocess.check_output(['/bin/ps', '-p', str(os.getpid()), '-o', 'lstart='], text=True).strip(),
            'script_sha256': digest(Path(__file__)), 'utc': utc()}

class GuardedMetadata:
    def __init__(self, f): self.f = f; self.count = 0
    def write(self, b):
        capacity(len(b)); self.count += len(b); assert self.count <= MAX_METADATA_FILE
        return self.f.write(b)
    def flush(self): self.f.flush()

def inventory():
    start = time.monotonic(); before = boundary(); use_before = no_use(); free = capacity()
    h = helper(); out = Path(tempfile.mkdtemp(prefix='otzaria-wave3-closed-native-preservation-20261127.', dir='/Users/m1/builds'))
    save(out / 'INVENTORY_OWNER.json', owner())
    for source, name in [(Path(__file__), 'closed_native.py'), (HELPER, 'metadata_helper.py'),
                         (CONTROL / 'PLAN.json', 'PLAN.json'), (CONTROL / 'PROVENANCE_READONLY.json', 'PROVENANCE_READONLY.json')]:
        save(out / name, source.read_bytes())
    unique = set(); payload_bytes = 0; stat_hash = hashlib.sha256(); content_hash = hashlib.sha256()
    entry_hash = hashlib.sha256(); payload_hash = hashlib.sha256(); entry_raw_bytes = payload_raw_bytes = 0
    totals = {'entries': 0, 'files': 0, 'directories': 0, 'symlinks': 0, 'logical_bytes': 0,
              'kernel_private_bytes': 0, 'xattr_entries': 0, 'acl_entries': 0, 'hardlinked_files': 0}
    root_counts = {str(r): {'files': 0, 'logical_bytes': 0} for r in roots()}; deps = []; hardlinks = {}
    with (out / 'entries.jsonl.gz').open('xb') as ef, (out / 'payloads.jsonl.gz').open('xb') as pf:
        with gzip.GzipFile(fileobj=GuardedMetadata(ef), mode='wb', mtime=0) as entries, gzip.GzipFile(fileobj=GuardedMetadata(pf), mode='wb', mtime=0) as payloads:
            for root, p, s in walk():
                h.ROOT = root; row = h.entry((p, s)); rel = p.relative_to(BASE).as_posix(); row['path'] = rel
                stat_hash.update(canonical({'path': rel, 'identity': h.identity(s)}))
                totals['entries'] += 1; totals['xattr_entries'] += bool(row['xattrs']); totals['acl_entries'] += row['acl'] is not None
                if row['type'] == 'file':
                    totals['files'] += 1; totals['logical_bytes'] += row['bytes']
                    root_counts[str(root)]['files'] += 1; root_counts[str(root)]['logical_bytes'] += row['bytes']
                    content_hash.update(canonical({'path': rel, 'bytes': row['bytes'], 'sha256': row['sha256']}))
                    allocation = private_size(h, p); row['allocation_observation'] = allocation
                    if s.st_nlink == 1: totals['kernel_private_bytes'] += allocation['private_bytes']
                    else:
                        totals['hardlinked_files'] += 1; hardlinks.setdefault(row['hardlink_group'], []).append(rel)
                    key = (row['sha256'], row['bytes']); member = 'objects/sha256/' + row['sha256']
                    row['payload'] = {'kind': 'new_member', 'member': member}
                    if key not in unique:
                        unique.add(key); payload_bytes += row['bytes']
                        b = canonical({'member': member, 'path': rel, 'bytes': row['bytes'], 'sha256': row['sha256'], 'identity': h.identity(s)})
                        payloads.write(b); payload_hash.update(b); payload_raw_bytes += len(b)
                    if p.name == '.git' or (p.name == 'alternates' and p.parent.name == 'info'):
                        deps.append({'path': rel, 'kind': 'git_metadata', 'sha256': row['sha256'], 'bytes': row['bytes']})
                elif row['type'] == 'directory': totals['directories'] += 1
                else:
                    totals['symlinks'] += 1; resolved = p.resolve(strict=False)
                    deps.append({'path': rel, 'kind': 'symlink', 'target': row['target'], 'resolved': str(resolved),
                                 'exists': resolved.exists(), 'inside_preserved_roots': any(resolved == r or r in resolved.parents for r in roots())})
                b = canonical(row); entries.write(b); entry_hash.update(b); entry_raw_bytes += len(b)
                if totals['entries'] % 1024 == 0: capacity()
        ef.flush(); pf.flush(); os.fsync(ef.fileno()); os.fsync(pf.fileno())
    for row in plan()['source_roots']:
        assert root_counts[row['path']] == {'files': row['files'], 'logical_bytes': row['logical_bytes']}
    assert totals['files'] == 34647 and totals['logical_bytes'] == 6249572185
    assert payload_bytes <= totals['logical_bytes']
    fresh_hash = hashlib.sha256()
    for root, p, s in walk(): fresh_hash.update(canonical({'path': p.relative_to(BASE).as_posix(), 'identity': h.identity(s)}))
    assert fresh_hash.digest() == stat_hash.digest(); assert boundary() == before
    probes = []
    for repo, scopes in [(SDK, ['Tools/OriginalEditor', 'Tools/Hanlin', '.github']), (BASE / 'Maktabah', ['Scripts/CI'])]:
        argv = ['/usr/bin/git', '--no-optional-locks', '-C', str(repo), 'grep', '-n', '-F']
        for r in roots(): argv += ['-e', str(r)]
        rr = subprocess.run(argv + ['--'] + scopes, capture_output=True, text=True)
        assert rr.returncode in (0, 1)
        probes.append({'repository': str(repo), 'scopes': scopes, 'exit': rr.returncode, 'stdout': rr.stdout, 'stderr': rr.stderr})
    metadata = []
    for name in ['entries.jsonl.gz', 'payloads.jsonl.gz', 'closed_native.py', 'metadata_helper.py', 'PLAN.json', 'PROVENANCE_READONLY.json', 'INVENTORY_OWNER.json']:
        p = out / name; metadata.append({'name': name, 'bytes': p.stat().st_size, 'sha256': digest(p)})
    metadata[0].update(uncompressed_sha256=entry_hash.hexdigest(), uncompressed_bytes=entry_raw_bytes)
    metadata[1].update(uncompressed_sha256=payload_hash.hexdigest(), uncompressed_bytes=payload_raw_bytes)
    header = {'schema': 'otzaria.closed-native-self-contained-preservation/1', 'utc': utc(), 'status': 'INVENTORIED_NOT_ARCHIVED_NOT_RETIRED',
              'evidence': str(out), 'base': str(BASE), 'boundary': before, 'script_sha256': digest(Path(__file__)),
              'metadata_helper_sha256': HELPER_SHA, 'plan_sha256': PLAN_SHA, 'summary': totals, 'per_root': root_counts,
              'metadata': metadata, 'unique_payloads': len(unique), 'unique_payload_bytes': payload_bytes,
              'path_stat_sha256': stat_hash.hexdigest(), 'regular_content_sha256': content_hash.hexdigest(),
              'dependency_records': deps, 'hardlink_groups': hardlinks, 'controller_reference_probes': probes,
              'external_referrers_exhaustively_excluded': False, 'prior_archive_references': 0,
              'open_use_before': use_before, 'open_use_after': no_use(), 'free_before': free, 'free_after': capacity(),
              'seconds': time.monotonic() - start, 'anything_deleted': False, 'builds': 0, 'native_runs': 0}
    receipt = save(out / 'HEADER.json', header)
    print(json.dumps({'status': header['status'], 'evidence': str(out), 'header': receipt, 'summary': totals,
                      'unique_payloads': len(unique), 'unique_payload_bytes': payload_bytes, 'dependencies': deps,
                      'reference_probe_matches': [r for r in probes if r['exit'] == 0], 'free_after': header['free_after'], 'seconds': header['seconds']}), flush=True)

def load_header(out, expected):
    assert out.parent == Path('/Users/m1/builds') and out.name.startswith('otzaria-wave3-closed-native-preservation-20261127.')
    assert digest(out / 'HEADER.json') == expected
    header = json.loads((out / 'HEADER.json').read_bytes())
    assert header['script_sha256'] == digest(Path(__file__)) and header['boundary'] == boundary()
    for row in header['metadata']:
        p = out / row['name']; assert p.stat().st_size == row['bytes'] and digest(p) == row['sha256']
    return header

class HashingReader:
    def __init__(self, f): self.f = f; self.sha = hashlib.sha256(); self.count = 0
    def read(self, n=-1):
        b = self.f.read(n); self.sha.update(b); self.count += len(b); return b

class HashingWriter:
    def __init__(self, f): self.f = f; self.sha = hashlib.sha256(); self.count = 0
    def write(self, b):
        capacity(); assert self.count + len(b) <= MAX_ARCHIVE
        self.f.write(b); self.sha.update(b); self.count += len(b); return len(b)
    def flush(self): self.f.flush()

def stream(out, expected):
    header = load_header(out, expected); h = helper(); before_use = no_use(); start = time.monotonic()
    save(out / 'STREAM_OWNER.json', owner()); writer = HashingWriter(sys.stdout.buffer); count = raw_bytes = 0
    with gzip.GzipFile(fileobj=writer, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as tar:
            for name in ['HEADER.json'] + [r['name'] for r in header['metadata']]:
                p = out / name; ti = tarfile.TarInfo('metadata/' + name); ti.size = p.stat().st_size; ti.mode = 0o600
                with p.open('rb') as f: tar.addfile(ti, f)
            with gzip.open(out / 'payloads.jsonl.gz', 'rb') as records:
                for line in records:
                    row = json.loads(line); rel = PurePosixPath(row['path'])
                    assert not rel.is_absolute() and '..' not in rel.parts and rel.parts[0] in {r.name for r in roots()}
                    p = BASE / str(rel); s = p.lstat(); assert tuple(row['identity']) == h.identity(s)
                    assert row['member'] == 'objects/sha256/' + row['sha256']
                    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
                    with os.fdopen(fd, 'rb') as f:
                        assert h.identity(os.fstat(f.fileno())) == tuple(row['identity'])
                        source = HashingReader(f); ti = tarfile.TarInfo(row['member']); ti.size = row['bytes']; ti.mode = 0o600
                        tar.addfile(ti, source)
                        assert source.count == row['bytes'] and source.sha.hexdigest() == row['sha256']
                        assert h.identity(os.fstat(f.fileno())) == tuple(row['identity'])
                    assert h.identity(p.lstat()) == tuple(row['identity']); count += 1; raw_bytes += row['bytes']
    writer.flush(); assert count == header['unique_payloads'] and raw_bytes == header['unique_payload_bytes']
    stat_hash = hashlib.sha256()
    for root, p, s in walk(): stat_hash.update(canonical({'path': p.relative_to(BASE).as_posix(), 'identity': h.identity(s)}))
    assert stat_hash.hexdigest() == header['path_stat_sha256']; assert boundary() == header['boundary']
    result = {'status': 'EXACT_SELF_CONTAINED_STREAM_COMPLETED_NOT_RETIRED', 'utc': utc(), 'header_sha256': expected,
              'archive_bytes': writer.count, 'archive_sha256': writer.sha.hexdigest(), 'unique_payloads': count,
              'unique_payload_bytes': raw_bytes, 'path_stat_sha256': stat_hash.hexdigest(), 'open_use_before': before_use,
              'open_use_after': no_use(), 'free_after': capacity(), 'seconds': time.monotonic() - start,
              'anything_deleted': False, 'builds': 0, 'native_runs': 0}
    save(out / 'STREAM_RESULT.json', result)
    print(json.dumps(result), file=sys.stderr, flush=True)

def reverify(out, expected):
    header = load_header(out, expected); h = helper(); start = time.monotonic(); count = 0; atime = 0
    stat_hash = hashlib.sha256(); content_hash = hashlib.sha256(); use_before = no_use()
    with gzip.open(out / 'entries.jsonl.gz', 'rb') as entries:
        for root, p, s in walk():
            line = entries.readline(); assert line
            old = json.loads(line); h.ROOT = root; now = h.entry((p, s)); now['path'] = p.relative_to(BASE).as_posix()
            compare = dict(old); compare.pop('payload', None); compare.pop('allocation_observation', None)
            atime += now['atime_ns'] != compare['atime_ns']
            now.pop('atime_ns'); compare.pop('atime_ns')
            assert now == compare, ('Full current source mismatch', old['path'])
            stat_hash.update(canonical({'path': now['path'], 'identity': h.identity(s)}))
            if now['type'] == 'file': content_hash.update(canonical({'path': now['path'], 'bytes': now['bytes'], 'sha256': now['sha256']}))
            count += 1
            if count % 1024 == 0: capacity()
        assert not entries.read(1)
    assert count == header['summary']['entries'] and stat_hash.hexdigest() == header['path_stat_sha256']
    assert content_hash.hexdigest() == header['regular_content_sha256'] and boundary() == header['boundary']
    result = {'status': 'FULL_SOURCE_CONTENT_METADATA_REVERIFIED_NO_RETIREMENT', 'utc': utc(), 'header_sha256': expected,
              'entries': count, 'path_stat_sha256': stat_hash.hexdigest(), 'regular_content_sha256': content_hash.hexdigest(),
              'full_metadata_equal_except_access_time': True, 'atime_changes_observed': atime,
              'original_access_times_preserved_in_archive_metadata': True, 'open_use_before': use_before, 'open_use_after': no_use(),
              'boundary': header['boundary'], 'seconds': time.monotonic() - start, 'free_after': capacity(),
              'anything_deleted': False, 'builds': 0, 'native_runs': 0}
    receipt = save(out / 'SOURCE_REVERIFIED.json', result)
    print(json.dumps({'status': result['status'], 'receipt': receipt, 'entries': count, 'atime_changes': atime,
                      'seconds': result['seconds'], 'free_after': result['free_after']}), flush=True)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('mode', choices=['inventory', 'stream', 'reverify'])
    ap.add_argument('--evidence', type=Path); ap.add_argument('--header-sha256'); args = ap.parse_args()
    if args.mode == 'inventory': inventory()
    else:
        assert args.evidence and args.header_sha256
        if args.mode == 'stream': stream(args.evidence, args.header_sha256)
        else: reverify(args.evidence, args.header_sha256)

if __name__ == '__main__':
    main()
