#!/usr/bin/env python3
"""One owned, pinned bridge; no ACK before byte-exact durable off-host evidence."""
from pathlib import Path
import base64
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import os
import queue
import shlex
import shutil
import subprocess
import sys
import threading

ARTIFACTS = Path(r'C:\Users\DAVID\.codex\artifacts')
OUT = ARTIFACTS / 'otzaria-wave3-closed-native-retirement-20261127'
MAC = '/Users/m1/builds/otzaria-wave3-closed-native-preservation-20261127.o5ye8las'
ORACLE = '/mnt/development/projects/diagnostics/otzaria-wave3-closed-native-preservation-20261127.fcws2jok'
BASE = '/Users/m1/builds/otzaria-root-actions-acceptance-20261126.wjQnLNJl/compact-reader-preview-worktree.5hRb5SYt'
ROOTS = [BASE + '/' + name for name in [
    'actual-candidate-focused-native.EeUZ35lg', 'continued-authority-focused.4m2Xqttt',
    'actual-narrow-application-toolbar-focus.n1VgwMQf', 'actual-phone-and-native-witness.Lj8qFaXi',
    'exact-standalone-reader-release-native.UperJJ5L', 'actual-reader-publication-note-focus.h1iNTzUP',
    'wave3-native-0db0ab78-20261127']]
PROOF_SHA = 'fc6acb50b51ece3133921d746cbdb06fc8869e0c541f057e4a1240ffe835f6a7'
SOURCE_SHA = '13fd31b5bde07fd7138ac39d9c7db2c0954b42bec0fc711b83cdf333ce790112'
VERIFIED_SHA = '50987d6a7daa36458322f755068f6730609ad470309ab2fa6cd4e96fdcf0720e'
MAC_SCRIPT_SHA = 'aea27961c4135686539cb9dbc2253bb8530b20452c899345d7abade61e818818'
ORACLE_SCRIPT_SHA = 'd9a9960c983b0684432ddf9f0b933afa7cd38bbec876baa0cbc4d60fd811c275'
FLOOR = 2415919104
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8']

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def canonical(value): return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
def command(alias, argv): return SSH + [alias, shlex.join(argv)]

def save(name, value):
    assert '/' not in name and '\\' not in name
    raw = value if isinstance(value, bytes) else canonical(value)
    assert len(raw) <= 2097152 and shutil.disk_usage(OUT).free - len(raw) >= FLOOR
    p = OUT / name
    with p.open('xb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())
    assert p.read_bytes() == raw
    return {'path': str(p), 'bytes': len(raw), 'sha256': sha(raw)}

def child_identity(process):
    method = ctypes.windll.kernel32.GetProcessTimes
    method.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    method.restype = wintypes.BOOL
    fields = [wintypes.FILETIME() for _ in range(4)]
    assert method(wintypes.HANDLE(int(process._handle)), *[ctypes.byref(x) for x in fields])
    return {'pid': process.pid, 'creation_filetime_100ns': (fields[0].dwHighDateTime << 32) | fields[0].dwLowDateTime,
            'retained_popen_handle': True}

def run_capture(label, argv, data=None, timeout=60):
    save(label + '.intent.json', {'utc': utc(), 'argv': argv, 'input_sha256': sha(data) if data else None})
    r = subprocess.run(argv, input=data, capture_output=True, timeout=timeout)
    save(label + '.stdout.json', r.stdout); save(label + '.stderr.log', r.stderr)
    assert r.returncode == 0, (label, r.returncode, r.stderr.decode(errors='replace'))
    return r.stdout

def script_check(alias, directory, name, expected):
    code = ('from pathlib import Path\nimport hashlib,json\n'
            'p=Path(' + repr(directory + '/' + name) + ')\n'
            'assert p.resolve()==p and not p.is_symlink()\n'
            'b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==' + repr(expected) + '\n'
            'print(json.dumps({"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}))\n')
    return run_capture(alias + '-script', command(alias, ['/usr/bin/python3' if alias == 'scaleway-mac' else 'python3', '-']), code.encode(), 30)

def oracle_receipt(name, raw):
    assert name in ('RETIREMENT_CURRENT_BINDINGS.json', 'RETIREMENT_PREDELETE.json',
                    'RETIREMENT_RESULT.json', 'RETIREMENT_ACK.json')
    expected = sha(raw)
    code = '''from pathlib import Path
import hashlib,json,os,shutil,stat,sys
base=Path(ORACLE_BASE);s=base.lstat()
assert stat.S_ISDIR(s.st_mode) and s.st_dev==2064 and s.st_ino==397500
p=base/NAME;raw=sys.stdin.buffer.read(2097153)
assert len(raw)<=2097152 and hashlib.sha256(raw).hexdigest()==EXPECTED
assert shutil.disk_usage(base).free-len(raw)>=687865856
fd=os.open(str(p),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
dfd=os.open(str(base),os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);os.fsync(dfd);os.close(dfd)
assert p.read_bytes()==raw
print(json.dumps({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'file_and_directory_fsynced':True}))
'''
    code = 'ORACLE_BASE=' + repr(ORACLE) + '\nNAME=' + repr(name) + '\nEXPECTED=' + repr(expected) + '\n' + code
    output = run_capture(name + '-oracle-copy', command('torah-social', ['python3', '-c', code]), raw, 30)
    result = json.loads(output)
    assert result['sha256'] == expected and result['bytes'] == len(raw) and result['file_and_directory_fsynced']
    return result

def main():
    assert os.name == 'nt' and sys.argv[1:] == ['--execute-root-authorized-seven-roots']
    assert ARTIFACTS.is_dir() and shutil.disk_usage(ARTIFACTS).free >= FLOOR + 67108864
    OUT.mkdir(exist_ok=False)
    own_raw = Path(__file__).read_bytes(); save('retire_closed_windows.py', own_raw)
    script_check('torah-social', ORACLE, 'current_closed_archive.py', ORACLE_SCRIPT_SHA)
    script_check('scaleway-mac', MAC, 'retire_closed_native.py', MAC_SCRIPT_SHA)
    current_raw = run_capture('CURRENT_ARCHIVE', command('torah-social', ['python3', '-B', ORACLE + '/current_closed_archive.py']), timeout=120)
    current = json.loads(current_raw)
    assert current['status'] == 'CURRENT_SELF_CONTAINED_ARCHIVE_AND_RECEIPTS_REHASHED'
    assert current['complete_preservation_sha256'] == PROOF_SHA and current['source_reverified_sha256'] == SOURCE_SHA
    assert current['archive_verification_sha256'] == VERIFIED_SHA
    assert [r['path'] for r in current['exact_roots']] == ROOTS
    current_pin = save('RETIREMENT_CURRENT_BINDINGS.json', current_raw)
    oracle_receipt('RETIREMENT_CURRENT_BINDINGS.json', current_raw)
    envelope = {'current_base64': base64.b64encode(current_raw).decode(),
                'current_sha256': current_pin['sha256'], 'retirement_script_sha256': MAC_SCRIPT_SHA}
    argv = command('scaleway-mac', ['/usr/bin/python3', '-B', MAC + '/retire_closed_native.py', '--execute-root-authorized-seven-roots'])
    save('MAC_RETIREMENT_SPAWN_INTENT.json', {'utc': utc(), 'parent_pid': os.getpid(), 'argv': argv,
         'script_sha256': MAC_SCRIPT_SHA, 'bridge_sha256': sha(own_raw), 'roots': ROOTS,
         'complete_preservation_sha256': PROOF_SHA, 'current_archive_sha256': current_pin['sha256']})
    process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    identity = child_identity(process)
    save('MAC_RETIREMENT_PROCESS.json', {**identity, 'utc': utc(), 'bridge_pid': os.getpid()})
    lines = queue.Queue(); errors = []
    def stdout_reader():
        while True:
            line = process.stdout.readline(2097153)
            lines.put(line)
            if not line: break
    def stderr_reader():
        for block in iter(lambda: process.stderr.read(65536), b''):
            errors.append(block)
            assert sum(map(len, errors)) <= 2097152
    out_thread = threading.Thread(target=stdout_reader, daemon=True)
    err_thread = threading.Thread(target=stderr_reader, daemon=True)
    out_thread.start(); err_thread.start()
    ack_sent = False
    try:
        process.stdin.write(canonical(envelope)); process.stdin.flush()
        first = lines.get(timeout=120)
        assert first and len(first) <= 2097152, 'No valid predelete output; no ACK sent'
        pre = json.loads(first)
        assert pre['status'] == 'EXACT_SEVEN_ROOTS_VERIFIED_AWAITING_DURABLE_OFFHOST_ACK'
        assert pre['roots'] == ROOTS and pre['origin_deletions'] == 0
        assert pre['complete_preservation_sha256'] == PROOF_SHA and pre['source_reverified_sha256'] == SOURCE_SHA
        assert pre['current_archive_bindings_sha256'] == current_pin['sha256'] and pre['script_sha256'] == MAC_SCRIPT_SHA
        assert child_identity(process) == identity and process.poll() is None
        pre_pin = save('RETIREMENT_PREDELETE.json', first)
        oracle_pre = oracle_receipt('RETIREMENT_PREDELETE.json', first)
        ack = {'ack': 'DURABLE_WINDOWS_ORACLE_EXACT_SEVEN_ROOTS_PREDELETE', 'sha256': pre_pin['sha256'],
               'complete_preservation_sha256': PROOF_SHA, 'source_reverified_sha256': SOURCE_SHA,
               'current_archive_bindings_sha256': current_pin['sha256']}
        save('RETIREMENT_ACK.json', ack); oracle_receipt('RETIREMENT_ACK.json', canonical(ack))
        process.stdin.write(canonical(ack)); process.stdin.flush(); ack_sent = True; process.stdin.close()
        print(json.dumps({'status': 'EXACT_PREDELETE_DURABLE_ON_WINDOWS_AND_ORACLE_ACK_SENT',
                          'predelete': pre_pin, 'oracle_predelete': oracle_pre, 'mac_owner': pre['owner_process']}), flush=True)
        final_raw = lines.get(timeout=240)
        assert final_raw and len(final_raw) <= 2097152
        final_pin = save('RETIREMENT_RESULT.json', final_raw)
        oracle_final = oracle_receipt('RETIREMENT_RESULT.json', final_raw)
        code = process.wait(timeout=60); out_thread.join(10); err_thread.join(10)
        save('RETIREMENT_STDERR.log', b''.join(errors))
        extra = []
        while not lines.empty():
            line = lines.get_nowait()
            if line: extra.append(line)
        save('RETIREMENT_EXTRA_STDOUT.log', b''.join(extra))
        result = json.loads(final_raw)
        assert code == 0 and result['status'] == 'RETIRED_ONLY_SEVEN_EXACT_FULLY_PRESERVED_DIAGNOSTIC_ROOTS'
        assert result['removed'] == ROOTS and result['origin_deletions'] == 7
        assert result['full_absence_verified'] and result['protected_identities_unchanged']
        print(json.dumps({'status': result['status'], 'receipt': final_pin, 'oracle_receipt': oracle_final,
                          'predelete': pre_pin, 'mac_receipt': MAC + '/RETIREMENT_RESULT.json',
                          'removed': result['removed'], 'free_before': result['free_before'], 'free_after': result['free_after'],
                          'concurrent_free_delta_bytes': result['concurrent_free_delta_bytes'],
                          'protected_identities_unchanged': True, 'full_absence_verified': True,
                          'builds': 0, 'native_runs': 0}), flush=True)
    except BaseException as error:
        if not process.stdin.closed: process.stdin.close()
        if not ack_sent:
            try: process.wait(timeout=110)
            except subprocess.TimeoutExpired: pass
        err_thread.join(2)
        failure = {'status': 'EXACT_SEVEN_ROOT_BRIDGE_ERROR', 'utc': utc(), 'error': repr(error),
                   'ack_sent': ack_sent, 'ssh_identity': identity, 'ssh_exit': process.poll(),
                   'signals_sent': [], 'stderr': b''.join(errors).decode(errors='replace'),
                   'origin_state': 'No removal ACK sent' if not ack_sent else 'Read exact Mac RETIREMENT_RESULT; never infer rollback from a bridge error'}
        receipt = save('RETIREMENT_BRIDGE_FAILURE.json', failure)
        print(json.dumps({'status': failure['status'], 'receipt': receipt, 'ack_sent': ack_sent}), flush=True)
        raise

if __name__ == '__main__':
    main()
