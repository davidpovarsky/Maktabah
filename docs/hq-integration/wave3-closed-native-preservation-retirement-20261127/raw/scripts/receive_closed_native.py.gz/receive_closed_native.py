#!/usr/bin/env python3
"""Receive and fully verify one self-contained archive. Never changes Mac sources."""
from pathlib import Path, PurePosixPath
import argparse
import base64
import datetime
import gzip
import hashlib
import json
import os
import shutil
import sys
import tarfile
import time

FLOOR = 687865856
MAXIMUM = 8589934592
PLAN_SHA = 'a7020841dad500e79cbda84f1ee85b7eb88225d9153c70d882266c801d97a8cc'
HELPER_SHA = 'f07264ccf70a75f9b74566d24f65cfdcd6e832e5f3b09231cb6311afae06749e'
MAC_SCRIPT_SHA = '08db63301219a38ad9175702140ded020278c737216461890067f99f1dd3177c'
PARENT = Path('/mnt/development/projects/diagnostics')

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def canonical(o): return (json.dumps(o, sort_keys=True, separators=(',', ':')) + '\n').encode()
def sha(b): return hashlib.sha256(b).hexdigest()
def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()
def capacity(out, amount=0):
    free = shutil.disk_usage(out).free
    assert free - amount >= FLOOR, ('Oracle Data reserve', free, amount)
    return free
def save(out, name, value):
    assert '/' not in name and name not in ('.', '..')
    body = value if isinstance(value, bytes) else canonical(value)
    capacity(out, len(body))
    with (out / name).open('xb') as f:
        f.write(body); f.flush(); os.fsync(f.fileno())
    assert (out / name).read_bytes() == body
    return {'path': str(out / name), 'bytes': len(body), 'sha256': sha(body)}

def check_root(out):
    assert out.parent == PARENT and out.name.startswith('otzaria-wave3-closed-native-preservation-20261127.')
    assert out.resolve() == out and out.is_dir() and not out.is_symlink()
    assert out.stat().st_dev == 2064, 'Expected existing Oracle Data filesystem identity changed'
    assert out.stat().st_uid == os.getuid()

def metadata_lines(path, expected):
    h = hashlib.sha256(); total = 0
    with gzip.open(path, 'rb') as f:
        for line in f:
            total += len(line); assert total <= 67108864; h.update(line)
            yield json.loads(line)
    assert total == expected['uncompressed_bytes'] and h.hexdigest() == expected['uncompressed_sha256']

def verify(archive, out, expected_header):
    start = time.monotonic(); header = None; wanted_metadata = {}; metadata = {}; expected_objects = None
    objects_seen = set(); members_seen = set(); object_bytes = 0
    with gzip.open(archive, 'rb') as gz:
        with tarfile.open(fileobj=gz, mode='r|') as tar:
            for m in tar:
                assert m.isfile() and m.name not in members_seen
                members_seen.add(m.name)
                if header is None:
                    assert m.name == 'metadata/HEADER.json' and m.size <= 1048576
                    raw = tar.extractfile(m).read(); assert sha(raw) == expected_header
                    header = json.loads(raw)
                    assert header['schema'] == 'otzaria.closed-native-self-contained-preservation/1'
                    assert header['plan_sha256'] == PLAN_SHA and header['metadata_helper_sha256'] == HELPER_SHA
                    assert header['script_sha256'] == MAC_SCRIPT_SHA and header['prior_archive_references'] == 0
                    assert header['boundary']['sdk_head'] == 'd6090c03b9ac4e5760941e34f4c04478db4ae59f'
                    assert len(header['boundary']['roots']) == 7
                    wanted_metadata = {'metadata/' + r['name']: r for r in header['metadata']}
                    assert len(wanted_metadata) == 7
                    metadata['HEADER.json'] = save(out, 'HEADER.json', raw)
                    continue
                if m.name in wanted_metadata:
                    row = wanted_metadata.pop(m.name)
                    assert m.size == row['bytes'] and m.size <= 67108864
                    raw = tar.extractfile(m).read(); assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
                    assert '/' not in row['name'] and row['name'] not in ('.', '..')
                    metadata[row['name']] = save(out, row['name'], raw)
                    continue
                assert not wanted_metadata and m.name.startswith('objects/sha256/')
                if expected_objects is None:
                    expected_objects = {}
                    row = next(r for r in header['metadata'] if r['name'] == 'payloads.jsonl.gz')
                    for value in metadata_lines(out / row['name'], row):
                        assert value['member'] == 'objects/sha256/' + value['sha256']
                        assert value['member'] not in expected_objects
                        expected_objects[value['member']] = value
                    assert len(expected_objects) == header['unique_payloads']
                assert m.name in expected_objects and m.name not in objects_seen
                row = expected_objects[m.name]; assert m.size == row['bytes']
                h = hashlib.sha256(); n = 0; f = tar.extractfile(m)
                for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b); n += len(b)
                assert n == row['bytes'] and h.hexdigest() == row['sha256']
                objects_seen.add(m.name); object_bytes += n; capacity(out)
        # Consume the gzip trailer/CRC and refuse hidden nonzero data beyond tar EOF.
        for b in iter(lambda: gz.read(1024 * 1024), b''): assert not any(b)
    assert header is not None and not wanted_metadata and expected_objects is not None
    assert objects_seen == set(expected_objects) and object_bytes == header['unique_payload_bytes']
    assert len(members_seen) == len(expected_objects) + 8
    assert digest(out / 'PLAN.json') == PLAN_SHA and digest(out / 'metadata_helper.py') == HELPER_SHA
    assert digest(out / 'closed_native.py') == MAC_SCRIPT_SHA
    plan = json.loads((out / 'PLAN.json').read_bytes()); root_names = {Path(r['path']).name for r in plan['source_roots']}
    assert len(root_names) == 7
    counts = {'entries': 0, 'files': 0, 'directories': 0, 'symlinks': 0, 'logical_bytes': 0,
              'xattr_entries': 0, 'acl_entries': 0, 'hardlinked_files': 0}
    paths = set(); hardlinks = {}; contents = hashlib.sha256(); referenced = set(); root_counts = {r: 0 for r in root_names}
    item = next(r for r in header['metadata'] if r['name'] == 'entries.jsonl.gz')
    for row in metadata_lines(out / item['name'], item):
        p = PurePosixPath(row['path'])
        assert not p.is_absolute() and '..' not in p.parts and p.parts[0] in root_names and row['path'] not in paths
        paths.add(row['path']); counts['entries'] += 1
        for key in ['mode', 'uid', 'gid', 'device', 'inode', 'nlink', 'bytes', 'mtime_ns', 'atime_ns', 'ctime_ns', 'birthtime_ns', 'flags', 'rdev']:
            assert isinstance(row[key], int)
        counts['xattr_entries'] += bool(row['xattrs']); counts['acl_entries'] += row['acl'] is not None
        for a in row['xattrs']:
            assert base64.b64decode(a['name_base64'])
            raw = base64.b64decode(a['value_base64']); assert len(raw) == a['bytes'] and sha(raw) == a['sha256']
        if row['acl'] is not None:
            a = row['acl']; raw = base64.b64decode(a['text_base64']); assert len(raw) == a['bytes'] and sha(raw) == a['sha256']
        if row['type'] == 'file':
            counts['files'] += 1; counts['logical_bytes'] += row['bytes']; root_counts[p.parts[0]] += 1
            assert row['payload'] == {'kind': 'new_member', 'member': 'objects/sha256/' + row['sha256']}
            member = row['payload']['member']; assert member in objects_seen
            assert expected_objects[member]['bytes'] == row['bytes'] and expected_objects[member]['sha256'] == row['sha256']
            referenced.add(member); contents.update(canonical({'path': row['path'], 'bytes': row['bytes'], 'sha256': row['sha256']}))
            if row['nlink'] > 1:
                counts['hardlinked_files'] += 1; hardlinks.setdefault(row['hardlink_group'], []).append(row['path'])
        elif row['type'] == 'directory': counts['directories'] += 1
        else:
            assert row['type'] == 'symlink'; counts['symlinks'] += 1
            assert base64.b64decode(row['target_bytes_base64']) == os.fsencode(row['target'])
    assert referenced == objects_seen and contents.hexdigest() == header['regular_content_sha256']
    assert hardlinks == header['hardlink_groups']
    for k, v in counts.items(): assert v == header['summary'][k], k
    for r in plan['source_roots']: assert root_counts[Path(r['path']).name] == r['files']
    assert counts['files'] == 34647 and counts['logical_bytes'] == 6249572185
    return {'status': 'ALL_ARCHIVE_MEMBERS_AND_FULL_METADATA_MAPPING_VERIFIED_NOT_RETIRED', 'utc': utc(),
            'header_sha256': expected_header, 'physical_members': len(members_seen), 'unique_payloads': len(objects_seen),
            'unique_payload_bytes': object_bytes, 'source_counts': counts, 'full_regular_content_sha256': contents.hexdigest(),
            'metadata': metadata, 'prior_archive_references': 0, 'every_source_file_maps_to_verified_member': True,
            'complete_metadata_fields_preserved': True, 'mac_filesystem_restore_executed': False,
            'source_fresh_reverification_still_required': True, 'seconds': time.monotonic() - start,
            'anything_deleted': False, 'builds': 0, 'native_runs': 0}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--evidence', type=Path, required=True)
    ap.add_argument('--header-sha256', required=True); args = ap.parse_args(); out = args.evidence
    check_root(out); assert len(args.header_sha256) == 64
    before = capacity(out); assert before >= FLOOR + MAXIMUM + 67108864
    target = out / 'closed-native-self-contained.tar.gz'; partial = target.with_suffix('.gz.partial')
    assert not target.exists() and not partial.exists()
    save(out, 'RECEIVE_STARTED.json', {'utc': utc(), 'pid': os.getpid(), 'pgid': os.getpgid(0),
         'source_script_sha256': digest(Path(__file__)), 'header_sha256': args.header_sha256,
         'expected_device': 2064, 'actual_device': out.stat().st_dev, 'output_cap_bytes': MAXIMUM,
         'floor_bytes': FLOOR, 'free_before': before, 'parent': str(out.parent), 'started_ns': time.time_ns()})
    h = hashlib.sha256(); count = 0
    try:
        with partial.open('xb') as f:
            for b in iter(lambda: sys.stdin.buffer.read(1024 * 1024), b''):
                assert count + len(b) <= MAXIMUM; capacity(out, len(b))
                f.write(b); h.update(b); count += len(b)
            f.flush(); os.fsync(f.fileno())
        assert count > 0 and partial.stat().st_size == count and digest(partial) == h.hexdigest()
        proof = verify(partial, out, args.header_sha256)
        assert not target.exists(); os.rename(partial, target)
        fd = os.open(out, os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
        proof.update(archive={'path': str(target), 'bytes': count, 'sha256': h.hexdigest()},
                     free_before=before, free_after=capacity(out), receiver_script_sha256=digest(Path(__file__)))
        receipt = save(out, 'ARCHIVE_VERIFIED.json', proof)
        print(json.dumps({'status': proof['status'], 'receipt': receipt, 'archive': proof['archive'],
                          'source_counts': proof['source_counts'], 'unique_payloads': proof['unique_payloads'],
                          'unique_payload_bytes': proof['unique_payload_bytes'], 'free_after': proof['free_after']}), flush=True)
    except BaseException as error:
        save(out, 'RECEIVE_FAILURE.json', {'utc': utc(), 'error': repr(error), 'received_bytes': count,
             'partial_path': str(partial), 'partial_exists': partial.exists(), 'anything_deleted': False,
             'free_after': shutil.disk_usage(out).free})
        raise

if __name__ == '__main__': main()
