#!/usr/bin/env python3
"""Pinned SSH memory-pipe preservation. No Windows archive and no source removal."""
from pathlib import Path
import base64
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import tempfile
import time

assert os.name == 'nt'
ARTIFACTS = Path(r'C:\Users\DAVID\.codex\artifacts')
MAC_CONTROL = '/Users/m1/builds/otzaria-wave3-closed-native-control-20261127.431ix46_'
MAC_EVIDENCE = '/Users/m1/builds/otzaria-wave3-closed-native-preservation-20261127.o5ye8las'
ORACLE_EVIDENCE = '/mnt/development/projects/diagnostics/otzaria-wave3-closed-native-preservation-20261127.fcws2jok'
HEADER_SHA = 'd6b5e2a0d8a403248b7919d4d7fd283df957f2b3524f5239a836f72f364856ee'
MAC_SCRIPT_SHA = '08db63301219a38ad9175702140ded020278c737216461890067f99f1dd3177c'
RECEIVER_SHA = '132ff06ef8341d689c54c4d0d594e4fbf02ddb05307358cab39ecb68644df9bf'
FLOOR = 2415919104
TIMEOUT = 1800
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8']

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def save(out, name, value):
    b = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    assert shutil.disk_usage(out).free - len(b) >= FLOOR
    with (out / name).open('xb') as f: f.write(b); f.flush(); os.fsync(f.fileno())
    assert (out / name).read_bytes() == b
    return {'path': str(out / name), 'bytes': len(b), 'sha256': sha(b)}

def remote_command(alias, argv): return SSH + [alias, shlex.join(argv)]

GetProcessTimes = ctypes.windll.kernel32.GetProcessTimes
GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
GetProcessTimes.restype = wintypes.BOOL
def child_identity(p):
    times = [wintypes.FILETIME() for _ in range(4)]
    assert GetProcessTimes(wintypes.HANDLE(int(p._handle)), *[ctypes.byref(t) for t in times])
    return {'pid': p.pid, 'creation_filetime_100ns': (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime,
            'retained_popen_handle': True, 'observed_at': utc()}

def read_remote(out, label, alias, code, timeout=60):
    argv = remote_command(alias, ['/usr/bin/python3' if alias == 'scaleway-mac' else 'python3', '-'])
    r = subprocess.run(argv, input=code.encode(), capture_output=True, timeout=timeout)
    save(out, label + '.stdout.json', r.stdout); save(out, label + '.stderr.log', r.stderr)
    assert r.returncode == 0, (label, r.returncode, r.stderr.decode(errors='replace'))
    return json.loads(r.stdout)

def source_receipt_code(path):
    return 'from pathlib import Path\nimport base64,hashlib,json\np=Path(' + repr(path) + ')\nb=p.read_bytes()\nprint(json.dumps({"path":str(p),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"base64":base64.b64encode(b).decode()}))\n'

def main():
    assert ARTIFACTS.is_dir() and shutil.disk_usage(ARTIFACTS).free >= FLOOR + 67108864
    out = Path(tempfile.mkdtemp(prefix='otzaria-wave3-closed-native-bridge-20261127.', dir=ARTIFACTS))
    save(out, 'bridge_closed_native.py', Path(__file__).read_bytes())
    mac_code = 'from pathlib import Path\nimport hashlib,json,shutil\np=Path(' + repr(MAC_CONTROL + '/closed_native.py') + ')\nh=Path(' + repr(MAC_EVIDENCE + '/HEADER.json') + ')\nassert hashlib.sha256(p.read_bytes()).hexdigest()==' + repr(MAC_SCRIPT_SHA) + '\nassert hashlib.sha256(h.read_bytes()).hexdigest()==' + repr(HEADER_SHA) + '\nassert shutil.disk_usage(p).free>=2415919104\nprint(json.dumps({"script_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"header_sha256":hashlib.sha256(h.read_bytes()).hexdigest(),"free":shutil.disk_usage(p).free}))\n'
    oracle_code = 'from pathlib import Path\nimport hashlib,json,os,shutil\np=Path(' + repr(ORACLE_EVIDENCE + '/receive_closed_native.py') + ')\nassert p.parent.stat().st_dev==2064 and p.parent.stat().st_uid==os.getuid()\nassert hashlib.sha256(p.read_bytes()).hexdigest()==' + repr(RECEIVER_SHA) + '\nassert shutil.disk_usage(p).free>=687865856+8589934592+67108864\nprint(json.dumps({"script_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"device":p.stat().st_dev,"free":shutil.disk_usage(p).free}))\n'
    mp = read_remote(out, 'MAC_PREFLIGHT', 'scaleway-mac', mac_code)
    op = read_remote(out, 'ORACLE_PREFLIGHT', 'torah-social', oracle_code)
    receiver_argv = remote_command('torah-social', ['python3', '-B', ORACLE_EVIDENCE + '/receive_closed_native.py', '--evidence', ORACLE_EVIDENCE, '--header-sha256', HEADER_SHA])
    source_argv = remote_command('scaleway-mac', ['/usr/bin/python3', '-B', MAC_CONTROL + '/closed_native.py', 'stream', '--evidence', MAC_EVIDENCE, '--header-sha256', HEADER_SHA])
    source = receiver = None; identities = {}; failure = None; signals = []
    try:
        save(out, 'RECEIVER_SPAWN_INTENT.json', {'utc': utc(), 'parent_pid': os.getpid(), 'argv': receiver_argv,
             'script_sha256': RECEIVER_SHA, 'header_sha256': HEADER_SHA, 'output_cap_bytes': 8589934592})
        with (out / 'RECEIVER.stdout.json').open('xb') as ro, (out / 'RECEIVER.stderr.log').open('xb') as re, (out / 'MAC_STREAM.stderr.log').open('xb') as me:
            receiver = subprocess.Popen(receiver_argv, stdin=subprocess.PIPE, stdout=ro, stderr=re)
            identities['receiver'] = child_identity(receiver); save(out, 'RECEIVER_PROCESS.json', identities['receiver'])
            save(out, 'SOURCE_SPAWN_INTENT.json', {'utc': utc(), 'parent_pid': os.getpid(), 'argv': source_argv,
                 'script_sha256': MAC_SCRIPT_SHA, 'header_sha256': HEADER_SHA, 'binary_stdout_connected_to_owned_receiver': True})
            source = subprocess.Popen(source_argv, stdin=subprocess.DEVNULL, stdout=receiver.stdin, stderr=me)
            receiver.stdin.close(); identities['source'] = child_identity(source); save(out, 'SOURCE_PROCESS.json', identities['source'])
            deadline = time.monotonic() + TIMEOUT
            while source.poll() is None or receiver.poll() is None:
                if time.monotonic() >= deadline: raise TimeoutError('Owned preservation pipe deadline')
                if source.poll() not in (None, 0): raise RuntimeError('Owned Mac source exit ' + str(source.returncode))
                if receiver.poll() not in (None, 0): raise RuntimeError('Owned Oracle receiver exit ' + str(receiver.returncode))
                time.sleep(5)
            assert source.wait() == 0 and receiver.wait() == 0
    except BaseException as error:
        failure = repr(error)
        for label, p in [('source', source), ('receiver', receiver)]:
            if p is not None and p.poll() is None:
                assert child_identity(p)['creation_filetime_100ns'] == identities[label]['creation_filetime_100ns']
                p.terminate(); signals.append({'process': label, 'identity': identities[label], 'operation': 'terminate_exact_retained_Popen_handle'})
                try: p.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    p.kill(); p.wait(timeout=15)
    if failure:
        receipt = save(out, 'BRIDGE_FAILURE.json', {'utc': utc(), 'failure': failure, 'identities': identities, 'signals_to_owned_ssh_only': signals,
                       'source_exit': source.returncode if source else None, 'receiver_exit': receiver.returncode if receiver else None,
                       'windows_archive_written': False, 'origin_deletions': 0})
        print(json.dumps({'status': 'PRESERVATION_PIPE_FAILED_ORIGINS_INTACT', 'receipt': receipt}), flush=True)
        raise RuntimeError(failure)
    rr = json.loads((out / 'RECEIVER.stdout.json').read_bytes())
    mac_raw = read_remote(out, 'MAC_STREAM_READBACK', 'scaleway-mac', source_receipt_code(MAC_EVIDENCE + '/STREAM_RESULT.json'))
    mac_bytes = base64.b64decode(mac_raw['base64']); assert len(mac_bytes) == mac_raw['bytes'] and sha(mac_bytes) == mac_raw['sha256']
    save(out, 'MAC_STREAM_RESULT.json', mac_bytes); mac = json.loads(mac_bytes)
    assert mac['header_sha256'] == HEADER_SHA and rr['archive']['sha256'] == mac['archive_sha256'] and rr['archive']['bytes'] == mac['archive_bytes']
    verify_argv = remote_command('scaleway-mac', ['/usr/bin/python3', '-B', MAC_CONTROL + '/closed_native.py', 'reverify', '--evidence', MAC_EVIDENCE, '--header-sha256', HEADER_SHA])
    save(out, 'SOURCE_REVERIFY_INTENT.json', {'utc': utc(), 'argv': verify_argv, 'script_sha256': MAC_SCRIPT_SHA, 'header_sha256': HEADER_SHA})
    with (out / 'SOURCE_REVERIFY.stdout.json').open('xb') as so, (out / 'SOURCE_REVERIFY.stderr.log').open('xb') as se:
        verify = subprocess.run(verify_argv, stdin=subprocess.DEVNULL, stdout=so, stderr=se, timeout=780)
    assert verify.returncode == 0
    sr = json.loads((out / 'SOURCE_REVERIFY.stdout.json').read_bytes())
    source_raw = read_remote(out, 'SOURCE_REVERIFIED_READBACK', 'scaleway-mac', source_receipt_code(MAC_EVIDENCE + '/SOURCE_REVERIFIED.json'))
    source_bytes = base64.b64decode(source_raw['base64']); assert len(source_bytes) == source_raw['bytes'] and sha(source_bytes) == source_raw['sha256']
    save(out, 'SOURCE_REVERIFIED.json', source_bytes); source_proof = json.loads(source_bytes)
    assert source_proof['header_sha256'] == HEADER_SHA and source_proof['entries'] == 37238
    result = {'utc': utc(), 'status': 'ARCHIVE_AND_CURRENT_SOURCE_VERIFIED_NO_RETIREMENT', 'control': str(out),
              'header_sha256': HEADER_SHA, 'source_identities': identities, 'mac_stream_receipt_sha256': mac_raw['sha256'],
              'source_reverified_sha256': source_raw['sha256'], 'source_reverification_result': sr,
              'oracle_archive_verification': rr, 'mac_evidence': MAC_EVIDENCE, 'oracle_evidence': ORACLE_EVIDENCE,
              'source_exit': source.returncode, 'receiver_exit': receiver.returncode, 'windows_archive_written': False,
              'signals': signals, 'preflights': {'mac': mp, 'oracle': op}, 'origin_deletions': 0, 'builds': 0, 'native_runs': 0,
              'windows_free_after': shutil.disk_usage(out).free, 'bridge_source_sha256': sha(Path(__file__).read_bytes())}
    receipt = save(out, 'BRIDGE_RESULT.json', result)
    print(json.dumps({'status': result['status'], 'receipt': receipt, 'archive': rr['archive'], 'archive_verification': rr['receipt'],
                      'source_reverified_sha256': source_raw['sha256'], 'mac_stream_receipt_sha256': mac_raw['sha256'],
                      'windows_control': str(out), 'oracle_evidence': ORACLE_EVIDENCE, 'origin_deletions': 0}), flush=True)

if __name__ == '__main__': main()
