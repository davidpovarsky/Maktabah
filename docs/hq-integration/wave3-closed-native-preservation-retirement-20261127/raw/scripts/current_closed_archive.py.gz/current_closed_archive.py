#!/usr/bin/env python3
"""Read-only fresh whole-archive identity and SHA binding; no member rerun."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import stat

BASE = Path('/mnt/development/projects/diagnostics/otzaria-wave3-closed-native-preservation-20261127.fcws2jok')
PINS = {
    'COMPLETE_PRESERVATION_VERIFIED.json': 'fc6acb50b51ece3133921d746cbdb06fc8869e0c541f057e4a1240ffe835f6a7',
    'SOURCE_REVERIFIED.json': '13fd31b5bde07fd7138ac39d9c7db2c0954b42bec0fc711b83cdf333ce790112',
    'ARCHIVE_VERIFIED.json': '50987d6a7daa36458322f755068f6730609ad470309ab2fa6cd4e96fdcf0720e',
    'HEADER.json': 'd6b5e2a0d8a403248b7919d4d7fd283df957f2b3524f5239a836f72f364856ee',
}

def identity(p):
    assert p.resolve() == p and not p.is_symlink()
    s = p.lstat(); assert stat.S_ISREG(s.st_mode)
    return {'device': s.st_dev, 'inode': s.st_ino, 'size': s.st_size,
            'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}

def main():
    s = BASE.lstat(); assert stat.S_ISDIR(s.st_mode) and s.st_dev == 2064 and s.st_ino == 397500
    values = {}
    for name, expected in PINS.items():
        p = BASE / name; before = identity(p); raw = p.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected and identity(p) == before
        values[name] = json.loads(raw)
    proof = values['COMPLETE_PRESERVATION_VERIFIED.json']
    verified = values['ARCHIVE_VERIFIED.json']
    source = values['SOURCE_REVERIFIED.json']
    header = values['HEADER.json']
    assert proof['archive'] == verified['archive'] and proof['prior_archive_references'] == 0
    assert proof['exact_roots'] == source['boundary']['roots'] == header['boundary']['roots']
    assert proof['origin_deletions'] == 0
    archive = Path(proof['archive']['path'])
    assert archive.parent == BASE and archive.name == 'closed-native-self-contained.tar.gz'
    before = identity(archive)
    assert before == proof['archive_stat_at_independent_readback']
    digest = hashlib.sha256(); count = 0
    with archive.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            digest.update(block); count += len(block)
            if count % (16 * 1048576) == 0: assert shutil.disk_usage(BASE).free >= 687865856
    assert identity(archive) == before
    assert count == proof['archive']['bytes'] and digest.hexdigest() == proof['archive']['sha256']
    print(json.dumps({
        'status': 'CURRENT_SELF_CONTAINED_ARCHIVE_AND_RECEIPTS_REHASHED',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': proof['archive'], 'archive_identity': before,
        'complete_preservation_sha256': PINS['COMPLETE_PRESERVATION_VERIFIED.json'],
        'source_reverified_sha256': PINS['SOURCE_REVERIFIED.json'],
        'archive_verification_sha256': PINS['ARCHIVE_VERIFIED.json'],
        'header_sha256': PINS['HEADER.json'], 'exact_roots': proof['exact_roots'],
        'fresh_whole_archive_sha256': digest.hexdigest(), 'whole_archive_bytes_read': count,
        'previous_full_member_receipt_bound': True, 'full_member_verification_repeated': False,
        'free_bytes': shutil.disk_usage(BASE).free, 'writes': 0,
    }, sort_keys=True, separators=(',', ':')))

if __name__ == '__main__':
    main()
