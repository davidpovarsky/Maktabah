import base64,gzip,hashlib,json,pathlib,shutil,subprocess,traceback

ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='d1ad8d5e003ecf24b32542aeb27d8bc4eac844cc'
BRANCH='codex/otzaria-wave3-integration-20261127'
DONOR_BASE='24cd9291dbc87d799c22a41f0bc73a82c6415bfa'
SOURCE='310db9a9a887b604f422581765feb902465fef99'
DOCS='a65cc9b3b1f802d3fe4b9e0bd57b9e073109d28f'
DONOR_REPO='/home/ubuntu/.codex/worktrees/Maktabah-wave3-public-search-entry-20261127'
D='docs/ui-routing/wave3-public-search-entry-20261127'
PROOF='docs/hq-integration/wave3-public-search-entry-intake-20261127'
RUN=pathlib.Path(__file__).parent
events=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def git(*args):
    p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*args],capture_output=True)
    row={'args':args,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')}
    if len(p.stdout)<4096 and args[0]not in ['show','cat-file']:row['stdout']=p.stdout.decode(errors='replace')
    events.append(row);dump(RUN/'EVENTS.json',events)
    if p.returncode:raise RuntimeError('Git failure: '+repr(args))
    return p.stdout
def rev(ref):return git('rev-parse',ref).decode().strip()
def show(ref,path):return git('show',ref+':'+path)

try:
    assert rev('HEAD')==BASE and git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
    assert not git('status','--porcelain') and shutil.disk_usage(ROOT).free>=1342177280
    remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
    assert git(*remote).decode().split()[0]==BASE
    git('fetch','--no-tags','--no-write-fetch-head',DONOR_REPO,DOCS)
    assert rev(SOURCE+'^')==DONOR_BASE and rev(DOCS+'^')==SOURCE
    source_paths=git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines()
    doc_paths=git('diff-tree','--no-commit-id','--name-only','-r',DOCS).decode().splitlines()
    assert len(source_paths)==10 and len(doc_paths)==38
    artifact_bytes=show(DOCS,D+'/ARTIFACTS.json')
    assert sha(artifact_bytes)=='44998606b47a288b494dff8e262a5a7241e54808e7b143ea5d0f546b7a6b571b'
    artifacts=json.loads(artifact_bytes)
    assert artifacts['sourceCommit']==SOURCE and len(artifacts['files'])==37
    assert set(doc_paths)=={D+'/'+x['path']for x in artifacts['files']}|{D+'/ARTIFACTS.json'}
    for row in artifacts['files']:
        raw=show(DOCS,D+'/'+row['path'])
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
    source_bytes=show(DOCS,D+'/SOURCE_INPUTS.json')
    assert sha(source_bytes)=='ff636d73aaea54ce5f5264107573fd63b22a10de58a699c0e2f0e13ed93ecc24'
    source_inputs=json.loads(source_bytes)
    assert source_inputs['base']==DONOR_BASE and source_inputs['sourceCommit']==SOURCE
    assert set(source_paths)=={row['path']for row in source_inputs['files']}
    joined=[]
    for row in source_inputs['files']:
        path=row['path'];after=show(SOURCE,path)
        assert len(after)==row['bytes'] and sha(after)==row['sha256']
        assert show(DOCS,path)==after
        assert git('ls-tree',SOURCE,'--',path).decode().startswith('100644 blob ')
        exists=bool(git('ls-tree',DONOR_BASE,'--',path))
        if exists:
            before=show(DONOR_BASE,path);assert show(BASE,path)==before
        else:
            assert not git('ls-tree',BASE,'--',path);before=None
        joined.append({**row,'beforeSHA256':sha(before)if before is not None else None,
                       'beforeBlob':rev(BASE+':'+path)if before is not None else None,'afterBlob':rev(SOURCE+':'+path)})
    protected=['Source/Otzaria/Actions','Source/Features','Vendor','Maktabah.xcodeproj','Maktabah-iOSUITests','.github','docs/architecture','Scripts/CI']
    trees={p:rev(BASE+':'+p)for p in protected}
    for p in protected:
        assert rev(BASE+':'+p)==rev(DONOR_BASE+':'+p)or p=='Scripts/CI'
        assert rev(SOURCE+':'+p)==rev(DONOR_BASE+':'+p)
    codec='Source/Otzaria/UIRouting/Sources/OtzariaUIRouting/Codec/PublicNavigationV2Codec.swift'
    assert show(BASE,codec)==show(SOURCE,codec)
    existing_tests='Source/Otzaria/UIRouting/Tests/OtzariaUIRoutingTests/Codec/PublicNavigationV2Tests.swift'
    assert show(BASE,existing_tests)==show(SOURCE,existing_tests)
    assert len(show(BASE,existing_tests))==35779
    index=json.loads(show(DOCS,D+'/EVIDENCE_INDEX.json'))
    assert len(index)==5
    member_count=0;capsules=[]
    for item in index:
        packed=show(DOCS,D+'/evidence/'+item['name']+'.json.gz')
        assert len(packed)==item['gzipBytes'] and sha(packed)==item['gzipSHA256']
        raw=gzip.decompress(packed)
        assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
        data=json.loads(raw);assert data['attempt']==item['name']
        assert len(data['files'])==item['fileCount']
        assert len({f['path']for f in data['files']})==len(data['files'])
        for f in data['files']:
            assert not f['path'].startswith('/') and '..'not in pathlib.PurePosixPath(f['path']).parts
            assert 'text'in f
            b=f['text'].encode()
            assert len(b)==f['bytes'] and sha(b)==f['sha256'],(item['name'],f['path'])
        results=[f for f in data['files']if f['path']=='RESULT.json']
        assert len(results)==1 and results[0]['sha256']==item['resultSHA256']
        member_count+=len(data['files'])
        capsules.append({'name':item['name'],'files':len(data['files']),'resultSHA256':item['resultSHA256'],'summary':item['summary'],'status':item['status']})
    assert member_count==212
    accepted={i['name']:i for i in index}
    assert accepted['public-search-portable-attempt-2']['summary']==[['40','0']]
    assert accepted['public-search-portable-attempt-2']['resultSHA256']=='ed10f3e1e6324c585d8b545e7f4435b631b4808ab7a44c4baf296071fb4b44df'
    assert accepted['public-search-catalog-attempt-1']['summary']==[['19','0']]
    assert accepted['public-search-catalog-attempt-1']['resultSHA256']=='9010f58c1498c2f9ce281b82734321ed5c16ff813b5766774a983a51018227a5'
    assert accepted['public-search-portable-attempt-4']['summary']==[['8','27']]
    proposals=json.loads(show(DOCS,D+'/root-proposals/INPUTS.json'))
    assert len(proposals['files'])==3
    for row in proposals['files']:
        assert sha(show(BASE,row['path']))==row['baseSHA256']
        patch=gzip.decompress(show(DOCS,D+'/root-proposals/'+pathlib.Path(row['path']).name+'.patch.gz'))
        assert len(patch)==row['patchBytes'] and sha(patch)==row['patchSHA256']
    git('diff','--check',SOURCE+'^',SOURCE)
    git('diff','--check',DOCS+'^',DOCS)
    git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',SOURCE)
    source_intake=rev('HEAD')
    git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',DOCS)
    docs_intake=rev('HEAD')
    assert not git('status','--porcelain')
    for p,h in trees.items():assert rev('HEAD:'+p)==h,p
    for row in joined:assert rev('HEAD:'+row['path'])==row['afterBlob']
    proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
    (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
    dump(proof/'EXACT_SOURCE_JOIN.json',joined)
    outcome={'schema':'otzaria.wave3.public-search-entry-intake.v1','base':BASE,'sourceDonor':SOURCE,'docsDonor':DOCS,
        'sourceIntake':source_intake,'docsIntake':docs_intake,'sourcePaths':10,'documentationPaths':38,'verifiedArtifacts':37,
        'verifiedCapsuleMembers':member_count,'capsules':capsules,'preservedTrees':trees,
        'originalPublicV2CodecUnchanged':sha(show(BASE,codec)),'originalPublicV2TestsUnchanged':sha(show(BASE,existing_tests)),
        'rootSharedProposals':'NOT_YET_APPLIED; combined with original History and SavedResults separately',
        'registration':'NOT_YET_APPLIED','AppleSDK':'NOT_RUN','native':'NOT_RUN','ownerApproval':'NOT_GRANTED','release':'OPEN'}
    dump(proof/'RESULT.json',outcome)
    (proof/'README.md').write_text('# Original public Search continuation source intake\n\nThe ten exact source/test files and separate38-file evidence packet were cherry-picked individually after current preimage checks. All37 artifact rows and212 lossless capsule members were verified. The40 portable tests include17 unchanged original PublicV2 tests,8 new policy tests and15 actual-service controls with an explicit native boundary. The19 catalog controls use actual lifetime policy with an explicit app/UI boundary. The generic-guard counterfactual and all initial failures remain preserved.\n\nNo native or Apple acceptance is inferred. The root-owned shared proposals, explicit app membership and translations are intentionally integrated separately with History and Saved Results. Until those joins, this source alone is not a working app entry. Original Features/Core/Vendor/PBX/native tests/workflows/owner architecture and the current CI source-admission changes remain unchanged.\n')
    git('add','--sparse','--',PROOF)
    git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record exact original public Search source intake')
    head=rev('HEAD');assert not git('status','--porcelain')
    assert set(git('diff','--name-only',BASE,'HEAD').decode().splitlines())==set(source_paths+doc_paths)|{PROOF+'/'+p.name for p in proof.iterdir()if p.is_file()}
    assert git(*remote).decode().split()[0]==BASE
    git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
    assert git(*remote).decode().split()[0]==head
    terminal={'ok':True,'head':head,'sourceIntake':source_intake,'docsIntake':docs_intake,
        'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),
        'freeBytes':shutil.disk_usage(ROOT).free,'nativeRuns':0,'sharedWiring':'PENDING'}
    dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
    dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
