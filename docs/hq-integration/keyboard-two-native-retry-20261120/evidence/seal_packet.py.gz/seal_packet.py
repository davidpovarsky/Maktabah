"""Seal the exact-source keyboard2 route without activating any workflow."""
from pathlib import Path
import gzip
import hashlib
import json

R = Path(__file__).resolve().parent
C = R / 'candidate'
DOCS = 'docs/hq-integration/keyboard-two-native-retry-20261120/'
D = C / DOCS
INDEX = D / 'PACKET_INDEX.json'
N = R.parent / 'keyboard-global-44796704535-20261120'
S = R.parent / 'native6-escape-focus-ownership-20261120'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def compress(source, name):
    target = D / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))


for name in ['prepare_template.py', 'finalize_source.py', 'validate_route.py', 'seal_packet.py', 'TEMPLATE_INPUTS.json',
             'TEMPLATE_PROOF.json', 'TEMPLATE_DELTA.patch', 'FINAL_BINDING_PROOF.json', 'evidence/VALIDATION.json',
             'evidence/controls-attempt1/RESULT.json', 'evidence/controls-attempt1/stdout.log', 'evidence/controls-attempt1/stderr.log',
             'authority/KEYBOARD_M.json', 'authority/KEYBOARD_TREE.json', 'authority/KEYBOARD_SOURCE_TREE.json']:
    compress(R / name, 'evidence/' + name + '.gz')
for row in json.loads((R / 'TEMPLATE_INPUTS.json').read_bytes())['base_records']:
    compress(R / 'base' / row['path'], 'evidence/base/' + row['path'] + '.gz')
for row in json.loads((R / 'TEMPLATE_INPUTS.json').read_bytes())['prior_route_records']:
    compress(R / 'prior-route' / row['path'], 'evidence/prior-route/' + row['path'] + '.gz')
for path in sorted((R / 'evidence/unfinalized').rglob('*.gz')):
    target = D / 'unfinalized' / path.relative_to(R / 'evidence/unfinalized')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(path.read_bytes())
for name in ['SOURCE_PUBLICATION.json', 'SOURCE_INVERSE.json', 'PROPOSED.patch']:
    compress(S / name, 'source/' + name + '.gz')
path = 'Source/ChavrusaText/Dependencies/CommandPalette/Sources/CommandPalette/Views/CommandPaletteView.swift'
for prefix in ['base', 'candidate']:
    compress(S / prefix / path, 'source/' + prefix + '/' + path + '.gz')
compress(N / 'ESCAPE_HANDOFF.json', 'prior-native6/ESCAPE_HANDOFF.json.gz')
compress(N / 'ALL_FIVE_ARTIFACTS_VERIFIED.json', 'prior-native6/ALL_FIVE_ARTIFACTS_VERIFIED.json.gz')
for path in ['artifacts/runtime27/result.json', 'artifacts/runtime27/verified-11-reader.tests.json',
             'artifacts/runtime27/verified-11-reader.summary.json', 'artifacts/keyboard-global-focused-native/SOURCE_BEFORE.json',
             'artifacts/keyboard-global-focused-native/SOURCE_AFTER.json', 'artifacts/keyboard-global-focused-native/RESULT_BEFORE.json',
             'artifacts/keyboard-global-focused-native/RESULT_AFTER.json', 'artifacts/native-routing-logs-11-reader/collection.json',
             'artifacts/native-routing-logs-11-reader/otzaria-reader.log']:
    compress(N / 'ipad11-evidence' / path, 'prior-native6/' + path + '.gz')
for name in ['RUN', 'JOBS', 'ARTIFACTS']:
    compress(N / 'resumed-api' / (name + '.json'), 'prior-native6/api/' + name + '.json.gz')

readme = '''# Keyboard2: exact-source retry of two original iPad11 methods

This prepared route is bound to Root's actual isolated source **M3248dfb5d45b3ae12372be4292dc330cd4608de7**, sole parent1146a249fdd94c345371c67a8d763f16223017ee, tree2ee3d4a80b0cd6ff2c7d4c01db011a08ecc4dc05. It has not been published as an executable branch or activated. Root is the sole CI activator.

## Product and test scope

Root's one production change conditionally removes the SwiftUI cancel shortcut while the existing input focus state is true. The original shortcut remains when unfocused and on non-iOS paths. Original UIKit handlers, visible Close control and all XCTest source remain unchanged. This is a source-reviewed focus-ownership candidate; actual cause and repaired Escape delivery are not yet qualified. No Apple compile or Native result is claimed.

The route selects exactly these existing methods on the original iPad11 configuration:

- `R27NativePadTests/testNormalBootstrapPaletteKeyboardDispatchCalibration`
- `FaithfulReaderUIAcceptanceTests/testPointerHoverClickAndHardwareKeyboardDismissal`

The full calibration still requires real Close, Down/Up selection changes, actual empty and filtered Escape, removal of the real input and preservation of the exact original target. Pointer coverage still uses genuine hover/click/typeKey, original frame equality, reopening with retained query and real result click. Their complete method bodies are byte-identical to the failed Native6 execution. Original15s assertions,600s XCTest limits,16200s matrix bound and360min workflow job are unchanged.

All116 original Native catalog rows and the complete Release114+2 manifest remain unchanged. The separate selected manifest retains those116 rows and appends only the same two diagnostic declarations. It uses the original11-reader/size11 matrix path, full actual app build,55 Apple Foundation Sefaria transport gate, original Swift declaration parser, source-before/source-after checks, raw XCTest leaves/summary and mandatory final aggregate. The original keyboard log collection status, byte length and SHA256 remain required. No host HID injection or replacement event is added; the existing two methods retain their own original input paths.

## Prior actual evidence

Run44796704535 on Fbce0fee51c813fe2b830d87d61b1c7943f0344f4/M40c1eaa6bb0092336f1ee687ad1ce1425eaf4223 completed2PASS/4FAIL across six executions. Both selected keyboard methods failed their original15s Escape assertions. The raw same-run source/result/log/API records are retained here; complete original archives remain authenticated in the Native6 result packet. This retry gets no historical pass credit. Global4 is a distinct run/source/selection.

## Preparation and validation

The original UNFINALIZED draft is retained under `unfinalized/`. It fails `require_finalized`; no invented final M was used. After Root supplied M, canonical Git commit/tree reads proved the sole changed source leaf and preserved every other mode/leaf. Actual current R27/project hashes and the original three-tree HQ schema are bound; four application/test trees are protected separately.

All36 adapted original Python boundary/receipt controls passed. The separate71 preservation checks passed, including the complete original keyboard qualification function, raw producer/consumer receipt names, whole workflow inverse, actual method identities, source binding, original budgets and full catalogs. These are Python/source controls, not app execution. The local full Git checkout gate and Swift declaration parser are NOT_RUN on this authenticated source projection; actual CI must run the original gates on its immutable checkout before compiling/executing.

The proposed new branch is `codex/otzaria-keyboard-two-native-retry-20261120`. Source/publication/activation is Root-owned. Failure, cancellation, skip, partial result, missing log or source mismatch cannot qualify either original method.
'''
(D / 'README.md').write_text(readme)
records = []
for path in sorted(D.rglob('*')):
    if not path.is_file() or path == INDEX:
        continue
    raw = path.read_bytes()
    entry = {'path': path.relative_to(C).as_posix(), 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw)}
    if path.suffix == '.gz':
        expanded = gzip.decompress(raw)
        entry.update(uncompressed_bytes=len(expanded), uncompressed_sha256=sha(expanded))
    records.append(entry)
dump(INDEX, {'schema_version': 1, 'source': '3248dfb5d45b3ae12372be4292dc330cd4608de7', 'records': records,
             'qualification': '36 Python controls plus71 source checks; Native0', 'activation': False})
files = []
for path in sorted(C.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    raw = path.read_bytes()
    files.append({'path': path.relative_to(C).as_posix(), 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw)})
runtime_paths = [item['path'] for item in files if not item['path'].startswith(DOCS)]
assert len(runtime_paths) == 7, runtime_paths
dump(R / 'PUBLICATION_REVIEW.json', {'root': str(C), 'parent': '3248dfb5d45b3ae12372be4292dc330cd4608de7',
     'base_tree': '2ee3d4a80b0cd6ff2c7d4c01db011a08ecc4dc05', 'branch': 'codex/otzaria-keyboard-two-native-retry-20261120',
     'files': files, 'packet_index': next(x for x in files if x['path'] == INDEX.relative_to(C).as_posix()),
     'runtime_paths': runtime_paths, 'publication_status': 'NOT_PUBLISHED_ROOT_OWNS_ACTIVATION'})
print(json.dumps({'files': len(files), 'runtime_paths': len(runtime_paths), 'packet_index_sha256': sha(INDEX.read_bytes()),
                  'bytes': sum(x['bytes'] for x in files), 'Native_candidate': 0}))
