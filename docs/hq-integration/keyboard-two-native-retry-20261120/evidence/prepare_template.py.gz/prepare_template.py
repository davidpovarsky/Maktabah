"""UNFINALIZED keyboard-only retry. Root supplies the real M before activation."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json

R = Path(__file__).resolve().parent
BASE, PRIOR, C = R / 'base', R / 'prior-route', R / 'candidate'
OLD = 'keyboard-global-focused-native'
NAME = 'keyboard-two-native-retry'
OLD_DOCS = 'docs/hq-integration/' + OLD + '-20261120/'
DOCS = 'docs/hq-integration/' + NAME + '-20261120/'
KNOWN_TEMPLATE = '1146a249fdd94c345371c67a8d763f16223017ee'
MANIFEST = 'docs/hq-integration/runtime27/R27_CASES.json'
SOURCE = R.parent / 'global-tab-ownership-native-20261120'
ACTUAL = R.parent / 'keyboard-global-focused-native-20261120/candidate'
CALIBRATION = 'R27NativePadTests/testNormalBootstrapPaletteKeyboardDispatchCalibration'
POINTER = 'FaithfulReaderUIAcceptanceTests/testPointerHoverClickAndHardwareKeyboardDismissal'
CASES = [CALIBRATION, POINTER]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def put(root, path, raw):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


metadata = json.loads((SOURCE / 'CANONICAL_INPUTS.json').read_bytes())
# Those15 files are outside the sole iPadLayout source change in the isolated
# child cb252; the canonical root/source preservation receipt proves they are
# byte-identical in its parent1146. They are a template, never a final M pin.
publication = json.loads((R.parent / 'native6-global-tab-diagnosis-20261120/SOURCE_PUBLICATION.json').read_bytes())
assert publication['parent'] == KNOWN_TEMPLATE
assert publication['change']['source_leaf_changed'] == ['UI/iOS/Views/iPadLayout.swift']
for item in metadata['base_records']:
    raw = (SOURCE / 'base' / item['path']).read_bytes()
    assert sha(raw) == item['sha256']
    put(BASE, item['path'], raw)
for item in metadata['prior_route_records']:
    raw = (SOURCE / 'prior-route' / item['path']).read_bytes()
    assert sha(raw) == item['sha256']
    put(PRIOR, item['path'], raw)
dump(R / 'TEMPLATE_INPUTS.json', {'template_source': KNOWN_TEMPLATE, 'template_only': True,
    'inherited_same_bytes_from_one_leaf_child': metadata['source'], 'base_records': metadata['base_records'],
    'prior_actual_native6': metadata['prior_native6_F'], 'prior_route_records': metadata['prior_route_records'],
    'final_source': 'UNFINALIZED', 'source_publication_preservation': publication['change']})

binding = json.loads((ACTUAL / OLD_DOCS / 'SOURCE_BINDING.json').read_bytes())
binding.update(source_sealed=False, source_commit='UNFINALIZED', source_tree='UNFINALIZED',
    protected_trees={k: 'UNFINALIZED' for k in binding['protected_trees']},
    template_source=KNOWN_TEMPLATE, template_only=True, original_route=metadata['prior_native6_F'],
    final_source_pending='Root will publish the actual keyboard product candidate. No invented M or activation.',
    exact_base_records=metadata['base_records'], native_executions=0, activation=False)
dump(C / DOCS / 'SOURCE_BINDING.json', binding)
edits = []


def replace(text, before, after, count=1):
    assert text.count(before) == count, (before, text.count(before), count)
    edits.append({'before': before, 'after': after, 'count': count})
    return text.replace(before, after)


old_driver = (PRIOR / f'Scripts/CI/{OLD}.py').read_text()
driver = replace(old_driver, OLD, NAME, old_driver.count(OLD))
driver = replace(driver, 'keyboard-global-ipad', 'keyboard-two-ipad', 2)
driver = replace(driver, 'keyboard_global_diagnostic_20261120', 'keyboard_two_diagnostic_20261120', 2)
driver = replace(driver, 'Bind two unchanged original Native scopes, then require all 4+2 outcomes.',
                 'Bind the unchanged iPad11 keyboard scope and require both original outcomes.')
driver = replace(driver, 'LANDSCAPE = "FaithfulReaderUIAcceptanceTests/testCandidateGlobalSearchLandscapeMatchesOriginalNavigation"\nPORTRAIT = "FaithfulReaderUIAcceptanceTests/testCandidateGlobalSearchPortraitMatchesOriginalNavigation"\n', '')
driver = replace(driver, 'CASES = [CALIBRATION, POINTER, LANDSCAPE, PORTRAIT]', 'CASES = [CALIBRATION, POINTER]')
driver = replace(driver, '    "ipad13": {"label": "13", "size": "13", "cases": [LANDSCAPE, PORTRAIT],\n               "manifest": "docs/hq-integration/runtime27/keyboard-two-ipad13.json"},\n', '')
driver = replace(driver, 'len(rows) == 120 and len({r["case_id"] for r in rows}) == 120, "Expected116+4 unique diagnostic declarations"',
                 'len(rows) == 118 and len({r["case_id"] for r in rows}) == 118, "Expected116+2 unique diagnostic declarations"')
driver = replace(driver, '["ipad11", "ipad11", configuration, configuration]', '["ipad11", "ipad11"]')
driver = replace(driver, 'expected_per_device = {"ipad11": 4 if configuration == "ipad11" else 0,\n                           "ipad13": 2 if configuration == "ipad13" else 0, "iphone": 0}',
                 'expected_per_device = {"ipad11": 2, "ipad13": 0, "iphone": 0}')
driver = replace(driver, 'require(len(actual) == 6, "Expected exactly four plus two actual executions")',
                 'require(len(actual) == 2, "Expected exactly two actual original keyboard executions")')
driver = replace(driver, '"requested_case_executions": 6', '"requested_case_executions": 2')
driver = replace(driver, 'SIX_SELECTED_ORIGINAL_NATIVE_EXECUTIONS_PASS', 'TWO_SELECTED_ORIGINAL_KEYBOARD_EXECUTIONS_PASS')
driver = replace(driver, 'executed_pass=6, executed_fail=0', 'executed_pass=2, executed_fail=0')
driver = replace(driver, 'Four original methods, six executions: ipad11=4 and ipad13=2; not final116/114 acceptance.',
                 'Two unchanged original keyboard methods on original ipad11 only; not final116/114 acceptance.')
put(C, f'Scripts/CI/{NAME}.py', driver.encode())

old_workflow = (PRIOR / f'.github/workflows/otzaria-{OLD}.yml').read_text()
workflow = old_workflow.replace(OLD, NAME).replace('keyboard-global-ipad', 'keyboard-two-ipad')
workflow = workflow.replace('build/downloaded-keyboard-global', 'build/downloaded-keyboard-two')
workflow = workflow.replace('Six original keyboard and Global Search native executions', 'Two original iPad keyboard native executions')
workflow = workflow.replace('original-six', 'original-two').replace('aggregate-six', 'aggregate-two')
workflow = workflow.replace('Require four plus two actual original Native executions', 'Require both actual original iPad11 keyboard executions')
workflow = workflow.replace('Require both original scopes and recheck actual raw results', 'Require the original iPad11 scope and recheck both actual raw results')
workflow = workflow.replace('count: 4', 'count: 2')
old_ipad13 = '          - configuration: ipad13\n            count: 2\n            manifest: docs/hq-integration/runtime27/keyboard-two-ipad13.json\n'
assert workflow.count(old_ipad13) == 1
workflow = workflow.replace(old_ipad13, '')
put(C, f'.github/workflows/otzaria-{NAME}.yml', workflow.encode())

old = json.loads((BASE / MANIFEST).read_bytes())
prior_manifest = json.loads((ACTUAL / 'docs/hq-integration/runtime27/keyboard-global-ipad11.json').read_bytes())
extra = prior_manifest['supplemental_cases'][-4:-2]
assert [row['case_id'] for row in extra] == CASES
assert len(old['cases'] + old['supplemental_cases']) == 116
current = copy.deepcopy(old)
for key in ['source_test_commit', 'app_source', 'application_source_sha']:
    current[key] = 'UNFINALIZED'
current.update(scope='UNFINALIZED keyboard-only retry template: two unchanged original methods on original iPad11; no final app source or execution.',
    native_cases_executed=0, required_nonzero_cases=2, expected_per_device={'ipad11': 2, 'ipad13': 0, 'iphone': 0},
    diagnostic_only=True, hid_comparison=False, execution_case_ids=CASES,
    execution_groups=[{'label': '11-reader', 'size': '11', 'case_ids': CASES}],
    selected_scope_reason='Same original full calibration and Pointer/hardware-keyboard methods; no changed action, assertion or deadline.',
    diagnostic_purpose='Qualify Root keyboard product correction only after exact M is provided; no retry or fabricated input delivery.',
    supplemental_cases=old['supplemental_cases'] + extra,
    keyboard_two_diagnostic_20261120={'configuration': 'ipad11', 'source_snapshot': 'UNFINALIZED',
        'original_execution_case_ids': old['execution_case_ids'], 'unchanged_original_row_count': 116,
        'additional_existing_diagnostic_rows': extra, 'new_native_executions': 0,
        'full_native116_acceptance': False, 'full_release114_acceptance': False,
        'original_manifest_sha256': sha((BASE / MANIFEST).read_bytes())})
dump(C / 'docs/hq-integration/runtime27/keyboard-two-ipad11.json', current)

original_runtime = (BASE / 'Scripts/CI/runtime27.py').read_text()
runtime = original_runtime.replace(binding['original_r27_pin'], binding['r27_test_sha256'])
assert original_runtime.count(binding['original_r27_pin']) == 1
runtime_edits = json.loads((ACTUAL / OLD_DOCS / 'RUNTIME_EXACT_EDIT.json').read_bytes())['replacements']
runtime_edits = copy.deepcopy(runtime_edits)
for edit in runtime_edits:
    edit['after'] = edit['after'].replace('keyboard-global-ipad11', 'keyboard-two-ipad11')
    edit['after'] = edit['after'].replace('        "docs/hq-integration/runtime27/keyboard-global-ipad13.json",\n', '')
    edit['after'] = edit['after'].replace('one of two reviewed independent diagnostics', 'the reviewed iPad11 keyboard diagnostic')
    assert runtime.count(edit['before']) == 1
    runtime = runtime.replace(edit['before'], edit['after'])
inverse = runtime
for edit in reversed(runtime_edits):
    assert inverse.count(edit['after']) == 1
    inverse = inverse.replace(edit['after'], edit['before'])
assert inverse.replace(binding['r27_test_sha256'], binding['original_r27_pin']) == original_runtime
put(C, 'Scripts/CI/runtime27.py', runtime.encode())
dump(C / DOCS / 'RUNTIME_EXACT_EDIT.json', {'path': 'Scripts/CI/runtime27.py', 'replacements': runtime_edits,
    'old_r27_pin': binding['original_r27_pin'], 'new_r27_pin': binding['r27_test_sha256'],
    'original_sha256': sha(original_runtime.encode()), 'candidate_sha256': sha(runtime.encode()), 'whole_body_inverse_exact': True})
old_additions = (BASE / 'Scripts/CI/hq-stage2-otzaria-test-additions.json').read_bytes()
assert old_additions.count(binding['old_project_pin'].encode()) == 1
additions = old_additions.replace(binding['old_project_pin'].encode(), binding['project_blob'].encode())
put(C, 'Scripts/CI/hq-stage2-otzaria-test-additions.json', additions)
inputs = json.loads((BASE / 'Scripts/CI/hq-stage2-focused-apple.inputs.json').read_bytes())
inputs.update(application_source_sha='UNFINALIZED', application_trees={key: 'UNFINALIZED' for key in ['Source', 'Vendor', 'Maktabah.xcodeproj']}, otzaria_test_additions_sha256=sha(additions))
dump(C / 'Scripts/CI/hq-stage2-focused-apple.inputs.json', inputs)

patch = ''.join(difflib.unified_diff(old_driver.splitlines(True), driver.splitlines(True), 'actual-Native6/driver.py', 'UNFINALIZED-keyboard2/driver.py'))
patch += ''.join(difflib.unified_diff(old_workflow.splitlines(True), workflow.splitlines(True), 'actual-Native6/workflow.yml', 'UNFINALIZED-keyboard2/workflow.yml'))
(R / 'TEMPLATE_DELTA.patch').write_text(patch)
dump(R / 'TEMPLATE_PROOF.json', {'status': 'UNFINALIZED_NOT_EXECUTABLE', 'template_source': KNOWN_TEMPLATE, 'final_M': 'UNFINALIZED',
    'driver_replacements': edits, 'original_full_native116_and_release114_preserved': True,
    'same_original_full_methods': CASES, 'configuration': 'ipad11', 'keyboard_trace_retention_required': True,
    'original15s_600s_16200s_360min_budgets_preserved': True, 'actual_Native_executed': 0,
    'source_graph_gate': 'Finalized real source M required before any actual CI execution', 'activation': False})
for path in [f'Scripts/CI/{NAME}.py', 'Scripts/CI/runtime27.py']:
    ast.parse((C / path).read_text())
print(json.dumps({'status': 'UNFINALIZED_NOT_EXECUTABLE', 'methods': 2, 'configurations': 1, 'final_M': 'UNFINALIZED', 'Native': 0}))
