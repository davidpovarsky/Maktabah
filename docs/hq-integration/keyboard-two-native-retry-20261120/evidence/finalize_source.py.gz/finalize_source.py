"""Bind the draft to Root's actual isolated product commit; no activation."""
from pathlib import Path
import copy
import gzip
import hashlib
import json

R = Path(__file__).resolve().parent
C, B, P = R / 'candidate', R / 'base', R / 'prior-route'
NAME, OLD = 'keyboard-two-native-retry', 'keyboard-global-focused-native'
DOCS = 'docs/hq-integration/' + NAME + '-20261120/'
M = '3248dfb5d45b3ae12372be4292dc330cd4608de7'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


commit = json.loads((R / 'authority/KEYBOARD_M.json').read_bytes())
tree = json.loads((R / 'authority/KEYBOARD_TREE.json').read_bytes())
assert commit['sha'] == M and commit['tree']['sha'] == tree['sha'] == '2ee3d4a80b0cd6ff2c7d4c01db011a08ecc4dc05'
assert [x['sha'] for x in commit['parents']] == ['1146a249fdd94c345371c67a8d763f16223017ee']
assert tree['truncated'] is False
trees = {row['path']: row['sha'] for row in tree['tree'] if row['path'] in ['Source', 'Vendor', 'Maktabah.xcodeproj', 'Maktabah-iOSUITests']}
assert trees == {'Source': '5f2f7cc9eceee62a24d3716de328433755ebed53', 'Vendor': '4065c0e62af325e83a65fe0c70270985229807ae',
                 'Maktabah.xcodeproj': 'ebf00ef1e0e466b083f476be9a9bf1a06c7d2b72', 'Maktabah-iOSUITests': '9be9f4c91114f5daffceac8a8ded0e7314f29fb4'}
before_tree = json.loads((R.parent / 'native6-global-tab-diagnosis-20261120/authority/CANONICAL_BASE_TREE.json').read_bytes())
old_root = {x['path']: (x['mode'], x['type'], x['sha']) for x in before_tree['tree']}
new_root = {x['path']: (x['mode'], x['type'], x['sha']) for x in tree['tree']}
assert [p for p in sorted(old_root.keys() | new_root.keys()) if old_root.get(p) != new_root.get(p)] == ['Source']
before_source = json.loads((R.parent / 'native6-global-tab-diagnosis-20261120/authority/CANONICAL_SOURCE_TREE.json').read_bytes())
after_source = json.loads((R / 'authority/KEYBOARD_SOURCE_TREE.json').read_bytes())
old_leaves = {x['path']: (x['mode'], x['type'], x['sha']) for x in before_source['tree'] if x['type'] != 'tree'}
new_leaves = {x['path']: (x['mode'], x['type'], x['sha']) for x in after_source['tree'] if x['type'] != 'tree'}
changed = [p for p in sorted(old_leaves.keys() | new_leaves.keys()) if old_leaves.get(p) != new_leaves.get(p)]
assert changed == ['ChavrusaText/Dependencies/CommandPalette/Sources/CommandPalette/Views/CommandPaletteView.swift']
assert new_leaves[changed[0]] == ('100644', 'blob', 'b51c924f3215f6042e8df355cb9e8c74b7650e11')
binding_path = C / DOCS / 'SOURCE_BINDING.json'
binding = json.loads(binding_path.read_bytes())
assert binding['source_sealed'] is False and binding['source_commit'] == 'UNFINALIZED'
for path in sorted(C.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    target = R / 'evidence/unfinalized' / (path.relative_to(C).as_posix() + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
binding.update(source_sealed=True, source_commit=M, source_tree=tree['sha'], protected_trees=trees,
               template_only=False, final_source_pending=None, final_source_readback='authority/KEYBOARD_M.json',
               source_mutation_since_template=['Source/' + x for x in changed], activation=False)
dump(binding_path, binding)
manifest_path = C / 'docs/hq-integration/runtime27/keyboard-two-ipad11.json'
manifest = json.loads(manifest_path.read_bytes())
for key in ['source_test_commit', 'app_source', 'application_source_sha']:
    assert manifest[key] == 'UNFINALIZED'
    manifest[key] = M
manifest['keyboard_two_diagnostic_20261120']['source_snapshot'] = M
manifest['scope'] = 'Two unchanged original keyboard methods on original iPad11, bound to actual isolated product source. Full Native116 and Release114 remain separately required.'
manifest['diagnostic_purpose'] = 'Qualify the exact Root focus-ownership correction with genuine original keyboard input and unchanged assertions; no fabricated input delivery or historical pass transfer.'
dump(manifest_path, manifest)
inputs_path = C / 'Scripts/CI/hq-stage2-focused-apple.inputs.json'
inputs = json.loads(inputs_path.read_bytes())
assert inputs['application_source_sha'] == 'UNFINALIZED'
inputs['application_source_sha'] = M
inputs['application_trees'] = {k: trees[k] for k in ['Source', 'Vendor', 'Maktabah.xcodeproj']}
dump(inputs_path, inputs)

# Preserve the original36 boundary/receipt checks, adapting only one-config
# expectations. The original calibrated methods and their UI assertions are
# not edited or replaced by these synthetic CI controls.
old = (P / f'Scripts/CI/test-{OLD}.py').read_text()
tests = old.replace(OLD, NAME).replace('keyboard-global-ipad', 'keyboard-two-ipad')
tests = tests.replace('keyboard_global_diagnostic_20261120', 'keyboard_two_diagnostic_20261120')
tests = tests.replace('test_current_two_metadata_scopes_preserve_all_original116', 'test_current_keyboard_scope_preserves_all_original116')
tests = tests.replace('4 if name == "ipad11" else 2', '2')
tests = tests.replace('test_default_and_exact_two_manifest_paths_only', 'test_default_and_exact_keyboard_manifest_path_only')
tests = tests.replace('test_missing_calibration_or_global_selection_rejected', 'test_missing_calibration_or_pointer_selection_rejected')
tests = tests.replace('test_four_and_two_matching_synthetic_outcomes', 'test_two_matching_synthetic_outcomes')
tests = tests.replace('test_aggregate_matrix_failure_even_after_six_labels_rejected', 'test_aggregate_matrix_failure_even_after_two_labels_rejected')
tests = tests.replace('test_aggregate_cannot_reuse_ipad11_as_ipad13', 'test_aggregate_cannot_add_a_different_configuration')
tests = tests.replace('self.validate("ipad11"); self.validate("ipad13")', 'self.validate("ipad11")')
tests = tests.replace('self.assertEqual(len(self.aggregate()), 6)', 'self.assertEqual(len(self.aggregate()), 2)')
tests = tests.replace('SIX_SELECTED_ORIGINAL_NATIVE_EXECUTIONS_PASS', 'TWO_SELECTED_ORIGINAL_KEYBOARD_EXECUTIONS_PASS')
tests = tests.replace('self.assertEqual(len(result["case_outcomes"]), 6)', 'self.assertEqual(len(result["case_outcomes"]), 2)')
tests = tests.replace('["ipad13"]', '["ipad11"]').replace('"ipad13")', '"ipad11")')
tests = tests.replace('self.manifests["ipad11"]["execution_groups"][0]["size"] = "11"',
                      'self.manifests["ipad11"]["execution_groups"][0]["size"] = "13"')
tests = tests.replace('("device", "ipad11"), ("configuration_label", "11-reader")',
                      '("device", "ipad13"), ("configuration_label", "13")')
tests = tests.replace('result["configuration"] = "ipad11"', 'result["configuration"] = "ipad13"')
tests = tests.replace('self.records["ipad11"] = copy.deepcopy(self.records["ipad11"])',
                      'self.records["ipad13"] = copy.deepcopy(self.records["ipad11"])')
assert old.count('    def test_') == tests.count('    def test_') == 36
(C / f'Scripts/CI/test-{NAME}.py').write_text(tests)
dump(R / 'FINAL_BINDING_PROOF.json', {'status': 'ACTUAL_M_BOUND_NATIVE_NOT_RUN', 'M': M, 'tree': tree['sha'],
    'parent': commit['parents'][0]['sha'], 'protected_trees': trees, 'canonical_source_changed_leaves': changed,
    'all_other_leaves_modes_unchanged': True, 'original36_Python_control_methods_retained': True,
    'unfinalized_draft_retained': 'evidence/unfinalized', 'Native_executed': 0, 'activation': False})
print(json.dumps({'status': 'ACTUAL_M_BOUND_NATIVE_NOT_RUN', 'M': M, 'protected_trees': trees, 'Native': 0}))
