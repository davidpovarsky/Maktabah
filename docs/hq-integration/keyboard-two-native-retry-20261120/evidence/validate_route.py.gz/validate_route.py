"""Verify exact keyboard-only scope and actual-source binding, without Swift."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import runpy
import yaml

R = Path(__file__).resolve().parent
C, B, P = R / 'candidate', R / 'base', R / 'prior-route'
NAME, OLD = 'keyboard-two-native-retry', 'keyboard-global-focused-native'
G = runpy.run_path(str(C / f'Scripts/CI/{NAME}.py'))
proof = json.loads((R / 'TEMPLATE_PROOF.json').read_bytes())
checks = []


def check(name, ok):
    checks.append({'name': name, 'passed': bool(ok)})
    if not ok:
        raise ValueError(name)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def function(text, name):
    rows = text.splitlines(True)
    node = next(x for x in ast.parse(text).body if isinstance(x, ast.FunctionDef) and x.name == name)
    return ''.join(rows[node.lineno - 1:node.end_lineno])


old = (P / f'Scripts/CI/{OLD}.py').read_text()
new = (C / G['SELF']).read_text()
expected = old
for edit in proof['driver_replacements']:
    check('exact_derivation:' + str(len(checks)), expected.count(edit['before']) == edit['count'])
    expected = expected.replace(edit['before'], edit['after'])
check('whole_driver_recipe_exact', expected == new)
old_normalized = old.replace(OLD, NAME).replace('keyboard-global-ipad', 'keyboard-two-ipad').replace(
    'keyboard_global_diagnostic_20261120', 'keyboard_two_diagnostic_20261120')
for name in ['require', 'sha', 'blob', 'git', 'read_json', 'frozen_json', 'write', 'require_finalized', 'github_context',
             'validate_context', 'validate_identity', 'validate_pins', 'exact_working_inputs', 'source_check', 'raw_leaves',
             'validate_outcomes', 'qualify', 'main']:
    check('whole_original_function:' + name, function(old_normalized, name) == function(new, name))
check('original_keyboard_log_hash_and_collection_required', 'Original keyboard diagnostic log not retained intact' in function(new, 'qualify')
      and 'collection.get("status") == "RETAINED"' in function(new, 'qualify'))

workflow = (C / G['WORKFLOW']).read_text()
old_workflow = (P / f'.github/workflows/otzaria-{OLD}.yml').read_text()
inverse = workflow.replace(NAME, OLD).replace('keyboard-two-ipad', 'keyboard-global-ipad')
inverse = inverse.replace('build/downloaded-keyboard-two', 'build/downloaded-keyboard-global')
inverse = inverse.replace('Two original iPad keyboard native executions', 'Six original keyboard and Global Search native executions')
inverse = inverse.replace('original-two', 'original-six').replace('aggregate-two', 'aggregate-six')
inverse = inverse.replace('Require both actual original iPad11 keyboard executions', 'Require four plus two actual original Native executions')
inverse = inverse.replace('Require the original iPad11 scope and recheck both actual raw results', 'Require both original scopes and recheck actual raw results')
needle = '- configuration: ipad11\n            count: 2'
check('single_ipad11_count_delta', inverse.count(needle) == 1)
inverse = inverse.replace(needle, '- configuration: ipad11\n            count: 4')
needle = '            manifest: docs/hq-integration/runtime27/keyboard-global-ipad11.json\n'
check('single_config_removal', inverse.count(needle) == 1)
inverse = inverse.replace(needle, needle + '          - configuration: ipad13\n            count: 2\n            manifest: docs/hq-integration/runtime27/keyboard-global-ipad13.json\n')
check('whole_actual_workflow_inverse', inverse == old_workflow)
w = yaml.load(workflow, Loader=yaml.BaseLoader)
check('exact_push_ref_only', w['on'] == {'push': {'branches': [G['REF'].removeprefix('refs/heads/')]}})
check('read_only_permissions', w['permissions'] == {'contents': 'read', 'actions': 'read'})
check('no_cancellation', w['concurrency']['cancel-in-progress'] == 'false')
j = w['jobs']['original-two']
check('original_xcode27_and360min', j['runs-on'] == 'xcode-27' and j['timeout-minutes'] == '360')
check('only_original_ipad11', j['strategy']['matrix']['include'] == [{'configuration': 'ipad11', 'count': '2',
      'manifest': 'docs/hq-integration/runtime27/keyboard-two-ipad11.json'}])
steps = {x.get('name'): x for x in j['steps'] if 'name' in x}
check('same_original_fullapp_executor', steps['Execute original full app build and unchanged selected native cases']['run'] == 'python3 Scripts/CI/runtime27.py')
check('same_actual_Apple55', steps['Require all 55 Sefaria transport cases on actual Apple Foundation']['run'] == 'python3 Scripts/CI/sefaria-toc-apple55.py')
for name in ['Bind post-execution source and actual per-configuration results', 'Retain real runtime evidence including failure',
             'Retain original native result bundles and visual captures separately']:
    check('always:' + name, steps[name]['if'] == 'always()')
check('no_continue_on_error_in_build_ui', all('continue-on-error' not in x for x in j['steps']))
check('mandatory_aggregate', w['jobs']['aggregate-two']['if'] == 'always()' and w['jobs']['aggregate-two']['needs'] == 'original-two')

G['require_finalized'](G['BINDING'])
check('actual_M_bound', G['BASE'] == '3248dfb5d45b3ae12372be4292dc330cd4608de7')
old_binding = json.loads(gzip.decompress((R / 'evidence/unfinalized' / (G['BINDING_PATH'] + '.gz')).read_bytes()))
try:
    G['require_finalized'](old_binding)
except ValueError:
    check('retained_unfinalized_draft_denied', True)
else:
    check('retained_unfinalized_draft_denied', False)
manifest = json.loads((C / G['CONFIGURATIONS']['ipad11']['manifest']).read_bytes())
G['validate_manifest'](manifest, json.loads((B / G['ORIGINAL_MANIFEST']).read_bytes()), 'ipad11')
check('all_original116_rows_plus_same_two_keyboard_rows', True)
check('no_global_or_phone_selection', list(G['CONFIGURATIONS']) == ['ipad11'] and G['CASES'] == [
      'R27NativePadTests/testNormalBootstrapPaletteKeyboardDispatchCalibration',
      'FaithfulReaderUIAcceptanceTests/testPointerHoverClickAndHardwareKeyboardDismissal'])
G['validate_pins'](json.loads((C / G['INPUTS']).read_bytes()), json.loads((B / G['INPUTS']).read_bytes()),
    (C / G['ADDITIONS']).read_bytes(), (B / G['ADDITIONS']).read_bytes(), (C / G['RUNTIME']).read_bytes(), (B / G['RUNTIME']).read_bytes())
check('source_pins_and_whole_original_runtime_inverse', True)
check('Native116_Release114_not_modified', not (C / G['ORIGINAL_MANIFEST']).exists() and not (C / 'Scripts/CI/runtime27-release-manifest.json').exists())
check('no_app_or_UI_source_changes_in_route', not (C / 'Source').exists() and not (C / 'Maktabah-iOSUITests').exists())
runtime = (C / G['RUNTIME']).read_text()
matrix = (B / 'Scripts/CI/run-faithful-ipad-matrix.py').read_text()
check('original600s_XCTest_limits', '"-default-test-execution-time-allowance", "600"' in matrix and '"-maximum-test-execution-time-allowance", "600"' in matrix)
check('original16200s_matrix_limit', '"native-matrix-driver.log", 16200, interrupt_controller=controller)' in runtime)
check('original_complete_Swift_parser', '["swiftc", "-frontend", "-dump-parse", "-D", "DEBUG", str(source)]' in
      (B / 'Scripts/CI/verify-faithful-xctest.py').read_text() and 'Scripts/CI/verify-faithful-xctest.py' in matrix)


def swift_block(raw, name):
    rows = raw.decode().splitlines(True)
    start = next(i for i, row in enumerate(rows) if re.search(r'\bfunc\s+' + re.escape(name) + r'\s*\(', row))
    indent = len(rows[start]) - len(rows[start].lstrip())
    for end in range(start + 1, len(rows)):
        if rows[end] == ' ' * indent + '}\n':
            return ''.join(rows[start:end + 1])
    raise ValueError(name)


actual = json.loads((R.parent / 'keyboard-global-44796704535-20261120/ipad11-evidence/artifacts/keyboard-global-focused-native/SOURCE_BEFORE.json').read_bytes())
for filename, method in [('FaithfulReaderUIAcceptanceTests.swift', 'testPointerHoverClickAndHardwareKeyboardDismissal'),
                         ('R27NativeInteractionAcceptanceTests.swift', 'testNormalBootstrapPaletteKeyboardDispatchCalibration')]:
    path = 'Maktabah-iOSUITests/' + filename
    old_raw = (R.parent / 'keyboard-global-focused-native-20261120/base' / path).read_bytes()
    current = (B / path).read_bytes()
    check('prior_whole_source_bound:' + filename, sha(old_raw) == actual['execution_inputs'][path]['sha256'])
    check('same_full_original_method:' + method, swift_block(old_raw, method) == swift_block(current, method))
    check('original15s_assertions_retained:' + method, 'timeout: 15' in swift_block(current, method))
check('full_calibration_Close_Down_Up_empty_filtered_locator', all(x in swift_block((B / 'Maktabah-iOSUITests/R27NativeInteractionAcceptanceTests.swift').read_bytes(),
      'testNormalBootstrapPaletteKeyboardDispatchCalibration') for x in ['command-palette-close', 'XCUIKeyboardKey.downArrow', 'XCUIKeyboardKey.upArrow',
      'Escape must also remove the genuinely filtered input', 'assertTarget(backend: "otzaria")']))
control = json.loads((R / 'evidence/controls-attempt1/RESULT.json').read_bytes())
log = (R / 'evidence/controls-attempt1/stderr.log').read_text()
check('actual36_Python_controls', control['returncode'] == 0 and log.count(' ... ok\n') == 36 and 'Ran 36 tests' in log and log.rstrip().endswith('OK'))
for path in [G['SELF'], G['TESTS'], G['RUNTIME']]:
    ast.parse((C / path).read_text())
    check('Python_syntax:' + path, True)
report = {'status': 'SOURCE_PRESERVATION_AND36_PYTHON_CONTROLS_PASS', 'M': G['BASE'], 'checks': checks,
    'checks_passed': len(checks), 'python_controls_passed': 36,
    'Swift_declaration_parser': 'NOT_RUN_LOCALLY; original Apple mandatory gate',
    'actual_Git_checkout_source_gate': 'NOT_RUN_LOCALLY; actual immutable CI checkout required',
    'Apple_build': 'NOT_RUN', 'Native_candidate_executed': 0, 'full_phase_credit': False}
(R / 'evidence/VALIDATION.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['status', 'M', 'checks_passed', 'python_controls_passed', 'Native_candidate_executed']}))
