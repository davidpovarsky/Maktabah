#!/usr/bin/env python3
"""Source-bound finite Native98 watcher. Never dispatches or cancels a workflow."""
from pathlib import Path
import argparse, collections, datetime, hashlib, json, os, re, subprocess

REPO = "davidpovarsky/Maktabah"
APP = "c6542e412fb5b052d182aacbea685c62bdf8440c"
WORKFLOW = ".github/workflows/sefaria-embedded-validation.yml"
MANIFEST = "docs/hq-integration/runtime27/R27_CASES.json"
LIMIT = 3380

def utc():
    return datetime.datetime.now(datetime.timezone.utc)

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())

def command(args, timeout=45):
    r = subprocess.run(args, capture_output=True, timeout=timeout)
    if r.returncode:
        raise RuntimeError(repr(args) + " exit=" + str(r.returncode) + " " + r.stderr.decode(errors="replace")[:2000])
    return r.stdout

def api(path, destination):
    raw = command(["gh", "api", path])
    if len(raw) > 16 * 1024 * 1024:
        raise RuntimeError("Metadata response exceeds finite bound")
    destination.write_bytes(raw)
    return json.loads(raw)

def verify_run(value, args):
    expected = {"id": args.run_id, "head_sha": args.expected_head,
                "head_branch": args.expected_branch, "path": WORKFLOW,
                "event": "workflow_dispatch", "run_attempt": 1}
    for key, required in expected.items():
        if value.get(key) != required:
            raise RuntimeError("Run identity mismatch: " + key)
    for key in ["repository", "head_repository"]:
        if value.get(key, {}).get("full_name") != REPO:
            raise RuntimeError("Wrong " + key)

def source_binding(args, output):
    raw = command(["git", "show", args.expected_head + ":" + MANIFEST])
    manifest = json.loads(raw)
    for key in ["source_test_commit", "app_source", "application_source_sha"]:
        if manifest.get(key) != APP:
            raise RuntimeError("Manifest app/test pin mismatch: " + key)
    selected = manifest.get("execution_case_ids", [])
    if len(selected) != 98 or len(set(selected)) != 98:
        raise RuntimeError("Require exact unique full Native98 selection")
    if manifest.get("required_nonzero_cases") != 98 or manifest.get("diagnostic_only") is not False:
        raise RuntimeError("Require full Native98 contract")
    rows = manifest.get("cases", []) + manifest.get("supplemental_cases", [])
    catalog = {row["case_id"]: row for row in rows}
    if len(catalog) != len(rows) or not set(selected).issubset(catalog):
        raise RuntimeError("Duplicate or missing catalog identity")
    devices = dict(collections.Counter(catalog[case]["device"] for case in selected))
    if devices != {"ipad11": 78, "iphone": 20} or manifest.get("expected_per_device") != devices:
        raise RuntimeError("Require exact78 iPad/20 iPhone")
    groups = manifest.get("execution_groups", [])
    flattened = [case for group in groups for case in group["case_ids"]]
    if len(flattened) != 98 or set(flattened) != set(selected):
        raise RuntimeError("Execution groups must partition all98 exactly")
    if not any(g["label"] == "11-index" and str(g["size"]) == "11" for g in groups):
        raise RuntimeError("Require explicit11-index")
    if manifest.get("hid_comparison") is not True:
        raise RuntimeError("Require original HID gate")
    if [g["label"] for g in groups if g.get("hid_comparison")] != ["11-window"]:
        raise RuntimeError("Only original11-window owns HID comparison")
    trees = {}
    for path in ["Source", "Vendor", "Maktabah-iOSUITests", "Maktabah.xcodeproj"]:
        actual = command(["git", "rev-parse", args.expected_head + ":" + path]).decode().strip()
        expected = command(["git", "rev-parse", APP + ":" + path]).decode().strip()
        if actual != expected:
            raise RuntimeError("App/test tree mismatch: " + path)
        trees[path] = actual
    (output / "EXPECTED_R27_CASES.git-lf.json").write_bytes(raw)
    write(output / "SOURCE_BINDING_EXPECTATIONS.json", {
        "atUTC": utc().isoformat(), "runID": args.run_id, "checkout": args.expected_head,
        "branch": args.expected_branch, "appTestSource": APP, "selected": 98,
        "byDevice": devices, "catalog": len(catalog), "trees": trees,
        "caseManifestSHA256": hashlib.sha256(raw).hexdigest(),
        "nativeOutcome": "NOT_EVALUATED_ARTIFACTS_REQUIRED"
    })

def no_matching_watcher(run_id, output):
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='gh.exe'\" | "
          "Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress")
    raw = command(["powershell", "-NoProfile", "-Command", ps])
    value = json.loads(raw.decode("utf-8-sig")) if raw.strip() else []
    processes = value if isinstance(value, list) else [value]
    def matches(process):
        tokens = (process.get("CommandLine") or "").replace(chr(34), "").replace(chr(39), "").lower().split()
        return any(tokens[i:i+3] == ["run", "watch", str(run_id)]
                   for i in range(max(0, len(tokens)-2)))
    found = [p for p in processes if matches(p)]
    write(output / "PREWATCH_PROCESSES.json", {
        "atUTC": utc().isoformat(), "matchingWatcherCount": len(found),
        "matchingWatchers": found, "allGhProcessCount": len(processes)
    })
    if found:
        raise RuntimeError("Exact run already has a gh watcher; refusing duplicate")

def collect(run_id, kind, output):
    rows, total = [], None
    for page in range(1, 11):
        obj = api("repos/" + REPO + "/actions/runs/" + str(run_id) + "/" + kind
                  + "?per_page=100&page=" + str(page),
                  output / ("FINAL_" + kind.upper() + "_PAGE_" + str(page) + ".json"))
        if total is None:
            total = obj["total_count"]
        elif total != obj["total_count"]:
            raise RuntimeError("Metadata changed while collecting")
        new = obj[kind]
        rows.extend(new)
        if len(rows) >= total:
            if len(rows) != total:
                raise RuntimeError("Metadata count mismatch")
            result = {"total_count": total, kind: rows}
            write(output / ("FINAL_" + kind.upper() + ".json"), result)
            return result
        if not new:
            raise RuntimeError("Missing metadata page")
    raise RuntimeError("Finite metadata1000-entry bound exceeded")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True, type=int)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-branch", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.run_id <= 0 or not re.fullmatch("[0-9a-f]{40}", args.expected_head):
        raise RuntimeError("Concrete runID and immutable SHA required")
    if not args.expected_branch.startswith("codex/otzaria-"):
        raise RuntimeError("Unexpected branch namespace")
    output = Path(args.output).resolve()
    owned = (Path.cwd() / "build").resolve()
    if not output.is_relative_to(owned) or str(args.run_id) not in output.name:
        raise RuntimeError("Output must be a fresh owned per-run build directory")
    output.mkdir(exist_ok=False)
    (output / "WATCHER_SOURCE.py").write_bytes(Path(__file__).read_bytes())
    write(output / "REQUEST.json", vars(args))
    try:
        source_binding(args, output)
        endpoint = "repos/" + REPO + "/actions/runs/" + str(args.run_id)
        before = api(endpoint, output / "PREWATCH_RUN.json")
        verify_run(before, args)
        no_matching_watcher(args.run_id, output)
        start = utc()
        record = {
            "runID": args.run_id, "checkout": args.expected_head, "branch": args.expected_branch,
            "appTestSource": APP, "startedUTC": start.isoformat(),
            "deadlineUTC": (start + datetime.timedelta(seconds=LIMIT)).isoformat(),
            "limitSeconds": LIMIT, "wrapperPID": os.getpid(),
            "command": ["gh", "run", "watch", str(args.run_id), "--repo", REPO,
                        "--exit-status", "--interval", "30"]
        }
        if before["status"] == "completed":
            record.update(watcherState="ALREADY_COMPLETED_NO_WATCH_STARTED", watchExitCode=None)
            write(output / "WATCH_STARTED.json", record)
        else:
            with (output / "FINITE_WATCH.log").open("wb") as log:
                process = subprocess.Popen(record["command"], stdout=log, stderr=subprocess.STDOUT)
                try:
                    record["watcherPID"] = process.pid
                    write(output / "WATCH_STARTED.json", record)
                    try:
                        record["watchExitCode"] = process.wait(timeout=LIMIT)
                        record["watcherState"] = "WATCH_PROCESS_FINISHED"
                    except subprocess.TimeoutExpired:
                        # Local watcher only; never sends a workflow cancellation.
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=5)
                        record["watchExitCode"] = process.returncode
                        record["watcherState"] = "WATCH_TIMEOUT_NOT_WORKFLOW_RESULT"
                finally:
                    # A local evidence-write/API wrapper failure must not orphan gh.
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=5)
        record["watcherObservedEndUTC"] = utc().isoformat()
        write(output / "WATCH_RESULT.json", record)
        after = api(endpoint, output / "AFTER_WATCH_RUN.json")
        verify_run(after, args)
        record.update(workflowOutcome=after.get("conclusion"), workflowStatus=after["status"],
                      workflowHeadVerified=True, workflowUpdatedAtUTC=after.get("updated_at"))
        if after["status"] == "completed":
            jobs = collect(args.run_id, "jobs", output)
            artifacts = collect(args.run_id, "artifacts", output)
            record["actualJobCompletedAtUTC"] = {str(j["id"]): j.get("completed_at") for j in jobs["jobs"]}
            record["artifactCount"] = artifacts["total_count"]
        record["nativeOutcome"] = "NOT_EVALUATED_ARTIFACTS_REQUIRED"
        write(output / "WATCH_RESULT.json", record)
        print(json.dumps(record, indent=2), flush=True)
    except Exception as error:
        write(output / "WATCH_PRECONDITION_OR_COLLECTION_ERROR.json", {
            "atUTC": utc().isoformat(), "errorType": type(error).__name__,
            "message": str(error), "workflowCancelled": False,
            "nativeOutcome": "NOT_EVALUATED"
        })
        raise

if __name__ == "__main__":
    main()
