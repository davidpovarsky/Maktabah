import base64,gzip,hashlib,json,pathlib,re,shutil,subprocess,traceback
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='409d28b2d5c3c72665081465ab628e53528645c6'
COMMIT='aaa4ebc36d28254a635d9157c61376909f6e4321'
PARENT='8223dab6d0031027fb08998a5043bc97228ff983'
DONOR='/mnt/development/projects/worktrees/Maktabah-wave3-hidden-active-phone-group-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127'
FOLDER='docs/ui-routing/wave3-hidden-active-phone-group-native-20261127'
PROOF='docs/hq-integration/wave3-hidden-active-phone-group-native-intake-20261127'
HELPER='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
SELECTOR='Maktabah-iOSUITests/NativeHiddenActivePhoneWorkspaceSelectionAcceptanceTests.swift'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def capacity():assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,COMMIT);assert rev(COMMIT+'^')==PARENT
 artifactRaw=show(COMMIT,FOLDER+'/ARTIFACTS.json');assert sha(artifactRaw)=='29811acde0f9e70bfac93c02763dd4f4fb2838d79edee332a07b9b556fb1388b'
 artifacts=json.loads(artifactRaw);assert len(artifacts['files'])==7 and artifacts['newTest']['path']==SELECTOR
 for row in artifacts['files']:pin(show(COMMIT,FOLDER+'/'+row['path']),row)
 paths=set(git('diff-tree','--no-commit-id','--name-only','-r',COMMIT).decode().splitlines())
 assert paths=={SELECTOR,FOLDER+'/ARTIFACTS.json'}|{FOLDER+'/'+r['path']for r in artifacts['files']}
 git('diff','--check',COMMIT+'^',COMMIT)
 resultRaw=show(COMMIT,FOLDER+'/RESULT.json');assert sha(resultRaw)=='73724ac6dbb80fe8f86a2e55d3a3592c97adc62ef4c7fbfd52d6fd775dfb3dfc'
 donor=json.loads(resultRaw)
 assert donor['sourceDependency']==PARENT and donor['selectors']==6 and donor['native']==donor['AppSDKTypecheck']==0
 old=show(BASE,HELPER);pin(old,donor['observedPrefix'])
 assert old==show(donor['observedRoot'],HELPER)
 assert old[:donor['originalPrefix']['bytes']]==show(donor['originalBase'],HELPER)
 suffix=show(COMMIT,FOLDER+'/proposal/NATIVE_HELPER_ADDITION.swift');pin(suffix,donor['suffix'])
 combined=old+suffix;pin(combined,donor['combinedObserved'])
 selector=show(COMMIT,SELECTOR);pin(selector,donor['selector']);pin(selector,artifacts['newTest'])
 methods=lambda b:set(re.findall(rb'func\s+(\w+)\s*\(',b))
 assert not methods(old).intersection(methods(suffix))
 declarations=re.findall(r'func\s+(test\w+)\s*\(',selector.decode());assert len(declarations)==len(set(declarations))==6
 validationRaw=show(COMMIT,FOLDER+'/evidence/VALIDATION.json');assert sha(validationRaw)=='92858c6633bd88cb3ed9dbe25f03f5635d91bdcb232ee2f517117ebca2c7e412'
 validation=json.loads(validationRaw)
 assert validation['status']=='PASS_SOURCE_SYNTAX_ONLY_NATIVE_NOT_RUN'and validation['native']==validation['SDKTypecheck']==0
 assert [(s['name'],s['exit'])for s in validation['steps']]==[('frozen-helper',0),('observed-helper',0),('selectors',0)]
 pin(show(BASE,'Maktabah.xcodeproj/project.pbxproj'),validation['originalPBX'])
 raw=json.loads(gzip.decompress(show(COMMIT,FOLDER+'/evidence/RAW.json.gz')));assert len(raw['files'])==13
 actual={}
 for row in raw['files']:
  assert row['path']not in actual;b=base64.b64decode(row['base64'],validate=True);pin(b,row);actual[row['path']]=b
 assert actual['ObservedRootWithSuffix.swift']==combined and actual['NATIVE_HELPER_ADDITION.swift']==suffix and actual[pathlib.Path(SELECTOR).name]==selector
 for row in validation['artifacts']:pin(actual[row['path']],row)
 sourceProof=show(BASE,'docs/hq-integration/wave3-hidden-active-phone-group-intake-20261127/RESULT.json')
 assert sha(sourceProof)=='21e26d081807299808db9fa2df97952052b84a161114a45293622d25e79e0475'
 for row in json.loads(sourceProof)['sourceFiles']:pin(show(BASE,row['path']),row['after'])
 protected=['Source','Vendor','Scripts','.github','docs/architecture','Maktabah.xcodeproj']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',COMMIT)
 picked=rev('HEAD');assert not git('status','--porcelain')
 assert (ROOT/HELPER).read_bytes()==old
 (ROOT/HELPER).write_bytes(combined)
 git('add','--sparse','--',HELPER);git('diff','--cached','--check')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Append reviewed hidden phone Group system acceptance helpers to original Annotation prefix')
 joined=rev('HEAD')
 assert set(git('diff','--name-only',BASE,'HEAD','--','Maktabah-iOSUITests').decode().splitlines())=={HELPER,SELECTOR}
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 result={'schema':'otzaria.wave3.hidden-phone-group-native-intake.v1','base':BASE,'donor':COMMIT,'picked':picked,'explicitHelperJoin':joined,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'testPaths':2,'donorDocsPaths':8,'originalHelper':donor['observedPrefix'],'appendedSuffix':donor['suffix'],'combinedHelper':donor['combinedObserved'],'sourceDependencyIntakeSHA256':sha(sourceProof),'rawFilesVerified':len(raw['files']),'originalSynchronizedTargetPBX':validation['originalPBX'],'selectors':declarations,'syntaxOnlyEvidenceSHA256':sha(validationRaw),'sourceReview':{'root':'Exact original Back/Library/History/Search/background setup, real cached AppEntity, production AppIntent, original TextKit/workspace/scene receipt; source read only.','peer':'navigation_fix reviewed exact3848a922 suffix and0eb7a591 selector; no demonstrated source blocker, no execution.'},'protectedTrees':trees,'newTestExecutions':0,'nativeRuns':0,'AppleSDK':'NOT_RUN','fixture':'Original miniTest10 only, no production acceptance','open':donor['open']+['Full Native116/Release114+2 on final production candidate','Original owner signatures, target merge and signed TestFlight']}
 dump(proof/'RESULT.json',result)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record exact hidden phone Group native selector join without execution claims')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'helperJoin':joined,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free};dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
