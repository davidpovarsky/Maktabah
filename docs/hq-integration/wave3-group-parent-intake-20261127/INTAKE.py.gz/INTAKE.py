import base64,gzip,hashlib,json,pathlib,shutil,subprocess,traceback
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='aa88b56b2e5fea1bf91de8a3e993e494ec41d96f'
PARENT='37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be'
DONOR='40847b8494cae95acaeb7d03ec5cdc6dbd2347bb'
DONOR_ROOT='/home/ubuntu/.codex/worktrees/Maktabah-wave3-group-parent-selection-20261127'
D='docs/ui-routing/wave3-group-parent-selection-20261127'
PROOF='docs/hq-integration/wave3-group-parent-intake-20261127'
SESSION='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
BRANCH='codex/otzaria-wave3-integration-20261127'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def capsule(name,count):
 x=json.loads(gzip.decompress(show(DONOR,D+'/'+name)));assert len(x['files'])==count
 out={}
 for row in x['files']:
  assert row['path']not in out
  b=base64.b64decode(row['base64'],validate=True);pin(b,row);out[row['path']]=b
 return x,out
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain')
 assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR_ROOT,DONOR)
 assert rev(DONOR+'^')==PARENT
 raw=show(DONOR,D+'/ARTIFACTS.json');assert sha(raw)=='88f7c823f0b65f8133f6b116decac33e9803f8d6d6219a03aac5ebb8080ebbbb'
 artifacts=json.loads(raw);assert len(artifacts['files'])==37 and len(artifacts['sourceFiles'])==4
 paths=git('diff-tree','--no-commit-id','--name-only','-r',DONOR).decode().splitlines()
 assert len(paths)==42 and set(paths)=={r['path']for r in artifacts['sourceFiles']}|{D+'/'+r['path']for r in artifacts['files']}|{D+'/ARTIFACTS.json'}
 for row in artifacts['files']:pin(show(DONOR,D+'/'+row['path']),row)
 for row in artifacts['sourceFiles']:
  pin(show(DONOR,row['path']),row)
  old=show(BASE,row['path']);assert old==show(PARENT,row['path'])and len(old)==row['beforeBytes']and sha(old)==row['beforeSHA256']
 rawInfo,rawFiles=capsule('evidence/RAW_CONTROLS.json.gz',263)
 coreInfo,coreFiles=capsule('evidence/READ_ONLY_CORE.json.gz',42)
 sourceInfo,sourceFiles=capsule('proposal/SOURCE.json.gz',30)
 for path,b in coreFiles.items():
  if path.startswith('inputs/Source/'):assert show(BASE,path.removeprefix('inputs/'))==b,path
 for path,b in sourceFiles.items():
  if path.startswith(('baseline/Source/','original-inputs/Source/')):assert show(BASE,path.split('/',1)[1])==b,path
  if path.startswith('source/Source/'):assert show(DONOR,path.removeprefix('source/'))==b,path
 raw=show(DONOR,D+'/evidence/RESULT.json');assert sha(raw)=='a0fcb555427a52298ed82d75d55c02fa90c389ad4ee4d1f195b714e02432a480'
 result=json.loads(raw)
 assert result['nativeRuns']==0 and result['AppleSDK']=='NOT_RUN'
 assert result['portable']['pass']==25 and result['portable']['fail']==0
 assert result['candidate']['pass']==21 and result['candidate']['fail']==0
 assert result['original-before-feature']['pass']==0 and result['original-before-feature']['fail']==2
 assert result['visibilityNegative']['pass']==0 and result['visibilityNegative']['fail']==2
 assert result['portableReuse']['noRerun']is True
 rawByHash={sha(b):b for b in rawFiles.values()}
 for step in result['steps']:
  assert step['exit']==(1 if step['name']in ['run-original-before-feature','run-visible-parent-counterfactual']else 0),step['name']
  for value in step['logs'].values():pin(rawByHash[value['sha256']],value)
 for name in ['result','log','input']:pin(rawByHash[result['portableReuse'][name]['sha256']],result['portableReuse'][name])
 assert json.loads(rawByHash[result['portableReuse']['log']['sha256']])==result['portable']
 for label,stepName in [('candidate','run-candidate'),('original-before-feature','run-original-before-feature'),('visibilityNegative','run-visible-parent-counterfactual')]:
  step=next(x for x in result['steps']if x['name']==stepName)
  assert json.loads(rawByHash[step['logs']['stdout']['sha256']])==result[label]
 for row in result['sourceJoins']:pin(show(DONOR if row['origin']=='source'else BASE,row['path']),row)
 for row in result['compiledInputInventory']:assert row['sha256']in rawByHash,row['path']
 edits=json.loads(show(DONOR,D+'/proposal/SESSION_EDITS.json'));assert len(edits)==13
 join=json.loads(show(DONOR,D+'/proposal/SESSION_JOIN.json'))
 old=show(BASE,SESSION);pin(old,join['base']);new=old.decode()
 for row in edits:assert new.count(row['before'])==1;new=new.replace(row['before'],row['after'],1)
 new=new.encode();pin(new,join['candidate'])
 assert new==sourceFiles['proposal-candidate/'+SESSION]
 inverse=new.decode()
 for row in reversed(edits):assert inverse.count(row['after'])==1;inverse=inverse.replace(row['after'],row['before'],1)
 assert inverse.encode()==old
 protected=['Vendor','Maktabah.xcodeproj','Scripts','.github','docs/architecture','Source/Otzaria/Actions','Maktabah-iOSUITests']
 trees={p:rev(BASE+':'+p)for p in protected}
 git('diff','--check',PARENT,DONOR)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',DONOR)
 picked=rev('HEAD');assert not git('status','--porcelain')
 target=ROOT/SESSION;assert target.read_bytes()==old;target.write_bytes(new)
 assert git('diff','--name-only').decode().splitlines()==[SESSION]
 git('diff','--check');git('add','--sparse','--',SESSION)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Connect exact Group selection through the original Viewer parent')
 sessionCommit=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 assert set(git('diff','--name-only',BASE,'HEAD','--','Source').decode().splitlines())=={SESSION}|{r['path']for r in artifacts['sourceFiles']}
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 report={'schema':'otzaria.wave3.group-parent-intake.v1','base':BASE,'donor':DONOR,'donorBase':PARENT,'picked':picked,'sessionCommit':sessionCommit,
  'sourceFiles':artifacts['sourceFiles'],'sourceTree':rev('HEAD:Source'),'protectedTrees':trees,'sessionJoin':join,'sessionHunks':13,'inverseExact':True,
  'capsulesVerified':{'rawControls':263,'readOnlyCore':42,'source':30},'sourceJoins':len(result['sourceJoins']),
  'actualPortableControls':{'pass':25,'fail':0},'actualOriginalDomainControls':{'pass':21,'fail':0},
  'preservedOriginalBeforeFeature':{'pass':0,'fail':2},'preservedRemoveVisibility':{'pass':0,'fail':2},
  'reusedFullSyntaxParses':5,'reexecutedControls':0,'AppleSDK':'NOT_RUN','nativeRuns':0,
  'scope':'Exact original Group/Viewer/Store/persistence/Adapter and Core parent selection; declared domain/UIKit/Resolver/Reader boundaries. No final native acceptance.',
  'stillOpen':['Cold pre-token Reader invocation','Hidden already-active phone Group','App SDK and native iPad/iPhone acceptance','Final Native116 and Release114+2','Real owner gate and final signed production release']}
 dump(proof/'RESULT.json',report)
 (proof/'README.md').write_text('# Group parent selection admission\n\nRoot admitted the exact four-file source packet and its38-file evidence packet, then applied the13 separately reviewed Session hunks. All263 raw control files,42 Core evidence files,30 source-capsule files and23 current source joins were rechecked. Inverting the Session proposal reproduces every original byte.\n\nActual prior execution is25/25 portable Core/UIRouting/Host controls and21/21 original domain controls. The original feature absence and removal of the repeated visible-parent check each remain0/2, with raw failures preserved. Five full frontend parses are reused by exact byte identity. These are source controls with declared platform boundaries; no SDK/native/production/physical acceptance is asserted.\n\nThe old ReaderTab nonnil condition remains in place. A nil active tab is accepted only by the finite workspace selection target and exact prepared empty group. Cold Reader invocation and already-active hidden phone groups are separate unfinished packets. Vendor, Core, PBX, scripts, native test sources and ownership policy were not changed.\n')
 git('add','--sparse','--',PROOF)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record exact Group parent integration and original-source evidence')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sessionCommit':sessionCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),
  'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'sourceControlsReused':46,'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
