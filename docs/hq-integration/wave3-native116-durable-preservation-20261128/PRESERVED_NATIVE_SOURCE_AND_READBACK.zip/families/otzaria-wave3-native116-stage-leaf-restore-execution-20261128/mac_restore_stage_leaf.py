#!/usr/bin/env python3
"""One exact opaque stage archive restoration receiver; no tree extraction."""
if not __debug__:
    raise RuntimeError("Optimized Python refused")
import base64,ctypes,datetime,errno,hashlib,json,os,signal,stat,struct,sys,time
STAGE_ROOT="/Users/m1/otzaria-native116-staged-archive-20261128"
ARCHIVE_NAME="native116-remaining-original-evidence.tar.gz"
ARCHIVE_BYTES=1272863810
ARCHIVE_SHA256="f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556"
SOURCE_DEVICE=16777232
MAC_RESERVE=2415919104
METADATA_RESERVE=4194304
MAX_XATTR=2*1024**2
BLOCK=65536
STARTED=time.monotonic()
DEADLINE=STARTED+1200
TERMINAL_GRACE_SECONDS=15
ORIGINAL_PARENT_PID=os.getppid()
WRITTEN=0
OUTPUT_BYTES=0
EXPECTED=json.loads("{\"parent\":{\"acl\":null,\"allocatedBytes\":0,\"atimeNS\":\"1795845249365515805\",\"birthtimeNS\":\"1795845188978746795\",\"bytes\":128,\"ctimeNS\":\"1795845188979074585\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215398,\"kind\":\"directory\",\"mode\":16832,\"mtimeNS\":\"1795845188979074585\",\"nlink\":4,\"pathBase64\":\"\",\"rdev\":0,\"uid\":501,\"xattrs\":[]},\"terminal\":{\"acl\":null,\"allocatedBytes\":65536,\"atimeNS\":\"1795845386429359912\",\"birthtimeNS\":\"1795845188978882252\",\"bytes\":65536,\"ctimeNS\":\"1795845386291846079\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215399,\"kind\":\"file\",\"mode\":33152,\"mtimeNS\":\"1795845386291846079\",\"nlink\":1,\"pathBase64\":\"U1RBR0VfVEVSTUlOQUwuanNvbg==\",\"rdev\":0,\"uid\":501,\"xattrs\":[]},\"archive\":{\"acl\":null,\"allocatedBytes\":1272864768,\"atimeNS\":\"1795845385698193451\",\"birthtimeNS\":\"1795845188979067835\",\"bytes\":1272863810,\"ctimeNS\":\"1795845386291328289\",\"device\":16777232,\"flags\":0,\"gid\":20,\"inode\":80215400,\"kind\":\"file\",\"mode\":33024,\"mtimeNS\":\"1795845337662706536\",\"nlink\":1,\"pathBase64\":\"bmF0aXZlMTE2LXJlbWFpbmluZy1vcmlnaW5hbC1ldmlkZW5jZS50YXIuZ3o=\",\"rdev\":0,\"uid\":501,\"xattrs\":[]}}")
NATIVE_FCNTL_HEADER="/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.0.sdk/usr/include/sys/fcntl.h"
NATIVE_FCNTL_HEADER_BYTES=27609
NATIVE_FCNTL_HEADER_SHA256="9aca8ca87031ab7b670617e5af8b15a0cad8f34f7ab3bdb5dd799eb153b3ad0e"
SYMLINK_FLAG=0x00200000
PYTHON_SYMLINK_FLAG=getattr(os,"O_SYMLINK",None)
def require(c,m):
    if not c: raise RuntimeError(m)
def canonical(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode("ascii")
def digest(b):return hashlib.sha256(b).hexdigest()
def b64(b):return base64.b64encode(b).decode("ascii")
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def capacity():
    v=os.statvfs("/System/Volumes/Data")
    require(type(v.f_frsize) is int and 0<v.f_frsize<=1024**2,"Qualified finite allocation unit")
    remain=ARCHIVE_BYTES-WRITTEN
    require(0<=remain<=ARCHIVE_BYTES,"Finite remaining payload")
    rounded=((remain+v.f_frsize-1)//v.f_frsize)*v.f_frsize
    return {"available":v.f_bavail*v.f_frsize,"unit":v.f_frsize,
            "remainingPayload":remain,"roundedRemaining":rounded,"metadataReserve":METADATA_RESERVE}
def guard():
    require(time.monotonic()<DEADLINE,"Owned receiver1200-second deadline")
    require(os.getppid()==ORIGINAL_PARENT_PID,"Original SSH parent detached")
    v=capacity()
    require(v["available"]>=MAC_RESERVE+v["roundedRemaining"]+METADATA_RESERVE,
            "Original Mac floor plus all remaining payload and metadata reserve")
def alarm(_s,_f):raise RuntimeError("Owned receiver alarm")
def terminal_alarm(_s,_f):os._exit(124)
def event(name,value):
    global OUTPUT_BYTES
    raw=canonical({"event":name,"utc":utc(),"value":value})+b"\n"
    require(len(raw)<=16384 and OUTPUT_BYTES+len(raw)<=32768,"Finite receiver metadata output")
    p=0
    while p<len(raw):
        n=os.write(1,raw[p:]);require(n>0,"Receiver report write");p+=n
    OUTPUT_BYTES+=len(raw)

def identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid, s.st_nlink,
            s.st_size, str(s.st_mtime_ns), str(s.st_ctime_ns), s.st_flags, s.st_rdev)

class AttrList(ctypes.Structure):
    _fields_ = [('count', ctypes.c_uint16), ('reserved', ctypes.c_uint16),
                ('common', ctypes.c_uint32), ('vol', ctypes.c_uint32),
                ('directory', ctypes.c_uint32), ('file', ctypes.c_uint32), ('fork', ctypes.c_uint32)]


LIB = ctypes.CDLL(None, use_errno=True)
LIB.openat.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
LIB.openat.restype = ctypes.c_int
LIB.flistxattr.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
LIB.flistxattr.restype = ctypes.c_ssize_t
LIB.fgetxattr.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.c_int]
LIB.fgetxattr.restype = ctypes.c_ssize_t
LIB.acl_get_fd_np.argtypes = [ctypes.c_int, ctypes.c_int]
LIB.acl_get_fd_np.restype = ctypes.c_void_p
LIB.acl_to_text.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ssize_t)]
LIB.acl_to_text.restype = ctypes.c_void_p
LIB.acl_free.argtypes = [ctypes.c_void_p]
LIB.acl_free.restype = ctypes.c_int
LIB.fgetattrlist.argtypes = [ctypes.c_int, ctypes.POINTER(AttrList), ctypes.c_void_p, ctypes.c_size_t, ctypes.c_ulong]
LIB.fgetattrlist.restype = ctypes.c_int

def qualify_native_metadata_abi():
    # This small read qualifies the same installed header for every producer
    # launch. It grants no access to source data and never writes SDK files.
    fd = os.open(NATIVE_FCNTL_HEADER, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size == NATIVE_FCNTL_HEADER_BYTES,
                'Installed native header type/size changed')
        raw = bytearray()
        while len(raw) <= NATIVE_FCNTL_HEADER_BYTES:
            block = os.read(fd, NATIVE_FCNTL_HEADER_BYTES + 1 - len(raw))
            if not block: break
            raw.extend(block)
        require(len(raw) == NATIVE_FCNTL_HEADER_BYTES and
                digest(raw) == NATIVE_FCNTL_HEADER_SHA256,
                'Installed native header byte identity changed')
        definitions = [line.split()[:3] for line in bytes(raw).splitlines()
                       if line.split()[:2] == [b'#define', b'O_SYMLINK']]
        require(definitions == [[b'#define', b'O_SYMLINK', b'0x00200000']],
                'Installed O_SYMLINK definition changed')
        require(identity(os.fstat(fd)) == identity(before) and
                identity(os.stat(NATIVE_FCNTL_HEADER, follow_symlinks=False)) == identity(before),
                'Installed native header replaced during qualification')
    finally:
        os.close(fd)
    return {'headerPath': NATIVE_FCNTL_HEADER, 'headerBytes': NATIVE_FCNTL_HEADER_BYTES,
            'headerSHA256': NATIVE_FCNTL_HEADER_SHA256, 'symlinkFlag': SYMLINK_FLAG,
            'pythonExposesSymlinkFlag': PYTHON_SYMLINK_FLAG is not None,
            'metadataOpen': 'native libc openat with pinned parent and single final component'}

def extended_metadata(parent_fd, name, before):
    # Darwin O_SYMLINK opens the link itself. Ordinary entries use O_NOFOLLOW.
    # Every native metadata call consumes this verified descriptor directly;
    # there is no /dev/fd path spelling or re-resolution of a source ancestor.
    flags = os.O_RDONLY | (SYMLINK_FLAG if stat.S_ISLNK(before.st_mode) else os.O_NOFOLLOW)
    if stat.S_ISDIR(before.st_mode): flags |= os.O_DIRECTORY
    raw_name = os.fsencode(name)
    require(raw_name and raw_name != b'..' and b'/' not in raw_name and b'\0' not in raw_name,
            'Native metadata open requires one exact final component')
    fd = LIB.openat(parent_fd, raw_name, flags)
    if fd < 0: raise OSError(ctypes.get_errno(), 'Native metadata openat failed')
    try:
        os.set_inheritable(fd, False)
        require(identity(os.fstat(fd)) == identity(before), 'Metadata descriptor identity mismatch')
        value = descriptor_metadata(fd, before)
        require(identity(os.fstat(fd)) == identity(before), 'Metadata descriptor changed')
        require(identity(os.stat(name, dir_fd=parent_fd, follow_symlinks=False)) == identity(before),
                'Metadata source name replaced')
        return value
    finally:
        os.close(fd)

def descriptor_metadata(fd, before):
    options = 0x0020  # XATTR_SHOWCOMPRESSION; fd already identifies the link itself.
    size = LIB.flistxattr(fd, None, 0, options)
    require(0 <= size <= MAX_XATTR, 'xattr name list unavailable/over bound')
    names = ctypes.create_string_buffer(max(1, size))
    require(LIB.flistxattr(fd, names, size, options) == size, 'xattr names changed')
    attributes = []
    for attribute in sorted(x for x in names.raw[:size].split(b'\0') if x):
        guard(); n = LIB.fgetxattr(fd, attribute, None, 0, 0, options)
        require(0 <= n <= MAX_XATTR, 'xattr payload unavailable/over bound')
        value = ctypes.create_string_buffer(max(1, n))
        require(LIB.fgetxattr(fd, attribute, value, n, 0, options) == n, 'xattr changed')
        raw = value.raw[:n]
        attributes.append({'nameBase64': b64(attribute), 'valueBase64': b64(raw),
                           'bytes': n, 'sha256': digest(raw)})
    ctypes.set_errno(0)
    acl = LIB.acl_get_fd_np(fd, 0x00000100)
    acl_value = None
    if not acl:
        require(ctypes.get_errno() == errno.ENOENT, 'ACL inspection failed')
    else:
        length = ctypes.c_ssize_t()
        text = LIB.acl_to_text(acl, ctypes.byref(length))
        try:
            require(text and 0 <= length.value <= MAX_XATTR, 'ACL text unavailable/over bound')
            raw = ctypes.string_at(text, length.value)
            acl_value = {'textBase64': b64(raw), 'bytes': len(raw), 'sha256': digest(raw)}
        finally:
            if text: LIB.acl_free(text)
            LIB.acl_free(acl)
    attrs = AttrList(5, 0, 0x00000200, 0, 0, 0, 0)
    output = ctypes.create_string_buffer(64)
    require(LIB.fgetattrlist(fd, ctypes.byref(attrs), output, 64, 0) == 0, 'Exact birthtime unavailable')
    require(struct.unpack_from('=I', output.raw, 0)[0] == 20, 'Birthtime layout mismatch')
    seconds, ns = struct.unpack_from('=qq', output.raw, 4)
    require(0 <= ns < 10**9 and abs(seconds - int(before.st_birthtime)) <= 1, 'Birthtime check')
    return {'xattrs': attributes, 'acl': acl_value, 'birthtimeNS': str(seconds * 10**9 + ns)}

def record(parent_fd, name, relative, before, full):
    guard()
    kind = 'file' if stat.S_ISREG(before.st_mode) else 'directory' if stat.S_ISDIR(before.st_mode) else 'symlink'
    require(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode) or stat.S_ISLNK(before.st_mode), 'Unsupported special source entry')
    require(before.st_dev == SOURCE_DEVICE, 'Cross-device source entry')
    metadata = extended_metadata(parent_fd, name, before)
    row = {'pathBase64': b64(relative), 'kind': kind, 'device': before.st_dev,
           'inode': before.st_ino, 'mode': before.st_mode, 'uid': before.st_uid,
           'gid': before.st_gid, 'nlink': before.st_nlink, 'bytes': before.st_size,
           'allocatedBytes': before.st_blocks * 512, 'mtimeNS': str(before.st_mtime_ns),
           'ctimeNS': str(before.st_ctime_ns), 'atimeNS': str(before.st_atime_ns),
           'flags': before.st_flags, 'rdev': before.st_rdev, **metadata}
    if kind == 'file' and full:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
        try:
            require(identity(os.fstat(fd)) == identity(before), 'File replaced before read')
            h, count = hashlib.sha256(), 0
            while True:
                guard(); block = os.read(fd, BLOCK)
                if not block: break
                count += len(block); require(count <= before.st_size, 'Source grew during hash'); h.update(block)
            require(count == before.st_size and identity(os.fstat(fd)) == identity(before), 'File changed during hash')
            row['sha256'] = h.hexdigest()
        finally:
            os.close(fd)
    elif kind == 'symlink':
        row['targetBase64'] = b64(os.fsencode(os.readlink(name, dir_fd=parent_fd)))
    require(identity(os.stat(name, dir_fd=parent_fd, follow_symlinks=False)) == identity(before), 'Source path identity changed')
    require(extended_metadata(parent_fd, name, before) == metadata, 'Source extended metadata changed')
    return row

def stable(row,ignore=()):
    return {k:v for k,v in row.items() if k not in set(ignore)}
def open_parent():
    fd=os.open("/",os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        for part in STAGE_ROOT.split("/")[1:]:
            guard()
            child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
            os.close(fd);fd=child
        return fd
    except BaseException:
        os.close(fd);raise
def capture(fd,name):
    before=os.stat(name,dir_fd=fd,follow_symlinks=False)
    return record(fd,name,os.fsencode(name) if name!="." else b"",before,False)
def parent_check(fd):
    row=capture(fd,".")
    require(stable(row,("bytes","nlink","allocatedBytes","atimeNS","mtimeNS","ctimeNS"))
            ==stable(EXPECTED["parent"],("bytes","nlink","allocatedBytes","atimeNS","mtimeNS","ctimeNS")),
            "Original parent identity/ownership/permissions/flags/birthtime/xattrs/ACL")
    require(identity(os.stat(STAGE_ROOT,follow_symlinks=False))==identity(os.fstat(fd)),
            "Pinned parent name/descriptor join")
    return row
def sibling_check(fd,names,terminal_before=None):
    require(set(os.listdir(fd))==set(names),"Exact restored-stage namespace")
    row=capture(fd,"STAGE_TERMINAL.json")
    require(stable(row,("atimeNS",))==stable(EXPECTED["terminal"],("atimeNS",)),
            "Protected terminal sibling is unchanged")
    if terminal_before is not None:
        require(row==terminal_before,"Protected terminal metadata changed during restoration")
    parent_check(fd)
    return row
def exact_file(fd,parent,name,nlinks):
    s=os.fstat(fd);named=os.stat(name,dir_fd=parent,follow_symlinks=False)
    require(identity(s)==identity(named) and stat.S_ISREG(s.st_mode)
            and s.st_dev==SOURCE_DEVICE and s.st_uid==501 and s.st_gid==20
            and s.st_nlink==nlinks,"Exact owned file descriptor/name")
    return s
def empty_metadata(fd):
    s=os.fstat(fd);value=descriptor_metadata(fd,s)
    require(not value["xattrs"] and value["acl"] is None and s.st_flags==0,
            "Only actually empty xattrs/nullACL/zero flags supported")
    require(identity(os.fstat(fd))==identity(s),"Stable metadata descriptor")
    return value
def ns_value(value):
    require(type(value) is str and 1<=len(value)<=20 and value.isascii()
            and value.isdigit() and str(int(value))==value,"Exact bounded nanosecond decimal")
    return int(value)
def hash_stored(fd,parent,name):
    expected=identity(os.fstat(fd))
    os.lseek(fd,0,os.SEEK_SET);h=hashlib.sha256();count=0
    while True:
        guard();require(identity(os.fstat(fd))==expected,"Stored file changed during full hash")
        raw=os.read(fd,1024**2)
        if not raw:break
        count+=len(raw);require(count<=ARCHIVE_BYTES,"Stored file size bound");h.update(raw)
    require(count==ARCHIVE_BYTES and h.hexdigest()==ARCHIVE_SHA256,"Full stored payload hash")
    exact_file(fd,parent,name,1)
    return {"bytes":count,"sha256":h.hexdigest()}
def main(request):
    global WRITTEN
    parent=payload=None;temp=None;published=False;temp_removed=False
    stage="ADMISSION";failure=None;report={}
    signal.signal(signal.SIGALRM,alarm);signal.alarm(1200)
    try:
        require(sys.platform=="darwin" and ctypes.sizeof(ctypes.c_void_p)==8
                and sys.flags.isolated and sys.dont_write_bytecode and os.geteuid()==501,
                "Qualified isolated original m1 runtime")
        require(PYTHON_SYMLINK_FLAG is None or
                (type(PYTHON_SYMLINK_FLAG) is int and PYTHON_SYMLINK_FLAG==SYMLINK_FLAG),
                "Native symlink flag agreement")
        require(os.utime in os.supports_fd and os.link in os.supports_dir_fd
                and os.unlink in os.supports_dir_fd and os.link in os.supports_follow_symlinks,
                "Required descriptor timestamp and exclusive link APIs")
        require(set(request)=={"schema","attemptID","pointerSHA256","authorizationSHA256","sourceSealSHA256",
                               "assetID","bytes","sha256"} and
                request["schema"]=="otzaria.native116-stage-restore-request/1"
                and request["assetID"]==803618998 and request["bytes"]==ARCHIVE_BYTES
                and request["sha256"]==ARCHIVE_SHA256,"Closed exact restore request")
        for k in ("pointerSHA256","authorizationSHA256","sourceSealSHA256"):
            require(type(request[k]) is str and len(request[k])==64 and
                    all(x in "0123456789abcdef" for x in request[k]),"Exact request SHA")
        aid=request["attemptID"]
        require(type(aid) is str and len(aid)==32 and all(c in "0123456789abcdef" for c in aid),
                "One fixed new attempt UUID")
        temp=".native116-restore-"+aid+".partial"
        guard();abi=qualify_native_metadata_abi()
        parent=open_parent();parent_before=parent_check(parent)
        terminal_before=sibling_check(parent,{"STAGE_TERMINAL.json"})
        require(ARCHIVE_NAME not in os.listdir(parent) and temp not in os.listdir(parent),
                "Absent final and exclusive temporary leaf")
        stage="CREATE_OWNED_TEMP"
        payload=os.open(temp,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=parent)
        require(not os.get_inheritable(payload),"Private noninheritable payload descriptor")
        exact_file(payload,parent,temp,1);empty_metadata(payload)
        os.fsync(payload);os.fsync(parent)
        created=capture(parent,temp)
        sibling_check(parent,{"STAGE_TERMINAL.json",temp},terminal_before)
        event("READY",{"request":request,"temporaryLeaf":temp,"createdMetadata":created,
                       "parentBefore":parent_before,"terminalBefore":terminal_before,
                       "capacity":capacity(),"nativeABI":abi,"existingLeafOverwritten":False})
        stage="RECEIVE_EXACT_PAYLOAD"
        h=hashlib.sha256()
        while WRITTEN<ARCHIVE_BYTES:
            guard();sibling_check(parent,{"STAGE_TERMINAL.json",temp},terminal_before)
            exact_file(payload,parent,temp,1)
            raw=os.read(0,min(BLOCK,ARCHIVE_BYTES-WRITTEN))
            require(raw,"Truncated authenticated payload stream")
            h.update(raw);p=0
            while p<len(raw):
                guard();n=os.write(payload,raw[p:]);require(n>0,"Owned temporary short write")
                p+=n;WRITTEN+=n
        require(os.read(0,1)==b"","No trailing payload/framing bytes")
        require(h.hexdigest()==ARCHIVE_SHA256,"Full incoming payload SHA256")
        os.fsync(payload)
        require(os.fstat(payload).st_size==ARCHIVE_BYTES,"Exact stored length")
        stage="FULL_STORED_FILE_HASH"
        stored=hash_stored(payload,parent,temp)
        empty_metadata(payload)
        stage="SUPPORTED_METADATA"
        os.fchmod(payload,0o400)
        os.utime(payload,ns=(ns_value(EXPECTED["archive"]["atimeNS"]),ns_value(EXPECTED["archive"]["mtimeNS"])))
        os.fsync(payload)
        supported=capture(parent,temp)
        require(supported["mode"]==33024 and supported["uid"]==501 and supported["gid"]==20
                and supported["flags"]==0 and supported["xattrs"]==[] and supported["acl"] is None
                and supported["atimeNS"]==EXPECTED["archive"]["atimeNS"]
                and supported["mtimeNS"]==EXPECTED["archive"]["mtimeNS"]
                and supported["bytes"]==ARCHIVE_BYTES and supported["nlink"]==1,
                "Actual complete supported metadata readback")
        sibling_check(parent,{"STAGE_TERMINAL.json",temp},terminal_before)
        exact_file(payload,parent,temp,1)
        stage="EXCLUSIVE_FINAL_LINK"
        # linkat semantics: fail if final exists; never overwriting rename.
        os.link(temp,ARCHIVE_NAME,src_dir_fd=parent,dst_dir_fd=parent,follow_symlinks=False)
        published=True
        os.fsync(parent)
        exact_file(payload,parent,temp,2);exact_file(payload,parent,ARCHIVE_NAME,2)
        sibling_check(parent,{"STAGE_TERMINAL.json",temp,ARCHIVE_NAME},terminal_before)
        stage="REMOVE_ONLY_NEW_TEMP_NAME"
        exact_file(payload,parent,temp,2);exact_file(payload,parent,ARCHIVE_NAME,2)
        os.unlink(temp,dir_fd=parent)
        temp_removed=True
        os.fsync(parent)
        exact_file(payload,parent,ARCHIVE_NAME,1)
        final=capture(parent,ARCHIVE_NAME)
        require(final["mode"]==33024 and final["uid"]==501 and final["gid"]==20
                and final["flags"]==0 and final["xattrs"]==[] and final["acl"] is None
                and final["atimeNS"]==EXPECTED["archive"]["atimeNS"]
                and final["mtimeNS"]==EXPECTED["archive"]["mtimeNS"] and final["bytes"]==ARCHIVE_BYTES,
                "Final supported metadata and exact bytes identity")
        sibling_check(parent,{"STAGE_TERMINAL.json",ARCHIVE_NAME},terminal_before)
        report={"status":"OPAQUE_STAGE_BYTES_RESTORED_WITH_SUPPORTED_METADATA","request":request,
                "storedFullHashBeforeMetadata":stored,"incomingSHA256":h.hexdigest(),
                "originalLeafMetadata":EXPECTED["archive"],"newLeafMetadata":final,
                "parentBefore":parent_before,"parentAfter":parent_check(parent),
                "terminalSiblingUnchanged":True,"newInodeCtimeBirthtimeAllocationRecorded":True,
                "inodeCtimeBirthtimeAllocationRestored":False,"fullTreeRestorePerformed":False,
                "temporaryNameRemoved":True,"publishedWithoutReplacement":True,
                "sourceNativeTreeTouched":False,"payloadReReadAfterFinalAtime":False}
    except BaseException as e:
        failure={"stage":stage,"type":type(e).__name__,"errno":e.errno if isinstance(e,OSError) else None,
                 "code":str(e)[:200] if type(e) is RuntimeError else None}
        report={"status":"RESTORE_FAILED_PARTIAL_STATE_PRESERVED","request":request,
                "failure":failure,"temporaryLeaf":temp,"writtenBytes":WRITTEN,
                "finalPublished":published,"temporaryNameRemoved":temp_removed,
                "noAutomaticCleanupOfPayload":True,"noAutomaticRetry":True}
    finally:
        # Bound only this receiver's terminal I/O; retain all partial payload states.
        signal.signal(signal.SIGALRM,terminal_alarm)
        signal.alarm(TERMINAL_GRACE_SECONDS)
        close_errors=[]
        if parent is not None:
            try:os.fsync(parent)
            except BaseException as e:close_errors.append({"operation":"parent-fsync","type":type(e).__name__})
        for fd in (payload,parent):
            if fd is not None:
                try:os.close(fd)
                except BaseException as e:close_errors.append({"operation":"close","type":type(e).__name__})
        if close_errors:
            report["status"]="RESTORE_FAILED_PARTIAL_STATE_PRESERVED"
        report.update({"closeErrors":close_errors,"seconds":time.monotonic()-STARTED,
                       "terminalGraceSeconds":TERMINAL_GRACE_SECONDS,
                       "noOtherSourceOrSiblingRemoved":True,"originalBirthtimeNeverSet":True})
        event("FINAL_RESULT",report)
        signal.alarm(0)
    return 0 if report["status"]=="OPAQUE_STAGE_BYTES_RESTORED_WITH_SUPPORTED_METADATA" else 2

