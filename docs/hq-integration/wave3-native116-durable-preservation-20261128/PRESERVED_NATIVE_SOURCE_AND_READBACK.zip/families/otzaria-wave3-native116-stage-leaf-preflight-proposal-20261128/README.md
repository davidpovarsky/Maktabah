# Native116 stage-leaf source packet

Status: source-only, unexecuted. This private packet preserves the exact 19,376-byte conditional plan and supplies a future read-only preflight collector plus an opaque-leaf restoration design. It grants no retirement, upload, authentication, live-source scan or build permission.

## Fixed source and evidence family

/home/ubuntu/otzaria-wave3-native116-stage-leaf-preflight-proposal-20261128

The complete family, including its one future actual-read-only-preflight directory and all retained failures, is capped at 2,097,152 allocated bytes. Original Root reserve: 1,593,835,520 bytes. The author and launcher refuse before any new allocation if the required margin is unavailable. The Mac live floor remains 2,415,919,104 bytes; SDK admission remains 15,032,385,536 bytes.

## Files

- CONDITIONAL_PLAN_ORIGINAL.json is the exact previously delivered 19,376-byte plan (SHA256 838c72dabf5d140bbf6de7643ad318e2178617071c145469c3d788b0025aaf1b). Its historical running-at-handoff state is not rewritten.
- STATUS_ADDENDUM.json preserves Root's later failed-readback report. There is no verified publication or new retirement authority.
- SOURCE_PLAN.json defines the fixed read-only phase, limits and unresolved coverage.
- mac_stage_leaf_preflight.py captures parent and all immediate siblings before archive content, hashes only the fixed existing stage archive, and retains bounded privileged consumer-query evidence.
- run_stage_leaf_preflight.py is the isolated Ubuntu launcher. It verifies the fixed source seal and SSH alias, preallocates finite private report slots, sends source in memory, preserves partial output and manages only its owned children.
- OPAQUE_LEAF_RESTORATION_DESIGN.json is a design, not an executable restorer. Birthtime/ACL/xattr/flags restoration is not fabricated; unsupported values remain explicit blockers or preserved-only metadata.
- ORIGINAL_PRODUCER.py, ORIGINAL_STAGE_HELPER.py and ORIGINAL_RUNTIME.py are inert byte-exact source references. They are never imported by the new launcher.
- SOURCE_REUSE.json and STATIC_SOURCE_PROOF.json distinguish exact reused metadata/lifetime bodies from new collector code. Source parsing and comparison do not constitute an executed collector, no-use result or restoration test.

## Review boundary

The target is only /Users/m1/otzaria-native116-staged-archive-20261128/native116-remaining-original-evidence.tar.gz, 1,272,863,810 bytes, SHA256 f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556. The stage parent/leaf historical identities are fixed. Other sibling contents, the 112,092-entry Native original, five external symlinks, two Git-reference dependencies, Windows bases, foreign work and simulators remain untouched.

A successful consumer query requires the collector's own exact read-only descriptor as a positive witness. Warnings, errors, unknown fields, missing fields, privilege failure, timeout or extra consumers cannot become a no-use success. This remains a point-in-time inspection, not a lease or future-consumer proof. No sibling content is read and no symlink target is followed.

Atime is captured before content and reported after; natural read effects are not erased. Every other captured metadata field must compare exactly before/after. Allocation is st_blocks information only, not APFS private extents or guaranteed reclaim.

Root must independently review this source, the eventual actual preflight, complete authenticated asset/member readback, exact restoration pointer and durable Git readback, then separately authorize PREDELETE/ACK. The current failed readback makes that qualification unresolved. Raw private API journals are not present in this packet and must remain private.

## Future command — not run

/usr/bin/sudo -u ubuntu -H /usr/bin/python3 -I -B <fixed-family>/run_stage_leaf_preflight.py --source-seal-sha256 <exact SOURCE_SEAL.json SHA256> collect-read-only

No automatic retry or alternate path exists. The future runtime directory must be absent. Source-only authoring may parse syntax and compare bodies but may not import these files or execute their functions.
