"""NEW fixed Native116 disk staging/transport helper; no automatic action.

The original producer and format are supplied as exact, hashed in-memory modules.
No authentication is accepted. Only a new fixed Mac directory is writable.
"""
if not __debug__:
    raise RuntimeError("Optimized staged transport is refused")
import datetime
import hashlib
import io
import json
import os
import pwd
import signal
import stat
import sys
import time

STAGE_ROOT = "/Users/m1/otzaria-native116-staged-archive-20261128"
ARCHIVE_NAME = "native116-remaining-original-evidence.tar.gz"
TERMINAL_NAME = "STAGE_TERMINAL.json"
ARCHIVE_BYTES = 1272863810
ARCHIVE_SHA256 = "f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556"
SNAPSHOT_SHA256 = "424c2e2f95b3616e39b51cbacc621678dc2899ceba857a2dd42b72b0a0597cc4"
PREPARED_SHA256 = "badb2383eb2b05d2c70a528bb6fdba9f2c61c921056ffc4bfe6df78a0f6b8a5d"
MAC_FLOOR = 2415919104
METADATA_ALLOWANCE = 4 * 1024**2
SLOT_BYTES = 64 * 1024
BLOCK = 1024**2
STARTED = time.monotonic()
ORIGINAL_PARENT = os.getppid()
DEADLINE = STARTED + 1200
P = F = None
LAST_ORIGINAL_TERMINAL = None


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode("ascii")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def free_bytes():
    v = os.statvfs("/System/Volumes/Data")
    return v.f_bavail * v.f_frsize


def rounded_payload_bytes():
    v = os.statvfs("/System/Volumes/Data")
    unit = v.f_frsize
    require(type(unit) is int and 0 < unit <= BLOCK, "Finite original filesystem allocation unit")
    return ((ARCHIVE_BYTES + unit - 1) // unit) * unit


def guard(addition=0):
    require(time.monotonic() < min(DEADLINE, P.DEADLINE), "Original 1200-second deadline")
    require(os.getppid() == ORIGINAL_PARENT, "Exact SSH parent detached")
    require(free_bytes() - addition >= MAC_FLOOR, "Unchanged Mac live floor")
    P.guard()


def timeout(_signal, _frame):
    raise RuntimeError("Original staged transport deadline")


def metadata(s):
    return {"device": s.st_dev, "inode": s.st_ino, "mode": s.st_mode,
            "uid": s.st_uid, "gid": s.st_gid, "nlink": s.st_nlink,
            "bytes": s.st_size, "allocatedBytes": s.st_blocks * 512,
            "mtimeNS": str(s.st_mtime_ns), "ctimeNS": str(s.st_ctime_ns),
            "flags": s.st_flags}


def directory_identity(fd):
    s = os.fstat(fd)
    require(stat.S_ISDIR(s.st_mode) and s.st_uid == 501 and s.st_gid == 20,
            "Exact owned Mac directory")
    return {"device": s.st_dev, "inode": s.st_ino, "mode": s.st_mode,
            "uid": s.st_uid, "gid": s.st_gid}


def open_absolute_directory(path):
    require(path.startswith("/") and all(x not in ("", ".", "..") for x in path.split("/")[1:]),
            "Fixed absolute directory")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in path.split("/")[1:]:
            guard()
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def same_file(fd, directory, name, expected):
    require(metadata(os.fstat(fd)) == expected, "Pinned archive descriptor changed")
    require(metadata(os.stat(name, dir_fd=directory, follow_symlinks=False)) == expected,
            "Pinned archive name changed")


def archive_kind(s):
    require(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_uid == 501 and s.st_gid == 20
            and s.st_size == ARCHIVE_BYTES, "Exact staged file type/link/owner/size")
    require(s.st_dev == F.SOURCE_DEVICE, "Staged archive must remain on original Mac filesystem")


def write_all(fd, raw, before_write=None):
    position = 0
    while position < len(raw):
        if before_write is not None:
            before_write(len(raw) - position)
        n = os.write(fd, raw[position:position + BLOCK])
        require(n > 0, "Short owned file write")
        position += n


def full_fd_hash(fd, directory, expected):
    same_file(fd, directory, ARCHIVE_NAME, expected)
    os.lseek(fd, 0, os.SEEK_SET)
    h = hashlib.sha256()
    count = 0
    while True:
        guard()
        same_file(fd, directory, ARCHIVE_NAME, expected)
        raw = os.read(fd, BLOCK)
        if not raw:
            break
        count += len(raw)
        require(count <= ARCHIVE_BYTES, "Staged file grew")
        h.update(raw)
    require(count == ARCHIVE_BYTES and h.hexdigest() == ARCHIVE_SHA256,
            "Full stored archive hash differs from original preparation")
    same_file(fd, directory, ARCHIVE_NAME, expected)
    return {"bytes": count, "sha256": h.hexdigest()}


class BoundedText:
    def __init__(self):
        self.parts = []
        self.count = 0

    def write(self, text):
        require(type(text) is str, "Producer terminal text")
        raw = text.encode("utf-8")
        require(self.count + len(raw) <= SLOT_BYTES, "Original producer terminal bound")
        self.parts.append(text)
        self.count += len(raw)
        return len(text)

    def flush(self):
        pass

    def body(self):
        return "".join(self.parts).encode("utf-8")


class OutputFacade:
    def __init__(self, binary):
        self.buffer = binary

    def write(self, _text):
        raise RuntimeError("Unexpected text on original binary source output")

    def flush(self):
        self.buffer.flush()


class NoOutput:
    def write(self, raw):
        require(not raw, "Reverify must emit no content")
        return 0

    def flush(self):
        pass


class StagedWriter:
    def __init__(self, fd, directory):
        self.fd = fd
        self.directory = directory
        self.count = 0

    def write(self, raw):
        require(type(raw) is bytes and len(raw) <= BLOCK, "Bounded original gzip output")
        require(self.count + len(raw) <= ARCHIVE_BYTES, "Exact staged payload cap")
        guard(len(raw) + SLOT_BYTES)
        write_all(self.fd, raw, lambda n: guard(min(n, BLOCK) + SLOT_BYTES))
        self.count += len(raw)
        used = sum(os.stat(n, dir_fd=self.directory, follow_symlinks=False).st_blocks * 512
                   for n in os.listdir(self.directory))
        require(used <= rounded_payload_bytes() + METADATA_ALLOWANCE, "Exact Mac staging allocation cap")
        return len(raw)

    def flush(self):
        guard()
        os.fsync(self.fd)


def original_request(request, mode, binary):
    global LAST_ORIGINAL_TERMINAL
    LAST_ORIGINAL_TERMINAL = None
    captured = BoundedText()
    original_stdout, original_stderr = sys.stdout, sys.stderr
    try:
        sys.stdout = OutputFacade(binary)
        sys.stderr = captured
        P.main({"mode": mode, "toolHashes": request["toolHashes"],
                "snapshotBase64": request["snapshotBase64"],
                "snapshotSHA256": SNAPSHOT_SHA256})
    finally:
        sys.stdout, sys.stderr = original_stdout, original_stderr
        preserved = captured.body()
        LAST_ORIGINAL_TERMINAL = {"rawBase64": F.b64(preserved), "rawSHA256": digest(preserved),
                                  "bytes": len(preserved)}
        # Original main clears its alarm; restore only the same absolute bound.
        remaining = min(DEADLINE, P.DEADLINE) - time.monotonic()
        if remaining > 0:
            signal.signal(signal.SIGALRM, timeout)
            signal.setitimer(signal.ITIMER_REAL, remaining)
    body = captured.body()
    lines = body.splitlines()
    require(len(lines) == 1, "Exactly one original producer terminal")
    value = json.loads(lines[0])
    require(value["schema"] == "otzaria.native116-owned-producer-terminal/1"
            and value["mode"] == mode and value["status"] == "SOURCE_VERIFIED_READ_ONLY"
            and value["sourceRoot"] == F.SOURCE_ROOT and value["sourceModified"] is False
            and value["snapshotSHA256"] == SNAPSHOT_SHA256, "Original source verification refused")
    if mode == "stream":
        require(value["archiveBytes"] == ARCHIVE_BYTES
                and value["archiveSHA256"] == ARCHIVE_SHA256
                and value["fullSourceBeforeAndAfter"] is True, "Original complete source/stream fence")
    else:
        require(value["fullCurrentSourceEqual"] is True, "Original full source reverify required")
    return {"terminal": value, "rawBase64": F.b64(body), "rawSHA256": digest(body)}


def write_slot(fd, value):
    raw = canonical(value)
    require(len(raw) <= SLOT_BYTES, "Complete terminal cannot be truncated")
    padded = raw + b" " * (SLOT_BYTES - len(raw))
    position = 0
    while position < len(padded):
        n = os.pwrite(fd, padded[position:], position)
        require(n > 0, "Short preallocated terminal write")
        position += n
    os.fsync(fd)
    return padded


def stage(request):
    parent = None
    directory = payload = slot = None
    slot_ready = False
    source = None
    try:
        guard(rounded_payload_bytes() + METADATA_ALLOWANCE)
        parent = open_absolute_directory("/Users/m1")
        os.mkdir(STAGE_ROOT.rsplit("/", 1)[1], 0o700, dir_fd=parent)
        os.fsync(parent)
        directory = os.open(STAGE_ROOT.rsplit("/", 1)[1],
                            os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        owned = directory_identity(directory)
        require(owned["device"] == F.SOURCE_DEVICE, "Staging on exact Mac volume")
        slot = os.open(TERMINAL_NAME, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                       0o600, dir_fd=directory)
        write_all(slot, b" " * SLOT_BYTES, lambda n: guard(n))
        os.fsync(slot)
        slot_ready = True
        payload = os.open(ARCHIVE_NAME, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                          0o600, dir_fd=directory)
        sink = StagedWriter(payload, directory)
        source = original_request(request, "stream", sink)
        require(sink.count == ARCHIVE_BYTES, "Complete original deterministic archive")
        guard()
        os.fsync(payload)
        original_metadata = metadata(os.fstat(payload))
        archive_kind(os.fstat(payload))
        check = full_fd_hash(payload, directory, original_metadata)
        os.fchmod(payload, 0o400)
        os.fsync(payload)
        pinned = metadata(os.fstat(payload))
        archive_kind(os.fstat(payload))
        same_file(payload, directory, ARCHIVE_NAME, pinned)
        require(set(os.listdir(directory)) == {ARCHIVE_NAME, TERMINAL_NAME}, "Exact owned stage membership")
        result = {"schema": "otzaria.native116-staged-archive/1",
                  "status": "STAGED_ARCHIVE_VERIFIED", "utc": utc(), "requestID": request["requestID"],
                  "stageRoot": STAGE_ROOT, "directoryIdentity": owned,
                  "archive": {"name": ARCHIVE_NAME, "bytes": ARCHIVE_BYTES,
                              "sha256": ARCHIVE_SHA256, "metadata": pinned},
                  "storedFullReadback": check, "originalProducer": source,
                  "preparedSHA256": PREPARED_SHA256, "snapshotSHA256": SNAPSHOT_SHA256,
                  "stageHelperSHA256": request["stageHelperSHA256"],
                  "originalSourceRetained": True, "sourceModified": False,
                  "uploaded": False, "retirementAuthorized": False,
                  "macFreeBytes": free_bytes(), "macFloorBytes": MAC_FLOOR,
                  "payloadAndMetadataAllocatedBytes": sum(
                      os.stat(n, dir_fd=directory, follow_symlinks=False).st_blocks * 512
                      for n in os.listdir(directory))}
        guard()
        raw = write_slot(slot, result)
        os.fsync(directory)
        os.lseek(slot, 0, os.SEEK_SET)
        require(os.read(slot, SLOT_BYTES + 1) == raw, "Staged terminal durable byte equality")
        same_file(payload, directory, ARCHIVE_NAME, pinned)
        require(directory_identity(directory) == owned, "Stage directory replaced")
        return {"schema": "otzaria.native116-stage-transfer-receipt/1", "status": "STAGED_ARCHIVE_VERIFIED",
                "stageRoot": STAGE_ROOT, "terminalBytes": len(raw), "terminalSHA256": digest(raw),
                "terminal": result, "pid": os.getpid(), "parentPID": ORIGINAL_PARENT,
                "elapsedSeconds": time.monotonic() - STARTED}
    except BaseException as error:
        failure = {"schema": "otzaria.native116-staged-archive/1",
                   "status": "FAILED_STAGED_ARCHIVE_NOT_ACCEPTED", "utc": utc(),
                   "requestID": request["requestID"], "stageRoot": STAGE_ROOT,
                   "errorType": type(error).__name__, "exceptionTextRecorded": False,
                   "partialOwnedArchiveRetained": payload is not None,
                   "originalProducer": source, "originalProducerRaw": LAST_ORIGINAL_TERMINAL,
                   "sourceModified": False, "uploaded": False, "automaticRetry": False, "retirementAuthorized": False}
        if slot is not None and slot_ready:
            write_slot(slot, failure)
        raise
    finally:
        for fd in (payload, slot, directory, parent):
            if fd is not None:
                os.close(fd)


def open_staged(request):
    directory = open_absolute_directory(STAGE_ROOT)
    payload = slot = None
    try:
        require(set(os.listdir(directory)) == {ARCHIVE_NAME, TERMINAL_NAME}, "Exact completed stage membership")
        slot = os.open(TERMINAL_NAME, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory)
        s = os.fstat(slot)
        require(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_size == SLOT_BYTES,
                "Pinned finite stage terminal")
        before = metadata(s)
        raw = bytearray()
        while len(raw) <= SLOT_BYTES:
            guard()
            part = os.read(slot, min(BLOCK, SLOT_BYTES + 1 - len(raw)))
            if not part:
                break
            raw.extend(part)
        require(len(raw) == SLOT_BYTES and digest(raw) == request["stagedTerminalSHA256"],
                "Root-reviewed stage terminal hash")
        require(metadata(os.fstat(slot)) == before
                and metadata(os.stat(TERMINAL_NAME, dir_fd=directory, follow_symlinks=False)) == before,
                "Stage terminal identity changed")
        value = json.loads(raw)
        require(value["status"] == "STAGED_ARCHIVE_VERIFIED"
                and value["schema"] == "otzaria.native116-staged-archive/1"
                and value["preparedSHA256"] == PREPARED_SHA256
                and value["snapshotSHA256"] == SNAPSHOT_SHA256
                and value["stageRoot"] == STAGE_ROOT
                and value["stageHelperSHA256"] == request["stageHelperSHA256"],
                "Exact successful original stage")
        require(directory_identity(directory) == value["directoryIdentity"], "Same original staged directory")
        pin = value["archive"]
        require(pin["name"] == ARCHIVE_NAME and pin["bytes"] == ARCHIVE_BYTES
                and pin["sha256"] == ARCHIVE_SHA256, "No alternative staged payload")
        payload = os.open(ARCHIVE_NAME, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory)
        archive_kind(os.fstat(payload))
        same_file(payload, directory, ARCHIVE_NAME, pin["metadata"])
        os.close(slot)
        slot = None
        return directory, payload, value
    except BaseException:
        for fd in (payload, slot, directory):
            if fd is not None:
                os.close(fd)
        raise


def send(request):
    directory = payload = None
    try:
        directory, payload, value = open_staged(request)
        pin = value["archive"]["metadata"]
        stored = full_fd_hash(payload, directory, pin)
        source = original_request(request, "reverify", NoOutput())
        same_file(payload, directory, ARCHIVE_NAME, pin)
        require(directory_identity(directory) == value["directoryIdentity"], "Same transport directory")
        guard()
        ready = {"schema": "otzaria.native116-staged-transport-ready/1",
                 "requestID": request["requestID"], "stagedTerminalSHA256": request["stagedTerminalSHA256"],
                 "stageHelperSHA256": request["stageHelperSHA256"],
                 "archiveBytes": ARCHIVE_BYTES, "archiveSHA256": ARCHIVE_SHA256,
                 "archiveMetadata": pin, "storedFullReadback": stored,
                 "originalPreHTTPSource": source,
                 "sourceTreeReadsAfterReady": False}
        header = canonical(ready)
        require(len(header) <= SLOT_BYTES, "Finite ready frame")
        sys.stdout.buffer.write(header)
        sys.stdout.buffer.flush()
        os.lseek(payload, 0, os.SEEK_SET)
        count = 0
        h = hashlib.sha256()
        while True:
            guard()
            same_file(payload, directory, ARCHIVE_NAME, pin)
            raw = os.read(payload, BLOCK)
            if not raw:
                break
            count += len(raw)
            require(count <= ARCHIVE_BYTES, "Transport payload bound")
            h.update(raw)
            require(sys.stdout.buffer.write(raw) == len(raw), "Short transport write")
        require(count == ARCHIVE_BYTES and h.hexdigest() == ARCHIVE_SHA256,
                "Complete staged transport hash")
        same_file(payload, directory, ARCHIVE_NAME, pin)
        require(directory_identity(directory) == value["directoryIdentity"], "Final staged directory identity")
        require(set(os.listdir(directory)) == {ARCHIVE_NAME, TERMINAL_NAME}, "Final stage membership")
        guard()
        sys.stdout.buffer.flush()
        return {"schema": "otzaria.native116-staged-transport-terminal/1",
                "status": "STAGED_ARCHIVE_TRANSPORT_VERIFIED", "utc": utc(),
                "requestID": request["requestID"], "readySHA256": digest(header),
                "stagedTerminalSHA256": request["stagedTerminalSHA256"],
                "archiveBytes": count, "archiveSHA256": h.hexdigest(),
                "archiveMetadata": pin, "pid": os.getpid(), "parentPID": ORIGINAL_PARENT,
                "sourceTreeReadsAfterReady": False, "sourceModified": False,
                "elapsedSeconds": time.monotonic() - STARTED}
    finally:
        for fd in (payload, directory):
            if fd is not None:
                os.close(fd)


def main(request, producer, format_module):
    global P, F
    P, F = producer, format_module
    require(sys.flags.isolated and sys.platform == "darwin"
            and pwd.getpwuid(os.getuid()).pw_name == "m1", "Qualified original Mac interpreter/account")
    common = {"mode", "requestID", "toolHashes", "snapshotBase64", "snapshotSHA256",
              "preparedSHA256", "stageHelperSHA256"}
    require(type(request) is dict
            and set(request) == common | ({"stagedTerminalSHA256"} if request.get("mode") == "send" else set()),
            "Closed nonsecret staged request")
    require(request["mode"] in ("stage", "send")
            and request["snapshotSHA256"] == SNAPSHOT_SHA256
            and request["preparedSHA256"] == PREPARED_SHA256,
            "Exact original preparation and snapshot")
    require(type(request["requestID"]) is str and len(request["requestID"]) == 32
            and all(c in "0123456789abcdef" for c in request["requestID"]), "Bounded request identity")
    require(type(request["stageHelperSHA256"]) is str and len(request["stageHelperSHA256"]) == 64
            and all(c in "0123456789abcdef" for c in request["stageHelperSHA256"]),
            "Pinned new helper source")
    signal.signal(signal.SIGALRM, timeout)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, min(DEADLINE, P.DEADLINE) - time.monotonic()))
    try:
        guard()
        result = stage(request) if request["mode"] == "stage" else send(request)
        raw = canonical(result)
        require(len(raw) <= SLOT_BYTES, "Complete staged terminal bound")
        sys.stderr.buffer.write(raw)
        sys.stderr.buffer.flush()
    except BaseException as error:
        failure = {"schema": "otzaria.native116-staged-transport-failure/1",
                   "status": "FAILED_NO_ACCEPTANCE_NO_RETIREMENT", "mode": request["mode"],
                   "requestID": request["requestID"], "errorType": type(error).__name__,
                   "exceptionTextRecorded": False, "automaticRetry": False,
                   "pid": os.getpid(), "parentPID": ORIGINAL_PARENT,
                   "originalProducerRaw": LAST_ORIGINAL_TERMINAL}
        sys.stderr.buffer.write(canonical(failure))
        sys.stderr.buffer.flush()
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
