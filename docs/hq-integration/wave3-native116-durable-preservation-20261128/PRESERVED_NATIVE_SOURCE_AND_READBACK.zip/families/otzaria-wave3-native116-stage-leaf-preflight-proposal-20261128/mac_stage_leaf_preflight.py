#!/usr/bin/env python3
"""Read-only, exact Native116 staged archive metadata/hash/consumer preflight.
No archive, extraction, write, delete, token, API or original-tree operation.
Executed only by the reviewed Oracle launcher through the existing pinned SSH.
"""
if not __debug__:
    raise RuntimeError("OPTIMIZED_PYTHON_REFUSED")
import base64
import ctypes
import datetime
import errno
import hashlib
import json
import os
import selectors
import signal
import stat
import struct
import subprocess
import sys
import time

STAGE_ROOT = "/Users/m1/otzaria-native116-staged-archive-20261128"
ARCHIVE_NAME = "native116-remaining-original-evidence.tar.gz"
ARCHIVE_PATH = STAGE_ROOT + "/" + ARCHIVE_NAME
ARCHIVE_BYTES = 1272863810
ARCHIVE_SHA256 = "f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556"
SOURCE_DEVICE = 16777232
PARENT_PIN = {"device": 16777232, "inode": 80215398, "uid": 501, "gid": 20, "mode": 16832}
LEAF_PIN = {"device": 16777232, "inode": 80215400, "uid": 501, "gid": 20,
            "mode": 33024, "nlink": 1, "bytes": ARCHIVE_BYTES, "flags": 0,
            "mtimeNS": "1795845337662706536", "ctimeNS": "1795845386291328289"}
HISTORICAL_NAMES = {ARCHIVE_NAME, "STAGE_TERMINAL.json"}
MAC_RESERVE = 2415919104
MAX_XATTR = 2 * 1024**2
MAX_SIBLINGS = 64
MAX_METADATA_CAPTURE = 128 * 1024
MAX_STDOUT = 512 * 1024
TERMINAL_RESERVE = 16 * 1024
PROBE_STDOUT_CAP = 64 * 1024
PROBE_STDERR_CAP = 16 * 1024
BLOCK = 1024**2
STARTED = time.monotonic()
DEADLINE = STARTED + 1200
ORIGINAL_PARENT_PID = os.getppid()
OUTPUT_BYTES = 0
SEQUENCE = 0
CURRENT_STAGE = "START"
NATIVE_METADATA_ABI = None
NATIVE_FCNTL_HEADER = "/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.0.sdk/usr/include/sys/fcntl.h"
NATIVE_FCNTL_HEADER_BYTES = 27609
NATIVE_FCNTL_HEADER_SHA256 = "9aca8ca87031ab7b670617e5af8b15a0cad8f34f7ab3bdb5dd799eb153b3ad0e"
SYMLINK_FLAG = 0x00200000
PYTHON_SYMLINK_FLAG = getattr(os, "O_SYMLINK", None)

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def b64(raw):
    return base64.b64encode(raw).decode("ascii")

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def error_record(error, stage):
    return {"stage": stage, "type": type(error).__name__,
            "errno": error.errno if isinstance(error, OSError) else None,
            "detail": str(error)[:240] if type(error) is RuntimeError else None}

def guard():
    require(time.monotonic() < DEADLINE, "OWNED_COLLECTOR_DEADLINE")
    require(os.getppid() == ORIGINAL_PARENT_PID, "ORIGINAL_SSH_PARENT_DETACHED")
    v = os.statvfs("/System/Volumes/Data")
    require(v.f_bavail * v.f_frsize >= MAC_RESERVE, "UNCHANGED_MAC_LIVE_RESERVE")

def alarm(_signal, _frame):
    raise RuntimeError("OWNED_COLLECTOR_ALARM")

def emit(kind, value, terminal=False):
    global OUTPUT_BYTES, SEQUENCE
    SEQUENCE += 1
    raw = canonical({"sequence": SEQUENCE, "event": kind, "utc": utc(), "value": value}) + b"\n"
    require(len(raw) <= (TERMINAL_RESERVE if terminal else MAX_STDOUT - TERMINAL_RESERVE),
            "FINITE_EVENT_BOUND")
    require(OUTPUT_BYTES + len(raw) <= (MAX_STDOUT if terminal else MAX_STDOUT - TERMINAL_RESERVE),
            "FINITE_TRANSCRIPT_BOUND")
    view = memoryview(raw)
    while view:
        n = os.write(1, view)
        require(n > 0, "STDOUT_SHORT_WRITE")
        view = view[n:]
    OUTPUT_BYTES += len(raw)
    return {"bytes": len(raw), "sha256": digest(raw)}

def identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid, s.st_nlink,
            s.st_size, str(s.st_mtime_ns), str(s.st_ctime_ns), s.st_flags, s.st_rdev)

class AttrList(ctypes.Structure):
    _fields_ = [('count', ctypes.c_uint16), ('reserved', ctypes.c_uint16),
                ('common', ctypes.c_uint32), ('vol', ctypes.c_uint32),
                ('directory', ctypes.c_uint32), ('file', ctypes.c_uint32), ('fork', ctypes.c_uint32)]


LIB = ctypes.CDLL(None, use_errno=True)
LIB.openat.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
LIB.openat.restype = ctypes.c_int
LIB.flistxattr.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
LIB.flistxattr.restype = ctypes.c_ssize_t
LIB.fgetxattr.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.c_int]
LIB.fgetxattr.restype = ctypes.c_ssize_t
LIB.acl_get_fd_np.argtypes = [ctypes.c_int, ctypes.c_int]
LIB.acl_get_fd_np.restype = ctypes.c_void_p
LIB.acl_to_text.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ssize_t)]
LIB.acl_to_text.restype = ctypes.c_void_p
LIB.acl_free.argtypes = [ctypes.c_void_p]
LIB.acl_free.restype = ctypes.c_int
LIB.fgetattrlist.argtypes = [ctypes.c_int, ctypes.POINTER(AttrList), ctypes.c_void_p, ctypes.c_size_t, ctypes.c_ulong]
LIB.fgetattrlist.restype = ctypes.c_int

def qualify_native_metadata_abi():
    # This small read qualifies the same installed header for every producer
    # launch. It grants no access to source data and never writes SDK files.
    fd = os.open(NATIVE_FCNTL_HEADER, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size == NATIVE_FCNTL_HEADER_BYTES,
                'Installed native header type/size changed')
        raw = bytearray()
        while len(raw) <= NATIVE_FCNTL_HEADER_BYTES:
            block = os.read(fd, NATIVE_FCNTL_HEADER_BYTES + 1 - len(raw))
            if not block: break
            raw.extend(block)
        require(len(raw) == NATIVE_FCNTL_HEADER_BYTES and
                digest(raw) == NATIVE_FCNTL_HEADER_SHA256,
                'Installed native header byte identity changed')
        definitions = [line.split()[:3] for line in bytes(raw).splitlines()
                       if line.split()[:2] == [b'#define', b'O_SYMLINK']]
        require(definitions == [[b'#define', b'O_SYMLINK', b'0x00200000']],
                'Installed O_SYMLINK definition changed')
        require(identity(os.fstat(fd)) == identity(before) and
                identity(os.stat(NATIVE_FCNTL_HEADER, follow_symlinks=False)) == identity(before),
                'Installed native header replaced during qualification')
    finally:
        os.close(fd)
    return {'headerPath': NATIVE_FCNTL_HEADER, 'headerBytes': NATIVE_FCNTL_HEADER_BYTES,
            'headerSHA256': NATIVE_FCNTL_HEADER_SHA256, 'symlinkFlag': SYMLINK_FLAG,
            'pythonExposesSymlinkFlag': PYTHON_SYMLINK_FLAG is not None,
            'metadataOpen': 'native libc openat with pinned parent and single final component'}

def extended_metadata(parent_fd, name, before):
    # Darwin O_SYMLINK opens the link itself. Ordinary entries use O_NOFOLLOW.
    # Every native metadata call consumes this verified descriptor directly;
    # there is no /dev/fd path spelling or re-resolution of a source ancestor.
    flags = os.O_RDONLY | (SYMLINK_FLAG if stat.S_ISLNK(before.st_mode) else os.O_NOFOLLOW)
    if stat.S_ISDIR(before.st_mode): flags |= os.O_DIRECTORY
    raw_name = os.fsencode(name)
    require(raw_name and raw_name != b'..' and b'/' not in raw_name and b'\0' not in raw_name,
            'Native metadata open requires one exact final component')
    fd = LIB.openat(parent_fd, raw_name, flags)
    if fd < 0: raise OSError(ctypes.get_errno(), 'Native metadata openat failed')
    try:
        os.set_inheritable(fd, False)
        require(identity(os.fstat(fd)) == identity(before), 'Metadata descriptor identity mismatch')
        value = descriptor_metadata(fd, before)
        require(identity(os.fstat(fd)) == identity(before), 'Metadata descriptor changed')
        require(identity(os.stat(name, dir_fd=parent_fd, follow_symlinks=False)) == identity(before),
                'Metadata source name replaced')
        return value
    finally:
        os.close(fd)

def descriptor_metadata(fd, before):
    options = 0x0020  # XATTR_SHOWCOMPRESSION; fd already identifies the link itself.
    size = LIB.flistxattr(fd, None, 0, options)
    require(0 <= size <= MAX_XATTR, 'xattr name list unavailable/over bound')
    names = ctypes.create_string_buffer(max(1, size))
    require(LIB.flistxattr(fd, names, size, options) == size, 'xattr names changed')
    attributes = []
    for attribute in sorted(x for x in names.raw[:size].split(b'\0') if x):
        guard(); n = LIB.fgetxattr(fd, attribute, None, 0, 0, options)
        require(0 <= n <= MAX_XATTR, 'xattr payload unavailable/over bound')
        value = ctypes.create_string_buffer(max(1, n))
        require(LIB.fgetxattr(fd, attribute, value, n, 0, options) == n, 'xattr changed')
        raw = value.raw[:n]
        attributes.append({'nameBase64': b64(attribute), 'valueBase64': b64(raw),
                           'bytes': n, 'sha256': digest(raw)})
    ctypes.set_errno(0)
    acl = LIB.acl_get_fd_np(fd, 0x00000100)
    acl_value = None
    if not acl:
        require(ctypes.get_errno() == errno.ENOENT, 'ACL inspection failed')
    else:
        length = ctypes.c_ssize_t()
        text = LIB.acl_to_text(acl, ctypes.byref(length))
        try:
            require(text and 0 <= length.value <= MAX_XATTR, 'ACL text unavailable/over bound')
            raw = ctypes.string_at(text, length.value)
            acl_value = {'textBase64': b64(raw), 'bytes': len(raw), 'sha256': digest(raw)}
        finally:
            if text: LIB.acl_free(text)
            LIB.acl_free(acl)
    attrs = AttrList(5, 0, 0x00000200, 0, 0, 0, 0)
    output = ctypes.create_string_buffer(64)
    require(LIB.fgetattrlist(fd, ctypes.byref(attrs), output, 64, 0) == 0, 'Exact birthtime unavailable')
    require(struct.unpack_from('=I', output.raw, 0)[0] == 20, 'Birthtime layout mismatch')
    seconds, ns = struct.unpack_from('=qq', output.raw, 4)
    require(0 <= ns < 10**9 and abs(seconds - int(before.st_birthtime)) <= 1, 'Birthtime check')
    return {'xattrs': attributes, 'acl': acl_value, 'birthtimeNS': str(seconds * 10**9 + ns)}

def record(parent_fd, name, relative, before, full):
    guard()
    kind = 'file' if stat.S_ISREG(before.st_mode) else 'directory' if stat.S_ISDIR(before.st_mode) else 'symlink'
    require(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode) or stat.S_ISLNK(before.st_mode), 'Unsupported special source entry')
    require(before.st_dev == SOURCE_DEVICE, 'Cross-device source entry')
    metadata = extended_metadata(parent_fd, name, before)
    row = {'pathBase64': b64(relative), 'kind': kind, 'device': before.st_dev,
           'inode': before.st_ino, 'mode': before.st_mode, 'uid': before.st_uid,
           'gid': before.st_gid, 'nlink': before.st_nlink, 'bytes': before.st_size,
           'allocatedBytes': before.st_blocks * 512, 'mtimeNS': str(before.st_mtime_ns),
           'ctimeNS': str(before.st_ctime_ns), 'atimeNS': str(before.st_atime_ns),
           'flags': before.st_flags, 'rdev': before.st_rdev, **metadata}
    if kind == 'file' and full:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
        try:
            require(identity(os.fstat(fd)) == identity(before), 'File replaced before read')
            h, count = hashlib.sha256(), 0
            while True:
                guard(); block = os.read(fd, BLOCK)
                if not block: break
                count += len(block); require(count <= before.st_size, 'Source grew during hash'); h.update(block)
            require(count == before.st_size and identity(os.fstat(fd)) == identity(before), 'File changed during hash')
            row['sha256'] = h.hexdigest()
        finally:
            os.close(fd)
    elif kind == 'symlink':
        row['targetBase64'] = b64(os.fsencode(os.readlink(name, dir_fd=parent_fd)))
    require(identity(os.stat(name, dir_fd=parent_fd, follow_symlinks=False)) == identity(before), 'Source path identity changed')
    require(extended_metadata(parent_fd, name, before) == metadata, 'Source extended metadata changed')
    return row

def open_stage_root():
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in STAGE_ROOT.split("/")[1:]:
            guard()
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        s = os.fstat(fd)
        value = {"device": s.st_dev, "inode": s.st_ino, "uid": s.st_uid,
                 "gid": s.st_gid, "mode": s.st_mode}
        require(value == PARENT_PIN, "EXACT_HISTORICAL_STAGE_PARENT")
        require(identity(os.stat(STAGE_ROOT, follow_symlinks=False)) == identity(s),
                "STAGE_PARENT_NAME_FD_JOIN")
        return fd
    except BaseException:
        os.close(fd)
        raise

def stable_metadata(value):
    # atime can change because of this read-only inspection. All other captured
    # fields, including exact nanosecond birthtime, xattrs and ACL stay fenced.
    return {k: v for k, v in value.items() if k != "atimeNS"}

def stat_pin(s):
    return {"device": s.st_dev, "inode": s.st_ino, "mode": s.st_mode,
            "uid": s.st_uid, "gid": s.st_gid, "nlink": s.st_nlink,
            "bytes": s.st_size, "flags": s.st_flags,
            "mtimeNS": str(s.st_mtime_ns), "ctimeNS": str(s.st_ctime_ns)}

def check_leaf_pin(s):
    require(stat.S_ISREG(s.st_mode) and stat_pin(s) == LEAF_PIN,
            "EXACT_HISTORICAL_REGULAR_SINGLE_LINK_STAGE_LEAF")

def list_names(fd):
    names = sorted((os.fsencode(n) for n in os.listdir(fd)))
    require(len(names) <= MAX_SIBLINGS and len(names) == len(set(names)), "SIBLING_COUNT_BOUND")
    for name in names:
        require(name and name not in (b".", b"..") and b"/" not in name and b"\0" not in name,
                "EXACT_SINGLE_COMPONENT_SIBLING")
    return names

def capture_metadata(fd, label):
    # The first fstat happens before listdir. No regular-file contents are read.
    parent_stat = os.fstat(fd)
    require(stat.S_ISDIR(parent_stat.st_mode), "PINNED_PARENT_DIRECTORY")
    parent = record(fd, b".", b"", parent_stat, False)
    names = list_names(fd)
    rows = []
    for name in names:
        guard()
        before = os.stat(name, dir_fd=fd, follow_symlinks=False)
        row = record(fd, name, name, before, False)
        rows.append(row)
        require(len(canonical({"parent": parent, "siblings": rows})) <= MAX_METADATA_CAPTURE,
                "COMPLETE_METADATA_CAPTURE_BOUND")
    require(list_names(fd) == names, "SIBLING_SET_CHANGED_DURING_METADATA")
    require(identity(os.fstat(fd)) == identity(parent_stat), "PARENT_CHANGED_DURING_METADATA")
    value = {"label": label, "parent": parent, "siblings": rows,
             "siblingCount": len(rows), "allImmediateSiblingsCaptured": True,
             "regularContentReads": 0, "recursiveTraversal": False,
             "historicalMembershipUnchanged": set(os.fsdecode(n) for n in names) == HISTORICAL_NAMES}
    require(len(canonical(value)) <= MAX_METADATA_CAPTURE, "COMPLETE_METADATA_CAPTURE_BOUND")
    emit("METADATA_CAPTURE", value)
    return value

def require_same_capture(before, after):
    require(stable_metadata(before["parent"]) == stable_metadata(after["parent"]),
            "PARENT_METADATA_CHANGED")
    old = {r["pathBase64"]: r for r in before["siblings"]}
    new = {r["pathBase64"]: r for r in after["siblings"]}
    require(set(old) == set(new), "SIBLING_MEMBERSHIP_CHANGED")
    for path in old:
        require(stable_metadata(old[path]) == stable_metadata(new[path]), "SIBLING_METADATA_CHANGED")
    return {"parent": {"before": before["parent"]["atimeNS"], "after": after["parent"]["atimeNS"]},
            "siblings": [{"pathBase64": k, "before": old[k]["atimeNS"], "after": new[k]["atimeNS"]}
                         for k in sorted(old)]}

def stop_owned_mac(process, identity_value, cleanup):
    if process.returncode is not None:
        return
    # No poll/reap before the signal decision. Only this unreaped Popen leader
    # and the group/session created by start_new_session=True may be signalled.
    pgid, sid = os.getpgid(process.pid), os.getsid(process.pid)
    require(pgid == sid == process.pid, "OWNED_PROBE_GROUP_IDENTITY")
    if identity_value is not None:
        require(identity_value == {"pid": process.pid, "pgid": pgid, "session": sid},
                "OWNED_PROBE_IDENTITY_CHANGED")
    os.killpg(process.pid, signal.SIGTERM)
    cleanup.append({"signal": "TERM", "pid": process.pid, "pgid": pgid})
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        require(os.getpgid(process.pid) == os.getsid(process.pid) == process.pid,
                "OWNED_PROBE_GROUP_CHANGED")
        os.killpg(process.pid, signal.SIGKILL)
        cleanup.append({"signal": "KILL", "pid": process.pid, "pgid": pgid})
        process.wait(timeout=5)

def run_probe(argv, label, seconds):
    process = None
    process_identity_value = None
    selector = None
    out, err = bytearray(), bytearray()
    failure, cleanup = None, []
    started = time.monotonic()
    try:
        guard()
        process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, close_fds=True, start_new_session=True)
        # Immediate protected cleanup after Popen, including identity/setup failure.
        try:
            process_identity_value = {"pid": process.pid, "pgid": os.getpgid(process.pid),
                                      "session": os.getsid(process.pid)}
            require(process_identity_value["pgid"] == process_identity_value["session"] == process.pid,
                    "OWNED_PROBE_SESSION")
            selector = selectors.DefaultSelector()
            for name, stream in (("stdout", process.stdout), ("stderr", process.stderr)):
                os.set_blocking(stream.fileno(), False)
                selector.register(stream.fileno(), selectors.EVENT_READ, name)
            until = min(DEADLINE, started + seconds)
            while selector.get_map():
                guard()
                require(time.monotonic() < until, "BOUNDED_CONSUMER_INSPECTION_DEADLINE")
                for key, _ in selector.select(0.1):
                    try:
                        raw = os.read(key.fd, 16384)
                    except BlockingIOError:
                        continue
                    if not raw:
                        selector.unregister(key.fd)
                        continue
                    buffer, cap = (out, PROBE_STDOUT_CAP) if key.data == "stdout" else (err, PROBE_STDERR_CAP)
                    remaining = cap - len(buffer)
                    buffer.extend(raw[:remaining])
                    require(len(raw) <= remaining, "BOUNDED_CONSUMER_INSPECTION_OUTPUT")
            process.wait(timeout=max(0.01, min(5, until - time.monotonic())))
        finally:
            try:
                stop_owned_mac(process, process_identity_value, cleanup)
            finally:
                if selector is not None:
                    selector.close()
                for stream in (process.stdout, process.stderr):
                    if stream is not None:
                        stream.close()
    except BaseException as error:
        failure = error_record(error, label)
    value = {"label": label, "argv": argv, "identity": process_identity_value,
             "returncode": process.returncode if process else None,
             "ownedLeaderReaped": process is not None and process.returncode is not None,
             "descendantExtinctionClaimed": False, "seconds": time.monotonic() - started,
             "stdoutBase64": b64(out), "stderrBase64": b64(err),
             "stdoutBytes": len(out), "stderrBytes": len(err),
             "stdoutSHA256": digest(out), "stderrSHA256": digest(err),
             "failure": failure, "cleanup": cleanup, "automaticRetries": 0}
    emit("CONSUMER_PROBE", value)
    return value, bytes(out), bytes(err)

def parse_lsof(raw, archive_fd):
    # Closed requested fields only. The NUL machine format is retained raw.
    # A known open read-only descriptor in this collector is a required positive
    # witness that this exact leaf was inspected; an empty query never proves no-use.
    process_info, file_info = None, None
    files = []
    def flush_file():
        nonlocal file_info
        if file_info is not None:
            require(process_info is not None, "LSOF_FILE_WITHOUT_PROCESS")
            files.append({"process": dict(process_info), "file": dict(file_info)})
            file_info = None
    for token in raw.split(b"\0"):
        token = token.lstrip(b"\n")
        if not token:
            continue
        field, value = token[:1], token[1:]
        require(field in (b"p", b"c", b"u", b"f", b"a", b"t", b"D", b"i", b"s", b"n"),
                "LSOF_UNEXPECTED_FIELD")
        if field == b"p":
            flush_file()
            require(value.isdigit() and len(value) <= 10, "LSOF_PID")
            process_info = {"p": value}
        elif field in (b"c", b"u"):
            require(process_info is not None and file_info is None, "LSOF_PROCESS_FIELD_ORDER")
            require(field.decode() not in process_info, "LSOF_DUPLICATE_PROCESS_FIELD")
            process_info[field.decode()] = value
        elif field == b"f":
            flush_file()
            require(process_info is not None, "LSOF_FD_WITHOUT_PROCESS")
            file_info = {"f": value}
        else:
            require(file_info is not None and field.decode() not in file_info, "LSOF_FILE_FIELD_ORDER")
            file_info[field.decode()] = value
    flush_file()
    require(0 < len(files) <= 256, "LSOF_FINITE_POSITIVE_FILE_SET")
    own, other = [], []
    for entry in files:
        p, f = entry["process"], entry["file"]
        require(set(p) == {"p", "c", "u"} and set(f) == {"f", "a", "t", "D", "i", "s", "n"},
                "LSOF_COMPLETE_REQUESTED_FIELDS")
        require(p["u"].isdigit() and len(p["u"]) <= 10, "LSOF_UID")
        require(f["i"].isdigit() and len(f["i"]) <= 20 and
                f["s"].isdigit() and len(f["s"]) <= 20, "LSOF_NUMERIC_FIELDS")
        d = f["D"]
        require(0 < len(d) <= 18 and
                ((d.startswith(b"0x") and all(c in b"0123456789abcdefABCDEF" for c in d[2:]))
                 or d.isdigit()), "LSOF_DEVICE_FORMAT")
        device = int(d, 16) if d.startswith(b"0x") else int(d, 10)
        require(device == SOURCE_DEVICE and int(f["i"]) == LEAF_PIN["inode"] and
                int(f["s"]) == ARCHIVE_BYTES and f["t"] == b"REG" and
                f["n"] == os.fsencode(ARCHIVE_PATH), "LSOF_EXACT_LEAF_JOIN")
        is_own = (int(p["p"]) == os.getpid() and int(p["u"]) == 501
                  and f["f"] == str(archive_fd).encode() and f["a"] == b"r")
        (own if is_own else other).append(entry)
    require(len(own) == 1, "LSOF_KNOWN_DESCRIPTOR_POSITIVE_WITNESS")
    return {"positiveOwnReadFD": archive_fd, "ownReaderPID": os.getpid(),
            "matchingOtherOpenRecords": len(other), "noOtherOpenRecordsObserved": not other,
            "coverage": "One privileged lsof query for the exact file; no future-consumer or lease claim",
            "otherRecordIdentities": [{"pid": int(x["process"]["p"]), "uid": int(x["process"]["u"]),
                                      "commBase64": b64(x["process"]["c"]),
                                      "fdBase64": b64(x["file"]["f"]),
                                      "accessBase64": b64(x["file"]["a"])} for x in other]}

def consumer_check(label, archive_fd, root_probe_ok):
    if not root_probe_ok:
        value = {"label": label, "complete": False, "noOtherOpenRecordsObserved": False,
                 "inspectionError": {"type": "PrivilegeQualificationUnavailable"},
                 "scope": "Exact staged leaf only"}
        emit("CONSUMER_CHECK", value)
        return value
    argv = ["/usr/bin/sudo", "-n", "/usr/sbin/lsof", "-nP", "-l",
            "-F0pcufaDtisn", "--", ARCHIVE_PATH]
    probe, out, err = run_probe(argv, label, 20)
    try:
        require(probe["failure"] is None and probe["returncode"] == 0 and not err,
                "PRIVILEGED_LSOF_INSPECTION_INCOMPLETE")
        result = parse_lsof(out, archive_fd)
        result.update({"label": label, "complete": True, "inspectionError": None})
    except BaseException as error:
        result = {"label": label, "complete": False, "noOtherOpenRecordsObserved": False,
                  "inspectionError": error_record(error, label)}
    emit("CONSUMER_CHECK", result)
    return result

def full_hash(fd, parent):
    require(identity(os.fstat(fd)) == identity(os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False)),
            "ARCHIVE_FD_NAME_BEFORE_HASH")
    check_leaf_pin(os.fstat(fd))
    os.lseek(fd, 0, os.SEEK_SET)
    h, count = hashlib.sha256(), 0
    while True:
        guard()
        check_leaf_pin(os.fstat(fd))
        check_leaf_pin(os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False))
        raw = os.read(fd, BLOCK)
        if not raw:
            break
        count += len(raw)
        require(count <= ARCHIVE_BYTES, "ARCHIVE_SIZE_GREW")
        h.update(raw)
    require(count == ARCHIVE_BYTES and h.hexdigest() == ARCHIVE_SHA256, "FULL_ARCHIVE_SHA256")
    check_leaf_pin(os.fstat(fd))
    check_leaf_pin(os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False))
    return {"bytes": count, "sha256": h.hexdigest(), "regularPayloadsHashed": 1}

def main():
    global CURRENT_STAGE, NATIVE_METADATA_ABI
    parent = archive = None
    failure = None
    result = {"schema": "otzaria.native116-stage-leaf-preflight/1", "archivePath": ARCHIVE_PATH,
              "status": "INCOMPLETE", "parentAndSiblingMetadataComplete": False,
              "fullArchiveHash": None, "boundedConsumerChecksComplete": False,
              "originalNativeTreeRead": False, "nonArchiveSiblingContentsRead": False,
              "sdkHeaderReadForABIOnly": True, "sourceWrites": False, "retirementAuthorized": False}
    signal.signal(signal.SIGALRM, alarm)
    signal.alarm(1200)
    try:
        require(sys.platform == "darwin" and ctypes.sizeof(ctypes.c_void_p) == 8,
                "QUALIFIED_64BIT_DARWIN_REQUIRED")
        require(sys.flags.isolated and sys.dont_write_bytecode and os.geteuid() == 501,
                "ISOLATED_NO_BYTECODE_ORIGINAL_M1_IDENTITY")
        require(PYTHON_SYMLINK_FLAG is None or
                (type(PYTHON_SYMLINK_FLAG) is int and PYTHON_SYMLINK_FLAG == SYMLINK_FLAG),
                "PYTHON_NATIVE_SYMLINK_FLAG_DISAGREEMENT")
        guard()
        emit("START", {"pid": os.getpid(), "parentPID": ORIGINAL_PARENT_PID,
                       "python": sys.version.split()[0], "macLiveFloor": MAC_RESERVE,
                       "deadlineSeconds": 1200, "scope": ARCHIVE_PATH})
        CURRENT_STAGE = "NATIVE_METADATA_ABI"
        NATIVE_METADATA_ABI = qualify_native_metadata_abi()
        emit("NATIVE_METADATA_ABI", NATIVE_METADATA_ABI)
        CURRENT_STAGE = "PARENT_AND_ALL_SIBLINGS_BEFORE_CONTENT"
        parent = open_stage_root()
        initial_leaf = os.stat(ARCHIVE_NAME, dir_fd=parent, follow_symlinks=False)
        emit("INITIAL_STAGE_IDENTITIES", {"parent": stat_pin(os.fstat(parent)),
             "leaf": stat_pin(initial_leaf), "leafAtimeNSBeforeContent": str(initial_leaf.st_atime_ns),
             "completeExtendedMetadataNotYetCaptured": True})
        before = capture_metadata(parent, "BEFORE_ANY_STAGE_CONTENT_READ")
        archive_row = [r for r in before["siblings"] if r["pathBase64"] == b64(os.fsencode(ARCHIVE_NAME))]
        require(len(archive_row) == 1, "ONE_CAPTURED_ARCHIVE")
        archive = os.open(ARCHIVE_NAME, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        check_leaf_pin(os.fstat(archive))
        require(os.get_inheritable(archive) is False, "ARCHIVE_FD_MUST_NOT_BE_INHERITED")
        require(archive_row[0]["inode"] == os.fstat(archive).st_ino, "CAPTURED_ARCHIVE_FD_JOIN")
        result["parentAndSiblingMetadataComplete"] = True
        result["beforeMetadataSHA256"] = digest(canonical(before))
        CURRENT_STAGE = "PRIVILEGED_CONSUMER_INSPECTION"
        privilege, raw, err = run_probe(["/usr/bin/sudo", "-n", "/usr/bin/id", "-u"],
                                        "privileged-inspection-capability", 10)
        root_ok = privilege["failure"] is None and privilege["returncode"] == 0 and raw == b"0\n" and not err
        first = consumer_check("before-content-hash", archive, root_ok)
        CURRENT_STAGE = "EXACT_ARCHIVE_FULL_HASH"
        result["fullArchiveHash"] = full_hash(archive, parent)
        emit("ARCHIVE_HASH", result["fullArchiveHash"])
        CURRENT_STAGE = "FINAL_CONSUMERS_AND_SOURCE_METADATA"
        second = consumer_check("after-content-hash", archive, root_ok)
        after = capture_metadata(parent, "AFTER_ARCHIVE_HASH_AND_CONSUMER_INSPECTION")
        atime = require_same_capture(before, after)
        check_leaf_pin(os.fstat(archive))
        require(identity(os.stat(STAGE_ROOT, follow_symlinks=False)) == identity(os.fstat(parent)),
                "STAGE_PARENT_NAME_FD_FINAL_JOIN")
        result.update({"afterMetadataSHA256": digest(canonical(after)), "immutableMetadataEqual": True,
                       "atimeComparisonSHA256": digest(canonical(atime)),
                       "atimeValuesRetainedInMetadataEvents": True,
                       "atimeChangedEntryCount": int(atime["parent"]["before"] != atime["parent"]["after"]) + sum(x["before"] != x["after"] for x in atime["siblings"]),
                       "historicalMembershipUnchanged": before["historicalMembershipUnchanged"] and after["historicalMembershipUnchanged"],
                       "boundedConsumerChecksComplete": first["complete"] and second["complete"],
                       "noOtherOpenRecordsObserved": first["noOtherOpenRecordsObserved"] and second["noOtherOpenRecordsObserved"],
                       "currentOpenFileObservationsOnly": True,
                       "futureConsumerClosureRequired": True, "apfsPrivateExtentsClaimed": False})
        complete = (result["boundedConsumerChecksComplete"] and result["noOtherOpenRecordsObserved"]
                    and result["historicalMembershipUnchanged"])
        result["status"] = "READ_ONLY_PREFLIGHT_CAPTURED" if complete else "CAPTURED_WITH_INSPECTION_OR_MEMBERSHIP_BLOCKERS"
    except BaseException as error:
        failure = error_record(error, CURRENT_STAGE)
        result["status"] = "READ_ONLY_PREFLIGHT_FAILED"
    finally:
        signal.alarm(0)
        close_errors = []
        for fd in (archive, parent):
            if fd is not None:
                try:
                    os.close(fd)
                except BaseException as error:
                    close_errors.append(error_record(error, "CLOSE_READ_ONLY_DESCRIPTOR"))
        if close_errors:
            result["status"] = "READ_ONLY_PREFLIGHT_FAILED"
        result.update({"failure": failure, "descriptorCloseErrors": close_errors,
                       "seconds": time.monotonic() - STARTED, "finalStage": CURRENT_STAGE,
                       "noAutomaticRetry": True, "nonArchiveSiblingContentsRead": False,
                       "liveRootClosureNotClaimed": True, "noRemovalInstruction": True})
        emit("FINAL_RESULT", result, terminal=True)
    return 0 if result["status"] == "READ_ONLY_PREFLIGHT_CAPTURED" else 2

if __name__ == "__main__":
    sys.exit(main())
