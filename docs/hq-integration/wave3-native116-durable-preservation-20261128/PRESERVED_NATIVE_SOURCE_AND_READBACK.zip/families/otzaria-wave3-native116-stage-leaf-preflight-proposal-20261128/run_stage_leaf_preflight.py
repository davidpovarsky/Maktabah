#!/usr/bin/env python3
"""Future explicit read-only stage-leaf collector launcher. No API or retirement."""
if not __debug__:
    raise RuntimeError("OPTIMIZED_PYTHON_REFUSED")
from pathlib import Path
import argparse
import base64
import datetime
import hashlib
import json
import os
import selectors
import signal
import stat
import subprocess
import sys
import time

FAMILY = Path("/home/ubuntu/otzaria-wave3-native116-stage-leaf-preflight-proposal-20261128")
RUN = FAMILY / "actual-read-only-preflight"
ROOT_FLOOR = 1593835520
FAMILY_CAP = 2 * 1024**2
MAX_ENTRIES = 96
MAX_DEPTH = 3
OVERALL_SECONDS = 1300
MAC_SHA256 = "29602d16f05a66b52e72fef32a04001878e22041027905187c110e3a7c3c885b"
MAC_BYTES = 31598
SLOTS = {"FINAL_RESULT.json": 32768, "SSH_ALIAS.json": 4096,
         "ssh-alias.stderr": 16384, "mac-collector.stdout": 524288,
         "mac-collector.stderr": 65536, "PROCESS_LEDGER.json": 16384,
         "TERMINAL.json": 16384}
STARTED = time.monotonic()
DEADLINE = STARTED + OVERALL_SECONDS
ORIGINAL_PARENT = os.getppid()
PROCESS_LEDGER = []

def require(value, code):
    if not value:
        raise RuntimeError(code)

def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode("ascii")

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def stable(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid, s.st_nlink,
            s.st_size, s.st_mtime_ns, s.st_ctime_ns)

def error_record(error, stage):
    return {"stage": stage, "type": type(error).__name__,
            "errno": error.errno if isinstance(error, OSError) else None,
            "detail": str(error)[:240] if type(error) is RuntimeError else None}

def free():
    v = os.statvfs("/")
    return v.f_bavail * v.f_frsize

def allocation():
    total, entries = 0, 0
    pending = [(FAMILY, 0)]
    while pending:
        path, depth = pending.pop()
        s = os.stat(path, follow_symlinks=False)
        entries += 1
        require(entries <= MAX_ENTRIES and depth <= MAX_DEPTH, "FIXED_FAMILY_INVENTORY_BOUND")
        require(s.st_dev == os.stat("/").st_dev and s.st_uid == 1001, "PRIVATE_ROOTFS_FAMILY")
        total += s.st_blocks * 512
        if stat.S_ISDIR(s.st_mode):
            with os.scandir(path) as it:
                pending.extend((Path(x.path), depth + 1) for x in it)
        else:
            require(stat.S_ISREG(s.st_mode) and s.st_nlink == 1, "FAMILY_REGULAR_SINGLE_LINK_ONLY")
    return total

def guard(addition=0):
    require(time.monotonic() < DEADLINE, "OWNED_LAUNCHER_DEADLINE")
    require(os.getppid() == ORIGINAL_PARENT, "ORIGINAL_LAUNCH_PARENT_DETACHED")
    require(free() - addition >= ROOT_FLOOR, "UNCHANGED_ROOT_RESERVE")
    require(allocation() + addition <= FAMILY_CAP, "EXACT_TWO_MIB_FAMILY_CAP")

def read_source(path, maximum):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and
                before.st_uid == 1001 and before.st_size <= maximum, "PRIVATE_SEALED_SOURCE")
        raw = bytearray()
        while True:
            block = os.read(fd, min(65536, maximum + 1 - len(raw)))
            if not block:
                break
            raw.extend(block)
            require(len(raw) <= maximum, "SOURCE_READ_BOUND")
        require(stable(os.fstat(fd)) == stable(before) and
                stable(os.stat(path, follow_symlinks=False)) == stable(before),
                "SOURCE_READ_IDENTITY_CHANGED")
        return bytes(raw)
    finally:
        os.close(fd)

def verify_seal(expected):
    require(os.getuid() == os.geteuid() == 1001 and sys.flags.isolated and sys.dont_write_bytecode,
            "UBUNTU_ISOLATED_NO_BYTECODE_REQUIRED")
    require(Path(__file__).absolute() == FAMILY / "run_stage_leaf_preflight.py",
            "FIXED_SOURCE_ENTRYPOINT")
    require(FAMILY.resolve(strict=True) == FAMILY, "SOURCE_PARENT_NO_SYMLINK")
    raw = read_source(FAMILY / "SOURCE_SEAL.json", 65536)
    require(digest(raw) == expected, "EXPLICIT_SOURCE_SEAL")
    seal = json.loads(raw)
    require(seal["schema"] == "otzaria.native116-stage-leaf-preflight-source/1",
            "CLOSED_SOURCE_SCHEMA")
    require(seal["familyPath"] == str(FAMILY) and seal["familyCap"] == FAMILY_CAP,
            "FIXED_FAMILY_SCOPE")
    for name, pin in seal["files"].items():
        require(name not in ("", ".", "..") and "/" not in name and "\\" not in name,
                "SEALED_SOURCE_LEAF")
        body = read_source(FAMILY / name, pin["bytes"])
        require(len(body) == pin["bytes"] and digest(body) == pin["sha256"], "SEALED_SOURCE_BYTES")
    require(seal["files"]["mac_stage_leaf_preflight.py"] ==
            {"bytes": MAC_BYTES, "sha256": MAC_SHA256}, "FIXED_MAC_SOURCE_PIN")
    return seal, raw

def process_identity(pid):
    raw = Path('/proc/%d/stat' % pid).read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    assert len(fields) >= 20
    return {'pid': pid, 'pgid': int(fields[2]), 'session': int(fields[3]),
            'startTicks': fields[19]}

def stop_owned(process, original):
    # Never poll/reap before a signal decision. An unreaped Popen leader cannot
    # have its PID reused. Every child was started in its own session/group.
    if process.returncode is not None:
        return
    current = process_identity(process.pid)
    assert current['pgid'] == current['session'] == process.pid
    assert original is None or current == original
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        current = process_identity(process.pid)
        assert current['pgid'] == current['session'] == process.pid
        assert original is None or current == original
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=20)

class ReservedFiles:
    def __init__(self):
        self.fd = None
        self.files = {}
        self.closed = set()
        self.reserved = set()

    def create(self):
        require(not RUN.exists() and not RUN.is_symlink(), "EXCLUSIVE_ATTEMPT_MUST_BE_ABSENT")
        guard(sum(SLOTS.values()) + (len(SLOTS) + 4) * 4096)
        parent = os.open(FAMILY, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.mkdir(RUN.name, 0o700, dir_fd=parent)
            os.fsync(parent)
            self.fd = os.open(RUN.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        finally:
            os.close(parent)
        # FINAL_RESULT is allocated first. Every later failure can be recorded
        # using its already allocated bytes, without a new file after refusal.
        for name, size in SLOTS.items():
            guard(size + 4096)
            fd = os.open(name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=self.fd)
            self.files[name] = fd
            remaining = size
            while remaining:
                raw = b"\0" * min(65536, remaining)
                n = os.write(fd, raw)
                require(n > 0, "REPORT_SLOT_SHORT_ALLOCATION")
                remaining -= n
            os.fsync(fd)
            require(os.fstat(fd).st_blocks * 512 >= size, "REPORT_SLOT_MUST_BE_ALLOCATED")
            self.reserved.add(name)
        os.fsync(self.fd)

    def write(self, name, raw, shrink=True):
        require(name in self.reserved and name not in self.closed and len(raw) <= SLOTS[name],
                "RESERVED_REPORT_BOUND")
        fd = self.files[name]
        s = os.fstat(fd)
        named = os.stat(name, dir_fd=self.fd, follow_symlinks=False)
        require(stable(named) == stable(s) and s.st_nlink == 1 and stat.S_ISREG(s.st_mode),
                "RESERVED_REPORT_FD_NAME")
        offset = 0
        while offset < len(raw):
            n = os.pwrite(fd, raw[offset:], offset)
            require(n > 0, "RESERVED_REPORT_SHORT_WRITE")
            offset += n
        if shrink:
            os.ftruncate(fd, len(raw))
            self.closed.add(name)
        os.fsync(fd)
        if shrink:
            actual = os.pread(fd, len(raw) + 1, 0)
            require(actual == raw, "RESERVED_REPORT_FULL_READBACK")
        os.fsync(self.fd)
        return {"path": str(RUN / name), "bytes": len(raw), "sha256": digest(raw)}

    def close(self):
        for fd in self.files.values():
            os.close(fd)
        if self.fd is not None:
            os.close(self.fd)

def save_process_ledger(slots):
    slots.write("PROCESS_LEDGER.json", canonical(PROCESS_LEDGER), shrink=False)

def run_owned(argv, label, input_body, stdout_cap, stderr_cap, seconds, slots, stdout_slot, stderr_slot):
    process = None
    identity_value = None
    selector = None
    out, err = bytearray(), bytearray()
    failure, cleanup_failure = None, None
    sent = 0
    code = None
    started = time.monotonic()
    guard()
    process = subprocess.Popen(argv, stdin=subprocess.PIPE if input_body is not None else subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               close_fds=True, start_new_session=True)
    # Immediate protected lifetime after Popen; no fallible setup precedes it.
    try:
        identity_value = process_identity(process.pid)
        require(identity_value["pgid"] == identity_value["session"] == process.pid, "OWNED_SSH_SESSION")
        PROCESS_LEDGER.append({"label": label, "identity": identity_value, "argv": argv,
                               "inputBytes": len(input_body or b""),
                               "inputSHA256": digest(input_body) if input_body is not None else None,
                               "startedUTC": utc()})
        save_process_ledger(slots)
        selector = selectors.DefaultSelector()
        for channel, pipe in (("stdout", process.stdout), ("stderr", process.stderr)):
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe.fileno(), selectors.EVENT_READ, channel)
        if process.stdin is not None:
            os.set_blocking(process.stdin.fileno(), False)
            selector.register(process.stdin.fileno(), selectors.EVENT_WRITE, "stdin")
        until = min(DEADLINE, started + seconds)
        while selector.get_map():
            guard()
            require(time.monotonic() < until, "OWNED_SSH_OR_ALIAS_DEADLINE")
            for key, _ in selector.select(0.25):
                if key.data == "stdin":
                    try:
                        n = os.write(key.fd, input_body[sent:sent + 65536])
                    except BlockingIOError:
                        continue
                    require(n > 0, "SSH_SOURCE_STDIN_CLOSED")
                    sent += n
                    if sent == len(input_body):
                        selector.unregister(key.fd)
                        process.stdin.close()
                    continue
                try:
                    raw = os.read(key.fd, 16384)
                except BlockingIOError:
                    continue
                if not raw:
                    selector.unregister(key.fd)
                    continue
                buffer, cap = (out, stdout_cap) if key.data == "stdout" else (err, stderr_cap)
                remaining = cap - len(buffer)
                buffer.extend(raw[:remaining])
                # Persist bounded partial output into already allocated slots.
                target = stdout_slot if key.data == "stdout" else stderr_slot
                if target is not None:
                    slots.write(target, bytes(buffer), shrink=False)
                require(len(raw) <= remaining, "OWNED_SSH_OUTPUT_BOUND")
        code = process.wait(timeout=max(0.01, min(20, until - time.monotonic())))
        require(input_body is None or sent == len(input_body), "WHOLE_MAC_SOURCE_DELIVERED")
    except BaseException as error:
        failure = error_record(error, label)
    finally:
        try:
            stop_owned(process, identity_value)
        except BaseException as error:
            cleanup_failure = error_record(error, label + "-cleanup")
        finally:
            if selector is not None:
                selector.close()
            for stream in (process.stdin, process.stdout, process.stderr):
                if stream is not None and not stream.closed:
                    stream.close()
            if stdout_slot is not None:
                slots.write(stdout_slot, bytes(out))
            if stderr_slot is not None:
                slots.write(stderr_slot, bytes(err))
            terminal = {"label": label, "pid": process.pid, "identity": identity_value,
                        "returncode": process.returncode, "stdoutBytes": len(out),
                        "stdoutSHA256": digest(out), "stderrBytes": len(err),
                        "stderrSHA256": digest(err), "seconds": time.monotonic() - started,
                        "failure": failure, "cleanupFailure": cleanup_failure,
                        "ownedLeaderReaped": process.returncode is not None,
                        "descendantExtinctionClaimed": False, "automaticRetries": 0}
            PROCESS_LEDGER.append({"terminal": terminal})
            save_process_ledger(slots)
    require(cleanup_failure is None, "OWNED_SSH_CLEANUP_REFUSED")
    return terminal, bytes(out), bytes(err)

def pinned_alias(slots):
    argv = ["/usr/bin/ssh", "-G", "-o", "StrictHostKeyChecking=yes",
            "-o", "IdentitiesOnly=yes", "-o", "UpdateHostKeys=no",
            "-o", "ControlMaster=no", "-o", "ControlPath=none", "scaleway-mac"]
    terminal, raw, err = run_owned(argv, "existing-pinned-ssh-alias", None, 65536, 16384,
                                   15, slots, None, "ssh-alias.stderr")
    require(terminal["failure"] is None and terminal["returncode"] == 0, "SSH_ALIAS_COMMAND_FAILED")
    values = {}
    for line in raw.decode("utf-8", "strict").splitlines():
        key, _, value = line.partition(" ")
        if key in ("hostname", "user", "port", "stricthostkeychecking", "identitiesonly"):
            require(key not in values, "DUPLICATE_PINNED_SSH_OPTION")
            values[key] = value
    require(values.get("hostname") == "62.210.195.226" and values.get("user") == "m1"
            and values.get("port") == "22" and values.get("stricthostkeychecking") in ("true", "yes")
            and values.get("identitiesonly") == "yes", "EXISTING_PINNED_SSH_ALIAS_MISMATCH")
    return slots.write("SSH_ALIAS.json", canonical({"allowedFields": values,
                         "rawConfigurationSHA256": digest(raw), "rawConfigurationNotPersisted": True,
                         "stderrSHA256": digest(err), "terminal": terminal}))

def validate_transcript(raw):
    require(raw and raw.endswith(b"\n"), "COMPLETE_NDJSON_TRANSCRIPT")
    lines = raw.splitlines()
    require(0 < len(lines) <= 32, "FINITE_COLLECTOR_EVENTS")
    events = []
    for index, line in enumerate(lines, 1):
        value = json.loads(line)
        require(set(value) == {"sequence", "event", "utc", "value"} and
                type(value["sequence"]) is int and value["sequence"] == index,
                "STRICT_COLLECTOR_EVENT_SEQUENCE")
        events.append(value)
    finals = [x for x in events if x["event"] == "FINAL_RESULT"]
    require(len(finals) == 1 and finals[0] is events[-1], "ONE_TERMINAL_COLLECTOR_EVENT")
    result = finals[0]["value"]
    captures = [x["value"] for x in events if x["event"] == "METADATA_CAPTURE"]
    require(result["schema"] == "otzaria.native116-stage-leaf-preflight/1" and
            result["archivePath"] == "/Users/m1/otzaria-native116-staged-archive-20261128/native116-remaining-original-evidence.tar.gz"
            and result["retirementAuthorized"] is False and result["sourceWrites"] is False,
            "EXACT_READ_ONLY_COLLECTOR_RESULT")
    if result["status"] == "READ_ONLY_PREFLIGHT_CAPTURED":
        require(len(captures) == 2 and
                captures[0]["label"] == "BEFORE_ANY_STAGE_CONTENT_READ" and
                captures[1]["label"] == "AFTER_ARCHIVE_HASH_AND_CONSUMER_INSPECTION",
                "BEFORE_AND_AFTER_METADATA_EVENTS")
        compact = lambda v: json.dumps(v, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
        require(digest(compact(captures[0])) == result["beforeMetadataSHA256"] and
                digest(compact(captures[1])) == result["afterMetadataSHA256"], "COMPLETE_METADATA_EVENT_JOIN")
        require(result["fullArchiveHash"] == {"bytes": 1272863810,
                "sha256": "f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556",
                "regularPayloadsHashed": 1} and result["immutableMetadataEqual"] is True and
                result["boundedConsumerChecksComplete"] is True and
                result["noOtherOpenRecordsObserved"] is True and
                result["parentAndSiblingMetadataComplete"] is True and
                result["failure"] is None and not result["descriptorCloseErrors"],
                "NO_SUCCESS_FROM_INCOMPLETE_PREFLIGHT")
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-seal-sha256", required=True)
    parser.add_argument("phase", choices=("collect-read-only",))
    args = parser.parse_args()
    seal, seal_raw = verify_seal(args.source_seal_sha256)
    require(free() >= ROOT_FLOOR + FAMILY_CAP, "ORIGINAL_ROOT_RESERVE_PLUS_FAMILY_ADMISSION")
    guard()
    slots = ReservedFiles()
    outcome = {"schema": "otzaria.native116-stage-leaf-preflight-dispatch/1",
               "status": "INCOMPLETE", "sourceSealSHA256": digest(seal_raw),
               "macSourceSHA256": MAC_SHA256, "sourceWrites": False,
               "retirementAuthorized": False, "automaticRetries": 0}
    failure = None
    try:
        slots.create()
        outcome["sshAlias"] = pinned_alias(slots)
        source = read_source(FAMILY / "mac_stage_leaf_preflight.py", MAC_BYTES)
        require(len(source) == MAC_BYTES and digest(source) == MAC_SHA256, "MAC_SOURCE_FRESH_READBACK")
        bootstrap = (b"if not __debug__: raise RuntimeError('OPTIMIZED_REFUSED')\n"
                     b"import base64,hashlib,sys\n"
                     b"if not sys.flags.isolated or not sys.dont_write_bytecode: raise RuntimeError('ISOLATION_REQUIRED')\n"
                     b"s=base64.b64decode(" + repr(base64.b64encode(source)).encode("ascii") + b",validate=True)\n"
                     b"if hashlib.sha256(s).hexdigest() != " + repr(MAC_SHA256).encode("ascii") + b": raise RuntimeError('SOURCE_HASH')\n"
                     b"exec(compile(s,'<reviewed-native116-stage-leaf-preflight>','exec'),{'__name__':'__main__'})\n")
        require(len(bootstrap) <= 64 * 1024, "BOUNDED_IN_MEMORY_SOURCE_ENVELOPE")
        argv = ["/usr/bin/ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8",
                "-o", "StrictHostKeyChecking=yes", "-o", "IdentitiesOnly=yes",
                "-o", "UpdateHostKeys=no", "-o", "ControlMaster=no", "-o", "ControlPath=none",
                "-T", "scaleway-mac", "/usr/bin/python3", "-I", "-B", "-"]
        terminal, raw, err = run_owned(argv, "exact-read-only-stage-leaf", bootstrap,
                                       524288, 65536, 1215, slots,
                                       "mac-collector.stdout", "mac-collector.stderr")
        outcome["childTerminal"] = terminal
        outcome["transcript"] = {"path": str(RUN / "mac-collector.stdout"),
                                 "bytes": len(raw), "sha256": digest(raw)}
        if raw:
            outcome["collectorResult"] = validate_transcript(raw)
        require(terminal["failure"] is None and terminal["returncode"] == 0 and not err,
                "READ_ONLY_COLLECTOR_NOT_SUCCESSFUL")
        require(outcome.get("collectorResult", {}).get("status") == "READ_ONLY_PREFLIGHT_CAPTURED",
                "COMPLETE_READ_ONLY_RESULT_REQUIRED")
        verify_seal(args.source_seal_sha256)
        outcome["status"] = "READ_ONLY_STAGE_LEAF_PREFLIGHT_COMPLETE"
    except BaseException as error:
        failure = error_record(error, "DISPATCH")
        outcome["status"] = "READ_ONLY_STAGE_LEAF_PREFLIGHT_FAILED"
    finally:
        outcome.update({"failure": failure, "seconds": time.monotonic() - STARTED,
                        "nativeTreeNotVisited": True, "originalSourcesAndStageRetained": True,
                        "futureClosureAndSeparateRetirementApprovalRequired": True})
        try:
            if "PROCESS_LEDGER.json" in slots.reserved and "PROCESS_LEDGER.json" not in slots.closed:
                slots.write("PROCESS_LEDGER.json", canonical(PROCESS_LEDGER))
            if "TERMINAL.json" in slots.reserved:
                slots.write("TERMINAL.json", canonical({"utc": utc(), "failure": failure,
                            "status": outcome["status"], "rootFreeBytes": free(),
                            "familyAllocatedBytes": allocation(), "familyCap": FAMILY_CAP}))
            if "FINAL_RESULT.json" in slots.reserved:
                outcome["report"] = slots.write("FINAL_RESULT.json", canonical(outcome))
            else:
                outcome["failureBeforeReservedReport"] = True
        finally:
            slots.close()
        print(json.dumps(outcome, sort_keys=True, ensure_ascii=True))
    return 0 if outcome["status"] == "READ_ONLY_STAGE_LEAF_PREFLIGHT_COMPLETE" else 2

if __name__ == "__main__":
    sys.exit(main())
