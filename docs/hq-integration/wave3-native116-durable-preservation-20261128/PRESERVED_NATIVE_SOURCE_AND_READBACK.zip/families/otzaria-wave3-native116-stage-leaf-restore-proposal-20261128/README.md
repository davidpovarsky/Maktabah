# Exact opaque Native116 stage-leaf restoration — SOURCE ONLY

This packet implements one future, explicitly Root-admitted restoration of the already existing private immutable archive asset 803618998. It has not been imported or executed. No authenticated GET, Mac write, restoration, retirement, Native test or build is performed by source preparation.

The source joins the actual read-only stage collector: FINAL_RESULT 8d49d1a2 and complete transcript bfaa. The old stage file is 1,272,863,810 bytes with SHA256 f427758916a543b58f230c87e3d5eff1067e7db47f79a46d984315f8e155b556. Its captured values are mode0400, uid501/gid20, empty xattrs, null ACL and zero flags. The exact original atime/mtime nanosecond strings are retained without JavaScript numeric conversion.

## Future CLI and approval boundary

Root must first review the complete source seal. After actual full remote qualification, durable remote Git pointer verification and a separately reviewed exact stage-leaf retirement, Root may construct the seven-evidence-file admission described by ADMISSION_TEMPLATE.json. Templates contain null pins and an unapproved status, so they cannot run. The pinned Root admission is the explicit approval boundary for the future durable-Git and actual-retirement proof adapters. The source does not pretend those future proofs currently exist or independently issue new Git API reads.

The later single command is:
```sh
/usr/bin/sudo -u ubuntu -H /usr/bin/python3 -I -B /home/ubuntu/otzaria-wave3-native116-stage-leaf-restore-proposal-20261128/restore_stage_leaf.py --source-seal-sha256 <Root-reviewed-source-seal> --admission-sha256 <Root-reviewed-exact-admission> restore-once
```

The final stage leaf and the unique owned temporary name must both be absent. This source contains no retirement entrypoint and never removes an original stage leaf. The full qualification receipt is joined to its actual successful Sentinel job output, three complete payloads, every original tar member and original source-before/source-after records. An asset server digest, the earlier timeout or a partially read prefix is insufficient.

## Transfer and publication

The Oracle side uses the existing authenticated gh mechanism, with GH_DEBUG absent, and the existing pinned scaleway-mac SSH alias. No token getter or credential transfer is introduced. Only the three fixed private metadata GETs and one immutable archive GET are allowed. The receiver admits its exact captured parent and protected terminal sibling, checks the original Mac floor plus every remaining rounded payload byte and4MiB metadata reserve, creates one exclusive temporary file, then reports READY. Oracle starts the archive GET only after that event.

Bounded pipes apply backpressure. Oracle counts and hashes every byte and holds the final64KiB until the getter exits0 and full length/SHA match. The receiver requires exact EOF, fsyncs and rehashes the entire stored file before applying captured permissions and atime/mtime. It rechecks empty xattrs, null ACL and zero flags. A same-parent exclusive link publishes the final name without replacing anything; only the newly created temporary name is removed afterward, with parent fsync and exact nlink checks.

Failure preserves partial payload and local reports. Cleanup is limited to each newly created, exact owned process group with its unreaped leader identity. Reports claim only owned leaders reaped, never arbitrary descendant extinction. Original reader/process helper bodies are byte-reused where identified in SOURCE_REUSE.json; the new relay is source-reviewed work, not a claimed old test result.

## Limits and explicit gaps

The original Root1,593,835,520-byte and Mac2,415,919,104-byte floors remain. SDK admission remains15,032,385,536 bytes. The prior preflight family's conservative630,784-byte planning charge plus new source/admission/runtime must fit the same2MiB reserve already charged to the Native48MiB guard. New source is capped at640KiB, future admission192KiB, and runtime512KiB including real directory/file allocations. The additional family maximum is1,466,368 bytes.

Overall2700s and the original finite1200s stream/receiver bound are retained. The separate1800s readback qualification approval is not silently extended to this restorer. No restoration throughput or Darwin write-operation qualification is claimed. Those methods fail closed on absent host API support or mismatched metadata. A future deadline adjustment would need its own reviewed source change.

New inode, ctime, birthtime and allocation are recorded; they are not restored to the old values. The original birthtime is retained in the pointer but no birthtime setter is implemented. No tar extraction, original Native tree recreation, external symlink traversal, Git-reference resolution, Windows-base operation, simulator action or source-tree deletion is present.

All packet content and any future authentication journals are private. No raw authenticated response or credential-bearing error should be put in public Git or chat output.

The first source-only author refused before creating this scope because current prior-family allocation was589,824 bytes, rather than the older630,784 sample. Its full source and raw failure are retained; the exact subsequent27-entry metadata read is preserved. No cause of the difference is inferred. The larger630,784 planning charge and all original caps remain unchanged. Full actual source-author scripts are preserved losslessly as gzip members inside SOURCE_RAW.zip, avoiding redundant standalone copies within the fixed source budget.
