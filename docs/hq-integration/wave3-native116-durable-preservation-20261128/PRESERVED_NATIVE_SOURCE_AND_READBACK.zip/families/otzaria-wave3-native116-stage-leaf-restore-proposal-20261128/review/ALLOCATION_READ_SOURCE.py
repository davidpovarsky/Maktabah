import json,os,pathlib,stat,time
p=pathlib.Path("/home/ubuntu/otzaria-wave3-native116-stage-leaf-preflight-proposal-20261128")
start=time.monotonic();out=[];total=0;rootdev=os.stat("/").st_dev
todo=[(p,"",0)]
while todo:
 if time.monotonic()-start>8:raise RuntimeError("Bounded known family")
 q,rel,d=todo.pop();s=q.lstat()
 if d>3 or len(out)>=128 or s.st_dev!=rootdev or s.st_uid!=1001 or s.st_gid!=1001:raise RuntimeError("Exact owned family")
 row={"path":rel,"device":s.st_dev,"inode":s.st_ino,"mode":s.st_mode,"uid":s.st_uid,"gid":s.st_gid,"nlink":s.st_nlink,"bytes":s.st_size,"allocatedBytes":s.st_blocks*512,"mtimeNS":str(s.st_mtime_ns),"ctimeNS":str(s.st_ctime_ns)}
 total+=row["allocatedBytes"];out.append(row)
 if stat.S_ISDIR(s.st_mode):
  for c in sorted(q.iterdir(),reverse=True):todo.append((c,rel+"/"+c.name if rel else c.name,d+1))
 elif not stat.S_ISREG(s.st_mode) or s.st_nlink!=1:raise RuntimeError("No links/special files")
new=pathlib.Path("/home/ubuntu/otzaria-wave3-native116-stage-leaf-restore-proposal-20261128")
print(json.dumps({"scope":str(p),"allocatedBytes":total,"entries":out,"newSourceExists":new.exists(),"newSourceSymlink":new.is_symlink(),"readOnlyMetadataOnly":True},sort_keys=True))
