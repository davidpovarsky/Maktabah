# Exact completed-readback output binding

This additive source-only delta preserves the frozen original 23-file restorer packet. It fixes only the output-parsing seam in verify_full_qualification: actual successful job_a02eee978d8f emits an admission JSON line and a final JSON line. The old single-json.loads call cannot parse that output.

CANDIDATE.patch and EXACT_EDIT.json reconstruct the full 50,478-byte candidate from the exact 49,510-byte original; the candidate SHA256 is 09e78f0456f51e9d474833fbb3c9f92a33f11b4c7b73ef95b159a5e886713193. The full candidate is deliberately not duplicated here. Exact forward/inverse and source AST definition comparison confirm that every other module byte is unchanged. No candidate import or runtime occurred.

The new seam requires the exact completed job ID, exact 571-byte stdout SHA256, exactly two lines, the actual admission path/1,650-byte hash/Ubuntu1001/all14+12 join, and the exact 65,536-byte final result e9242bcf. It then performs the unchanged final receipt equality. All earlier full asset/member/source qualification checks remain unchanged. The original seven future admission evidence leaves are unchanged.

ACTUAL_READBACK_JOB.json is the exact safe notification text returned by the existing notification service; its output contains the original two-line stdout. ACTUAL_ROOT_ADMISSION.json is the independently hash-joined actual admission. The complete final result and sourceBefore/sourceAfter remain at their pinned original runtime paths; this packet records their full verified hashes without duplicating them. No raw private API journals or credentials are included.

This is a reviewable source delta, not a standalone execution entrypoint. Root must integrate the reviewed delta into a future executable source closure, preserve the original packet, bind its new seal in the restoration pointer/admission, and count all retained source storage before any invocation. No pointer, retirement authority, future seven-file admission, runtime directory, GET, Mac action or restore was created.

Budget: this packet is capped at 53,248 allocated bytes, counted with the old 602,112 source bytes against the original 655,360 source allowance. It is also counted with the conservative historical 630,784 bytes and unchanged 196,608 admission + 524,288 runtime reserves within the original 2,097,152 combined family limit. The original root floor, Mac live floor, payload reserve, stream/overall deadlines and all owned-process cleanup bodies are unchanged. SDK admission remains 15,032,385,536 bytes.
