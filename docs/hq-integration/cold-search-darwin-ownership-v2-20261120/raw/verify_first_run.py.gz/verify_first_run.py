from pathlib import Path
import gzip, hashlib, json, zipfile

R = Path(__file__).resolve().parent
E = R / 'extracted/cold-search-ownership'
def sha(data): return hashlib.sha256(data).hexdigest()
def read(name): return json.loads((E / name).read_bytes())
metadata = json.loads((R / 'ARTIFACT_METADATA.json').read_text())['artifacts'][0]
archive = (R / 'artifact-14646590409.zip').read_bytes()
assert len(archive) == metadata['size_in_bytes'] == 1203409
assert 'sha256:' + sha(archive) == metadata['digest']
run = json.loads((R / 'RUN.json').read_text())
jobs = json.loads((R / 'JOBS.json').read_text())['jobs']
assert run['id'] == 44765987116 and run['run_attempt'] == 1
assert run['head_sha'] == metadata['workflow_run']['head_sha'] == '3ef8f6c410074a633dda5c33121d429ccf543ef3'
assert run['status'] == 'completed' and run['conclusion'] == 'failure'
assert len(jobs) == 1 and jobs[0]['id'] == 136390606628 and jobs[0]['conclusion'] == 'failure'
result = read('RESULT.json')
assert result['status'] == 'FAIL_ACTUAL_OWNERSHIP_ACCEPTANCE'
assert result['github']['GITHUB_SHA'] == run['head_sha'] and result['github']['GITHUB_RUN_ATTEMPT'] == '1'
before, after = read('source-before.json'), read('source-after.json')
assert before == after
with zipfile.ZipFile(E / 'SOURCE_INPUTS.zip') as z:
    assert z.testzip() is None
    manifest = json.loads(z.read('Tests/HQ/cold-search-ownership/OWNERSHIP_INPUTS.json'))
    assert sha(z.read('Tests/HQ/cold-search-ownership/OWNERSHIP_INPUTS.json')) == result['input_manifest_sha256']
    for row in before:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
    preguard = gzip.decompress(z.read('Tests/HQ/cold-search-ownership/pre-publication-Repository.swift.gz'))
    product = z.read('Source/Otzaria/Search/OtzariaTantivySearchRepository.swift')
stages = {}
for name, expected_names, expected_source in [('pre-guard1', [manifest['baseline_case']], preguard),
                                               ('candidate32', manifest['cases'], product)]:
    stage = result['stages'][name]
    checks = read(name + '.CHECKS.json')
    assert checks == stage['checks']
    assert [row['id'] for row in checks['checks']] == expected_names
    assert stage['compile']['returncode'] == 0 and not stage['compile']['timed_out']
    assert stage['runtime']['returncode'] == 1 and not stage['runtime']['timed_out']
    for kind in ('compile', 'run'):
        data = (E / (name + '.' + kind + '.log')).read_bytes()
        assert sha(data) == stage['compile' if kind == 'compile' else 'runtime']['log_sha256']
    assert read(name + '.source-before.json') == read(name + '.source-after.json')
    assert read(name + '.source-before.json')['OtzariaTantivySearchRepository.swift'] == sha(expected_source)
    passed = sum(row['outcome'] == 'passed' for row in checks['checks'])
    stages[name] = {'declared_and_completed': len(expected_names), 'passed': passed,
                   'failed': len(expected_names) - passed, 'qualified': stage['qualified'],
                   'compile_exit': 0, 'runtime_exit': 1, 'source_unchanged': True,
                   'failure_rows': [row for row in checks['checks'] if row['outcome'] != 'passed']}
assert stages['candidate32']['passed'] == 18 and stages['candidate32']['failed'] == 14
assert stages['pre-guard1']['failure_rows'][0]['code'] == 'candidate_handle_not_closed'
assert not any(stage['qualified'] for stage in stages.values())
report = {'status': 'AUTHENTIC_FIRST_FAILURE_VERIFIED', 'run': run['id'], 'attempt': 1,
          'head': run['head_sha'], 'branch': run['head_branch'], 'job': jobs[0]['id'],
          'actual_job_started_at': jobs[0]['started_at'], 'actual_job_completed_at': jobs[0]['completed_at'],
          'artifact': metadata['id'], 'zip_bytes': len(archive), 'zip_sha256': sha(archive),
          'source_inputs_zip_sha256': sha((E / 'SOURCE_INPUTS.zip').read_bytes()),
          'bound_source_inputs': len(before), 'stages': stages,
          'baseline_red_qualified': False, 'actual_c_or_rust_engine_executed': 0, 'native_ui_executed': 0,
          'interpretation': 'Both Swift stages compiled and all named custom Foundation checks completed. The baseline failure was the wrong oracle; candidate18/32 passed. No app/engine/Native credit.'}
(R / 'AUTHENTIC_FIRST_RUN_REVIEW.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('status', 'run', 'head', 'bound_source_inputs', 'baseline_red_qualified')}))
print(json.dumps({name: {key: stage[key] for key in ('declared_and_completed', 'passed', 'failed', 'qualified')} for name, stage in stages.items()}))
