#!/usr/bin/env python3
"""Reverify current owned Work against complete off-host preservation; never retire."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import resource
import sys
import time
import types

sys.dont_write_bytecode = True
EVIDENCE = Path('/Users/m1/builds/otzaria-wave3-ad6-preservation-20261127.n155e60d')
HEADER_SHA = '0eda5768bd4ef592a41b2ad278b3ebd6ffb18b26e7f7c0b38bb63d220d8ec21f'
SCRIPT_SHA = '9bb4e8dc5ddf3661860bbc5b71245d1227c04561a2bf25cced727e7b38132f4d'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def main(expected):
    started = time.monotonic()
    body = (EVIDENCE / 'ad6_preservation.py').read_bytes()
    assert hashlib.sha256(body).hexdigest() == SCRIPT_SHA
    module = types.ModuleType('frozen_ad6_preservation_helpers')
    module.__file__ = str(EVIDENCE / 'ad6_preservation.py')
    exec(compile(body, module.__file__, 'exec'), module.__dict__)
    header = module.load_header(EVIDENCE, HEADER_SHA)
    proof_path = EVIDENCE / 'COMPLETE_PRESERVATION_VERIFIED.json'
    assert digest(proof_path) == expected
    proof = json.loads(proof_path.read_bytes())
    assert proof['status'] == 'COMPLETE_FAILED_AD6_DIFFERENTIAL_AND_ALL_PHYSICAL_REFERENCES_VERIFIED_NOT_RETIRED'
    assert proof['header_sha256'] == HEADER_SHA and not proof['anything_deleted']
    assert not proof['retirement_authorized'] and len(proof['archive_bindings']) == 6
    streamed = json.loads((EVIDENCE / 'STREAM_RESULT.json').read_bytes())
    assert streamed['header_sha256'] == HEADER_SHA
    assert streamed['archive_sha256'] == proof['new_archive_sha256']
    assert streamed['archive_bytes'] == proof['new_archive_bytes']
    before = module.boundary()
    assert before == header['boundary']
    use_before = module.no_use()
    free = module.capacity()
    helper_module, h, _ = module.helpers()
    h.ROOT = module.ROOT
    count = files = logical = private = atime_changes = 0
    stat_sha = hashlib.sha256()
    content_sha = hashlib.sha256()
    with gzip.open(EVIDENCE / 'entries.jsonl.gz', 'rb') as original:
        for p, s in module.walk():
            raw = original.readline()
            assert raw, 'Current source gained a path'
            initial = json.loads(raw)
            actual = h.entry((p, s))
            actual['path'] = p.relative_to(module.ROOT).as_posix()
            assert {k: v for k, v in actual.items() if k != 'atime_ns'} == {
                k: v for k, v in initial.items() if k not in ('atime_ns', 'payload', 'allocation_observation')
            }, str(p)
            atime_changes += actual['atime_ns'] != initial['atime_ns']
            stat_sha.update(module.canonical({'path': actual['path'], 'identity': h.identity(s)}))
            count += 1
            if actual['type'] == 'file':
                files += 1
                logical += actual['bytes']
                content_sha.update(module.canonical({'path': actual['path'], 'bytes': actual['bytes'], 'sha256': actual['sha256']}))
                allocation = helper_module.private_size(h, p)
                if actual['nlink'] == 1:
                    private += allocation['private_bytes']
            if count % 1024 == 0:
                module.capacity()
        assert original.read(1) == b'', 'Current source lost a path'
    assert count == header['summary']['entries'] == 136409
    assert files == header['summary']['files'] == 117206
    assert logical == header['summary']['logical_bytes'] == 11451441643
    assert stat_sha.hexdigest() == header['path_stat_sha256']
    assert content_sha.hexdigest() == header['regular_content_sha256']
    after_stat = hashlib.sha256()
    for p, s in module.walk():
        after_stat.update(module.canonical({'path': p.relative_to(module.ROOT).as_posix(), 'identity': h.identity(s)}))
    assert after_stat.digest() == stat_sha.digest()
    assert module.boundary() == before
    use_after = module.no_use()
    result = {'status': 'COMPLETE_FAILED_AD6_CURRENT_SOURCE_CONTENT_METADATA_REVERIFIED_NOT_RETIRED',
              'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'root': str(module.ROOT), 'header_sha256': HEADER_SHA,
              'complete_preservation_receipt_sha256': expected,
              'new_archive': proof['new_archive'], 'new_archive_sha256': proof['new_archive_sha256'],
              'new_archive_bytes': proof['new_archive_bytes'],
              'entries': count, 'files': files, 'logical_bytes': logical,
              'fresh_kernel_private_bytes': private,
              'path_stat_sha256': stat_sha.hexdigest(), 'regular_content_sha256': content_sha.hexdigest(),
              'boundary_before': before, 'boundary_after': module.boundary(),
              'open_use_before': use_before, 'open_use_after': use_after,
              'free_before': free, 'free_after': module.capacity(),
              'metadata_note': 'All original atime values remain in the verified archive. Only read-induced current atime is excluded from equality; every other original metadata/content field is compared. Historical inode/device/ctime are evidence, not promised numeric values after restoring a filesystem.',
              'read_induced_atime_differences': atime_changes,
              'full_restored_tree_materialized': False,
              'preservation_proof': 'Every current path/content/metadata matches the complete preserved inventory, and every original file maps to an independently verified new physical member or an exact member in one of six unchanged fully verified archives.',
              'anything_deleted': False, 'retirement_authorized': False,
              'new_sdk_qualification': False, 'new_native_runs': 0,
              'reverification_script_sha256': digest(Path(__file__)),
              'seconds': time.monotonic() - started,
              'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    receipt = module.save(EVIDENCE / 'SOURCE_REVERIFIED.json', result)
    print(json.dumps({'status': result['status'], 'receipt': receipt,
                      'entries': count, 'files': files, 'fresh_kernel_private_bytes': private,
                      'atime_differences': atime_changes, 'free_after': result['free_after'],
                      'seconds': result['seconds']}))

if __name__ == '__main__':
    assert len(sys.argv) == 2
    main(sys.argv[1])
