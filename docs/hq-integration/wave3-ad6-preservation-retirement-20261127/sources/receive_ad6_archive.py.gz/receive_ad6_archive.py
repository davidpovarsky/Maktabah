#!/usr/bin/env python3
"""Receive the authorized failed-ad6 differential; no source deletion or build."""
from pathlib import Path
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import threading
import time

ROOT = Path(r'C:\Users\DAVID\.codex\artifacts\otzaria-wave3-ad6-preservation-20261127')
MAC = '/Users/m1/builds/otzaria-wave3-ad6-preservation-20261127.n155e60d'
HEADER = '0eda5768bd4ef592a41b2ad278b3ebd6ffb18b26e7f7c0b38bb63d220d8ec21f'
SCRIPT = '9bb4e8dc5ddf3661860bbc5b71245d1227c04561a2bf25cced727e7b38132f4d'
RESERVE = 2415919104
MAXIMUM = 4294967296
TIMEOUT = 900
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'scaleway-mac']
K = ctypes.WinDLL('kernel32', use_last_error=True)
K.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
K.OpenProcess.restype = wintypes.HANDLE
K.GetProcessTimes.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.FILETIME),
                             ctypes.POINTER(wintypes.FILETIME), ctypes.POINTER(wintypes.FILETIME),
                             ctypes.POINTER(wintypes.FILETIME)]
K.GetProcessTimes.restype = wintypes.BOOL
K.CloseHandle.argtypes = [wintypes.HANDLE]

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(pid):
    handle = K.OpenProcess(0x1000, False, pid)
    if not handle:
        raise OSError(ctypes.get_last_error(), 'OpenProcess', pid)
    times = [wintypes.FILETIME() for _ in range(4)]
    try:
        assert K.GetProcessTimes(handle, *(ctypes.byref(x) for x in times))
        return {'pid': pid, 'creation_filetime': (times[0].dwHighDateTime << 32) | times[0].dwLowDateTime}
    finally:
        K.CloseHandle(handle)

def save(name, value):
    data = value if isinstance(value, bytes) else (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    assert shutil.disk_usage(ROOT).free - len(data) >= RESERVE
    p = ROOT / name
    with p.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def remote(name):
    assert '/' not in name and '\\' not in name
    r = subprocess.run(SSH + ['/bin/cat', MAC + '/' + name], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
    assert r.returncode == 0, (name, r.returncode, r.stderr.decode(errors='replace'))
    return r.stdout

assert ROOT.is_dir()
assert shutil.disk_usage(ROOT).free >= RESERVE + MAXIMUM + 67108864
partial = ROOT / 'failed-ad6-work-differential.tar.gz.partial'
target = ROOT / 'failed-ad6-work-differential.tar.gz'
assert not partial.exists() and not target.exists()
started = time.monotonic()
before = shutil.disk_usage(ROOT).free
stop = threading.Event()
failure = []
mac_owner = None
total = 0
hashing = hashlib.sha256()
with (ROOT / 'STREAM.stderr.log').open('xb') as err:
    proc = subprocess.Popen(SSH + ['/usr/bin/python3', MAC + '/ad6_preservation.py', 'stream', MAC, HEADER],
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=err)
    own = identity(proc.pid)
    save('RECEIVER_OWNER.json', {'utc': utc(), 'receiver': identity(os.getpid()), 'owned_ssh': own,
         'receiver_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'mac_script_sha256': SCRIPT, 'mac_evidence': MAC, 'header_sha256': HEADER,
         'archive_limit_bytes': MAXIMUM, 'windows_reserve_bytes': RESERVE, 'timeout_seconds': TIMEOUT,
         'source_deletion_authorized': False, 'build_authorized': False})
    def guard():
        while not stop.wait(1):
            reason = None
            if time.monotonic() - started >= TIMEOUT:
                reason = 'Own transfer timeout'
            elif shutil.disk_usage(ROOT).free < RESERVE + 1048576:
                reason = 'Own Windows live reserve'
            if reason and proc.poll() is None:
                failure.append(reason)
                try:
                    assert identity(proc.pid) == own
                    proc.terminate()
                except BaseException as error:
                    failure.append(repr(error))
                return
    thread = threading.Thread(target=guard, daemon=True)
    thread.start()
    try:
        with partial.open('xb') as output:
            while True:
                b = proc.stdout.read(65536)
                if not b:
                    break
                if total + len(b) > MAXIMUM or shutil.disk_usage(ROOT).free - len(b) < RESERVE:
                    failure.append('Own archive output cap or Windows reserve')
                    if proc.poll() is None:
                        assert identity(proc.pid) == own
                        proc.terminate()
                    raise RuntimeError(failure[-1])
                output.write(b)
                hashing.update(b)
                total += len(b)
                if mac_owner is None:
                    raw = remote('STREAM_OWNER.json')
                    mac_owner = json.loads(raw)
                    assert mac_owner['script_sha256'] == SCRIPT and mac_owner['pid'] > 0
                    assert MAC + '/ad6_preservation.py stream ' + MAC + ' ' + HEADER in mac_owner['command']
                    save('MAC_STREAM_OWNER.json', raw)
            output.flush()
            os.fsync(output.fileno())
        code = proc.wait(timeout=20)
        assert code == 0 and not failure, (code, failure, (ROOT / 'STREAM.stderr.log').read_text(errors='replace'))
        raw = remote('STREAM_RESULT.json')
        observed = json.loads(raw)
        assert observed['status'] == 'FAILED_AD6_DIFFERENTIAL_STREAMED_NOT_RETIRED'
        assert observed['header_sha256'] == HEADER and observed['owner'] == mac_owner
        assert observed['archive_bytes'] == total and observed['archive_sha256'] == hashing.hexdigest()
        assert observed['new_payloads'] == 31355 and observed['new_payload_bytes'] == 3770386133
        save('MAC_STREAM_RESULT.json', raw)
        partial.rename(target)
        result = {'status': 'EXACT_DIFFERENTIAL_TRANSFERRED_ALL_MEMBER_VERIFICATION_PENDING',
                  'utc': utc(), 'archive': str(target), 'archive_bytes': total,
                  'archive_sha256': hashing.hexdigest(), 'header_sha256': HEADER,
                  'mac_owner': mac_owner, 'owned_ssh': own, 'windows_free_before': before,
                  'windows_free_after': shutil.disk_usage(ROOT).free,
                  'seconds': time.monotonic() - started, 'anything_deleted': False,
                  'new_sdk_or_native_runs': 0, 'new_cache_qualification': False}
        receipt = save('TRANSFER_RESULT.json', result)
        print(json.dumps({'result': result, 'receipt': receipt}))
    except BaseException as error:
        if proc.poll() is None:
            assert identity(proc.pid) == own
            proc.terminate()
        save('TRANSFER_FAILURE.json', {'utc': utc(), 'error': repr(error), 'failures': failure,
             'owned_ssh': own, 'bytes_received': total, 'partial_sha256': hashing.hexdigest(),
             'anything_deleted': False})
        raise
    finally:
        stop.set()
        thread.join(timeout=3)
