#!/usr/bin/env python3
"""Bind every current prior reference to physical original members and current archives."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import time
import types
import datetime

ROOT = Path(r'C:\Users\DAVID\.codex\artifacts\otzaria-wave3-ad6-preservation-20261127')
FIVE = ROOT.parent / 'otzaria-wave3-five-scope-preservation-20261127-attempt2'
RESERVE = 2415919104

def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def identity(p):
    s = p.stat()
    return {'device': s.st_dev, 'inode': s.st_ino, 'bytes': s.st_size,
            'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}

def save(name, data):
    if not isinstance(data, bytes):
        data = (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()
    assert shutil.disk_usage(ROOT).free - len(data) >= RESERVE
    p = ROOT / name
    with p.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

started = time.monotonic()
new_bytes = (ROOT / 'NEW_ARCHIVE_VERIFIED.json').read_bytes()
new = json.loads(new_bytes)
assert new['status'] == 'COMPLETE_NEW_ARCHIVE_MEMBERS_METADATA_AND_PATHSET_VERIFIED_PRIOR_MEMBERSHIP_PENDING'
header = json.loads((ROOT / 'metadata/HEADER.json').read_bytes())
ledger = new['prior_reference_ledger']
assert digest(Path(ledger['path'])) == ledger['sha256']
required = {}
raw_sha = hashlib.sha256()
raw_count = count = 0
with gzip.open(ledger['path'], 'rb') as f:
    for line in f:
        row = json.loads(line)
        raw_sha.update(line)
        raw_count += len(line)
        target = required.setdefault(row['archive_id'], {})
        assert row['member'] not in target
        target[row['member']] = row
        count += 1
assert count == ledger['members'] and raw_count == ledger['raw_bytes']
assert raw_sha.hexdigest() == ledger['raw_sha256']
old_header = (FIVE / 'HEADER.json').read_bytes()
assert hashlib.sha256(old_header).hexdigest() == '8a2e85baf405350e77bebb2cab20a4f430c55ceaddc8689893b5e34d831aa007'
old = json.loads(old_header)
source = (FIVE / 'five_scope.py').read_bytes()
assert hashlib.sha256(source).hexdigest() == old['script_sha256']
text = source.decode()
nodes = [n for n in ast.parse(text).body if isinstance(n, ast.ClassDef) and n.name == 'Stream']
assert len(nodes) == 1
parser_source = ast.get_source_segment(text, nodes[0])
parser = types.ModuleType('verbatim_original_stream_parser')
parser.__dict__['json'] = json
exec(compile(parser_source, str(FIVE / 'five_scope.py') + ':Stream', 'exec'), parser.__dict__)
win_bytes = (ROOT / 'prior-windows/PRIOR_WINDOWS_ARCHIVES_VERIFIED.json').read_bytes()
assert hashlib.sha256(win_bytes).hexdigest() == 'df5fdcf1d3754457eac738b25200a6bec6b0d6e407a2f89c7c7486a8531dc1bf'
windows = json.loads(win_bytes)
assert windows['status'] == 'FOUR_EXISTING_ARCHIVE_BYTES_AND_ORIGINAL_FULL_MEMBER_PROOFS_VERIFIED'
results = []
for binding in windows['archives']:
    aid = binding['id']
    p = Path(binding['archive'])
    m = Path(binding['manifest'])
    r = Path(binding['full_member_receipt'])
    assert identity(p) == binding['archive_identity']
    assert identity(m) == binding['manifest_identity']
    assert digest(r) == binding['full_member_receipt_sha256']
    before = identity(m)
    assert digest(m) == binding['manifest_sha256']
    need = required.get(aid, {})
    found = set()
    physical = 'entries' if aid in ('app-generated', 'old-sdk-producer') else 'new_payloads'
    counts = {'entries': 0, 'new_payloads': 0}
    with m.open(encoding='utf-8') as f:
        for kind, row in parser.Stream(f).arrays():
            counts[kind] += 1
            if kind != physical or (kind == 'entries' and row.get('type') != 'file'):
                continue
            member = row['path'] if kind == 'entries' else row['member']
            if member not in need:
                continue
            expected = need[member]
            assert expected['archive_sha256'] == binding['archive_sha256']
            assert expected['bytes'] == row['bytes'] and expected['sha256'] == row['sha256']
            assert member not in found
            found.add(member)
    assert found == set(need) and identity(m) == before
    expected_counts = next(x['counts'] for x in header['base_archives'] if x['id'] == aid)
    assert counts == expected_counts
    results.append({**binding, 'required_members': len(need), 'required_members_matched': len(found),
                    'manifest_counts': counts, 'physical_member_scope': physical,
                    'original_full_member_proof_reused_for_identical_freshly_hashed_archive': True})
oracle_bytes = (ROOT / 'PRIOR_ORACLE_ARCHIVES_VERIFIED.json').read_bytes()
oracle = json.loads(oracle_bytes)
assert oracle['status'] == 'TWO_EXISTING_ORACLE_ARCHIVES_AND_ORIGINAL_MEMBER_PROOFS_VERIFIED'
oracle_source = r'''from pathlib import Path
import sys,json,gzip,hashlib
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def identity(p):
 s=p.stat();return {'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
packet=json.loads(gzip.decompress(sys.stdin.buffer.read()))
out=[]
for binding in packet['bindings']:
 aid=binding['id'];p=Path(binding['archive']);m=Path(binding['new_payload_manifest'])
 assert identity(p)==binding['archive_identity'] and identity(m)==binding['new_payload_manifest_identity']
 assert digest(Path(binding['full_member_receipt']))==binding['full_member_receipt_sha256']
 assert digest(Path(binding['header']))==binding['header_sha256']
 assert digest(m)==binding['new_payload_manifest_sha256']
 header=json.loads(Path(binding['header']).read_bytes())
 meta=next(x for x in header['metadata'] if x['name']=='new-payloads.jsonl.gz')
 need={x['member']:x for x in packet['required'] if x['archive_id']==aid};found=set()
 h=hashlib.sha256();count=total=0
 with gzip.open(m,'rb') as f:
  for line in f:
   h.update(line);total+=len(line);row=json.loads(line);count+=1
   member=row['member']
   if member in need:
    expected=need[member]
    assert expected['archive_sha256']==binding['archive_sha256']
    assert expected['bytes']==row['bytes'] and expected['sha256']==row['sha256']
    assert member not in found;found.add(member)
 assert total==meta['uncompressed_bytes'] and h.hexdigest()==meta['uncompressed_sha256']
 assert found==set(need) and identity(p)==binding['archive_identity'] and identity(m)==binding['new_payload_manifest_identity']
 out.append({**binding,'required_members':len(need),'required_members_matched':len(found),
             'physical_members':count,'physical_member_scope':'new_payloads',
             'original_full_member_proof_reused_for_identical_freshly_hashed_archive':True})
print(json.dumps({'status':'ALL_REQUIRED_ORACLE_PHYSICAL_MEMBERS_MATCH_EXACT_PRIOR_PROOFS',
                  'archives':out,'writes':0,'archives_mutated':False}))
'''
oracle_ids = {x['id'] for x in oracle['archives']}
packet = {'bindings': oracle['archives'], 'required': [row for aid in oracle_ids for row in required.get(aid, {}).values()]}
payload = gzip.compress((json.dumps(packet, sort_keys=True) + '\n').encode(), mtime=0)
save('ORACLE_REQUIRED_INPUT.json.gz', payload)
save('verify_oracle_required_members.py', oracle_source.encode())
command = '/usr/bin/python3 -c ' + shlex.quote(oracle_source)
run = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'torah-social', command],
                     input=payload, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
save('PRIOR_ORACLE_REQUIRED.stdout.json', run.stdout)
save('PRIOR_ORACLE_REQUIRED.stderr.log', run.stderr)
assert run.returncode == 0, (run.returncode, run.stderr.decode(errors='replace'))
observed = json.loads(run.stdout)
assert observed['status'] == 'ALL_REQUIRED_ORACLE_PHYSICAL_MEMBERS_MATCH_EXACT_PRIOR_PROOFS'
results.extend(observed['archives'])
assert {x['id'] for x in results} == {x['id'] for x in header['base_archives']}
assert sum(x['required_members_matched'] for x in results) == count
assert identity(Path(new['new_archive'])) == new['archive_identity']
record = {'status': 'ALL_SIX_ARCHIVES_CURRENT_AND_EVERY_REQUIRED_PHYSICAL_MEMBER_BOUND',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'header_sha256': new['header_sha256'], 'new_archive_verification_sha256': hashlib.sha256(new_bytes).hexdigest(),
          'prior_reference_ledger': ledger, 'prior_members_verified': count,
          'archive_bindings': results, 'windows_archive_fresh_hash_receipt_sha256': hashlib.sha256(win_bytes).hexdigest(),
          'oracle_archive_fresh_hash_receipt_sha256': hashlib.sha256(oracle_bytes).hexdigest(),
          'oracle_required_receipt_sha256': hashlib.sha256(run.stdout).hexdigest(),
          'verbatim_parser_origin_sha256': hashlib.sha256(source).hexdigest(),
          'verbatim_parser_sha256': hashlib.sha256(parser_source.encode()).hexdigest(),
          'verifier_sha256': digest(Path(__file__)), 'seconds': time.monotonic() - started,
          'archives_mutated': False, 'anything_deleted': False, 'retirement_authorized': False,
          'new_sdk_or_native_runs': 0}
receipt = save('PRIOR_MEMBERS_VERIFIED.json', record)
print(json.dumps({'status': record['status'], 'receipt': receipt, 'prior_members': count,
                  'archives': len(results), 'seconds': record['seconds']}))
