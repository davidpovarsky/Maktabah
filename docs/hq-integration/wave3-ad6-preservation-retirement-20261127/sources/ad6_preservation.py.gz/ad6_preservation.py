#!/usr/bin/env python3
"""Preserve only the failed local-ad6e Work, with full metadata and exact prior payload references.

No deletion, cache admission, source edit, or build action exists in this script.
"""
from pathlib import Path
import argparse
import datetime
import gzip
import hashlib
import io
import json
import os
import resource
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import time
import types

sys.dont_write_bytecode = True
ROOT = Path('/Users/m1/builds/otzaria-wave1-sdk-20261127/source/build/SDK-Wave3-1be97035-Debug-FreshAfterFiveScopes-20261127-Work')
SOURCE = ROOT.parent.parent
CONTROL = Path('/Users/m1/builds/otzaria-wave3-ad6-preservation-control-20261127')
PLAN = CONTROL / 'READ_ONLY_PLAN.json'
PLAN_SHA = 'f7926486d1e091ed8ffff89f7fbe222cc9e2b71fea25d4c8486bfe97c305fe85'
FIVE = Path('/Users/m1/builds/otzaria-wave3-five-scope-preservation-20261127.erim3ayq')
FIVE_HEADER_SHA = '8a2e85baf405350e77bebb2cab20a4f430c55ceaddc8689893b5e34d831aa007'
FIVE_PROOF_SHA = 'ef4ab6539a882c68df77ce8d0d349c2eeb83a2167bbb8b260cb6e2777ebc48a0'
FIVE_ARCHIVE_SHA = '39c5145756f859ca62ca215f3ceecd084384f2303a70b7345b3e08a8b2133e49'
SOURCE_SHA = '1be970356c655bcef3688ddf1d129d5029bbc533'
MAC_RESERVE = 2415919104
MAX_ARCHIVE = 4294967296
PROTECTED = (
    SOURCE,
    SOURCE / 'Dependencies/Middleware',
    SOURCE / 'Dependencies/Hanlin',
    ROOT.parent / 'SDK-Wave3-1be97035-Debug-FreshAfterFiveScopes-20261127-Evidence',
    ROOT.parent / 'SDK-Wave3-1be97035-NativeABI-FreshAfterFiveScopes-20261127',
    Path('/Users/m1/builds/otzaria-shared-agent1-20261126/anytype-formal-original-swift-abi-9bc6420f/source'),
)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def capacity(extra=0):
    free = shutil.disk_usage('/System/Volumes/Data').free
    assert free - extra >= MAC_RESERVE, ('Mac reserve', free, extra)
    return free

def save(path, value):
    data = value if isinstance(value, bytes) else canonical(value)
    capacity(len(data))
    with path.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def source_state():
    g = ['/usr/bin/git', '--no-optional-locks', '-C', str(SOURCE)]
    return {'head': subprocess.check_output(g + ['rev-parse', 'HEAD'], text=True).strip(),
            'tracked_status': subprocess.check_output(g + ['status', '--porcelain=v1', '--untracked-files=no'], text=True)}

def boundary():
    assert ROOT.resolve() == ROOT and not ROOT.is_symlink()
    s = ROOT.lstat()
    assert stat.S_ISDIR(s.st_mode) and s.st_uid == os.getuid() and s.st_ino == 73167243
    assert source_state() == {'head': SOURCE_SHA, 'tracked_status': ''}
    values = []
    for p in PROTECTED:
        assert p.resolve() == p and not p.is_symlink() and p != ROOT and ROOT not in p.parents
        info = p.lstat()
        assert stat.S_ISDIR(info.st_mode)
        values.append({'path': str(p), 'device': info.st_dev, 'inode': info.st_ino,
                       'uid': info.st_uid, 'gid': info.st_gid, 'mode': info.st_mode})
    return {'root': {'device': s.st_dev, 'inode': s.st_ino, 'uid': s.st_uid,
                     'gid': s.st_gid, 'mode': s.st_mode}, 'source': source_state(), 'protected': values}

def walk():
    root = ROOT.lstat()
    pending = [ROOT]
    while pending:
        p = pending.pop()
        s = p.lstat()
        assert s.st_dev == root.st_dev
        assert stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode) or stat.S_ISLNK(s.st_mode), str(p)
        yield p, s
        if stat.S_ISDIR(s.st_mode):
            with os.scandir(p) as it:
                pending.extend(sorted((Path(x.path) for x in it), key=os.fsencode, reverse=True))

def no_use():
    p = subprocess.Popen(['/usr/sbin/lsof', '-nP', '-Fpcfn'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    pid = command = fd = None
    found = []
    for line in p.stdout:
        line = line.rstrip('\n')
        if line.startswith('p'):
            pid = line[1:]
        elif line.startswith('c'):
            command = line[1:]
        elif line.startswith('f'):
            fd = line[1:]
        elif line.startswith('n') and (line[1:] == str(ROOT) or line[1:].startswith(str(ROOT) + '/')):
            found.append({'pid': pid, 'command': command, 'fd': fd, 'path': line[1:]})
    errors = p.stderr.read()
    code = p.wait(timeout=15)
    assert code in (0, 1)
    ps = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,lstart=,comm=,args='], text=True)
    references = [line for line in ps.splitlines() if str(ROOT) in line
                  and int(line.split()[0]) not in (os.getpid(), os.getppid())]
    value = {'utc': utc(), 'open_paths': found, 'process_references': references,
             'lsof_exit': code, 'lsof_stderr': errors}
    assert not found and not references, value
    return value

def helpers():
    assert digest(FIVE / 'HEADER.json') == FIVE_HEADER_SHA
    assert digest(FIVE / 'COMPLETE_PRESERVATION_VERIFIED.json') == FIVE_PROOF_SHA
    header = json.loads((FIVE / 'HEADER.json').read_bytes())
    code = (FIVE / 'five_scope.py').read_bytes()
    assert hashlib.sha256(code).hexdigest() == header['script_sha256']
    mod = types.ModuleType('pinned_original_metadata_and_reference_helpers')
    mod.__file__ = str(FIVE / 'five_scope.py')
    exec(compile(code, mod.__file__, 'exec'), mod.__dict__)
    h = mod.helper()
    return mod, h, header

def reference_index(mod, h, five):
    index, pins = mod.payload_index(h)
    meta = next(x for x in five['metadata'] if x['name'] == 'new-payloads.jsonl.gz')
    p = FIVE / meta['name']
    assert digest(p) == meta['sha256']
    proof = json.loads((FIVE / 'COMPLETE_PRESERVATION_VERIFIED.json').read_bytes())
    assert proof['header_sha256'] == FIVE_HEADER_SHA and proof['new_archive_sha256'] == FIVE_ARCHIVE_SHA
    count = total = 0
    sha = hashlib.sha256()
    with gzip.open(p, 'rb') as f:
        for line in f:
            row = json.loads(line)
            count += 1
            total += len(line)
            sha.update(line)
            index.setdefault((bytes.fromhex(row['sha256']), row['bytes']),
                             ('five-scope-differential', row['member'], FIVE_ARCHIVE_SHA))
    assert count == 103 and total == meta['uncompressed_bytes'] and sha.hexdigest() == meta['uncompressed_sha256']
    pins.append({'id': 'five-scope-differential', 'manifest': str(p), 'manifest_sha256': meta['sha256'],
                 'manifest_format': 'gzip-json-lines-physical-new-payloads', 'counts': {'new_payloads': count},
                 'archive': proof['new_archive'], 'archive_bytes': proof['new_archive_bytes'],
                 'archive_sha256': FIVE_ARCHIVE_SHA, 'source_header_sha256': FIVE_HEADER_SHA,
                 'complete_preservation_sha256': FIVE_PROOF_SHA,
                 'full_member_verification_sha256': proof['new_archive_verification_sha256']})
    return index, pins

def process_identity():
    return {'pid': os.getpid(), 'ppid': os.getppid(), 'pgid': os.getpgid(0),
            'lstart': subprocess.check_output(['/bin/ps', '-p', str(os.getpid()), '-o', 'lstart='], text=True).strip(),
            'command': subprocess.check_output(['/bin/ps', '-p', str(os.getpid()), '-o', 'command='], text=True).strip(),
            'script_sha256': digest(Path(__file__)), 'utc': utc()}

def inventory():
    started = time.monotonic()
    before = boundary()
    free = capacity()
    assert digest(PLAN) == PLAN_SHA
    plan = json.loads(PLAN.read_bytes())
    assert plan['root'] == str(ROOT) and plan['source'] == before['source']
    assert plan['status'] == 'FULL_OWNED_FAILED_WORK_CONTENT_COMPARISON_ONLY'
    mod, h, five = helpers()
    old, pins = reference_index(mod, h, five)
    evidence = Path(tempfile.mkdtemp(prefix='otzaria-wave3-ad6-preservation-20261127.', dir='/Users/m1/builds'))
    save(evidence / 'ad6_preservation.py', Path(__file__).read_bytes())
    save(evidence / 'READ_ONLY_PLAN.json.gz', gzip.compress(PLAN.read_bytes(), mtime=0))
    save(evidence / 'INVENTORY_OWNER.json', process_identity())
    use_before = no_use()
    unique = set()
    total_new = 0
    stat_hash = hashlib.sha256()
    content_hash = hashlib.sha256()
    entry_hash = hashlib.sha256()
    payload_hash = hashlib.sha256()
    entry_bytes = payload_bytes = 0
    summary = {'root': str(ROOT), 'entries': 0, 'files': 0, 'directories': 0, 'symlinks': 0,
               'logical_bytes': 0, 'kernel_private_bytes': 0, 'hardlinked_files': 0,
               'covered_files': 0, 'covered_bytes': 0, 'xattr_entries': 0, 'acl_entries': 0}
    dependencies = []
    h.ROOT = ROOT
    eraw_path = evidence / 'entries.jsonl.gz'
    praw_path = evidence / 'new-payloads.jsonl.gz'
    with eraw_path.open('xb') as eraw, praw_path.open('xb') as praw:
        with gzip.GzipFile(fileobj=eraw, mode='wb', mtime=0) as entries, gzip.GzipFile(fileobj=praw, mode='wb', mtime=0) as payloads:
            for p, s in walk():
                rel = p.relative_to(ROOT).as_posix()
                stat_hash.update(canonical({'path': rel, 'identity': h.identity(s)}))
                row = h.entry((p, s))
                row['path'] = rel
                summary['entries'] += 1
                summary['xattr_entries'] += bool(row['xattrs'])
                summary['acl_entries'] += row['acl'] is not None
                if row['type'] == 'file':
                    summary['files'] += 1
                    summary['logical_bytes'] += row['bytes']
                    content_hash.update(canonical({'path': rel, 'bytes': row['bytes'], 'sha256': row['sha256']}))
                    allocation = mod.private_size(h, p)
                    row['allocation_observation'] = allocation
                    if row['nlink'] == 1:
                        summary['kernel_private_bytes'] += allocation['private_bytes']
                    else:
                        summary['hardlinked_files'] += 1
                    key = (bytes.fromhex(row['sha256']), row['bytes'])
                    if key in old:
                        aid, member, archive_sha = old[key]
                        row['payload'] = {'kind': 'prior_member', 'archive_id': aid,
                                          'archive_sha256': archive_sha, 'member': member}
                        summary['covered_files'] += 1
                        summary['covered_bytes'] += row['bytes']
                    else:
                        member = 'objects/sha256/' + row['sha256']
                        row['payload'] = {'kind': 'new_member', 'member': member}
                        if key not in unique:
                            unique.add(key)
                            total_new += row['bytes']
                            payload = {'member': member, 'source_path': rel, 'bytes': row['bytes'],
                                       'sha256': row['sha256'], 'stat_identity': h.identity(s)}
                            b = canonical(payload)
                            payloads.write(b)
                            payload_hash.update(b)
                            payload_bytes += len(b)
                    if (p.name == 'alternates' and p.parent.name == 'info' and p.parent.parent.name == 'objects') or p.name == '.git':
                        assert row['bytes'] <= 65536
                        text = p.read_text()
                        for line in text.splitlines():
                            target = line.removeprefix('gitdir: ')
                            destination = Path(target) if os.path.isabs(target) else p.parent / target
                            resolved = destination.resolve(strict=False)
                            dependencies.append({'path': rel, 'kind': 'git_metadata', 'target': target,
                                                 'resolved': str(resolved), 'exists': resolved.exists(),
                                                 'internal': resolved == ROOT or ROOT in resolved.parents,
                                                 'bytes': row['bytes'], 'sha256': row['sha256']})
                elif row['type'] == 'directory':
                    summary['directories'] += 1
                else:
                    summary['symlinks'] += 1
                    resolved = p.resolve(strict=False)
                    dependencies.append({'path': rel, 'kind': 'symlink', 'target': row['target'],
                                         'resolved': str(resolved), 'exists': resolved.exists(),
                                         'internal': resolved == ROOT or ROOT in resolved.parents})
                b = canonical(row)
                entries.write(b)
                entry_hash.update(b)
                entry_bytes += len(b)
                if summary['entries'] % 1024 == 0:
                    capacity()
        eraw.flush()
        praw.flush()
        os.fsync(eraw.fileno())
        os.fsync(praw.fileno())
    assert summary['entries'] == 136409 and summary['files'] == 117206
    assert summary['logical_bytes'] == 11451441643
    assert summary['covered_files'] == 84673 and summary['covered_bytes'] == 7518295098
    assert len(unique) == 31355 and total_new == 3770386133
    assert stat_hash.hexdigest() == plan['path_stat_sha256']
    assert content_hash.hexdigest() == plan['regular_content_sha256']
    fresh_stat = hashlib.sha256()
    for p, s in walk():
        fresh_stat.update(canonical({'path': p.relative_to(ROOT).as_posix(), 'identity': h.identity(s)}))
    assert fresh_stat.digest() == stat_hash.digest()
    assert boundary() == before
    use_after = no_use()
    metadata = []
    for path, raw_sha, raw_bytes in ((eraw_path, entry_hash.hexdigest(), entry_bytes),
                                    (praw_path, payload_hash.hexdigest(), payload_bytes)):
        metadata.append({'name': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path),
                         'uncompressed_bytes': raw_bytes, 'uncompressed_sha256': raw_sha})
    original = ROOT.parent / 'SDK-Wave3-1be97035-Debug-FreshAfterFiveScopes-20261127-Evidence/execution.json'
    assert digest(original) == '7abea9cc589e87e3034bf1c54aa286c5c3b631a0ca74fc80e15dbda49cc94a93'
    execution = json.loads(original.read_bytes())
    probe = subprocess.run(['/usr/bin/git', '--no-optional-locks', '-C', str(SOURCE), 'grep', '-n', '-F',
                            str(ROOT), '--', 'Tools/OriginalEditor', 'Tools/Hanlin', '.github'],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    assert probe.returncode in (0, 1)
    header = {'schema': 'otzaria.failed-ad6-complete-preservation/1', 'utc': utc(), 'evidence': str(evidence),
              'status': 'FULL_METADATA_AND_CONTENT_INVENTORIED_NOT_ARCHIVED_NOT_RETIRED',
              'root': str(ROOT), 'boundary': before, 'script_sha256': digest(Path(__file__)),
              'metadata_helper_sha256': five['helper_sha256'], 'reference_helper_sha256': five['script_sha256'],
              'read_only_plan_sha256': PLAN_SHA, 'base_archives': pins, 'summary': summary,
              'metadata': metadata, 'path_stat_sha256': stat_hash.hexdigest(),
              'regular_content_sha256': content_hash.hexdigest(),
              'new_unique_payloads': len(unique), 'new_unique_raw_bytes': total_new,
              'open_use_before': use_before, 'open_use_after': use_after,
              'dependency_records': dependencies,
              'source_controller_reference_probe': {'exit': probe.returncode, 'stdout': probe.stdout, 'stderr': probe.stderr},
              'original_execution': {'path': str(original), 'sha256': digest(original),
                                     'status': execution['status'], 'phase': execution['phase'],
                                     'external_consumer_build': execution['external_consumer_build']},
              'external_referrers_exhaustively_excluded': False,
              'free_before': free, 'free_after': capacity(),
              'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              'seconds': time.monotonic() - started, 'anything_deleted': False,
              'retirement_authorized': False, 'native_acceptance': 0, 'new_sdk_qualification': False,
              'metadata_scope': 'All original type/path/mode/uid/gid/timestamps/flags/hardlink/symlink/ACL/xattr records retained. Historical inode/device/ctime are evidence; no restored filesystem is falsely claimed.'}
    receipt = save(evidence / 'HEADER.json', header)
    print(json.dumps({'status': header['status'], 'evidence': str(evidence),
                      'header_sha256': receipt['sha256'], 'header_bytes': receipt['bytes'],
                      'summary': summary, 'new_unique_payloads': len(unique),
                      'new_unique_raw_bytes': total_new, 'metadata': metadata,
                      'dependencies': {'records': len(dependencies),
                                       'outside': sum(not x['internal'] for x in dependencies)},
                      'free_after': header['free_after'], 'seconds': header['seconds']}))

class HashingReader:
    def __init__(self, f):
        self.f, self.sha, self.count = f, hashlib.sha256(), 0
    def read(self, size=-1):
        b = self.f.read(size)
        self.sha.update(b)
        self.count += len(b)
        return b

class HashingWriter:
    def __init__(self, f):
        self.f, self.sha, self.count = f, hashlib.sha256(), 0
    def write(self, b):
        assert self.count + len(b) <= MAX_ARCHIVE, 'Own archive output cap reached'
        self.f.write(b)
        self.sha.update(b)
        self.count += len(b)
        return len(b)
    def flush(self):
        self.f.flush()

def load_header(evidence, expected):
    assert evidence.parent == Path('/Users/m1/builds') and evidence.name.startswith('otzaria-wave3-ad6-preservation-20261127.')
    assert digest(evidence / 'HEADER.json') == expected
    header = json.loads((evidence / 'HEADER.json').read_bytes())
    assert header['root'] == str(ROOT) and header['script_sha256'] == digest(Path(__file__))
    assert header['boundary'] == boundary()
    for row in header['metadata']:
        p = evidence / row['name']
        assert p.stat().st_size == row['bytes'] and digest(p) == row['sha256']
    return header

def stream(evidence, expected):
    started = time.monotonic()
    header = load_header(evidence, expected)
    mod, h, five = helpers()
    before_use = no_use()
    owner = process_identity()
    save(evidence / 'STREAM_OWNER.json', owner)
    free = capacity()
    writer = HashingWriter(sys.stdout.buffer)
    count = total = 0
    try:
        with gzip.GzipFile(fileobj=writer, mode='wb', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for name in ('HEADER.json', 'entries.jsonl.gz', 'new-payloads.jsonl.gz',
                             'ad6_preservation.py', 'READ_ONLY_PLAN.json.gz', 'INVENTORY_OWNER.json', 'STREAM_OWNER.json'):
                    p = evidence / name
                    with p.open('rb') as f:
                        info = tarfile.TarInfo(name)
                        info.size = p.stat().st_size
                        info.mode = 0o600
                        tar.addfile(info, f)
                with gzip.open(evidence / 'new-payloads.jsonl.gz', 'rb') as payloads:
                    for line in payloads:
                        row = json.loads(line)
                        p = ROOT / row['source_path']
                        assert ROOT in p.parents and p.resolve() == p and not p.is_symlink()
                        s = p.lstat()
                        assert list(h.identity(s)) == row['stat_identity']
                        fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
                        with os.fdopen(fd, 'rb') as f:
                            assert h.identity(os.fstat(f.fileno())) == h.identity(s)
                            reader = HashingReader(f)
                            info = tarfile.TarInfo(row['member'])
                            info.size = row['bytes']
                            info.mode = 0o600
                            tar.addfile(info, reader)
                            assert reader.count == row['bytes'] and reader.sha.hexdigest() == row['sha256']
                            assert h.identity(os.fstat(f.fileno())) == h.identity(s)
                        assert h.identity(p.lstat()) == h.identity(s)
                        count += 1
                        total += row['bytes']
                        capacity()
        writer.flush()
        assert count == header['new_unique_payloads'] and total == header['new_unique_raw_bytes']
        assert boundary() == header['boundary']
        after_use = no_use()
        save(evidence / 'STREAM_RESULT.json', {'status': 'FAILED_AD6_DIFFERENTIAL_STREAMED_NOT_RETIRED',
             'utc': utc(), 'evidence': str(evidence), 'header_sha256': expected,
             'archive_bytes': writer.count, 'archive_sha256': writer.sha.hexdigest(),
             'new_payloads': count, 'new_payload_bytes': total,
             'open_use_before': before_use, 'open_use_after': after_use,
             'free_before': free, 'free_after': capacity(), 'seconds': time.monotonic() - started,
             'owner': owner, 'anything_deleted': False, 'sdk_qualification': False})
    except BaseException as error:
        save(evidence / 'STREAM_FAILURE.json', {'utc': utc(), 'owner': owner,
             'error': repr(error), 'bytes_written': writer.count, 'payloads_completed': count,
             'anything_deleted': False, 'sdk_qualification': False})
        raise

if __name__ == '__main__':
    if sys.argv[1:] == ['inventory']:
        inventory()
    elif len(sys.argv) == 4 and sys.argv[1] == 'stream':
        stream(Path(sys.argv[2]), sys.argv[3])
    else:
        raise SystemExit('Only inventory or stream of the fixed failed Work is supported.')
