#!/usr/bin/env python3
"""Fresh archive bindings and durable two-host ACK for the one authorized ad6 root."""
from pathlib import Path
import base64
import datetime
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import threading

ROOT = Path(r'C:\Users\DAVID\.codex\artifacts\otzaria-wave3-ad6-preservation-20261127')
MAC = '/Users/m1/builds/otzaria-wave3-ad6-preservation-20261127.n155e60d'
ORACLE = '/mnt/development/projects/diagnostics/otzaria-wave3-ad6-retirement-20261127'
SOURCE_ROOT = '/Users/m1/builds/otzaria-wave1-sdk-20261127/source/build/SDK-Wave3-1be97035-Debug-FreshAfterFiveScopes-20261127-Work'
PROOF_SHA = 'b93cf1bca06300066702c0d588cd14efe166e753f11f3d4fbca18e79a0d0ac68'
SOURCE_SHA = '41f3afac682426e9de31cfcb1029672817f1411819d6606d58f2f66af281bdee'
NEW_VERIFIED_SHA = '591e5599d05619b28427a9b9b7af43e50cfe751a281ce6930817e57abb0ad85c'
MAC_SCRIPT_SHA = '3ddb2ec671175c46226fa09fcfd2dea2808e4b4ef20f43710b4c079779f0b3b4'
RESERVE = 2415919104
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8']


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()


def identity(path):
    assert not path.is_symlink()
    s = path.stat()
    return {'device': s.st_dev, 'inode': s.st_ino, 'bytes': s.st_size,
            'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}


def save(name, raw):
    if not isinstance(raw, bytes):
        raw = canonical(raw)
    assert shutil.disk_usage(ROOT).free - len(raw) >= RESERVE
    path = ROOT / name
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    assert path.read_bytes() == raw
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def oracle_current(bindings):
    code = '''from pathlib import Path
import sys,json,hashlib,shutil,datetime
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ident(p):
 assert p.resolve()==p and not p.is_symlink()
 s=p.stat();return {'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
rows=json.loads(sys.stdin.buffer.read())
for r in rows:
 assert ident(Path(r['archive']))==r['archive_identity']
 assert ident(Path(r['new_payload_manifest']))==r['new_payload_manifest_identity']
 assert digest(Path(r['new_payload_manifest']))==r['new_payload_manifest_sha256']
 assert digest(Path(r['full_member_receipt']))==r['full_member_receipt_sha256']
 assert digest(Path(r['header']))==r['header_sha256']
free=shutil.disk_usage('/mnt/development/projects/diagnostics').free
assert free>=687865856+1048576
print(json.dumps({'status':'BOTH_ORACLE_ARCHIVES_AND_METADATA_IDENTITIES_UNCHANGED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':rows,'free':free,'writes':0}))
'''
    result = subprocess.run(SSH + ['torah-social', '/usr/bin/python3 -c ' + shlex.quote(code)],
                            input=canonical(bindings), capture_output=True, timeout=30)
    save('RETIREMENT_ORACLE_CURRENT.stdout.json', result.stdout)
    save('RETIREMENT_ORACLE_CURRENT.stderr.log', result.stderr)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    return json.loads(result.stdout)


def oracle_receipt(name, raw):
    assert name in ('RETIREMENT_PREDELETE.json', 'RETIREMENT_RESULT.json')
    expected = hashlib.sha256(raw).hexdigest()
    code = '''from pathlib import Path
import sys,hashlib,shutil,os,json
p=Path(DESTINATION);b=sys.stdin.buffer.read(1024*1024)
assert hashlib.sha256(b).hexdigest()==EXPECTED
assert shutil.disk_usage(p.parent.parent).free-len(b)>=687865856
if p.name=='RETIREMENT_PREDELETE.json':p.parent.mkdir(exist_ok=False)
assert p.parent.is_dir() and not p.parent.is_symlink()
with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
try:os.fsync(fd)
finally:os.close(fd)
assert p.read_bytes()==b
print(json.dumps({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'file_and_directory_fsynced':True}))
'''
    code = 'DESTINATION=' + repr(ORACLE + '/' + name) + '\nEXPECTED=' + repr(expected) + '\n' + code
    result = subprocess.run(SSH + ['torah-social', '/usr/bin/python3 -c ' + shlex.quote(code)],
                            input=raw, capture_output=True, timeout=30)
    save(name + '.oracle-copy.stdout.json', result.stdout)
    save(name + '.oracle-copy.stderr.log', result.stderr)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    receipt = json.loads(result.stdout)
    assert receipt['sha256'] == expected and receipt['bytes'] == len(raw)
    return receipt


def main():
    proof_raw = (ROOT / 'COMPLETE_PRESERVATION_VERIFIED.json').read_bytes()
    source_raw = (ROOT / 'SOURCE_REVERIFIED.json').read_bytes()
    assert hashlib.sha256(proof_raw).hexdigest() == PROOF_SHA
    assert hashlib.sha256(source_raw).hexdigest() == SOURCE_SHA
    proof, source = json.loads(proof_raw), json.loads(source_raw)
    assert proof['root'] == source['root'] == SOURCE_ROOT
    new_raw = (ROOT / 'NEW_ARCHIVE_VERIFIED.json').read_bytes()
    assert hashlib.sha256(new_raw).hexdigest() == NEW_VERIFIED_SHA
    new = json.loads(new_raw)
    assert new['archive_identity'] == proof['new_archive_identity']
    assert identity(Path(proof['new_archive'])) == proof['new_archive_identity']
    assert new['new_archive_sha256'] == proof['new_archive_sha256']
    assert new['new_archive_bytes'] == proof['new_archive_bytes']
    for row in proof['archive_bindings']:
        if row['id'] in ('session-pair-differential', 'five-scope-differential'):
            continue
        assert identity(Path(row['archive'])) == row['archive_identity']
        assert identity(Path(row['manifest'])) == row['manifest_identity']
        assert digest(Path(row['manifest'])) == row['manifest_sha256']
        assert digest(Path(row['full_member_receipt'])) == row['full_member_receipt_sha256']
    oracle = oracle_current([row for row in proof['archive_bindings']
                             if row['id'] in ('session-pair-differential', 'five-scope-differential')])
    current = {'status': 'ALL_CURRENT_AD6_ARCHIVE_AND_RECEIPT_IDENTITIES_MATCH', 'utc': utc(),
               'root': SOURCE_ROOT, 'complete_preservation_sha256': PROOF_SHA,
               'source_reverified_sha256': SOURCE_SHA, 'new_archive_verification_sha256': NEW_VERIFIED_SHA,
               'new_archive': proof['new_archive'], 'new_archive_bytes': proof['new_archive_bytes'],
               'new_archive_sha256': proof['new_archive_sha256'], 'new_archive_identity': proof['new_archive_identity'],
               'archive_bindings': proof['archive_bindings'], 'oracle_identity_receipt_sha256': hashlib.sha256(canonical(oracle)).hexdigest(),
               'windows_driver_sha256': digest(Path(__file__)),
               'scope': 'Every current physical archive identity matches its freshly hashed immutable archive proof; manifests and member receipts were rehashed. Whole archives were not needlessly reread.',
               'anything_deleted': False}
    current_raw = canonical(current)
    current_pin = save('RETIREMENT_CURRENT_BINDINGS.json', current_raw)
    check = 'from pathlib import Path;import hashlib;p=Path(' + repr(MAC + '/retire_ad6.py') + ');assert hashlib.sha256(p.read_bytes()).hexdigest()==' + repr(MAC_SCRIPT_SHA)
    checked = subprocess.run(SSH + ['scaleway-mac', '/usr/bin/python3 -c ' + shlex.quote(check)], capture_output=True, timeout=30)
    save('RETIREMENT_SCRIPT_READBACK.stdout.log', checked.stdout)
    save('RETIREMENT_SCRIPT_READBACK.stderr.log', checked.stderr)
    assert checked.returncode == 0, checked.stderr.decode(errors='replace')
    envelope = {'proof_base64': base64.b64encode(proof_raw).decode(),
                'source_base64': base64.b64encode(source_raw).decode(),
                'current_base64': base64.b64encode(current_raw).decode(),
                'current_sha256': current_pin['sha256'], 'retirement_script_sha256': MAC_SCRIPT_SHA}
    process = subprocess.Popen(SSH + ['scaleway-mac', '/usr/bin/python3 -B ' + shlex.quote(MAC + '/retire_ad6.py')],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    save('RETIREMENT_BRIDGE_OWNER.json', {'utc': utc(), 'pid': os.getpid(), 'ssh_pid': process.pid,
                                         'script_sha256': digest(Path(__file__)), 'root': SOURCE_ROOT})
    errors = []
    def drain():
        for block in iter(lambda: process.stderr.read(65536), b''):
            errors.append(block)
    thread = threading.Thread(target=drain, daemon=True)
    thread.start()
    process.stdin.write(canonical(envelope))
    process.stdin.flush()
    first = process.stdout.readline(1024**2)
    if not first:
        process.stdin.close()
        code = process.wait(timeout=30)
        thread.join(30)
        failure = {'status': 'MAC_AD6_PREDELETE_CHECK_FAILED_WITHOUT_ACK', 'utc': utc(), 'exit': code,
                   'stderr': b''.join(errors).decode(errors='replace'), 'anything_deleted': False}
        save('RETIREMENT_PREDELETE_FAILURE.json', failure)
        raise RuntimeError(failure)
    try:
        pre = json.loads(first)
        assert pre['status'] == 'EXACT_AD6_CURRENT_STATE_VERIFIED_AWAITING_DURABLE_OFFHOST_ACK'
        assert pre['root'] == SOURCE_ROOT and not pre['anything_deleted']
        assert pre['complete_preservation_sha256'] == PROOF_SHA and pre['source_reverified_sha256'] == SOURCE_SHA
        assert pre['current_archive_bindings_sha256'] == current_pin['sha256']
        assert pre['script_sha256'] == MAC_SCRIPT_SHA
        pin = save('RETIREMENT_PREDELETE.json', first)
        oracle_pre = oracle_receipt('RETIREMENT_PREDELETE.json', first)
        ack = {'ack': 'DURABLE_OFFHOST_EXACT_AD6_PREDELETE', 'sha256': pin['sha256'],
               'complete_preservation_sha256': PROOF_SHA, 'source_reverified_sha256': SOURCE_SHA,
               'current_archive_bindings_sha256': current_pin['sha256']}
        save('RETIREMENT_ACK.json', ack)
    except BaseException:
        process.stdin.close()
        code = process.wait(timeout=100)
        thread.join(30)
        save('RETIREMENT_OFFHOST_ACK_ABORT.stderr.log', b''.join(errors))
        raise
    process.stdin.write(canonical(ack))
    process.stdin.flush()
    process.stdin.close()
    print(json.dumps({'status': 'EXACT_AD6_PREDELETE_DURABLE_ON_WINDOWS_AND_ORACLE_ACK_SENT',
                      'predelete': pin, 'oracle_predelete': oracle_pre, 'mac_owner': pre['owner_process']}), flush=True)
    final_raw = process.stdout.read()
    code = process.wait(timeout=60)
    thread.join(30)
    save('RETIREMENT_STDERR.log', b''.join(errors))
    final_pin = save('RETIREMENT_RESULT.json', final_raw)
    oracle_final = oracle_receipt('RETIREMENT_RESULT.json', final_raw)
    result = json.loads(final_raw)
    assert code == 0 and result['status'] == 'RETIRED_ONLY_EXACT_FULLY_PRESERVED_AD6_WORK'
    assert result['removed'] == [SOURCE_ROOT] and result['full_absence_verified']
    assert result['protected_identities_unchanged']
    print(json.dumps({'status': result['status'], 'removed': result['removed'], 'receipt': final_pin,
                      'predelete': pin, 'oracle_receipt': oracle_final,
                      'free_before': result['free_before'], 'free_after': result['free_after'],
                      'concurrent_free_delta_bytes': result['concurrent_free_delta_bytes'],
                      'protected_identities_unchanged': True, 'full_absence_verified': True,
                      'native_acceptance': 0, 'sdk_retry': False}), flush=True)


if __name__ == '__main__':
    main()
