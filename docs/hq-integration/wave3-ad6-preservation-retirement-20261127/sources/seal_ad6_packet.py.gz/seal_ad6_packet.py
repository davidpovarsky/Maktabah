#!/usr/bin/env python3
"""Seal small byte-exact evidence for the completed authorized ad6 preservation."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import os
import shutil
import tarfile

ROOT = Path(r'C:\Users\DAVID\.codex\artifacts\otzaria-wave3-ad6-preservation-20261127')
OUT = ROOT / 'git-packet'
RESERVE = 2415919104


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


pins = {
    'COMPLETE_PRESERVATION_VERIFIED.json': 'b93cf1bca06300066702c0d588cd14efe166e753f11f3d4fbca18e79a0d0ac68',
    'SOURCE_REVERIFIED.json': '41f3afac682426e9de31cfcb1029672817f1411819d6606d58f2f66af281bdee',
    'NEW_ARCHIVE_VERIFIED.json': '591e5599d05619b28427a9b9b7af43e50cfe751a281ce6930817e57abb0ad85c',
    'PRIOR_MEMBERS_VERIFIED.json': '1cd29c0a43acfbfb0a61e0fc3dad87da97c1630d51b5ede3ec285793111c45ac',
    'RETIREMENT_PREDELETE.json': '9ac5aa0191106212f7406546171fb2b54ede51450a1972fb453f98c30f9b0624',
    'RETIREMENT_RESULT.json': '45556d5e873441983cc819beb46f04f5feb300f35363d5f5e1b34d5e79c13d4f',
    'TRANSFER_RESULT.json': '837d38fe6c45f6c8b54ae29d90faa1e30c883126dcd144a17edbda49a9093213',
    'prior-windows/PRIOR_WINDOWS_ARCHIVES_VERIFIED.json': 'df5fdcf1d3754457eac738b25200a6bec6b0d6e407a2f89c7c7486a8531dc1bf',
    'PRIOR_ORACLE_ARCHIVES_VERIFIED.json': '63aa34d7b5e1923cdb463f0b756987c9c31498a85d609eedfdf27f43b0023f25',
    'metadata/HEADER.json': '0eda5768bd4ef592a41b2ad278b3ebd6ffb18b26e7f7c0b38bb63d220d8ec21f',
    'metadata/ad6_preservation.py': '9bb4e8dc5ddf3661860bbc5b71245d1227c04561a2bf25cced727e7b38132f4d',
    'receive_ad6_archive.py': 'f518336f2574631b0896b34d4b5c805422d8458267a7af94b35c28970cf71c90',
    'verify_ad6_archive.py': '571d79617dc1a468aa8d36fbf33c6b471981cc504e205008ad73e824c782f7fb',
    'verify_ad6_prior_members.py': 'bd0192214c2f9d8a3fe96037367bc79bf7d3c86523b2a57f6afada434c007116',
    'reverify_ad6_source.py': 'dd794069f00c786d0c1f0dbe4820f6ac0a7fbd3985f7e25996cf30abe1907eb4',
    'retire_ad6.py': '3ddb2ec671175c46226fa09fcfd2dea2808e4b4ef20f43710b4c079779f0b3b4',
    'retire_ad6_windows.py': '8aa58490d8def72e450157b175f25fd5729c7d4e4bfa71c1db85d36442f4a7f4',
}
for name, pin in pins.items():
    assert sha((ROOT / name).read_bytes()) == pin, name
proof = json.loads((ROOT / 'COMPLETE_PRESERVATION_VERIFIED.json').read_bytes())
source = json.loads((ROOT / 'SOURCE_REVERIFIED.json').read_bytes())
result = json.loads((ROOT / 'RETIREMENT_RESULT.json').read_bytes())
assert result['status'] == 'RETIRED_ONLY_EXACT_FULLY_PRESERVED_AD6_WORK'
assert result['root'] == proof['root'] == source['root']
assert result['removed'] == [proof['root']] and result['full_absence_verified']
assert result['protected_outside_before'] == result['protected_outside_after']
assert result['protected_files_before'] == result['protected_files_after']
assert result['predelete_receipt_sha256'] == pins['RETIREMENT_PREDELETE.json']
assert shutil.disk_usage(ROOT).free > RESERVE + 10485760
assert not OUT.exists()
OUT.mkdir()
rows = []


def put(destination, original, compress=False, already_gzip=False):
    raw = (ROOT / original).read_bytes()
    body = gzip.compress(raw, mtime=0) if compress else raw
    p = OUT / destination
    p.parent.mkdir(exist_ok=True, parents=True)
    assert shutil.disk_usage(ROOT).free - len(body) >= RESERVE
    with p.open('xb') as f:
        f.write(body)
        f.flush()
        os.fsync(f.fileno())
    assert p.read_bytes() == body
    row = {'path': destination, 'bytes': len(body), 'sha256': sha(body), 'source': str(ROOT / original)}
    if compress or already_gzip:
        unpacked = gzip.decompress(body)
        assert unpacked == (raw if compress else gzip.decompress(raw))
        row.update({'uncompressed_bytes': len(unpacked), 'uncompressed_sha256': sha(unpacked),
                    'lossless_original_bytes': True})
    rows.append(row)


for name in ('README.md', 'COMPLETE_PRESERVATION_VERIFIED.json', 'SOURCE_REVERIFIED.json',
             'NEW_ARCHIVE_VERIFIED.json', 'PRIOR_MEMBERS_VERIFIED.json', 'TRANSFER_RESULT.json',
             'PRIOR_ORACLE_ARCHIVES_VERIFIED.json', 'RETIREMENT_CURRENT_BINDINGS.json',
             'RETIREMENT_PREDELETE.json', 'RETIREMENT_ACK.json', 'RETIREMENT_RESULT.json',
             'RETIREMENT_CONTROLS_STAGED.json', 'RETIREMENT_BRIDGE_OWNER.json', 'RECEIVER_OWNER.json',
             'MAC_STREAM_OWNER.json', 'MAC_STREAM_RESULT.json'):
    put(name, name)
put('PRIOR_WINDOWS_ARCHIVES_VERIFIED.json', 'prior-windows/PRIOR_WINDOWS_ARCHIVES_VERIFIED.json')
put('INVENTORY_OWNER.json', 'metadata/INVENTORY_OWNER.json')
put('HEADER.json.gz', 'metadata/HEADER.json', compress=True)
put('READ_ONLY_PLAN.json.gz', 'metadata/READ_ONLY_PLAN.json.gz', already_gzip=True)
scripts = [('ad6_preservation.py', 'metadata/ad6_preservation.py')]
scripts += [(name, name) for name in ('receive_ad6_archive.py', 'verify_ad6_archive.py',
            'verify_ad6_prior_members.py', 'verify_oracle_required_members.py', 'reverify_ad6_source.py',
            'retire_ad6.py', 'retire_ad6_windows.py', 'seal_ad6_packet.py')]
for destination, original in scripts:
    put('sources/' + destination + '.gz', original, compress=True)
for name in ('verify_ad6_archive.py.stdout.json', 'verify_ad6_archive.py.stderr.log',
             'verify_ad6_prior_members.py.stdout.json', 'verify_ad6_prior_members.py.stderr.log',
             'SOURCE_REVERIFY.stdout.json', 'SOURCE_REVERIFY.stderr.log', 'STREAM.stderr.log',
             'PRIOR_ORACLE_REQUIRED.stdout.json', 'PRIOR_ORACLE_REQUIRED.stderr.log',
             'RETIREMENT_ORACLE_CURRENT.stdout.json', 'RETIREMENT_ORACLE_CURRENT.stderr.log',
             'RETIREMENT_PREDELETE.json.oracle-copy.stdout.json', 'RETIREMENT_PREDELETE.json.oracle-copy.stderr.log',
             'RETIREMENT_RESULT.json.oracle-copy.stdout.json', 'RETIREMENT_RESULT.json.oracle-copy.stderr.log',
             'RETIREMENT_SCRIPT_READBACK.stdout.log', 'RETIREMENT_SCRIPT_READBACK.stderr.log', 'RETIREMENT_STDERR.log'):
    put('raw/' + name + '.gz', name, compress=True)

index = {'schema': 'otzaria.failed-ad6-preservation-retirement-packet/1',
         'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'root': proof['root'], 'original_sdk_source': '1be970356c655bcef3688ddf1d129d5029bbc533',
         'original_failure_packet_commit': 'b16d3c305be3d54706f032b11cac442d6075d7ad',
         'files': sorted(rows, key=lambda x: x['path']), 'index_excludes_itself': True,
         'new_archive': {'path': proof['new_archive'], 'bytes': proof['new_archive_bytes'],
                         'sha256': proof['new_archive_sha256']},
         'large_metadata_and_archive_stay_at_verified_original_locations': True,
         'product_files_changed': 0, 'new_build_or_native_runs': 0}
raw = canonical(index)
with (OUT / 'PACKET_INDEX.json').open('xb') as f:
    f.write(raw)
    f.flush()
    os.fsync(f.fileno())
all_files = sorted([r['path'] for r in rows] + ['PACKET_INDEX.json'])
archive = ROOT / 'git-proof-packet.tar.gz'
with archive.open('xb') as f:
    with gzip.GzipFile(fileobj=f, mode='wb', mtime=0) as z:
        with tarfile.open(fileobj=z, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
            for name in all_files:
                body = (OUT / name).read_bytes()
                item = tarfile.TarInfo(name)
                item.size = len(body)
                item.mtime = 0
                item.mode = 0o644
                tar.addfile(item, io.BytesIO(body))
    f.flush()
    os.fsync(f.fileno())
seen = []
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        assert member.isfile() and member.name in all_files
        assert tar.extractfile(member).read() == (OUT / member.name).read_bytes()
        seen.append(member.name)
assert seen == all_files
report = {'status': 'SMALL_GIT_PACKET_SEALED_EVERY_MEMBER_VERIFIED', 'files': len(all_files),
          'packet_index_sha256': sha(raw), 'packet_index_bytes': len(raw),
          'archive': str(archive), 'archive_bytes': archive.stat().st_size,
          'archive_sha256': sha(archive.read_bytes()), 'packet_root': str(OUT),
          'compressed_original_files': sum('uncompressed_sha256' in r for r in rows),
          'product_files_changed': 0, 'new_build_or_native_runs': 0}
raw = canonical(report)
with (ROOT / 'GIT_PACKET_SEALED.json').open('xb') as f:
    f.write(raw)
    f.flush()
    os.fsync(f.fileno())
print(json.dumps(report))
