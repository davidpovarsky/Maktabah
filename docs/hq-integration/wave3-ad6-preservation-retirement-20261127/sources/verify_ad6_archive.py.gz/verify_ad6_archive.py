#!/usr/bin/env python3
"""Verify every new archive byte, metadata record, path and reference declaration."""
from pathlib import Path, PurePosixPath
import base64
import datetime
import gzip
import hashlib
import json
import os
import shutil
import tarfile
import time

ROOT = Path(r'C:\Users\DAVID\.codex\artifacts\otzaria-wave3-ad6-preservation-20261127')
HEADER_SHA = '0eda5768bd4ef592a41b2ad278b3ebd6ffb18b26e7f7c0b38bb63d220d8ec21f'
SCRIPT_SHA = '9bb4e8dc5ddf3661860bbc5b71245d1227c04561a2bf25cced727e7b38132f4d'
PLAN_SHA = 'f7926486d1e091ed8ffff89f7fbe222cc9e2b71fea25d4c8486bfe97c305fe85'
RESERVE = 2415919104

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def identity(p):
    s = p.stat()
    return {'device': s.st_dev, 'inode': s.st_ino, 'bytes': s.st_size,
            'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns}

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()

def save(path, raw):
    if not isinstance(raw, bytes):
        raw = canonical(raw)
    assert shutil.disk_usage(ROOT).free - len(raw) >= RESERVE
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def rows(path, meta):
    assert path.stat().st_size == meta['bytes'] and digest(path) == meta['sha256']
    h = hashlib.sha256()
    total = 0
    with gzip.open(path, 'rb') as f:
        for line in f:
            total += len(line)
            h.update(line)
            yield json.loads(line)
    assert total == meta['uncompressed_bytes'] and h.hexdigest() == meta['uncompressed_sha256']

def safe_path(value, root_allowed=False):
    path = PurePosixPath(value)
    assert not path.is_absolute() and '..' not in path.parts and str(path) == value
    assert root_allowed or value != '.'
    return path

started = time.monotonic()
transfer_raw = (ROOT / 'TRANSFER_RESULT.json').read_bytes()
transfer = json.loads(transfer_raw)
assert transfer['status'] == 'EXACT_DIFFERENTIAL_TRANSFERRED_ALL_MEMBER_VERIFICATION_PENDING'
archive = Path(transfer['archive'])
assert archive == ROOT / 'failed-ad6-work-differential.tar.gz'
before = identity(archive)
assert before['bytes'] == transfer['archive_bytes'] <= 4294967296
assert digest(archive) == transfer['archive_sha256']
metadata_dir = ROOT / 'metadata'
assert not metadata_dir.exists()
metadata_dir.mkdir()
names = ('HEADER.json', 'entries.jsonl.gz', 'new-payloads.jsonl.gz', 'ad6_preservation.py',
         'READ_ONLY_PLAN.json.gz', 'INVENTORY_OWNER.json', 'STREAM_OWNER.json')
header = None
payloads = {}
seen = set()
member_count = payload_count = payload_bytes = 0
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        assert member.isfile() and member.name not in seen and not member.pax_headers
        safe_path(member.name)
        seen.add(member.name)
        file = tar.extractfile(member)
        if member_count < len(names):
            assert member.name == names[member_count]
            assert member.size < 16777216
            raw = file.read()
            assert len(raw) == member.size
            save(metadata_dir / member.name, raw)
            if member.name == 'HEADER.json':
                assert hashlib.sha256(raw).hexdigest() == HEADER_SHA
                header = json.loads(raw)
                assert header['root'] == '/Users/m1/builds/otzaria-wave1-sdk-20261127/source/build/SDK-Wave3-1be97035-Debug-FreshAfterFiveScopes-20261127-Work'
                assert header['boundary']['source'] == {'head': '1be970356c655bcef3688ddf1d129d5029bbc533', 'tracked_status': ''}
                assert not header['anything_deleted'] and not header['retirement_authorized']
            elif member.name == 'ad6_preservation.py':
                assert hashlib.sha256(raw).hexdigest() == header['script_sha256'] == SCRIPT_SHA
            elif member.name == 'READ_ONLY_PLAN.json.gz':
                assert hashlib.sha256(gzip.decompress(raw)).hexdigest() == PLAN_SHA
            if member_count == len(names) - 1:
                assert header is not None
                meta = next(x for x in header['metadata'] if x['name'] == 'new-payloads.jsonl.gz')
                for row in rows(metadata_dir / meta['name'], meta):
                    assert row['member'] == 'objects/sha256/' + row['sha256']
                    assert row['member'] not in payloads
                    safe_path(row['source_path'])
                    assert type(row['bytes']) is int and row['bytes'] >= 0 and len(row['sha256']) == 64
                    payloads[row['member']] = row
                assert len(payloads) == header['new_unique_payloads'] == 31355
                assert sum(x['bytes'] for x in payloads.values()) == header['new_unique_raw_bytes'] == 3770386133
        else:
            assert member.name in payloads
            expected = payloads[member.name]
            assert member.size == expected['bytes']
            h = hashlib.sha256()
            total = 0
            while True:
                b = file.read(1048576)
                if not b:
                    break
                h.update(b)
                total += len(b)
            assert total == expected['bytes'] and h.hexdigest() == expected['sha256']
            payload_count += 1
            payload_bytes += total
        member_count += 1
assert member_count == 31362 and payload_count == 31355 and payload_bytes == 3770386133
assert set(seen) == set(names) | set(payloads)
assert identity(archive) == before
meta = next(x for x in header['metadata'] if x['name'] == 'entries.jsonl.gz')
types = {}
refs = {}
content = hashlib.sha256()
counts = {'entries': 0, 'files': 0, 'directories': 0, 'symlinks': 0, 'logical_bytes': 0,
          'covered_files': 0, 'covered_bytes': 0, 'new_files': 0,
          'xattr_entries': 0, 'acl_entries': 0, 'hardlinked_files': 0}
pins = {x['id']: x['archive_sha256'] for x in header['base_archives']}
assert len(pins) == 6
new_keys = set()
for row in rows(metadata_dir / meta['name'], meta):
    path = safe_path(row['path'], True)
    assert row['path'] not in types and row['type'] in ('file', 'directory', 'symlink')
    if row['path'] == '.':
        assert not types and row['type'] == 'directory'
    else:
        assert types[str(path.parent)] == 'directory'
    types[row['path']] = row['type']
    for name in ('mode', 'uid', 'gid', 'device', 'inode', 'nlink', 'bytes', 'allocated_bytes',
                 'mtime_ns', 'atime_ns', 'ctime_ns', 'birthtime_ns', 'flags', 'rdev'):
        assert type(row[name]) is int
    assert 0 <= row['mode'] <= 4095 and row['nlink'] >= 1
    attr_names = set()
    for attr in row['xattrs']:
        name = base64.b64decode(attr['name_base64'], validate=True)
        value = base64.b64decode(attr['value_base64'], validate=True)
        assert name not in attr_names and len(value) == attr['bytes']
        assert hashlib.sha256(value).hexdigest() == attr['sha256']
        attr_names.add(name)
    if row['acl'] is not None:
        value = base64.b64decode(row['acl']['text_base64'], validate=True)
        assert len(value) == row['acl']['bytes'] and hashlib.sha256(value).hexdigest() == row['acl']['sha256']
    counts['entries'] += 1
    counts['xattr_entries'] += bool(row['xattrs'])
    counts['acl_entries'] += row['acl'] is not None
    if row['type'] == 'directory':
        counts['directories'] += 1
        assert 'payload' not in row
    elif row['type'] == 'symlink':
        counts['symlinks'] += 1
        assert base64.b64decode(row['target_bytes_base64'], validate=True) == row['target'].encode('utf-8', 'surrogateescape')
        assert 'payload' not in row
    else:
        counts['files'] += 1
        counts['logical_bytes'] += row['bytes']
        content.update(canonical({'path': row['path'], 'bytes': row['bytes'], 'sha256': row['sha256']}))
        if row['nlink'] > 1:
            counts['hardlinked_files'] += 1
            assert row['hardlink_group'] == str(row['device']) + ':' + str(row['inode'])
        payload = row['payload']
        safe_path(payload['member'])
        if payload['kind'] == 'new_member':
            expected = payloads[payload['member']]
            assert (row['bytes'], row['sha256']) == (expected['bytes'], expected['sha256'])
            counts['new_files'] += 1
            new_keys.add(payload['member'])
        else:
            assert payload['kind'] == 'prior_member'
            aid = payload['archive_id']
            assert pins[aid] == payload['archive_sha256']
            key = (aid, payload['member'])
            expected = {'archive_id': aid, 'member': payload['member'], 'archive_sha256': payload['archive_sha256'],
                        'bytes': row['bytes'], 'sha256': row['sha256']}
            assert key not in refs or refs[key] == expected
            refs[key] = expected
            counts['covered_files'] += 1
            counts['covered_bytes'] += row['bytes']
assert set(payloads) == new_keys
assert content.hexdigest() == header['regular_content_sha256'] == '78ad6fe46073f00da5915861a4a2f8c12c59fe8390c1b680247ed09cd9ebd470'
for name, expected in header['summary'].items():
    if name in counts:
        assert counts[name] == expected, (name, counts[name], expected)
assert counts['entries'] == 136409 and counts['files'] == 117206 and counts['new_files'] == 32533
ledger = ROOT / 'PRIOR_REFERENCES.jsonl.gz'
raw_sha = hashlib.sha256()
raw_bytes = 0
by_archive = {}
with ledger.open('xb') as underlying:
    with gzip.GzipFile(fileobj=underlying, mode='wb', mtime=0) as f:
        for key in sorted(refs):
            row = refs[key]
            b = canonical(row)
            f.write(b)
            raw_sha.update(b)
            raw_bytes += len(b)
            by_archive[row['archive_id']] = by_archive.get(row['archive_id'], 0) + 1
    underlying.flush()
    os.fsync(underlying.fileno())
record = {'status': 'COMPLETE_NEW_ARCHIVE_MEMBERS_METADATA_AND_PATHSET_VERIFIED_PRIOR_MEMBERSHIP_PENDING',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'new_archive': str(archive), 'new_archive_bytes': before['bytes'],
          'new_archive_sha256': transfer['archive_sha256'], 'archive_identity': before,
          'header_sha256': HEADER_SHA, 'member_count': member_count,
          'new_payload_count': payload_count, 'new_payload_bytes': payload_bytes,
          'source_counts': counts, 'full_metadata_records_verified': counts['entries'],
          'regular_content_sha256': content.hexdigest(),
          'prior_reference_ledger': {'path': str(ledger), 'bytes': ledger.stat().st_size,
                                    'sha256': digest(ledger), 'raw_bytes': raw_bytes,
                                    'raw_sha256': raw_sha.hexdigest(), 'members': len(refs), 'by_archive': by_archive},
          'transfer_receipt_sha256': hashlib.sha256(transfer_raw).hexdigest(),
          'verifier_sha256': digest(Path(__file__)), 'seconds': time.monotonic() - started,
          'full_restored_tree_materialized': False, 'anything_deleted': False,
          'retirement_authorized': False, 'new_sdk_or_native_runs': 0}
receipt = save(ROOT / 'NEW_ARCHIVE_VERIFIED.json', record)
print(json.dumps({'status': record['status'], 'receipt': receipt,
                  'archive_bytes': before['bytes'], 'archive_sha256': transfer['archive_sha256'],
                  'members': member_count, 'metadata_entries': counts['entries'],
                  'prior_reference_members': len(refs), 'references_by_archive': by_archive,
                  'seconds': record['seconds'], 'windows_free': shutil.disk_usage(ROOT).free}))
