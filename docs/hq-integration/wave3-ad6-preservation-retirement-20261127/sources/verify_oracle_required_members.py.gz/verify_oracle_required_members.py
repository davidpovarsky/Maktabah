from pathlib import Path
import sys,json,gzip,hashlib
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def identity(p):
 s=p.stat();return {'device':s.st_dev,'inode':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
packet=json.loads(gzip.decompress(sys.stdin.buffer.read()))
out=[]
for binding in packet['bindings']:
 aid=binding['id'];p=Path(binding['archive']);m=Path(binding['new_payload_manifest'])
 assert identity(p)==binding['archive_identity'] and identity(m)==binding['new_payload_manifest_identity']
 assert digest(Path(binding['full_member_receipt']))==binding['full_member_receipt_sha256']
 assert digest(Path(binding['header']))==binding['header_sha256']
 assert digest(m)==binding['new_payload_manifest_sha256']
 header=json.loads(Path(binding['header']).read_bytes())
 meta=next(x for x in header['metadata'] if x['name']=='new-payloads.jsonl.gz')
 need={x['member']:x for x in packet['required'] if x['archive_id']==aid};found=set()
 h=hashlib.sha256();count=total=0
 with gzip.open(m,'rb') as f:
  for line in f:
   h.update(line);total+=len(line);row=json.loads(line);count+=1
   member=row['member']
   if member in need:
    expected=need[member]
    assert expected['archive_sha256']==binding['archive_sha256']
    assert expected['bytes']==row['bytes'] and expected['sha256']==row['sha256']
    assert member not in found;found.add(member)
 assert total==meta['uncompressed_bytes'] and h.hexdigest()==meta['uncompressed_sha256']
 assert found==set(need) and identity(p)==binding['archive_identity'] and identity(m)==binding['new_payload_manifest_identity']
 out.append({**binding,'required_members':len(need),'required_members_matched':len(found),
             'physical_members':count,'physical_member_scope':'new_payloads',
             'original_full_member_proof_reused_for_identical_freshly_hashed_archive':True})
print(json.dumps({'status':'ALL_REQUIRED_ORACLE_PHYSICAL_MEMBERS_MATCH_EXACT_PRIOR_PROOFS',
                  'archives':out,'writes':0,'archives_mutated':False}))
