#!/usr/bin/env python3
"""Retire only the independently preserved and separately authorized local-ad6e Work."""
from pathlib import Path
import base64
import datetime
import hashlib
import inspect
import json
import os
import select
import shutil
import stat
import subprocess
import sys
import types

sys.dont_write_bytecode = True
EVIDENCE = Path('/Users/m1/builds/otzaria-wave3-ad6-preservation-20261127.n155e60d')
ROOT = Path('/Users/m1/builds/otzaria-wave1-sdk-20261127/source/build/SDK-Wave3-1be97035-Debug-FreshAfterFiveScopes-20261127-Work')
HEADER_SHA = '0eda5768bd4ef592a41b2ad278b3ebd6ffb18b26e7f7c0b38bb63d220d8ec21f'
PROOF_SHA = 'b93cf1bca06300066702c0d588cd14efe166e753f11f3d4fbca18e79a0d0ac68'
SOURCE_SHA = '41f3afac682426e9de31cfcb1029672817f1411819d6606d58f2f66af281bdee'
INVENTORY_SHA = '9bb4e8dc5ddf3661860bbc5b71245d1227c04561a2bf25cced727e7b38132f4d'


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def fixed_directory(path):
    assert path.resolve() == path and not path.is_symlink()
    s = path.lstat()
    assert stat.S_ISDIR(s.st_mode)
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino,
            'mode': s.st_mode, 'uid': s.st_uid, 'gid': s.st_gid}


def outside(inventory, header):
    result = [fixed_directory(Path(row['path'])) for row in header['boundary']['protected']]
    assert result == header['boundary']['protected']
    assert inventory.source_state() == header['boundary']['source']
    for item in result:
        assert item['path'] != str(ROOT) and ROOT not in Path(item['path']).parents
    return {'directories': result, 'exact_parent': fixed_directory(ROOT.parent),
            'source': inventory.source_state()}


def protected_files(inventory, header):
    original = header['original_execution']
    paths = [(Path(original['path']), original['sha256']),
             (inventory.SOURCE / 'Anytype/Sources/ServiceLayer/Block/Pastboard/PasteboardHelper.swift',
              '1edd18bf419c01fb88f72dcbca367e3417b2b8993394d1d0a3190dcb685b7eb0')]
    result = []
    for path, expected in paths:
        assert path.resolve() == path and ROOT not in path.parents
        before = path.lstat()
        assert stat.S_ISREG(before.st_mode)
        actual = inventory.digest(path)
        after = path.lstat()
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
        assert actual == expected
        result.append({'path': str(path), 'bytes': before.st_size, 'sha256': actual,
                       'device': before.st_dev, 'inode': before.st_ino,
                       'mtime_ns': before.st_mtime_ns, 'ctime_ns': before.st_ctime_ns})
    return result


def dependencies(inventory, header):
    for row in header['dependency_records']:
        path = ROOT / row['path']
        if row['kind'] == 'symlink':
            assert path.is_symlink() and os.readlink(path) == row['target']
            resolved = path.resolve(strict=False)
        else:
            assert row['kind'] == 'git_metadata' and not path.is_symlink()
            raw = path.read_bytes()
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
            assert row['target'] in [x.removeprefix('gitdir: ') for x in raw.decode().splitlines()]
            target = Path(row['target'])
            resolved = (target if target.is_absolute() else path.parent / target).resolve(strict=False)
        assert str(resolved) == row['resolved'] and resolved.exists() == row['exists']
        assert row['internal'] and (resolved == ROOT or ROOT in resolved.parents)
    probe = subprocess.run(['/usr/bin/git', '--no-optional-locks', '-C', str(inventory.SOURCE),
                            'grep', '-n', '-F', str(ROOT), '--', 'Tools/OriginalEditor', 'Tools/Hanlin', '.github'],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    actual = {'exit': probe.returncode, 'stdout': probe.stdout, 'stderr': probe.stderr}
    assert actual == header['source_controller_reference_probe'] == {'exit': 1, 'stdout': '', 'stderr': ''}
    return {'records': len(header['dependency_records']),
            'record_sha256': hashlib.sha256(canonical(header['dependency_records'])).hexdigest(),
            'all_internal': True, 'existing_targets': sum(x['exists'] for x in header['dependency_records']),
            'preserved_dangling_symlinks': [x for x in header['dependency_records'] if not x['exists']],
            'current_controller_reference_probe': actual,
            'external_referrers_exhaustively_excluded': False}


def path_stat(inventory, helper, header):
    h = hashlib.sha256()
    count = 0
    for path, info in inventory.walk():
        h.update(canonical({'path': path.relative_to(ROOT).as_posix(), 'identity': helper.identity(info)}))
        count += 1
    assert count == header['summary']['entries'] == 136409
    assert h.hexdigest() == header['path_stat_sha256']
    return {'entries': count, 'sha256': h.hexdigest()}


def main():
    envelope = json.loads(sys.stdin.buffer.readline(256 * 1024))
    proof_raw = base64.b64decode(envelope['proof_base64'], validate=True)
    source_raw = base64.b64decode(envelope['source_base64'], validate=True)
    current_raw = base64.b64decode(envelope['current_base64'], validate=True)
    assert hashlib.sha256(proof_raw).hexdigest() == PROOF_SHA
    assert hashlib.sha256(source_raw).hexdigest() == SOURCE_SHA
    assert hashlib.sha256(current_raw).hexdigest() == envelope['current_sha256']
    assert (EVIDENCE / 'COMPLETE_PRESERVATION_VERIFIED.json').read_bytes() == proof_raw
    assert (EVIDENCE / 'SOURCE_REVERIFIED.json').read_bytes() == source_raw
    proof, source, current = json.loads(proof_raw), json.loads(source_raw), json.loads(current_raw)
    assert proof['root'] == source['root'] == current['root'] == str(ROOT)
    assert proof['header_sha256'] == source['header_sha256'] == HEADER_SHA
    assert source['complete_preservation_receipt_sha256'] == PROOF_SHA
    assert not proof['anything_deleted'] and not source['anything_deleted']
    assert current['status'] == 'ALL_CURRENT_AD6_ARCHIVE_AND_RECEIPT_IDENTITIES_MATCH'
    assert current['complete_preservation_sha256'] == PROOF_SHA and current['source_reverified_sha256'] == SOURCE_SHA
    assert current['archive_bindings'] == proof['archive_bindings']
    assert current['new_archive_identity'] == proof['new_archive_identity']
    assert current['new_archive_sha256'] == proof['new_archive_sha256']
    assert current['new_archive_bytes'] == proof['new_archive_bytes']
    age = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(current['utc'])).total_seconds()
    assert 0 <= age <= 180
    body = (EVIDENCE / 'ad6_preservation.py').read_bytes()
    assert hashlib.sha256(body).hexdigest() == INVENTORY_SHA
    inventory = types.ModuleType('fixed_ad6_inventory')
    inventory.__file__ = str(EVIDENCE / 'ad6_preservation.py')
    exec(compile(body, inventory.__file__, 'exec'), inventory.__dict__)
    assert inventory.ROOT == ROOT
    header = inventory.load_header(EVIDENCE, HEADER_SHA)
    _, helper, _ = inventory.helpers()
    assert inventory.boundary() == header['boundary'] == source['boundary_after']
    assert inventory.digest(Path(__file__)) == envelope['retirement_script_sha256']
    before_use = inventory.no_use()
    protected = outside(inventory, header)
    files = protected_files(inventory, header)
    dep = dependencies(inventory, header)
    paths = path_stat(inventory, helper, header)
    assert outside(inventory, header) == protected and protected_files(inventory, header) == files
    after_use = inventory.no_use()
    before = {'status': 'EXACT_AD6_CURRENT_STATE_VERIFIED_AWAITING_DURABLE_OFFHOST_ACK', 'utc': utc(),
              'root': str(ROOT), 'root_identity': header['boundary']['root'], 'header_sha256': HEADER_SHA,
              'complete_preservation_sha256': PROOF_SHA, 'source_reverified_sha256': SOURCE_SHA,
              'current_archive_bindings_sha256': envelope['current_sha256'],
              'current_archive_bindings': current, 'path_stat_rechecked': paths,
              'protected_outside_before': protected, 'protected_files_before': files,
              'dependency_before': dep, 'open_use_before': before_use, 'open_use_after': after_use,
              'free_before': inventory.capacity(), 'script_sha256': inventory.digest(Path(__file__)),
              'owner_process': {**inventory.process_identity(),
                                'script_sha256': inventory.digest(Path(__file__)),
                                'inventory_identity_helper_sha256': INVENTORY_SHA},
              'authorization': 'Root separately authorized only this exact failed local-ad6e Work after independent read of b93cf1bca063 and 41f3afac6824. All archives, original Evidence/ABI/source and other work remain protected. No build or SDK retry is authorized.',
              'anything_deleted': False, 'native_acceptance': 0, 'sdk_retry': False}
    raw = canonical(before)
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()
    ready, _, _ = select.select([sys.stdin.buffer], [], [], 90)
    assert ready, 'No timely durable off-host ACK; nothing removed'
    acknowledgement = json.loads(sys.stdin.buffer.readline(4096))
    expected_ack = {'ack': 'DURABLE_OFFHOST_EXACT_AD6_PREDELETE', 'sha256': hashlib.sha256(raw).hexdigest(),
                    'complete_preservation_sha256': PROOF_SHA, 'source_reverified_sha256': SOURCE_SHA,
                    'current_archive_bindings_sha256': envelope['current_sha256']}
    assert acknowledgement == expected_ack
    assert path_stat(inventory, helper, header) == paths
    assert dependencies(inventory, header) == dep
    assert protected_files(inventory, header) == files and outside(inventory, header) == protected
    assert inventory.boundary() == header['boundary']
    immediate_use = inventory.no_use()
    assert not immediate_use['open_paths'] and not immediate_use['process_references']
    assert shutil.rmtree.avoids_symlink_attacks
    expected_parent = protected['exact_parent']
    parent_fd = os.open(ROOT.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    ps = os.fstat(parent_fd)
    assert (ps.st_dev, ps.st_ino, ps.st_mode, ps.st_uid, ps.st_gid) == (
        expected_parent['device'], expected_parent['inode'], expected_parent['mode'], expected_parent['uid'], expected_parent['gid'])
    cwd_fd = os.open('.', os.O_RDONLY | os.O_DIRECTORY)
    started = False
    try:
        has_dir_fd = 'dir_fd' in inspect.signature(shutil.rmtree).parameters
        if not has_dir_fd:
            os.fchdir(parent_fd)
        rs = os.stat(ROOT.name, dir_fd=parent_fd, follow_symlinks=False)
        original = header['boundary']['root']
        assert (rs.st_dev, rs.st_ino, rs.st_mode, rs.st_uid, rs.st_gid) == (
            original['device'], original['inode'], original['mode'], original['uid'], original['gid'])
        started = True
        if has_dir_fd:
            shutil.rmtree(ROOT.name, dir_fd=parent_fd)
        else:
            shutil.rmtree(ROOT.name)
        try:
            os.stat(ROOT.name, dir_fd=parent_fd, follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            raise AssertionError('Exact authorized Work still exists')
        os.fchdir(cwd_fd)
        assert not os.path.lexists(ROOT)
        assert outside(inventory, header) == protected
        assert protected_files(inventory, header) == files
        result = {**before, 'status': 'RETIRED_ONLY_EXACT_FULLY_PRESERVED_AD6_WORK', 'finished_at': utc(),
                  'anything_deleted': True, 'removed': [str(ROOT)], 'full_absence_verified': True,
                  'immediate_predelete_no_use': immediate_use,
                  'protected_outside_after': outside(inventory, header),
                  'protected_files_after': protected_files(inventory, header),
                  'protected_identities_unchanged': True, 'parent_fd_pinned': True,
                  'fd_based_rmtree': True, 'predelete_receipt_sha256': hashlib.sha256(raw).hexdigest(),
                  'free_after': inventory.capacity()}
        result['concurrent_free_delta_bytes'] = result['free_after'] - result['free_before']
        result['free_delta_scope'] = 'Concurrent filesystem observations; not exclusive attribution or a production capacity pass.'
    except BaseException as error:
        result = {**before, 'status': 'EXACT_AD6_RETIREMENT_ERROR', 'finished_at': utc(),
                  'anything_deleted': started, 'removal_started': started,
                  'error': repr(error), 'root_still_exists': os.path.lexists(ROOT),
                  'predelete_receipt_sha256': hashlib.sha256(raw).hexdigest()}
        sys.stdout.buffer.write(canonical(result))
        sys.stdout.buffer.flush()
        raise
    finally:
        os.fchdir(cwd_fd)
        os.close(cwd_fd)
        os.close(parent_fd)
    sys.stdout.buffer.write(canonical(result))
    sys.stdout.buffer.flush()


if __name__ == '__main__':
    main()
