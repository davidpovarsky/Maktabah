import base64,gzip,hashlib,io,json,os,pathlib,shutil,signal,subprocess,time,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='e142c1c461f886d62c98cf29f46e41a4fa0af100'
PARENT='ce4fe5a327168524f6f1fef1e7792a275ece0ebe'
SOURCE='d7b4d0978fe1bfc5d79bb377a2691b789db08741'
DONOR='/mnt/development/projects/worktrees/Maktabah-wave3-cold-initial-content-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127'
D='docs/ui-routing/wave3-cold-initial-content-20261127'
PROOF='docs/hq-integration/wave3-cold-reader-intake-20261127'
ZIP=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-cold-shared-intake-20261127.zip')
CONTROL=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-reader-tool-cold-20261127-attempt1')
SWIFT=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[];steps=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes'] and sha(b)==row['sha256'],row.get('path','unnamed')
def apply(text,changes,a,b):
 for e in changes:
  assert text.count(e[a])==e.get('occurrences',1),e[a][:100]
  text=text.replace(e[a],e[b])
 return text
def capacity():
 assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
 assert sum(p.stat().st_blocks*512 for p in RUN.rglob('*')if p.is_file())<268435456
def run(name,argv,timeout=90):
 capacity();step={'name':name,'argv':list(map(str,argv)),'started':time.time()};steps.append(step)
 with (RUN/(name+'.stdout')).open('wb')as out,(RUN/(name+'.stderr')).open('wb')as err:
  p=subprocess.Popen(list(map(str,argv)),stdout=out,stderr=err,start_new_session=True,env={**os.environ,'TMPDIR':str(RUN/'tmp')})
  step['pid']=p.pid;step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21];until=time.time()+timeout
  while p.poll()is None:
   try:capacity();assert time.time()<until
   except BaseException:
    step['interrupted']='owned deadline/capacity guard';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.25)
  step['exit']=p.returncode
 step['finished']=time.time();step['logs']={s:{'bytes':(RUN/(name+s)).stat().st_size,'sha256':sha((RUN/(name+s)).read_bytes())}for s in ['.stdout','.stderr']}
 dump(RUN/'STEPS.json',steps);assert p.returncode==0,name
def archive_records(name,count):
 packed=show(SOURCE,D+'/'+name);meta=json.loads(show(SOURCE,D+'/'+name+'.manifest.json'))
 assert len(packed)==meta['gzipBytes'] and sha(packed)==meta['gzipSHA256']
 raw=gzip.decompress(packed);assert len(raw)==meta['rawBytes']and sha(raw)==meta['rawSHA256']
 records=json.loads(raw)['files'];assert len(records)==count
 assert [{k:r[k]for k in ['path','bytes','sha256']}for r in records]==meta['files']
 values={}
 for row in records:
  rel=pathlib.PurePosixPath(row['path']);assert not rel.is_absolute()and'..'not in rel.parts and row['path']not in values
  b=base64.b64decode(row['base64'],validate=True);pin(b,row);values[row['path']]=b
 return values,meta
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,SOURCE);assert rev(SOURCE+'^')==PARENT
 indexRaw=show(SOURCE,D+'/ARTIFACTS.json');assert sha(indexRaw)=='3d7d7c7d9810eaa46b3be5286dc36cd2c5a55932d76d11352d32e11df02e0cda'
 index=json.loads(indexRaw);rows=index['files'];assert len(rows)==33
 for row in rows:pin(show(SOURCE,D+'/'+row['path']),row)
 packet=json.loads(show(SOURCE,D+'/RESULT.json'));assert packet['observedIntegrationHEAD']==BASE
 assert packet['counts']['AppleSDK']==packet['counts']['native']==0
 sourceRows=packet['sourceFiles'];assert len(sourceRows)==6
 changed=git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines()
 assert len(changed)==40 and set(changed)=={r['path']for r in sourceRows}|{D+'/'+r['path']for r in rows}|{D+'/ARTIFACTS.json'}
 for row in sourceRows:
  p=row['path'];pin(show(SOURCE,p),row['after'])
  if row['before']is None:assert not git('ls-tree',BASE,'--',p)
  else:pin(show(BASE,p),row['before']);assert show(BASE,p)==show(PARENT,p)
 rawControls,rawMeta=archive_records('evidence/RAW_CONTROLS.json.gz',142)
 snapshots,snapshotMeta=archive_records('proposal/SOURCE.json.gz',4)
 for row in packet['preservedGeneratedProducts']:
  p=pathlib.Path(row['path']);assert str(p).startswith('/mnt/development/projects/diagnostics/otzaria-wave3-cold-initial-content-20261127/');pin(p.read_bytes(),row)
 counts={}
 for path,expected in [('attempt-1/run-baseline.stdout',(3,4)),('attempt-1/run-candidate.stdout',(35,0)),('publisher-followup-attempt-1/run-ios-candidate.stdout',(14,3)),('publisher-followup-attempt-2/run-ios-before.stdout',(10,7)),('publisher-followup-attempt-2/run-ios-candidate.stdout',(17,0)),('publisher-followup-attempt-2/run-macos-before.stdout',(3,2)),('publisher-followup-attempt-2/run-macos-candidate.stdout',(5,0))]:
  r=json.loads(rawControls[path]);assert (r['pass'],r['fail'])==expected;counts[path]={'pass':r['pass'],'fail':r['fail']}
 for row in sourceRows:assert rawControls['publisher-followup-attempt-2/inputs/candidate/'+row['path']]==show(SOURCE,row['path'])
 raw=ZIP.read_bytes();assert len(raw)==129451 and sha(raw)=='572c4adc2659887c017d118ca8ac5090cdcd8e84b8c08815635ab20d3b8000f8'
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  zrows=json.loads(z.read('MANIFEST.json'));assert len(zrows)==6 and len(z.namelist())==7
  assert set(z.namelist())=={r['path']for r in zrows}|{'MANIFEST.json'}
  files={r['path']:z.read(r['path'])for r in zrows}
  for row in zrows:pin(files[row['path']],row)
 join=json.loads(files['JOIN.json']);assert join['base']==BASE and len(join['rows'])==3
 shared={}
 for row in join['rows']:
  p=row['path'];old=show(BASE,p);new=files['candidate/'+p]
  assert len(old)==row['beforeBytes']and sha(old)==row['beforeSHA256']and len(new)==row['afterBytes']and sha(new)==row['afterSHA256'];shared[p]=new
 session='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
 sedits=json.loads(show(SOURCE,D+'/proposal/SESSION_EDITS.json'))['edits'];assert len(sedits)==2
 assert apply(show(BASE,session).decode(),sedits,'before','after').encode()==shared[session]
 assert apply(shared[session].decode(),list(reversed(sedits)),'after','before').encode()==show(BASE,session)
 assert snapshots['observed-root/'+session]==show(BASE,session)and snapshots['observed-root-proposal/'+session]==shared[session]
 tool=json.loads(files['READER_TOOL_EDITS.json']);assert len(tool['edits'])==5
 assert apply(show(BASE,tool['path']).decode(),tool['edits'],'before','after').encode()==shared[tool['path']]
 assert apply(shared[tool['path']].decode(),list(reversed(tool['edits'])),'after','before').encode()==show(BASE,tool['path'])
 registration=json.loads(files['REGISTRATION.json']);assert set(registration['targets'])=={'Maktabah','Maktabah-Direct','Maktabah-iOS'}and len(registration['newObjects'])==4
 project='Maktabah.xcodeproj/project.pbxproj';inverse=shared[project].decode()
 for edit in reversed(registration['insertions']):
  assert inverse[edit['offset']:edit['offset']+len(edit['text'])]==edit['text'];inverse=inverse[:edit['offset']]+inverse[edit['offset']+len(edit['text']):]
 assert inverse.encode()==show(BASE,project)
 controlRaw=(CONTROL/'RESULT.json').read_bytes();assert sha(controlRaw)=='c5db1561d0f0d470547e194d3064bc3f1118813370f7e290337f9c76844b386f'
 controls=json.loads(controlRaw);assert controls['rootHead']==BASE and controls['nativeRuns']==0 and controls['AppleSDK']=='NOT_RUN'
 assert [(r['passed'],r['failed'],r['exit'])for r in controls['variants']]==[(3,6,1),(9,0,0)]
 for row in controls['inputs']['rows']:pin((CONTROL/'inputs'/row['path']).read_bytes(),row)
 def stripped(b):
  assert b.startswith(b'#if os(iOS)\n')and b.endswith(b'#endif\n');return b[len(b'#if os(iOS)\n'):-len(b'#endif\n')]
 assert stripped(show(BASE,tool['path']))==(CONTROL/'inputs/original.swift').read_bytes()
 assert stripped(shared[tool['path']])==(CONTROL/'inputs/candidate.swift').read_bytes()
 for name in ['ReaderContentLoadCoordinator.swift','ReaderInitialContentRequest.swift']:
  assert (CONTROL/'inputs/common'/name).read_bytes()==show(SOURCE,'Source/ChavrusaText/Navigation/'+name)
 for step in controls['steps']:
  for suffix,row in step['logs'].items():pin((CONTROL/(step['name']+suffix)).read_bytes(),row)
 for row in controls['reusedProducts']:pin(pathlib.Path(row['path']).read_bytes(),row)
 # Reuse only evidence whose complete source pins and original/candidate bytes
 # match. The two newly joined complete app files receive actual syntax parses.
 for name in ['tmp','inputs']:(RUN/name).mkdir()
 assert sha(SWIFT.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 syntax=[]
 for p in [session,tool['path']]:
  target=RUN/'inputs'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(shared[p]);syntax.append(target)
 for mode in ['release','debug']:
  run('joined-full-ios-syntax-'+mode,[SWIFT,'-frontend','-parse','-target','arm64-apple-ios27.0',*(['-D','DEBUG']if mode=='debug'else[]),*syntax])
 protected=['Source/Otzaria/Actions','Source/Otzaria/UIRouting','Source/ChavrusaText/UIRoutingHost/Sources','Vendor','Scripts','.github','docs/architecture','Maktabah-iOSUITests','Source/Localizable.xcstrings','Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift']
 trees={p:rev(BASE+':'+p)for p in protected}
 git('diff','--check',PARENT,SOURCE)
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',SOURCE)
 picked=rev('HEAD');assert not git('status','--porcelain')
 for p,b in shared.items():assert (ROOT/p).read_bytes()==show(BASE,p);(ROOT/p).write_bytes(b)
 git('add','--sparse','--',*shared);git('diff','--cached','--check');assert set(git('diff','--cached','--name-only').decode().splitlines())==set(shared)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Join cold Reader lifetime to workspace and selected-note routing')
 sharedCommit=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 proofRecords=[]
 for p in sorted(CONTROL.rglob('*')):
  if not p.is_file()or'module-cache'in p.parts or'tmp'in p.relative_to(CONTROL).parts or p.name in ['original','candidate']:continue
  b=p.read_bytes();proofRecords.append({'path':str(p.relative_to(CONTROL)),'bytes':len(b),'sha256':sha(b),'base64':base64.b64encode(b).decode()})
 assert len(proofRecords)==25
 preserved=[{'path':str(CONTROL/name),'bytes':(CONTROL/name).stat().st_size,'sha256':sha((CONTROL/name).read_bytes()),'preserved':True}for name in ['original','candidate']]
 readerArchive=json.dumps({'files':proofRecords,'preservedGeneratedProducts':preserved,'scope':controls['scope']},ensure_ascii=False,indent=2).encode()+b'\n'
 (proof/'READER_TOOL_RAW.json.gz').write_bytes(gzip.compress(readerArchive,mtime=0))
 dump(proof/'READER_TOOL_RAW_MANIFEST.json',{'files':[{k:r[k]for k in ['path','bytes','sha256']}for r in proofRecords],'preservedGeneratedProducts':preserved,'rawBytes':len(readerArchive),'rawSHA256':sha(readerArchive)})
 (proof/'READER_TOOL_RESULT.json').write_bytes(controlRaw)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 for name in ['JOIN.json','REGISTRATION.json','READER_TOOL_EDITS.json']:(proof/(name+'.gz')).write_bytes(gzip.compress(files[name],mtime=0))
 (proof/'STEPS.json').write_bytes((RUN/'STEPS.json').read_bytes())
 for step in steps:
  for suffix in step['logs']:(proof/(step['name']+suffix)).write_bytes((RUN/(step['name']+suffix)).read_bytes())
 report={'schema':'otzaria.wave3.cold-reader-intake.v1','base':BASE,'donor':SOURCE,'picked':picked,'sharedCommit':sharedCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'productPaths':6,'docsPaths':34,'manifestRows':33,'rawColdEvidenceFilesVerified':142,'sessionSnapshotsVerified':4,'sourceControls':counts,'readerToolSourceControls':{'original':{'passed':3,'failed':6},'candidate':{'passed':9,'failed':0},'resultSHA256':sha(controlRaw),'rawFilesPreserved':25,'preservedGeneratedProducts':preserved},'rootSharedJoin':join,'registration':registration,'newBehaviorControlExecutions':0,'newFullAppFileSyntaxParses':4,'syntaxSteps':steps,'protectedTrees':trees,'AppleSDK':'NOT_RUN','nativeRuns':0,'open':['App SDK typing and real cold/inactive/restored/cancelled/background UI acceptance','Hidden already-active phone Group presentation','Annotation expansion original full-caller correction and native selectors','Original Inspector complete source traversal','Final production/owner/target merge/TestFlight']}
 dump(proof/'RESULT.json',report)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record cold Reader and selected-note source integration evidence')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sharedCommit':sharedCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc(),'steps':steps});raise
