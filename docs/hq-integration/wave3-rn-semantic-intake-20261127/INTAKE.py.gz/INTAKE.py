import base64,gzip,hashlib,io,json,os,pathlib,shutil,signal,subprocess,tarfile,time,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='db764d51080102504ee296d43aebe261793b8163'
PARENT='37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be'
SOURCE='d4e25c0cf5581427d6742ade1d4d1e0f3ddaa1a3'
DOCS='7215591a74f48e3d50b14d22b35c3a602e9f9753'
DONOR='/mnt/development/projects/worktrees/Maktabah-wave3-vendor-admission-private-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127'
D='docs/ui-routing/wave3-sefaria-semantic-targets-20261127'
PROOF='docs/hq-integration/wave3-rn-semantic-intake-20261127'
ZIP=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-rn-shared-intake-20261127.zip')
SWIFT=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
CORE=ROOT/'.git/search-continuation-integrated-controls-20261127'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[];steps=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def capacity():
 assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
 assert sum(p.stat().st_blocks*512 for p in RUN.rglob('*')if p.is_file())<268435456
def run(name,argv,timeout=120):
 capacity();step={'name':name,'argv':list(map(str,argv)),'started':time.time()};steps.append(step)
 with (RUN/(name+'.stdout')).open('wb')as out,(RUN/(name+'.stderr')).open('wb')as err:
  p=subprocess.Popen(list(map(str,argv)),stdout=out,stderr=err,start_new_session=True,env={**os.environ,'TMPDIR':str(RUN/'tmp')})
  step['pid']=p.pid;step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21]
  until=time.time()+timeout
  while p.poll()is None:
   try:capacity();assert time.time()<until
   except BaseException:
    step['interrupted']='owned deadline/capacity guard';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
  step['exit']=p.returncode
 step['finished']=time.time();step['logs']={s:{'bytes':(RUN/(name+s)).stat().st_size,'sha256':sha((RUN/(name+s)).read_bytes())}for s in ['.stdout','.stderr']}
 dump(RUN/'STEPS.json',steps);assert p.returncode==0,name
def archive(name,index,count):
 raw=show(DOCS,D+'/'+name);expected=json.loads(show(DOCS,D+'/'+index))['members'];assert len(expected)==count
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as t:
  members=[x for x in t.getmembers()if x.isfile()];assert len(members)==count
  assert {x.name for x in members}=={r['path']for r in expected}
  values={}
  for row in expected:
   b=t.extractfile(row['path']).read();pin(b,row);values[row['path']]=b
 return values
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,DOCS)
 assert rev(SOURCE+'^')==PARENT and rev(DOCS+'^')==SOURCE
 manifestBytes=show(DOCS,D+'/ARTIFACTS.json');assert sha(manifestBytes)=='10cf21a27f867b59500214b480864e2b85639ddafe54600463ad61180e75d32e'
 manifest=json.loads(manifestBytes)['artifacts'];assert len(manifest)==30
 docsPaths=git('diff-tree','--no-commit-id','--name-only','-r',DOCS).decode().splitlines()
 assert set(docsPaths)=={D+'/'+r['path']for r in manifest}|{D+'/ARTIFACTS.json'}
 for row in manifest:pin(show(DOCS,D+'/'+row['path']),row)
 sourceRows=json.loads(show(DOCS,D+'/SOURCE_INPUTS.json'))['rows'];assert len(sourceRows)==19
 sourcePaths=git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines()
 assert set(sourcePaths)=={r['path']for r in sourceRows}
 for row in sourceRows:
  pin(show(SOURCE,row['path']),row['after'])
  if row['before']:pin(show(BASE,row['path']),row['before']);assert show(BASE,row['path'])==show(PARENT,row['path'])
  else:assert not git('ls-tree',BASE,'--',row['path'])
 vendorPaths=[p for p in sourcePaths if p.startswith('Vendor/')];assert len(vendorPaths)==6
 assert rev(BASE+':Vendor')==rev(PARENT+':Vendor')=='9e4f188c5bedeef55ce95d97943f5e5046b6f3d6'
 assert rev(SOURCE+':Vendor')=='2fb868bdbe5d2d52735e857a24933918ff658cef'
 actual=archive('actual-source-controls.tar.gz','ACTUAL_SOURCE_CONTROLS_INDEX.json',265)
 local=archive('local-source-controls.tar.gz','LOCAL_SOURCE_CONTROLS_INDEX.json',39)
 summary=json.loads(show(DOCS,D+'/RESULT.json'))
 assert summary['sdk_typecheck']==summary['metro']==summary['native_ui']=='NOT_RUN'
 controls=json.loads(actual['attempt-4/candidate/RESULT.json']);assert controls['compileExit']==controls['runExit']==0 and controls['passed']==50 and controls['failed']==0
 for label,counts in [('workspace-publication-candidate-attempt-1',(4,0)),('workspace-publication-baseline-attempt-1',(2,2))]:
  result=json.loads(actual[label+'/RESULT.json']);assert result['compileExit']==0 and (result['result']['passed'],result['result']['failed'])==counts
 for label,counts in [('candidate',(36,0)),('omit-native-claim',(24,12))]:
  result=json.loads(local['controls-js-attempt-3/'+label+'/RESULT.json']);assert (result['passed'],result['failed'])==counts
 # All archived results, commands and negative artifacts retain original bytes.
 # The summary keeps the geometry/binding/root cases in their own boundaries.
 assert summary['source_results']['complete_binding_and_rpc_with_platform_boundaries']==[13,0]
 assert summary['source_results']['native_geometry_algorithm_with_platform_boundary']==[32,0]
 assert summary['source_results']['unchanged_original_js_root_controls']==[24,0]
 b=ZIP.read_bytes();assert len(b)==219772 and sha(b)=='27273cb8a1821590d3b933dab7f59236072c701fff56e361ba53d3172d194c4b'
 with zipfile.ZipFile(io.BytesIO(b))as z:
  index=json.loads(z.read('MANIFEST.json'));assert len(index)==15 and len(z.namelist())==16
  assert set(z.namelist())=={r['path']for r in index}|{'MANIFEST.json'}
  files={r['path']:z.read(r['path'])for r in index}
  for row in index:pin(files[row['path']],row)
 edits=json.loads(files['EXACT_SHARED_EDITS.json']);assert len(edits)==45
 mergeRows=json.loads(files['MERGE_RESULT.json']);assert len(mergeRows)==10 and all(r['exit']==0 for r in mergeRows)
 pairs=json.loads(gzip.decompress(show(DOCS,D+'/shared-proposals/exact-source-pairs.json.gz')))
 shared={};originals={}
 for row in mergeRows:
  p=row['path'];before=show(BASE,p);assert sha(before)==row['currentSHA256'];originals[p]=before
  rawBefore=base64.b64decode(pairs[p]['before']);rawAfter=base64.b64decode(pairs[p]['after'])
  assert rawBefore==show(PARENT,p)
  text=before.decode();oldText=rawBefore.decode()
  selected=[x for x in edits if x['path']==p]
  for e in selected:
   assert text.count(e['old'])==oldText.count(e['old'])==1
   text=text.replace(e['old'],e['new'],1);oldText=oldText.replace(e['old'],e['new'],1)
  assert oldText.encode()==rawAfter and text.encode()==files['candidate/'+p]
  assert sha(text.encode())==row['candidateSHA256']
  inverse=text
  for e in reversed(selected):assert inverse.count(e['new'])==1;inverse=inverse.replace(e['new'],e['old'],1)
  assert inverse.encode()==before;shared[p]=text.encode()
 registration=json.loads(files['REGISTRATION.json']);project='Maktabah.xcodeproj/project.pbxproj'
 assert sha(show(BASE,project))==registration['beforeSHA256']and registration['newObjects']==4
 assert set(registration['targets'])=={'Maktabah','Maktabah-Direct','Maktabah-iOS'}
 inverse=files['candidate/'+project].decode()
 for e in reversed(registration['projectInsertions']):
  assert inverse[e['offset']:e['offset']+len(e['text'])]==e['text'];inverse=inverse[:e['offset']]+inverse[e['offset']+len(e['text']):]
 assert inverse.encode()==show(BASE,project)and sha(files['candidate/'+project])==registration['afterSHA256']
 shared[project]=files['candidate/'+project]
 syntax=json.loads(show(DOCS,D+'/SYNTAX_RESULT.json'));assert syntax['passed']==30 and syntax['failed']==0
 for check in syntax['checks']:
  p=check['path'];b=base64.b64decode(pairs[p]['after'])if p in pairs else show(SOURCE,p)
  pin(b,check);assert check['exit']==0
 # Compile the actual merged portable packages once to resolve integration
 # typing after Group, ReaderTools, passive publication and Guide additions.
 for name in ['inputs','output','tmp','module-cache']:(RUN/name).mkdir()
 assert sha(SWIFT.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 coreInputs=json.loads((CORE/'INPUTS.json').read_text())
 coreRows=[r for r in coreInputs['files']if r['path'].startswith('Source/Otzaria/Actions/Sources/OtzariaActionCore/')];assert len(coreRows)==31
 for row in coreRows:pin(show(BASE,row['path']),row)
 for name,digest in [('OtzariaActionCore.swiftmodule','c45482e0c872e1378e9048b9f1b9fef473b0a9b8973ef0e17ee9e2df22a24103'),('libOtzariaActionCore.so','f7a7d43d27b341f53a32b5205306c6bcec69c7a05b1f381d6e2239d5803d049a')]:assert sha((CORE/'output'/name).read_bytes())==digest
 packageRows=[];packages=[]
 for folder in ['Source/Otzaria/UIRouting/Sources/OtzariaUIRouting','Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost']:
  paths=git('ls-tree','-r','--name-only',BASE,folder).decode().splitlines();inputs=[]
  for p in paths:
   if not p.endswith('.swift'):continue
   b=shared.get(p,show(BASE,p));target=RUN/'inputs'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);inputs.append(target)
   packageRows.append({'path':p,'bytes':len(b),'sha256':sha(b)})
  packages.append(inputs)
 assert len(packages[0])==13 and len(packages[1])==39
 flags=[SWIFT,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',RUN/'module-cache',
  '-I',CORE/'output','-L',CORE/'output','-lOtzariaActionCore','-Xlinker','-rpath','-Xlinker',CORE/'output']
 run('compile-merged-ui',flags+['-emit-module','-emit-library','-module-name','OtzariaUIRouting','-emit-module-path',RUN/'output/OtzariaUIRouting.swiftmodule','-o',RUN/'output/libOtzariaUIRouting.so']+packages[0])
 run('compile-merged-host',flags+['-I',RUN/'output','-L',RUN/'output','-lOtzariaUIRouting','-Xlinker','-rpath','-Xlinker',RUN/'output',
  '-emit-module','-emit-library','-module-name','ChavrusaUIRoutingHost','-emit-module-path',RUN/'output/ChavrusaUIRoutingHost.swiftmodule','-o',RUN/'output/libChavrusaUIRoutingHost.so']+packages[1])
 for p in ['Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift','Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift']:
  f=RUN/'inputs'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(shared[p])
  for debug in [False,True]:run('syntax-'+f.stem+'-'+('debug'if debug else'release'),[SWIFT,'-frontend','-parse','-target','arm64-apple-ios27.0-simulator']+(['-D','DEBUG']if debug else[])+[f],timeout=30)
 dump(RUN/'PACKAGE_INPUTS.json',{'files':packageRows,'coreRejoined':coreRows,'scope':'Actual current 13 UIRouting and39 Host files; Apple guarded bodies untyped; no native execution.'})
 protected=['Source/Otzaria/Actions','Scripts','.github','docs/architecture','Maktabah-iOSUITests','Source/Localizable.xcstrings']
 trees={p:rev(BASE+':'+p)for p in protected}
 git('diff','--check',PARENT,SOURCE);git('diff','--check',SOURCE,DOCS)
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 picked=[]
 for donor in [SOURCE,DOCS]:
  git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',donor)
  picked.append({'donor':donor,'intake':rev('HEAD')});assert not git('status','--porcelain')
 for p,b in shared.items():
  assert (ROOT/p).read_bytes()==show(BASE,p);(ROOT/p).write_bytes(b)
 git('add','--sparse','--',*shared);git('diff','--cached','--check')
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(shared)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Wire four original Sefaria targets through retained source owners')
 sharedCommit=rev('HEAD');assert not git('status','--porcelain')
 assert rev('HEAD:Vendor')=='2fb868bdbe5d2d52735e857a24933918ff658cef'
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 for name in ['EXACT_SHARED_EDITS.json','HUNK_JOIN.json','REGISTRATION.json','MERGE_RESULT.json']:(proof/(name+'.gz')).write_bytes(gzip.compress(files[name],mtime=0))
 for name in ['STEPS.json','PACKAGE_INPUTS.json']:(proof/name).write_bytes((RUN/name).read_bytes())
 for step in steps:
  for suffix in step['logs']:(proof/(step['name']+suffix)).write_bytes((RUN/(step['name']+suffix)).read_bytes())
 report={'schema':'otzaria.wave3.rn-semantic-intake.v1','base':BASE,'picked':picked,'sharedCommit':sharedCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),
  'sourcePaths':19,'ownedProductPaths':10,'additiveSourceControlPaths':9,'docsPaths':31,'artifactRowsVerified':30,'actualArchiveMembers':265,'localArchiveMembers':39,
  'sharedHunks':45,'sharedFiles':10,'PBXRegistration':registration,'originalSourcePairsAndInverseVerified':True,'sharedHunkJoin':json.loads(files['HUNK_JOIN.json']),
  'sourceControlsReused':summary,'actualNewPortableCompiles':{'UIRoutingFiles':13,'HostFiles':39,'steps':steps},'reusedSyntaxParses':30,'newCombinedSyntaxParses':4,
  'protectedTrees':trees,'oldVendorContract':'Unchanged and not eligible for new Vendor tree; new chained actual-intake contract and fresh Metro remain mandatory.',
  'AppleSDK':'NOT_RUN','nativeRuns':0,'open':['Annotations original modal facet follow-up','Root-ancestry strict Vendor transition and final source binding','Fresh Metro and original app SDK','Native selectors and EN/HE iPad/iPhone acceptance','Genuine owner approvals and production release']}
 dump(proof/'RESULT.json',report)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record Sefaria source integration and unchanged release gates')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sharedCommit':sharedCommit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),
  'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'portablePackageFiles':52,'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc(),'steps':steps});raise
