#!/usr/bin/env python3
"""Source-only inverse and immutable original-oracle checks; never Swift."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "base"
CANDIDATE = ROOT / "candidate"
EVIDENCE = ROOT / "evidence"
PRODUCTS = [
    "Maktabah.xcodeproj/project.pbxproj",
    "Source/ChavrusaText/Annotations/LocalEditor/AnnotationLocalEditorCloudKit.swift",
    "Source/ChavrusaText/Annotations/LocalEditor/AnnotationLocalEditorCloudOwnership.swift",
    "Source/ChavrusaText/Annotations/LocalEditor/AnnotationLocalEditorModels.swift",
    "Source/ChavrusaText/Annotations/LocalEditor/AnnotationLocalEditorPersistence.swift",
    "Source/ChavrusaText/Annotations/LocalEditor/AnnotationLocalEditorSession.swift",
    "Source/Core/CloudKit/CloudKitCoreManager.swift",
    "Source/Core/Database/SQLiteDatabase.swift",
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def run(*args, cwd):
    return subprocess.check_output(args, cwd=cwd, stderr=subprocess.STDOUT)


def exact_change(text, old, new):
    assert text.count(old) == 1, old[:90]
    return text.replace(old, new, 1)


def main():
    checks = {}
    persistence = PRODUCTS[4]
    assert (CANDIDATE / persistence).read_bytes().startswith((BASE / persistence).read_bytes())
    checks["whole_original_persistence_prefix_unchanged"] = True
    session = PRODUCTS[5]
    before = (BASE / session).read_text(); after = (CANDIDATE / session).read_text()
    boundaries = [
        ("    func read() async", "\n    func prepareSave("),
        ("    func prepareSave(", "\n    func save(_ intent:"),
        ("    func save(_ intent:", "\nextension AnnotationStore {"),
    ]
    for start, end in boundaries:
        body = before[before.index(start):before.index(end, before.index(start))]
        assert after.count(body) == 1
    callback = before[before.index("            // Invalidate rather than installing an old-profile row"):]
    assert after.count(callback) == 1
    checks["original_read_prepare_save_and_default_cloud_callback_bytes_unchanged"] = True
    sqlite = PRODUCTS[-1]
    before = (BASE / sqlite).read_text(); after = (CANDIDATE / sqlite).read_text()
    suffix = before[before.index("    func transaction("):]
    assert after.endswith(suffix)
    checks["whole_original_transaction_and_query_methods_unchanged"] = True
    core = PRODUCTS[-2]
    before = (BASE / core).read_text(); after = (CANDIDATE / core).read_text()
    expected = exact_change(before,
        "    func upload(records: [CKRecord], completion: (@Sendable (Result<Void, any Error>) -> Void)? = nil) {",
        "    func upload(\n        records: [CKRecord],\n        completionNotification: (@Sendable () -> Void)? = nil,\n        completion: (@Sendable (Result<Void, any Error>) -> Void)? = nil\n    ) {")
    start = expected.index("    func upload(\n"); end = expected.index("    func delete(", start)
    upload = exact_change(expected[start:end],
        "            completion?(result)\n            self?.notifyWorkerToSync()",
        "            completion?(result)\n            if let completionNotification {\n                completionNotification()\n            } else {\n                self?.notifyWorkerToSync()\n            }")
    expected = expected[:start] + upload + expected[end:]
    expected = exact_change(expected, "    private func asyncWorker() {",
        "    // A read-only snapshot of the existing configured request. An opt-in owner\n"
        "    // must revalidate its original context before dispatching these same bytes.\n"
        "    func workerRequestSnapshot() -> URLRequest? { makeWorker() }\n\n"
        "    private func asyncWorker() {")
    assert expected == after
    checks["core_exact_reviewed_optional_hook_inverse_and_callback_order"] = True
    registration = json.loads((EVIDENCE / "TARGET_REGISTRATION.json").read_text())
    ids = {value for row in registration["rows"] for value in [row["reference"], *row["build_references"]]}
    project = (CANDIDATE / PRODUCTS[0]).read_text().splitlines(keepends=True)
    restored = "".join(line for line in project if not any(value in line for value in ids))
    assert restored.encode() == (BASE / PRODUCTS[0]).read_bytes()
    assert sum(any(value in line for value in ids) for line in project) == 16
    checks["project_six_memberships_two_files_inverse_all_original_bytes"] = True
    original_paths = [
        "Tests/HQ/local-annotation-editor/LocalAnnotationEditorAcceptance.swift",
        "Tests/HQ/local-annotation-editor/LocalAnnotationEditorBoundary.swift",
        "Tests/HQ/annotation-exchange/AnnotationExchangeAcceptance.swift",
        "Tests/HQ/annotation-exchange/AnnotationExchangeTestSupport.swift",
        "tools/hq-local-annotation-editor-acceptance.py", "tools/hq-annotation-exchange-acceptance.py",
        "Scripts/CI/select-runtime27-toolchain.py",
        "Source/Features/Annotations/Database/AnnotationRepository.swift",
        "Source/Features/Annotations/Database/AnnotationStore.swift",
        "Source/Core/CloudKit/SyncPendingStore.swift",
        "Source/Core/CloudKit/CloudKitUploadDebouncer.swift",
        "Source/Core/CloudKit/CloudKitSyncable.swift",
        "Source/Core/CloudKit/AnnotationSyncHandler.swift",
        "Source/Core/Database/CloudKitSyncManager.swift",
        "Source/Features/Reader/iOS/iOSAnnotationEditorSheet.swift",
    ]
    for path in original_paths:
        assert (BASE / path).read_bytes() == (CANDIDATE / path).read_bytes(), path
    checks["original43_28_assertions_drivers_deadlines_and_remaining_original_product_files"] = True
    old_gate = Path("/workspace/scratch/8c31d602ec0a/local-annotation-apple-v2-20261120/candidate/Scripts/CI/local-annotation-editor-apple.py").read_text()
    new_gate = (CANDIDATE / "Scripts/CI/local-annotation-cloud-apple.py").read_text()
    exchange_start = '    require(exchange.get("status") == "PASS_ACTUAL_SQLITE_COMPONENT"'
    exchange_end = '    return {"local_cases": 43'
    old_exchange_validation = old_gate[old_gate.index(exchange_start):old_gate.index(exchange_end)]
    assert old_exchange_validation in new_gate
    checks["complete_original_exchange_result_and_crash_validation_bytes_unchanged"] = True
    old_tests = Path("/workspace/scratch/8c31d602ec0a/local-annotation-apple-v2-20261120/candidate/Scripts/CI/test-local-annotation-editor-apple.py").read_text()
    new_tests = (CANDIDATE / "Scripts/CI/test-local-annotation-cloud-apple.py").read_text()
    def methods(text):
        return {node.name: node for node in ast.walk(ast.parse(text)) if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")}
    old_methods, new_methods = methods(old_tests), methods(new_tests)
    assert set(old_methods) <= set(new_methods)
    # Every original assert call survives, including the positive original
    # 43/2/28/2 result assertion. New fields add guards; none remove old oracles.
    for name, node in old_methods.items():
        original_asserts = [ast.dump(x, include_attributes=False) for x in ast.walk(node)
            if isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute) and x.func.attr.startswith("assert")]
        new_asserts = [ast.dump(x, include_attributes=False) for x in ast.walk(new_methods[name])
            if isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute) and x.func.attr.startswith("assert")]
        for assertion in original_asserts:
            assert assertion in new_asserts, name
    checks["all32_original_python_test_declarations_and_assert_calls_retained"] = True
    with tempfile.TemporaryDirectory(prefix="otzaria-cloud-product-inverse-") as temporary:
        work = Path(temporary)
        run("git", "init", "-q", cwd=work)
        existing = [path for path in PRODUCTS if (BASE / path).is_file()]
        fresh = [path for path in PRODUCTS if not (BASE / path).exists()]
        for path in existing:
            destination = work / path; destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(BASE / path, destination)
        run("git", "add", "--", *existing, cwd=work)
        for path in PRODUCTS:
            destination = work / path; destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(CANDIDATE / path, destination)
        run("git", "add", "-N", "--", *fresh, cwd=work)
        patch = run("git", "diff", "--no-ext-diff", "--binary", cwd=work)
        patch_path = work / "product.patch"; patch_path.write_bytes(patch)
        run("git", "apply", "--reverse", "--check", str(patch_path), cwd=work)
        run("git", "apply", "--reverse", str(patch_path), cwd=work)
        for path in existing: assert (work / path).read_bytes() == (BASE / path).read_bytes(), path
        for path in fresh: assert not (work / path).exists(), path
    checks["whole_eight_file_git_inverse_matches_originals"] = True
    path = EVIDENCE / "CANDIDATE_SOURCE.patch"
    if path.exists() and path.read_bytes() != patch:
        retained = EVIDENCE / "CANDIDATE_SOURCE_before_account_category.patch"
        if not retained.exists(): retained.write_bytes(path.read_bytes())
    path.write_bytes(patch)
    rows = []
    for relative in PRODUCTS:
        candidate = (CANDIDATE / relative).read_bytes()
        base = (BASE / relative).read_bytes() if (BASE / relative).exists() else None
        rows.append({"path": relative, "candidate_bytes": len(candidate), "candidate_sha256": digest(candidate),
                     "base_sha256": digest(base) if base is not None else None})
    report = {"status": "PASS_SOURCE_INVERSE_ONLY", "checks": checks, "products": rows,
              "whole_product_patch_sha256": digest(patch), "original_files_unchanged": original_paths,
              "original_python_controls": len(old_methods), "current_python_controls": len(new_methods),
              "swift_executed": 0, "apple_executed": 0, "native_executed": 0}
    (EVIDENCE / "SOURCE_PRESERVATION.json").write_bytes((json.dumps(report, indent=2, sort_keys=True) + "\n").encode())
    print(json.dumps({"status": report["status"], "checks": len(checks), "product_files": len(rows),
                      "old_python_controls": len(old_methods), "new_python_controls": len(new_methods)}))


if __name__ == "__main__":
    main()
