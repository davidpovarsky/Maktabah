# CloudKit ownership: in-progress design checkpoint

Source base b19d30d9db402ef267e0d3afcc4dece0be013f24. Candidate source is still byte-identical to base: local Apple43 closure repair and subsequent actual-result collection interrupted implementation. The proposed Core hook is reviewed by Root and B and may now be applied after packaging; it has not yet been applied.

## Approved original hook

PROPOSED_CORE_HOOK.patch adds optional completionNotification before the existing trailing completion, preserving nil/default notification order. workerRequestSnapshot calls the same original makeWorker without side effects. Original delete, CK operation setup and async wrappers remain unchanged; whole inverse proven. No actual account data may enter reports.

## Bounded implementation direction

- Real consumer is the existing MainActor AnnotationLocalEditorSession/AnnotationStore factory. Add an explicit prepared owned-Cloud upload intent and save overload; default save remains equivalent and invokes the existing upload path. The owned overload publishes original cache/tree events but suppresses that one legacy upload, preventing duplicate dispatch.
- At preparation, first validate the original local intent, then synchronously observe CKAccountChanged with a new one-way epoch before fetching the original CKContainer user record ID. Retain original container/privateDatabase/zone, actual returned identity and epoch. No identity means a deferred upload and durable local pending row; never adopt the current account after commit. Revalidate after every await.
- The existing Core's container/database/zone are immutable. Account identity is not. Retaining the Core object alone is not account proof. Keep actual private identity internal; report only fixed outcome categories or explicit test doubles.
- Use the original CloudKitUploadDebouncer per owned operation, preserving its two-second default and avoiding original global UUID-only cross-context batching. Retain it explicitly until flush; its internal task captures weak self. No global singleton replacement and no retry/conflict fallback through the live PendingSyncCoordinator.
- Preserve admission versus completion: once original CloudKit upload is admitted, retain its actual success/error even if owner/account retires. Retirement denies local ACK/delivery; it cannot prove remote cancellation/rollback or atomic OS account isolation. A changed account after admission is a physical/SDK boundary still requiring qualification.

## Exact pending ACK

Original sync_pending has record ID, operation and seconds-resolution queued_at only. Timestamp is not a unique revision. Bind the original ledger mutation/revision/payload/source plus exact pending row, same captured DB connection/lifetime, sqlite total_changes and PRAGMA data_version as conservative no-intervening-write witnesses. Both counters are needed: total_changes observes this connection, data_version observes other connections. This may defer ACK after unrelated writes; it must never erase a newer row.

Use the original SQLite transaction mutex and nested SAVEPOINT semantics. An owned commit wrapper can call original persistence.commit inside one outer transaction, capture provisional queue/counter state after all its own mutations, let the real outer COMMIT complete, then finalize the witness only if an atomic post-COMMIT recheck sees the same values. If any intervening write occurs, return the actual commit receipt with publication deferred. Do not throw away a real commit.

Before upload admission and again before local ACK, atomically validate captured source/version/queue/counters on that same handle. Delete only the exact upload row, never a delete operation. Do not use shared repository/coordinator completion. Validate after SQL while rollback is still possible, and return actual ACK outcome after COMMIT without a post-COMMIT throw. If retirement occurs after committed ACK, report that actual ACK separately from refused owner delivery.

## Worker

Capture the actual original worker URLRequest at preparation. An opt-in notification must not call the global live-settings notifier. Preserve the original 60-second delay, then revalidate original account epoch/identity, owner/source and exact captured request before dispatching those bytes. No new destination, remote rollback or live-exchange authority. Tests may explicitly double waiting/transport; no real delay/network claim from those controls.

Prefer returning the actual local outcome plus an owned publication handle whose completion retains remote/ACK/worker results, so the new explicit API does not keep the editor busy through a 60-second notification wait. The task retains only captured immutable dependencies. Session retirement invalidates admission/publication; cancellation never fabricates that an already-enqueued CK operation did not happen.

Existing global background retry of original pending rows is outside this opt-in attempt and remains unqualified. Do not claim the new immediate path alone qualifies all future background sync or cold account/profile replay. Preserve default behavior; surface the remaining seam explicitly before any live integration.

## Required meaningful controls

Whole original local persistence/SQLite/ledger and new owner code, with explicit CloudKit identity/transport/wait doubles: original identity unavailable; account change and change-return during preparation/debounce/upload/ACK; source/profile switch and return; session retirement; same-UUID newer ledger/pending write including same second; identical queue replacement; other-connection mutation; unrelated write conservative deferral; successful exact original ACK; original pending delete preserved; actual remote error/success retained on post-admission retirement; no legacy double send; worker URL/setting/identity change; exact default inverse. No Swift exists locally; prepare a real bounded Apple component gate and preserve original43 plus exchange28 regressions.
