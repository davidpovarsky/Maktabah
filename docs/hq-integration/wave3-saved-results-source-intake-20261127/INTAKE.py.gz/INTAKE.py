import gzip,hashlib,io,json,pathlib,re,shutil,subprocess,traceback,zipfile

ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='43a8c10e2456a35ff985b282783fefdfdd8e71a6'
BRANCH='codex/otzaria-wave3-integration-20261127'
SOURCE='86fb81e5b9231650b457daf13dbcf0d554a902cc';DOCS='b0fd2d88c7f51db3b2004dccd5ecef10a58d9551'
DONOR_BASE='24cd9291dbc87d799c22a41f0bc73a82c6415bfa'
D='docs/hq-ui-inventory/wave3-saved-results-reveal-20261127'
PROOF='docs/hq-integration/wave3-saved-results-source-intake-20261127'
RUN=pathlib.Path(__file__).parent
events=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 row={'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')}
 if len(p.stdout)<4096 and a[0]not in ['show','cat-file']:row['stdout']=p.stdout.decode(errors='replace')
 events.append(row);dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure: '+repr(a))
 return p.stdout
def rev(ref):return git('rev-parse',ref).decode().strip()
def show(ref,path):return git('show',ref+':'+path)
def body(raw,name):
 s=raw.decode();matches=list(re.finditer(r'\bfunc\s+'+re.escape(name)+r'\s*\(',s));assert len(matches)==1
 a=matches[0].start();i=s.index('{',a);j=i+1;depth=1
 while depth:
  if s[j]=='{':depth+=1
  elif s[j]=='}':depth-=1
  j+=1
 return s[a:j].encode()

try:
 assert rev('HEAD')==BASE and git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 assert not git('status','--porcelain')and shutil.disk_usage(ROOT).free>=1342177280
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 assert rev(SOURCE+'^')==DONOR_BASE and rev(DOCS+'^')==SOURCE
 source_paths=git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines()
 doc_paths=git('diff-tree','--no-commit-id','--name-only','-r',DOCS).decode().splitlines()
 assert len(source_paths)==10 and len(doc_paths)==111
 raw=show(DOCS,D+'/MANIFEST.json');assert sha(raw)=='fa1332f26c89449681a28cc6ccc46c0315cc949fa045252e42a93b9dada293a8'
 manifest=json.loads(raw);assert len(manifest['files'])==110 and manifest['source_commit']==SOURCE
 assert manifest['source_tree']==rev(SOURCE+':Source')=='255b60caa248e6fe0aa95642638c571b579a5d4b'
 assert set(doc_paths)=={D+'/'+r['path']for r in manifest['files']}|{D+'/MANIFEST.json'}
 for row in manifest['files']:
  b=show(DOCS,D+'/'+row['path']);assert len(b)==row['bytes']and sha(b)==row['sha256']
  assert git('ls-tree',DOCS,'--',D+'/'+row['path']).decode().startswith('100644 blob ')
 products=json.loads(show(DOCS,D+'/evidence/PRODUCT_SOURCE_MANIFEST.json'))
 assert products['base']==DONOR_BASE and len(products['files'])==10
 assert sum(r['new']for r in products['files'])==6
 assert set(source_paths)=={r['path']for r in products['files']}
 joins=[]
 for row in products['files']:
  path=row['path'];b=show(SOURCE,path)
  assert len(b)==row['bytes']and sha(b)==row['sha256']and show(DOCS,path)==b
  if row['new']:assert not git('ls-tree',BASE,'--',path)
  else:
   a=show(BASE,path);assert len(a)==row['before_bytes']and sha(a)==row['before_sha256']
   assert a==show(DONOR_BASE,path)
   upstream=show(row['upstream_ref'],path);assert sha(upstream)==row['upstream_sha256']
   assert (a==upstream)==row['baseline_matches_upstream']
  joins.append({**row,'afterBlob':rev(SOURCE+':'+path)})
 effects=json.loads(show(DOCS,D+'/evidence/ORIGINAL_EFFECTS.json'))
 assert len(effects)==15
 for row in effects:
  path=row['path'];a=show(BASE,path);b=show(SOURCE,path)
  if 'method'in row:
   a=body(a,row['method']);b=body(b,row['method']);assert a==b
  elif row.get('unchanged_whole_file'):assert a==b
  elif path.endswith('/ResultsViewModel.swift'):
   addition=b'    let nativeLoadLifetime = OriginalSavedResultsLoadLifetime()\n'
   assert b.count(addition)==1 and b.replace(addition,b'')==a
  elif path.endswith('/Results+Load.swift'):
   addition=b'        let nativeLoad = nativeLoadLifetime.beginOriginalLoad()\n        defer { nativeLoadLifetime.endOriginalLoad(nativeLoad, cancelled: Task.isCancelled) }\n'
   assert b.count(addition)==2 and b.replace(addition,b'')==a
  else:raise AssertionError(row)
  assert len(a)==row['bytes']and sha(a)==row['sha256']
 summary=json.loads(show(DOCS,D+'/RESULT.json'))
 assert summary['controls']=={'load_lifetime':{'passed':14,'failed':0},'service':{'passed':12,'failed':0},'owner_original_paths':{'passed':28,'failed':0},'targeted_existing_completed_case':{'passed':1,'failed':0}}
 assert summary['syntax']['exit']==0 and summary['syntax']['input_count']==18
 receipt=json.loads(show(DOCS,D+'/evidence/remote/evidence/RAW_ARCHIVE_RECEIPT.json'))
 archive=show(DOCS,D+'/'+summary['raw_archive']['path'])
 assert len(archive)==receipt['bytes']==396278 and sha(archive)==receipt['sha256']=='5fa901d73f300fbae8983ce39886f67ce12e452f0ab2e81b26c563d022a297ab'
 assert pathlib.Path(receipt['path']).read_bytes()==archive
 with zipfile.ZipFile(io.BytesIO(archive))as z:
  names=z.namelist();assert len(names)==len(set(names))==receipt['members']==79
  assert len(receipt['files'])==78
  raw_manifest=z.read('RAW_MANIFEST.json')
  assert len(raw_manifest)==13150 and sha(raw_manifest)=='7ded800812ba241bc70b09eeaf3be039091ce5af41da90d7fb930ebcdf50cb52'
  assert json.loads(raw_manifest)==receipt['files']
  assert set(names)=={r['path']for r in receipt['files']}|{'RAW_MANIFEST.json'}
  for row in receipt['files']:
   assert not row['path'].startswith('/')and '..'not in pathlib.PurePosixPath(row['path']).parts
   b=z.read(row['path']);assert len(b)==row['bytes']and sha(b)==row['sha256']
  for row in summary['original_results']:
   b=show(DOCS,D+'/'+row['path']);assert len(b)==row['bytes']and sha(b)==row['sha256']
   assert z.read('controls/attempt-'+str(row['attempt'])+'/RESULT.json')==b
 preserved=['Source/Otzaria','Source/ZayitSearch','Vendor','Maktabah.xcodeproj','Maktabah-iOSUITests','Scripts/CI','.github','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in preserved}
 for path in preserved:assert rev(SOURCE+':'+path)==rev(DONOR_BASE+':'+path)
 git('diff','--check',DONOR_BASE,SOURCE)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',SOURCE)
 source_intake=rev('HEAD')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',DOCS)
 docs_intake=rev('HEAD');assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 for row in joins:assert rev('HEAD:'+row['path'])==row['afterBlob']
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 first=pathlib.Path('/home/ubuntu/.codex/diagnostics/otzaria-wave3-saved-results-source-intake-20261127')
 failure=json.loads((first/'FAILURE.json').read_text())
 assert failure['error']=='AssertionError()' and "len(receipt['files'])==79" in failure['traceback']
 for name in ['RUN.py','EVENTS.json','FAILURE.json']:
  (proof/('ATTEMPT_1_'+name+'.gz')).write_bytes(gzip.compress((first/name).read_bytes(),mtime=0))
 dump(proof/'EXACT_SOURCE_JOIN.json',joins)
 result={'schema':'otzaria.wave3.saved-results-source-intake.v1','base':BASE,'sourceDonor':SOURCE,'docsDonor':DOCS,
  'sourceIntake':source_intake,'docsIntake':docs_intake,'sourceFiles':10,'newFiles':6,'originalHooks':4,'documentationFiles':111,
  'manifestRows':110,'originalFunctionBodiesUnchanged':10,'modelAndLoadInverseExact':True,'unchangedOriginalModels':3,
  'rawArchiveMembers':79,'rawHashedFiles':78,'rawManifestSHA256':sha(raw_manifest),'originalResultsPreserved':6,'actualSourceControls':summary['controls'],'sourceOnlyBoundary':summary['boundary'],
  'firstIntakeFailurePreserved':'Before mutation: expected a self-hashed manifest row. Actual archive contains 78 pinned raw files and the exact manifest of those files, totaling 79 members.',
  'preservedTrees':trees,'sharedWiringAndRegistration':'PENDING_ROOT_COMBINED_INTAKE',
  'scopeLimit':'Original mounted Search parent and warm exact tree reveal. Cross-root/cold node restoration is not claimed.',
  'AppleSDK':'NOT_RUN','native':'NOT_RUN','production':'NOT_RUN','ownerApproval':'NOT_GRANTED'}
 dump(proof/'RESULT.json',result)
 (proof/'README.md').write_text('# Original Saved Results source intake\n\nOnly the ten pinned product files and separate111-file evidence handoff were cherry-picked. All110 manifest rows,79 raw archive members and six original result files were verified, including equality with the actual owned raw archive. Four original preimages were joined to live integration and upstream evidence. Ten original method bodies, the exact inverse of the model/load metadata brackets and three untouched models were independently checked.\n\nThe14 load,12 service and28 owner controls cover distinct source boundaries; the one targeted recatalog rerun strengthens an existing case. Explicit UIKit/database/window substitutes remain explicit. No native, Apple, production or owner approval is claimed. Shared45-hunk wiring, History modal-publication correction, translations, tenth Shortcut and app membership remain a separate root-owned combined intake. The current source supports the original mounted Search parent and warm exact node reveal; cross-root/cold node restoration remains an honest separate requirement.\n')
 git('add','--sparse','--',PROOF)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record verified original Saved Results source intake')
 head=rev('HEAD');assert not git('status','--porcelain')
 assert set(git('diff','--name-only',BASE,'HEAD').decode().splitlines())==set(source_paths+doc_paths)|{PROOF+'/'+p.name for p in proof.iterdir()if p.is_file()}
 assert git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'sourceIntake':source_intake,'docsIntake':docs_intake,'sourceTree':rev('HEAD:Source'),
  'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'freeBytes':shutil.disk_usage(ROOT).free,'nativeRuns':0}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
