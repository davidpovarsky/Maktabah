// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "LongNotePreservationAcceptance",
    platforms: [.macOS(.v15)], dependencies: [.package(path: "/Users/m1/builds/otzaria-sqlite-final-57a4193d-source-20261125/Source/Otzaria/Actions")],
    targets: [.executableTarget(name: "LongNotePreservationAcceptance",
        dependencies: [.product(name: "OtzariaActionCore", package: "actions")],
        swiftSettings: [.unsafeFlags(["-strict-concurrency=complete"])],
        linkerSettings: [.linkedLibrary("sqlite3")])], swiftLanguageModes: [.v6])
