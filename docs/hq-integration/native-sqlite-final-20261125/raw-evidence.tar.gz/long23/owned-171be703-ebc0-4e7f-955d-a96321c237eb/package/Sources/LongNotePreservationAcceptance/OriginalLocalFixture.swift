import Foundation
import Combine
import SQLite3
import Synchronization
import OtzariaActionCore

struct LocalCheckFailure: Error, CustomStringConvertible, Sendable {
    let description: String
    init(_ description: String) { self.description = description }
}
func check(_ value: @autoclosure () throws -> Bool, _ message: String) throws {
    guard try value() else { throw LocalCheckFailure(message) }
}
func rejects<E: Error & Equatable>(_ expected: E, _ work: () throws -> Void) throws {
    do { try work() } catch let error as E { try check(error == expected, "expected \(expected), got \(error)"); return }
    throw LocalCheckFailure("expected \(expected), accepted")
}
@MainActor
func rejectsAsync<E: Error & Equatable>(_ expected: E, _ work: @MainActor () async throws -> Void) async throws {
    do { try await work() } catch let error as E { try check(error == expected, "expected \(expected), got \(error)"); return }
    throw LocalCheckFailure("expected \(expected), accepted")
}
let fixtureFormat = try! AnnotationLocalEditorBodyFormat(identifier: "org.otzaria.acceptance.two-blocks", version: 1)
func fixtureBody(_ suffix: String = "one") -> TorahAnnotationEnvelope.RichBody {
    // Opaque fixture bytes only: not claimed to be Anytype serialization.
    let bytes = Data("{\"blocks\":[{\"id\":\"b1\",\"text\":\"שלום \(suffix)\"},{\"id\":\"b2\",\"text\":\"שני\"}]}".utf8)
    return .init(format: fixtureFormat.identifier, formatVersion: 1, bytes: bytes)
}

@MainActor
struct LocalFixture {
    let url: URL
    let annotation: Annotation
    let db: SQLiteDatabase
    let store = AnnotationStore.shared
    var repository: AnnotationRepository { store.repository }
    var uuid: UUID { UUID(uuidString: annotation.ckRecordId!)! }
    var ledger: AnnotationExchangeLedger { .init(database: db, digest: AnnotationExchangePlatformDigest()) }

    init(root: URL, name: String) throws {
        url = root.appendingPathComponent(name, isDirectory: true)
        AnnotationStore.shared.disconnect()
        try AnnotationStore.shared.setup(at: url)
        let row = Annotation(id: nil, bkId: 28, contentId: 2, range: NSRange(location: 4, length: 5),
            rangeDiacritics: NSRange(location: 6, length: 7), colorHex: "#123456", type: .underline,
            note: "original plain note", createdAt: 1_700_000_001, context: "original context שָׁלוֹם",
            page: 9, part: 1, tags: ["עיון", "second"], ckRecordId: UUID().uuidString,
            lastModified: nil, backendLocator: .init(backend: .fixture, workKey: "fixture:28:2"))
        let id = try AnnotationStore.shared.addAnnotation(row)
        guard let saved = try AnnotationRepository.shared.loadAnnotationById(id), let database = AnnotationRepository.shared.db else {
            throw LocalCheckFailure("original setup/add/load failed")
        }
        annotation = saved; db = database
        try AnnotationRepository.shared.addPendingSync(ckRecordId: "unrelated-delete", operation: "delete")
        CloudKitSyncManager.shared.resetObservation()
    }
    func session(formats: Set<AnnotationLocalEditorBodyFormat> = [fixtureFormat]) throws -> AnnotationLocalEditorSession {
        try store.makeLocalAnnotationEditor(annotation: annotation, supportedFormats: formats)
    }
    func storage(owner: AnnotationLocalEditorLifetime = .init()) throws -> AnnotationLocalEditorPersistence {
        try .init(connection: repository.captureLocalEditorConnection(), annotationID: annotation.id!, annotationUUID: uuid,
            sessionID: UUID(), owner: owner, formats: [fixtureFormat], digest: AnnotationExchangePlatformDigest())
    }
    func scalar(_ query: String, _ parameters: [Any] = []) throws -> Int64 {
        try db.fetch(query: query, parameters: parameters) { $0.int64(at: 0) }.first ?? -1
    }
    func rows() throws -> Data {
        try ledger.captureSource(annotationUUID: uuid).canonicalBytes
    }
    /// Snapshot the actual SQLite image, including rows, tags, ledger and queues.
    func databaseImage() throws -> Data {
        try db.withSerializedAccess {
            var count: sqlite3_int64 = 0
            guard let bytes = sqlite3_serialize(db.dbPointer, "main", &count, 0),
                  count > 0, count <= Int.max else {
                throw LocalCheckFailure("SQLite image unavailable")
            }
            defer { sqlite3_free(bytes) }
            return Data(bytes: bytes, count: Int(count))
        }
    }
    func refusePlainWrite<E: Error & Equatable>(_ expected: E) throws {
        let before = try databaseImage()
        let cloud = CloudKitSyncManager.shared.observation
        var edited = annotation
        edited.note = "stale plain replacement"
        edited.colorHex = "#ffffff"
        edited.tags = ["stale replacement tag"]
        try rejects(expected) { try store.updateAnnotation(edited) }
        try check(try databaseImage() == before, "refused plain Save changed SQLite bytes")
        let after = CloudKitSyncManager.shared.observation
        try check(after.uploads == cloud.uploads && after.trackPending == cloud.trackPending &&
                  after.deletes == cloud.deletes, "refused plain Save published a CloudKit callback")
    }
    func intent(_ session: AnnotationLocalEditorSession, snapshot: AnnotationLocalEditorSnapshot,
                mutation: UUID = UUID(), suffix: String = "one", preview: String = "תצוגה פשוטה") throws -> AnnotationLocalEditorIntent {
        try session.prepareSave(snapshot: snapshot, mutationID: mutation, body: fixtureBody(suffix),
                                textPreview: preview, editorRevision: "fixture-revision-\(suffix)")
    }
    func save(_ session: AnnotationLocalEditorSession, _ intent: AnnotationLocalEditorIntent) async throws -> AnnotationLocalEditorCommitted {
        guard case .committed(let saved) = try await session.save(intent) else { throw LocalCheckFailure("lost expected ownership") }
        return saved
    }
    func initialSave(_ session: AnnotationLocalEditorSession) async throws -> AnnotationLocalEditorCommitted {
        let snapshot = try await session.read()
        return try await save(session, intent(session, snapshot: snapshot))
    }
    func replacePayload(_ saved: AnnotationLocalEditorCommitted, mutate: (inout ActionObject) throws -> Void) throws -> Data {
        var fields = try ActionWireCodec.decodeObject(saved.snapshot.version!.payload)
        try mutate(&fields)
        let bytes = try AnnotationExchangeValidation.canonical(.object(fields))
        let hash = AnnotationExchangePlatformDigest().sha256(bytes)
        try db.execute(query: "UPDATE otzaria_annotation_exchange_versions SET payload_base64=?, payload_digest=? WHERE mutation_id=?;",
                       parameters: [bytes.base64EncodedString(), hash, saved.receipt.mutationID.uuidString])
        return bytes
    }
}

// The actual original SQLite driver calls this synchronous function inside the
// real transaction. No asynchronous waiting or repository state lock is added.
func retireLocalEditorDuringSQL(_ context: OpaquePointer?, _ count: Int32,
                               _ values: UnsafeMutablePointer<OpaquePointer?>?) {
    if let context, let pointer = sqlite3_user_data(context) {
        Unmanaged<AnnotationLocalEditorLifetime>.fromOpaque(pointer).takeUnretainedValue().retire()
    }
    sqlite3_result_int(context, 1)
}

// Fault injection belongs only to this owned fixture connection. The actual
// SQLite update hook proves the preview write ran before its version INSERT
// is denied; the original driver must roll the complete transaction back.
final class LocalSQLiteWriteFailureProbe: Sendable {
    struct Observation: Sendable {
        var previewUpdates = 0
        var deniedVersionInserts = 0
    }
    private let state = Mutex(Observation())
    var observation: Observation { state.withLock { $0 } }
    func recordPreview() { state.withLock { $0.previewUpdates += 1 } }
    func recordRefusal() { state.withLock { $0.deniedVersionInserts += 1 } }
}

func observeLocalPreviewWrite(_ context: UnsafeMutableRawPointer?, _ operation: Int32,
                              _ database: UnsafePointer<CChar>?, _ table: UnsafePointer<CChar>?,
                              _ rowID: sqlite3_int64) {
    guard let context, operation == SQLITE_UPDATE, let database, let table,
          String(cString: database) == "main", String(cString: table) == "annotations" else { return }
    Unmanaged<LocalSQLiteWriteFailureProbe>.fromOpaque(context).takeUnretainedValue().recordPreview()
}

func refuseLocalVersionInsert(_ context: UnsafeMutableRawPointer?, _ operation: Int32,
                              _ table: UnsafePointer<CChar>?, _ column: UnsafePointer<CChar>?,
                              _ database: UnsafePointer<CChar>?, _ trigger: UnsafePointer<CChar>?) -> Int32 {
    guard let context, operation == SQLITE_INSERT, let database, let table,
          String(cString: database) == "main",
          String(cString: table) == "otzaria_annotation_exchange_versions" else { return SQLITE_OK }
    Unmanaged<LocalSQLiteWriteFailureProbe>.fromOpaque(context).takeUnretainedValue().recordRefusal()
    return SQLITE_DENY
}

