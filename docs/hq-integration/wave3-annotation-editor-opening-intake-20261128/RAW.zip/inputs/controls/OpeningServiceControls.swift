import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

struct ServiceControlFailure: Error { let message: String }
@MainActor func serviceRequire(_ value: @autoclosure () -> Bool, _ message: String) throws {
    if !value() { throw ServiceControlFailure(message: message) }
}
@MainActor final class OpeningServiceFixture {
    typealias Service = NativeAnnotationEditorIntentService
    var snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 7)
    var records: [Service.Record]
    var windows: [NativeIntentService.Destination]
    let identifier: String, windowIdentifier: String
    var reads = 0, dispatches = 0, completions = 0
    var mode = "ok"
    var parentCovered = false
    var beforeSecondCatalog: (() -> Void)?
    var afterDispatch: (() -> Void)?
    var beforeCompletion: (() throws -> Void)?
    var observed: UISceneAcknowledgement?
    var completionRequest: UUID?
    init() throws {
        let scene = UIStableID(rawValue: "original-scene")!
        let record = try Service.Record(reference: .init(backend: .otzaria, token: UUID()),
            title: "Original actual annotation row", sceneID: scene)
        let window = NativeIntentService.Destination(backend: .otzaria,
            destination: .init(rawValue: "native.annotations")!, title: "Annotations", sceneID: scene)
        records = [record]; windows = [window]
        identifier = record.id; windowIdentifier = window.id
    }
    func service() -> Service {
        Service(read: {
            self.reads += 1
            if self.reads == 2 { self.beforeSecondCatalog?() }
            if self.parentCovered { throw UIRouteError(.unavailable, "original_list_covered") }
            return .init(snapshot: self.snapshot, records: self.records)
        }, windows: { self.windows }, navigate: { request in
            self.dispatches += 1
            if self.mode == "requires-foreground" {
                self.observed = .requiresForeground; return .requiresForeground
            }
            let route = RouteSpec(requestId: self.mode == "wrong-request" ? UUID() : request.requestID,
                destination: self.mode == "wrong-parent" ? .init(rawValue: "native.annotations.record")! : Service.destination,
                backend: .otzaria,
                presentation: .init(kind: self.mode == "wrong-presentation" ? .currentTab : .sheet),
                state: .init(selectedItemID: self.mode == "missing-item" ? nil : request.record.itemID,
                    sidebarVisible: self.mode == "extra-state" ? true : nil),
                scene: .init(kind: .specific, sceneID: request.window.sceneID, expectedRevision: 5),
                expectedBackendSnapshot: request.expectedSnapshot)
            let receipt = UISceneReceipt(requestId: request.requestID, route: route,
                backendSnapshot: request.expectedSnapshot, sceneID: request.window.sceneID,
                basedOnSceneRevision: 5, appliedSceneRevision: 6)
            let result = UISceneAcknowledgement.acknowledged(receipt)
            self.observed = result; self.afterDispatch?()
            return result
        }, validateCompletion: { request, receipt in
            self.completions += 1; self.completionRequest = request.requestID
            try self.beforeCompletion?()
            guard request.requestID == receipt.requestId,
                  request.record.id == self.identifier, request.window.id == self.windowIdentifier else {
                throw UIRouteError(.staleState, "explicit_original_completed_source_changed")
            }
        })
    }
    func run(_ service: Service) async throws -> UISceneAcknowledgement {
        try await service.open(identifier: identifier, windowIdentifier: windowIdentifier)
    }
}

@main struct OpeningServiceControls {
    @MainActor static func main() async {
        var cases: [[String: Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            do { try await body(); cases.append(["name": name, "pass": true]) }
            catch { cases.append(["name": name, "pass": false, "error": String(describing: error)]) }
        }
        await run("same original annotation entity uses one exact editor route and completion") {
            let f = try OpeningServiceFixture(), service = f.service()
            let result = try await f.run(service)
            try NativeIntentOutcome.requireVisibleAcknowledgement(result)
            try serviceRequire(f.dispatches == 1 && f.completions == 1 && result == f.observed,
                "one host operation and its unchanged actual return")
        }
        await run("original list coverage does not trigger a replacement catalog after ACK") {
            let f = try OpeningServiceFixture(), service = f.service()
            f.afterDispatch = { f.parentCovered = true; f.records = [] }
            _ = try await f.run(service)
            try serviceRequire(f.reads == 2 && f.dispatches == 1 && f.completions == 1,
                "post-effect validation must use only the same completed original proof")
        }
        await run("changed original catalog before dispatch refuses") {
            let f = try OpeningServiceFixture(), service = f.service()
            f.beforeSecondCatalog = { f.records = [] }
            var rejected = false; do { _ = try await f.run(service) } catch { rejected = true }
            try serviceRequire(rejected && f.dispatches == 0 && f.completions == 0, "no effect")
        }
        await run("duplicate original entity identity is rejected before dispatch") {
            let f = try OpeningServiceFixture(), service = f.service(); f.records.append(f.records[0])
            var rejected = false; do { _ = try await f.run(service) } catch { rejected = true }
            try serviceRequire(rejected && f.dispatches == 0, "ambiguous source cannot execute")
        }
        await run("malformed cached identity is refused before source access") {
            let f = try OpeningServiceFixture(), service = f.service()
            var rejected = false
            do { _ = try await service.open(identifier: f.identifier + "=", windowIdentifier: f.windowIdentifier) }
            catch { rejected = true }
            try serviceRequire(rejected && f.reads == 0 && f.dispatches == 0, "no noncanonical entity acceptance")
        }
        await run("foreign original window refuses before operation") {
            let f = try OpeningServiceFixture(), service = f.service()
            var rejected = false
            do { _ = try await service.open(identifier: f.identifier, windowIdentifier: "foreign") }
            catch { rejected = true }
            try serviceRequire(rejected && f.dispatches == 0, "no fallback scene")
        }
        await run("explicit foreground refusal is returned unchanged") {
            let f = try OpeningServiceFixture(), service = f.service(); f.mode = "requires-foreground"
            let result = try await f.run(service)
            try serviceRequire(result == .requiresForeground && f.completions == 0, "refusal is not a receipt")
        }
        for mode in ["wrong-request", "wrong-parent", "wrong-presentation", "missing-item", "extra-state"] {
            await run("\(mode) preserves observed host receipt and refuses") {
                let f = try OpeningServiceFixture(), service = f.service(); f.mode = mode
                do { _ = try await f.run(service); throw ServiceControlFailure(message: "malformed ACK accepted") }
                catch let error as NativeAnnotationEditorIntentService.Failure {
                    try serviceRequire(error.acknowledgement == f.observed && f.dispatches == 1 && f.completions == 0,
                        "actual returned receipt remains available on refusal")
                }
            }
        }
        await run("completed original source removal after actual ACK remains failure with receipt") {
            let f = try OpeningServiceFixture(), service = f.service()
            f.beforeCompletion = { throw UIRouteError(.staleState, "actual_completed_owner_removed") }
            do { _ = try await f.run(service); throw ServiceControlFailure(message: "retired completed owner accepted") }
            catch let error as NativeAnnotationEditorIntentService.Failure {
                try serviceRequire(error.acknowledgement == f.observed && error.status == .staleState && f.completions == 1,
                    "late refusal retains exact observed effect evidence")
            }
        }
        await run("post-effect cancellation preserves observed receipt") {
            let task = Task { @MainActor in
                let f = try OpeningServiceFixture(), service = f.service()
                f.afterDispatch = { withUnsafeCurrentTask { $0?.cancel() } }
                do { _ = try await f.run(service); throw ServiceControlFailure(message: "cancellation accepted") }
                catch let error as NativeAnnotationEditorIntentService.Failure {
                    try serviceRequire(error.acknowledgement == f.observed && error.status == .cancelled,
                        "cancellation is not effect erasure")
                }
            }
            try await task.value
        }
        let report: [String: Any] = [
            "boundary": "complete new service and actual original entity codec + current original Core/UIRouting/Host value types; explicit metadata/navigation/completion providers, no Core operation or native/UI/SDK acceptance",
            "passed": cases.filter { $0["pass"] as? Bool == true }.count,
            "failed": cases.filter { $0["pass"] as? Bool == false }.count,
            "cases": cases]
        print(String(decoding: try! JSONSerialization.data(withJSONObject: report, options: [.sortedKeys, .prettyPrinted]), as: UTF8.self))
        if report["failed"] as? Int != 0 { exit(1) }
    }
}
