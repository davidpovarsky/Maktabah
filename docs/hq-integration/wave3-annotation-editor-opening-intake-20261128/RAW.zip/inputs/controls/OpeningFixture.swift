import Foundation
import OtzariaUIRouting
import ChavrusaUIRoutingHost

struct OpeningControlFailure: Error { let message: String }
@MainActor func require(_ value: @autoclosure () throws -> Bool, _ message: String) throws {
    if try !value() { throw OpeningControlFailure(message: message) }
}
@MainActor func requireRefusal(_ body: () throws -> Void, _ message: String) throws {
    var refused = false
    do { try body() } catch { refused = true }
    try require(refused, message)
}

/// Only platform scheduling, app-domain storage/providers and admission are
/// fixtures. The owner, complete original List callbacks, Session modal/root
/// capture, original controller methods and original child owner are compiled
/// from the exact source joins alongside this file.
@MainActor final class OpeningFixture {
    typealias Opening = MaktabahNativeAnnotationEditorOpening
    typealias Editor = MaktabahNativeAnnotationEditorControls
    let sceneID = UIStableID(rawValue: "original-scene")!
    let requestID = UUID()
    let manager = iOSNavigationManager()
    let window = UIWindow()
    let root = MaktabahNativeRootPublicationSource()
    let tab = Cell(iOSTab.annotations), settings = Cell(false)
    let presentation = MaktabahNativeWorkspacePresentationBinding()
    let list = OriginalAnnotationListBoundary()
    let originalAnnotation = Annotation(id: 7)
    var workspace: Workspace!
    var projection: MaktabahNativeWorkspaceProjectionSource!
    var bindings: MaktabahNativeSceneBindings!
    var session: OpeningSceneBoundary!
    var selection: MaktabahNativeAnnotationSelectionBinding!
    var controller: iOSAnnotationViewController!
    var editor: Editor!
    var opening: Opening!
    var record: NativeAnnotationSelectionIntentService.Record!
    var foreground = true
    var grantCurrent = true
    var onGrant: (() -> Void)?
    var onOriginalTagPublication: (() -> Void)?
    var onEditorSnapshot: (() -> Void)?
    var onEditorParent: (() -> Void)?
    var editorChangedCalls = 0
    var openingInvalidations = 0
    var reportCalls = 0
    var form: UIView!
    var body: UITextView!
    var childToken = UUID(), childViewID = UUID()
    var childAnnotation: Annotation
    var childInitialized = true, childBlocked = false, childAllowsPlainEditing = true

    init() throws {
        childAnnotation = originalAnnotation
        BackendCoordinator.shared.activeBackendID = .otzaria
        BackendCoordinator.shared.isTransitioning = false
        BackendCoordinator.shared.activeCapabilities = true
        workspace = Workspace(manager); projection = .init(workspace)
        bindings = .init(manager: manager, selectedTab: root.selectionBinding(tab.binding),
            showSettings: root.settingsBinding(settings.binding), rootPublications: root)
        session = .init(bindings: bindings, workspace: projection, presentation: presentation, window: window)
        list.nativeRoutingSession = session
        selection = .init(sceneID: sceneID, bindings: bindings, workspaceSource: projection,
            workspacePresentation: presentation, commonReady: { true },
            windowReady: { [unowned self] in self.foreground },
            retainWindow: { [unowned self] in try self.session.retainOriginalWindowObservation() },
            readForeignPresentations: {}, originalUIKitPresentationWillChange: { [unowned self] owner in
                self.session.originalAnnotationPresentationWillChange(owner: owner)
                self.onOriginalTagPublication?()
            })
        session.annotationSelectionBinding = selection
        selection.install(changed: {}, invalidated: {})
        editor = .init(sceneID: sceneID,
            retainWindow: { [unowned self] in try self.session.retainOriginalWindowObservation() },
            retainParent: { _ in
                throw OpeningControlFailure(message: "opening must not issue a warm editor retention")
            })
        session.annotationEditorControls = editor
        opening = .init(sceneID: sceneID, selection: selection, editor: editor,
            retainWindow: { [unowned self] in try self.session.retainOriginalWindowObservation() },
            retainParent: { [unowned self] owner, annotation, request in
                try self.session.captureOpening(owner: owner, annotation: annotation, requestID: request)
            }, windowReady: { [unowned self] in self.foreground })
        session.annotationEditorOpening = opening
        opening.install(changed: {}, invalidated: { [unowned self] in self.openingInvalidations += 1 })
        editor.install(changed: { [unowned self] in
            self.editorChangedCalls += 1
            self.opening.originalEditorHostDidChange()
        }, invalidated: {})
        list.appear()
        controller = .init(window: window, model: manager.annotationViewModel)
        controller.controlSeed([("one", originalAnnotation)])
        controller.nativeRoutingAttach(binding: selection, owner: list.nativeRoutingOwner,
            blocked: { [unowned self] in
                self.list.editingAnnotation != nil || self.list.isImporting || self.list.isExporting
                    || self.list.showOverwriteDialog || self.list.showImportAlert || self.list.showMissingBookAlert
            })
        record = try selection.catalog().first
        try require(record != nil, "fixture must expose the one actual original row")
        form = UIView(window); body = UITextView(window)
    }
    func retain() throws { try opening.retain(record: record, requestID: requestID) }
    func begin() throws {
        try opening.begin(requestID: requestID) { [unowned self] in
            self.onGrant?()
            guard self.grantCurrent else { throw UIRouteError(.cancelled, "explicit_original_admission_retired") }
        }
    }
    func apply() throws { try opening.apply(requestID: requestID) }
    func applyOriginal() throws { try retain(); try begin(); try apply() }
    var access: Editor.Access {
        .init(viewID: childViewID,
            attachment: .init(controls: editor, listOwner: list.nativeRoutingOwner,
                parentCurrent: { [unowned self] in
                    self.onEditorParent?()
                    return self.list.editingAnnotation == self.childAnnotation
                }),
            snapshot: { [unowned self] in
                self.onEditorSnapshot?()
                return .init(annotation: self.childAnnotation, note: self.childAnnotation.note,
                    nativeNote: self.body.text, tags: self.childAnnotation.tags.joined(separator: ","),
                    color: "original-color", underline: false, initialized: self.childInitialized,
                    allowsPlainEditing: self.childAllowsPlainEditing, blocked: self.childBlocked)
            }, bodyTextView: { [unowned self] in self.body })
    }
    func mountChild() { editor.attach(access: access, token: childToken, view: form) }
    func childLayout() { editor.originalLayoutDidChange(viewID: childViewID) }
    func detachChild() { editor.detach(viewID: childViewID, token: childToken, view: form) }
    func makeVisible(coverage: Bool = false) throws {
        try applyOriginal()
        if coverage { list.disappear() }
        mountChild()
        try require(opening.hasVisibleSurface(requestID: requestID), "same original editor must be visible")
    }
    func report() throws {
        try opening.withValidatedSurface(requestID: requestID) { [unowned self] in self.reportCalls += 1 }
    }
    func complete() throws {
        try report()
        opening.finish(requestID: requestID, completed: true)
        opening.releaseSource(requestID: requestID)
        try opening.validateCompletedSurface(requestID: requestID)
    }
}
