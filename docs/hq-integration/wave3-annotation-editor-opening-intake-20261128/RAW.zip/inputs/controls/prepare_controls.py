from pathlib import Path
import hashlib,json,re,argparse
arguments=argparse.ArgumentParser();arguments.add_argument('--output');arguments.add_argument('--manifest');args=arguments.parse_args()
r=Path(__file__).resolve().parents[1]; c=r/'candidate'; p=r/'proposal/candidate'; out=Path(args.output) if args.output else r/'controls/generated';out.mkdir(exist_ok=True)
def reference(name):
 saved=r/'reference'/name
 return saved if saved.exists() else Path(name)
joins=[]
def read(rel,proposal=False): return ((p if proposal else c)/rel).read_text()
def extract(text,needle):
 start=text.index(needle);brace=text.index('{',start);n=1;i=brace+1;string=False;line=False;block=0
 while n:
  ch=text[i];nxt=text[i:i+2]
  if line:
   if ch=='\n':line=False
  elif block:
   if nxt=='/*':block+=1;i+=1
   elif nxt=='*/':block-=1;i+=1
  elif string:
   if ch=='\\':i+=1
   elif ch=='"':string=False
  elif nxt=='//':line=True;i+=1
  elif nxt=='/*':block=1;i+=1
  elif ch=='"':string=True
  elif ch=='{':n+=1
  elif ch=='}':n-=1
  i+=1
 return text[start:i]
def frag(rel,needle,proposal=False):
 text=read(rel,proposal);f=extract(text,needle)
 joins.append({'source':('proposal/' if proposal else 'candidate/')+rel,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'needle':needle,'fragment_bytes':len(f.encode()),'fragment_sha256':hashlib.sha256(f.encode()).hexdigest()})
 return f
def portable(text):
 assert text.startswith('#if os(iOS)\n') and text.endswith('#endif\n')
 return text.removeprefix('#if os(iOS)\n').removesuffix('#endif\n').replace('import UIKit\n','').replace('@preconcurrency import Combine\n','')
I='Source/ChavrusaText/UIRoutingHost/Integration/';H='Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/';L='Source/Features/Annotations/iOS/AnnotationListView.swift';V='Source/Features/Annotations/iOS/iOSAnnotationViewController.swift';T='Source/Features/Annotations/iOS/iOSAnVC+TagFilter.swift'
for f in ['MaktabahNativeAnnotationEditorOpening.swift','MaktabahNativeAnnotationSelectionBinding.swift','MaktabahNativeAnnotationEditorControls.swift']:
 text=read(I+f);(out/f).write_text(portable(text));joins.append({'source':'candidate/'+I+f,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'projection':'only outer iOS wrapper/UIKit/Combine imports removed; all original implementation bodies unchanged'})
service=read(H+'NativeAnnotationEditorIntentService.swift')
(out/'NativeAnnotationEditorIntentService.swift').write_text('import ChavrusaUIRoutingHost\n'+service)
joins.append({'source':'candidate/'+H+'NativeAnnotationEditorIntentService.swift','source_sha256':hashlib.sha256(service.encode()).hexdigest(),'projection':'one import of the current original Host module for standalone membership; complete new service body unchanged'})
identifier=reference('annotations-selection-analysis/controls/ActualNativeReaderEntityIdentifier.swift').read_text()
(out/'ActualNativeReaderEntityIdentifier.swift').write_text(identifier)
joins.append({'source':'annotations-selection-analysis/controls/ActualNativeReaderEntityIdentifier.swift','source_sha256':hashlib.sha256(identifier.encode()).hexdigest(),'projection':'exact original internal entity codec, compiled locally because package-internal visibility is not exported by Host'})
# These actual current sources already have an independent 85-input join in the
# preserved warm editor evidence. The new runner must rejoin current Git again.
for src,dest,wrapped in [
 ('annotations-editor-controls-implementation/controls/ActualComponentSourceObservation.swift','ActualComponentSourceObservation.swift',False),
 ('annotations-editor-controls-implementation/controls/OriginalWindowObservation.swift','OriginalWindowObservation.swift',True),
 ('annotations-selection-analysis/packet/Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeAnnotationListPublication.swift','ActualListPublication.swift',True)]:
 text=reference(src).read_text();(out/dest).write_text(portable(text) if wrapped else text)
 joins.append({'source':src,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'projection':'outer platform wrapper/imports only' if wrapped else 'exact retained actual source'})
rootPath='rn-inner-semantics/root-shared-intake/candidate/Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSearchEntry.swift'
rootSource=reference(rootPath).read_text();rootBody=extract(rootSource,'@MainActor\nfinal class MaktabahNativeRootPublicationSource')
(out/'ActualOriginalRootPublication.swift').write_text('import Foundation\nimport ChavrusaUIRoutingHost\n\n'+rootBody+'\n')
joins.append({'source':rootPath,'source_sha256':hashlib.sha256(rootSource.encode()).hexdigest(),'git_path':I+'MaktabahNativeSearchEntry.swift','needle':'@MainActor\nfinal class MaktabahNativeRootPublicationSource','fragment_sha256':hashlib.sha256(rootBody.encode()).hexdigest(),'projection':'complete actual current original root-publication class, standalone imports only'})
# Explicit domain/platform boundary comes from the preserved original Annotation
# controls. Extend only the declared Apple/Store/model stand-ins for this task.
b=reference('annotations-selection-analysis/controls/ExplicitAnnotationBoundary.swift').read_text()
a=b.index('@MainActor final class MaktabahNativeComponentSourceObservation');z=b.index('@MainActor final class AnyCancellable',a);b=b[:a]+b[z:]
b=b.replace('enum AppMode { case viewer, annotations }','enum AppMode { case viewer, annotations }')
b=b.replace('enum iOSTab { case viewer, annotations; func isAvailable(for enabled: Bool) -> Bool { enabled } }','enum iOSTab { case viewer, annotations; var canonical: Self { self }; var appMode: AppMode { self == .annotations ? .annotations : .viewer }; func isAvailable(for enabled: Bool) -> Bool { enabled } }')
b=b.replace('    var activeBackendID = BackendID.otzaria\n','    @ObservationIgnored let objectWillChange = EventPublisher()\n    var activeBackendID = BackendID.otzaria { willSet { objectWillChange.send() } }\n')
b=b.replace('    var generation: UInt64 = 0\n    var isTransitioning = false\n','    var generation: UInt64 = 0 { willSet { objectWillChange.send() } }\n    var isTransitioning = false { willSet { objectWillChange.send() } }\n')
b=b.replace('    var visible = true\n','    var visible = true\n    var isTopSheet = true\n    var isUserInteractionEnabled = true\n    var isFirstResponder = false\n    func becomeFirstResponder() -> Bool { isFirstResponder = true; return true }\n',1)
b=b.replace('@MainActor class UICollectionViewCell:', '@MainActor final class UITextView: UIView { var isEditable = true; var text: String? = "draft" }\n@MainActor final class UITextField: UIView { var isEnabled = true; var text: String? = "one" }\n@MainActor class UICollectionViewCell:')
b=b.replace('    static func evidence(_ view: UIView) -> Evidence {','    static func isVisible(_ view: UIView, in sheet: UIView, window: UIWindow, sceneID: UIStableID) -> Bool {\n        view.visible && sheet.visible && view.window === window && sheet.window === window\n            && window.windowScene?.session.persistentIdentifier == sceneID.rawValue\n    }\n    static func evidence(_ view: UIView) -> Evidence {')
b=b.replace('    var tagFilterMode = 0 { willSet { nativeRoutingPublication.willPublish() } }','    var tagFilterMode = TagFilterMode.or { willSet { nativeRoutingPublication.willPublish() } }\n    var allTags = ["one", "two"]\n    var availableTags: [String] { allTags }\n    func availableTags(for tags: Set<String>) -> [String] { allTags }\n    func toggleTagSelection(_ tag: String) { if selectedTags.contains(tag) { selectedTags.remove(tag) } else { selectedTags.insert(tag) } }')
b=b.replace('struct MappingEvent: Equatable { var epoch: UInt64; var phase = 0 }','enum MappingPhase { case available, changing }\nstruct MappingEvent: Equatable { var epoch: UInt64; var phase = MappingPhase.available }')
b=b.replace('    func mappingOwnershipObservation() -> Mapping?', '    var mappingOwnershipSource: MappingSource { source }\n    func mappingOwnershipObservation() -> Mapping?')
b+='''
extension String { init(localized value: String) { self = value } }
enum TagFilterMode { case and, or }
@MainActor enum MaktabahNativeAnnotationEditorGeometry {
    static func ownsTopSheet(_ view: UIView, sceneID: UIStableID) -> Bool {
        view.isTopSheet && view.window?.windowScene?.session.persistentIdentifier == sceneID.rawValue
    }
}
@MainActor class UIViewController { }
@MainActor final class SheetBoundary {
    enum Detent { case medium, large; static func medium() -> Self { .medium }; static func large() -> Self { .large } }
    var detents: [Detent] = []
    var prefersGrabberVisible = false
}
@MainActor final class UIHostingController<Content>: UIViewController {
    let rootView: Content
    let sheetPresentationController: SheetBoundary? = .init()
    init(rootView: Content) { self.rootView = rootView }
}
@MainActor struct TagFilterSelectionView {
    let allTags: [String]
    let selectedTags: Set<String>
    let isAndMode: Bool
    let availableTagsProvider: (Set<String>) -> [String]
    let onToggle: (String) -> Void
    let onSelectAll: () -> Void
    let onDeselectAll: () -> Void
}
@MainActor final class ForeignSurfaceBoundary { var presentationFacets = 0; var isRequestedOrMounted = false }
@MainActor final class NoteOwnerBoundary { var current: Int?; var presentationActive = false }
'''
# Cases in a Swift enum cannot also have same-name functions. Use original
# UIKit-style static factory signatures as explicitly declared stand-ins.
b=b.replace('enum Detent { case medium, large; static func medium() -> Self { .medium }; static func large() -> Self { .large } }','struct Detent { static func medium() -> Self { .init() }; static func large() -> Self { .init() } }')
(out/'ExplicitOpeningBoundary.swift').write_text(b)
# Actual complete original collection methods, including current expansion and
# the real new tag prepublication. Surrounding storage/UICollectionView is above.
oldCapsule=reference('annotations-selection-analysis/controls/ActualAnnotationControllerCapsule.swift').read_text()
a=oldCapsule.index('@MainActor final class iOSAnnotationViewController {');z=oldCapsule.index('    private func toggleGroup',a)
controller=oldCapsule[a:z]
controller=controller.replace('    var isViewLoaded = true\n','''    var presentedViewController: UIViewController?
    var presentCalls = 0
    var beforePresent: (() -> Void)?
    func present(_ value: UIViewController, animated: Bool) {
        beforePresent?(); presentCalls += 1; presentedViewController = value
    }
    func originalDismissed() { presentedViewController = nil }
    var isViewLoaded = true
''')
# The node and exact original owned methods are copied verbatim.
for needle in ['    private func toggleGroup(', '    private func setOriginalGroupExpanded(', '    struct NativeRoutingRow {',
 '    func nativeRoutingAttach(', '    func nativeRoutingDetach()', '    func nativeRoutingOriginalModalWillPresent()',
 '    func nativeRoutingRows()', '    func nativeRoutingMatches(', '    func nativeRoutingReveal(', '    func nativeRoutingSelectedCell(', '    fileprivate func nativeRoutingPublishLayout()']:
 controller+=frag(V,needle)+'\n\n'
controller+=frag(T,'    func presentTagFilterSheet()')+'\n'
# Keep actual historical pre-hook body as the source counterexample; it calls
# the same explicit UIKit presentation/dismissal boundary.
baselineTag=(r/'baseline'/T).read_text();old=extract(baselineTag,'    func presentTagFilterSheet()').replace('func presentTagFilterSheet()', 'func originalBeforeHookTagPresentation()',1)
joins.append({'source':'baseline/'+T,'source_sha256':hashlib.sha256(baselineTag.encode()).hexdigest(),'needle':'    func presentTagFilterSheet()','fragment_sha256':hashlib.sha256(extract(baselineTag,'    func presentTagFilterSheet()').encode()).hexdigest(),'projection':'historical exact complete original tag method; method name changed only for side-by-side source counterexample'})
controller+=old+'\n}\n'
(out/'ActualOriginalController.swift').write_text('import Foundation\nimport OtzariaUIRouting\n'+controller)
# Exact original Session modal/publication and complete existing root-window
# capture bodies. Unrelated scene/UI providers are explicit fixture boundaries.
Session='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
session='''import Foundation
import Observation
import OtzariaUIRouting
import ChavrusaUIRoutingHost
@MainActor final class OpeningSceneBoundary {
    let sceneID = UIStableID(rawValue: "original-scene")!
    let bindings: MaktabahNativeSceneBindings
    let workspaceProjectionSource: MaktabahNativeWorkspaceProjectionSource?
    let workspacePresentation: MaktabahNativeWorkspacePresentationBinding?
    var mounted = true
    var annotationEditorOpening: MaktabahNativeAnnotationEditorOpening?
    var annotationSelectionBinding: MaktabahNativeAnnotationSelectionBinding?
    var annotationEditorControls: MaktabahNativeAnnotationEditorControls?
    var annotationPresentationOwner: UUID?
    var annotationPresentationBlocked: (@MainActor () -> Bool)?
    var annotationPresentationPublicationRevision: UInt64? = 0
    let originalAnnotationPresentationPublication = NativeComponentSourcePublication()
    var window: UIWindow
    var originalWindowRevision: UInt64 = 0
    var readerBinding: Bool?, readerTabBinding: Bool?, workspaceSelectionBinding: Bool?
    var searchResultsBinding: Bool?, searchContinuationOwner: Bool?
    var hasOriginalWorkspacePresentation = false, hasOriginalSefariaSurface = false
    var sefariaSurfaceBinding: ForeignSurfaceBoundary?, savedResultsBinding: ForeignSurfaceBoundary?
    var studyChatPresentationID: UUID?
    var searchPresentationBlocked: (() -> Bool)?
    var searchRevision: UInt64 = 0
    var noteEditorOwner: NoteOwnerBoundary?
    init(bindings: MaktabahNativeSceneBindings, workspace: MaktabahNativeWorkspaceProjectionSource,
         presentation: MaktabahNativeWorkspacePresentationBinding, window: UIWindow) {
        self.bindings = bindings; workspaceProjectionSource = workspace
        workspacePresentation = presentation; self.window = window
    }
    func retainOriginalWindowObservation() throws -> MaktabahNativeWindowObservation {
        let revision = originalWindowRevision, window = window
        return .init(window: window, validateOriginalOwner: { [weak self] actual in
            guard let self else { return false }
            return self.mounted && self.window === actual && actual === window && self.originalWindowRevision == revision
        })
    }
    func retainHistorySearchPresentationObservation() throws -> @MainActor () throws -> Void {
        let revision = searchRevision
        return { [weak self] in
            guard let self, self.searchRevision == revision, self.searchPresentationBlocked?() != true else {
                throw UIRouteError(.staleState, "explicit_foreign_search_boundary")
            }
        }
    }
    func captureOpening(owner: UUID, annotation: Annotation, requestID: UUID) throws -> @MainActor () throws -> Void {
        try captureAnnotationOpeningWindow(owner: owner, annotation: annotation, requestID: requestID)
    }
    func foreignAnnotationProof() throws -> @MainActor () throws -> Void { try retainOriginalAnnotationPresentationObservation() }
'''
for needle in ['    func observeAnnotationPresentation(', '    func originalAnnotationPresentationWillChange(', '    func removeAnnotationPresentation(',
 '    private func advanceOriginalAnnotationPresentationPublication()', '    private var hasOriginalAnnotationPresentation:',
 '    func retainOriginalAnnotationPresentationObservation()', '    private func retainOriginalAnnotationEditorPresentationObservation(',
 '    private func retainOriginalAnnotationOpeningPresentationObservation(', '    private var isOriginalAnnotationEditorRootReady:',
 '    func captureHistoryReaderWindow()', '    private func captureHistoryReaderWindow(annotationEditorOwner:',
 '    private func captureHistoryReaderWindow(searchPresentation:', '    private func captureAnnotationOpeningWindow(']:
 session+=frag(Session,needle,True)+'\n\n'
session+='}\n';(out/'ActualOpeningSession.swift').write_text(session)
# The real List callback/State setter with only SwiftUI storage and lifecycle
# scheduling replaced by explicit fixture fields/invocations.
listSource=read(L);baselineList=(r/'baseline'/L).read_text()
listType='''import Foundation
import ChavrusaUIRoutingHost
@MainActor final class OriginalAnnotationListBoundary {
    var nativeRoutingSession: OpeningSceneBoundary?
    let nativeRoutingOwner = UUID()
    var isExporting = false, isImporting = false, showOverwriteDialog = false
    var showImportAlert = false, showMissingBookAlert = false
    var editingAnnotation: Annotation? { didSet { assignmentCount += 1 } }
    var assignmentCount = 0
    func ordinaryEdit(_ annotation: Annotation) throws { try presentOriginalAnnotationEditor(annotation) }
    func applyOriginalEdit(_ annotation: Annotation, permit: MaktabahNativeAnnotationEditorOpening.EditPermit) throws {
        try presentOriginalAnnotationEditor(annotation, permit: permit)
    }
    func originalEqualModalWrite() { nativeModalWillChange() }
'''
for needle in ['    private func nativeModalWillChange()', '    private var nativeEditorOpeningState:',
 '    private func presentOriginalAnnotationEditor(', '    private func nativeModalBinding<']:
 f=frag(L,needle)
 if needle=='    private func nativeModalBinding<':
  # The original SwiftUI View is a value type. Its explicit test storage is a
  # reference type, so Swift requires an explicit self capture on this escaping
  # setter. No getter/setter effect statement or ordering is changed.
  assert f.count('set: { value in')==1
  f=f.replace('set: { value in','set: { [self] value in')
  joins[-1]['projection']='only explicit [self] capture for reference fixture replacing original value View; complete original getter/setter effect body unchanged'
 listType+=f+'\n\n'
for name,needle in [('appear','.onAppear {'),('disappear','.onDisappear {')]:
 body=extract(listSource,needle);body=body[body.index('{')+1:-1]
 joins.append({'source':'candidate/'+L,'source_sha256':hashlib.sha256(listSource.encode()).hexdigest(),'needle':needle,'fragment_sha256':hashlib.sha256(body.encode()).hexdigest(),'projection':'exact closure body in explicitly invoked fixture lifecycle method'})
 if name=='appear':
  for before,after in [('isBlocked: {','isBlocked: { [self] in'),('read: { nativeEditorOpeningState }','read: { [self] in nativeEditorOpeningState }'),('edit: { annotation, permit in','edit: { [self] annotation, permit in')]:
   assert body.count(before)==1;body=body.replace(before,after)
  joins[-1]['projection']='original onAppear effect statements/order; only explicit [self] captures for reference fixture replacing original value View'
 listType+='    func '+name+'() {'+body+'}\n'
old=extract(baselineList,'.onDisappear {');old=old[old.index('{')+1:-1]
joins.append({'source':'baseline/'+L,'source_sha256':hashlib.sha256(baselineList.encode()).hexdigest(),'needle':'.onDisappear {','fragment_sha256':hashlib.sha256(old.encode()).hexdigest(),'projection':'exact original pre-coverage callback body in separately invoked historical fixture method'})
listType+='    func beforeCoverageDisappearance() {'+old+'}\n}\n'
(out/'ActualOriginalList.swift').write_text(listType)
oldChild=r/'evidence/pre-independent-child-publication/candidate'/I/'MaktabahNativeAnnotationEditorControls.swift'
if oldChild.exists():
 text=oldChild.read_text();(out/'BeforeIndependentChildState.swift').write_text(portable(text))
 joins.append({'source':str(oldChild.relative_to(r)),'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'projection':'reviewed original child proof before independent State publication; only outer platform wrapper/UIKit import removed'})
(Path(args.manifest) if args.manifest else r/'controls/SOURCE_EXTRACTIONS.json').write_text(json.dumps({'boundary':'Actual source bodies; explicit Apple, Combine, app Store/model/workspace/provider/storage scheduling boundaries; no UIKit/Core execution/persistence/receipt acceptance','joins':joins},indent=2)+'\n')
print(json.dumps({'actual_joins':len(joins),'generated_files':len(list(out.glob('*.swift'))),'bytes':sum(f.stat().st_size for f in out.glob('*.swift'))},indent=2))
