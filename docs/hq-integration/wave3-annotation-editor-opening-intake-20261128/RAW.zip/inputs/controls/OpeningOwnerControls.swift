import Foundation
import OtzariaUIRouting
import ChavrusaUIRoutingHost

@main struct OpeningOwnerControls {
    @MainActor static func main() {
        var cases: [[String: Any]] = []
        func run(_ name: String, _ body: () throws -> Void) {
            do { try body(); cases.append(["name": name, "pass": true]) }
            catch { cases.append(["name": name, "pass": false, "error": String(describing: error)]) }
        }
        let historicalTag = CommandLine.arguments.contains("--historical-tag")
        let historicalCoverage = CommandLine.arguments.contains("--historical-coverage")
        let lateCoverageOnly = CommandLine.arguments.contains("--late-coverage-only")
        func tagABA() throws {
            let f = try OpeningFixture(); try f.retain()
            if historicalTag { f.controller.originalBeforeHookTagPresentation() }
            else { f.controller.presentTagFilterSheet() }
            f.controller.originalDismissed()
            try require(f.controller.presentCalls == 1, "ordinary original UIKit presentation must run exactly once")
            try requireRefusal({ try f.opening.validateSource(requestID: f.requestID) },
                "actual original tag open/close must permanently retire the retained source")
        }
        func originalCoverage() throws {
            let f = try OpeningFixture(); try f.applyOriginal()
            if historicalCoverage { f.list.beforeCoverageDisappearance() } else { f.list.disappear() }
            f.mountChild()
            try require(f.opening.hasVisibleSurface(requestID: f.requestID),
                "one actual original covered-list callback must preserve the same editor proof")
            try f.complete()
            try require(f.list.assignmentCount == 1 && f.list.editingAnnotation == f.originalAnnotation,
                "one original State assignment only")
        }
        func originalLateCoverage() throws {
            let f = try OpeningFixture(); try f.makeVisible()
            f.list.disappear()
            try f.complete()
            try require(f.list.assignmentCount == 1 && f.reportCalls == 1,
                "same child record proof survives only the one authorized original coverage without reapply")
        }
        if historicalTag { run("original pre-hook tag method admits open/close stale source", tagABA) }
        else if historicalCoverage { run("original pre-allowance List removal rejects its actual editor", originalCoverage) }
        else if lateCoverageOnly { run("same actual child before original List coverage remains valid", originalLateCoverage) }
        else {
            run("same cached row invokes original Edit once and actual child completion") {
                let f = try OpeningFixture(); try f.makeVisible(); try f.complete()
                try require(f.list.assignmentCount == 1 && f.reportCalls == 1, "one setter and report")
                try require(f.controller.collectionView.selections == 0 && f.controller.collectionView.scrolls == 0,
                    "opening does not invoke selected-row reveal or Reader navigation")
                try require(f.opening.observedItem(requestID: f.requestID) == f.record.itemID,
                    "actual completed editor retains the same selected record")
                try requireRefusal({ try f.report() }, "completed proof is not active reporting authority")
            }
            run("one actual List coverage retains editor while original counter advances", originalCoverage)
            run("second original coverage cannot reuse the one consumed event") {
                let f = try OpeningFixture(); try f.makeVisible(coverage: true)
                f.list.disappear()
                try requireRefusal({ try f.report() }, "repeated coverage must revoke")
            }
            run("same actual child before original List coverage remains valid", originalLateCoverage)
            run("unowned List removal preserves original behavior and refuses") {
                let f = try OpeningFixture(); try f.retain(); f.list.disappear()
                try requireRefusal({ try f.begin() }, "pre-effect disappearance must revoke")
                try require(f.list.assignmentCount == 0, "no editor State assignment")
            }
            run("real tag open close retires source without suppressing original present", tagABA)
            run("fresh discovery blocks actual original tag sheet and returns only after close") {
                let f = try OpeningFixture(); f.controller.presentTagFilterSheet()
                try require(!f.selection.isAvailable && !f.opening.isAvailable, "actual presented controller blocks source")
                try require(try f.selection.catalog().isEmpty, "no fresh entity while tag sheet is open")
                f.controller.originalDismissed()
                let fresh = try f.selection.catalog()
                try require(fresh.count == 1 && fresh[0].id != f.record.id, "fresh publication uses a different identity")
                try requireRefusal({ try f.retain() }, "cached pre-modal entity remains stale")
            }
            run("tag prepublication callback cannot recapture a source before UIKit present") {
                let f = try OpeningFixture(); var offered: [NativeAnnotationSelectionIntentService.Record] = []
                f.onOriginalTagPublication = { offered = (try? f.selection.catalog()) ?? [] }
                f.controller.presentTagFilterSheet()
                try require(offered.isEmpty && f.controller.presentCalls == 1, "pre-open publication is closed, ordinary present still runs")
            }
            run("same record ID with changed full Annotation is refused") {
                let f = try OpeningFixture(); try f.retain()
                var changed = f.originalAnnotation; changed.note += "changed"
                // Explicit collection-boundary replacement; full actual original
                // nativeRoutingMatches still compares every Annotation field.
                f.controller.controlSeed([("one", changed)])
                try requireRefusal({ try f.begin() }, "same SQL ID must not substitute another record value")
                try require(f.list.assignmentCount == 0, "no editor write")
            }
            run("actual model search ABA cannot rearm a captured row") {
                let f = try OpeningFixture(); try f.retain()
                f.manager.annotationViewModel.searchText = "changed"
                f.manager.annotationViewModel.searchText = ""
                try requireRefusal({ try f.begin() }, "original source publication must remain stale after ABA")
            }
            run("actual model equal setter publication retires") {
                let f = try OpeningFixture(); try f.retain()
                f.manager.annotationViewModel.searchScope = f.manager.annotationViewModel.searchScope
                try requireRefusal({ try f.begin() }, "equal original setter must not resurrect proof")
            }
            run("actual original Store event retires independent editor row proof") {
                let f = try OpeningFixture(); try f.retain(); AnnotationStore.shared.events.send()
                try requireRefusal({ try f.begin() }, "original Store publication must revoke")
            }
            run("original backend transition ABA retires independent row proof") {
                let f = try OpeningFixture(); try f.retain()
                BackendCoordinator.shared.isTransitioning = true; BackendCoordinator.shared.isTransitioning = false
                try requireRefusal({ try f.begin() }, "aborted backend transition must revoke")
            }
            run("same controller detach and reattach cannot transfer old source") {
                let f = try OpeningFixture(); try f.retain(); f.controller.nativeRoutingDetach()
                f.controller.nativeRoutingAttach(binding: f.selection, owner: f.list.nativeRoutingOwner, blocked: { false })
                try requireRefusal({ try f.begin() }, "controller identity alone does not restore old attachment")
            }
            run("original root selection ABA retires") {
                let f = try OpeningFixture(); try f.retain()
                f.bindings.selectedTab.wrappedValue = .viewer; f.bindings.selectedTab.wrappedValue = .annotations
                try requireRefusal({ try f.begin() }, "same final tab must not restore root authority")
            }
            run("actual retained window ownership revision rejects return to same window") {
                let f = try OpeningFixture(); try f.retain()
                f.session.originalWindowRevision += 1
                try requireRefusal({ try f.begin() }, "same final window cannot borrow a newer ownership revision")
            }
            run("original ordinary equal modal event refuses automated assignment") {
                let f = try OpeningFixture(); try f.retain(); try f.begin(); f.list.originalEqualModalWrite()
                try requireRefusal({ try f.apply() }, "unowned equal State publication must revoke")
                try require(f.list.assignmentCount == 0, "no native assignment after source retirement")
            }
            run("ordinary UI setter remains unrestricted during pending navigation") {
                let f = try OpeningFixture(); try f.retain(); try f.begin()
                try f.list.ordinaryEdit(f.originalAnnotation)
                try require(f.list.assignmentCount == 1 && f.list.editingAnnotation == f.originalAnnotation,
                    "metadata retirement must not block the original ordinary setter")
                try requireRefusal({ try f.apply() }, "original UI mutation does not authorize another native assignment")
            }
            run("reentrant ordinary edit during canonical validator owns only its ordinary write") {
                let f = try OpeningFixture(); try f.retain(); try f.begin()
                f.onGrant = { f.onGrant = nil; try? f.list.ordinaryEdit(f.originalAnnotation) }
                try requireRefusal({ try f.apply() }, "retired canonical action must stop after callback")
                try require(f.list.assignmentCount == 1, "only the original user setter may write")
            }
            run("missing real Session prepublication cannot be replaced by permit bookkeeping") {
                let f = try OpeningFixture()
                f.opening.attachList(owner: f.list.nativeRoutingOwner,
                    read: { .init(editingAnnotation: f.list.editingAnnotation, blockedByOtherPresentation: false) },
                    edit: { annotation, permit in
                        try permit.willSet(owner: f.list.nativeRoutingOwner, annotation: annotation)
                        f.opening.originalModalWillChange(owner: f.list.nativeRoutingOwner)
                        try permit.didPublish(owner: f.list.nativeRoutingOwner)
                        f.list.editingAnnotation = annotation
                        try permit.didSet(owner: f.list.nativeRoutingOwner, annotation: annotation)
                    })
                try f.retain(); try f.begin()
                try requireRefusal({ try f.apply() }, "actual monotonic Session publication is mandatory")
                try require(f.list.assignmentCount == 0, "counter check occurs before the original State assignment")
            }
            run("release during original validation prevents effect") {
                let f = try OpeningFixture(); try f.retain(); try f.begin()
                f.onGrant = { f.onGrant = nil; f.opening.releaseSource(requestID: f.requestID) }
                try requireRefusal({ try f.apply() }, "released exact pending cannot continue from a copied local")
                try require(f.list.assignmentCount == 0, "no effect")
            }
            run("retired original admission prevents effect") {
                let f = try OpeningFixture(); try f.retain(); try f.begin(); f.grantCurrent = false
                try requireRefusal({ try f.apply() }, "same request still requires original admission")
                try require(f.list.assignmentCount == 0, "no effect")
            }
            run("first actual child lifecycle is required before a visible proof") {
                let f = try OpeningFixture(); try f.applyOriginal()
                try require(!f.opening.hasVisibleSurface(requestID: f.requestID), "no model-only acknowledgement")
                f.mountChild(); try f.report()
                try require(f.editorChangedCalls > 0 && f.reportCalls == 1, "original attach callback supplied first identity")
            }
            run("same actual child may finish original initialization before first proof") {
                let f = try OpeningFixture(); try f.applyOriginal(); f.childInitialized = false; f.mountChild()
                try require(!f.opening.hasVisibleSurface(requestID: f.requestID), "uninitialized original editor must wait")
                f.editor.originalStateWillChange(viewID: f.childViewID)
                f.childInitialized = true; f.childLayout(); try f.report()
                try require(f.list.assignmentCount == 1, "initialization did not reapply Edit")
            }
            run("child detach and same-view reattach cannot transfer retained opening") {
                let f = try OpeningFixture(); try f.makeVisible(); f.detachChild(); f.mountChild()
                try requireRefusal({ try f.report() }, "original attachment ABA must remain retired")
            }
            run("child snapshot with a different complete record cannot acknowledge") {
                let f = try OpeningFixture(); try f.applyOriginal(); f.childAnnotation.note += "foreign"; f.mountChild()
                try requireRefusal({ try f.report() }, "same ID in another editor value is not a receipt")
            }
            run("child actual window and top-sheet visibility are mandatory") {
                let f = try OpeningFixture(); try f.applyOriginal(); f.form.isTopSheet = false; f.mountChild()
                try require(!f.opening.hasVisibleSurface(requestID: f.requestID), "covered editor cannot acknowledge")
                f.form.isTopSheet = true; f.form.visible = false
                try require(!f.opening.hasVisibleSurface(requestID: f.requestID), "hidden original view cannot acknowledge")
                f.form.visible = true; f.form.window = UIWindow()
                try requireRefusal({ try f.report() }, "foreign window cannot acknowledge")
            }
            run("editor initialization callback reentry cannot substitute a host") {
                let f = try OpeningFixture(); try f.applyOriginal()
                f.onEditorSnapshot = { f.onEditorSnapshot = nil; f.opening.releaseSource(requestID: f.requestID) }
                f.mountChild()
                try requireRefusal({ try f.report() }, "callback release invalidates the captured first child")
            }
            run("original child State publication after first proof permanently retires") {
                let f = try OpeningFixture(); try f.makeVisible()
                f.editor.originalStateWillChange(viewID: f.childViewID)
                try requireRefusal({ try f.report() }, "equal original editor State write must invalidate first proof")
            }
            run("ordinary editor State mutation after legitimate late coverage still revokes") {
                let f = try OpeningFixture(); try f.makeVisible(); f.list.disappear()
                f.editor.originalStateWillChange(viewID: f.childViewID)
                f.childAnnotation.note += "new draft"
                try requireRefusal({ try f.report() }, "independent child publication must not exempt real editor State")
            }
            run("allowsPlainEditing remains unchanged for opening a readonly original editor") {
                let f = try OpeningFixture(); f.childAllowsPlainEditing = false; try f.makeVisible(); try f.report()
                try require(!f.editor.isAvailable(anchor: .body) && !f.editor.isAvailable(anchor: .tags),
                    "opening cannot grant plain-edit control availability")
            }
            run("reentrant release during surface report preserves effect but refuses acknowledgement") {
                let f = try OpeningFixture(); try f.makeVisible()
                try requireRefusal({
                    try f.opening.withValidatedSurface(requestID: f.requestID) {
                        f.reportCalls += 1; f.opening.releaseSource(requestID: f.requestID)
                    }
                }, "report callback cannot release then reuse captured authority")
                try require(f.list.assignmentCount == 1 && f.reportCalls == 1,
                    "actual original effect remains honestly observable after refusal")
            }
            run("original modal revision exhaustion fails closed before Edit") {
                let f = try OpeningFixture(); f.session.annotationPresentationPublicationRevision = .max
                try requireRefusal({ try f.retain() }, "no first edit may consume an exhausted counter")
                try require(f.list.assignmentCount == 0, "no effect")
            }
            run("Session pre-unmount retirement cannot borrow own coverage allowance") {
                let f = try OpeningFixture(); try f.applyOriginal()
                f.opening.originalSessionWillUnmount()
                f.session.removeAnnotationPresentation(owner: f.list.nativeRoutingOwner)
                f.mountChild()
                try requireRefusal({ try f.report() }, "unmount is never the one owned List cover")
            }
        }
        let report: [String: Any] = [
            "boundary": "actual original/new owner/List/Session/controller/child source bodies + original Core/UI/Host value modules; explicit UIKit, SwiftUI scheduling, geometry, Store/model/backend/admission boundaries; no Core operation, UIKit, app, persistence, SDK or native acceptance",
            "source_variant": historicalTag ? "actual original pre-hook tag method, new owner harness" : (historicalCoverage ? "actual original pre-allowance List disappearance, new owner harness" : "candidate actual source bodies"),
            "passed": cases.filter { $0["pass"] as? Bool == true }.count,
            "failed": cases.filter { $0["pass"] as? Bool == false }.count,
            "cases": cases]
        print(String(decoding: try! JSONSerialization.data(withJSONObject: report, options: [.sortedKeys, .prettyPrinted]), as: UTF8.self))
        if report["failed"] as? Int != 0 { exit(1) }
    }
}
