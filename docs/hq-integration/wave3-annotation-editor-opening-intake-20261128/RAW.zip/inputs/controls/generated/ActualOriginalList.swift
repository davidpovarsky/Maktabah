import Foundation
import ChavrusaUIRoutingHost
@MainActor final class OriginalAnnotationListBoundary {
    var nativeRoutingSession: OpeningSceneBoundary?
    let nativeRoutingOwner = UUID()
    var isExporting = false, isImporting = false, showOverwriteDialog = false
    var showImportAlert = false, showMissingBookAlert = false
    var editingAnnotation: Annotation? { didSet { assignmentCount += 1 } }
    var assignmentCount = 0
    func ordinaryEdit(_ annotation: Annotation) throws { try presentOriginalAnnotationEditor(annotation) }
    func applyOriginalEdit(_ annotation: Annotation, permit: MaktabahNativeAnnotationEditorOpening.EditPermit) throws {
        try presentOriginalAnnotationEditor(annotation, permit: permit)
    }
    func originalEqualModalWrite() { nativeModalWillChange() }
    private func nativeModalWillChange() {
        nativeRoutingSession?.originalAnnotationPresentationWillChange(owner: nativeRoutingOwner)
    }

    private var nativeEditorOpeningState: MaktabahNativeAnnotationEditorOpening.ListState {
        .init(editingAnnotation: editingAnnotation,
            blockedByOtherPresentation: isExporting || isImporting || showOverwriteDialog
                || showImportAlert || showMissingBookAlert)
    }

    private func presentOriginalAnnotationEditor(_ annotation: Annotation,
        permit: MaktabahNativeAnnotationEditorOpening.EditPermit? = nil) throws {
        try permit?.willSet(owner: nativeRoutingOwner, annotation: annotation)
        nativeModalWillChange()
        try permit?.didPublish(owner: nativeRoutingOwner)
        editingAnnotation = annotation
        try permit?.didSet(owner: nativeRoutingOwner, annotation: annotation)
    }

    private func nativeModalBinding<Value>(_ original: Binding<Value>) -> Binding<Value> {
        Binding(get: { original.wrappedValue }, set: { [self] value in
            nativeModalWillChange(); original.wrappedValue = value
        })
    }

    func appear() {
                nativeRoutingSession?.observeAnnotationPresentation(owner: nativeRoutingOwner, isBlocked: { [self] in
                    isExporting || isImporting || showOverwriteDialog || showImportAlert
                        || showMissingBookAlert || editingAnnotation != nil
                })
                nativeRoutingSession?.annotationEditorOpening?.attachList(owner: nativeRoutingOwner,
                    read: { [self] in nativeEditorOpeningState },
                    edit: { [self] annotation, permit in
                        try presentOriginalAnnotationEditor(annotation, permit: permit)
                    })
            }
    func disappear() {
                let opening = nativeRoutingSession?.annotationEditorOpening
                let coverage = opening?.originalListWillDisappear(owner: nativeRoutingOwner,
                    annotation: editingAnnotation)
                nativeRoutingSession?.removeAnnotationPresentation(owner: nativeRoutingOwner)
                opening?.originalListDidDisappear(owner: nativeRoutingOwner, coverage: coverage)
            }
    func beforeCoverageDisappearance() { nativeRoutingSession?.removeAnnotationPresentation(owner: nativeRoutingOwner) }
}
