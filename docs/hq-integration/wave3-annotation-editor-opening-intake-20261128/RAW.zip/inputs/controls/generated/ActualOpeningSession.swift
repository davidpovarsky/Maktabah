import Foundation
import Observation
import OtzariaUIRouting
import ChavrusaUIRoutingHost
@MainActor final class OpeningSceneBoundary {
    let sceneID = UIStableID(rawValue: "original-scene")!
    let bindings: MaktabahNativeSceneBindings
    let workspaceProjectionSource: MaktabahNativeWorkspaceProjectionSource?
    let workspacePresentation: MaktabahNativeWorkspacePresentationBinding?
    var mounted = true
    var annotationEditorOpening: MaktabahNativeAnnotationEditorOpening?
    var annotationSelectionBinding: MaktabahNativeAnnotationSelectionBinding?
    var annotationEditorControls: MaktabahNativeAnnotationEditorControls?
    var annotationPresentationOwner: UUID?
    var annotationPresentationBlocked: (@MainActor () -> Bool)?
    var annotationPresentationPublicationRevision: UInt64? = 0
    let originalAnnotationPresentationPublication = NativeComponentSourcePublication()
    var window: UIWindow
    var originalWindowRevision: UInt64 = 0
    var readerBinding: Bool?, readerTabBinding: Bool?, workspaceSelectionBinding: Bool?
    var searchResultsBinding: Bool?, searchContinuationOwner: Bool?
    var hasOriginalWorkspacePresentation = false, hasOriginalSefariaSurface = false
    var sefariaSurfaceBinding: ForeignSurfaceBoundary?, savedResultsBinding: ForeignSurfaceBoundary?
    var studyChatPresentationID: UUID?
    var searchPresentationBlocked: (() -> Bool)?
    var searchRevision: UInt64 = 0
    var noteEditorOwner: NoteOwnerBoundary?
    init(bindings: MaktabahNativeSceneBindings, workspace: MaktabahNativeWorkspaceProjectionSource,
         presentation: MaktabahNativeWorkspacePresentationBinding, window: UIWindow) {
        self.bindings = bindings; workspaceProjectionSource = workspace
        workspacePresentation = presentation; self.window = window
    }
    func retainOriginalWindowObservation() throws -> MaktabahNativeWindowObservation {
        let revision = originalWindowRevision, window = window
        return .init(window: window, validateOriginalOwner: { [weak self] actual in
            guard let self else { return false }
            return self.mounted && self.window === actual && actual === window && self.originalWindowRevision == revision
        })
    }
    func retainHistorySearchPresentationObservation() throws -> @MainActor () throws -> Void {
        let revision = searchRevision
        return { [weak self] in
            guard let self, self.searchRevision == revision, self.searchPresentationBlocked?() != true else {
                throw UIRouteError(.staleState, "explicit_foreign_search_boundary")
            }
        }
    }
    func captureOpening(owner: UUID, annotation: Annotation, requestID: UUID) throws -> @MainActor () throws -> Void {
        try captureAnnotationOpeningWindow(owner: owner, annotation: annotation, requestID: requestID)
    }
    func foreignAnnotationProof() throws -> @MainActor () throws -> Void { try retainOriginalAnnotationPresentationObservation() }
    func observeAnnotationPresentation(owner: UUID, isBlocked: @escaping @MainActor () -> Bool) {
        guard mounted else { return }
        if annotationPresentationOwner != owner {
            advanceOriginalAnnotationPresentationPublication()
            annotationPresentationOwner = owner; annotationPresentationBlocked = isBlocked
            annotationSelectionBinding?.retire()
            annotationEditorOpening?.retire()
        } else { annotationPresentationBlocked = isBlocked }
    }

    func originalAnnotationPresentationWillChange(owner: UUID) {
        guard mounted, annotationPresentationOwner == owner else { return }
        annotationEditorOpening?.originalModalWillChange(owner: owner)
        advanceOriginalAnnotationPresentationPublication()
        annotationSelectionBinding?.originalModalWillChange(owner: owner)
    }

    func removeAnnotationPresentation(owner: UUID) {
        guard annotationPresentationOwner == owner else { return }
        advanceOriginalAnnotationPresentationPublication()
        let revision = annotationPresentationPublicationRevision
        annotationSelectionBinding?.retire()
        // The original list can be covered by its own editor/import/export
        // presentation. Preserve its blocker until that actual owner clears it.
        guard annotationPresentationBlocked?() != true,
              annotationPresentationOwner == owner,
              annotationPresentationPublicationRevision == revision else { return }
        annotationPresentationOwner = nil; annotationPresentationBlocked = nil
    }

    private func advanceOriginalAnnotationPresentationPublication() {
        // Fixed weak one-way latches only. No user/State callback runs under a
        // source lock; RN claims can be refused before the original setter.
        originalAnnotationPresentationPublication.invalidateRetainedSources()
        defer { annotationEditorControls?.retire() }
        guard let revision = annotationPresentationPublicationRevision, revision < .max else {
            annotationPresentationPublicationRevision = nil
            return
        }
        annotationPresentationPublicationRevision = revision + 1
    }

    private var hasOriginalAnnotationPresentation: Bool {
        guard let revision = annotationPresentationPublicationRevision else { return true }
        let owner = annotationPresentationOwner
        let blocked = annotationPresentationBlocked?() == true
            || annotationSelectionBinding?.hasOriginalUIKitPresentation == true
        return blocked || annotationPresentationPublicationRevision != revision || annotationPresentationOwner != owner
    }

    func retainOriginalAnnotationPresentationObservation() throws -> @MainActor () throws -> Void {
        guard mounted, let revision = annotationPresentationPublicationRevision else {
            throw UIRouteError(.unavailable, "original_annotation_presentation_unavailable")
        }
        let owner = annotationPresentationOwner
        let originalList = annotationSelectionBinding
        let validate: @MainActor () throws -> Void = { [weak self, weak originalList] in
            guard let self, self.mounted,
                  self.annotationSelectionBinding === originalList,
                  originalList?.hasOriginalUIKitPresentation != true,
                  self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  self.annotationPresentationBlocked?() != true else {
                throw UIRouteError(.staleState, "original_annotation_presentation_changed")
            }
            // The original blocker is a getter callback. It may publish a new
            // owner/state; final equality alone cannot restore that source.
            guard self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  self.annotationSelectionBinding === originalList,
                  originalList?.hasOriginalUIKitPresentation != true else {
                throw UIRouteError(.staleState, "original_annotation_presentation_changed")
            }
        }
        try validate()
        return validate
    }

    private func retainOriginalAnnotationEditorPresentationObservation(owner: UUID) throws
        -> @MainActor () throws -> Void {
        guard mounted, let revision = annotationPresentationPublicationRevision,
              annotationPresentationOwner == owner, let original = annotationEditorControls,
              original.originalListOwner == owner else {
            throw UIRouteError(.unavailable, "original_annotation_editor_parent_unavailable")
        }
        let validate: @MainActor () throws -> Void = { [weak self, weak original] in
            guard let self, let original, self.mounted,
                  self.annotationEditorControls === original,
                  self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  original.originalListOwner == owner,
                  self.annotationPresentationBlocked?() == true,
                  original.isAvailable() else {
                throw UIRouteError(.staleState, "original_annotation_editor_parent_changed")
            }
            // Both getters above may synchronously publish/detach an owner.
            guard self.mounted, self.annotationEditorControls === original,
                  self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  original.originalListOwner == owner else {
                throw UIRouteError(.staleState, "original_annotation_editor_parent_changed")
            }
        }
        try validate()
        return validate
    }

    private func retainOriginalAnnotationOpeningPresentationObservation(owner: UUID,
        annotation: Annotation, requestID: UUID) throws -> @MainActor () throws -> Void {
        guard mounted, let revision = annotationPresentationPublicationRevision, revision < .max,
              annotationPresentationOwner == owner, let opening = annotationEditorOpening,
              let originalList = annotationSelectionBinding,
              !originalList.hasOriginalUIKitPresentation else {
            throw UIRouteError(.unavailable, "original_annotation_opening_parent_unavailable")
        }
        let validate: @MainActor () throws -> Void = { [weak self, weak opening, weak originalList] in
            guard let self, let opening, let originalList, self.mounted,
                  self.annotationEditorOpening === opening, self.annotationSelectionBinding === originalList,
                  self.annotationPresentationOwner == owner,
                  opening.allowsOriginalPresentationRevision(requestID: requestID, owner: owner,
                    initial: revision, current: self.annotationPresentationPublicationRevision) else {
                throw UIRouteError(.staleState, "original_annotation_opening_parent_changed")
            }
            let editing = try opening.originalListIsEditing(requestID: requestID, owner: owner, annotation: annotation)
            guard self.annotationPresentationBlocked?() == editing,
                  editing || !originalList.hasOriginalUIKitPresentation else {
                throw UIRouteError(.staleState, "original_annotation_opening_parent_changed")
            }
            // Recheck both the callback's original owner and monotonic revision.
            guard self.mounted, self.annotationEditorOpening === opening,
                  self.annotationSelectionBinding === originalList, self.annotationPresentationOwner == owner,
                  opening.allowsOriginalPresentationRevision(requestID: requestID, owner: owner,
                    initial: revision, current: self.annotationPresentationPublicationRevision),
                  try opening.originalListIsEditing(requestID: requestID, owner: owner, annotation: annotation) == editing,
                  editing || !originalList.hasOriginalUIKitPresentation else {
                throw UIRouteError(.staleState, "original_annotation_opening_parent_changed")
            }
        }
        try validate()
        return validate
    }

    private var isOriginalAnnotationEditorRootReady: Bool {
        mounted && readerBinding == nil && readerTabBinding == nil && workspaceSelectionBinding == nil
            && searchResultsBinding == nil && searchContinuationOwner == nil
            && bindings.selectedTab.wrappedValue.canonical == .annotations
            && bindings.manager.currentMode == .annotations
            && bindings.isPresentationReady && !bindings.showSettings.wrappedValue
            && !hasOriginalWorkspacePresentation && !hasOriginalSefariaSurface
            && savedResultsBinding?.isRequestedOrMounted != true
            && studyChatPresentationID == nil && searchPresentationBlocked?() != true
            && noteEditorOwner?.current == nil && noteEditorOwner?.presentationActive != true
    }

    func captureHistoryReaderWindow() throws -> @MainActor () throws -> Void {
        try captureHistoryReaderWindow(annotationEditorOwner: nil)
    }

    private func captureHistoryReaderWindow(annotationEditorOwner: UUID?) throws -> @MainActor () throws -> Void {
        let searchPresentation = try retainHistorySearchPresentationObservation()
        let annotationPresentation: @MainActor () throws -> Void
        if let annotationEditorOwner {
            annotationPresentation = try retainOriginalAnnotationEditorPresentationObservation(owner: annotationEditorOwner)
        } else { annotationPresentation = try retainOriginalAnnotationPresentationObservation() }
        return try captureHistoryReaderWindow(searchPresentation: searchPresentation,
            annotationPresentation: annotationPresentation)
    }

    private func captureHistoryReaderWindow(searchPresentation: @escaping @MainActor () throws -> Void,
        annotationPresentation: @escaping @MainActor () throws -> Void) throws -> @MainActor () throws -> Void {
        let originalWindow = try retainOriginalWindowObservation()
        _ = try originalWindow.validate()
        let manager = bindings.manager
        guard mounted, !bindings.showSettings.wrappedValue, bindings.isPresentationReady,
              let root = bindings.rootPublications,
              let rootRevision = root.selectionRevision, let settingsRevision = root.settingsRevision,
              let modeRevision = manager.nativeModePresentationRevision,
              let bookRevision = manager.selectedBookPresentationRevision,
              let source = workspaceProjectionSource, source.isAuthoritative,
              let workspace = try source.read(), workspace.attached, !workspace.isSwitching,
              let mapping = workspace.mappingOwnershipObservation(),
              mapping.coverage == .liveNativeSetters, mapping.scene == sceneID.rawValue,
              mapping.owner == ObjectIdentifier(manager), mapping.source.event.phase == .available,
              mapping.source.event.epoch == mapping.epoch else {
            throw UIRouteError(.unavailable, "history_reader_window_owner_unavailable")
        }
        let selected = bindings.selectedTab.wrappedValue
        guard selected == selected.canonical, manager.currentMode == selected.appMode else {
            throw UIRouteError(.unavailable, "history_reader_window_not_committed")
        }
        let observation = MaktabahNativeComponentSourceObservation {
            _ = manager.openTabs; _ = manager.activeTabId; _ = manager.selectedBook
            _ = manager.selectedContentId; _ = manager.currentMode
            _ = manager.selectedBookForInfo; _ = manager.showingTabsList; _ = manager.alertMessage
            _ = manager.activeReaderViewModel?.isPopoverPresented
            _ = manager.activeReaderViewModel?.readerInspectorVisible
            _ = DonationManager.shared.showDonationSheet
            _ = workspace.attached; _ = workspace.isSwitching
            _ = workspace.mappingOwnershipSource.event
        }
        let validate: @MainActor () throws -> Void = { [weak self, weak manager, weak workspace] in
            try searchPresentation()
            try annotationPresentation()
            _ = try originalWindow.validate()
            try observation.validate()
            guard let self, let manager, let workspace, self.mounted,
                  self.bindings.manager === manager, self.bindings.rootPublications === root,
                  root.selectionRevision == rootRevision, root.settingsRevision == settingsRevision,
                  self.bindings.selectedTab.wrappedValue == selected,
                  manager.currentMode == selected.appMode,
                  manager.nativeModePresentationRevision == modeRevision,
                  manager.selectedBookPresentationRevision == bookRevision,
                  !self.bindings.showSettings.wrappedValue, self.bindings.isPresentationReady,
                  self.workspaceProjectionSource === source, source.isAuthoritative,
                  let current = try source.read(), current === workspace,
                  workspace.attached, !workspace.isSwitching,
                  let actual = workspace.mappingOwnershipObservation(),
                  actual.coverage == .liveNativeSetters, actual.source === mapping.source,
                  actual.owner == mapping.owner, actual.scene == mapping.scene,
                  actual.epoch == mapping.epoch, actual.projection == mapping.projection,
                  actual.source.event.phase == .available, actual.source.event.epoch == actual.epoch else {
                throw UIRouteError(.staleState, "history_reader_window_owner_changed")
            }
            try observation.validate()
            _ = try originalWindow.validate()
            try searchPresentation()
            try annotationPresentation()
        }
        try validate()
        return validate
    }

    private func captureAnnotationOpeningWindow(owner: UUID, annotation: Annotation, requestID: UUID) throws
        -> @MainActor () throws -> Void {
        guard isOriginalAnnotationEditorRootReady, let original = annotationEditorOpening else {
            throw UIRouteError(.unavailable, "original_annotation_opening_root_unavailable")
        }
        let observation = MaktabahNativeComponentSourceObservation {
            _ = mounted; _ = studyChatPresentationID
            _ = workspacePresentation?.originalStateRevision
            _ = sefariaSurfaceBinding?.presentationFacets
            _ = savedResultsBinding?.isRequestedOrMounted
        }
        let search = try retainHistorySearchPresentationObservation()
        let annotations = try retainOriginalAnnotationOpeningPresentationObservation(owner: owner,
            annotation: annotation, requestID: requestID)
        let root = try captureHistoryReaderWindow(searchPresentation: search, annotationPresentation: annotations)
        let validate: @MainActor () throws -> Void = { [weak self, weak original] in
            try observation.validate(); try root()
            guard let self, let original, self.annotationEditorOpening === original,
                  self.isOriginalAnnotationEditorRootReady else {
                throw UIRouteError(.staleState, "original_annotation_opening_root_changed")
            }
            try root(); try observation.validate()
        }
        try validate()
        return validate
    }

}
