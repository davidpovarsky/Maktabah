# Original annotation editor opening: source-control boundary

The new implementation and proposed shared wiring are based on immutable root `759da82e7eb443634a4396c4768e44bca53f9001`. The host run has not started. This document records the intended boundary and must be joined to the actual execution receipts before reporting a result.

## Actual source under test

The owner executable compiles the complete new opening owner, the complete current selection binding with its readonly original-row capture, the complete original warm-editor control owner plus the independent child-record publication, and the complete new semantic service. Only outer iOS conditionals and UIKit/Combine imports are removed in the declared portable projections. The service receives an import of the existing Host module because this standalone executable is outside its normal package membership.

The executable also compiles exact original function bodies for:

- The List's Edit setter, original modal prepublication, onAppear owner registration and onDisappear callback.
- The Session's original annotation modal owner/counter callbacks, unchanged removal and counter-advance bodies, the opening-specific readonly facet, and the complete existing root/window/workspace capture body.
- The original controller's cached-row enumeration, full Annotation comparison, current reveal/expansion methods, attachment lifecycle, and complete original tag-sheet presentation method.
- The existing original window observation, original list publication, original root publication, and actual component-source observation with its original backend publisher.

`controls/SOURCE_EXTRACTIONS.json` records the full source hashes and exact extracted fragments. The original SwiftUI List is a value type; its reference-based fixture adds explicit `[self]` captures solely where Swift requires them. The original effect statements and their order remain unchanged. Those adaptations are recorded separately from product changes.

## Explicit boundaries

UIKit controllers, diffable snapshots, native view geometry, SwiftUI State storage and lifecycle scheduling, the Annotation/Store/model/backend providers, the scene's actual UIKit window provider, and the live admission callback are explicitly declared fixtures. The executable does not claim to implement or exercise Apple's scheduling, actual database persistence, a Core navigation operation, a simulator, an installed app, a real App Intent transport, or a native receipt.

The service executable compiles the complete new service and original entity codec against the current original Core/UIRouting/Host value modules. Metadata, host navigation and completed-source providers are explicit boundaries. A constructed acknowledgement is a service-validation input, never a claimed application acknowledgement.

The original readonly module closure is 31 Core, 13 UI and 41 Host source files. The runner rejoins every compiled input, complete module membership, module/library hash and actual `ldd` resolution before using them. Host lookup precedes UI lookup because the older RN output directory also contains a Host module. Existing products and caches are not modified.

## Preserved counterexamples

Three bounded variants use preserved actual bodies, with unchanged expectations:

1. The original pre-hook tag presentation body is invoked alongside the new owner. The old open/close sequence should demonstrate that no prepublication retired its already-retained source. This is an original-function counterexample, not a claim that the new feature existed in the historical app.
2. The original pre-allowance List disappearance body is invoked after the real Edit setter. It should demonstrate why the unchanged removal counter needs the separately consumed passive coverage allowance.
3. The reviewed child owner `969f24be…` is compiled with the same complete caller chain. It should refuse the legitimate child-before-coverage order because the warm-control retirement invalidates its first child proof. The candidate's independent child-record State publication supports both coverage orders without rearming a retired proof.

Actual product mutation, source replacement, cancellation or a second original modal event must still refuse. The warm-control request proof and the original Session removal/counter bodies remain unchanged.

## Capacity and qualification

The proposed new rootfs task scope is limited to 80 MiB. The aggregate lane budget remains 300 MiB, Data reserve remains 2 GiB, and rootfs reserve remains 1.25 GiB. A fresh private module cache belongs to this scope; no path-bound PCM is copied from another cache. The runner must stop only its own process group if a gate fails, preserve partial outputs, and report failure.

Full-file Debug/Release frontend parsing is syntax evidence only. Apple SDK typechecking, real UIKit ordering for both coverage sequences, system App Intent discovery/delivery, native selected-record/editor geometry, the original full native suites and physical device acceptance remain **NOT_RUN** until the qualified application is available.
