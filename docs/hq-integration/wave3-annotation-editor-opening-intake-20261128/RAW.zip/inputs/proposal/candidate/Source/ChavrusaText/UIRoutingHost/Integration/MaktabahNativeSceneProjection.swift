#if os(iOS)
import Foundation
import SwiftUI
import UIKit
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

/// Read-only projection of the existing native controls and reader. This file
/// belongs to the app target (manager-owned membership), not the portable SPM
/// target. It neither saves reader state nor resolves a requested locator.
@MainActor
struct MaktabahNativeSceneProjection {
    enum Surface { case library, tableOfContents, reader, emptyReader, history, search, searchResults, annotations, annotationEditor, settings, inspector, noteDraft, workspaceProfiles, workspaceOverview, sefariaEmbedded, savedResults }
    let manager: iOSNavigationManager
    let selectedTab: iOSTab
    let columnVisibility: NavigationSplitViewVisibility
    let settingsPresented: Bool
    let sidebar: ReaderSidebarPageCoordinator?
    let workspace: StudyWorkspaceNavigationAdapter?

    private var activeTab: iOSNavigationManager.ReaderTab? {
        guard let id = manager.activeTabId else { return nil }
        // Never substitute a first tab for a missing/stale active ID.
        return manager.openTabs.first { $0.id == id }
    }
    private func stable(_ id: UUID?) -> UIStableID? { id.flatMap { UIStableID(rawValue: $0.uuidString) } }
    private func id(_ value: String) -> UIDestinationID { UIDestinationID(rawValue: value)! }

    func identity(workspacePresentation: MaktabahNativeWorkspacePresentationBinding? = nil,
                  sefariaSurface: MaktabahNativeSefariaSurfaceBinding? = nil,
                  savedResults: MaktabahNativeSavedResultsBinding? = nil,
                  annotationEditor: MaktabahNativeAnnotationEditorControls? = nil) throws -> NativeSceneIdentity {
        let reader = activeTab?.viewModel
        let section = try reader?.currentLocator.map(ActionAppIdentityBridge.actionRef)
        var selection: UIUTF16Range?
        if let range = reader?.readerState.selectedRange, range.location != NSNotFound {
            guard let location = UInt64(exactly: range.location), let length = UInt64(exactly: range.length) else {
                throw UIRouteError(.unavailable, "native_selection_unavailable")
            }
            selection = .init(location: location, length: length)
        }
        let sidebarVisible: Bool? = columnVisibility == .all || columnVisibility == .doubleColumn ? true : columnVisibility == .detailOnly ? false : nil
        let originalSheet: UIDestinationID?
        if settingsPresented { originalSheet = id("native.settings") }
        else if workspacePresentation?.presentationFacets(for: .profiles).requested == true {
            originalSheet = MaktabahNativeWorkspacePresentationBinding.Parent.profiles.destination
        } else if workspacePresentation?.presentationFacets(for: .overview).requested == true {
            originalSheet = MaktabahNativeWorkspacePresentationBinding.Parent.overview.destination
        } else if sefariaSurface?.presentationFacets.requested == true {
            originalSheet = MaktabahNativeSefariaSurfaceBinding.destination
        } else if savedResults?.isRequestedOrMounted == true {
            originalSheet = MaktabahNativeSavedResultsBinding.destination
        } else if annotationEditor?.isMounted == true {
            originalSheet = MaktabahNativeAnnotationEditorControls.destination
        } else { originalSheet = nil }
        let state = UIStateSpec(workspaceID: stable(workspace?.selection?.groupID), profileID: stable(workspace?.selection?.profileID),
                               selectedItemID: sidebar?.page == .contents ? stable(activeTab?.id) : nil,
                               sidebarVisible: sidebarVisible, inspectorVisible: reader?.readerInspectorVisible,
                               sheet: originalSheet)
        return .init(topLevel: selectedTab.canonical.rawValue, activeTabID: stable(manager.activeTabId), section: section,
                     selectedRange: selection, state: state, libraryQuery: manager.libraryViewModel.searchQuery, globalQuery: manager.searchText)
    }

    /// Only return states which can actually be observed from this host. Unknown
    /// compact-column visibility, unread content or source mismatch stays nil.
    func surface(_ surface: Surface,
                 workspacePresentation: MaktabahNativeWorkspacePresentationBinding? = nil,
                 phoneTOCPresentation: MaktabahNativePhoneTOCPresentationBinding? = nil,
                 sefariaSurface: MaktabahNativeSefariaSurfaceBinding? = nil,
                 historyRecord: MaktabahNativeHistoryRecordBinding? = nil,
                 annotationSelection: MaktabahNativeAnnotationSelectionBinding? = nil,
                 annotationRequestID: UUID? = nil,
                 annotationOpening: MaktabahNativeAnnotationEditorOpening? = nil,
                 annotationOpeningRequestID: UUID? = nil,
                 annotationEditor: MaktabahNativeAnnotationEditorControls? = nil,
                 annotationEditorRequestID: UUID? = nil,
                 savedResults: MaktabahNativeSavedResultsBinding? = nil,
                 savedResultsRequestID: UUID? = nil) throws -> NativeSurfaceState? {
        let state = UIStateSpec(workspaceID: stable(workspace?.selection?.groupID),
            profileID: stable(workspace?.selection?.profileID), selectedItemID: nil)
        switch surface {
        case .annotationEditor:
            if let original = annotationOpening {
                guard !settingsPresented, selectedTab.canonical == .annotations, manager.currentMode == .annotations,
                      let requestID = annotationOpeningRequestID,
                      original.hasVisibleSurface(requestID: requestID),
                      let selected = original.observedItem(requestID: requestID) else { return nil }
                return .init(destination: MaktabahNativeAnnotationEditorOpening.destination,
                    presentation: .init(kind: .sheet), content: nil,
                    state: .init(workspaceID: state.workspaceID, profileID: state.profileID, selectedItemID: selected), focus: nil)
            }
            guard !settingsPresented, selectedTab.canonical == .annotations, manager.currentMode == .annotations,
                  let original = annotationEditor, let requestID = annotationEditorRequestID,
                  original.isAvailable(), (try? original.validateVisible(requestID: requestID)) != nil else { return nil }
            // Exact original editor/control proof is necessary, but the
            // separate original sheet UIKit witness still supplies the receipt.
            return .init(destination: MaktabahNativeAnnotationEditorControls.destination,
                presentation: .init(kind: .sheet), content: nil, state: state, focus: nil)
        case .savedResults:
            guard !settingsPresented, selectedTab.canonical == .search, manager.currentMode == .search,
                  let original = savedResults, let requestID = savedResultsRequestID,
                  original.hasVisibleSurface(requestID: requestID) else { return nil }
            return .init(destination: MaktabahNativeSavedResultsBinding.destination,
                presentation: .init(kind: .sheet), content: nil,
                state: .init(workspaceID: state.workspaceID, profileID: state.profileID,
                             selectedItemID: original.observedItem(requestID: requestID)), focus: nil)
        case .sefariaEmbedded:
            guard !settingsPresented, let workspace, let binding = sefariaSurface,
                  binding.owns(workspace, manager: manager), binding.isAvailable else { return nil }
            let actual = binding.presentationFacets
            guard actual.requested, actual.mounted, actual.visible, actual.ready,
                  !actual.transitioning, let destination = binding.observedDestination else { return nil }
            // The feature proves the ORIGINAL React mount/epoch/layout. This
            // state is still not an ACK: the separate native marker must be
            // visible in this same window and its final report is source-locked.
            return .init(destination: destination,
                         presentation: .init(kind: .sheet), content: nil, state: state, focus: nil)
        case .workspaceProfiles, .workspaceOverview:
            let parent: MaktabahNativeWorkspacePresentationBinding.Parent =
                surface == .workspaceProfiles ? .profiles : .overview
            guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer,
                  let workspace, let binding = workspacePresentation,
                  binding.owns(workspace, manager: manager), binding.isAvailable(parent: parent) else { return nil }
            let actual = binding.presentationFacets(for: parent)
            guard actual.requested, actual.mounted, actual.visible,
                  !actual.blockingChild, !actual.transitioning else { return nil }
            // These facets belong to the original presenter and its actual
            // UIKit host. The separate full-surface witness still must be visible.
            return .init(destination: parent.destination, presentation: .init(kind: .sheet),
                         content: nil, state: state, focus: nil)
        case .settings:
            guard settingsPresented else { return nil }
            return .init(destination: id("native.settings"), presentation: .init(kind: .sheet), content: nil, state: state, focus: nil)
        case .history:
            guard !settingsPresented, selectedTab.canonical == .history, manager.currentMode == .history else { return nil }
            if let historyRecord {
                guard let selected = try historyRecord.observedItem() else { return nil }
                // This opaque identity is derived from the retained original
                // card and actual row visibility, never from the requested route.
                return .init(destination: id("native.history"), presentation: .init(), content: nil,
                    state: .init(workspaceID: state.workspaceID, profileID: state.profileID,
                                 selectedItemID: selected), focus: nil)
            }
            guard HistoryViewModel.shared.searchText.isEmpty else { return nil }
            return .init(destination: id("native.history"), presentation: .init(), content: nil, state: state, focus: nil)
        case .searchResults:
            let search = manager.unifiedSearchSession
            guard !settingsPresented, MaktabahNativeRootDestination.search.isAvailable,
                  selectedTab.canonical == .search, manager.currentMode == .search,
                  search.hasSubmitted, !search.isSearching, !search.resultsAreDirty,
                  search.errorMessage == nil else { return nil }
            return .init(destination: id("native.search.results"), presentation: .init(),
                         content: nil, state: state, focus: nil)
        case .search, .annotations:
            let root: MaktabahNativeRootDestination = surface == .search ? .search : .annotations
            guard !settingsPresented, root.isAvailable,
                  selectedTab.canonical == root.tab, manager.currentMode == root.tab.appMode else { return nil }
            if surface == .annotations, let original = annotationSelection {
                guard let requestID = annotationRequestID, original.hasVisibleSurface(requestID: requestID),
                      let selected = original.observedItem(requestID: requestID) else { return nil }
                return .init(destination: MaktabahNativeAnnotationSelectionBinding.destination,
                    presentation: .init(kind: .currentTab), content: nil,
                    state: .init(workspaceID: state.workspaceID, profileID: state.profileID, selectedItemID: selected), focus: nil)
            }
            // Existing private query/note state remains in its original owner.
            // Opening a root never submits a query, creates a draft or writes data.
            return .init(destination: id(root.rawValue), presentation: .init(), content: nil, state: state, focus: nil)
        case .library, .tableOfContents:
            guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer else { return nil }
            if !MaktabahApp.isIpad && surface == .tableOfContents {
                guard let phoneTOCPresentation, phoneTOCPresentation.isPresented,
                      !phoneTOCPresentation.blocksRouting, !phoneTOCPresentation.isTransitioning else { return nil }
                // The original pushed Reader owns this TOC column. Its state is
                // not a receipt: the independent actual tocColumn witness still
                // must appear in this scene before a currentTab ACK is possible.
            } else if let sidebar {
                let page: ReaderSidebarPageCoordinator.Page = surface == .library ? .library : .contents
                guard sidebar.page == page,
                      columnVisibility == .all || columnVisibility == .doubleColumn else { return nil }
                if surface == .tableOfContents {
                    guard MaktabahNativeSceneBindings.hasOriginalTableOfContents(manager) else { return nil }
                }
            } else {
                // Original compact Library is a NavigationStack root; its
                // pushed Reader must be gone before this surface can be visible.
                guard surface == .library, !MaktabahApp.isIpad, manager.selectedBook == nil else { return nil }
            }
            let destination = surface == .library ? "native.library" : "native.reader.toc"
            // Public v2 already defines currentTab roots. No new wire format,
            // private tab identity, or guessed sidebar state is introduced.
            // The exact original page plus its independent UIKit witness must
            // actually be visible before it can acknowledge this root.
            return .init(destination: id(destination), presentation: .init(),
                         content: nil, state: state, focus: nil)
        case .noteDraft:
            guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer,
                  MaktabahNativeInspectorBinding.currentReader(in: manager) != nil else { return nil }
            // The session additionally requires its exact unsaved original
            // editor binding, live UITextView and independent UIKit witness.
            return .init(destination: id("native.reader.noteDraft"), presentation: .init(kind: .sheet),
                content: nil, state: state, focus: nil)
        case .inspector:
            guard !settingsPresented, selectedTab.canonical == .viewer,
                  let reader = MaktabahNativeInspectorBinding.currentReader(in: manager),
                  reader.readerInspectorVisible else { return nil }
            return .init(destination: id("native.reader.inspector"), presentation: .init(kind: .inspector),
                content: nil, state: .init(workspaceID: state.workspaceID, profileID: state.profileID,
                                          inspectorVisible: true), focus: nil)
        case .emptyReader:
            guard MaktabahApp.isIpad, !settingsPresented, selectedTab.canonical == .viewer,
                  manager.currentMode == .viewer, manager.openTabs.isEmpty,
                  manager.activeTabId == nil, manager.selectedBook == nil else { return nil }
            // Only the existing empty Reader placeholder owns this marker.
            // It cannot stand in for any nonempty group's rendered Reader.
            return .init(destination: id("native.reader.empty"), presentation: .init(kind: .currentTab),
                         content: nil, state: state, focus: nil)
        case .reader:
            guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer,
                  let tab = activeTab, let destination = try readerWitnessDestination(includingContainingSection: true),
                  let actual = tab.viewModel.backendSection?.locator,
                  actual == destination.sectionLocator,
                  actual.backend == BackendCoordinator.shared.activeBackendID,
                  tab.book.backendLocator?.workKey == actual.workKey,
                  !tab.viewModel.contentText.isEmpty else { return nil }
            let newlyCreated = workspace?.hasCommittedNativeReader(tabID: tab.id) == true
            let content = ActionReaderDestination(sectionLocator: try ActionAppIdentityBridge.actionRef(actual),
                focusLocator: try destination.focusLocator.map(ActionAppIdentityBridge.actionRef),
                presentationMode: newlyCreated ? .newTab : .sameTab)
            let actualState = UIStateSpec(workspaceID: state.workspaceID, profileID: state.profileID,
                                          inspectorVisible: tab.viewModel.readerInspectorVisible)
            // This describes model state only. The scene session separately
            // requires its original TextKit text/viewport witness before an
            // observation can acknowledge this content or focused segment.
            return .init(destination: id("native.reader"), presentation: .init(kind: newlyCreated ? .newTab : .currentTab, tabID: stable(tab.id)),
                         content: content, state: actualState, focus: nil)
        }
    }

    /// Read metadata from the exact loaded original Reader for a bounded user
    /// consent offer. This is independent of the stricter native-route receipt:
    /// Otzaria may load the containing unit for an exact requested source line.
    struct HanlinCurrentWorkReadSource: Equatable {
        let readerOwner: ObjectIdentifier
        let requestToken: ReaderContentRequestToken
        let requested: LibraryReaderDestination
        let loaded: LibraryReaderDestination
    }

    func hanlinCurrentWorkReadSource() throws -> HanlinCurrentWorkReadSource? {
        try Task.checkCancellation()
        guard !settingsPresented, selectedTab.canonical == .viewer, manager.currentMode == .viewer,
              BackendCoordinator.shared.activeBackendID == .otzaria,
              let activeID = manager.activeTabId else { return nil }
        let tabs = manager.openTabs.filter { $0.id == activeID }
        guard tabs.count == 1, let tab = tabs.first,
              MaktabahApp.isIpad || manager.selectedBook === tab.book,
              let book = tab.book.backendLocator, book.backend == .otzaria,
              tab.viewModel.currentBook?.id == tab.book.id,
              tab.viewModel.currentBook?.backendLocator == book,
              case .loaded = tab.viewModel.state,
              let requested = tab.viewModel.currentDestination,
              requested.sectionLocator.backend == book.backend,
              requested.sectionLocator.workKey == book.workKey,
              let section = tab.viewModel.backendSection,
              section.locator.backend == book.backend, section.locator.workKey == book.workKey,
              let render = tab.viewModel.backendRenderModel, !render.text.isEmpty,
              (render.text as NSString).isEqual(to: tab.viewModel.contentText),
              let token = tab.viewModel.contentLoadCoordinator.currentRequestToken(),
              token.backend == book.backend, token.workKey == book.workKey,
              token.sectionLocator == requested.sectionLocator,
              section.segments.allSatisfy({
                  $0.locator.backend == book.backend && $0.locator.workKey == book.workKey
              }) else { return nil }

        func containsRenderedSource(_ locator: TextLocator) -> Bool {
            let source = section.segments.filter { $0.locator == locator }
            let rendered = render.renderedSegments.filter { $0.locator == locator }
            return source.count == 1 && rendered.count == 1
                && rendered[0].segment == source[0] && rendered[0].visualRange.length > 0
        }
        if requested.sectionLocator != section.locator {
            guard case .legacyLine(let requestedLine) = requested.sectionLocator.position, requestedLine >= 0,
                  case .legacyLine(let loadedLine) = section.locator.position, loadedLine >= 0,
                  containsRenderedSource(requested.sectionLocator) else { return nil }
        }
        if let focus = requested.focusLocator {
            guard focus.backend == book.backend, focus.workKey == book.workKey,
                  containsRenderedSource(focus) else { return nil }
        }
        guard tab.viewModel.contentLoadCoordinator.canApplyContent(token: token, currentBookLocator: book) else { return nil }
        return .init(readerOwner: ObjectIdentifier(tab.viewModel), requestToken: token, requested: requested,
            loaded: .init(sectionLocator: section.locator, focusLocator: requested.focusLocator))
    }

    private func readerWitnessDestination(includingContainingSection: Bool) throws -> LibraryReaderDestination? {
        guard let tab = activeTab, let requested = tab.viewModel.currentDestination,
              let loadedSection = tab.viewModel.backendSection?.locator else { return nil }
        if requested.sectionLocator == loadedSection { return requested }
        guard includingContainingSection else { return nil }
        // Otzaria may have restored a line inside the currently rendered
        // paragraph. Reuse the verified request token and segment mapping.
        return try hanlinCurrentWorkReadSource()?.loaded
    }

    /// Independently read the original rendered view. NativeSurfaceWitness
    /// separately proves container visibility, presentation and scene ownership.
    func hasRenderedReaderEvidence(sceneID: UIStableID, includingContainingSection: Bool = false) -> Bool {
        guard let tab = activeTab, let section = tab.viewModel.backendSection,
              let destination = try? readerWitnessDestination(includingContainingSection: includingContainingSection),
              section.locator == destination.sectionLocator,
              section.locator.backend == BackendCoordinator.shared.activeBackendID,
              tab.book.backendLocator?.workKey == section.locator.workKey,
              let observe = tab.viewModel.isNativeReaderTextVisible else { return false }
        guard case .loaded = tab.viewModel.state else { return false }
        let sourceRange: NSRange?
        if let focus = destination.focusLocator {
            guard focus.backend == section.locator.backend,
                  focus.workKey == section.locator.workKey,
                  let range = tab.viewModel.backendRenderModel?.renderedSegment(for: focus)?.visualRange else { return false }
            sourceRange = range
        } else { sourceRange = nil }
        return observe(sceneID.rawValue, sourceRange)
    }
}

// BEGIN SELF-CONTAINED NATIVE READER TEXT VISIBILITY
/// Read-only proof from the existing UITextView, with its original renderer's
/// source-to-display mapping. It never scrolls, selects, mutates or renders text.
@MainActor
enum ReaderNativeTextVisibility {
    static func isVisible(textView: UITextView, sceneID: String,
                          expectedSource: String, renderedSource: String, renderedText: String,
                          sourceRange: NSRange?, displayedRange: (NSRange) -> NSRange) -> Bool {
        guard !expectedSource.isEmpty, !renderedText.isEmpty,
              (expectedSource as NSString).isEqual(to: renderedSource),
              (renderedText as NSString).isEqual(to: textView.textStorage.string),
              let window = textView.window, let scene = window.windowScene,
              scene.session.persistentIdentifier == sceneID,
              scene.activationState == .foregroundActive,
              !textView.isHidden, textView.alpha > 0,
              textView.bounds.width > 1, textView.bounds.height > 1 else { return false }
        var ancestor = textView.superview
        while let current = ancestor {
            guard !current.isHidden, current.alpha > 0 else { return false }
            ancestor = current.superview
        }
        let viewport = textView.bounds.inset(by: textView.adjustedContentInset)
        guard !viewport.isEmpty,
              textView.convert(viewport, to: window).intersects(window.bounds) else { return false }
        let rect: CGRect
        // Reading layoutManager would replace this view's TextKit 2 engine.
        // Keep visibility observation on the original native text-input path.
        if textView.textLayoutManager != nil {
            let characterIndex: Int
            if let sourceRange {
                let sourceLength = (renderedSource as NSString).length
                guard valid(sourceRange, length: sourceLength) else { return false }
                let range = displayedRange(sourceRange)
                guard valid(range, length: textView.textStorage.length) else { return false }
                // Inspect only the focus's first displayed character, just as
                // the legacy glyph path does; a later visible line cannot pass.
                characterIndex = range.location
            } else {
                let point = CGPoint(x: viewport.midX, y: viewport.midY)
                guard let closest = textView.closestPosition(
                    to: textView.textInputView.convert(point, from: textView)
                ) else { return false }
                let index = textView.offset(from: textView.beginningOfDocument, to: closest)
                guard index >= 0, index <= textView.textStorage.length else { return false }
                characterIndex = min(index, textView.textStorage.length - 1)
            }
            let firstCharacter = (renderedText as NSString)
                .rangeOfComposedCharacterSequence(at: characterIndex)
            guard valid(firstCharacter, length: textView.textStorage.length),
                  let start = textView.position(from: textView.beginningOfDocument, offset: firstCharacter.location),
                  let end = textView.position(from: textView.beginningOfDocument, offset: NSMaxRange(firstCharacter)),
                  let range = textView.textRange(from: start, to: end), !range.isEmpty else { return false }
            // A nearest position is only a candidate. The actual nonempty text
            // range's rectangle must pass every original viewport/clip check.
            rect = textView.convert(textView.firstRect(for: range), from: textView.textInputView)
        } else {
            let glyphs: NSRange
            if let sourceRange {
                let sourceLength = (renderedSource as NSString).length
                guard valid(sourceRange, length: sourceLength) else { return false }
                let range = displayedRange(sourceRange)
                guard valid(range, length: textView.textStorage.length) else { return false }
                // Require the focus's first rendered glyph in the actual viewport;
                // a model range or a distant part of a long paragraph is insufficient.
                let first = NSRange(location: range.location, length: 1)
                textView.layoutManager.ensureLayout(forCharacterRange: first)
                glyphs = textView.layoutManager.glyphRange(forCharacterRange: first, actualCharacterRange: nil)
            } else {
                // Non-focused reads also require a real glyph in the viewport.
                // UIKit returns a range whose first/last glyph intersects this rect.
                let containerViewport = viewport.offsetBy(dx: -textView.textContainerInset.left,
                                                           dy: -textView.textContainerInset.top)
                let visible = textView.layoutManager.glyphRange(forBoundingRect: containerViewport, in: textView.textContainer)
                guard visible.length > 0 else { return false }
                glyphs = NSRange(location: visible.location, length: 1)
            }
            guard glyphs.length > 0 else { return false }
            rect = textView.layoutManager.boundingRect(forGlyphRange: glyphs, in: textView.textContainer)
                .offsetBy(dx: textView.textContainerInset.left, dy: textView.textContainerInset.top)
        }
        guard !rect.isEmpty, rect.origin.x.isFinite, rect.origin.y.isFinite,
              rect.width.isFinite, rect.height.isFinite else { return false }
        guard viewport.insetBy(dx: -1, dy: -1).intersects(rect),
              textView.convert(rect, to: window).intersects(window.bounds) else { return false }
        var clippingAncestor = textView.superview
        while let current = clippingAncestor {
            if current.clipsToBounds && !textView.convert(rect, to: current).intersects(current.bounds) { return false }
            clippingAncestor = current.superview
        }
        return true
    }

    private static func valid(_ range: NSRange, length: Int) -> Bool {
        range.location != NSNotFound && range.location >= 0 && range.length > 0
            && range.location <= length && range.length <= length - range.location
    }
}
// END SELF-CONTAINED NATIVE READER TEXT VISIBILITY
#endif
