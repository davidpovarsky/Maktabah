if not __debug__:
    raise RuntimeError('Optimized Python is forbidden: exact source-control guards must execute')

from pathlib import Path
import os, base64, zlib, json, hashlib, shutil, subprocess, signal, time, traceback, zipfile, re

BASE = '759da82e7eb443634a4396c4768e44bca53f9001'
ROOT = Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
DATA = Path('/mnt/development/projects/diagnostics')
TASK = Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-annotation-editor-opening-controls-20261127')
OWN = TASK / 'attempt-1'
PRIOR = DATA / 'otzaria-wave3-annotations-selection-20261127/caller-current-bindings-attempt-1'
SWIFT = Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
HOST = DATA / 'otzaria-wave3-annotation-selection-intake-20261127-attempt2/output'
UI = DATA / 'otzaria-wave3-rn-semantic-intake-20261127/output'
CORE = ROOT / '.git/search-continuation-integrated-controls-20261127/output'
I = 'Source/ChavrusaText/UIRoutingHost/Integration/'
H = 'Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/'

def sha(data): return hashlib.sha256(data).hexdigest()
def footprint():
    return sum(p.stat().st_blocks * 512 for p in TASK.rglob('*') if p.is_file()) if TASK.exists() else 0
def capacity():
    free = {'data': shutil.disk_usage(DATA).free, 'root': shutil.disk_usage(ROOT).free, 'own': footprint()}
    if free['data'] < 2147483648 or free['root'] < 1342177280 or free['own'] > 83886080:
        raise RuntimeError('original shared floors / exact own80MiB cap: ' + repr(free))
    return free
def git(*args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(ROOT), *args])

initial_capacity = capacity()
if OWN.exists(): raise RuntimeError('fresh owned attempt required')
OWN.mkdir(parents=True)
for name in ['output', 'tmp', 'module-cache']: (OWN / name).mkdir()
def put(path, data):
    p = OWN / path; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data); return p
def save(path, value): return put(path, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())
result = {'schema': 'otzaria.annotation-editor-opening.source-controls.v1', 'base': BASE,
          'started': time.time(), 'initial_capacity': initial_capacity,
          'native': 'NOT_RUN', 'apple_sdk': 'NOT_RUN', 'steps': []}

def run(name, args, expected=0):
    capacity()
    row = {'name': name, 'argv': list(map(str, args)), 'started': time.time()}; result['steps'].append(row)
    with (OWN / (name + '.stdout')).open('wb') as out, (OWN / (name + '.stderr')).open('wb') as err:
        process = subprocess.Popen(list(map(str, args)), stdout=out, stderr=err, start_new_session=True,
            env={**os.environ, 'TMPDIR': str(OWN / 'tmp')})
        row['pid'] = process.pid
        row['start_ticks'] = Path('/proc/' + str(process.pid) + '/stat').read_text().split()[21]
        save('STATUS.json', result)
        end = time.monotonic() + 180
        while process.poll() is None:
            try: capacity()
            except BaseException as error: row['guard'] = repr(error)
            if time.monotonic() > end: row['guard'] = 'owned process deadline'
            if 'guard' in row:
                os.killpg(process.pid, signal.SIGTERM)
                try: process.wait(timeout=5)
                except subprocess.TimeoutExpired: os.killpg(process.pid, signal.SIGKILL); process.wait()
                break
            time.sleep(.5)
        row.update(exit=process.returncode, finished=time.time()); save('STATUS.json', result)
    if 'guard' in row:
        raise RuntimeError(name + ' stopped by the original capacity/deadline guard: ' + row['guard'])
    if expected is None:
        if row['exit'] == 0: raise RuntimeError(name + ' unexpectedly passed the stated source counterexample')
    elif row['exit'] != expected: raise RuntimeError(name + ' exit ' + str(row['exit']))
    return row

def body(text, needle):
    start = text.index(needle); pos = text.index('{', start); depth = 1; p = pos + 1
    quoted = False; line = False; block = 0
    while depth:
        char = text[p]; pair = text[p:p+2]
        if line:
            if char == '\n': line = False
        elif block:
            if pair == '/*': block += 1; p += 1
            elif pair == '*/': block -= 1; p += 1
        elif quoted:
            if char == '\\': p += 1
            elif char == '"': quoted = False
        elif pair == '//': line = True; p += 1
        elif pair == '/*': block = 1; p += 1
        elif char == '"': quoted = True
        elif char == '{': depth += 1
        elif char == '}': depth -= 1
        p += 1
    return text[start:p]

try:
    put('RUN.py', RUN_SOURCE.encode())
    if sha(SWIFT.read_bytes()) != '39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a':
        raise RuntimeError('original compiler identity')
    raw = zlib.decompress(base64.b64decode(PAYLOAD['zlib_base64']))
    if len(raw) != PAYLOAD['bytes'] or sha(raw) != PAYLOAD['sha256']: raise RuntimeError('input transport identity')
    payload = json.loads(raw); rows = []
    for row in payload['files']:
        data = row['text'].encode(); rel = Path(row['path'])
        if rel.is_absolute() or '..' in rel.parts or sha(data) != row['sha256'] or len(data) != row['bytes']:
            raise RuntimeError('exact bounded input ' + row['path'])
        put('inputs/' + row['path'], data); rows.append({k: v for k, v in row.items() if k != 'text'})
    save('INPUTS.json', {'base': BASE, 'files': rows, 'transport_sha256': PAYLOAD['sha256']})
    # Rebuild every declared capsule from its transported full source, keeping
    # the originally transported inputs immutable and comparing every byte.
    reconstructed = OWN / 'reconstructed-capsules'
    run('reconstruct-exact-source-capsules', ['python3', OWN / 'inputs/controls/prepare_controls.py',
        '--output', reconstructed, '--manifest', OWN / 'RECONSTRUCTED_SOURCE_EXTRACTIONS.json'])
    original_capsules = OWN / 'inputs/controls/generated'
    if {p.name for p in reconstructed.glob('*.swift')} != {p.name for p in original_capsules.glob('*.swift')}:
        raise RuntimeError('complete source capsule membership')
    for path in reconstructed.glob('*.swift'):
        if path.read_bytes() != (original_capsules / path.name).read_bytes(): raise RuntimeError('exact reconstructed source ' + path.name)
    if (OWN / 'RECONSTRUCTED_SOURCE_EXTRACTIONS.json').read_bytes() != (OWN / 'inputs/controls/SOURCE_EXTRACTIONS.json').read_bytes():
        raise RuntimeError('exact source extraction manifest')
    prior_result = (PRIOR / 'RESULT.json').read_bytes()
    if sha(prior_result) != 'ebe40c5edffc71696bda9b7336786a277288ed90510816a7f46de471eb9c6e85':
        raise RuntimeError('retained module qualification receipt')
    with zipfile.ZipFile(PRIOR / 'RAW.zip') as archive:
        manifest = json.loads(archive.read('RAW_MANIFEST.json'))
        row = next(x for x in manifest if x['path'] == 'CURRENT_MODULE_SOURCE_JOIN.json')
        joined_raw = archive.read(row['path'])
        if sha(joined_raw) != row['sha256'] or len(joined_raw) != row['bytes'] or joined_raw != (PRIOR / row['path']).read_bytes():
            raise RuntimeError('retained original module closure')
    joined = json.loads(joined_raw)
    if joined['counts'] != {'Core': 31, 'UI': 13, 'Host': 41}: raise RuntimeError('full original closure counts')
    for row in joined['files']:
        source = git('show', BASE + ':' + row['path'])
        if sha(source) != row['sha256'] or len(source) != row['bytes'] or source != Path(row['compiled_input']).read_bytes():
            raise RuntimeError('original compiled module source ' + row['path'])
    for prefix, name in [('Source/Otzaria/Actions/Sources/OtzariaActionCore/', 'Core'),
                         ('Source/Otzaria/UIRouting/Sources/OtzariaUIRouting/', 'UI'), (H, 'Host')]:
        names = {p for p in git('ls-tree', '-r', '--name-only', BASE, '--', prefix).decode().splitlines() if p.endswith('.swift')}
        if names != {r['path'] for r in joined['files'] if r['module'] == name}: raise RuntimeError('full module membership ' + name)
    for row in joined['products']:
        if sha(Path(row['path']).read_bytes()) != row['sha256']: raise RuntimeError('original product ' + row['path'])
    put('retained-receipts/CALLER_RESULT.json', prior_result)
    put('retained-receipts/CURRENT_MODULE_SOURCE_JOIN.json', joined_raw)
    save('CURRENT_MODULE_JOIN.json', {'base': BASE, 'rejoined': 85, 'counts': joined['counts'],
        'source_join_sha256': sha(joined_raw), 'products': joined['products']})

    # Original leased preimages and shared old spans remain bound to actual Git.
    for row in rows:
        prefix = next((x for x in ['baseline/', 'proposal/baseline/'] if row['path'].startswith(x)), None)
        if prefix and row['path'].endswith('.swift'):
            path = row['path'][len(prefix):]
            if git('show', BASE + ':' + path) != (OWN / 'inputs' / row['path']).read_bytes():
                raise RuntimeError('original preimage ' + path)
    component = git('show', BASE + ':' + I + 'MaktabahNativeComponentBinding.swift').decode()
    a = component.index('typealias MaktabahNativeComponentDescriptor'); b = component.index('/// A passive view', a)
    actual_component = 'import Foundation\nimport ChavrusaUIRoutingHost\nimport OtzariaUIRouting\n\n' + component[a:b]
    if actual_component != (OWN / 'inputs/controls/generated/ActualComponentSourceObservation.swift').read_text():
        raise RuntimeError('actual component/backend publication bridge')
    for path, projected in [(I + 'MaktabahNativeWindowObservation.swift', 'OriginalWindowObservation.swift'),
                            (I + 'MaktabahNativeAnnotationListPublication.swift', 'ActualListPublication.swift')]:
        original = git('show', BASE + ':' + path).decode()
        expected = original.removeprefix('#if os(iOS)\n').removesuffix('#endif\n').replace('import UIKit\n', '').replace('@preconcurrency import Combine\n', '')
        if expected != (OWN / 'inputs/controls/generated' / projected).read_text(): raise RuntimeError('actual source projection ' + path)
    original_root = git('show', BASE + ':' + I + 'MaktabahNativeSearchEntry.swift').decode()
    root_body = body(original_root, '@MainActor\nfinal class MaktabahNativeRootPublicationSource')
    if 'import Foundation\nimport ChavrusaUIRoutingHost\n\n' + root_body + '\n' != (OWN / 'inputs/controls/generated/ActualOriginalRootPublication.swift').read_text():
        raise RuntimeError('actual current root publication class')
    original_codec = git('show', BASE + ':' + H + 'NativeReaderIntentService.swift').decode()
    codec_body = body(original_codec, 'enum NativeReaderEntityIdentifier')
    if 'import Foundation\nimport OtzariaUIRouting\n\n' + codec_body + '\n' != (OWN / 'inputs/controls/generated/ActualNativeReaderEntityIdentifier.swift').read_text():
        raise RuntimeError('actual current original entity codec')
    shared = json.loads((OWN / 'inputs/proposal/SHARED_EDITS.json').read_text())
    save('SHARED_PROPOSAL_JOIN.json', {'manifest_sha256': sha((OWN / 'inputs/proposal/SHARED_EDITS.json').read_bytes()),
        'scope': 'all four original full preimages rejoined to Git; candidate hunks are root-only, never applied to the live repository'})
    old_session = (OWN / 'inputs/proposal/baseline' / (I + 'MaktabahNativeSceneSession.swift')).read_text()
    new_session = (OWN / 'inputs/proposal/candidate' / (I + 'MaktabahNativeSceneSession.swift')).read_text()
    for needle in ['    func removeAnnotationPresentation(', '    private func advanceOriginalAnnotationPresentationPublication()']:
        if body(old_session, needle) != body(new_session, needle): raise RuntimeError('original removal/publication modified')
    old_child = (OWN / 'inputs/evidence/pre-independent-child-publication/candidate' / (I + 'MaktabahNativeAnnotationEditorControls.swift')).read_text()
    new_child = (OWN / 'inputs/candidate' / (I + 'MaktabahNativeAnnotationEditorControls.swift')).read_text()
    for needle in ['    func retainSource(', '    func begin(', '    func apply(', '    func withValidatedSurface',
                   '    func finish(', '    func releaseSource(', '    func retire()']:
        if body(old_child, needle) != body(new_child, needle): raise RuntimeError('warm control behavior changed by independent child publication')
    save('UNCHANGED_ORIGINAL_BODIES.json', {'Session_remove_and_advance': 'byte-identical',
        'warm_child_control_retention_apply_report_finish_release_retire': 'byte-identical',
        'child_state_before': sha(old_child.encode()), 'child_state_after': sha(new_child.encode())})

    generated = OWN / 'inputs/controls/generated'
    argv = [SWIFT, '-swift-version', '6', '-strict-concurrency=complete', '-parse-as-library',
            '-module-cache-path', OWN / 'module-cache']
    # Host-first is mandatory: the older RN output also contains a Host module.
    for path, name in [(HOST, 'ChavrusaUIRoutingHost'), (UI, 'OtzariaUIRouting'), (CORE, 'OtzariaActionCore')]:
        argv += ['-I', path, '-L', path, '-l' + name, '-Xlinker', '-rpath', '-Xlinker', path]
    common = sorted(p for p in generated.glob('*.swift') if p.name not in {
        'MaktabahNativeAnnotationEditorControls.swift', 'BeforeIndependentChildState.swift'})
    common += [OWN / 'inputs/controls/OpeningFixture.swift', OWN / 'inputs/controls/OpeningOwnerControls.swift']
    owner = OWN / 'output/actual-opening-owner-controls'
    run('compile-actual-owner-and-original-callbacks', argv + common + [generated / 'MaktabahNativeAnnotationEditorControls.swift', '-o', owner])
    run('actual-runtime-library-identity', ['ldd', owner])
    linked = (OWN / 'actual-runtime-library-identity.stdout').read_text()
    for path, name in [(HOST, 'ChavrusaUIRoutingHost'), (UI, 'OtzariaUIRouting'), (CORE, 'OtzariaActionCore')]:
        if re.search(r'^\s*lib' + name + r'\.so\s+=>\s+' + re.escape(str(path / ('lib' + name + '.so'))) + r'\s', linked, re.M) is None:
            raise RuntimeError('actual linked current original library ' + name)
    run('actual-owner-controls', [owner])
    owner_report = json.loads((OWN / 'actual-owner-controls.stdout').read_text())
    if owner_report['failed'] != 0: raise RuntimeError('actual owner/source controls failed')
    run('original-tag-method-ABA-counterexample', [owner, '--historical-tag'], expected=None)
    run('original-List-coverage-counterexample', [owner, '--historical-coverage'], expected=None)
    old = OWN / 'output/before-independent-child-state'
    run('compile-before-independent-child-state', argv + common + [generated / 'BeforeIndependentChildState.swift', '-o', old])
    run('late-coverage-before-independent-state-counterexample', [old, '--late-coverage-only'], expected=None)
    for name in ['original-tag-method-ABA-counterexample', 'original-List-coverage-counterexample',
                 'late-coverage-before-independent-state-counterexample']:
        report = json.loads((OWN / (name + '.stdout')).read_text())
        if report['passed'] != 0 or report['failed'] != 1: raise RuntimeError('bounded expected source counterexample ' + name)

    service = OWN / 'output/actual-opening-service-controls'
    run('compile-actual-service', argv + [generated / 'NativeAnnotationEditorIntentService.swift',
        generated / 'ActualNativeReaderEntityIdentifier.swift', OWN / 'inputs/controls/OpeningServiceControls.swift', '-o', service])
    run('actual-service-controls', [service])
    service_report = json.loads((OWN / 'actual-service-controls.stdout').read_text())
    if service_report['failed'] != 0: raise RuntimeError('actual service controls failed')
    syntax = []
    for n, row in enumerate(r for r in rows if r['path'].startswith(('candidate/', 'proposal/candidate/')) and r['path'].endswith('.swift')):
        for configuration in ['Debug', 'Release']:
            flags = ['-D', 'DEBUG'] if configuration == 'Debug' else []
            name = 'full-ios-syntax-' + str(n) + '-' + configuration
            run(name, [SWIFT, '-frontend', '-parse', '-target', 'arm64-apple-ios27.0', *flags, OWN / 'inputs' / row['path']])
            syntax.append(name)
    for row in joined['products']:
        if sha(Path(row['path']).read_bytes()) != row['sha256']: raise RuntimeError('original readonly product changed')
    result.update(status='PASS_SOURCE_ONLY', owner_controls={'passed': owner_report['passed'], 'failed': 0},
        service_controls={'passed': service_report['passed'], 'failed': 0}, actual_source_counterexamples=3,
        full_swift_syntax=len(syntax), original_module_counts=joined['counts'],
        scope='Actual new owner/service, original List/Session/controller/child source bodies, actual current Core/UI/Host types and source bridge; explicit Apple/UI layout/lifecycle scheduling, Store/model/backend/admission boundaries. No Core operation, real UIKit, persistence, Apple SDK, native receipt or app acceptance.')
except BaseException as error:
    result.update(status='FAILED', error=repr(error), traceback=traceback.format_exc())
finally:
    result.update(finished=time.time(), task_bytes=footprint(), data_free=shutil.disk_usage(DATA).free,
                  root_free=shutil.disk_usage(ROOT).free)
    path = save('RESULT.json', result); manifest = []
    for file in sorted(OWN.rglob('*')):
        rel = file.relative_to(OWN)
        if file.is_file() and not any(x in rel.parts for x in ['output', 'module-cache', 'tmp']) and file.name not in {'RAW.zip', 'RAW_MANIFEST.json'}:
            data = file.read_bytes(); manifest.append({'path': str(rel), 'bytes': len(data), 'sha256': sha(data)})
    save('RAW_MANIFEST.json', manifest)
    with zipfile.ZipFile(OWN / 'RAW.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for row in manifest: archive.write(OWN / row['path'], row['path'])
        archive.write(OWN / 'RAW_MANIFEST.json', 'RAW_MANIFEST.json')
    raw = (OWN / 'RAW.zip').read_bytes()
    print(json.dumps({'path': str(path), 'sha256': sha(path.read_bytes()), 'status': result['status'],
        'owner': result.get('owner_controls'), 'service': result.get('service_controls'),
        'raw_sha256': sha(raw), 'raw_bytes': len(raw), 'raw_members': len(manifest), 'error': result.get('error')}))
if result['status'] != 'PASS_SOURCE_ONLY': raise SystemExit(1)
