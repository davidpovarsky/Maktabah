import ast,gzip,hashlib,io,json,pathlib,shutil,subprocess,tarfile,traceback
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='1aa4732e3da0ce4385d6231821713f378010a554'
BRANCH='codex/otzaria-wave3-integration-20261127'
DONOR='a7be0e1fbe915a385c698acaef50b34cbc4b0986'
DONOR_BASE='24cd9291dbc87d799c22a41f0bc73a82c6415bfa'
DONOR_REPO='/mnt/development/projects/worktrees/Maktabah-wave3-vendor-admission-private-20261127'
D='docs/hq-integration/wave3-vendor-source-admission-20261127'
PROOF='docs/hq-integration/wave3-vendor-admission-intake-20261127'
RUN=pathlib.Path(__file__).parent
events=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 # Contents and binary blobs are hashed in records rather than repeated in logs.
 event={'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')}
 if len(p.stdout)<4096 and (not a or a[0] not in ['show','cat-file']):event['stdout']=p.stdout.decode(errors='replace')
 events.append(event);dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure: '+repr(a))
 return p.stdout
def rev(x):return git('rev-parse',x).decode().strip()
def show(c,p):return git('show',c+':'+p)
def function_bytes(raw,name):
 text=raw.decode();matches=[n for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
 assert len(matches)==1,(name,len(matches));node=matches[0]
 return ''.join(text.splitlines(keepends=True)[node.lineno-1:node.end_lineno]).encode()
try:
 assert rev('HEAD')==BASE and git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 assert not git('status','--porcelain') and shutil.disk_usage(ROOT).free>=1342177280
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 protected=['Source','Vendor','Maktabah.xcodeproj','Maktabah-iOSUITests','.github','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected}
 git('fetch','--no-tags','--no-write-fetch-head',DONOR_REPO,DONOR)
 assert rev(DONOR+'^')==DONOR_BASE
 changed=git('diff-tree','--no-commit-id','--name-only','-r',DONOR).decode().splitlines()
 manifestRaw=show(DONOR,D+'/DONOR_SOURCE_MANIFEST.json')
 assert sha(manifestRaw)=='3baf0f9970482dcafb2b3a2a61bd4d0df921b89634d7951138b27c8a05a4de81'
 manifest=json.loads(manifestRaw);sources=manifest['source_files']
 assert len(sources)==7
 assert set(row['path']for row in sources)=={'Scripts/CI/'+name for name in ['final_integration_source.py','fixtures/reviewed-vendor-legacy-inputs.json','hq-stage2-focused-apple.py','prepare-normal-ios-workspace.py','reviewed-vendor-source.inputs.json','test-normal-ios-workspace.py','test-reviewed-vendor-source.py']}
 artifactsRaw=show(DONOR,D+'/ARTIFACTS.json')
 assert sha(artifactsRaw)=='f69580b2bd0bb70ec683eeb00a961b4864186a4fd117e7bfb63d1f5e41ccc38a'
 artifacts=json.loads(artifactsRaw);assert len(artifacts)==30
 assert len(changed)==38 and set(changed)==set(artifacts)|{D+'/ARTIFACTS.json'}|{r['path']for r in sources}
 for path in changed:
  raw=git('ls-tree',DONOR,'--',path).decode().strip();assert raw.startswith('100644 blob '),path
 for path,row in artifacts.items():
  raw=show(DONOR,path);assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],path
 for row in sources:
  path=row['path'];after=row['after'];raw=show(DONOR,path)
  assert len(raw)==after['bytes'] and sha(raw)==after['sha256'] and rev(DONOR+':'+path)==after['git_blob']
  if row['before'] is not None:
   before=row['before'];data=show(BASE,path)
   assert len(data)==before['bytes'] and sha(data)==before['sha256'] and rev(BASE+':'+path)==before['git_blob']
  else:assert not git('ls-tree',BASE,'--',path)
 for path,expected in manifest['unchanged_product_trees'].items():
  assert rev(DONOR+':'+path)==expected==trees[path]
 for path,row in manifest['unchanged_source_profile'].items():
  assert show(BASE,path)==show(DONOR,path) and sha(show(DONOR,path))==row['sha256']
 assert manifest['production_tolerance_for_missing_git_objects_added'] is False
 for name in ['final_integration_source.py','hq-stage2-focused-apple.py','prepare-normal-ios-workspace.py']:
  assert b'--missing-ok' not in show(DONOR,'Scripts/CI/'+name)
 summaryRaw=show(DONOR,D+'/validation/CONTROL_SUMMARY.json')
 assert sha(summaryRaw)=='b153461d10357c749a925fa1acb0bacd3dd7eb9c7bfe32bcdda02c1db4e9f259'
 summary=json.loads(summaryRaw)
 assert summary['current']=={'errors':0,'failures':0,'process_exit':0,'status':'PASS','tests':39}
 assert summary['original_normal']=={'errors':0,'failures':0,'process_exit':0,'tests':28}
 assert all(summary[k]=='NOT_RUN'for k in ['native','app_sdk','metro'])
 archive=show(DONOR,D+'/validation/actual-source-controls.tar.gz')
 assert len(archive)==2522657 and sha(archive)=='4ec985ad2a4a0b50590547de21f8286226ee98fc9bb7aa0cb0d6294fc62ecd63'
 index=json.loads(show(DONOR,D+'/validation/ARCHIVE_INDEX.json'))
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tar:
  members=tar.getmembers();assert len(members)==len(index)==306
  assert len({m.name for m in members})==306 and {m.name for m in members}==set(index)
  for member in members:
   assert not member.name.startswith('/') and '..'not in pathlib.PurePosixPath(member.name).parts
   row=index[member.name]
   if row['type']=='symlink':assert member.issym() and member.linkname==row['target']
   else:
    assert member.isfile();raw=tar.extractfile(member).read()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
  rawResult=tar.extractfile('attempt-3/current-real-git/RESULT.json').read()
  assert sha(rawResult)=='42fab4c88448475868f0cebbc44d09cc9779450e7ad9cd6a09942ae1eb925a0f'
 assertions=json.loads(show(DONOR,D+'/review/ORIGINAL_ASSERTIONS_PRESERVED.json'))['records']
 assert len(assertions)==39
 unchangedFunctions=[]
 for row in assertions:
  path='Scripts/CI/'+row['file'];before=function_bytes(show(BASE,path),row['function']);after=function_bytes(show(DONOR,path),row['function'])
  assert before==after
  unchangedFunctions.append({'path':path,'function':row['function'],'bytes':len(after),'sha256':sha(after)})
 binding=json.loads(show(DONOR,D+'/review/BINDING_FIELDS_PRESERVED.json'))
 for call in binding['original_require_calls']:assert call.encode()in show(DONOR,'Scripts/CI/final_integration_source.py')
 def binding_fields(commit):
  tree=ast.parse(show(commit,'Scripts/CI/final_integration_source.py'))
  vals=[n.value for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='BINDING_FIELDS'for t in n.targets)]
  assert len(vals)==1;return ast.literal_eval(vals[0])
 assert binding_fields(BASE)==binding_fields(DONOR)==set(binding['binding_fields'])
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',DONOR)
 integrated=rev('HEAD');assert not git('status','--porcelain')
 assert all(rev('HEAD:'+p)==v for p,v in trees.items())
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 dump(proof/'ORIGINAL_FUNCTIONS_JOIN.json',unchangedFunctions)
 outcome={'schema':'otzaria.wave3.vendor-source-admission-intake.v1','base':BASE,'donor':DONOR,'donorBase':DONOR_BASE,'integrated':integrated,'sourcePathsVerified':7,'commitPathsVerified':38,'artifactRowsVerified':30,'archiveMembersVerified':306,'rawControlResultSHA256':sha(rawResult),'currentSourceControls':summary['current'],'originalSourceControls':summary['original_normal'],'originalFunctionBodiesUnchanged':39,'bindingFieldsUnchanged':sorted(binding_fields(BASE)),'protectedTreesUnchanged':trees,'finalSourceProfileUnchanged':manifest['unchanged_source_profile'],'realMetro':'NOT_RUN','newSDK':'NOT_RUN','native':'NOT_RUN','ownerApproval':'NOT_GRANTED','releaseAndTestFlight':'OPEN'}
 dump(proof/'RESULT.json',outcome)
 (proof/'README.md').write_text('# Exact reviewed Vendor source admission intake\n\nThe seven source/control files and31 evidence files were independently reviewed and cherry-picked from the scoped publication. Every30 evidence hash/length, all306 archive members and the exact current source preimages were rejoined. The39 new controls and28 unchanged original controls are source-only evidence. The28 original test bodies and11 original production functions remain byte-identical, as do BINDING_FIELDS and its two original exact-binding predicates.\n\nThis intake admits only the closed seven-path Vendor contract and exact one-field JS source declaration transition through the original validator entry points. The original engine, resource, artifact, build, owner, target-policy and runtime gates are not waived. A new Metro bundle, real SDK/app build and full final-candidate acceptance remain required. The old final source profile deliberately remains unchanged and must be rebound only after actual application freeze. All Source, Vendor, Xcode project, native UI tests, workflows and owner architecture trees remain unchanged.\n')
 git('add','--sparse','--',PROOF)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record verified closed Vendor source admission intake')
 head=rev('HEAD');assert not git('status','--porcelain')
 assert all(rev('HEAD:'+p)==v for p,v in trees.items())
 total=set(git('diff','--name-only',BASE,'HEAD').decode().splitlines())
 assert all(p in changed or p.startswith(PROOF+'/')for p in total)
 assert git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'integrated':integrated,'donor':DONOR,'sourceTree':trees['Source'],'vendorTree':trees['Vendor'],'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'freeBytes':shutil.disk_usage(ROOT).free,'scope':'Closed source admission only; final acceptance OPEN'}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
