import gzip,hashlib,io,json,pathlib,shutil,subprocess,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='6fab35806ac97a1a287176a2605fd5bdc5918ba6'
PARENT='37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be'
SOURCE='6bca884d70f0dad8ed00639076f5db976c349573'
DOCS='3103dfd8d8883cccc9b93854ee2100131fce2ad0'
DONOR_ROOT='/home/ubuntu/otzaria-wave3-saved-results-native-20261127/source'
D='docs/hq-ui-inventory/wave3-saved-results-native-20261127'
PROOF='docs/hq-integration/wave3-saved-results-native-intake-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row['path']
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain')and shutil.disk_usage(ROOT).free>=1342177280
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR_ROOT,DOCS)
 assert rev(SOURCE+'^')==PARENT and rev(DOCS+'^')==SOURCE
 source_paths=git('diff-tree','--no-commit-id','--name-only','-r',SOURCE).decode().splitlines()
 assert set(source_paths)=={'Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift','Maktabah-iOSUITests/NativeSavedResultsAcceptanceTests.swift'}
 doc_paths=git('diff-tree','--no-commit-id','--name-only','-r',DOCS).decode().splitlines()
 raw=show(DOCS,D+'/MANIFEST.json')
 assert sha(raw)=='4b970e7862696d3047fc606aa0e6a8da668deb072084b49a0b3e6e4fabf82a77'
 manifest=json.loads(raw);assert len(manifest)==39
 assert set(doc_paths)=={D+'/'+r['path']for r in manifest}|{D+'/MANIFEST.json'}
 for row in manifest:pin(show(DOCS,D+'/'+row['path']),row)
 packet=json.loads(show(DOCS,D+'/SOURCE_PACKET.json'))
 assert packet['base']==PARENT and packet['unchanged_original_prefix']is True and packet['product_files_changed']==[]
 assert len(packet['new_test_declarations'])==len(set(packet['new_test_declarations']))==6
 main='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
 old=show(BASE,main);assert old==show(PARENT,main)
 assert len(old)==337724 and sha(old)=='3bf29c5fc7f3a434d605b8962f2954ca8afdd5521f16ae0b3eea2d1315a1c58f'
 suffix=show(DOCS,D+'/NATIVE_HELPER_ADDITION.swift')
 assert len(suffix)==37710 and sha(suffix)=='fe2f04de2a71ac5459c27e1d9ab67080e5113b013d468e22ebf67a5bbebb9a62'
 assert show(SOURCE,main)==old+suffix
 for row in packet['test_files']:pin(show(SOURCE,row['path']),row)
 assert not git('ls-tree',BASE,'--','Maktabah-iOSUITests/NativeSavedResultsAcceptanceTests.swift')
 dependencies=json.loads(show(DOCS,D+'/DEPENDENCY_CURRENT_GIT_JOIN.json'))
 assert len(dependencies['files'])==16
 for row in dependencies['files']:
  pin(show(BASE,row['path']),row);assert rev(BASE+':'+row['path'])==row['git_blob']and row['matches_read_input']is True
 for row in manifest:
  if row['path'].startswith('original-source/'):
   assert show(DOCS,D+'/'+row['path'])==show(BASE,row['path'].removeprefix('original-source/'))
 packed=show(DOCS,D+'/controls/SOURCE_CONTROLS_ATTEMPT_1.zip')
 assert len(packed)==129746 and sha(packed)=='e18912d27bfe1f0fe8d279c764590cd7268abd4e594fb8d14d94a4ab6cbb9aa3'
 with zipfile.ZipFile(io.BytesIO(packed))as archive:
  members=archive.namelist();raw_manifest=json.loads(archive.read('RAW_MANIFEST.json'))
  assert len(members)==23 and len(set(members))==23 and len(raw_manifest)==22
  assert set(members)=={r['path']for r in raw_manifest}|{'RAW_MANIFEST.json'}
  for row in raw_manifest:pin(archive.read(row['path']),row)
  result_data=archive.read('RESULT.json');assert result_data==show(DOCS,D+'/controls/RESULT.json')
  assert sha(result_data)=='9dd3bef6c6e4481bbf36b9c6a4f0f4a0fbc2db85643035d04bb59f18dd735c8e'
  result=json.loads(result_data);assert result['status']=='PASSED_SOURCE_ONLY'and result['native']=='NOT_RUN'
  assert result['oracle_controls']['passed']==10 and result['oracle_controls']['failed']==0
  assert [c['exit_code']for c in result['commands']]==[0,0,0,0]
  for command in result['commands']:
   for name in ['stdout','stderr']:pin(archive.read(command[name]['path']),command[name])
  for path in source_paths:assert archive.read('inputs/candidate/'+path)==show(SOURCE,path)
  assert archive.read('inputs/proposal/NATIVE_HELPER_ADDITION.swift')==suffix
  assert archive.read('inputs/controls/OriginalSQLiteOracleControls.swift')==show(DOCS,D+'/controls/OriginalSQLiteOracleControls.swift')
  observed=json.loads(archive.read('oracle-execute.stdout'));assert observed==result['oracle_controls']
 # The one inherited whitespace byte is retained as exact original evidence.
 # It is not newly authored source, an assertion, or a build/test-gate change.
 exception=json.loads(show(DOCS,D+'/publication/ORIGINAL_SOURCE_WHITESPACE_REVIEW.json'))
 assert exception['raw_evidence_path']==D+'/original-source/Source/Features/Bookmarks/iOS/iOSFolderSelectionGroup.swift'
 assert show(DOCS,exception['raw_evidence_path'])==show(BASE,exception['original_path'])
 assert show(BASE,exception['original_path']).splitlines(keepends=True)[18]==bytes.fromhex('202020200a')
 git('diff','--check',PARENT,SOURCE)
 git('diff','--check',SOURCE,DOCS,'--',*[p for p in doc_paths if p!=exception['raw_evidence_path']])
 protected=['Source','Vendor','Maktabah.xcodeproj','Scripts','.github','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected}
 for p in protected:assert rev(DOCS+':'+p)==rev(PARENT+':'+p)
 picked=[]
 for donor in [SOURCE,DOCS]:
  git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',donor)
  picked.append({'donor':donor,'intake':rev('HEAD')});assert not git('status','--porcelain')
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 for path in source_paths:assert show('HEAD',path)==show(SOURCE,path)
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 report={'schema':'otzaria.wave3.saved-native-source-intake.v1','base':BASE,'donorBase':PARENT,'picked':picked,
  'sourcePaths':2,'docsPaths':40,'manifestRows':39,'dependenciesRejoined':16,'rawFilesVerified':22,'zipMembers':23,
  'oldPrefixBytes':len(old),'oldPrefixSHA256':sha(old),'suffixBytes':len(suffix),'suffixSHA256':sha(suffix),
  'combinedSHA256':sha(old+suffix),'originalAssertionsAndSelectors':'Whole original337724-byte prefix exact',
  'reusedExecutedSourceControls':{'sqlite':10,'fullFrontendSyntaxParses':2},'newNativeSelectors':6,'newNativeRuns':0,
  'PBX':'Unchanged; existing synchronized UI-test group membership','protectedTrees':trees,
  'originalWhitespaceEvidence':exception,'scope':'Warm mounted original Saved tree; actual AppIntents and native delivery NOT_RUN; no production, full Hebrew/VoiceOver/keyboard/resize/physical acceptance.'}
 dump(proof/'RESULT.json',report)
 (proof/'README.md').write_text('# Saved Results native selector source admission\n\nRoot integrated only the two exact test-source paths and their40-file evidence packet. The complete original337724-byte shared helper prefix is unchanged; the37710-byte independent suffix and six new selector wrappers match the source that was parsed. All16 original setup/service dependencies and22 raw control files were independently rejoined.\n\nThe reused actual controls are ten passing SQLite-helper cases and two frontend syntax parses. No Apple SDK compile, native AppIntent execution, production acceptance, physical test or final Native116/Release114+2 run is represented here. The original Back/Delete draft was rejected because Back retires the catalog; the retained correction proves the same child entity still live immediately before original confirmed deletion.\n\nOne whitespace line belongs to an exact copy of original source. Its byte identity and prior diff-check failure remain preserved; all authored files passed their original diff check. No test gate or source assertion changed.\n')
 git('add','--sparse','--',PROOF)
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record Saved Results native selector source admission')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),
  'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'freeBytes':shutil.disk_usage(ROOT).free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
