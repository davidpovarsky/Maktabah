import gzip,hashlib,io,json,pathlib,re,shutil,subprocess,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='a3c347092bee5fa8fa24ce2fee60198dca4f655d'
DONOR_BASE='b463ffd03a76026cea06c79c608df97d00094152'
COMMITS=['caf02d7b2cf1461c44de7d040f935872f713897f','0608d4309526539fd4d31ee45bf9deccf7556921']
DONOR='/home/ubuntu/otzaria-wave3-annotation-native-published-20261127/source'
BRANCH='codex/otzaria-wave3-integration-20261127'
TEST='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
SELECTOR='Maktabah-iOSUITests/NativeAnnotationSelectionAcceptanceTests.swift'
CONTROLLER='Source/Features/Annotations/iOS/iOSAnnotationViewController.swift'
FOLDER='docs/hq-ui-inventory/wave3-annotation-native-20261127'
PROOF='docs/hq-integration/wave3-annotation-native-intake-20261127'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def capacity():assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,COMMITS[-1])
 assert rev(COMMITS[0]+'^')==DONOR_BASE and rev(COMMITS[1]+'^')==COMMITS[0]
 paths=git('diff-tree','--no-commit-id','--name-only','-r',COMMITS[0]).decode().splitlines()
 assert set(paths)=={TEST,SELECTOR}
 git('diff','--check',COMMITS[0]+'^',COMMITS[0])
 index=show(COMMITS[1],FOLDER+'/MANIFEST.json')
 assert sha(index)=='ea8b9ee06e4ce75fabbc339319b77a12cb56fbe9efd9ef1e27f91a61d3ce8cb8'
 rows=json.loads(index)['files'];assert len(rows)==40
 assert set(git('diff-tree','--no-commit-id','--name-only','-r',COMMITS[1]).decode().splitlines())=={FOLDER+'/'+r['path']for r in rows}|{FOLDER+'/MANIFEST.json'}
 for row in rows:pin(show(COMMITS[1],FOLDER+'/'+row['path']),row)
 rawRows=json.loads(show(COMMITS[1],FOLDER+'/evidence/raw/RAW_MANIFEST.json'));assert len(rawRows)==31
 for row in rawRows:pin(show(COMMITS[1],FOLDER+'/evidence/raw/'+row['path']),row)
 with zipfile.ZipFile(io.BytesIO(show(COMMITS[1],FOLDER+'/evidence/RAW.zip')))as z:
  assert set(z.namelist())=={r['path']for r in rawRows}|{'RAW_MANIFEST.json'}
  for row in rawRows:pin(z.read(row['path']),row)
  assert z.read('RAW_MANIFEST.json')==show(COMMITS[1],FOLDER+'/evidence/raw/RAW_MANIFEST.json')
 source=json.loads(show(COMMITS[1],FOLDER+'/SOURCE_PROOF.json'))
 prefix=show(BASE,TEST);suffix=show(COMMITS[1],FOLDER+'/NATIVE_HELPER_ADDITION.swift');combined=show(COMMITS[0],TEST);selector=show(COMMITS[0],SELECTOR)
 pin(prefix,source['original_prefix']);pin(suffix,source['suffix']);pin(combined,source['combined']);pin(selector,source['selector'])
 assert prefix==show(DONOR_BASE,TEST) and prefix+suffix==combined
 assert show(COMMITS[1],FOLDER+'/evidence/raw/candidate/'+TEST)==combined
 assert show(COMMITS[1],FOLDER+'/evidence/raw/candidate/'+SELECTOR)==selector
 oldMethods=set(re.findall(rb'func\s+(\w+)\s*\(',prefix));newMethods=set(re.findall(rb'func\s+(\w+)\s*\(',suffix))
 assert not oldMethods.intersection(newMethods)
 declarations=re.findall(r'func\s+(test\w+)\s*\(',selector.decode())
 assert len(declarations)==len(set(declarations))==6 and set(declarations)==set(source['new_tests'])
 membership=json.loads(show(COMMITS[1],FOLDER+'/MEMBERSHIP.json'))
 project=show(BASE,membership['path']);pin(project,membership)
 assert rev(BASE+':'+membership['path'])==membership['git_blob']
 assert membership['group'].encode()in project and membership['target'].encode()in project
 joined=json.loads(show(COMMITS[1],FOLDER+'/evidence/raw/ORIGINAL_SOURCE_JOIN.json'))
 assert joined['base']==DONOR_BASE and len(joined['files'])==20
 currentJoined=[];integratedCorrections=[]
 for row in joined['files']:
  old=show(DONOR_BASE,row['path']);pin(old,row)
  assert show(COMMITS[1],FOLDER+'/evidence/raw/original/'+row['path'])==old
  now=show(BASE,row['path'])
  if row['path']==CONTROLLER:
   assert row['sha256']=='bf7bc1ea1bb559e02a7904dad3508fab1c265ecd07e1592365cab045aecbc714'
   assert sha(now)=='a6577cf5d2060b3849ab06634c9e52915e9048260feda7814c02cf926965bd1c'
   integratedCorrections.append({'path':row['path'],'oldSHA256':row['sha256'],'currentSHA256':sha(now),'qualification':'Already integrated original helper/caller source correction; no new native execution','proof':'docs/hq-integration/wave3-annotation-expansion-intake-20261127/RESULT.json'})
  else:assert now==old;currentJoined.append(row['path'])
 assert len(currentJoined)==19 and len(integratedCorrections)==1
 correctionProof=show(BASE,'docs/hq-integration/wave3-annotation-expansion-intake-20261127/RESULT.json')
 assert sha(correctionProof)=='e38b91cecd433c76740446a0ed440161ca9997f554077800be425ff1d2598212'
 evidenceRaw=show(COMMITS[1],FOLDER+'/evidence/raw/RESULT.json')
 assert sha(evidenceRaw)=='4ec69e698fb83f2c070ce8d4040fcaf390ba03b5df9d63c0dfb1c5ab7e672fe3'
 evidence=json.loads(evidenceRaw)
 assert evidence['status']=='PASS_SOURCE_JOIN_AND_SYNTAX_ONLY'and evidence['native']==evidence['apple_sdk_typecheck']=='NOT_RUN'and evidence['test_execution_count']==0
 assert [(r['name'],r['exit'])for r in evidence['steps']]==[('two-complete-native-source-files-syntax-only',0)]
 assert set(evidence['selector_declarations'])==set(declarations)
 rawDiff=subprocess.run(['git','-C',str(ROOT),'diff','--check',COMMITS[0],COMMITS[1]],capture_output=True)
 assert rawDiff.returncode==2 and rawDiff.stderr==b''and len(rawDiff.stdout)==142 and sha(rawDiff.stdout)=='9a02235702e3e13bc6271b7db6a9f2f5eecc5231084d30fe8dc4da944df6bf1e'
 protected=['Source','Vendor','Scripts','.github','docs/architecture','Maktabah.xcodeproj']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 picked=[]
 for commit in COMMITS:
  git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',commit)
  picked.append({'donor':commit,'intake':rev('HEAD')});assert not git('status','--porcelain')
 assert show('HEAD',TEST)==combined and show('HEAD',SELECTOR)==selector
 assert set(git('diff','--name-only',BASE,'HEAD','--','Maktabah-iOSUITests').decode().splitlines())=={TEST,SELECTOR}
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 (proof/'RAW_ARTIFACT_WHITESPACE.txt.gz').write_bytes(gzip.compress(rawDiff.stdout,mtime=0))
 result={'schema':'otzaria.wave3.annotation-native-selector-intake.v1','base':BASE,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'testPaths':2,'docsPaths':41,'manifestSHA256':sha(index),'manifestRows':len(rows),'verifiedRawFiles':len(rawRows),'originalPrefix':source['original_prefix'],'appendOnlySuffix':source['suffix'],'currentOriginalDependenciesIdentical':currentJoined,'separatelyIntegratedProductCorrections':integratedCorrections,'correctionProofSHA256':sha(correctionProof),'newSelectorDeclarations':declarations,'sourceOnlyResultSHA256':sha(evidenceRaw),'sourceOnlyScope':evidence['scope'],'originalSynchronizedTargetMembership':membership,'protectedTrees':trees,'newTestExecutions':0,'nativeRuns':0,'AppleSDK':'NOT_RUN','fixture':'Original miniTest10 fixture only; no production qualification','open':['All six actual system-native journeys','Final Native116 and Release114+2 with production v40','Siri, VoiceOver, keyboard, locales, cold entry and physical-owner acceptance','Final original-owner signatures, target merge, signed archive and TestFlight']}
 dump(proof/'RESULT.json',result)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Integrate additive original Annotation system acceptance selectors with exact source evidence')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free};dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
