// swift-tools-version: 6.2
import PackageDescription
let package = Package(name: "HanlinHostCheck", platforms: [.iOS("27.0"), .macOS(.v26)], targets: [
    .target(name: "HanlinPlatformContracts", resources: [.process("Resources")]),
    .target(name: "HanlinHostContracts", dependencies: ["HanlinPlatformContracts"]),
    .target(name: "HanlinAgentCore", dependencies: ["HanlinHostContracts", "HanlinPlatformContracts"]),
    .target(name: "OtzariaActionCore", resources: [.process("Resources")]),
    .target(name: "OtzariaHanlinHostAdapter", dependencies: ["HanlinHostContracts", "HanlinPlatformContracts", "OtzariaActionCore"]),
    .testTarget(name: "OtzariaHanlinHostAdapterTests", dependencies: ["HanlinAgentCore", "OtzariaHanlinHostAdapter", "HanlinHostContracts", "HanlinPlatformContracts", "OtzariaActionCore"])
], swiftLanguageModes: [.v6])
