import Foundation
@main struct OccurrenceReportAcceptance {
    private struct ExactOccurrenceCheck: Encodable {
        let query: String
        let request: OtzariaExactOccurrenceRequest
        let result: ObservedOccurrence
    }

    /// Lossless typed projection of the observed Swift/C result. Expected SQL
    /// scalars and revisions belong to the external acceptance gate, not this report.
    private struct ObservedOccurrence: Encodable {
        let occurrences: UInt64
        let matchingLiveDocuments: UInt64
        let proof: Proof
        let work: Work

        init(_ observed: OtzariaExactOccurrenceResult) {
            occurrences = observed.occurrences
            matchingLiveDocuments = observed.matchingLiveDocuments
            proof = Proof(observed.proof)
            work = Work(observed.work)
        }

        struct Segment: Encodable {
            let segmentId: String
            let deleteOpstamp: UInt64?

            init(_ observed: OtzariaExactOccurrenceResult.Segment) {
                segmentId = observed.segmentId
                deleteOpstamp = observed.deleteOpstamp
            }
        }

        struct Snapshot: Encodable {
            let generationId: UInt64
            let segments: [Segment]

            init(_ observed: OtzariaExactOccurrenceResult.Snapshot) {
                generationId = observed.generationId
                segments = observed.segments.map(Segment.init)
            }
        }

        struct Proof: Encodable {
            let requestToken: UInt64
            let countKind: String
            let exact: Bool
            let analyzedToken: String
            let requestedFacets: [String]
            let searcherGeneration: Snapshot
            let liveIndexDocuments: UInt64
            let indexSchemaVersion: UInt32
            let enginePackageVersion: String
            let engineCommit: String
            let originalUpstreamBase: String
            let engineRepository: String
            let engineBranch: String

            init(_ observed: OtzariaExactOccurrenceResult.Proof) {
                requestToken = observed.requestToken
                countKind = observed.countKind
                exact = observed.exact
                analyzedToken = observed.analyzedToken
                requestedFacets = observed.requestedFacets
                searcherGeneration = Snapshot(observed.searcherGeneration)
                liveIndexDocuments = observed.liveIndexDocuments
                indexSchemaVersion = observed.indexSchemaVersion
                enginePackageVersion = observed.enginePackageVersion
                engineCommit = observed.engineCommit
                originalUpstreamBase = observed.originalUpstreamBase
                engineRepository = observed.engineRepository
                engineBranch = observed.engineBranch
            }
        }

        struct Work: Encodable {
            let visitedCandidateDocuments: UInt64
            let inspectedPositions: UInt64
            let visitedSegments: UInt32

            init(_ observed: OtzariaExactOccurrenceResult.Work) {
                visitedCandidateDocuments = observed.visitedCandidateDocuments
                inspectedPositions = observed.inspectedPositions
                visitedSegments = observed.visitedSegments
            }
        }
    }


    private struct Echo: Decodable {
        let query: String
        let request: RequestEcho
        let result: OtzariaExactOccurrenceResult
    }
    private struct RequestEcho: Decodable {
        struct Limits: Decodable {
            let maxCandidateDocuments: UInt64
            let maxPositions: UInt64
            let maxPositionsPerDocument: UInt32
            let maxSegments: UInt32
        }
        let version: Int
        let mode: String
        let query: String
        let facets: [String]
        let bookIds: [UInt64]
        let timeoutMs: UInt64
        let limits: Limits
    }
    private struct FixtureFailure: Error { let reason: String }
    private static func require(_ condition: @autoclosure () -> Bool, _ reason: String) throws {
        if !condition() { throw FixtureFailure(reason: reason) }
    }
    private static func check(
        _ name: String, token: UInt64, generation: UInt64,
        firstDelete: String, secondDelete: String,
        expectedFirst: UInt64?, expectedSecond: UInt64?
    ) throws {
        let occurrenceQuery = "מבחן"
                let request = try OtzariaExactOccurrenceRequest(
                    query: occurrenceQuery,
                    facets: ["/"],
                    bookIds: [],
                    timeoutMs: 60_000,
                    limits: .init(
                        maxCandidateDocuments: 1_000_000,
                        maxPositions: 10_000_000,
                        maxPositionsPerDocument: 262_144,
                        maxSegments: 4_096
                    )
                )

        let source = try OtzariaExactOccurrenceSource(
            engineCommit: String(repeating: "a", count: 40),
            engineRepository: "fixture/observed-repository",
            engineBranch: "fixture/observed-branch",
            originalUpstreamBase: String(repeating: "b", count: 40),
            indexSchemaVersion: 4, enginePackageVersion: "fixture-observed-version"
        )
        // Synthetic C-boundary JSON. No engine, index, model, or Native execution.
        let response = """
        {"ok":true,"value":{
          "occurrences":17,"matchingLiveDocuments":7,
          "proof":{
            "requestToken":\(token),"countKind":"distinctTokenPositions","exact":true,
            "analyzedToken":"טקסט","requestedFacets":["/"],
            "searcherGeneration":{"generationId":\(generation),"segments":[
              {"segmentId":"11111111111111111111111111111111"\(firstDelete)},
              {"segmentId":"22222222222222222222222222222222"\(secondDelete)}
            ]},
            "liveIndexDocuments":501,"indexSchemaVersion":4,
            "enginePackageVersion":"fixture-observed-version",
            "engineCommit":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
            "originalUpstreamBase":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
            "engineRepository":"fixture/observed-repository",
            "engineBranch":"fixture/observed-branch"
          },
          "work":{"visitedCandidateDocuments":23,"inspectedPositions":29,"visitedSegments":2}
        }}
        """
        let original = try OtzariaExactOccurrenceWire.decode(
            Data(response.utf8), request: request, token: token, source: source
        )
        let report = ExactOccurrenceCheck(
            query: occurrenceQuery, request: request, result: ObservedOccurrence(original)
        )
        let encoded = try JSONEncoder().encode(report)
        let echo = try JSONDecoder().decode(Echo.self, from: encoded)
        try require(echo.result == original, "\(name): an observed result field changed")
        try require(echo.query == occurrenceQuery && echo.request.query == occurrenceQuery,
                    "\(name): query wrapper changed")
        let r = echo.request
        try require(r.version == 1 && r.mode == "exact" && r.facets == ["/"] && r.bookIds.isEmpty,
                    "\(name): global original request scope changed")
        try require(r.timeoutMs == 60_000 && r.limits.maxCandidateDocuments == 1_000_000
                    && r.limits.maxPositions == 10_000_000
                    && r.limits.maxPositionsPerDocument == 262_144
                    && r.limits.maxSegments == 4_096, "\(name): hard limits changed")
        let segments = echo.result.proof.searcherGeneration.segments
        try require(segments.map(\.segmentId) == [
            "11111111111111111111111111111111", "22222222222222222222222222222222"
        ], "\(name): segment order changed")
        try require(segments[0].deleteOpstamp == expectedFirst
                    && segments[1].deleteOpstamp == expectedSecond,
                    "\(name): nil, zero, or maximum delete stamp changed")
        try require(echo.result.proof.requestToken == token
                    && echo.result.proof.searcherGeneration.generationId == generation,
                    "\(name): UInt64 identity changed")
        print("PASS \(name)")
    }
    static func main() throws {
        try check("all_observed_fields_and_original_hard_bound_request",
                  token: 41, generation: 42,
                  firstDelete: ",\"deleteOpstamp\":null", secondDelete: ",\"deleteOpstamp\":71",
                  expectedFirst: nil, expectedSecond: 71)
        try check("missing_delete_stamp_retains_semantic_nil",
                  token: 51, generation: 52,
                  firstDelete: "", secondDelete: ",\"deleteOpstamp\":81",
                  expectedFirst: nil, expectedSecond: 81)
        try check("zero_delete_stamp_remains_distinct_from_nil",
                  token: 61, generation: 62,
                  firstDelete: ",\"deleteOpstamp\":0", secondDelete: "",
                  expectedFirst: 0, expectedSecond: nil)
        try check("uint64_max_identity_and_delete_stamp_are_lossless",
                  token: UInt64.max, generation: UInt64.max,
                  firstDelete: ",\"deleteOpstamp\":18446744073709551615", secondDelete: "",
                  expectedFirst: UInt64.max, expectedSecond: nil)
        print("SUMMARY 4 executed 4 passed 0 failed DTO_ONLY")
    }

}
