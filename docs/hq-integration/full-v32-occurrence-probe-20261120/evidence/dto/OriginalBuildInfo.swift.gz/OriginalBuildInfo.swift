import Foundation
struct OtzariaSearchEngineBuildInfo: Codable, Equatable, Sendable {
    let upstreamRepository: String
    let upstreamBranch: String
    let upstreamCommit: String
    let engineVersion: String
    let indexSchemaVersion: UInt32
    let defaultGenerationOrder: UInt32
    let semanticEnabled: Bool
    let semanticSidecarRevision: String
    let syncedAt: String
    let adapterVersion: String
    let resourceHashes: [String: String]
}
