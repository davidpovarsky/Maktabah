from pathlib import Path
import datetime,hashlib,json,re,runpy,subprocess,sys
root=Path.cwd();out=root/'build/release114-selection-20261120/validation-canonical'
out.mkdir(parents=True,exist_ok=False)
(out/'VALIDATION_SOURCE.py').write_bytes(Path(__file__).read_bytes())
snapshot=out/'source';snapshot.mkdir()
base=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
tests=['Scripts/CI/test-runtime27-release-producer.py','Scripts/CI/test-runtime27-release-stages.py',
 'Scripts/CI/test-runtime27-release-handoff.py','Scripts/CI/test-runtime27-release-gate.py']
changed={'Scripts/CI/runtime27-release-manifest.json',*tests[:2]}
tracked=subprocess.check_output(['git','ls-files','Scripts/CI','Maktabah-iOSUITests/*.swift']).decode().splitlines()
paths=[p for p in tracked if Path(p).suffix in {'.py','.json','.swift'}]
paths+=['tools/verify_xcresult_zero_skips.py','.github/workflows/sefaria-embedded-validation.yml']
records=[]
for name in sorted(set(paths)):
 raw=(root/name).read_bytes().replace(b'\r\n',b'\n')
 if name not in changed:assert raw==subprocess.check_output(['git','show',base+':'+name]),name
 target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 records.append({'path':name,'canonicalSHA256':sha(raw),'bytes':len(raw),
                 'source':'current additive manifest/expected-count fixture' if name in changed else 'exact Git blob '+base})
assert sum(x['bytes'] for x in records)<16*1024*1024
(out/'INPUTS_BEFORE.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
sys.path.insert(0,str(snapshot/'Scripts/CI'))
producer=runpy.run_path(str(snapshot/'Scripts/CI/runtime27-release.py'))
m=producer['load_manifest'](snapshot)
ui=[(row['id'],case) for row in m['configurations'] for case in row['required_ui_cases']]
oracles=[(row['id'],case) for row in m['configurations'] for case in row.get('required_oracle_cases',[])]
assert len(ui)==len(set(ui))==114 and len(oracles)==len(set(oracles))==2
report={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,
 'originalLoadManifest':'PASS','originalDeclarationAndPreparedSourceSHAGuards':'PASS',
 'uiExecutionsRequired':114,'uniqueUIMethods':len(set(x[1] for x in ui)),'prototypeExecutionsRequired':2,
 'configurations':len(m['configurations']),'sourceProjectionFiles':len(records),'sourceProjectionBytes':sum(x['bytes'] for x in records),
 'projection':'Whole original files in canonical Git LF; no method, guard, expectedSHA or source stripping changes',
 'native':'NOT_RUN','Apple':'NOT_RUN','productionRelease':'NOT_RUN','fixtures':[]}
for i,test in enumerate(tests):
 command=[sys.executable,'-X','utf8',test]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(command,cwd=snapshot,capture_output=True,timeout=90)
 (out/f'{i}.stdout.log').write_bytes(r.stdout);(out/f'{i}.stderr.log').write_bytes(r.stderr)
 text=r.stderr.decode('utf-8',errors='replace')
 count=re.search(r'Ran (\d+) tests?',text)
 skipped=re.search(r'skipped=(\d+)',text)
 item={'command':command,'cwd':str(snapshot),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'returncode':r.returncode,'tests':int(count.group(1)) if count else None,'skipped':int(skipped.group(1)) if skipped else 0}
 report['fixtures'].append(item)
 print(json.dumps(item),flush=True)
 if r.returncode:
  report['status']='FAIL';(out/'RESULT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
  print(text,flush=True);raise SystemExit(r.returncode)
after=[]
for row in records:
 raw=(snapshot/row['path']).read_bytes()
 assert sha(raw)==row['canonicalSHA256'],row['path']
 assert raw==(root/row['path']).read_bytes().replace(b'\r\n',b'\n'),row['path']
 after.append(dict(row))
(out/'INPUTS_AFTER.json').write_text(json.dumps(after,indent=2),encoding='utf-8')
report.update(status='PASS',inputHashesUnchanged=True,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 totalControls=sum(x['tests'] for x in report['fixtures']),totalSkipped=sum(x['skipped'] for x in report['fixtures']))
(out/'RESULT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report),flush=True)
