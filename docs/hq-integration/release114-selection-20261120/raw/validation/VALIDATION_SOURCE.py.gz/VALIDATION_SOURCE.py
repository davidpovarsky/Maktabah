from pathlib import Path
import datetime,hashlib,json,runpy,subprocess,sys
root=Path.cwd();out=root/'build/release114-selection-20261120/validation'
out.mkdir(parents=True,exist_ok=False)
(out/'VALIDATION_SOURCE.py').write_bytes(Path(__file__).read_bytes())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
manifest='Scripts/CI/runtime27-release-manifest.json'
tests=['Scripts/CI/test-runtime27-release-producer.py','Scripts/CI/test-runtime27-release-stages.py',
 'Scripts/CI/test-runtime27-release-handoff.py','Scripts/CI/test-runtime27-release-gate.py']
helpers=['Scripts/CI/runtime27-release.py','Scripts/CI/runtime27-release-stages.py','Scripts/CI/runtime27_release_handoff.py',
 'Scripts/CI/verify-runtime27-release-gate.py','Scripts/CI/runtime27.py','Scripts/CI/run-faithful-ipad-matrix.py',
 'Scripts/CI/verify-faithful-xctest.py','Scripts/CI/runtime27_interruption.py','.github/workflows/sefaria-embedded-validation.yml']
paths=[manifest,*tests,*helpers]
inputs={p:{'rawSHA256':sha((root/p).read_bytes()),'canonicalLFSHA256':sha((root/p).read_bytes().replace(b'\r\n',b'\n')),'rawBytes':(root/p).stat().st_size} for p in paths}
(out/'INPUTS_BEFORE.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
for p in helpers:
 assert (root/p).read_bytes().replace(b'\r\n',b'\n')==subprocess.check_output(['git','show',base+':'+p]),p
# Original load_manifest checks canonical registered UIKit source SHA on Mac.
# Build a tiny complete-source LF projection from exact Git blobs on Windows;
# no guard, test method, or implementation is patched.
snapshot=out/'canonical-source';snapshot.mkdir()
snapshot_paths=[manifest,'Scripts/CI/runtime27-release.py','Scripts/CI/verify-faithful-xctest.py']
swift_paths=subprocess.check_output(['git','ls-files','Maktabah-iOSUITests/*.swift']).decode().splitlines()
snapshot_paths+=swift_paths
snapshot_records=[]
for p in snapshot_paths:
 raw=(root/p).read_bytes().replace(b'\r\n',b'\n')
 if p!=manifest:assert raw==subprocess.check_output(['git','show',base+':'+p]),p
 target=snapshot/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 snapshot_records.append({'path':p,'canonicalSHA256':sha(raw),'bytes':len(raw),
                           'origin':'exact current candidate manifest' if p==manifest else 'exact canonical Git blob '+base})
(snapshot/'INPUTS.json').write_text(json.dumps(snapshot_records,indent=2),encoding='utf-8')
producer=runpy.run_path(str(snapshot/'Scripts/CI/runtime27-release.py'))
d=producer['load_manifest'](snapshot)
selected=[(r['id'],x) for r in d['configurations'] for x in r['required_ui_cases']]
oracle=[(r['id'],x) for r in d['configurations'] for x in r.get('required_oracle_cases',[])]
assert len(selected)==len(set(selected))==114
assert len(oracle)==len(set(oracle))==2
report={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,
 'originalLoadManifest':'PASS','originalDeclarationAndPreparedSourceSHAGuards':'PASS',
 'uiExecutionsRequired':len(selected),'uniqueUIMethods':len(set(x[1] for x in selected)),
 'prototypeExecutionsRequired':len(oracle),'configurations':len(d['configurations']),
 'native':'NOT_RUN','Apple':'NOT_RUN','productionRelease':'NOT_RUN','fixtures':[]}
for i,test in enumerate(tests):
 command=[sys.executable,'-X','utf8',test]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 r=subprocess.run(command,cwd=root,capture_output=True,timeout=90)
 (out/f'{i}.stdout.log').write_bytes(r.stdout);(out/f'{i}.stderr.log').write_bytes(r.stderr)
 item={'command':command,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode}
 report['fixtures'].append(item)
 print(json.dumps(item),flush=True)
 if r.returncode:
  report['status']='FAIL';(out/'RESULT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
  print(r.stderr.decode('utf-8',errors='replace'),flush=True);raise SystemExit(r.returncode)
after={p:{'rawSHA256':sha((root/p).read_bytes()),'canonicalLFSHA256':sha((root/p).read_bytes().replace(b'\r\n',b'\n')),'rawBytes':(root/p).stat().st_size} for p in paths}
assert inputs==after
(out/'INPUTS_AFTER.json').write_text(json.dumps(after,indent=2),encoding='utf-8')
report.update(status='PASS',inputHashesUnchanged=True,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'RESULT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report),flush=True)
