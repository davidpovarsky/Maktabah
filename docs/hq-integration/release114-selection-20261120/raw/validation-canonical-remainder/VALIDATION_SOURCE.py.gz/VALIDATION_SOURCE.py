from pathlib import Path
import datetime,hashlib,json,re,subprocess,sys
root=Path.cwd();out=root/'build/release114-selection-20261120/validation-canonical-remainder';out.mkdir(exist_ok=False)
(out/'VALIDATION_SOURCE.py').write_bytes(Path(__file__).read_bytes())
prior=root/'build/release114-selection-20261120/validation-canonical'
snap=prior/'source';records=json.loads((prior/'INPUTS_BEFORE.json').read_text(encoding='utf-8'))
for row in records:
 a=(snap/row['path']).read_bytes();b=(root/row['path']).read_bytes().replace(b'\r\n',b'\n')
 assert a==b and hashlib.sha256(a).hexdigest()==row['canonicalSHA256'],row['path']
command=[sys.executable,'-X','utf8','Scripts/CI/test-runtime27-release-gate.py']
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(command,cwd=snap,capture_output=True,timeout=90)
(out/'stdout.log').write_bytes(r.stdout);(out/'stderr.log').write_bytes(r.stderr)
text=r.stderr.decode('utf-8',errors='replace');count=re.search(r'Ran (\d+) tests?',text)
for row in records:
 a=(snap/row['path']).read_bytes();b=(root/row['path']).read_bytes().replace(b'\r\n',b'\n')
 assert a==b and hashlib.sha256(a).hexdigest()==row['canonicalSHA256'],row['path']
(out/'INPUTS_UNCHANGED.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
report={'status':'PASS' if r.returncode==0 else 'FAIL','command':command,'cwd':str(snap),'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode,'tests':int(count.group(1)) if count else None,'inputHashesUnchanged':True,'native':'NOT_RUN','Apple':'NOT_RUN','scope':'Final independent original gate fixture after preserved Windows-specific handoff failures; no skip, expectation, source or runtime guard changes'}
(out/'RESULT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report));print(text[-12000:])
print(subprocess.check_output(['git','status','--short']).decode())
print(subprocess.check_output(['git','diff','--stat']).decode())
print((root/'build/release114-selection-20261120/SOURCE_PRESERVATION.json').read_text(encoding='utf-8')[:18000])
raise SystemExit(r.returncode)
