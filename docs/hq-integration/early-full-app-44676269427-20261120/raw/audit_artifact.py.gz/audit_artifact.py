#!/usr/bin/env python3
"""Read-only verification of the exact early full-app CI artifact; no build/run."""
from pathlib import Path
import collections
import hashlib
import json
import plistlib
import re
import zipfile

ROOT = Path(__file__).resolve().parent
RUN = 44676269427
JOB = 136088741213
HEAD = "f7c110da7f35a1043c1ad6da777cb89fa6d07460"
APP = "34c7ab5ae026a0d3d08f02a2c97ddf4b38e1a56c"
ARTIFACT = 14606375008
ZIP_SHA = "2899854c7566fc11266ce3ddaef0e80a7421253fdf4a34c025cb6df9c3b4c4f7"
HANLIN = "e00498e33f106cc43be0476ffa2e09329c8ca300"
JS_SHA = "6ed1fee31285b96164acc8a17ab1d9d97cbde1394e8dcdd3a1d557fe0ce377ce"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

run = json.loads((ROOT / "workflow-run.json").read_text())
jobs = json.loads((ROOT / "workflow-jobs.json").read_text())
metadata = json.loads((ROOT / "artifact-metadata.json").read_text())
if isinstance(jobs, dict):
    jobs = jobs["jobs"]
assert run["id"] == RUN and run["head_sha"] == HEAD
assert run["status"] == "completed" and run["conclusion"] == "success" and run["run_attempt"] == 1
assert len(jobs) == 5
job = next(x for x in jobs if x["id"] == JOB)
assert job["conclusion"] == "success"
assert len([x for x in jobs if x["conclusion"] == "skipped"]) == 4
assert next(x for x in job["steps"] if x["name"] == "Compile exact integrated app without signing")["conclusion"] == "success"
assert metadata["id"] == ARTIFACT and metadata["workflow_run"]["id"] == RUN
assert metadata["workflow_run"]["head_sha"] == HEAD
assert metadata["digest"] == "sha256:" + ZIP_SHA
zip_path = ROOT / f"{ARTIFACT}.zip"
assert zip_path.stat().st_size == metadata["size_in_bytes"] == 1091125
assert sha(zip_path.read_bytes()) == ZIP_SHA

with zipfile.ZipFile(zip_path) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 30
    assert z.testzip() is None
    members = [{"name": i.filename, "bytes": i.file_size, "compressedBytes": i.compress_size,
                "crc32": f"{i.CRC:08x}", "sha256": sha(z.read(i))} for i in z.infolist()]
    result = json.loads(z.read("result.json"))
    sources = json.loads(z.read("actual-source-inputs.json"))
    assert result["status"] == "UNSIGNED_APP_BUILD_PASS"
    assert result["scope"] == "ONE_UNSIGNED_REAL_IOS_APP_BUILD"
    assert result["checkout_sha"] == HEAD and result["application_source_sha"] == APP
    assert result["device"] == result["runtime"] == "NOT_RUN"
    assert all(result[k] is False for k in ["signing", "archive", "distribution"])
    assert result["no_fixture_or_app_model_mocks"] is True
    assert result["actual_source_inputs_verified"] == len(sources) == 996
    assert result["hanlin_gitlink"] == HANLIN
    before = z.read("hanlin-sdk-inputs.json")
    after = z.read("hanlin-sdk-inputs-after.json")
    assert before == after
    sdk = json.loads(before)
    projection = json.loads((ROOT / "hanlin-sdk-api-tree-projection.json").read_text())
    assert projection["requestedCommit"] == sdk["sha"] == HANLIN
    assert projection["recursiveTreeTruncated"] is False
    original_blobs = {x["path"]: x["sha"] for x in projection["selectedBlobs"]}
    assert original_blobs == sdk["git_blobs"] == result["hanlin_sdk_source"]["git_blobs"]
    assert len(original_blobs) == sdk["verified_files"] == 424
    assert sdk["manifest_sha256"] == result["hanlin_sdk_source"]["manifest_sha256"]

    artifacts_expected = {
        14596463166: ("efc73de90d74fdd380ffecfa334fe9dcece38519832b89cf3fb2a5741dcc25ad", 136041463727),
        14595389912: ("64f4ba7b8d6cfced525732699fd1958ca0cc5ec836369dcf839d91df855914d7", 136041463406),
    }
    for artifact_id, (digest, producer_job) in artifacts_expected.items():
        a = next(x for x in result["artifact_inputs"] if x["id"] == artifact_id)
        assert a["sha256"] == a["verified_sha256"] == digest
        assert a["producer_run"] == 44661774024 and a["producer_attempt"] == 1
        assert a["producer_sha"] == "99f7927e4da72f2463417f5c2de2c4d20c6aa168"
        assert a["producer_job"] == producer_job
        assert a["verified_producer"]["producer_job_conclusion"] == "success"
        assert a["producer_run_conclusion"] == a["verified_producer"]["producer_run_conclusion"] == "failure"
        assert a["verified_producer"]["artifact_digest"] == "sha256:" + digest
    assert result["otzaria_test_additions"]["reviewed_added_regular_files"] == 78
    assert result["otzaria_test_additions"]["mode"] == "EXACT_NEW_TEST_FILES_ONLY"
    assert result["zayit_framework"]["mode"] == "UNCHANGED_PRODUCTION_PREBUILT"
    assert result["zayit_framework"]["changed_paths"] == []
    assert result["embedded_bundle_build"]["mode"] == "REBUILD_EXACT_REVIEWED_JS"
    assert result["embedded_bundle_build"]["bundle_sha256"] == result["built_app_embedded_bundle_sha256"] == result["resource_inputs"]["jsbundle_sha256"] == JS_SHA
    assert result["resource_inputs"]["no_book_database_payload"] is True
    assert len(result["actual_package_checkouts"]) == len(result["package_pins"]) == 17
    for k, v in result["actual_package_checkouts"].items():
        assert v["head"] == result["package_pins"][k] and v["status"] == "CLEAN"
    assert result["package_resolved_sha256"] == result["package_resolved_after_sha256"]
    assert z.read("resolved-Package.resolved") == z.read("workspace-Package.resolved")
    assert sha(z.read("resolved-Package.resolved")) == result["package_resolved_sha256"]
    macro = result["compiler_macro_authorization"]
    assert macro["normal_xcode_fingerprint_validation"] is True and macro["global_validation_disabled"] is False
    assert macro["source_verified_clean"] is True
    assert macro["entry"] == {"fingerprint": result["package_pins"]["equatable"], "packageIdentity": "equatable", "targetName": "EquatableMacros"}

    # Original CocoaPods privacy aggregation is an explicit generated input,
    # not silently claimed identical to the repository's original privacy file.
    generated = result["generated_configuration"]
    assert len(generated) == 1 and generated[0]["path"] == "Source/PrivacyInfo.xcprivacy"
    privacy = generated[0]
    original_bytes, generated_bytes = z.read("privacy-original.xcprivacy"), z.read("privacy-generated.xcprivacy")
    assert sha(original_bytes) == privacy["original_sha256"]
    assert sha(generated_bytes) == privacy["compiled_sha256"]
    old, new = plistlib.loads(original_bytes), plistlib.loads(generated_bytes)
    old_types = old.pop("NSPrivacyAccessedAPITypes")
    new_types = new.pop("NSPrivacyAccessedAPITypes")
    assert old == new
    old_pairs = {(x["NSPrivacyAccessedAPIType"], y) for x in old_types for y in x["NSPrivacyAccessedAPITypeReasons"]}
    new_pairs = {(x["NSPrivacyAccessedAPIType"], y) for x in new_types for y in x["NSPrivacyAccessedAPITypeReasons"]}
    assert old_pairs <= new_pairs
    observed_additions = {(x["category"], x["reason"]) for x in privacy["added_reasons"]}
    assert observed_additions == new_pairs - old_pairs and len(observed_additions) == 6
    dependency_verifications = []
    for addition in privacy["added_reasons"]:
        for dep in addition["dependency_inputs"]:
            data = z.read(dep["artifact_path"])
            assert sha(data) == dep["sha256"]
            tree = plistlib.loads(data)
            assert any(x["NSPrivacyAccessedAPIType"] == addition["category"] and addition["reason"] in x["NSPrivacyAccessedAPITypeReasons"] for x in tree["NSPrivacyAccessedAPITypes"])
            dependency_verifications.append({"category": addition["category"], "reason": addition["reason"], "sha256": dep["sha256"]})

    commands = result["commands"]
    build = next(c for c in commands if c[:2] == ["xcodebuild", "build"])
    assert build[build.index("-workspace") + 1] == "Maktabah.xcworkspace"
    assert build[build.index("-scheme") + 1] == "Maktabah-iOS"
    assert build[build.index("-configuration") + 1] == "Debug"
    assert build[build.index("-destination") + 1] == "generic/platform=iOS Simulator"
    assert all(x in build for x in ["ARCHS=arm64", "CODE_SIGNING_ALLOWED=NO", "CODE_SIGNING_REQUIRED=NO", "FAIL_ON_MISSING_BUNDLE=1"])
    log = z.read("unsigned-app-build.log").decode("utf-8")
    lines = log.splitlines()
    warnings = [{"line": i+1, "message": l} for i,l in enumerate(lines) if re.search(r"\bwarning:", l, re.I)]
    errors = [{"line": i+1, "message": l} for i,l in enumerate(lines) if re.search(r"\berror:", l, re.I)]
    assert not errors
    assert sum(l == "** BUILD SUCCEEDED **" for l in lines) == 1
    selectors = ["ProcessXCFramework ", "Validate ", "Touch ", "Ld ", "main.jsbundle", "** BUILD SUCCEEDED **"]
    selected = []
    for i,l in enumerate(lines):
        if any(x in l for x in selectors) and ("Maktabah.app" in l or "ProcessXCFramework " in l or "** BUILD SUCCEEDED **" in l):
            selected.append({"line": i+1, "message": l})
    assert any("Maktabah.app/Maktabah normal" in x["message"] for x in selected)
    assert any(x["message"].startswith("Validate ") for x in selected)
    assert any("Copying pre-built main.jsbundle (3268663 bytes)" in x["message"] for x in selected)
    assert sum(x["message"].startswith("ProcessXCFramework ") for x in selected) == 2
    # Preserve all compiler warnings and the original raw dependency logs.
    warning_counts = collections.Counter(re.sub(r"^.*?\bwarning:\s*", "", x["message"], flags=re.I) for x in warnings)
    warning_review = {"rule": "case-insensitive word warning followed by colon; occurrences are not unique defects", "compilerWarningLines": len(warnings), "uniqueFullWarningStrings": len({x['message'] for x in warnings}), "compilerErrorLines": len(errors), "allCompilerWarnings": warnings, "messageFrequency": warning_counts.most_common(), "npmAuditSummary": next(l for l in z.read("npm-ci.log").decode().splitlines() if re.match(r"\d+ vulnerabilities", l)), "otherRetainedLogs": ["npm-ci.log", "pod-install.log", "matching-embedded-bundle.log"]}
    assert len(warnings) == 1480
    save("WARNING_INVENTORY.json", warning_review)
    save("BUILD_OUTPUT_WITNESSES.json", selected)
    save("ZIP_MEMBER_HASHES.json", members)
    review = {"status": "VERIFIED_EXACT_EARLY_UNSIGNED_FULL_APP_BUILD", "run": RUN, "job": JOB, "checkout": HEAD, "applicationSource": APP, "registry": "OFF_AT_TESTED_SOURCE", "artifact": {"id": ARTIFACT, "name": metadata["name"], "bytes": zip_path.stat().st_size, "sha256": ZIP_SHA, "members": len(members), "allCRCsVerified": True}, "buildCommand": build, "buildStatus": result["status"], "xcode": result["xcode"], "swift": result["swift"], "sdk": result["sdk_path"], "applicationTrees": result["application_trees"], "sourceInputReferences": len(sources), "sourceInputVerification": "REQUIRES_SEPARATE_GIT_OBJECT_REVIEW", "hanlinOriginalBlobsBeforeAfterAndAPI": len(original_blobs), "hanlinOriginalCommit": HANLIN, "hanlinBeforeAfterBytesEqual": True, "hanlinAPIReuse": "Same authenticated untruncated original API tree retained in early SDK audit; exact 424 paths/blobs independently compared again", "pinnedFrameworkReceipts": result["artifact_inputs"][:2], "frameworkStaticAuditReference": "../occurrence-apple-framework-44661774024-20261120", "preservedOriginalPackageCheckouts": len(result["actual_package_checkouts"]), "packageResolvedBeforeAfterEqual": True, "macroAuthorization": macro, "reviewedJSRebuiltAndCopiedIntoAppSHA256": JS_SHA, "originalReactGitlink": result["native_context"]["gitlink"], "generatedPrivacy": {"originalSha256": privacy["original_sha256"], "compiledSha256": privacy["compiled_sha256"], "otherFieldsUnchanged": True, "allOriginalReasonsPreserved": True, "exactAddedReasons": privacy["added_reasons"], "dependencyReasonVerifications": dependency_verifications}, "warnings": {k: v for k,v in warning_review.items() if k not in ["allCompilerWarnings", "messageFrequency"]}, "runtime": "NOT_RUN", "nativeTests": "NOT_RUN", "signing": False, "archive": False, "distribution": False, "builtAppBinaryRetention": "Artifact contains authenticated build log and built bundle hash, not the app executable/DerivedData; no independent post-download app binary hash asserted", "reviewDidNotBuildOrExecute": True}
    save("ARTIFACT_REVIEW.json", review)
    print(json.dumps({"status": review["status"], "members": len(members), "originalSDKBlobs": len(original_blobs), "sourceInputs": len(sources), "compilerWarnings": len(warnings), "buildOutputWitnesses": len(selected), "reviewSHA256": sha((ROOT/'ARTIFACT_REVIEW.json').read_bytes())}, indent=2))
