from pathlib import Path
import subprocess,json,zipfile,hashlib,shutil
p=Path(r'C:\Users\DAVID\Code\Maktabah-index-read-compatibility-20261120')
out=p/'build/early-app-44676269427-20261120'
head='f7c110da7f35a1043c1ad6da777cb89fa6d07460'
app='34c7ab5ae026a0d3d08f02a2c97ddf4b38e1a56c'
def git(*args):return subprocess.check_output(['git',*args],cwd=p)
def blob(path):return git('show',head+':'+path)
def git_blob_sha(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
with zipfile.ZipFile(out/'14606375008.zip') as z:
 r=json.loads(z.read('result.json'))
 src=json.loads(z.read('actual-source-inputs.json'))
 generated_privacy=z.read('privacy-generated.xcprivacy')
tree=git('ls-tree','-r',head,'Source','Vendor').decode('utf-8').splitlines()
entries={line.split('\t',1)[1]:line.split('\t',1)[0].split()[2] for line in tree}
mismatch=[{'path':path,'expectedArtifactBlob':v,'actualCommitBlob':entries.get(path)} for path,v in src.items() if entries.get(path)!=v]
assert len(mismatch)==1 and mismatch[0]['path']=='Source/PrivacyInfo.xcprivacy',mismatch
privacy=r['generated_configuration'][0]
privacy_raw=blob('Source/PrivacyInfo.xcprivacy')
assert hashlib.sha256(privacy_raw).hexdigest()==privacy['original_sha256']
assert entries['Source/PrivacyInfo.xcprivacy']==privacy['original_git_blob']==git_blob_sha(privacy_raw)
assert src['Source/PrivacyInfo.xcprivacy']==git_blob_sha(generated_privacy)
assert hashlib.sha256(generated_privacy).hexdigest()==privacy['compiled_sha256']
hash_paths={'validator_sha256':'Scripts/CI/hq-stage2-focused-apple.py','inputs_sha256':'Scripts/CI/hq-stage2-focused-apple.inputs.json','workflow_sha256':'.github/workflows/sefaria-embedded-validation.yml','project_sha256':'Maktabah.xcodeproj/project.pbxproj'}
source_hashes=[]
for key,path in hash_paths.items():
 raw=blob(path); actual=hashlib.sha256(raw).hexdigest();assert actual==r[key],(key,actual,r[key])
 source_hashes.append({'path':path,'bytes':len(raw),'sha256':actual})
trees={}
for path,expected in r['application_trees'].items():
 a=git('rev-parse',head+':'+path).decode().strip()
 b=git('rev-parse',app+':'+path).decode().strip()
 assert a==b==expected,(path,a,b,expected)
 trees[path]=a
for path,expected in r['embedded_bundle_build']['overlay_source_sha256'].items():
 assert hashlib.sha256(blob(path)).hexdigest()==expected
 assert entries[path]==src[path]
policy_path='Source/Otzaria/Search/Distribution/OtzariaSearchArtifactPolicy.swift'
policy=blob(policy_path).decode('utf-8')
registry_line='    private static let qualifiedContracts: Set<Contract> = []'
assert registry_line in policy
review={'status':'PASS_IMMUTABLE_SOURCE_BINDING_WITH_ORIGINAL_GENERATED_PRIVACY_INPUT','checkout':head,'applicationSource':app,'actualSourceInputCount':len(src),'matchedUnchangedGitBlobReferences':len(src)-1,'exactGeneratedInputCount':1,'unexplainedMismatches':[],'canonicalGitSHA256References':source_hashes,'identicalApplicationTrees':trees,'privacyGeneratedInputException':{'path':'Source/PrivacyInfo.xcprivacy','originalGitBlob':entries['Source/PrivacyInfo.xcprivacy'],'compiledGitBlob':src['Source/PrivacyInfo.xcprivacy'],'originalSHA256':privacy['original_sha256'],'compiledSHA256':privacy['compiled_sha256'],'dependencyAndDeclarationAudit':'ARTIFACT_REVIEW.json; original archived dependency privacy files'},'registryPolicyPath':policy_path,'registryState':'OFF','registryDeclaration':registry_line.strip(),'JSOverlayOriginalBlobAndSHA256Matched':True,'inputVerificationTiming':'Original validator verifies tracked input hashes after dependency setup and before xcodebuild. It rechecks original Hanlin SDK blobs, package lock and copied app JS after the build; it does not record a second complete 996-path after-build map.','reviewDidNotCompileOrRunApp':True}
(out/'SOURCE_BINDING_REVIEW.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
script=blob('Scripts/CI/hq-stage2-focused-apple.py').decode('utf-8').splitlines()
selected=[]
for a,b in [(402,420),(462,490),(680,713)]:
 selected.append({'startLine':a,'text':'\n'.join(script[a-1:b])})
(out/'VALIDATOR_SOURCE_EXCERPTS.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(__file__,out/'audit_source_binding.py')
print(json.dumps({'status':review['status'],'matchedUnchanged':len(src)-1,'exactGenerated':1,'hashes':source_hashes,'trees':trees,'reviewSHA256':hashlib.sha256((out/'SOURCE_BINDING_REVIEW.json').read_bytes()).hexdigest()},ensure_ascii=False))

(out/'AUDITOR_ATTEMPT1.json').write_text(json.dumps(json.loads("{\"status\":\"READ_ONLY_AUDITOR_ATTEMPT_FAILED_EXPECTED_GENERATED_INPUT_EXCEPTION\",\"returncode\":1,\"output\":\"Traceback (most recent call last):\\r\\n  File \\\"C:\\\\ProgramData\\\\SentinelX\\\\uploads\\\\.sentinelx_uploads\\\\script_job_b82f76177b2340378959539d8c6a4698\\\\script.py\\\", line 21, in <module>\\r\\n    assert not mismatch,mismatch\\r\\n           ^^^^^^^^^^^^\\r\\nAssertionError: [{'path': 'Source/PrivacyInfo.xcprivacy', 'expectedArtifactBlob': 'af80d26d37547b62412f5922bfd9cc601a7e9344', 'actualCommitBlob': 'c86c62cc12e3ceadea279ff9948a8891a0860577'}]\",\"scope\":\"First reviewer incorrectly expected all 996 input blobs identical to Git; actual privacy aggregation is explicitly recorded and authenticated by the original validator. This is not a CI/build failure.\"}"),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
