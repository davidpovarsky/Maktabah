from pathlib import Path
import json,zipfile,hashlib,subprocess,re,datetime,plistlib
out=Path('build/native-restart-20261119/run-44571075774');review=out/'review';review.mkdir(exist_ok=True)
def git_tree(root,ref):
    rows=subprocess.check_output(['git','ls-tree','-r','-z',ref],cwd=root).split(b'\0')
    result={}
    for row in rows:
        if row:
            meta,path=row.split(b'\t',1);result[path.decode('utf-8')]=meta.split()[2].decode('ascii')
    return result
source_ref='5a40fe9c25e8dd6cfaef71c2f51e34d0adbd796e'
app_git=git_tree('.',source_ref)
sdk_git=git_tree('C:/Users/DAVID/Code/hanlin-otzaria-navigation-20261119','6d62957852ffcb428810b065b4252e5384f1374b')
with zipfile.ZipFile(out/'runtime27-evidence.zip') as z:
    runtime=json.loads(z.read('artifacts/runtime27/result.json'))
    verified=json.loads(z.read('artifacts/runtime27/verified-11.json'))
    summaryraw=z.read('artifacts/runtime27/verified-11.summary.json');testsraw=z.read('artifacts/runtime27/verified-11.tests.json')
    summary=json.loads(summaryraw);tests=json.loads(testsraw)
    assert runtime['checkout_sha']==source_ref and runtime['executed_ui_pass']==2
    assert runtime['executed_ui_fail']==runtime['executed_ui_skip']==runtime['ui_not_run']==0
    for value,label in [(summary,'summary'),(tests,'tests')]:
        assert hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()==verified[label+'_sha256']
    leaves=[]
    def walk(node):
        if node.get('nodeType')=='Test Case':leaves.append(node)
        for child in node.get('children',[]):walk(child)
    for node in tests['testNodes']:walk(node)
    expected=set(verified['required_ui_cases'])
    assert len(leaves)==2 and {n['nodeIdentifier'].removesuffix('()') for n in leaves}==expected
    assert all(n['result']=='Passed' for n in leaves)
    assert summary['totalTestCount']==summary['passedTests']==2
    assert summary['failedTests']==summary['skippedTests']==summary['expectedFailures']==0
    actual=json.loads(z.read('hq-stage2/actual-source-inputs.json'))
    assert len(actual)==876
    mismatches=[p for p,h in actual.items() if app_git.get(p)!=h]
    assert mismatches==['Source/PrivacyInfo.xcprivacy'],mismatches
    build=json.loads(z.read('hq-stage2/result.json'))
    privacy=build['generated_configuration'];assert len(privacy)==1
    privacy=privacy[0];assert privacy['path']==mismatches[0]
    original=z.read('hq-stage2/privacy-original.xcprivacy')
    generated=z.read('hq-stage2/privacy-generated.xcprivacy')
    assert original==subprocess.check_output(['git','show',source_ref+':'+mismatches[0]])
    assert hashlib.sha256(original).hexdigest()==privacy['original_sha256']
    assert hashlib.sha256(generated).hexdigest()==privacy['compiled_sha256']
    assert hashlib.sha1(b'blob '+str(len(generated)).encode()+b'\0'+generated).hexdigest()==actual[mismatches[0]]
    before=plistlib.loads(original);after=plistlib.loads(generated)
    api_key='NSPrivacyAccessedAPITypes'
    assert {k:v for k,v in before.items() if k!=api_key}=={k:v for k,v in after.items() if k!=api_key}
    def categories(value):
        rows=value.get(api_key,[])
        result={row['NSPrivacyAccessedAPIType']:set(row['NSPrivacyAccessedAPITypeReasons']) for row in rows}
        assert len(result)==len(rows)
        return result
    before_categories=categories(before);after_categories=categories(after)
    assert all(reasons<=after_categories.get(category,set()) for category,reasons in before_categories.items())
    added={(category,reason) for category,reasons in after_categories.items() for reason in reasons-before_categories.get(category,set())}
    assert added=={(item['category'],item['reason']) for item in privacy['added_reasons']}
    dependency_hashes=set()
    for item in privacy['added_reasons']:
        assert item['dependency_inputs']
        for dependency in item['dependency_inputs']:
            raw=z.read('hq-stage2/'+dependency['artifact_path'])
            assert hashlib.sha256(raw).hexdigest()==dependency['sha256']
            assert item['reason'] in categories(plistlib.loads(raw)).get(item['category'],set())
            dependency_hashes.add(dependency['sha256'])
    sdk=json.loads(z.read('hq-stage2/hanlin-sdk-inputs.json'))
    assert sdk==json.loads(z.read('hq-stage2/hanlin-sdk-inputs-after.json'))
    assert len(sdk['git_blobs'])==422 and all(sdk_git.get(p)==h for p,h in sdk['git_blobs'].items())
    tree1=subprocess.check_output(['git','rev-parse',source_ref+':Maktabah-iOSUITests'],text=True).strip()
    tree0=subprocess.check_output(['git','rev-parse','5456dab63e963aa68688798a09e601491190bcac:Maktabah-iOSUITests'],text=True).strip()
    assert tree1==tree0==runtime['test_tree']
    hashes={**runtime['test_inputs_sha256'],**runtime['helper_inputs_sha256']}
    for path,digest in hashes.items():
        blob=subprocess.check_output(['git','show',source_ref+':'+path])
        assert hashlib.sha256(blob).hexdigest()==digest,path
    cases=[{'case':n['nodeIdentifier'].removesuffix('()'),'status':n['result'],'duration_seconds':n['durationInSeconds']} for n in leaves]
with zipfile.ZipFile(out/'runtime27-native-captures.zip') as z:
    manifest=json.loads(z.read('visual-11/manifest.json'))
    attachments=[a for t in manifest for a in t['attachments']]
    def attachment(term):
        matches=[a for a in attachments if term in a['suggestedHumanReadableName']]
        assert len(matches)==1,(term,matches)
        return 'visual-11/'+matches[0]['exportedFileName']
    beforetxt=z.read(attachment('hanlin-original-draft-before-dismiss-hierarchy')).decode('utf-8')
    aftertxt=z.read(attachment('hanlin-original-draft-after-process-restart-hierarchy')).decode('utf-8')
    beforepid=re.search(r'pid: (\d+)',beforetxt).group(1);afterpid=re.search(r'pid: (\d+)',aftertxt).group(1)
    assert beforepid!=afterpid and 'otzaria-hanlin-reconnect' in aftertxt
    assert any('otzaria-hanlin-send' in line and 'Disabled' in line for line in aftertxt.splitlines())
    assert 'Study chat unavailable' not in aftertxt
    beforepng=attachment('hanlin-reader-original-before-chat_')
    afterpng=attachment('hanlin-reader-original-after-chat-dismissal_')
    assert z.read(beforepng)==z.read(afterpng)
    reader_hash=hashlib.sha256(z.read(beforepng)).hexdigest()
    images=[attachment('hanlin-original-draft-after-process-restart-screen'),attachment('hanlin-original-draft-before-dismiss-screen'),beforepng,afterpng]
    for n in images:(review/Path(n).name).write_bytes(z.read(n))
report={'status':'ORIGINAL_NATIVE_CONSUMER_2_OF_2_VERIFIED_PASS','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'run_id':44571075774,'source_sha':source_ref,'application_source_sha':'868a94c0e4bfb8171cc910dc432710651054aa5d',
 'cases':cases,'missing':[],'duplicates':[],'skipped':0,'failed':0,
 'verified_app_source_git_blobs':875,'verified_original_dependency_generated_privacy_inputs':1,'privacy_added_reasons':len(added),'privacy_dependency_input_files':len(dependency_hashes),'verified_sdk_source_git_blobs':422,'sdk_before_after_identical':True,
 'verified_test_and_helper_sha256_inputs':len(hashes),'test_tree_unchanged_from':'5456dab63e963aa68688798a09e601491190bcac','test_tree':tree1,
 'draft_process_before':beforepid,'draft_process_after':afterpid,
 'draft_value_exactness':'Original XCTest asserts complete Hebrew/English multiline editor value after reopen and restart. AX itself truncates the displayed value.',
 'after_restart_reconnect_visible_and_send_disabled':True,
 'reader_before_after_png_sha256':reader_hash,'reader_before_after_png_identical':True,
 'review_images':[str((review/Path(n).name).resolve()) for n in images],'device':tests['devices'][0],
 'xcresult_export_hash_mode':'Original verifier hashes json.dumps(value, sort_keys=True); independently matched. Raw file hashes recorded separately.',
 'summary_json_raw_sha256':hashlib.sha256(summaryraw).hexdigest(),'tests_json_raw_sha256':hashlib.sha256(testsraw).hexdigest(),
 'boundaries':['Pinned Simulator native UI only','No model/provider requests','No host transition API1.2 adoption','No full corpus, physical device, integrated77 or release acceptance']}
(review/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,ensure_ascii=False))
