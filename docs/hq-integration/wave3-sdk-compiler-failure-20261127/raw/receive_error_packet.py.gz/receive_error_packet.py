import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

base = Path(__file__).resolve().parent
out = base / 'compiler-failure-packet'
assert not out.exists(), 'Preserve an existing attempt; do not overwrite it'
assert shutil.disk_usage(base).free > 2415919104 + 33554432
out.mkdir()
script = (base / 'build_error_packet.py').read_bytes()
archive = out / 'original-sdk-compiler-failure.tar.gz'
with (out / 'REMOTE_STDERR.txt').open('xb') as se:
    p = subprocess.Popen(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8',
                          'scaleway-mac', '/usr/bin/python3', '-'],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=se)
    p.stdin.write(script)
    p.stdin.close()
    h = hashlib.sha256()
    total = 0
    with archive.open('xb') as f:
        while True:
            b = p.stdout.read(1048576)
            if not b:
                break
            assert shutil.disk_usage(out).free > 2415919104 + len(b) + 1048576
            f.write(b)
            h.update(b)
            total += len(b)
        f.flush()
        os.fsync(f.fileno())
    p.stdout.close()
    rc = p.wait(timeout=60)
assert rc == 0, 'Actual read-only packet producer failed; preserve its stderr and partial file'
actual = {}
capture = {}
with tarfile.open(archive, 'r:gz') as tf:
    for member in tf:
        assert member.isfile() and member.name not in actual
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
        mh = hashlib.sha256()
        size = 0
        pieces = []
        keep = member.name in {'FILE_MANIFEST.json', 'COMPILER_FAILURE.json',
                               'ORIGINAL17_INPUT_GUARDS.json', 'XCRESULT_BUILD_RESULTS.json',
                               'XCRESULT_MEMBERS.json'}
        with tf.extractfile(member) as f:
            while b := f.read(1048576):
                mh.update(b)
                size += len(b)
                if keep:
                    pieces.append(b)
        assert size == member.size
        actual[member.name] = {'bytes': size, 'sha256': mh.hexdigest()}
        if keep:
            capture[member.name] = b''.join(pieces)
manifest = json.loads(capture['FILE_MANIFEST.json'])
expected = {x['path']: x for x in manifest['files']}
assert set(actual) - {'FILE_MANIFEST.json'} == set(expected)
for name, row in expected.items():
    assert actual[name]['bytes'] == row['bytes'] and actual[name]['sha256'] == row['sha256']
for name, b in capture.items():
    with (out / name).open('xb') as f:
        f.write(b)
        f.flush()
        os.fsync(f.fileno())
summary = json.loads(capture['COMPILER_FAILURE.json'])
result = {'status': 'EXACT_COMPILER_FAILURE_PACKET_FULLY_VERIFIED',
          'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'archive': str(archive), 'archiveBytes': total, 'archiveSHA256': h.hexdigest(),
          'regularMembersVerified': len(actual), 'manifestSHA256': actual['FILE_MANIFEST.json']['sha256'],
          'summarySHA256': actual['COMPILER_FAILURE.json']['sha256'],
          'sourceScriptSHA256': hashlib.sha256(script).hexdigest(),
          'receiverSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'compilerFailure': summary['firstCompilerCause'], 'actualXcodebuildExit': 65,
          'newRuns': 0, 'macPacketFilesWritten': 0, 'oracleWrites': 0,
          'windowsFreeAfter': shutil.disk_usage(out).free}
with (out / 'PACKET_VERIFIED.json').open('xb') as f:
    f.write((json.dumps(result, indent=2) + '\n').encode())
    f.flush()
    os.fsync(f.fileno())
print(json.dumps(result), flush=True)
