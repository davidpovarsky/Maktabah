import datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent
rows=json.loads((out/'TRANSFER_ROWS.json').read_bytes())
remote_body="import ast,base64,datetime,hashlib,json,os,pwd,subprocess,tempfile\nfrom pathlib import Path\nassert pwd.getpwuid(os.geteuid()).pw_name=='m1','Must use existing m1 pinned SSH context'\ndf=subprocess.run(['/bin/df','-k','/System/Volumes/Data'],capture_output=True,text=True,check=True).stdout\nfree=int(df.splitlines()[1].split()[3])*1024\nassert free>=2415919104+2097152,'Original live reserve before small envelope write'\ncontrol=Path(tempfile.mkdtemp(prefix='otzaria-wave3-sdk-fresh-after-five-launch-20261127.',dir='/Users/m1/builds'))\nverified=[]\nfor row in rows:\n b=base64.b64decode(row['base64'],validate=True);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']\n q=control/row['name'];assert q.parent==control\n with q.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())\n assert q.read_bytes()==b\n if q.suffix=='.py':ast.parse(b)\n verified.append({'name':q.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})\ncopy={'status':'EXACT_APPROVED_LAUNCH_INPUTS_COPIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'control':str(control),'verified':verified,'freeBeforeCopy':free,'user':'m1'}\nwith(control/'COPY_RESULT.json').open('xb')as f:f.write((json.dumps(copy,indent=2)+'\\n').encode());f.flush();os.fsync(f.fileno())\np=subprocess.run(['/opt/homebrew/opt/python@3.12/libexec/bin/python3','-B',str(control/'launch_owned.py'),'--execute-root-authorized-attempt'],capture_output=True,timeout=120)\nfor name,b in [('launch.stdout.log',p.stdout),('launch.stderr.log',p.stderr)]:\n with(control/name).open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())\nresult={'status':'OWNED_LAUNCH_SUBMITTED'if p.returncode==0 else'LAUNCH_FAILED_NO_RETRY','control':str(control),'launchExit':p.returncode,'copied':verified,'freeBeforeCopy':free,'stdout':p.stdout.decode('utf-8','replace'),'stderr':p.stderr.decode('utf-8','replace')}\nwith(control/'BRIDGE_REMOTE_RESULT.json').open('xb')as f:f.write((json.dumps(result,indent=2)+'\\n').encode());f.flush();os.fsync(f.fileno())\nprint(json.dumps(result),flush=True)\nraise SystemExit(p.returncode)\n"
remote='import json\nrows=json.loads('+repr(json.dumps(rows))+')\n'+remote_body
assert shutil.disk_usage(out).free>2415919104+2097152,'Windows reserve'
for row in rows:
 import base64
 b=base64.b64decode(row['base64'],validate=True);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
 with(out/row['name']).open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
assert not(out/'BRIDGE_RESULT.json').exists(),'No retry authorized'
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','scaleway-mac','/usr/bin/python3','-'],input=remote.encode(),capture_output=True,timeout=180)
for name,b in [('REMOTE_STDOUT.json',p.stdout),('REMOTE_STDERR.txt',p.stderr)]:
 with(out/name).open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
result={'status':'DURABLE_LAUNCH_REQUEST_COMPLETED'if p.returncode==0 else'LAUNCH_BRIDGE_FAILED_REQUIRES_READBACK','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'bridgeSourceSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'remoteSourceSHA256':hashlib.sha256(remote.encode()).hexdigest(),'stdoutBytes':len(p.stdout),'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrBytes':len(p.stderr),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest(),'windowsFreeAfter':shutil.disk_usage(out).free,'oracleWrites':0}
try:result['remote']=json.loads(p.stdout)
except ValueError:result['remoteParseError']=True
with(out/'BRIDGE_RESULT.json').open('xb')as f:f.write((json.dumps(result,indent=2)+'\n').encode());f.flush();os.fsync(f.fileno())
print(json.dumps(result),flush=True)
raise SystemExit(p.returncode)

