"""Read the exact failed SDK attempt and stream a small, lossless evidence packet."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile

ROOT = Path('/Users/m1/builds/otzaria-wave1-sdk-20261127/source')
SOURCE = '1be970356c655bcef3688ddf1d129d5029bbc533'
CONTROL = Path('/Users/m1/builds/otzaria-wave3-sdk-fresh-after-five-launch-20261127.4pw02_zj')
OUT = Path('/Users/m1/builds/otzaria-root-actions-acceptance-20261126.wjQnLNJl/wave3-sdk-fresh-after-five-scopes-20261127.degtfvn6')
EVIDENCE = ROOT / 'build/SDK-Wave3-1be97035-Debug-FreshAfterFiveScopes-20261127-Evidence'
MACRO = ROOT / 'build/SDK-Wave3-1be97035-ReviewedMacro-FreshAfterFiveScopes-20261127'
ABI = ROOT / 'build/SDK-Wave3-1be97035-NativeABI-FreshAfterFiveScopes-20261127'
ERROR_PATH = 'Anytype/Sources/ServiceLayer/Block/Pastboard/PasteboardHelper.swift'
files = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while b := f.read(1048576):
            h.update(b)
    return h.hexdigest()


def git(*args):
    return subprocess.run(['/usr/bin/git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
                           '-C', str(ROOT), *args], capture_output=True, check=True).stdout


def blob(path):
    return git('show', SOURCE + ':' + path)


def add_bytes(tf, name, data, source=None):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o644
    info.mtime = 0
    tf.addfile(info, io.BytesIO(data))
    files.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'source': source})


def add_json(tf, name, value):
    add_bytes(tf, name, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())


class HashingReader:
    def __init__(self, file):
        self.file = file
        self.hash = hashlib.sha256()

    def read(self, size=-1):
        data = self.file.read(size)
        self.hash.update(data)
        return data


def add_file(tf, name, path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and not path.is_symlink()
    info = tarfile.TarInfo(name)
    info.size = before.st_size
    info.mode = stat.S_IMODE(before.st_mode)
    info.mtime = before.st_mtime
    with path.open('rb') as f:
        reader = HashingReader(f)
        tf.addfile(info, reader)
        digest = reader.hash.hexdigest()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    files.append({'path': name, 'bytes': before.st_size, 'sha256': digest, 'source': str(path),
                  'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns})


head = git('rev-parse', 'HEAD').decode().strip()
status = git('status', '--porcelain', '--untracked-files=no').decode()
assert head == SOURCE and not status.strip(), 'Preserve current source state; do not misbind a changed checkout'
claim = json.loads((CONTROL / 'LAUNCH_CLAIM.json').read_bytes())
assert claim['originalGuardFilesVerified'] == 17
contract = json.loads((CONTROL / 'HISTORICAL_OBSERVED_CONTRACT.json').read_bytes())
launch = json.loads((CONTROL / 'LAUNCH_INPUTS.json').read_bytes())
guards = []
for row in contract['original_files'] + [launch['preflightGuard']]:
    b = (ROOT / row['path']).read_bytes()
    assert len(b) == row['bytes'] and sha(b) == row['sha256'] and b == blob(row['path'])
    guards.append(dict(row, current_matches=True, matches_exact_source_blob=True))
source = (ROOT / ERROR_PATH).read_bytes()
assert source == blob(ERROR_PATH) and sha(source) == '1edd18bf419c01fb88f72dcbca367e3417b2b8993394d1d0a3190dcb685b7eb0'
before = (EVIDENCE / 'source-before.json').read_bytes()
after = (EVIDENCE / 'source-after.json').read_bytes()
assert before == after and sha(before) == '1ce89f67d515fcb4745ce29e65e59452cb379797673e59523ed51f39883700d2'
execution = json.loads((EVIDENCE / 'execution.json').read_bytes())
command = json.loads((EVIDENCE / 'framework-build.command.json').read_bytes())
assert command['returncode'] == 65 and command['timed_out'] is False
assert file_digest(EVIDENCE / 'framework-build.stdout.log') == command['stdout_sha256']
assert file_digest(EVIDENCE / 'framework-build.stderr.log') == command['stderr_sha256']
export = subprocess.run(['/usr/bin/xcrun', 'xcresulttool', 'get', 'build-results', '--path',
                         str(EVIDENCE / 'framework-build.xcresult'), '--compact'], capture_output=True, timeout=60)
assert export.returncode == 0 and sha(export.stdout) == 'c34e548df71b4eb82e9c3489b4078da23609c8d0d722540c66514776bafce8cd'
xc = json.loads(export.stdout)
assert xc['status'] == 'failed' and xc['errorCount'] == 1
errors = []
with (EVIDENCE / 'framework-build.stdout.log').open('r', errors='replace') as f:
    for n, line in enumerate(f, 1):
        if re.match(r'^/.+\.swift:\d+:\d+: (?:fatal )?error:', line):
            errors.append({'logLine': n, 'text': line.rstrip('\n')})
assert len(errors) == 1 and 'PasteboardHelper.swift:88:88:' in errors[0]['text']
xc_members = []
xcroot = EVIDENCE / 'framework-build.xcresult'
for parent, dirs, names in os.walk(xcroot, followlinks=False):
    for name in sorted(dirs + names):
        q = Path(parent) / name
        s = q.lstat()
        row = {'path': str(q.relative_to(xcroot)), 'mode': s.st_mode, 'bytes': s.st_size,
               'mtime_ns': s.st_mtime_ns}
        if stat.S_ISREG(s.st_mode):
            row['sha256'] = file_digest(q)
        elif stat.S_ISLNK(s.st_mode):
            row['target'] = os.readlink(q)
        xc_members.append(row)
summary = {
    'schema': 'otzaria.wave3.actual-sdk-compiler-failure/1',
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'ACTUAL_PRODUCER_COMPILE_FAILED_NOT_ACCEPTED',
    'sourceSHA': head, 'trackedStatus': status, 'currentOriginalGuards': len(guards),
    'executionID': 'local-ad6e0a4b-ca9a-4d64-91ea-8d1c1c843ee7',
    'firstCompilerCause': errors[0], 'actualXcodebuildExit': 65,
    'actualXcodebuildTimedOut': False, 'reserveInterruptionRecorded': False,
    'xcresultErrors': xc['errorCount'], 'xcresultWarnings': xc['warningCount'],
    'sourceErrorFile': {'path': ERROR_PATH, 'bytes': len(source), 'sha256': sha(source)},
    'sourceBeforeAfterBytesEqual': True, 'sourceBeforeAfterSHA256': sha(before),
    'originalStatusFields': {k: execution.get(k) for k in ['status', 'phase', 'error', 'error_type',
        'strict_dependency_resolution', 'original_framework_build', 'external_consumer_build',
        'native_editor_ui_tests', 'original_app_runtime', 'editable_mount', 'verified_runtime_observations']},
    'interpretation': 'The framework compiler actually ran and failed. The original framework NOT_RUN scalar does not mean no compiler process was launched; no completed framework qualification exists. Downstream consumer/runtime gates remain unrun.',
    'minimalSourceCandidateForOwnerReview': 'Add explicit options: [] to PropertyListSerialization.propertyList(from: data, options: [], format: nil). No source edit or candidate verification performed by this reviewer.',
    'newMaktabahAppBuilds': 0, 'newMaktabahNativeRuns': 0, 'retryExecuted': False,
    'cleanupExecuted': False, 'macPacketFilesWritten': 0, 'oracleWrites': 0,
    'retainedOriginalXcresult': str(xcroot),
}
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|gz') as tf:
    add_json(tf, 'COMPILER_FAILURE.json', summary)
    add_json(tf, 'ORIGINAL17_INPUT_GUARDS.json', {'sourceSHA': head, 'trackedStatus': status, 'guards': guards})
    add_json(tf, 'XCRESULT_MEMBERS.json', {'path': str(xcroot), 'retained_in_place': True, 'members': xc_members})
    add_bytes(tf, 'XCRESULT_BUILD_RESULTS.json', export.stdout, 'xcresulttool get build-results --compact')
    add_bytes(tf, 'source/PasteboardHelper.swift', source, str(ROOT / ERROR_PATH))
    for name in ['execution.json', 'framework-build.command.json', 'framework-build.stdout.log',
                 'framework-build.stderr.log', 'source-before.json', 'source-after.json',
                 'source-admission.json', 'import-abi-before.json', 'original-hanlin-snapshot.json',
                 'owned-simulator-cleanup.json', 'local-execution.json', 'local-execution.env',
                 'exact-package-resolution.command.json', 'exact-package-resolution.stdout.log',
                 'exact-package-resolution.stderr.log', 'actual-swift.command.json', 'actual-swift.stdout.log',
                 'actual-swift.stderr.log', 'actual-simulator-sdk.command.json', 'actual-simulator-sdk.stdout.log',
                 'actual-simulator-sdk.stderr.log']:
        add_file(tf, 'original/' + name, EVIDENCE / name)
    for name in ['LAUNCH_INPUTS.json', 'LAUNCH_CLAIM.json', 'LAUNCH_RESULT.json', 'WATCHER_STARTED.json',
                 'SUPERVISOR_PROCESS.json', 'WATCHER_RESULT.json', 'supervisor.py', 'completion_watcher.py',
                 'launch_owned.py', 'supervisor.stdout.log', 'supervisor.stderr.log', 'watcher.stdout.log',
                 'watcher.stderr.log', 'COPY_RESULT.json', 'BRIDGE_REMOTE_RESULT.json',
                 'FRESH_RUN_COMMANDS.json', 'HISTORICAL_OBSERVED_CONTRACT.json', 'PROPOSAL.json']:
        add_file(tf, 'controller/' + name, CONTROL / name)
    add_file(tf, 'supervisor/RESULT.json', OUT / 'RESULT.json')
    add_file(tf, 'macro/macro-restoration.json', MACRO / 'macro-restoration.json')
    add_file(tf, 'abi/ABI_DONOR_INPUT.json', ABI / 'ABI_DONOR_INPUT.json')
    add_json(tf, 'FILE_MANIFEST.json', {'schema': 1, 'files': files})
