#!/usr/bin/env python3
"""Real temporary-Git/authority controls; Apple, tools and UI are NOT executed."""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile
from unittest.mock import patch
import yaml

HERE = Path(__file__).resolve().parent
CI = HERE / "candidate/Scripts/CI"
sys.path.insert(0, str(CI))
import runtime27_final_push as push
import runtime27_release_handoff as handoff
import prepare_wrappers as prepare
sys.path.append(str(HERE / "original/Scripts/CI"))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


original_handoff = load_module("original_handoff", HERE / "original/Scripts/CI/runtime27_release_handoff.py")
old_tests = load_module("original_handoff_controls", HERE / "original/Scripts/CI/test-runtime27-release-handoff.py")
original_stages = load_module("original_release_stages", HERE / "original/Scripts/CI/runtime27-release-stages.py")


def write(root, name, content):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content if isinstance(content, bytes) else content.encode())


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root, stderr=subprocess.STDOUT, timeout=30).decode().strip()


class WorkflowPreservation(unittest.TestCase):
    def setUp(self):
        self.original = prepare.ORIGINAL.read_text()
        self.original_yaml = yaml.load(self.original, Loader=yaml.BaseLoader)

    def check_route(self, mode):
        branch, path = prepare.ROUTES[mode]
        content = (prepare.CANDIDATE / path).read_text()
        self.assertEqual(content, prepare.render(self.original, mode))
        result = yaml.load(content, Loader=yaml.BaseLoader)
        self.assertEqual(result["on"], {"push": {"branches": [branch]}})
        self.assertEqual(result["permissions"], {"contents": "read", "actions": "read"})
        self.assertEqual(result["concurrency"]["cancel-in-progress"], "false")
        self.assertEqual(list(result["jobs"]), prepare.JOBS[mode])
        for name, job in result["jobs"].items():
            expected = yaml.load(prepare.specialize(prepare.job_block(self.original, name), mode), Loader=yaml.BaseLoader)[name]
            observed = copy.deepcopy(job)
            guards = [s for s in observed["steps"] if s.get("name", "").startswith("Bind exact final push source (")]
            self.assertEqual(len(guards), 2)
            self.assertEqual(guards[1]["if"], "always()")
            observed["steps"] = [s for s in observed["steps"] if s not in guards]
            self.assertIn(expected["if"][4:-3], observed["if"])
            self.assertIn("github.event_name == 'push'", observed["if"])
            self.assertIn("github.ref == 'refs/heads/" + branch + "'", observed["if"])
            observed["if"] = expected["if"]
            self.assertEqual(observed, expected, name)
        return result

    def test_native_every_original_step_output_condition_and_timeout_is_retained(self):
        value = self.check_route("ui")
        self.assertIn("|| 360", value["jobs"]["runtime27"]["timeout-minutes"])

    def test_release_same_run_graph_names_outputs_and_all_steps_are_retained(self):
        value = self.check_route("release")
        self.assertEqual(value["jobs"]["runtime27-release-native"]["needs"], "runtime27")
        self.assertEqual(value["jobs"]["runtime27-release-production"]["needs"], ["runtime27", "runtime27-release-native"])
        self.assertEqual(value["jobs"]["runtime27-release-native"]["timeout-minutes"], "345")
        self.assertEqual(value["jobs"]["runtime27-release-production"]["timeout-minutes"], "300")
        self.assertIn("&& 210", value["jobs"]["runtime27"]["timeout-minutes"])

    def test_fixed_dispatch_substitution_never_changes_original_shell_or_python_bodies(self):
        for mode in prepare.ROUTES:
            for name in prepare.JOBS[mode]:
                actual = yaml.load(prepare.specialize(prepare.job_block(self.original, name), mode), Loader=yaml.BaseLoader)[name]
                for before, after in zip(self.original_yaml["jobs"][name]["steps"], actual["steps"]):
                    if "run" in before:
                        self.assertEqual(before["run"], after["run"])

    def test_original_workflow_and_stages_are_canonical_and_not_candidate_replacements(self):
        self.assertEqual(prepare.blob(self.original.encode()), prepare.ORIGINAL_BLOB)
        self.assertFalse((prepare.CANDIDATE / ".github/workflows/sefaria-embedded-validation.yml").exists())
        self.assertFalse((prepare.CANDIDATE / "Scripts/CI/runtime27-release-stages.py").exists())

    def test_unfinalized_binding_selects_neither_application_nor_frozen_commit(self):
        value = json.loads((CI / "runtime27-final-push.inputs.json").read_text())
        self.assertEqual(value["state"], "UNFINALIZED")
        self.assertIsNone(value["application_source_sha"])
        self.assertIsNone(value["reviewed_r27_sha256"])
        self.assertEqual(set(value["application_trees"].values()), {None})
        self.assertEqual(set(value["source_pin_sha256"].values()), {None})
        self.assertNotIn("frozen_checkout", value)

    def test_no_other_job_or_dispatch_entrypoint_is_added(self):
        for mode, (_, name) in prepare.ROUTES.items():
            value = yaml.load((prepare.CANDIDATE / name).read_text(), Loader=yaml.BaseLoader)
            self.assertEqual(set(value["on"]), {"push"})
            self.assertEqual(set(value["jobs"]), set(prepare.JOBS[mode]))


class PushAPIControls(unittest.TestCase):
    def setUp(self):
        self.context = old_tests.fixture_context()
        self.context.update(workflow=push.ROUTES["release"]["workflow"], push_authority=push.authority("release"))
        self.run = {"id": 101, "run_attempt": 2, "head_sha": "a" * 40, "event": "push",
                    "path": self.context["workflow"], "head_branch": push.ROUTES["release"]["ref"].removeprefix("refs/heads/"),
                    "repository": {"id": push.REPOSITORY_ID, "full_name": push.REPOSITORY},
                    "head_repository": {"id": push.REPOSITORY_ID, "full_name": push.REPOSITORY},
                    "status": "in_progress", "conclusion": None}
        self.metadata = {"id": 301, "name": "runtime27-release-build-handoff", "expired": False,
                         "size_in_bytes": 500, "digest": "sha256:" + "6" * 64, "created_at": "2026-11-20T07:01:00Z",
                         "workflow_run": {"id": 101, "head_sha": "a" * 40,
                                          "repository_id": handoff.REPOSITORY_ID, "head_repository_id": handoff.REPOSITORY_ID}}
        self.jobs = [{"name": "Release build and prototype", "run_id": 101, "run_attempt": 2,
                      "head_sha": "a" * 40, "status": "completed", "conclusion": "success",
                      "started_at": "2026-11-20T07:00:00Z", "completed_at": "2026-11-20T07:02:00Z"}]

    def check(self):
        return handoff.validate_artifact_metadata(self.metadata, self.run, self.jobs, self.context, "build", 301)

    def test_exact_push_case_requires_real_successful_producer_even_when_run_in_progress(self):
        self.assertEqual(self.check(), self.jobs[0])

    def test_exact_api_path_with_exact_ref_suffix_is_supported(self):
        self.run["path"] += "@" + push.ROUTES["release"]["ref"]
        self.assertEqual(self.check(), self.jobs[0])

    def test_original_manual_case_still_rejects_push_even_on_new_exact_branch(self):
        with self.assertRaisesRegex(ValueError, "source/attempt"):
            original_handoff.validate_artifact_metadata(self.metadata, self.run, self.jobs,
                                                        old_tests.fixture_context(), "build", 301)
        self.context = old_tests.fixture_context()
        with self.assertRaisesRegex(ValueError, "source/attempt"):
            self.check()

    def test_wrong_api_event_is_rejected(self):
        for value in ["workflow_dispatch", "pull_request", "workflow_run", "schedule", "repository_dispatch", None]:
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "event/path/ref"):
                self.run["event"] = value
                self.check()

    def test_wrong_or_mixed_api_workflow_path_is_rejected(self):
        for value in [handoff.WORKFLOW, push.ROUTES["ui"]["workflow"], ".github/workflows/other.yml",
                      self.context["workflow"] + "@refs/heads/main", self.context["workflow"] + "@" + "a" * 40, None]:
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "event/path/ref"):
                self.run["path"] = value
                self.check()

    def test_wrong_api_branch_including_similarly_named_ref_is_rejected(self):
        for value in ["main", self.run["head_branch"] + "-other", push.ROUTES["ui"]["ref"].removeprefix("refs/heads/"),
                      push.ROUTES["release"]["ref"], None]:
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "event/path/ref"):
                self.run["head_branch"] = value
                self.check()

    def test_api_repository_and_head_repository_must_both_be_owned_exactly(self):
        for name in ("repository", "head_repository"):
            original = copy.deepcopy(self.run[name])
            for changed in [{"id": 1, "full_name": push.REPOSITORY}, {"id": push.REPOSITORY_ID, "full_name": "other/Maktabah"}, {}, {"id": True}]:
                with self.subTest(name=name, changed=changed), self.assertRaisesRegex(ValueError, "repository"):
                    self.run[name] = changed
                    self.check()
            self.run[name] = original

    def test_mixed_run_attempt_head_and_boolean_identity_are_rejected(self):
        for key, value in [("id", 102), ("run_attempt", 3), ("head_sha", "b" * 40), ("id", True), ("run_attempt", True)]:
            original = self.run[key]
            with self.subTest(key=key, value=value), self.assertRaisesRegex(ValueError, "source/attempt"):
                self.run[key] = value
                self.check()
            self.run[key] = original

    def test_context_cannot_relabel_manual_or_wrong_push_authority(self):
        for key in self.context["push_authority"]:
            changed = copy.deepcopy(self.context)
            changed["push_authority"][key] = "wrong"
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "authority"):
                handoff.validate_artifact_metadata(self.metadata, self.run, self.jobs, changed, "build", 301)
        changed = copy.deepcopy(self.context)
        changed.pop("push_authority")
        with self.assertRaisesRegex(ValueError, "authority"):
            handoff.validate_artifact_metadata(self.metadata, self.run, self.jobs, changed, "build", 301)

    def test_artifact_run_head_repository_expiry_name_size_digest_remain_required(self):
        for key, value in [("id", 302), ("name", "runtime27-evidence"), ("expired", True),
                           ("size_in_bytes", 0), ("digest", "sha256:bad")]:
            original = self.metadata[key]
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.metadata[key] = value
                self.check()
            self.metadata[key] = original
        for key, value in [("id", 102), ("head_sha", "b" * 40), ("repository_id", 1), ("head_repository_id", 2)]:
            original = self.metadata["workflow_run"][key]
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.metadata["workflow_run"][key] = value
                self.check()
            self.metadata["workflow_run"][key] = original

    def test_producer_mixed_run_attempt_failure_and_duplicate_are_still_rejected(self):
        for key, value in [("run_id", 102), ("run_attempt", 1), ("head_sha", "b" * 40),
                           ("status", "in_progress"), ("conclusion", "cancelled"), ("name", "other")]:
            original = self.jobs[0][key]
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.jobs[0][key] = value
                self.check()
            self.jobs[0][key] = original
        self.jobs.append(copy.deepcopy(self.jobs[0]))
        with self.assertRaises(ValueError):
            self.check()

    def test_upload_interval_remains_bound_to_that_producer(self):
        for timestamp in ["2026-11-20T06:59:59Z", "2026-11-20T07:02:01Z"]:
            with self.subTest(timestamp=timestamp), self.assertRaisesRegex(ValueError, "outside"):
                self.metadata["created_at"] = timestamp
                self.check()

    def test_full_push_fetch_preserves_verified_actual_envelope_and_api_lineage_fields(self):
        # The GitHub API/transport and platform context are explicit fixture boundaries.
        # ZIP/tar bytes, their hashes, POSIX permissions and original extract path are real.
        with tempfile.TemporaryDirectory(prefix="push-handoff-envelope-") as folder:
            root = Path(folder)
            producer, consumer = root / "producer", root / "consumer"
            producer.mkdir(); consumer.mkdir()
            old_tests.products(producer)
            destination = root / "handoff"
            receipt = handoff.pack(producer, destination, "build",
                [producer / p for p in handoff.PRODUCT_ROOTS], self.context, "RELEASE_BUILD_ONLY_PASS",
                products=handoff.product_inventory(producer))
            envelope = root / "artifact.zip"
            with zipfile.ZipFile(envelope, "w", zipfile.ZIP_DEFLATED) as archive:
                for name in ("build.json", "build.tar.gz"):
                    archive.write(destination / name, name)
            self.metadata.update(size_in_bytes=envelope.stat().st_size, digest="sha256:" + handoff.digest(envelope))
            def api(path, *command):
                self.assertEqual(command[:2], ("gh", "api"))
                endpoint = command[2]
                if endpoint.endswith("/artifacts/301"):
                    return json.dumps(self.metadata)
                if endpoint.endswith("/runs/101"):
                    return json.dumps(self.run)
                self.assertTrue(endpoint.endswith("/runs/101/attempts/2/jobs?per_page=100"))
                return json.dumps({"total_count": 1, "jobs": self.jobs})
            def transport(command, **kwargs):
                self.assertEqual(command, ["gh", "api", "repos/" + handoff.REPOSITORY + "/actions/artifacts/301/zip"])
                self.assertEqual(kwargs["timeout"], 900)
                self.assertIs(kwargs["check"], True)
                kwargs["stdout"].write(envelope.read_bytes())
                return subprocess.CompletedProcess(command, 0)
            with patch.object(handoff, "context", return_value=self.context), \
                    patch.object(handoff, "capture", side_effect=api), \
                    patch.object(handoff.subprocess, "run", side_effect=transport):
                fetched = handoff.fetch(consumer, "build", 301, receipt["archive"]["sha256"], "native")
            self.assertEqual(fetched, receipt)
            self.assertEqual(handoff.product_inventory(consumer), receipt["products"])
            proof = json.loads((consumer / "build/artifacts/runtime27/handoff-build-import-native.json").read_bytes())
            self.assertEqual(proof["workflow"], {key: self.run[key] for key in ["id", "head_sha", "run_attempt", "event", "path"]})
            self.assertEqual(proof["push_workflow"], {key: self.run[key] for key in ["head_branch", "repository", "head_repository"]})
            self.assertIs(proof["full_release_acceptance"], False)


class TemporaryGitBinding(unittest.TestCase):
    """Actual Git/files; synthetic app tree and explicitly doubled Apple commands."""
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="final-push-control-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        git(self.root, "init", "-q")
        git(self.root, "config", "user.name", "Disposable CI control")
        git(self.root, "config", "user.email", "ci-fixture@example.invalid")
        for path in push.TREE_PATHS:
            write(self.root, path + "/synthetic-source.txt", "Explicit synthetic app boundary; never compiled\n")
        write(self.root, push.R27_SOURCE, "// Explicit synthetic R27 source identity; never compiled\n")
        self.r27_sha = hashlib.sha256((self.root / push.R27_SOURCE).read_bytes()).hexdigest()
        git(self.root, "add", ".")
        git(self.root, "commit", "-qm", "Synthetic application tree")
        self.application = git(self.root, "rev-parse", "HEAD")
        self.trees = {p: git(self.root, "rev-parse", "HEAD:" + p) for p in push.TREE_PATHS}
        for mode, (_, path) in prepare.ROUTES.items():
            write(self.root, path, (prepare.CANDIDATE / path).read_bytes())
        write(self.root, push.ORIGINAL_WORKFLOW, prepare.ORIGINAL.read_bytes())
        for path in ["runtime27_final_push.py", "runtime27_release_handoff.py"]:
            write(self.root, "Scripts/CI/" + path, (CI / path).read_bytes())
        write(self.root, "Scripts/CI/runtime27-release-stages.py", (HERE / "original/Scripts/CI/runtime27-release-stages.py").read_bytes())
        runtime = (HERE / "original/Scripts/CI/runtime27.py").read_bytes()
        runtime = runtime.replace(push.ORIGINAL_R27_SHA256.encode(), self.r27_sha.encode(), 1)
        write(self.root, "Scripts/CI/runtime27.py", runtime)
        for path in ["Scripts/CI/verify-faithful-xctest.py", "tools/verify_xcresult_zero_skips.py"]:
            write(self.root, path, "# Explicit fixture source identity only; no execution\n")
        self.binding = json.loads((CI / "runtime27-final-push.inputs.json").read_text())
        self.binding.update(state="FINALIZED", application_source_sha=self.application, application_trees=self.trees)
        self.binding["reviewed_r27_sha256"] = self.r27_sha
        for path in push.PIN_PATHS:
            pin_trees = {key: self.trees[key] for key in ("Source", "Vendor", "Maktabah.xcodeproj")} if path == push.PIN_PATHS[0] else self.trees
            value = json.dumps({"application_source_sha": self.application, "application_trees": pin_trees}) + "\n"
            write(self.root, path, value)
            self.binding["source_pin_sha256"][path] = hashlib.sha256(value.encode()).hexdigest()
        self.persist_binding()
        self.commit()
        self.env = {"GITHUB_EVENT_NAME": "push", "GITHUB_REPOSITORY": push.REPOSITORY,
                    "GITHUB_REPOSITORY_ID": str(push.REPOSITORY_ID),
                    "GITHUB_REF": push.ROUTES["release"]["ref"],
                    "GITHUB_WORKFLOW_REF": push.authority("release")["workflow_ref"],
                    "GITHUB_SHA": self.head, "EXPECTED_CHECKOUT_SHA": self.head,
                    "GITHUB_RUN_ID": "101", "GITHUB_RUN_ATTEMPT": "2", "FAITHFUL_RUNTIME27_IDENTIFIER": "fixture.iOS-27-2"}

    def persist_binding(self):
        write(self.root, push.BINDING, json.dumps(self.binding, indent=2) + "\n")

    def commit(self):
        git(self.root, "add", ".")
        git(self.root, "commit", "-qm", "Synthetic final binding")
        self.head = git(self.root, "rev-parse", "HEAD")
        if hasattr(self, "env"):
            self.env.update(GITHUB_SHA=self.head, EXPECTED_CHECKOUT_SHA=self.head)

    def observe(self):
        with patch.dict(os.environ, self.env, clear=True):
            return push.observe_source(self.root, "release")

    def invoke_cli(self, phase):
        return subprocess.run([sys.executable, str(self.root / "Scripts/CI/runtime27_final_push.py"),
                               "--mode", "release", "--stage", "build", "--phase", phase],
                              cwd=self.root, env=self.env, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=30)

    def receipt(self, phase):
        return json.loads((self.root / ("build/artifacts/runtime27/final-push-build." + phase + ".json")).read_bytes())

    def test_focused_inputs_preserve_original_three_tree_schema(self):
        focused = json.loads((self.root / push.PIN_PATHS[0]).read_bytes())
        self.assertEqual(set(focused["application_trees"]), {"Source", "Vendor", "Maktabah.xcodeproj"})
        result = self.observe()
        self.assertEqual(result["application_trees"], self.trees)
        self.assertEqual(set(result["application_trees"]), set(push.TREE_PATHS))

    def test_focused_inputs_reject_four_trees_even_when_values_match_binding(self):
        path = push.PIN_PATHS[0]
        value = json.dumps({"application_source_sha": self.application, "application_trees": self.trees}) + "\n"
        write(self.root, path, value)
        self.binding["source_pin_sha256"][path] = hashlib.sha256(value.encode()).hexdigest()
        self.persist_binding(); self.commit()
        with self.assertRaisesRegex(ValueError, "Original focused driver"):
            self.observe()

    def original_build_report(self, build_trees):
        # Complete unchanged original stage function; JSON/Git are real. Only
        # its already-bound runner/platform context is supplied explicitly.
        context = old_tests.fixture_context()
        context.update(checkout_sha=self.head, trees=self.trees)
        report = {"status": "RELEASE_BUILD_ONLY_PASS", "release_stage": "build",
                  "full_release_acceptance": False, "checkout_sha": self.head,
                  "release_manifest_sha256": context["release_manifest_sha256"]}
        build = {"status": "SIMULATOR_BUILD_FOR_REAL_UI_PASS", "checkout_sha": self.head,
                 "application_trees": build_trees}
        write(self.root, "build/artifacts/runtime27/release-build-result.json", json.dumps(report))
        write(self.root, "build/hq-stage2/result.json", json.dumps(build))
        with patch.object(original_stages, "ROOT", self.root), \
             patch.object(original_stages, "OUT", self.root / "build/artifacts/runtime27"), \
             patch.object(original_stages.transfer, "context", return_value=context):
            return original_stages.expected_build_report()

    def test_original_pack_build_report_accepts_the_same_three_focused_trees(self):
        focused = json.loads((self.root / push.PIN_PATHS[0]).read_bytes())
        report, build = self.original_build_report(focused["application_trees"])
        self.assertEqual(build["application_trees"], {key: self.trees[key] for key in
                         ("Source", "Vendor", "Maktabah.xcodeproj")})
        self.assertFalse(report["full_release_acceptance"])

    def test_original_pack_build_report_rejects_extra_ui_test_tree(self):
        with self.assertRaisesRegex(ValueError, "Original Debug build source trees differ"):
            self.original_build_report(self.trees)

    def test_actual_cli_before_after_records_bound_sources_without_native_credit(self):
        self.assertEqual(self.invoke_cli("before").returncode, 0)
        self.assertEqual(self.invoke_cli("after").returncode, 0)
        self.assertEqual(self.receipt("before")["status"], "FINAL_PUSH_SOURCE_BOUND")
        self.assertEqual(self.receipt("after")["status"], "FINAL_PUSH_SOURCE_UNCHANGED")
        self.assertEqual(self.receipt("before")["source"], self.receipt("after")["source"])
        self.assertIs(self.receipt("after")["native_execution_claimed"], False)

    def test_actual_after_cli_without_before_fails_and_preserves_failure_receipt(self):
        self.assertEqual(self.invoke_cli("after").returncode, 1)
        self.assertEqual(self.receipt("after")["status"], "FINAL_PUSH_SOURCE_REJECTED")
        self.assertIs(self.receipt("after")["native_execution_claimed"], False)

    def test_actual_after_cli_cannot_overwrite_prior_success_with_changed_source(self):
        self.assertEqual(self.invoke_cli("before").returncode, 0)
        before = self.receipt("before")
        path = self.root / "Scripts/CI/runtime27_release_handoff.py"
        path.write_bytes(path.read_bytes() + b"\n# changed source\n")
        self.assertEqual(self.invoke_cli("after").returncode, 1)
        self.assertEqual(self.receipt("before"), before)
        self.assertEqual(self.receipt("after")["status"], "FINAL_PUSH_SOURCE_REJECTED")

    def test_actual_git_source_closure_contains_both_push_workflows_and_original_declaration_gate(self):
        result = self.observe()
        paths = {row["path"] for row in result["inputs"]}
        self.assertTrue({r["workflow"] for r in push.ROUTES.values()} <= paths)
        self.assertIn("Scripts/CI/verify-faithful-xctest.py", paths)
        self.assertEqual(result["application_source_sha"], self.application)

    def test_single_runtime_digest_edit_inverts_to_the_whole_original_driver(self):
        result = self.observe()
        proof = result["runtime27_digest_binding"]
        self.assertEqual(proof["whole_driver_inverse_git_blob"], push.ORIGINAL_RUNTIME_BLOB)
        self.assertEqual(proof["new_digest"], self.r27_sha)
        self.assertEqual(proof["r27_source"]["sha256"], self.r27_sha)

    def test_committed_driver_logic_change_or_duplicate_digest_cannot_borrow_the_refreeze(self):
        path = self.root / "Scripts/CI/runtime27.py"
        original = path.read_bytes()
        for appended, error in [(b"\n# unreviewed extra logic\n", "driver changed beyond"),
                                (('\nEXTRA = "' + self.r27_sha + '"\n').encode(), "one exact literal")]:
            path.write_bytes(original + appended); self.commit()
            with self.subTest(error=error), self.assertRaisesRegex(ValueError, error):
                self.observe()
            path.write_bytes(original); self.commit()

    def test_reviewed_r27_digest_must_match_the_actual_application_tree_file(self):
        self.binding["reviewed_r27_sha256"] = "f" * 64
        self.persist_binding(); self.commit()
        with self.assertRaisesRegex(ValueError, "R27 source digest differs"):
            self.observe()

    def test_unfinalized_current_draft_is_rejected(self):
        self.binding["state"] = "UNFINALIZED"
        self.persist_binding(); self.commit()
        with self.assertRaisesRegex(ValueError, "not finalized"):
            self.observe()

    def test_every_environment_event_repository_ref_path_head_run_and_attempt_is_required(self):
        for key, value in [("GITHUB_EVENT_NAME", "workflow_dispatch"), ("GITHUB_REPOSITORY", "other/Maktabah"),
                           ("GITHUB_REPOSITORY_ID", "1"), ("GITHUB_REF", "refs/heads/main"),
                           ("GITHUB_WORKFLOW_REF", push.REPOSITORY + "/" + push.ORIGINAL_WORKFLOW + "@" + self.env["GITHUB_REF"]),
                           ("GITHUB_SHA", "b" * 40), ("EXPECTED_CHECKOUT_SHA", "b" * 40),
                           ("GITHUB_RUN_ID", "0"), ("GITHUB_RUN_ATTEMPT", "-1")]:
            original = self.env[key]
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.env[key] = value
                self.observe()
            self.env[key] = original

    def test_each_original_four_pin_must_match_the_reviewed_final_digest(self):
        for path in push.PIN_PATHS:
            original = (self.root / path).read_bytes()
            write(self.root, path, original + b" ")
            self.commit()
            with self.subTest(path=path), self.assertRaisesRegex(ValueError, "source pin differs"):
                self.observe()
            write(self.root, path, original)
            self.commit()

    def test_each_product_tree_must_equal_the_explicit_application_commit(self):
        for path in push.TREE_PATHS:
            original = (self.root / path / "synthetic-source.txt").read_bytes()
            write(self.root, path + "/synthetic-source.txt", original + b"changed")
            self.commit()
            with self.subTest(path=path), self.assertRaisesRegex(ValueError, "tree differs"):
                self.observe()
            write(self.root, path + "/synthetic-source.txt", original)
            self.commit()

    def test_actual_dirty_workflow_helper_and_test_bytes_cannot_borrow_head_identity(self):
        for path in [push.ROUTES["release"]["workflow"], "Scripts/CI/runtime27_release_handoff.py",
                     "Maktabah-iOSUITests/synthetic-source.txt"]:
            original = (self.root / path).read_bytes()
            write(self.root, path, original + b"changed")
            with self.subTest(path=path), self.assertRaisesRegex(ValueError, "source bytes changed"):
                self.observe()
            write(self.root, path, original)

    def test_missing_complete_original_declaration_parser_is_rejected(self):
        (self.root / "Scripts/CI/verify-faithful-xctest.py").unlink()
        self.commit()
        with self.assertRaisesRegex(ValueError, "source closure"):
            self.observe()

    def test_symlinked_source_cannot_borrow_original_workflow_identity(self):
        path = self.root / push.ROUTES["release"]["workflow"]
        target = self.root / "source-link-target"
        target.write_bytes(path.read_bytes())
        path.unlink(); path.symlink_to(target)
        with self.assertRaisesRegex(ValueError, "Linked"):
            self.observe()

    def test_changed_counts_and_timeout_contract_are_rejected(self):
        for key in push.SELECTION:
            original = self.binding["selection"][key]
            self.binding["selection"][key] = original + 1
            self.persist_binding(); self.commit()
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "selection contract"):
                self.observe()
            self.binding["selection"][key] = original
            self.persist_binding(); self.commit()

    def test_original_manual_context_values_remain_exact(self):
        # Apple/tool observations are explicit doubles; Git and all file hashes are real.
        def capture(root, *command):
            if command == ("xcrun", "simctl", "list", "runtimes", "-j"):
                return json.dumps({"runtimes": [{"identifier": "fixture.iOS-27-2", "isAvailable": True,
                                                "version": "27.2", "buildversion": "synthetic"}]})
            if command == ("xcrun", "--sdk", "iphonesimulator", "--show-sdk-version"):
                return "27.2"
            if command == ("xcodebuild", "-version"):
                return "SYNTHETIC Xcode 27.2"
            if command == ("xcrun", "swiftc", "--version"):
                return "SYNTHETIC Swift 6.4.2"
            return git(root, *command[1:])
        self.env["GITHUB_EVENT_NAME"] = "workflow_dispatch"
        with patch.dict(os.environ, self.env, clear=True), patch.object(handoff, "capture", side_effect=capture), \
                patch.object(original_handoff, "capture", side_effect=capture):
            self.assertEqual(handoff.context(self.root), original_handoff.context(self.root))

    def test_push_context_adds_workflow_and_final_binding_without_losing_original_context(self):
        original = old_tests.fixture_context()
        original.update(checkout_sha=self.head)
        with patch.dict(os.environ, self.env, clear=True):
            result = push.release_context(self.root, original)
        self.assertEqual(result["original_workflow_sha256"], original["workflow_sha256"])
        self.assertEqual(result["push_source_binding"]["application_source_sha"], self.application)
        for key in set(original) - {"workflow", "workflow_sha256"}:
            self.assertEqual(result[key], original[key])

    def test_push_context_cannot_mix_original_run_attempt_or_head(self):
        for key, value in [("checkout_sha", "b" * 40), ("run_id", 102), ("run_attempt", 1)]:
            original = old_tests.fixture_context()
            original.update(checkout_sha=self.head)
            original[key] = value
            with self.subTest(key=key), patch.dict(os.environ, self.env, clear=True), self.assertRaisesRegex(ValueError, "Mixed"):
                push.release_context(self.root, original)


if __name__ == "__main__":
    unittest.main(verbosity=2)
