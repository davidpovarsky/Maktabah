#!/usr/bin/env python3
"""Seal unchanged inputs, exact leaf inventories and raw local Python results."""
from __future__ import annotations
import ast
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "validation/focused-schema-v2"


def inputs():
    paths = [ROOT / "test_final_push.py", ROOT / "prepare_wrappers.py", ROOT / "prepare_handoff.py", Path(__file__)]
    paths += [p for p in (ROOT / "candidate").rglob("*") if p.is_file() and "docs" not in p.parts and "__pycache__" not in p.parts]
    paths += [ROOT / "original/.github/workflows/sefaria-embedded-validation.yml",
              ROOT / "original/Scripts/CI/runtime27_release_handoff.py",
              ROOT / "original/Scripts/CI/runtime27.py",
              ROOT / "original/Scripts/CI/runtime27-release-stages.py",
              ROOT / "original/Scripts/CI/runtime27_interruption.py",
              ROOT / "original/Scripts/CI/test-runtime27-release-handoff.py"]
    result = []
    for path in sorted(set(paths)):
        data = path.read_bytes()
        result.append({"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                       "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()})
    return result


def cases(path):
    tree = ast.parse(path.read_bytes())
    return sorted("__main__." + cls.name + "." + node.name for cls in tree.body if isinstance(cls, ast.ClassDef)
                  for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = inputs()
    (OUT / "INPUTS_BEFORE.json").write_text(json.dumps(before, indent=2) + "\n")
    new = ROOT / "test_final_push.py"
    old = ROOT / "original/Scripts/CI/test-runtime27-release-handoff.py"
    old_command = ("import sys,runpy,hashlib,json;sys.path.insert(0," + repr(str(ROOT / "candidate/Scripts/CI")) + ");"
                   "import runtime27_release_handoff as h;from pathlib import Path;"
                   "print(json.dumps({'actual_candidate_handoff':h.__file__,'sha256':hashlib.sha256(Path(h.__file__).read_bytes()).hexdigest()}));"
                   "runpy.run_path(" + repr(str(old)) + ",run_name='__main__')")
    definitions = [("new-controls", [sys.executable, str(new)], cases(new)),
                   ("original-handoff29", [sys.executable, "-c", old_command], cases(old))]
    rows = []
    for name, command, expected in definitions:
        started = dt.datetime.now(dt.timezone.utc).isoformat()
        clock = time.monotonic()
        timed_out = False
        try:
            completed = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
            stdout, stderr, returncode = completed.stdout, completed.stderr, completed.returncode
        except subprocess.TimeoutExpired as error:
            stdout, stderr, returncode, timed_out = error.stdout or b"", error.stderr or b"", None, True
        (OUT / (name + ".stdout.log")).write_bytes(stdout)
        (OUT / (name + ".stderr.log")).write_bytes(stderr)
        passed = re.findall(r"^test_[^\n]*\((__main__\.[^)]+)\) \.\.\. ok$", stderr.decode(errors="replace"), re.MULTILINE)
        summary = re.findall(r"^Ran ([0-9]+) tests in [0-9.]+s$", stderr.decode(errors="replace"), re.MULTILINE)
        qualified = (not timed_out and returncode == 0 and sorted(passed) == expected and len(passed) == len(set(passed))
                     and summary == [str(len(expected))] and stderr.decode().rstrip().endswith("\nOK"))
        rows.append({"name": name, "command": command, "started_at_utc": started,
                     "completed_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                     "duration_seconds": time.monotonic() - clock, "returncode": returncode, "timed_out": timed_out,
                     "expected_cases": expected, "observed_passed_cases": passed,
                     "qualified": qualified, "unverified_partial_execution": timed_out})
        if not qualified:
            break
    after = inputs()
    (OUT / "INPUTS_AFTER.json").write_text(json.dumps(after, indent=2) + "\n")
    result = {"status": "LOCAL_CONTROLS_PASS" if len(rows) == 2 and all(r["qualified"] for r in rows) and before == after else "LOCAL_CONTROLS_FAILED",
              "runs": rows, "inputs_unchanged": before == after,
              "scope": "Linux Python with real disposable Git, ZIP/tar extraction and POSIX permissions; GitHub API/Apple context are explicitly synthetic boundaries",
              "apple_build": "NOT_RUN", "swift_declaration_parser": "NOT_RUN", "native_ui": "NOT_RUN",
              "workflow_activated": False, "application_source_selected": False}
    (OUT / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "runs": [{"name": r["name"], "qualified": r["qualified"], "passed": len(r["observed_passed_cases"])} for r in rows],
                      "inputs_unchanged": result["inputs_unchanged"]}))
    return 0 if result["status"] == "LOCAL_CONTROLS_PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
