#!/usr/bin/env python3
"""Prepare reviewable, inactive wrappers; never commits, pushes, or dispatches."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE / "original/.github/workflows/sefaria-embedded-validation.yml"
CANDIDATE = HERE / "candidate"
ORIGINAL_BLOB = "ac42069b4dbbe57898c45e280513412c8df41ee7"
REVIEWED_BASE = "e603d8182a1c10c4b37b14c92b5f0bc3829edea8"
ROUTES = {
    "ui": ("codex/otzaria-final-native116-20261120", ".github/workflows/otzaria-final-native-push.yml"),
    "release": ("codex/otzaria-final-release114-20261120", ".github/workflows/otzaria-final-release-push.yml"),
}
JOBS = {"ui": ["runtime27"],
        "release": ["runtime27", "runtime27-release-native", "runtime27-release-production"]}
STAGES = {"runtime27-release-native": "native", "runtime27-release-production": "production"}


def blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def job_block(text: str, name: str) -> str:
    match = re.search(r"(?m)^  " + re.escape(name) + r":\n", text)
    if not match:
        raise ValueError("Missing original job: " + name)
    following = re.search(r"(?m)^  [A-Za-z0-9_-]+:\n", text[match.end():])
    end = match.end() + following.start() if following else len(text)
    return text[match.start():end].rstrip() + "\n"


def specialize(block: str, mode: str) -> str:
    """Substitute only fixed workflow_dispatch inputs, preserving every step."""
    values = {
        "runtime27_mode": repr(mode), "hq_stage2_expected_sha": "github.sha",
        "books_updates_check_only": "false", "hq_stage2_focused": "false",
        "ui_sdk_check_only": "false", "run_production_release": "false",
        "source_ref": "''", "ui_diagnostic_cases": "''", "run_simulator_tests": "false",
    }
    def expression(match):
        return re.sub(r"\binputs\.([a-z_0-9]+)\b", lambda m: values[m[1]], match[0])
    result = re.sub(r"\$\{\{.*?\}\}", expression, block, flags=re.DOTALL)
    if any("inputs." in match[0] for match in re.finditer(r"\$\{\{.*?\}\}", result, re.DOTALL)):
        raise ValueError("An unresolved dispatch input remains")
    return result


def guard_step(mode: str, stage: str, phase: str) -> str:
    return ("      - name: Bind exact final push source (" + phase + ")\n"
            + ("        if: always()\n" if phase == "after" else "")
            + "        env:\n          EXPECTED_CHECKOUT_SHA: ${{ github.sha }}\n"
            + "        run: python3 Scripts/CI/runtime27_final_push.py --mode " + mode
            + " --stage " + stage + " --phase " + phase + "\n")


def render(original: str, mode: str) -> str:
    if mode not in ROUTES:
        raise ValueError("Unsupported final route")
    branch, _ = ROUTES[mode]
    title = "Native116 original full matrix" if mode == "ui" else "Release114 original three-stage acceptance"
    header = ("# Prepared route only: runtime27-final-push.inputs.json is UNFINALIZED.\n"
              "# Root must finalize four original source pins and review this immutable branch before activation.\n"
              f"name: {title}\n\non:\n  push:\n    branches:\n      - {branch}\n\n"
              "permissions:\n  contents: read\n  actions: read\n\n"
              "concurrency:\n  group: ${{ github.workflow }}-${{ github.ref }}\n"
              "  cancel-in-progress: false\n\njobs:\n")
    blocks = []
    for name in JOBS[mode]:
        block = specialize(job_block(original, name), mode)
        outer = ("github.repository == 'davidpovarsky/Maktabah' && github.event_name == 'push'"
                 + " && github.ref == 'refs/heads/" + branch + "'")
        block, count = re.subn(r"(?m)^    if: \$\{\{ (.*?) \}\}$",
                              lambda m: "    if: ${{ " + outer + " && (" + m[1] + ") }}", block, count=1)
        if count != 1:
            raise ValueError("Expected one original job admission")
        stage = STAGES.get(name, "build" if mode == "release" else "native")
        checkout_end = "          fetch-depth: 0\n"
        if block.count(checkout_end) != 1:
            raise ValueError("Original exact checkout changed")
        block = block.replace(checkout_end, checkout_end + guard_step(mode, stage, "before"), 1)
        if name == "runtime27":
            marker = "        run: python3 Scripts/CI/runtime27.py\n"
        elif name == "runtime27-release-native":
            marker = '          --build-artifact "$BUILD_ARTIFACT" --build-archive-sha "$BUILD_ARCHIVE_SHA"\n'
        else:
            marker = '          --native-artifact "$NATIVE_ARTIFACT" --native-archive-sha "$NATIVE_ARCHIVE_SHA"\n'
        if block.count(marker) != 1:
            raise ValueError("Original executor boundary changed")
        block = block.replace(marker, marker + guard_step(mode, stage, "after"), 1)
        blocks.append(block)
    return header + "\n".join(blocks)


def main() -> None:
    data = ORIGINAL.read_bytes()
    if blob(data) != ORIGINAL_BLOB:
        raise ValueError("Original workflow is not the reviewed canonical Git blob")
    for mode, (_, relative) in ROUTES.items():
        path = CANDIDATE / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(render(data.decode(), mode))
    binding = {
        "schema": "otzaria-final-runtime-push-v1", "state": "UNFINALIZED",
        "reviewed_wrapper_base": REVIEWED_BASE,
        "application_source_sha": None,
        "reviewed_r27_sha256": None,
        "application_trees": {p: None for p in ["Source", "Vendor", "Maktabah.xcodeproj", "Maktabah-iOSUITests"]},
        "source_pin_sha256": {p: None for p in [
            "Scripts/CI/hq-stage2-focused-apple.inputs.json",
            "docs/hq-integration/runtime27/R27_CASES.json",
            "Scripts/CI/runtime27-release-manifest.json",
            "Scripts/CI/hq-v32-prebuilt-native.py"]},
        "selection": {"native_cases": 116, "release_ui_cases": 114, "release_oracle_cases": 2,
                      "per_test_timeout_seconds": 600},
        "routes": {mode: {"ref": "refs/heads/" + branch, "workflow": path}
                   for mode, (branch, path) in ROUTES.items()},
    }
    path = CANDIDATE / "Scripts/CI/runtime27-final-push.inputs.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(binding, indent=2) + "\n")
    print("Prepared two inactive routes; no application/frozen SHA chosen")


if __name__ == "__main__":
    main()
