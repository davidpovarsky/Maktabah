#!/usr/bin/env python3
"""Seal the local review packet; no Git or network mutation."""
import gzip
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
CANDIDATE = BASE / "candidate"
DOCS = CANDIDATE / "docs/hq-integration/final-runtime-push-route-20261120"


def digest(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def main():
    result = json.loads((BASE / "validation/focused-schema-v2/RESULT.json").read_bytes())
    assert result["status"] == "LOCAL_CONTROLS_PASS" and result["inputs_unchanged"]
    assert [len(r["observed_passed_cases"]) for r in result["runs"]] == [41, 29]
    sources = []
    for name in ["prepare_wrappers.py", "prepare_handoff.py", "test_final_push.py", "run_controls.py", "seal_packet.py"]:
        sources.append((BASE / name, "raw/preparation/" + name + ".gz"))
    for group in ("original", "validation"):
        for path in (BASE / group).rglob("*"):
            if path.is_file() and "__pycache__" not in path.parts:
                sources.append((path, "raw/" + group + "/" + str(path.relative_to(BASE / group)) + ".gz"))
    for source, relative in sources:
        target = DOCS / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    execution = {"status": "LOCAL_CONTROLS_PASS", "new_cases": 41, "unchanged_original_cases": 29,
                 "total_unique_methods": 70, "raw_result": "raw/validation/focused-schema-v2/RESULT.json.gz",
                 "input_hashes_before": "raw/validation/focused-schema-v2/INPUTS_BEFORE.json.gz",
                 "input_hashes_after": "raw/validation/focused-schema-v2/INPUTS_AFTER.json.gz",
                 "inputs_unchanged": True, "reviewed_base": "e603d8182a1c10c4b37b14c92b5f0bc3829edea8",
                 "application_M": "UNSELECTED", "frozen_F": "UNSELECTED",
                 "workflow_activation": "NOT_PERFORMED", "Apple": "NOT_RUN", "Native": "NOT_RUN"}
    (DOCS / "EXECUTION.json").write_text(json.dumps(execution, indent=2) + "\n")
    rows = []
    for path in sorted(CANDIDATE.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.name != "PACKET_INDEX.json":
            data = path.read_bytes()
            row = {"path": str(path.relative_to(CANDIDATE)), **digest(data)}
            if path.suffix == ".gz":
                raw = gzip.decompress(data)
                row.update(uncompressed_bytes=len(raw), uncompressed_sha256=hashlib.sha256(raw).hexdigest())
            rows.append(row)
    index = {"schema": "reviewed-local-payload-v1", "scope": "Unactivated final Native/Release exact push routes",
             "reviewed_base": execution["reviewed_base"], "payloads": rows}
    target = DOCS / "PACKET_INDEX.json"
    target.write_text(json.dumps(index, indent=2) + "\n")
    print(json.dumps({"packet": str(DOCS), "payloads": len(rows), "runtime_payloads": sum(not r["path"].startswith("docs/") for r in rows),
                      "index": digest(target.read_bytes()), "actual_new": 41, "actual_original": 29}))


if __name__ == "__main__":
    main()
