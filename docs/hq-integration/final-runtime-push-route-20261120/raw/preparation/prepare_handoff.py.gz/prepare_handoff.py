#!/usr/bin/env python3
"""Exact additive transformation with a complete inverse, for local review only."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PATH = "Scripts/CI/runtime27_release_handoff.py"
original = (HERE / "original" / PATH).read_text()
assert hashlib.sha1(b"blob " + str(len(original.encode())).encode() + b"\0" + original.encode()).hexdigest() == "a26c0b401b6b5d77d3c298110e531ba32b606bae"

wrapper = '''def context(root):
    if os.environ.get("GITHUB_EVENT_NAME") != "push":
        return _manual_context(root)
    final_push.environment_identity("release")
    return final_push.release_context(root, _manual_context(root))


'''
manual = '''    require(positive_integer(run.get("id")) and positive_integer(run.get("run_attempt"))
            and run.get("id") == expected_context["run_id"] and run.get("run_attempt") == expected_context["run_attempt"]
            and run.get("head_sha") == expected_context["checkout_sha"]
            and run.get("event") == "workflow_dispatch" and run.get("path", "").split("@")[0] == WORKFLOW,
            "Handoff workflow source/attempt mismatch")
'''
new = '''    if "push_authority" in expected_context or expected_context.get("workflow") == final_push.ROUTES["release"]["workflow"]:
        final_push.validate_release_run(run, expected_context)
    else:
''' + "".join("    " + line if line.strip() else line for line in manual.splitlines(keepends=True))
changes = [
    ("import zipfile\n", "import zipfile\n\nimport runtime27_final_push as final_push\n"),
    ("def context(root):\n", "def _manual_context(root):\n"),
    ("def resolve_carried_link(name, rows):\n", wrapper + "def resolve_carried_link(name, rows):\n"),
    (manual, new),
    ('    write_json(root / f"build/artifacts/runtime27/handoff-{kind}-import-{consumer}.json", proof)\n',
     '    if "push_authority" in expected_context:\n'
     '        proof["push_workflow"] = {"head_branch": run["head_branch"], **{\n'
     '            name: {key: run[name][key] for key in ["id", "full_name"]}\n'
     '            for name in ["repository", "head_repository"]}}\n'
     '    write_json(root / f"build/artifacts/runtime27/handoff-{kind}-import-{consumer}.json", proof)\n'),
]
candidate = original
for before, after in changes:
    assert candidate.count(before) == 1
    candidate = candidate.replace(before, after, 1)
inverse = candidate
for before, after in reversed(changes):
    assert inverse.count(after) == 1
    inverse = inverse.replace(after, before, 1)
assert inverse == original
target = HERE / "candidate" / PATH
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(candidate)
(HERE / "PROPOSED_HANDOFF.patch").write_text("".join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True),
    fromfile="a/" + PATH, tofile="b/" + PATH)))
(HERE / "HANDOFF_INVERSE.json").write_text(json.dumps({
    "original_git_blob": "a26c0b401b6b5d77d3c298110e531ba32b606bae", "hunks": len(changes),
    "full_inverse_matches_original": True,
    "manual_context_body_unchanged": True,
    "original_manual_authority_expression_unchanged_after_indentation": True,
    "remaining_archive_artifact_producer_receipt_code_unchanged": True,
    "original_sha256": hashlib.sha256(original.encode()).hexdigest(),
    "candidate_sha256": hashlib.sha256(candidate.encode()).hexdigest(),
}, indent=2) + "\n")
print("Prepared additive handoff; five exact changes fully invert to original")
