from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
PATH = 'Source/UI/iOS/Views/iPadLayout.swift'
base = (ROOT / 'base' / PATH).read_bytes()
assert hashlib.sha256(base).hexdigest() == '6a9a754f35e4603f273a5c4f83214efb84e77f49274192d88fd003fc17cba09f'
assert hashlib.sha1(b'blob ' + str(len(base)).encode() + b'\0' + base).hexdigest() == 'a22264dfb0ffec5e19365861914c14c325188dd8'

old_policy = '''    // The active global tab supplies its own preference. An offscreen Reader
    // must not be the only publisher of the enclosing tab bar's policy.
    private var globalTabBarVisibility: Visibility? {
        guard ChavrusaTextReaderUI.isEnabled else { return nil }
        return selectedTab == .viewer
            ? (sidebar.navigationChrome.isVisible ? .visible : .hidden)
            : .automatic
    }
'''
new_policy = '''    // Only the selected Reader supplies a preference to the global tab bar.
    // Other tabs retain their original system policy.
    private var readerTabBarVisibility: Visibility? {
        guard ChavrusaTextReaderUI.isEnabled, selectedTab == .viewer else { return nil }
        return sidebar.navigationChrome.isVisible ? .visible : .hidden
    }
'''
old_helper = '''/// A direct global-tab content boundary, above each tab's original navigation
/// and any nested sidebar pager. Only the feature gate changes this branch;
/// selecting another tab changes the value, without replacing its content.
private struct GlobalTabBarVisibility: ViewModifier {
    let visibility: Visibility?

    @ViewBuilder
    func body(content: Content) -> some View {
        if let visibility {
            content.toolbarVisibility(visibility, for: .tabBar)
        } else {
            content
        }
    }
}
'''
new_helper = '''/// Keep Reader content at the same structural position when tab selection
/// changes. Only this noninteractive background conditionally publishes a
/// preference, above the Reader's navigation and nested sidebar pager.
private struct ReaderTabBarVisibility: ViewModifier {
    let visibility: Visibility?

    func body(content: Content) -> some View {
        content.background {
            if let visibility {
                Color.clear
                    .toolbarVisibility(visibility, for: .tabBar)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
        }
    }
}
'''

text = base.decode('utf-8')
edits = [(old_policy, new_policy)]
for old, new in edits:
    assert text.count(old) == 1
    text = text.replace(old, new)
for content in ('viewerTabContent', 'searchTabContent', 'authorTabContent', 'annotationsTabContent', 'historyTabContent'):
    indent = '                    ' if content in ('searchTabContent', 'authorTabContent') else '                '
    old = indent + content + '\n' + indent + '    .modifier(GlobalTabBarVisibility(visibility: globalTabBarVisibility))\n'
    new = indent + content + '\n'
    if content == 'viewerTabContent':
        new += indent + '    .modifier(ReaderTabBarVisibility(visibility: readerTabBarVisibility))\n'
    assert text.count(old) == 1, content
    text = text.replace(old, new)
    edits.append((old, new))
assert text.count(old_helper) == 1
text = text.replace(old_helper, new_helper)
edits.append((old_helper, new_helper))

candidate = text.encode('utf-8')
inverse = text
for old, new in reversed(edits):
    assert inverse.count(new) == 1
    inverse = inverse.replace(new, old)
assert inverse.encode('utf-8') == base

out = ROOT / 'candidate' / PATH
out.parent.mkdir(parents=True, exist_ok=True)
out.write_bytes(candidate)
(ROOT / 'PROPOSED.patch').write_text(''.join(difflib.unified_diff(base.decode().splitlines(True), text.splitlines(True), fromfile='a/' + PATH, tofile='b/' + PATH)), encoding='utf-8')

def record(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

proof = {
    'path': PATH,
    'baseline': record(base),
    'candidate': record(candidate),
    'exact_inverse': True,
    'exact_replacements': len(edits),
    'removed_nonreader_modifier_calls': 4,
    'remaining_modifier_calls': 1,
    'reader_content_structurally_unconditional': True,
    'original_reader_scroll_state_and_lifecycle_bytes_unchanged': True,
    'original_feature_off_viewer_and_four_nonreader_body_definitions_bytes_unchanged': True,
    'other_source_and_test_files_changed': 0,
    'source_relationship': {'failed_M': '40c1eaa6bb0092336f1ee687ad1ce1425eaf4223', 'reviewed_M': '409519a6972783990a276ade0dbdc4703bb36ae4', 'requested_parent': '1146a249fdd94c345371c67a8d763f16223017ee', 'unchanged_Source_tree': '3e2541b84ee83a4fed5ec7f93cc5ac488c7c2169'},
    'scope': 'Ownership correction candidate; the actual Native6 geometry cause and repaired runtime behavior are not yet qualified.',
    'Swift_parse': 'NOT_RUN',
    'Apple_typecheck': 'NOT_RUN',
    'Native_candidate': 'NOT_RUN',
}
assert text.count('.modifier(ReaderTabBarVisibility(') == 1
assert 'GlobalTabBarVisibility' not in text
assert 'globalTabBarVisibility' not in text
assert 'return selectedTab == .viewer' not in text
(ROOT / 'SOURCE_INVERSE.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
print(json.dumps(proof, indent=2))
