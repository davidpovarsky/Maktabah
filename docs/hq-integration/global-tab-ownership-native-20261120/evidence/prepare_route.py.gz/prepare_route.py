"""Derive four unchanged Global Native executions from the actual Native6 route.

Preparation only. No branch, workflow activation, Swift, or Native execution.
"""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json

R = Path(__file__).resolve().parent
B, P, C = R / 'base', R / 'prior-route', R / 'candidate'
OLD_NAME = 'keyboard-global-focused-native'
NAME = 'global-tab-ownership-native'
OLD_DOCS = 'docs/hq-integration/' + OLD_NAME + '-20261120/'
DOCS = 'docs/hq-integration/' + NAME + '-20261120/'
M = 'cb252c143955d037ab0cef4df556b1e8fcd4c334'
OLD_F = 'bce0fee51c813fe2b830d87d61b1c7943f0344f4'
MANIFEST = 'docs/hq-integration/runtime27/R27_CASES.json'
TREES = {'Source': '9aa3a513dcb4802988f6cba6fc0bcbad794de792',
         'Vendor': '4065c0e62af325e83a65fe0c70270985229807ae',
         'Maktabah.xcodeproj': 'ebf00ef1e0e466b083f476be9a9bf1a06c7d2b72',
         'Maktabah-iOSUITests': '9be9f4c91114f5daffceac8a8ded0e7314f29fb4'}
L = 'FaithfulReaderUIAcceptanceTests/testCandidateGlobalSearchLandscapeMatchesOriginalNavigation'
PCASE = 'FaithfulReaderUIAcceptanceTests/testCandidateGlobalSearchPortraitMatchesOriginalNavigation'
CASES = [L, PCASE]


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def put(path, raw):
    target = C / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


canonical = json.loads((R / 'CANONICAL_INPUTS.json').read_text())
assert canonical['source'] == M
for row in canonical['base_records']:
    raw = (B / row['path']).read_bytes()
    assert blob(raw) == row['sha'] and digest(raw) == row['sha256'], row['path']
for row in canonical['prior_route_records']:
    raw = (P / row['path']).read_bytes()
    assert blob(raw) == row['blob'] and digest(raw) == row['sha256'], row['path']

binding = json.loads((R.parent / 'keyboard-global-focused-native-20261120/candidate' / OLD_DOCS / 'SOURCE_BINDING.json').read_text())
binding.update(source_commit=M, source_tree='71c49f8ac4404a1ffd2cc2640ec30ee1db6c7cba',
               protected_trees=TREES, original_route=OLD_F, native_executions=0, activation=False,
               exact_base_records=canonical['base_records'])
dump(C / DOCS / 'SOURCE_BINDING.json', binding)

replacements = []


def transform(text, before, after, expected=1):
    count = text.count(before)
    assert count == expected, (before, count, expected)
    replacements.append({'before': before, 'after': after, 'count': count})
    return text.replace(before, after)


old_driver = (P / f'Scripts/CI/{OLD_NAME}.py').read_text()
driver = old_driver
driver = transform(driver, OLD_NAME, NAME, old_driver.count(OLD_NAME))
driver = transform(driver, 'keyboard-global-ipad', 'global-tab-ownership-ipad', 2)
driver = transform(driver, 'keyboard_global_diagnostic_20261120', 'global_tab_ownership_diagnostic_20261120', 2)
driver = transform(driver, 'Bind two unchanged original Native scopes, then require all 4+2 outcomes.',
                   'Bind two unchanged Global Native scopes, then require all 2+2 outcomes.')
driver = transform(driver, 'CALIBRATION = "R27NativePadTests/testNormalBootstrapPaletteKeyboardDispatchCalibration"\nPOINTER = "FaithfulReaderUIAcceptanceTests/testPointerHoverClickAndHardwareKeyboardDismissal"\n', '')
driver = transform(driver, 'CASES = [CALIBRATION, POINTER, LANDSCAPE, PORTRAIT]', 'CASES = [LANDSCAPE, PORTRAIT]')
driver = transform(driver, 'len(rows) == 120 and len({r["case_id"] for r in rows}) == 120, "Expected116+4 unique diagnostic declarations"',
                   'len(rows) == 118 and len({r["case_id"] for r in rows}) == 118, "Expected116+2 unique diagnostic declarations"')
driver = transform(driver, '["ipad11", "ipad11", configuration, configuration]', '[configuration, configuration]')
driver = transform(driver, '"ipad11": 4 if configuration == "ipad11" else 0', '"ipad11": 2 if configuration == "ipad11" else 0')
# Keyboard collection was a required observation only for the two omitted
# keyboard methods. All original Global UI, source, xcresult and aggregate
# gates remain. Original app logs still upload through the unchanged workflow.
keyboard_guard = '''    if configuration == "ipad11":
        collection = load("artifacts/native-routing-logs-11-reader/collection.json")
        log = (build_root / "artifacts/native-routing-logs-11-reader/otzaria-reader.log").read_bytes()
        require(collection.get("status") == "RETAINED" and collection.get("bytes") == len(log)
                and collection.get("sha256") == sha(log), "Original keyboard diagnostic log not retained intact")
'''
driver = transform(driver, keyboard_guard, '')
driver = transform(driver, 'require(len(actual) == 6, "Expected exactly four plus two actual executions")',
                   'require(len(actual) == 4, "Expected exactly two plus two actual executions")')
driver = transform(driver, '"requested_case_executions": 6', '"requested_case_executions": 4')
driver = transform(driver, 'SIX_SELECTED_ORIGINAL_NATIVE_EXECUTIONS_PASS', 'FOUR_SELECTED_ORIGINAL_NATIVE_EXECUTIONS_PASS')
driver = transform(driver, 'executed_pass=6, executed_fail=0', 'executed_pass=4, executed_fail=0')
driver = transform(driver, 'Four original methods, six executions: ipad11=4 and ipad13=2; not final116/114 acceptance.',
                   'Two original Global methods, four executions: ipad11=2 and ipad13=2; not final116/114 acceptance.')
put(f'Scripts/CI/{NAME}.py', driver.encode())
driver_edits = copy.deepcopy(replacements)

old_tests = (P / f'Scripts/CI/test-{OLD_NAME}.py').read_text()
tests = old_tests.replace(OLD_NAME, NAME).replace('keyboard-global-ipad', 'global-tab-ownership-ipad')
tests = tests.replace('keyboard_global_diagnostic_20261120', 'global_tab_ownership_diagnostic_20261120')
tests = tests.replace('4 if name == "ipad11" else 2', '2')
tests = tests.replace('test_missing_calibration_or_global_selection_rejected', 'test_missing_global_selection_rejected')
tests = tests.replace('test_four_and_two_matching_synthetic_outcomes', 'test_two_and_two_matching_synthetic_outcomes')
tests = tests.replace('test_aggregate_matrix_failure_even_after_six_labels_rejected', 'test_aggregate_matrix_failure_even_after_four_labels_rejected')
tests = tests.replace('self.assertEqual(len(self.aggregate()), 6)', 'self.assertEqual(len(self.aggregate()), 4)')
tests = tests.replace('SIX_SELECTED_ORIGINAL_NATIVE_EXECUTIONS_PASS', 'FOUR_SELECTED_ORIGINAL_NATIVE_EXECUTIONS_PASS')
tests = tests.replace('self.assertEqual(len(result["case_outcomes"]), 6)', 'self.assertEqual(len(result["case_outcomes"]), 4)')
put(f'Scripts/CI/test-{NAME}.py', tests.encode())
assert old_tests.count('    def test_') == tests.count('    def test_') == 36

old_workflow = (P / f'.github/workflows/otzaria-{OLD_NAME}.yml').read_text()
workflow = old_workflow.replace(OLD_NAME, NAME).replace('keyboard-global-ipad', 'global-tab-ownership-ipad')
workflow = workflow.replace('build/downloaded-keyboard-global', 'build/downloaded-global-tab-ownership')
workflow = workflow.replace('Six original keyboard and Global Search native executions', 'Four original Global Search navigation executions')
workflow = workflow.replace('original-six', 'original-four').replace('aggregate-six', 'aggregate-four')
workflow = workflow.replace('Require four plus two actual original Native executions', 'Require two plus two actual original Native executions')
assert workflow.count('count: 4') == 1
workflow = workflow.replace('count: 4', 'count: 2')
put(f'.github/workflows/otzaria-{NAME}.yml', workflow.encode())

original_bytes = (B / MANIFEST).read_bytes()
original = json.loads(original_bytes)
original_rows = original['cases'] + original['supplemental_cases']
assert len(original_rows) == 116 and not set(CASES) & {x['case_id'] for x in original_rows}
old_root = R.parent / 'keyboard-global-focused-native-20261120/candidate'
for configuration, label, size in [('ipad11', '11-reader', '11'), ('ipad13', '13', '13')]:
    old_manifest = json.loads((old_root / f'docs/hq-integration/runtime27/keyboard-global-{configuration}.json').read_bytes())
    extra = old_manifest['supplemental_cases'][-2:]
    assert [x['case_id'] for x in extra] == CASES and all(x['device'] == configuration for x in extra)
    current = copy.deepcopy(original)
    for key in ['source_test_commit', 'app_source', 'application_source_sha']:
        current[key] = M
    current.update(scope=f'Focused Global navigation ownership diagnostic {configuration}: two unchanged original methods; full Native116 and Release114 remain separately required.',
                   native_cases_executed=0, required_nonzero_cases=2,
                   expected_per_device={'ipad11': 2 if configuration == 'ipad11' else 0, 'ipad13': 2 if configuration == 'ipad13' else 0, 'iphone': 0},
                   diagnostic_only=True, hid_comparison=False, execution_case_ids=CASES,
                   execution_groups=[{'label': label, 'size': size, 'case_ids': CASES}],
                   selected_scope_reason='Same two original methods on each original iPad size; no aliases, changed oracles or shared mutable runner state.',
                   diagnostic_purpose='Qualify selected-Reader-only tab bar preference ownership against each same-window original baseline; no arbitrary frame offset.',
                   supplemental_cases=original['supplemental_cases'] + extra,
                   global_tab_ownership_diagnostic_20261120={
                       'configuration': configuration, 'source_snapshot': M,
                       'original_execution_case_ids': original['execution_case_ids'], 'unchanged_original_row_count': 116,
                       'additional_existing_diagnostic_rows': extra, 'new_native_executions': 0,
                       'full_native116_acceptance': False, 'full_release114_acceptance': False,
                       'original_manifest_sha256': digest(original_bytes)})
    dump(C / f'docs/hq-integration/runtime27/global-tab-ownership-{configuration}.json', current)

old_runtime = (B / 'Scripts/CI/runtime27.py').read_text()
runtime = old_runtime.replace(binding['original_r27_pin'], binding['r27_test_sha256'])
assert old_runtime.count(binding['original_r27_pin']) == 1
prior_edits = json.loads((old_root / OLD_DOCS / 'RUNTIME_EXACT_EDIT.json').read_bytes())['replacements']
runtime_edits = copy.deepcopy(prior_edits)
for edit in runtime_edits:
    edit['after'] = edit['after'].replace('keyboard-global-ipad', 'global-tab-ownership-ipad')
    assert runtime.count(edit['before']) == 1
    runtime = runtime.replace(edit['before'], edit['after'], 1)
inverse = runtime
for edit in reversed(runtime_edits):
    assert inverse.count(edit['after']) == 1
    inverse = inverse.replace(edit['after'], edit['before'], 1)
assert inverse.replace(binding['r27_test_sha256'], binding['original_r27_pin']) == old_runtime
put('Scripts/CI/runtime27.py', runtime.encode())
dump(C / DOCS / 'RUNTIME_EXACT_EDIT.json', {'path': 'Scripts/CI/runtime27.py', 'replacements': runtime_edits,
     'old_r27_pin': binding['original_r27_pin'], 'new_r27_pin': binding['r27_test_sha256'],
     'original_sha256': digest(old_runtime.encode()), 'candidate_sha256': digest(runtime.encode()), 'whole_body_inverse_exact': True})
old_additions = (B / 'Scripts/CI/hq-stage2-otzaria-test-additions.json').read_bytes()
assert old_additions.count(binding['old_project_pin'].encode()) == 1
additions = old_additions.replace(binding['old_project_pin'].encode(), binding['project_blob'].encode())
put('Scripts/CI/hq-stage2-otzaria-test-additions.json', additions)
inputs = json.loads((B / 'Scripts/CI/hq-stage2-focused-apple.inputs.json').read_bytes())
inputs.update(application_source_sha=M, application_trees={k: TREES[k] for k in ['Source', 'Vendor', 'Maktabah.xcodeproj']}, otzaria_test_additions_sha256=digest(additions))
dump(C / 'Scripts/CI/hq-stage2-focused-apple.inputs.json', inputs)

patch = ''
for name, old, new in [(NAME + '.py', old_driver, driver), ('test-' + NAME + '.py', old_tests, tests), ('workflow.yml', old_workflow, workflow)]:
    patch += ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), 'actual-Native6/' + name, 'candidate/' + name))
(R / 'ROUTE_DELTA.patch').write_text(patch)
dump(R / 'ROUTE_PROOF.json', {'application_and_tests': M, 'source_tree': binding['source_tree'], 'protected_trees': TREES,
     'prior_actual_native6': {'run': 44796704535, 'F': OLD_F, 'pass': 2, 'fail': 4, 'skip': 0, 'unverified': 0},
     'source_commit_changes': ['Source/UI/iOS/Views/iPadLayout.swift'], 'app_tests_changed_by_route': False,
     'selected': {'ipad11': CASES, 'ipad13': CASES}, 'original_Native116_catalog_unchanged': True,
     'original_Release114_plus2_unchanged': True, 'original_600s_unchanged': True,
     'preserved_control_methods': 36, 'driver_replacements': driver_edits,
     'omitted_keyboard_log_only_requirement': keyboard_guard, 'keyboard_product_scope': 'Root owns separately; two keyboard methods are unselected, never passed.',
     'Swift_parse': 'NOT_RUN', 'Apple_build': 'NOT_RUN', 'Native_candidate_executed': 0, 'activation': False})
for path in [f'Scripts/CI/{NAME}.py', f'Scripts/CI/test-{NAME}.py', 'Scripts/CI/runtime27.py']:
    ast.parse((C / path).read_text())
print(json.dumps({'source': M, 'configurations': 2, 'selected_executions': 4, 'original_rows': 116, 'control_methods': 36, 'Native': 'NOT_RUN'}))
