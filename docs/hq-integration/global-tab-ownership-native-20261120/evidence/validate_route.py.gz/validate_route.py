"""Source and receipt compatibility controls; no Swift/Native result."""
from pathlib import Path
import ast
import hashlib
import json
import re
import runpy
import yaml

R = Path(__file__).resolve().parent
B, P, C = R / 'base', R / 'prior-route', R / 'candidate'
NAME, OLD = 'global-tab-ownership-native', 'keyboard-global-focused-native'
G = runpy.run_path(str(C / f'Scripts/CI/{NAME}.py'))
proof = json.loads((R / 'ROUTE_PROOF.json').read_bytes())
checks = []


def check(name, ok):
    checks.append({'name': name, 'passed': bool(ok)})
    if not ok:
        raise ValueError(name)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def function(text, name):
    rows = text.splitlines(True)
    node = next(x for x in ast.parse(text).body if isinstance(x, ast.FunctionDef) and x.name == name)
    return ''.join(rows[node.lineno - 1:node.end_lineno])


old = (P / f'Scripts/CI/{OLD}.py').read_text()
new = (C / G['SELF']).read_text()
expected = old
for edit in proof['driver_replacements']:
    check('exact_recipe:' + str(len(checks)), expected.count(edit['before']) == edit['count'])
    expected = expected.replace(edit['before'], edit['after'])
check('whole_driver_exact_recipe', expected == new)
renamed_old = old.replace(OLD, NAME).replace('keyboard-global-ipad', 'global-tab-ownership-ipad').replace(
    'keyboard_global_diagnostic_20261120', 'global_tab_ownership_diagnostic_20261120')
for name in ['require', 'sha', 'blob', 'git', 'read_json', 'frozen_json', 'write', 'require_finalized',
             'github_context', 'validate_context', 'validate_identity', 'validate_pins', 'exact_working_inputs',
             'source_check', 'raw_leaves', 'validate_outcomes', 'main']:
    check('unchanged_actual_driver_function:' + name, function(renamed_old, name) == function(new, name))
check('qualify_only_removes_omitted_keyboard_observation',
      function(renamed_old, 'qualify').replace(proof['omitted_keyboard_log_only_requirement'], '') == function(new, 'qualify'))

workflow = (C / G['WORKFLOW']).read_text()
prior = (P / f'.github/workflows/otzaria-{OLD}.yml').read_text()
inverse = workflow.replace(NAME, OLD).replace('global-tab-ownership-ipad', 'keyboard-global-ipad')
inverse = inverse.replace('build/downloaded-global-tab-ownership', 'build/downloaded-keyboard-global')
inverse = inverse.replace('Four original Global Search navigation executions', 'Six original keyboard and Global Search native executions')
inverse = inverse.replace('original-four', 'original-six').replace('aggregate-four', 'aggregate-six')
inverse = inverse.replace('Require two plus two actual original Native executions', 'Require four plus two actual original Native executions')
needle = '- configuration: ipad11\n            count: 2'
check('single_workflow_count_rebind', inverse.count(needle) == 1)
inverse = inverse.replace(needle, '- configuration: ipad11\n            count: 4')
check('whole_actual_workflow_inverse', inverse == prior)
w = yaml.load(workflow, Loader=yaml.BaseLoader)
check('exact_branch_push_only', w['on'] == {'push': {'branches': [G['REF'].removeprefix('refs/heads/')]}})
check('read_only_permissions', w['permissions'] == {'contents': 'read', 'actions': 'read'})
check('no_cancellation', w['concurrency']['cancel-in-progress'] == 'false')
j = w['jobs']['original-four']
check('same_runner_finite_job_and_isolation', j['runs-on'] == 'xcode-27' and j['timeout-minutes'] == '360'
      and j['strategy']['fail-fast'] == 'false' and j['strategy']['max-parallel'] == '2')
check('exact_two_original_configurations', [(r['configuration'], r['count']) for r in j['strategy']['matrix']['include']] == [('ipad11', '2'), ('ipad13', '2')])
steps = {s.get('name'): s for s in j['steps'] if 'name' in s}
check('original_executor', steps['Execute original full app build and unchanged selected native cases']['run'] == 'python3 Scripts/CI/runtime27.py')
check('always_source_after', steps['Bind post-execution source and actual per-configuration results']['if'] == 'always()')
for name in ['Retain real runtime evidence including failure', 'Retain original native result bundles and visual captures separately']:
    check('always_upload:' + name, steps[name]['if'] == 'always()')
check('native_build_steps_no_continue_on_error', all('continue-on-error' not in s for s in j['steps']))
check('aggregate_required_after_both_configs', w['jobs']['aggregate-four']['needs'] == 'original-four'
      and w['jobs']['aggregate-four']['if'] == 'always()')

original = json.loads((B / G['ORIGINAL_MANIFEST']).read_bytes())
for configuration, config in G['CONFIGURATIONS'].items():
    value = json.loads((C / config['manifest']).read_bytes())
    G['validate_manifest'](value, original, configuration)
    check('original116_and_two_same_global_rows:' + configuration, True)
G['validate_pins'](json.loads((C / G['INPUTS']).read_bytes()), json.loads((B / G['INPUTS']).read_bytes()),
    (C / G['ADDITIONS']).read_bytes(), (B / G['ADDITIONS']).read_bytes(), (C / G['RUNTIME']).read_bytes(), (B / G['RUNTIME']).read_bytes())
check('original_three_pin_and_runtime_path_inverse', True)
check('original_catalog_not_written', not (C / G['ORIGINAL_MANIFEST']).exists())
check('release114_manifest_not_written', not (C / 'Scripts/CI/runtime27-release-manifest.json').exists())
check('no_UI_or_product_edits_in_CI_packet', not (C / 'Maktabah-iOSUITests').exists() and not (C / 'Source').exists())
matrix = (B / 'Scripts/CI/run-faithful-ipad-matrix.py').read_text()
check('original_600s_per_case_budgets', '"-default-test-execution-time-allowance", "600"' in matrix and '"-maximum-test-execution-time-allowance", "600"' in matrix)
check('original_complete_Swift_declaration_parser', '["swiftc", "-frontend", "-dump-parse", "-D", "DEBUG", str(source)]' in
      (B / 'Scripts/CI/verify-faithful-xctest.py').read_text() and 'Scripts/CI/verify-faithful-xctest.py' in matrix)

# Relevant original test methods and their actual frame oracle are unchanged
# since Native6; Motion-only changes elsewhere do not earn Global credit.
old_faithful = (R.parent / 'keyboard-global-focused-native-20261120/base/Maktabah-iOSUITests/FaithfulReaderUIAcceptanceTests.swift').read_bytes()
actual = json.loads((R.parent / 'keyboard-global-44796704535-20261120/ipad11-evidence/artifacts/keyboard-global-focused-native/SOURCE_BEFORE.json').read_bytes())
check('prior_full_Faithful_matches_actual_execution', sha(old_faithful) == actual['execution_inputs']['Maktabah-iOSUITests/FaithfulReaderUIAcceptanceTests.swift']['sha256'])
new_faithful = (B / 'Maktabah-iOSUITests/FaithfulReaderUIAcceptanceTests.swift').read_bytes()


def swift_block(text, name):
    # This source preservation check is not the original Swift declaration
    # parser. It compares a whole actual method up to its next same-indent
    # declaration, and leaves the real Swift parser mandatory on Apple.
    lines = text.decode().splitlines(True)
    start = next(i for i, line in enumerate(lines) if re.search(r'\bfunc\s+' + re.escape(name) + r'\s*\(', line))
    indent = len(lines[start]) - len(lines[start].lstrip())
    for end in range(start + 1, len(lines)):
        if lines[end].startswith(' ' * indent + '}') and lines[end].strip() == '}':
            return ''.join(lines[start:end + 1])
    raise ValueError(name)


for name in ['testCandidateGlobalSearchLandscapeMatchesOriginalNavigation', 'testCandidateGlobalSearchPortraitMatchesOriginalNavigation',
             'exerciseUnchangedOriginalScreen', 'capture']:
    check('whole_original_Global_method:' + name, swift_block(old_faithful, name) == swift_block(new_faithful, name))
check('original_bar_frame_tolerance', 'accuracy: 1' in swift_block(new_faithful, 'exerciseUnchangedOriginalScreen'))
for configuration, label in [('ipad11', '11-reader'), ('ipad13', '13')]:
    root = R.parent / 'keyboard-global-44796704535-20261120' / (configuration + '-evidence') / 'artifacts'
    for filename in ['SOURCE_BEFORE.json', 'SOURCE_AFTER.json', 'RESULT_BEFORE.json', 'RESULT_AFTER.json']:
        check('actual_prior_receipt:' + configuration + '/' + filename, (root / 'keyboard-global-focused-native' / filename).is_file())
    for filename in ['verified-' + label + '.summary.json', 'verified-' + label + '.tests.json', 'result.json']:
        check('actual_original_runtime_receipt:' + configuration + '/' + filename, (root / 'runtime27' / filename).is_file())

receipt = json.loads((R / 'evidence/controls/RESULT.json').read_bytes())
log = (R / 'evidence/controls/stderr.log').read_text()
check('actual_36_Python_controls', receipt['returncode'] == 0 and log.count(' ... ok\n') == 36 and 'Ran 36 tests' in log and log.rstrip().endswith('OK'))
for path in [G['SELF'], G['TESTS'], G['RUNTIME']]:
    ast.parse((C / path).read_text())
    check('python_parse:' + path, True)
report = {'status': 'SOURCE_PRESERVATION_AND36_PYTHON_CONTROLS_PASS', 'source': G['BASE'], 'checks': checks,
          'python_controls': 36, 'source_preservation_checks': len(checks), 'Swift_declaration_checker': 'NOT_RUN_LOCALLY; mandatory original Apple gate',
          'full_Git_source_gate': 'NOT_RUN_LOCALLY; canonical source projection only, mandatory actual Git checkout on CI',
          'Apple_build': 'NOT_RUN', 'Native_candidate_executed': 0, 'full_phase_credit': False}
(R / 'evidence/VALIDATION.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['status', 'source', 'python_controls', 'source_preservation_checks', 'Native_candidate_executed']}))
