"""Seal a source-bound Global4 preparation with authentic previous observations."""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import runpy

R = Path(__file__).resolve().parent
C, B = R / 'candidate', R / 'base'
D = C / 'docs/hq-integration/global-tab-ownership-native-20261120'
N = R.parent / 'keyboard-global-44796704535-20261120'
S = R.parent / 'native6-global-tab-diagnosis-20261120'
INDEX = D / 'PACKET_INDEX.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def zipped(source, relative):
    target = D / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))


run = json.loads((N / 'resumed-api/RUN.json').read_bytes())
jobs = json.loads((N / 'resumed-api/JOBS.json').read_bytes())
assert run['id'] == 44796704535 and run['head_sha'] == 'bce0fee51c813fe2b830d87d61b1c7943f0344f4'
assert run['status'] == 'completed' and run['conclusion'] == 'failure' and run['run_attempt'] == 1
assert {j['id'] for j in jobs['jobs']} == {136497998236, 136497998833, 136537298877}
assert all(j['status'] == 'completed' and j['conclusion'] == 'failure' for j in jobs['jobs'])
case_id = runpy.run_path(str(B / 'tools/verify_xcresult_zero_skips.py'))['case_id']
cases = []
for configuration, label, count in [('ipad11', '11-reader', 4), ('ipad13', '13', 2)]:
    folder = N / (configuration + '-evidence') / 'artifacts'
    ui = json.loads((folder / 'runtime27/result.json').read_bytes())
    tree = json.loads((folder / f'runtime27/verified-{label}.tests.json').read_bytes())
    summary = json.loads((folder / f'runtime27/verified-{label}.summary.json').read_bytes())
    before = json.loads((folder / 'keyboard-global-focused-native/SOURCE_BEFORE.json').read_bytes())
    after = json.loads((folder / 'keyboard-global-focused-native/SOURCE_AFTER.json').read_bytes())
    assert before['head'] == after['head'] == run['head_sha']
    assert before['application_and_tests'] == after['application_and_tests'] == '40c1eaa6bb0092336f1ee687ad1ce1425eaf4223'
    assert before['execution_inputs'] == after['execution_inputs']
    leaves = []
    def visit(node, suite=None):
        if node.get('nodeType') == 'Test Suite':
            suite = node['name'].split('.')[-1]
        if node.get('nodeType') == 'Test Case':
            leaves.append((case_id(node.get('nodeIdentifier') or f"{suite}/{node['name']}"), node.get('result')))
        for child in node.get('children', []):
            visit(child, suite)
    for node in tree.get('testNodes', []):
        visit(node)
    expected = Counter((x['case_id'], x['actual']) for x in ui['case_outcomes'])
    assert Counter(leaves) == expected and len(leaves) == count
    assert summary['passedTests'] == ui['executed_ui_pass'] == 1
    assert summary['failedTests'] == ui['executed_ui_fail'] == count - 1
    assert summary['skippedTests'] == summary['expectedFailures'] == ui['executed_ui_skip'] == ui['ui_not_run'] == 0
    cases.extend(dict(x, source=before['application_and_tests'], head=run['head_sha']) for x in ui['case_outcomes'])
    for path in ['runtime27/result.json', f'runtime27/verified-{label}.tests.json', f'runtime27/verified-{label}.summary.json',
                 'keyboard-global-focused-native/SOURCE_BEFORE.json', 'keyboard-global-focused-native/SOURCE_AFTER.json',
                 'keyboard-global-focused-native/RESULT_BEFORE.json', 'keyboard-global-focused-native/RESULT_AFTER.json']:
        zipped(folder / path, 'prior-native6/' + configuration + '/' + path + '.gz')
assert len(cases) == 6 and Counter(x['actual'] for x in cases) == {'Passed': 2, 'Failed': 4}
artifacts = json.loads((N / 'ALL_FIVE_ARTIFACTS_VERIFIED.json').read_bytes())
assert len(artifacts) == 5 and sum(x['crc_members'] for x in artifacts) == 3166
prior = {'status': 'ACTUAL_NATIVE6_FAILURE', 'run_id': run['id'], 'run_attempt': 1, 'F': run['head_sha'],
         'M': '40c1eaa6bb0092336f1ee687ad1ce1425eaf4223', 'workflow_updated_at': run['updated_at'],
         'jobs': [{k: j.get(k) for k in ['id', 'name', 'status', 'conclusion', 'started_at', 'completed_at']} for j in jobs['jobs']],
         'case_executions': 6, 'distinct_methods': 4, 'passed': 2, 'failed': 4, 'skipped': 0, 'unverified': 0,
         'case_outcomes': cases, 'artifacts': artifacts, 'zip_members_crc_verified': 3166,
         'full_native116_acceptance': False, 'full_release114_acceptance': False,
         'candidate_Global4_executed': 0, 'historical_passes_transferred': False,
         'raw_preservation': 'All five authentic complete ZIPs retained at the recorded local paths and original GitHub artifact IDs. This compact route packet includes raw leaves/source receipts/API metadata; no entire capture ZIP is copied into this CI packet.'}
dump(D / 'PRIOR_NATIVE6_RESULT.json', prior)
for name in ['RUN', 'JOBS', 'ARTIFACTS']:
    zipped(N / ('resumed-api/' + name + '.json'), 'prior-native6/api/' + name + '.json.gz')
for name in ['GLOBAL_MATCHED_AX.json', 'ESCAPE_HANDOFF.json', 'ALL_FIVE_ARTIFACTS_VERIFIED.json']:
    zipped(N / name, 'prior-native6/' + name + '.gz')
for name in ['SOURCE_PUBLICATION.json', 'SOURCE_INVERSE.json', 'PROPOSED.patch', 'prepare_candidate.py']:
    zipped(S / name, 'source-candidate/' + name + '.gz')
for path in ['base/Source/UI/iOS/Views/iPadLayout.swift', 'candidate/Source/UI/iOS/Views/iPadLayout.swift',
             'authority/BASE_COMMIT.json', 'authority/CANONICAL_BASE_TREE.json', 'authority/CANONICAL_SOURCE_TREE.json']:
    zipped(S / path, 'source-candidate/' + path + '.gz')
for name in ['prepare_route.py', 'validate_route.py', 'seal_packet.py', 'CANONICAL_INPUTS.json', 'SETUP_ATTEMPTS.json',
             'ROUTE_DELTA.patch', 'ROUTE_PROOF.json', 'evidence/VALIDATION.json', 'evidence/controls/RESULT.json',
             'evidence/controls/stdout.log', 'evidence/controls/stderr.log']:
    zipped(R / name, 'evidence/' + name + '.gz')
for name in ['Scripts.json', 'tools.json', 'Maktabah_xcodeproj.json', 'Maktabah-iOSUITests.json']:
    zipped(R / 'authority' / name, 'evidence/authority/' + name + '.gz')
for row in json.loads((R / 'CANONICAL_INPUTS.json').read_bytes())['base_records']:
    zipped(B / row['path'], 'evidence/base/' + row['path'] + '.gz')
for row in json.loads((R / 'CANONICAL_INPUTS.json').read_bytes())['prior_route_records']:
    zipped(R / 'prior-route' / row['path'], 'evidence/prior-route/' + row['path'] + '.gz')

dump(D / 'PEER_SOURCE_REVIEWS.json', {
    'scope': 'Source-only reviews; no independent Swift/Apple/Native execution.',
    'root': 'Read full production patch; background-only hit-testing/accessibility modifiers and structurally unconditional Reader have no identified source blocker. Authorized isolated one-file source publication and same four Global executions.',
    'agent_C': 'Reader content stays unconditional. No new StateObject/session replacement. Four unrelated preferences removed. Remaining original platformTabBarVisibility precedence is an actual Native question.',
    'agent_B': 'Stable content.background and noninteractive/accessibility-hidden conditional publisher; inner original iPad visible policy unchanged. Actual preference propagation, 20pt geometry and Reader hide/show remain unqualified.'})
readme = '''# Global tab ownership: source candidate and four original Native executions

Source M is `cb252c143955d037ab0cef4df556b1e8fcd4c334`, one isolated iPadLayout change on exact parent `1146a249fdd94c345371c67a8d763f16223017ee`. No integration ref or executable branch was changed when M was created. Root owns review, publication and activation of this new route.

## Actual preceding result

Native6 run [44796704535](https://github.com/davidpovarsky/Maktabah/actions/runs/44796704535), F `bce0fee51c813fe2b830d87d61b1c7943f0344f4`, M `40c1eaa6bb0092336f1ee687ad1ce1425eaf4223`, completed **2 PASS / 4 FAIL / 0 skip / 0 unverified**. Both iPad jobs and aggregate failed. The raw six leaves match the original per-configuration summaries and runtime records; before/after execution-source observations match. Five complete original artifacts were authenticated (330,190,019 bytes, 3,166 ZIP CRC entries).

| Configuration | Landscape Global | Portrait Global | Other selected cases |
|---|---|---|---|
| iPad11 | FAIL: original nav minY106, candidate86 | PASS:86 and86 | Pointer Escape and R27 keyboard calibration FAIL |
| iPad13 | PASS:106 and106 | FAIL: original106, candidate86 | None |

Each comparison used equal physical window bounds within its OFF/ON pair. Both devices executed landscape then portrait. The opposite failing orientations and the86 baseline on iPad11 portrait mean this is not demonstrated to be a portrait-only defect. No fixed expected y-coordinate or offset is introduced. Complete raw capture ZIPs remain at the authenticated local paths and their original GitHub artifacts; this small CI packet carries raw source/result/API observations and the capture mapping, not hundreds of MB of duplicate capture data.

## Production change and limits

The selected Reader now alone emits its existing visible/hidden tab-bar preference. The four unrelated global tabs no longer emit `.automatic`. Reader content remains at one unconditional structural position; only a noninteractive, accessibility-hidden `Color.clear` background conditionally publishes that preference. The complete one-file inverse preserves all original Reader state, scroll, selection, navigation and feature-off content bodies. All other Git leaves and modes are unchanged.

Apple documents toolbar visibility as a preference propagated to a bar-rendering container, with final visibility determined by that container: https://developer.apple.com/documentation/swiftui/view/toolbarvisibility(_:for:) . That contract supports investigating preference ownership; it does not prove the observed SwiftUI20pt cause. Actual background propagation/precedence against the unchanged original iPad `.visible` declaration, and Reader collapse/reveal behavior, remain runtime questions. No Swift parse, Apple typecheck or candidate Native result is claimed here.

## Exact route

`codex/otzaria-global-tab-ownership-native-20261120` is an **unactivated proposed branch**. Its new workflow derives from the actual Native6 workflow. It independently builds on the original two iPad configurations and runs the same landscape and portrait methods on each: **four executions of two existing methods**. Original whole-method geometry comparisons,±1 tolerance,20s capture and600s per-case limits are unchanged. Each proposed configuration retains all116 original catalog rows plus the two original Global diagnostic rows; the complete Native116 catalog and Release114+2 manifest are unchanged. The existing original Swift declaration parser remains mandatory in actual CI.

The prior two keyboard methods are unselected and earn no pass. Only their keyboard-log-specific qualification was omitted from this Global route. The unchanged workflow still collects original app logs. Source/hash guards, actual full-app build,55 Apple Foundation transport controls, raw XCTest leaves, zero skip/unverified checks, before/after receipts and both-configuration aggregate remain mandatory. Aggregate receipt filenames match the actual producer and the tested case-sensitive consumer. No historical pass is transferred.

## Verification already executed

All36 adapted original Python boundary/receipt controls passed. The separate79 source-preservation assertions passed, including complete driver function preservation, whole workflow inverse, actual receipt names, canonical inputs, unchanged methods/capture/oracle and the original full catalogs/budgets. These are CI and source controls, not app execution. The local full Git source gate and original Swift declaration parser are NOT_RUN on this authenticated projection; both execute first on the actual immutable CI checkout. Two local setup transport failures are retained in `SETUP_ATTEMPTS` and did not execute Swift or modify product sources.

The four Global results will qualify only this narrow source change. Reader scroll-collapse and repeated cross-tab lifetime tests, full Native116, Release114+2 and physical-device acceptance remain separately required.
'''
(D / 'README.md').write_text(readme)
items = []
for path in sorted(D.rglob('*')):
    if not path.is_file() or path == INDEX:
        continue
    raw = path.read_bytes()
    item = {'path': path.relative_to(C).as_posix(), 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw)}
    if path.suffix == '.gz':
        expanded = gzip.decompress(raw)
        item['uncompressed_bytes'] = len(expanded)
        item['uncompressed_sha256'] = sha(expanded)
    items.append(item)
dump(INDEX, {'schema_version': 1, 'source': 'cb252c143955d037ab0cef4df556b1e8fcd4c334', 'records': items,
             'qualification': 'SOURCE/PYTHON ONLY; candidate Native0', 'original_native6': 'actual2PASS4FAIL; no transfer'})
files = []
for path in sorted(C.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    raw = path.read_bytes()
    files.append({'path': path.relative_to(C).as_posix(), 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw)})
runtime_paths = [x['path'] for x in files if not x['path'].startswith('docs/hq-integration/global-tab-ownership-native-20261120/')]
assert len(runtime_paths) == 8, runtime_paths
dump(R / 'PUBLICATION_REVIEW.json', {'root': str(C), 'parent': 'cb252c143955d037ab0cef4df556b1e8fcd4c334',
     'base_tree': '71c49f8ac4404a1ffd2cc2640ec30ee1db6c7cba', 'branch': 'codex/otzaria-global-tab-ownership-native-20261120',
     'files': files, 'packet_index': next(x for x in files if x['path'] == INDEX.relative_to(C).as_posix()),
     'runtime_paths': runtime_paths, 'publication_status': 'NOT_PUBLISHED_ROOT_OWNS_ACTIVATION'})
print(json.dumps({'publication_files': len(files), 'runtime_paths': len(runtime_paths), 'packet_index_sha256': sha(INDEX.read_bytes()),
                  'candidate_Native_executed': 0, 'prior_actual': '2PASS4FAIL', 'source': 'cb252c143955d037ab0cef4df556b1e8fcd4c334'}))
