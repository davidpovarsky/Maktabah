import gzip,hashlib,json,pathlib,shutil,subprocess,time,traceback
ROOT=pathlib.Path("/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127")
BASE="24cd9291dbc87d799c22a41f0bc73a82c6415bfa"
BRANCH="codex/otzaria-wave3-integration-20261127"
DONOR="924056aca97ab3b0206069e78070d5d30fa44262"
DONOR_REPO="/home/ubuntu/otzaria-wave3-requirements-reconciliation-20261127/source"
D="docs/hq-ui-inventory/wave3-requirements-reconciliation-20261127"
PROOF="docs/hq-integration/wave3-requirements-audit-intake-20261127"
RUN=pathlib.Path(__file__).parent
events=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+"\n")
def git(*a):
 p=subprocess.run(["git","-c","gc.auto=0","-c","maintenance.auto=false","-C",str(ROOT),*a],capture_output=True)
 events.append({"args":a,"exit":p.returncode,"stdout":p.stdout.decode(errors="replace"),"stderr":p.stderr.decode(errors="replace")})
 dump(RUN/"EVENTS.json",events)
 if p.returncode:raise RuntimeError("Git failure: "+repr(a))
 return p.stdout
def rev(x):return git("rev-parse",x).decode().strip()
def show(c,p):return git("show",c+":"+p)
try:
 assert rev("HEAD")==BASE and git("symbolic-ref","--short","HEAD").decode().strip()==BRANCH
 assert not git("status","--porcelain")
 assert shutil.disk_usage(ROOT).free>=1342177280
 remote=["-c","credential.helper=!gh auth git-credential","ls-remote","origin","refs/heads/"+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 trees={p:rev(BASE+":"+p) for p in ["Source","Vendor","Maktabah.xcodeproj","Maktabah-iOSUITests","Scripts",".github","docs/architecture"]}
 git("fetch","--no-tags","--no-write-fetch-head",DONOR_REPO,DONOR)
 assert rev(DONOR+"^")==BASE
 changed=git("diff-tree","--no-commit-id","--name-only","-r",DONOR).decode().splitlines()
 assert len(changed)==17 and all(p.startswith(D+"/") for p in changed)
 treeRows=git("ls-tree","-r",DONOR,"--",D).decode().splitlines()
 assert len(treeRows)==17 and all(x.startswith("100644 blob ") for x in treeRows)
 raw=show(DONOR,D+"/MANIFEST.json")
 assert sha(raw)=="a2db079b705193889b6ae685e3fbef9240572f299a0d8f9ddd7526f4289c221f"
 manifest=json.loads(raw);rows=manifest["members"]
 assert len(rows)==16 and len(set(x["path"] for x in rows))==16
 assert set(changed)=={D+"/MANIFEST.json"}|{D+"/"+x["path"] for x in rows}
 for x in rows:
  data=show(DONOR,D+"/"+x["path"]);assert len(data)==x["bytes"] and sha(data)==x["sha256"]
 result=json.loads(show(DONOR,D+"/RESULT.json"))
 assert result["status"]=="SOURCE_RECONCILED_ACCEPTANCE_OPEN" and result["current_source"]==BASE
 assert result["current_source_tree"]==trees["Source"]=="23cdfce49553927656ef79c6db10f654c889e2fc"
 assert all(result[k]==0 for k in ["native_tests_run","physical_tests_run","compiler_or_app_build_invocations","product_source_changes","owner_approval_changes"])
 assert sha(show(DONOR,D+"/CURRENT_SOURCE_OBJECTS.json"))=="e04a8589085fc3cc28b29e0cf039b3a787465921d8d42287bea0c74e900ad3e6"
 assert sha(show(DONOR,D+"/CURRENT_TEST_INDEX.json"))=="024e8fec2e75ad9a7d7f9afb1b4e93ce1681b9acb03d946338da777ec15e92ae"
 git("-c","user.name=ChatGPT","-c","user.email=chatgpt-agent@users.noreply.github.com","cherry-pick","-x",DONOR)
 integrated=rev("HEAD")
 assert not git("status","--porcelain")
 assert all(rev("HEAD:"+p)==v for p,v in trees.items())
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 receipt=pathlib.Path(DONOR_REPO).parent/"evidence/PUBLICATION_RESULT.json"
 rawReceipt=receipt.read_bytes()
 (proof/"DONOR_PUBLICATION_RESULT.json").write_bytes(rawReceipt)
 (proof/"INTAKE.py.gz").write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 outcome={"schema":"otzaria.wave3.requirements-audit-intake.v1","base":BASE,"donor":DONOR,"integrated":integrated,"verifiedManifestMembers":16,"verifiedCommitPaths":17,"manifestSHA256":sha(raw),"resultSHA256":sha(show(DONOR,D+"/RESULT.json")),"originalInventoryRows":294,"originalQAFamilies":51,"sourceGapGroups":8,"unchangedTrees":trees,"actualDonorPublicationReceiptSHA256":sha(rawReceipt),"newTestsRun":0,"newBuildsRun":0,"ownerApprovals":0,"fullAcceptance":"OPEN"}
 dump(proof/"RESULT.json",outcome)
 (proof/"README.md").write_text("# Original requirements audit intake\n\nThe exact 17-path documentation commit was reviewed and cherry-picked. All 16 manifest members were independently hash/length verified. The current 122-path Source object join and native test declaration index match root's independently captured originals.\n\nAll Source, Vendor, project, UI tests, CI scripts, workflow and architecture/owner-policy trees are unchanged. The 294 unique inventory IDs and 51 original QA families are source reconciliation, not native or product acceptance. Eight bounded remaining source-gap groups remain explicit. No old Native116 failure, owner gate or final release requirement is waived. Saved Results and public Search implementation proceed in isolated scopes; History remembered-position Reader entry is root owned.\n")
 git("add","--sparse","--",PROOF)
 git("-c","user.name=ChatGPT","-c","user.email=chatgpt-agent@users.noreply.github.com","commit","-m","Record verified original interface requirement reconciliation intake")
 head=rev("HEAD")
 assert not git("status","--porcelain")
 assert all(rev("HEAD:"+p)==v for p,v in trees.items())
 total=set(git("diff","--name-only",BASE,"HEAD").decode().splitlines())
 assert all(p.startswith(D+"/") or p.startswith(PROOF+"/") for p in total)
 assert git(*remote).decode().split()[0]==BASE
 git("-c","remote.origin.mirror=false","-c","credential.helper=!gh auth git-credential","push","origin","HEAD:refs/heads/"+BRANCH)
 assert git(*remote).decode().split()[0]==head
 terminal={"ok":True,"head":head,"donor":DONOR,"integrated":integrated,"sourceTree":trees["Source"],"resultSHA256":sha((proof/"RESULT.json").read_bytes()),"freeBytes":shutil.disk_usage(ROOT).free,"scope":"docs only, all acceptance OPEN"}
 dump(RUN/"TERMINAL.json",terminal);print(json.dumps(terminal))
except BaseException as e:
 dump(RUN/"FAILURE.json",{"error":repr(e),"traceback":traceback.format_exc()});raise
