"""Seal actual Native6 results; preserve raw archives and avoid candidate credit."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil

R = Path(__file__).resolve().parent
W = R / 'publication'
PREFIX = 'docs/hq-integration/native6-44796704535-20261120'
D = W / PREFIX
D.mkdir(parents=True, exist_ok=True)
INDEX = D / 'PACKET_INDEX.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def gz(source, relative):
    target = D / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = source.read_bytes()
    target.write_bytes(gzip.compress(raw, mtime=0))


verified = json.loads((R / 'ALL_FIVE_ARTIFACTS_VERIFIED.json').read_bytes())
archive_index = []
for record in verified:
    source = Path(record['path'])
    raw = source.read_bytes()
    assert len(raw) == record['bytes'] and sha(raw) == record['sha256'], source
    record = dict(record, api_url='https://api.github.com/repos/davidpovarsky/Maktabah/actions/artifacts/' + str(record['artifact_id']),
                  run_url='https://github.com/davidpovarsky/Maktabah/actions/runs/44796704535')
    if source.name.endswith('-evidence.zip') or source.name == 'aggregate.zip':
        target = D / 'original-artifacts' / source.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        record['publication_path'] = target.relative_to(W).as_posix()
    else:
        record['publication_path'] = None
        record['publication_limit'] = 'Complete original capture ZIP retained locally and at its authentic GitHub artifact; this packet carries selected raw captures and complete capture manifests.'
    archive_index.append(record)
assert sum(x['bytes'] for x in archive_index) == 330190019
assert sum(x['crc_members'] for x in archive_index) == 3166
dump(D / 'ARTIFACT_AUTHENTICATION.json', archive_index)
for name in ['RUN', 'JOBS', 'ARTIFACTS']:
    gz(R / ('resumed-api/' + name + '.json'), 'api/' + name + '.json.gz')
api0 = json.loads((R / 'API_0.json').read_bytes())
assert isinstance(api0['content'], str)
job13 = R / 'ipad13-JOB.log'
job13.write_bytes(api0['content'].encode())
for name in ['ipad11-JOB.log', 'ipad13-JOB.log', 'aggregate-JOB.log']:
    gz(R / name, 'joblogs/' + name + '.gz')
for name in ['GLOBAL_MATCHED_AX.json', 'ESCAPE_HANDOFF.json', 'ALL_FIVE_ARTIFACTS_VERIFIED.json']:
    gz(R / name, 'observations/' + name + '.gz')
summary = R.parent / 'global-tab-ownership-native-20261120/candidate/docs/hq-integration/global-tab-ownership-native-20261120/PRIOR_NATIVE6_RESULT.json'
shutil.copyfile(summary, D / 'RESULT.json')
for configuration, label in [('ipad11', '11-reader'), ('ipad13', '13')]:
    root = R / (configuration + '-evidence')
    for path in ['hq-stage2/result.json', 'artifacts/runtime27/result.json',
                 f'artifacts/runtime27/verified-{label}.tests.json', f'artifacts/runtime27/verified-{label}.summary.json',
                 f'artifacts/runtime27/verified-{label}.json',
                 'artifacts/keyboard-global-focused-native/SOURCE_BEFORE.json', 'artifacts/keyboard-global-focused-native/SOURCE_AFTER.json',
                 'artifacts/keyboard-global-focused-native/RESULT_BEFORE.json', 'artifacts/keyboard-global-focused-native/RESULT_AFTER.json',
                 f'artifacts/test-simulator-{label}.log']:
        gz(root / path, 'raw/' + configuration + '/' + path + '.gz')
    if configuration == 'ipad11':
        gz(root / 'artifacts/native-routing-logs-11-reader/otzaria-reader.log', 'raw/ipad11/otzaria-reader.log.gz')
        gz(root / 'artifacts/native-routing-logs-11-reader/collection.json', 'raw/ipad11/collection.json.gz')
    capture = R / (configuration + '-captures') / ('visual-' + label)
    gz(capture / 'manifest.json', 'capture-manifests/' + configuration + '.json.gz')
gz(R / 'aggregate/AGGREGATE.json', 'raw/AGGREGATE.json.gz')
ax = json.loads((R / 'GLOBAL_MATCHED_AX.json').read_bytes())
for item in ax:
    for snapshot in item['snapshots']:
        source = Path(snapshot['path'])
        assert sha(source.read_bytes()) == snapshot['sha256']
        gz(source, 'selected-captures/' + item['device'] + '/' + source.name + '.gz')
images = {
    'ipad11': ['4FD2F8C5-59CF-4744-B139-363D446EFFCC.png', 'C1E45AB9-5FCF-47B7-B623-01FBFB85989A.png',
               '9516664B-DCAD-478D-81B3-07700CFB3CF9.png', '187B890B-76E1-4C44-B586-F7C78716072B.png'],
    'ipad13': ['41A72AE2-38B4-4659-A01A-41C26EFA6E45.png', '78854549-9B5A-4A07-BC6B-B3A6577F09C1.png',
               '74FB1E36-B620-44DD-A759-0139D5BA1557.png', '4A882FB3-8637-4430-90FE-3B6C39D5F46B.png']}
for configuration, names in images.items():
    label = '11-reader' if configuration == 'ipad11' else '13'
    for name in names:
        source = R / (configuration + '-captures') / ('visual-' + label) / name
        target = D / 'selected-captures' / configuration / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
for name in ['5FAA2C49-EB8E-4269-941A-7C7AE11FBFF4.txt', 'CCDBCA29-821D-4A07-98CD-DEA5B3914C4C.png']:
    source = R / 'ipad11-captures/visual-11-reader' / name
    if source.suffix == '.txt':
        gz(source, 'selected-captures/escape/' + name + '.gz')
    else:
        target = D / 'selected-captures/escape' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
gz(Path(__file__), 'evidence/seal_terminal_result.py.gz')
readme = '''# Native6 actual terminal evidence — run44796704535

The exact frozen checkout `bce0fee51c813fe2b830d87d61b1c7943f0344f4`, application/tests `40c1eaa6bb0092336f1ee687ad1ce1425eaf4223`, ran once and completed **FAILURE:2 PASS,4 FAIL,0 skipped,0 unverified** across six executions of four distinct original methods. No result is transferred to a later source. This is not full Native116 or Release114+2 acceptance.

## Verified outcomes

| Device | Original method | Actual outcome |
|---|---|---|
| iPad11 | Global Search landscape parity | FAIL: both actual navigation bars minY106→86, unchanged±1 oracle |
| iPad11 | Global Search portrait parity | PASS:86→86 |
| iPad11 | Pointer hover/click and hardware-keyboard dismissal | FAIL: original15s Escape dismissal |
| iPad11 | R27 keyboard dispatch calibration | FAIL: original15s Escape input removal |
| iPad13 | Global Search landscape parity | PASS:106→106 |
| iPad13 | Global Search portrait parity | FAIL: both actual navigation bars106→86 |

The six raw XCTest case leaves, raw summaries and original runtime result rows agree exactly. Both complete full-app/test builds reached real UI execution. The two source-before/source-after execution closures match. Both matrix jobs and aggregate fail; aggregate preserves partial observations as unqualified rather than reporting a pass. Full build/compiler logs remain inside the original evidence ZIPs. No zero-compiler-warning claim is made.

## Execution time and layout observations

iPad13 job136497998833 ended19:43:19UTC, iPad11 job136497998236 ended20:05:05UTC, and aggregate136537298877 ended20:05:39UTC on2026-11-20. Workflow updated_at is20:05:39UTC; readback/collection time is a separate observation and does not redefine execution finish.

Both jobs executed landscape before portrait; within each method the original feature-off app launched before the enabled candidate. Every OFF/ON pair has equal physical window bounds. iPad13 portrait is1032×1376; landscape1376×1032. iPad11 portrait834×1210; landscape1210×834. Failed pairs shift both navigation bars and the original query field20pt upward; bar sizes stay the same. Because iPad11 portrait passes at86 and iPad13 landscape passes at106, the evidence does not establish a single required absolute y-coordinate or a portrait-only defect. The exact paired AX and original PNGs are retained.

The source ownership candidate later published as `cb252c143955d037ab0cef4df556b1e8fcd4c334` removes unnecessary unrelated-tab preference publishers and keeps Reader structurally unconditional. It has **zero Native execution** in this packet; actual SwiftUI preference propagation, geometry and Reader behavior remain to be qualified. The prior source M40 and current pre-candidate409/1146 have identical application Source trees, so the failed product state has not been silently attributed to a newer unrelated fix.

## Keyboard boundary

Original app trace proves real palette opening, owner/focus callback, first responder and key window. Calibration logs original Close and reopen, plus Down/Up input before the XCTest Escape synthesized event. No corresponding Escape handler/close trace was observed. This does not identify whether event delivery, platform keyboard state or product handling caused the missing dismissal. Root owns that diagnosis separately. Exact trace lines, event/AX/PNG IDs and source timestamps remain in ESCAPE_HANDOFF.

## Authentication and preservation

All five original ZIPs are preserved and match the canonical GitHub artifact byte sizes and SHA256 values. All3,166 ZIP entries passed CRC verification. Total original archive bytes:330,190,019. This packet includes the two complete evidence ZIPs and complete aggregate ZIP, all three full job logs, terminal run/jobs/artifacts API records, raw source/result observations, full visual-capture manifests, eight matched Global AX/PNG pairs and selected Escape evidence.

The two complete capture ZIPs (93,782,761 and221,407,962bytes) remain intact at the recorded local paths and original GitHub artifact IDs. They are not duplicated into this Git documentation packet; selected entries and their manifest mapping are included. Signed download URLs and secret transport receipts are excluded. Existing archive/source records are preserved unchanged. No test rerun, workflow cancellation or dispatch was performed to assemble this packet.
'''
(D / 'README.md').write_text(readme)
records = []
for path in sorted(D.rglob('*')):
    if not path.is_file() or path == INDEX:
        continue
    raw = path.read_bytes()
    item = {'path': path.relative_to(W).as_posix(), 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw)}
    if path.suffix == '.gz':
        expanded = gzip.decompress(raw)
        item.update(uncompressed_bytes=len(expanded), uncompressed_sha256=sha(expanded))
    records.append(item)
dump(INDEX, {'schema_version': 1, 'run_id': 44796704535, 'F': 'bce0fee51c813fe2b830d87d61b1c7943f0344f4',
             'M': '40c1eaa6bb0092336f1ee687ad1ce1425eaf4223', 'status': 'ACTUAL_FAILURE_2PASS_4FAIL', 'records': records})
raw = INDEX.read_bytes()
records.append({'path': INDEX.relative_to(W).as_posix(), 'bytes': len(raw), 'sha256': sha(raw), 'git_blob': blob(raw)})
dump(R / 'TERMINAL_PUBLICATION_REVIEW.json', {'root': str(W), 'docs_prefix': PREFIX,
     'parent': 'bce0fee51c813fe2b830d87d61b1c7943f0344f4', 'base_tree': 'b7703bb1b5c3fa14687bdbc6ec7c0cbcf8a20e52',
     'files': records, 'packet_index': records[-1], 'publication_status': 'SEALED_LOCALLY_NOT_PUBLISHED',
     'no_executable_branch_or_current_integration_mutation': True})
print(json.dumps({'files': len(records), 'bytes': sum(x['bytes'] for x in records), 'index_sha256': sha(raw),
                  'actual': '2PASS4FAIL_0skip_0unverified', 'Native_candidate': 0}))
