import Foundation
import OtzariaActionCore

// These are explicit synthetic authority/backend/clock boundaries. The real
// ActionExecutor factory and production grant run; no native/provider runs.
private enum ControlError: Error { case unused, failed }
private final class TestClock: ActionClock, @unchecked Sendable {
    private let lock = NSLock()
    private var value: UInt64 = 100
    func now() -> UInt64 { lock.lock(); defer { lock.unlock() }; return value }
    func sleep(until deadline: UInt64) async throws { throw ControlError.unused }
    func advance(to value: UInt64) { lock.lock(); self.value = value; lock.unlock() }
}

@MainActor private final class Backend: ActionSynchronousBackendStatePort, ActionResolverPort, ActionSearchPort {
    var value: ActionBackendSnapshot
    var onRead: (@MainActor () -> Void)?
    init(_ value: ActionBackendSnapshot) { self.value = value }
    func currentBackendSnapshot() throws -> ActionBackendSnapshot { onRead?(); return value }
    func snapshot() async throws -> ActionBackendSnapshot { try currentBackendSnapshot() }
    func report(for backend: ActionBackendID) async throws -> ActionBackendReport { throw ControlError.unused }
    func assess(action: String, arguments: ActionObject, invocation: ActionPortInvocation) async throws -> ActionCapabilityAssessment { throw ControlError.unused }
    func resolveWork(_ query: ActionResolveWorkQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionWorkRef> { throw ControlError.unused }
    func resolveReference(_ query: ActionResolveReferenceQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionTextRef> { throw ControlError.unused }
    func validateDestination(_ destination: ActionReaderDestination, invocation: ActionPortInvocation) async throws -> ActionReaderDestination { throw ControlError.unused }
    func search(_ query: ActionSearchQuery, invocation: ActionPortInvocation) async throws -> ActionSearchPage { throw ControlError.unused }
}

@MainActor private final class Navigation: ActionNavigationAuthority {
    var context: ActionExecutionContext
    var scene = "original-scene"
    var lifetime = UUID()
    var revision: UInt64 = 0
    var active = true
    var onRead: (@MainActor () -> Void)?
    init(_ context: ActionExecutionContext) { self.context = context }
    func navigationState(sceneID: String) throws -> ActionNavigationState {
        onRead?()
        return .init(context: context, sceneID: scene, lifetimeID: lifetime,
                     authorityRevision: revision, active: active)
    }
}

@MainActor private struct Fixture {
    let backend: Backend
    let navigation: Navigation
    let clock: TestClock
    let core: ActionExecutor
    let context: ActionExecutionContext
    let command: ActionSearchContinuationCommand

    init(backendID: ActionBackendID = .otzaria, rpcEpoch: UInt64? = nil,
         scopes: Set<ActionScope> = [.navigation, .discovery], limited: Bool = false,
         nextPage: Bool = false) throws {
        let snapshot = ActionBackendSnapshot(backend: backendID, generation: 7, rpcEpoch: rpcEpoch)
        let context = ActionExecutionContext(subjectID: "original-scene-owner", origin: .inApp,
            allowedBackends: [backendID], scopes: scopes,
            allowedWorkKeys: limited ? [backendID: ["retained-work"]] : nil,
            foregroundSceneID: "original-scene")
        let backend = Backend(snapshot), navigation = Navigation(context), clock = TestClock()
        self.backend = backend; self.navigation = navigation; self.clock = clock; self.context = context
        core = try ActionExecutor(state: backend, resolver: backend, search: backend,
                                  clock: clock, navigationAuthority: navigation)
        let source = ActionSearchContinuationSource(observationID: UUID(), sceneID: "original-scene",
            snapshot: snapshot, sessionID: UUID(), modelID: UUID(), generation: 3,
            sourceRevision: 4, submissionRevision: 1, cancellationRevision: 0,
            paginationRevision: 0, pageRevision: 1, configuration: Data("fixture-original-configuration".utf8))
        command = .init(source: source,
            operation: nextPage ? .nextOriginalPage(token: UUID()) : .revealLoadedHit(token: UUID()),
            invocation: .init(requestId: UUID(), snapshot: snapshot, deadlineUptimeNanoseconds: 5_100))
    }

    func grant() throws -> ActionSearchContinuationAuthority {
        try core.prepareSearchContinuationSynchronously(command, context: context)
    }
}

@main private struct Controls {
    @MainActor static func main() async {
        var rows: [[String: Any]] = []
        @MainActor func rejects(_ body: @MainActor () throws -> Void) -> Bool { do { try body(); return false } catch { return true } }
        @MainActor func check(_ name: String, _ body: @MainActor () throws -> Bool) {
            do { rows.append(["name": name, "pass": try body()]) }
            catch { rows.append(["name": name, "pass": false, "errorType": String(describing: type(of: error))]) }
        }
        check("freshness does not authorize original execution") {
            let f = try Fixture(), grant = try f.grant()
            try grant.validateFreshness(for: f.command)
            return rejects { try grant.validateExecution(for: f.command) }
                && rejects { try grant.validateCompletion(for: f.command) }
        }
        check("one actual grant supports live execution and completion") {
            let f = try Fixture(), grant = try f.grant()
            try grant.authorizeOriginalOperation(f.command)
            try grant.validateExecution(for: f.command); try grant.validateCompletion(for: f.command)
            return rejects { try grant.authorizeOriginalOperation(f.command) }
        }
        check("next-page operation is one use independently of hit operation") {
            let f = try Fixture(nextPage: true), grant = try f.grant()
            try grant.authorizeOriginalOperation(f.command); try grant.validateExecution(for: f.command)
            let foreign = ActionSearchContinuationCommand(source: f.command.source,
                operation: .revealLoadedHit(token: UUID()), invocation: f.command.invocation)
            return rejects { try grant.validateExecution(for: foreign) }
                && rejects { try grant.authorizeOriginalOperation(f.command) }
        }
        check("different request cannot reuse authority") {
            let f = try Fixture(), grant = try f.grant()
            let command = ActionSearchContinuationCommand(source: f.command.source, operation: f.command.operation,
                invocation: .init(requestId: UUID(), snapshot: f.command.invocation.snapshot,
                                  deadlineUptimeNanoseconds: f.command.invocation.deadlineUptimeNanoseconds))
            return rejects { try grant.authorizeOriginalOperation(command) }
        }
        check("renewed deadline cannot reuse authority") {
            let f = try Fixture(), grant = try f.grant()
            let command = ActionSearchContinuationCommand(source: f.command.source, operation: f.command.operation,
                invocation: .init(requestId: f.command.invocation.requestId, snapshot: f.command.invocation.snapshot,
                                  deadlineUptimeNanoseconds: 10_100))
            return rejects { try grant.authorizeOriginalOperation(command) }
        }
        check("different source observation cannot reuse authority") {
            let f = try Fixture(), other = try Fixture(), grant = try f.grant()
            let command = ActionSearchContinuationCommand(source: other.command.source,
                operation: f.command.operation, invocation: f.command.invocation)
            return rejects { try grant.authorizeOriginalOperation(command) }
        }
        check("reentrant original operation receives no second grant") {
            let f = try Fixture(), grant = try f.grant()
            var denied = false
            f.navigation.onRead = {
                f.navigation.onRead = nil
                denied = rejects { try grant.authorizeOriginalOperation(f.command) }
            }
            try grant.authorizeOriginalOperation(f.command)
            try grant.validateExecution(for: f.command)
            return denied
        }
        check("metadata validation callback cannot authorize an effect") {
            let f = try Fixture(), grant = try f.grant()
            var denied = false
            f.navigation.onRead = {
                f.navigation.onRead = nil
                denied = rejects { try grant.authorizeOriginalOperation(f.command) }
            }
            try grant.validateFreshness(for: f.command)
            return denied && rejects { try grant.validateExecution(for: f.command) }
        }
        check("retirement inside original commit validation is terminal") {
            let f = try Fixture(), grant = try f.grant()
            f.navigation.onRead = { f.navigation.onRead = nil; grant.retire() }
            return rejects { try grant.authorizeOriginalOperation(f.command) }
                && rejects { try grant.authorizeOriginalOperation(f.command) }
                && rejects { try grant.validateExecution(for: f.command) }
        }
        check("retirement inside execution validation invalidates result") {
            let f = try Fixture(), grant = try f.grant()
            try grant.authorizeOriginalOperation(f.command)
            f.navigation.onRead = { f.navigation.onRead = nil; grant.retire() }
            return rejects { try grant.validateExecution(for: f.command) }
        }
        check("retirement before commit cannot be rearmed") {
            let f = try Fixture(), grant = try f.grant(); grant.retire()
            return rejects { try grant.authorizeOriginalOperation(f.command) }
                && rejects { try grant.validateFreshness(for: f.command) }
        }
        check("failed authorization cannot become valid after authority restore") {
            let f = try Fixture(), grant = try f.grant(); f.navigation.active = false
            let first = rejects { try grant.authorizeOriginalOperation(f.command) }
            f.navigation.active = true
            return first && rejects { try grant.authorizeOriginalOperation(f.command) }
        }
        check("authority revision ABA invalidates consumed grant") {
            let f = try Fixture(), grant = try f.grant(); try grant.authorizeOriginalOperation(f.command)
            f.navigation.active = false; f.navigation.revision += 1
            f.navigation.active = true; f.navigation.revision += 1
            return rejects { try grant.validateCompletion(for: f.command) }
        }
        check("native lifetime replacement invalidates grant") {
            let f = try Fixture(), grant = try f.grant(); f.navigation.lifetime = UUID()
            return rejects { try grant.authorizeOriginalOperation(f.command) }
        }
        check("backend generation change invalidates consumed grant") {
            let f = try Fixture(), grant = try f.grant(); try grant.authorizeOriginalOperation(f.command)
            f.backend.value = .init(backend: .otzaria, generation: 8)
            return rejects { try grant.validateCompletion(for: f.command) }
        }
        check("real RPC epoch change invalidates consumed grant") {
            let f = try Fixture(backendID: .sefariaEmbedded, rpcEpoch: 4), grant = try f.grant()
            try grant.authorizeOriginalOperation(f.command)
            f.backend.value = .init(backend: .sefariaEmbedded, generation: 7, rpcEpoch: 5)
            return rejects { try grant.validateExecution(for: f.command) }
        }
        check("missing required RPC epoch cannot issue grant") {
            let f = try Fixture(backendID: .sefariaEmbedded)
            return rejects { _ = try f.grant() }
        }
        check("deadline boundary refuses before native operation") {
            let f = try Fixture(), grant = try f.grant(); f.clock.advance(to: 5_100)
            return rejects { try grant.authorizeOriginalOperation(f.command) }
        }
        check("deadline after operation refuses completion without new grant") {
            let f = try Fixture(), grant = try f.grant(); try grant.authorizeOriginalOperation(f.command)
            f.clock.advance(to: 5_100)
            return rejects { try grant.validateCompletion(for: f.command) }
        }
        check("discovery alone cannot grant native mutation") {
            let f = try Fixture(scopes: [.discovery]); return rejects { _ = try f.grant() }
        }
        check("opaque configuration does not widen limited work scope") {
            let f = try Fixture(limited: true); return rejects { _ = try f.grant() }
        }
        check("foreground scene change invalidates grant") {
            let f = try Fixture(), grant = try f.grant(); f.navigation.scene = "replacement-scene"
            return rejects { try grant.authorizeOriginalOperation(f.command) }
        }
        check("context revocation invalidates grant") {
            let f = try Fixture(), grant = try f.grant()
            f.navigation.context = .init(subjectID: "original-scene-owner", origin: .inApp,
                allowedBackends: [.otzaria], scopes: [.discovery], foregroundSceneID: "original-scene")
            return rejects { try grant.authorizeOriginalOperation(f.command) }
        }
        let cancelled = Task { @MainActor in
            do { let f = try Fixture(); _ = try f.grant(); return false }
            catch is CancellationError { return true }
            catch { return false }
        }
        cancelled.cancel()
        rows.append(["name": "actual cancelled task cannot issue grant", "pass": await cancelled.value])
        let passed = rows.filter { $0["pass"] as? Bool == true }.count
        let result: [String: Any] = ["scope": "Actual Core factory and grant; explicit synthetic live owners and clock",
            "passed": passed, "failed": rows.count - passed, "cases": rows,
            "nativeOperations": 0, "providerQueries": 0, "appleSDK": "NOT_RUN"]
        let data = try! JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        print(String(decoding: data, as: UTF8.self))
        if passed != rows.count { exit(1) }
    }
}
