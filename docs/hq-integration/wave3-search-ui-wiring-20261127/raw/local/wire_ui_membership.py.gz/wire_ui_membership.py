from pathlib import Path
import hashlib
import json
import re
import runpy

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "ui-baseline"
OUT = ROOT / "candidate"
REPORT = ROOT / "review"


def sha(value):
    return hashlib.sha256(value).hexdigest()


def save(path, data):
    target = OUT / path
    assert not target.exists(), str(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


parser_path = BASE / "verify_source_registration.py"
assert sha(parser_path.read_bytes()) == "eff5cf3c0935562f9e9b1bbcd296f192c4daf2922cc9185d8fa5ad0ab3246a18"
parser = runpy.run_path(str(parser_path))
project_path = "Maktabah.xcodeproj/project.pbxproj"
original = (BASE / project_path).read_bytes()
assert sha(original) == "ab245c2c715d8ee7cb4550f1a6d9d7b26f3955c53faf3bfc295f35cb5b547f43"
before, old_duplicates = parser["parse"](original.decode())
objects = before["objects"]
phases = parser["target_sources"](before)
group = "CFEE00000000000000000001"
phase = phases["Maktabah-iOS"][0]
assert phase == "F30576E22FA46222005732C6"

# These two existing owners both belong only to the original iOS app target.
for neighbor in ["StudyWorkspace/StudyWorkspaceNavigationAdapter.swift",
                 "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeReaderTabBinding.swift"]:
    refs = [key for key, value in objects.items()
            if value.get("isa") == "PBXFileReference" and value.get("path") == neighbor]
    assert len(refs) == 1
    builds = [key for key, value in objects.items() if value.get("fileRef") == refs[0]]
    assert [name for name, (_, entries) in phases.items() if any(x in entries for x in builds)] == ["Maktabah-iOS"]

paths = [
    "StudyWorkspace/StudyWorkspacePreparedGroupSelection.swift",
    "StudyWorkspace/StudyWorkspaceGroupSelectionReservation.swift",
    "UIRoutingHost/Integration/MaktabahNativeWorkspaceSelectionBinding.swift",
    "UIRoutingHost/Integration/MaktabahNativeWindowObservation.swift",
    "UIRoutingHost/Integration/MaktabahNativeViewerParentContinuation.swift",
    "UIRoutingHost/Integration/MaktabahNativeViewerParentWitness.swift",
    "UIRoutingHost/Integration/MaktabahNativeSearchContinuationOwner.swift",
]
entries = []
for relative in paths:
    name = Path(relative).name
    entry = {"path": "Source/ChavrusaText/" + relative, "relative": relative, "name": name,
             "ref": hashlib.sha256(("wave3-ui-ref:" + relative).encode()).hexdigest()[:24].upper(),
             "build": hashlib.sha256(("wave3-ui-ios-build:" + relative).encode()).hexdigest()[:24].upper()}
    assert entry["ref"] not in objects and entry["build"] not in objects
    assert not any(value.get("isa") == "PBXFileReference" and value.get("path") == relative for value in objects.values())
    entries.append(entry)
assert len({value for entry in entries for value in (entry["ref"], entry["build"])}) == 14
text = original.decode()
insertions = []


def insert(offset, value, purpose):
    global text
    text = text[:offset] + value + text[offset:]
    insertions.append({"offset": offset, "text": value, "purpose": purpose})


insert(text.index("/* End PBXBuildFile section */"), "".join(
    "\t\t" + x["build"] + " /* " + x["name"] + " in Sources */ = {isa = PBXBuildFile; fileRef = "
    + x["ref"] + " /* " + x["name"] + " */; };\n" for x in entries), "Seven original iOS source build entries")
insert(text.index("/* End PBXFileReference section */"), "".join(
    "\t\t" + x["ref"] + " /* " + x["name"] + " */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = \""
    + x["relative"] + "\"; sourceTree = \"<group>\"; };\n" for x in entries), "Seven app source references")
for object_id, field, content in [
    (group, "children", "".join("\t\t\t\t" + x["ref"] + " /* " + x["name"] + " */,\n" for x in entries)),
    (phase, "files", "".join("\t\t\t\t" + x["build"] + " /* " + x["name"] + " in Sources */,\n" for x in entries)),
]:
    start = re.search(r"(?m)^\t\t" + object_id + r" /\*[^*]+\*/ = \{\n", text).start()
    anchor = "\t\t\t" + field + " = (\n"
    insert(text.index(anchor, start) + len(anchor), content, "Append exact " + field + " memberships")

after, duplicates = parser["parse"](text)
assert duplicates == old_duplicates
new_objects = after["objects"]
assert set(new_objects) - set(objects) == {value for x in entries for value in (x["ref"], x["build"])}
assert {key for key in objects if objects[key] != new_objects[key]} == {group, phase}
assert {key: value for key, value in before.items() if key != "objects"} == {key: value for key, value in after.items() if key != "objects"}
for key, field in [(group, "children"), (phase, "files")]:
    assert {k: v for k, v in objects[key].items() if k != field} == {k: v for k, v in new_objects[key].items() if k != field}
    assert [x for x in new_objects[key][field] if x in objects[key][field]] == objects[key][field]
for entry in entries:
    assert new_objects[group]["children"].count(entry["ref"]) == 1
    assert new_objects[phase]["files"].count(entry["build"]) == 1
    assert [name for name, (_, ids) in parser["target_sources"](after).items() if entry["build"] in ids] == ["Maktabah-iOS"]
inverse = text
for addition in reversed(insertions):
    offset, value = addition["offset"], addition["text"]
    assert inverse[offset:offset + len(value)] == value
    inverse = inverse[:offset] + inverse[offset + len(value):]
assert inverse.encode() == original
save(project_path, text.encode())
(REPORT / "UI_PBX_INSERTIONS.json").write_text(json.dumps(insertions, indent=2) + "\n")

catalog_rows = []


def add_catalog(path, translations, include_english):
    original = (BASE / path).read_bytes()
    parsed = json.loads(original)
    assert parsed["sourceLanguage"] == "en"
    assert not set(translations) & set(parsed["strings"])
    additions = {}
    for english, hebrew in translations.items():
        localizations = {"he": {"stringUnit": {"state": "translated", "value": hebrew}}}
        if include_english:
            localizations = {"en": {"stringUnit": {"state": "translated", "value": english}}, **localizations}
        additions[english] = {"localizations": localizations}
    block = json.dumps(additions, ensure_ascii=False, indent=2)[2:-2]
    block = "\n".join("  " + line for line in block.splitlines()) + ",\n"
    anchor = '  "strings": {\n'
    source = original.decode()
    assert source.count(anchor) == 1
    candidate = source.replace(anchor, anchor + block, 1)
    result = json.loads(candidate)
    assert {k: v for k, v in result.items() if k != "strings"} == {k: v for k, v in parsed.items() if k != "strings"}
    assert {k: v for k, v in result["strings"].items() if k not in additions} == parsed["strings"]
    assert candidate.replace(anchor + block, anchor, 1).encode() == original
    for key, value in additions.items():
        assert result["strings"][key] == value
        assert re.findall(r"\$\{[^}]+\}", key) == re.findall(r"\$\{[^}]+\}", translations[key])
    save(path, candidate.encode())
    catalog_rows.append({"path": path, "beforeSHA256": sha(original), "afterSHA256": sha(candidate.encode()),
                         "keys": list(additions), "originalBytesRestoredByRemovingInsertion": True})


add_catalog("Source/Localizable.xcstrings", {
    "Study profile": "פרופיל לימוד",
    "Tab group": "קבוצת טאבים",
    "Open a study profile": "פתיחת פרופיל לימוד",
    "Open study profile": "פתיחת פרופיל לימוד",
    "Open a tab group": "פתיחת קבוצת טאבים",
    "Open tab group": "פתיחת קבוצת טאבים",
    "Open ${selection}": "פתיחת ${selection}",
    "Select the first tab group of an original study profile in the current library of the selected Maktabah window.":
        "בחירת קבוצת הטאבים הראשונה בפרופיל לימוד קיים, בספרייה הנוכחית של חלון אוצריא שנבחר.",
    "Select an original tab group in the current study profile and library of the selected Maktabah window.":
        "בחירת קבוצת טאבים קיימת בפרופיל הלימוד ובספרייה הנוכחיים בחלון אוצריא שנבחר.",
}, True)
add_catalog("Source/ChavrusaText/UIRoutingHost/Integration/AppShortcuts.xcstrings", {
    "Open study profile ${selection} in ${applicationName}": "פתיחת פרופיל הלימוד ${selection} באפליקציה ${applicationName}",
    "Open tab group ${selection} in ${applicationName}": "פתיחת קבוצת הטאבים ${selection} באפליקציה ${applicationName}",
}, False)

shortcut_path = "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift"
original_shortcuts = (BASE / shortcut_path).read_text()
assert sha(original_shortcuts.encode()) == "23404297c83bce209dc710e0ffb22e28d767d224c37ca4ae602eb84aad5836a4"
addition = '''        AppShortcut(intent: OpenStudyProfileIntent(),
                    phrases: ["Open study profile \\(\\.$selection) in \\(.applicationName)"],
                    shortTitle: "Open study profile", systemImageName: "person.crop.circle")
        AppShortcut(intent: OpenStudyTabGroupIntent(),
                    phrases: ["Open tab group \\(\\.$selection) in \\(.applicationName)"],
                    shortTitle: "Open tab group", systemImageName: "rectangle.3.group")
'''
anchor = "    }\n}\n#endif\n"
assert original_shortcuts.count(anchor) == 1
new_shortcuts = original_shortcuts.replace(anchor, addition + anchor)
assert original_shortcuts.count("AppShortcut(intent:") == 4 and new_shortcuts.count("AppShortcut(intent:") == 6
assert new_shortcuts.replace(addition, "") == original_shortcuts
save(shortcut_path, new_shortcuts.encode())
report = {"schema": "otzaria.wave3.ui-source-membership-and-localization.v1",
          "base": "dd4b28f42950689713a5980dbd3dae21eb414f26",
          "project": {"beforeSHA256": sha(original), "afterSHA256": sha(text.encode()),
                      "afterBytes": len(text.encode()), "entries": entries, "newObjects": 14,
                      "existingChangedObjects": [group, phase], "oldBytesExactlyRestoredByRemovingInsertions": True},
          "catalogs": catalog_rows,
          "shortcuts": {"path": shortcut_path, "beforeSHA256": sha(original_shortcuts.encode()),
                        "afterSHA256": sha(new_shortcuts.encode()), "preservedOriginalDefinitions": 4, "addedDefinitions": 2},
          "originalParserSHA256": sha(parser_path.read_bytes()),
          "AppleAppIntentsMetadataExtraction": "NOT_RUN", "XcodeCompilation": "NOT_RUN", "native": "NOT_RUN"}
(REPORT / "UI_MEMBERSHIP_LOCALIZATION.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False))
