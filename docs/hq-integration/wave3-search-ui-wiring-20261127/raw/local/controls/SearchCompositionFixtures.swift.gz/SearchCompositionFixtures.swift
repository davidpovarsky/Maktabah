import Foundation
import OtzariaActionCore

// Explicit app/domain doubles around the extracted unchanged production entry.
// The real Core and real NativeSearchContinuationService run. No UIKit view,
// native publication, provider, database or OS App Intent is simulated as PASS.
enum CompositionControlError: Error { case unused, refused, invalid }
struct UIStableID: Hashable { let rawValue: String }
struct UIRouteError: Error {
    let status: ActionStatus
    let code: String
    init(_ status: ActionStatus, _ code: String) { self.status = status; self.code = code }
}
@MainActor final class iOSNavigationManager {}

@MainActor final class CompositionBackend: ActionSynchronousBackendStatePort, ActionResolverPort, ActionSearchPort {
    var value = ActionBackendSnapshot(backend: .otzaria, generation: 7)
    var providerQueries = 0
    func currentBackendSnapshot() throws -> ActionBackendSnapshot { value }
    func snapshot() async throws -> ActionBackendSnapshot { value }
    func report(for backend: ActionBackendID) async throws -> ActionBackendReport { throw CompositionControlError.unused }
    func assess(action: String, arguments: ActionObject, invocation: ActionPortInvocation) async throws -> ActionCapabilityAssessment { throw CompositionControlError.unused }
    func resolveWork(_ query: ActionResolveWorkQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionWorkRef> { throw CompositionControlError.unused }
    func resolveReference(_ query: ActionResolveReferenceQuery, invocation: ActionPortInvocation) async throws -> ActionResolution<ActionTextRef> { throw CompositionControlError.unused }
    func validateDestination(_ destination: ActionReaderDestination, invocation: ActionPortInvocation) async throws -> ActionReaderDestination { throw CompositionControlError.unused }
    func search(_ query: ActionSearchQuery, invocation: ActionPortInvocation) async throws -> ActionSearchPage {
        providerQueries += 1; throw CompositionControlError.unused
    }
}

@MainActor final class CompositionNavigation: ActionNavigationAuthority {
    struct Lease: Equatable { let lifetimeID: UUID }
    let lease = Lease(lifetimeID: UUID())
    var admitted: ActionExecutionContext?
    var revision: UInt64 = 0
    var admits = 0
    var releases = 0
    func admit(context: ActionExecutionContext, sceneID: UIStableID) throws -> Lease {
        guard admitted == nil, context.foregroundSceneID == sceneID.rawValue else { throw CompositionControlError.invalid }
        admitted = context; admits += 1
        return lease
    }
    func release(_ actual: Lease) {
        guard actual == lease, admitted != nil else { return }
        admitted = nil; releases += 1
    }
    func navigationState(sceneID: String) throws -> ActionNavigationState {
        guard let admitted else { throw CompositionControlError.refused }
        return .init(context: admitted, sceneID: sceneID, lifetimeID: lease.lifetimeID,
                     authorityRevision: revision, active: true)
    }
}

@MainActor final class MaktabahNativeSearchContinuationBinding {
    typealias Check = @MainActor () throws -> Void
    let snapshot: ActionBackendSnapshot
    let sceneID: UIStableID
    let hit = ActionLoadedSearchHit(token: UUID(), stableID: "fixture-row", locator: nil,
                                  versionTitle: nil, language: nil, identity: Data("fixture-identity".utf8))
    var source: ActionSearchContinuationSource?
    var authority: Check?
    var observeCount = 0
    var applyCount = 0
    var effectCount = 0
    var validates = 0
    var retired = false
    var beforeEffect: (@MainActor () async -> Void)?
    var afterEffect: (@MainActor () -> Void)?
    var response: (@MainActor (ActionSearchContinuationCommand, ActionSearchContinuationReceipt) -> ActionSearchContinuationOutcome)?
    var actualReturned: ActionSearchContinuationOutcome?

    init(snapshot: ActionBackendSnapshot, sceneID: UIStableID) { self.snapshot = snapshot; self.sceneID = sceneID }
    func observe(invocation: ActionPortInvocation, retainAuthority: () throws -> Check) throws -> ActionSearchContinuationObservation {
        authority = try retainAuthority(); try authority?()
        guard !retired else { throw CompositionControlError.refused }
        observeCount += 1
        let source = ActionSearchContinuationSource(observationID: UUID(), sceneID: sceneID.rawValue,
            snapshot: snapshot, sessionID: UUID(), modelID: UUID(), generation: 3,
            sourceRevision: 1, submissionRevision: 1, cancellationRevision: 0,
            paginationRevision: 0, pageRevision: 1, configuration: Data("fixture-configuration".utf8))
        self.source = source
        return .init(source: source, loadedHits: [hit], nextPageToken: nil)
    }
    func perform(_ command: ActionSearchContinuationCommand, validateAuthority: @escaping Check) async -> ActionSearchContinuationOutcome {
        applyCount += 1
        do {
            if let beforeEffect { await beforeEffect() }
            try validateAuthority(); try authority?()
            guard !retired, command.source == source,
                  command.operation == .revealLoadedHit(token: hit.token) else { throw CompositionControlError.refused }
            effectCount += 1
            let receipt = ActionSearchContinuationReceipt(requestID: command.invocation.requestId,
                before: command.source, after: command.source, operation: command.operation,
                effects: [.hitSelectionApplied(hit)],
                visible: .init(witnessID: UUID(), listID: UUID(), rowID: UUID(), layoutRevision: 1, identity: hit.identity))
            afterEffect?()
            let result = response?(command, receipt) ?? .acknowledged(receipt)
            actualReturned = result
            return result
        } catch {
            let result = ActionSearchContinuationOutcome.refused(.init(requestID: command.invocation.requestId,
                reason: .staleSource, effects: [], source: command.source, operation: command.operation))
            actualReturned = result
            return result
        }
    }
    func validateCompletion(_ command: ActionSearchContinuationCommand, receipt: ActionSearchContinuationReceipt) throws {
        validates += 1
        guard !retired, source == command.source, receipt.before == command.source else { throw CompositionControlError.refused }
        try authority?()
    }
    func retire() { retired = true; authority = nil }
}

@MainActor final class MaktabahNativeSearchContinuationOwner {
    let requestID: UUID
    let sceneID: UIStableID
    let binding: MaktabahNativeSearchContinuationBinding
    var valid = true
    init(requestID: UUID, sceneID: UIStableID, binding: MaktabahNativeSearchContinuationBinding) {
        self.requestID = requestID; self.sceneID = sceneID; self.binding = binding
    }
    func validate() throws { guard valid else { throw CompositionControlError.refused } }
    func retire() { valid = false; binding.retire() }
}

@MainActor final class CompositionScene {
    let sceneID: UIStableID
    var mounted = true
    var foreground = true
    var retained: MaktabahNativeSearchContinuationOwner?
    var last: MaktabahNativeSearchContinuationOwner?
    var retains = 0
    var releases = 0
    var refusesOriginalWindow = false
    var configure: (@MainActor (MaktabahNativeSearchContinuationBinding) -> Void)?
    init(sceneID: UIStableID) { self.sceneID = sceneID }
    func retainSearchContinuation(requestID: UUID, currentSnapshot: @escaping @MainActor () throws -> ActionBackendSnapshot) throws -> MaktabahNativeSearchContinuationOwner {
        guard !refusesOriginalWindow, retained == nil else { throw CompositionControlError.refused }
        let binding = MaktabahNativeSearchContinuationBinding(snapshot: try currentSnapshot(), sceneID: sceneID)
        configure?(binding)
        let owner = MaktabahNativeSearchContinuationOwner(requestID: requestID, sceneID: sceneID, binding: binding)
        retained = owner; last = owner; retains += 1
        return owner
    }
    func validateSearchContinuationOwner(_ owner: MaktabahNativeSearchContinuationOwner) throws {
        guard retained === owner, mounted, foreground else { throw CompositionControlError.refused }
        try owner.validate()
    }
    func releaseSearchContinuation(_ owner: MaktabahNativeSearchContinuationOwner) {
        guard retained === owner else { return }
        owner.retire(); retained = nil; releases += 1
    }
}

@MainActor final class MaktabahNativeRoutingComposition {
    struct Registration {
        let managerID: ObjectIdentifier
        weak var manager: iOSNavigationManager?
        let session: CompositionScene
        let lease: CompositionNavigation.Lease
    }
    let backend = CompositionBackend()
    let authority = CompositionNavigation()
    let core: ActionExecutor
    var scenes: [UIStableID: Registration] = [:]
    var contexts: [UIStableID: ActionExecutionContext] = [:]
    init() throws {
        core = try ActionExecutor(state: backend, resolver: backend, search: backend,
                                  clock: SystemActionClock(), navigationAuthority: authority)
    }
    func install(_ manager: iOSNavigationManager, scene: CompositionScene) {
        scenes[scene.sceneID] = Registration(managerID: ObjectIdentifier(manager), manager: manager,
                                            session: scene, lease: authority.lease)
    }
    func context(sceneID: UIStableID, origin: ActionOrigin, snapshot: ActionBackendSnapshot) -> ActionExecutionContext {
        .init(subjectID: "fixture-scene-owner", origin: origin, allowedBackends: [snapshot.backend],
              scopes: [.navigation, .discovery], foregroundSceneID: sceneID.rawValue)
    }
    func issue(_ context: ActionExecutionContext, sceneID: UIStableID) throws {
        guard contexts[sceneID] == nil else { throw CompositionControlError.refused }
        contexts[sceneID] = context
    }
    func finish(_ context: ActionExecutionContext, sceneID: UIStableID) {
        if contexts[sceneID] == context { contexts.removeValue(forKey: sceneID) }
    }
    func deadline() -> UInt64 {
        let (end, overflow) = SystemActionClock().now().addingReportingOverflow(5_000_000_000)
        return overflow ? UInt64.max : end
    }
}

@MainActor struct CompositionFixture {
    let app: MaktabahNativeRoutingComposition
    let manager = iOSNavigationManager()
    let scene = CompositionScene(sceneID: UIStableID(rawValue: "fixture-original-scene"))
    init() throws { app = try MaktabahNativeRoutingComposition(); app.install(manager, scene: scene) }
    func perform() async throws -> ActionSearchContinuationOutcome {
        try await app.continueOriginalSearch(manager: manager) { observation in
            guard observation.loadedHits.count == 1 else { throw CompositionControlError.invalid }
            return .revealLoadedHit(token: observation.loadedHits[0].token)
        }
    }
    var cleaned: Bool { scene.retained == nil && app.contexts.isEmpty && app.authority.admitted == nil }
}

@main struct SearchCompositionControls {
    @MainActor static func main() async {
        var rows: [[String: Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Bool) async {
            do { rows.append(["name": name, "pass": try await body()]) }
            catch { rows.append(["name": name, "pass": false, "errorType": String(describing: type(of: error))]) }
        }
        await run("one original admission, Core grant, source effect, visible validation and cleanup") {
            let f = try CompositionFixture()
            let result = try await f.perform()
            guard case .acknowledged = result, let b = f.scene.last?.binding else { return false }
            return f.app.authority.admits == 1 && f.app.authority.releases == 1
                && b.observeCount == 1 && b.applyCount == 1 && b.effectCount == 1 && b.validates == 1
                && b.retired && f.cleaned && f.app.backend.providerQueries == 0
        }
        await run("selector backend drift refuses before the original operation") {
            let f = try CompositionFixture()
            do {
                _ = try await f.app.continueOriginalSearch(manager: f.manager) { observation in
                    f.app.backend.value = .init(backend: .otzaria, generation: 8)
                    return .revealLoadedHit(token: observation.loadedHits[0].token)
                }
                return false
            } catch {
                return f.scene.last?.binding.applyCount == 0 && f.scene.last?.binding.effectCount == 0
                    && f.app.authority.admits == 1 && f.app.authority.releases == 1 && f.cleaned
            }
        }
        await run("selector failure releases the original owner and admission") {
            let f = try CompositionFixture()
            do { _ = try await f.app.continueOriginalSearch(manager: f.manager) { _ in throw CompositionControlError.refused }; return false }
            catch { return f.scene.last?.binding.effectCount == 0 && f.scene.releases == 1
                && f.app.authority.releases == 1 && f.cleaned }
        }
        await run("same scene name with replacement Session after await refuses before effect") {
            let f = try CompositionFixture()
            f.scene.configure = { binding in
                binding.beforeEffect = {
                    await Task.yield()
                    f.app.install(f.manager, scene: CompositionScene(sceneID: f.scene.sceneID))
                }
            }
            let result = try await f.perform()
            guard case .refused(let failure) = result else { return false }
            return failure.effects.isEmpty && f.scene.last?.binding.effectCount == 0 && f.cleaned
        }
        await run("authority revoke restore after await cannot reuse the original grant") {
            let f = try CompositionFixture()
            f.scene.configure = { binding in binding.beforeEffect = { await Task.yield(); f.app.authority.revision += 2 } }
            let result = try await f.perform()
            guard case .refused(let failure) = result else { return false }
            return failure.effects.isEmpty && f.scene.last?.binding.effectCount == 0 && f.cleaned
        }
        await run("owner retirement after a real fixture effect preserves that joined effect") {
            let f = try CompositionFixture()
            f.scene.configure = { binding in binding.afterEffect = { f.scene.retained?.valid = false } }
            let result = try await f.perform()
            guard case .refused(let failure) = result else { return false }
            return failure.effects.count == 1 && f.scene.last?.binding.effectCount == 1 && f.cleaned
        }
        await run("late authority revision keeps an exactly joined partial refusal") {
            let f = try CompositionFixture()
            f.scene.configure = { binding in
                binding.afterEffect = { f.app.authority.revision += 1 }
                binding.response = { command, receipt in .refused(.init(requestID: command.invocation.requestId,
                    reason: .providerFailed, effects: receipt.effects, source: command.source, operation: command.operation)) }
            }
            let result = try await f.perform()
            guard case .refused(let failure) = result else { return false }
            return failure.effects.count == 1 && f.scene.last?.binding.effectCount == 1 && f.cleaned
        }
        await run("foreign completion remains raw unqualified evidence with its original effect") {
            let f = try CompositionFixture()
            f.scene.configure = { binding in binding.response = { command, receipt in
                .acknowledged(.init(requestID: UUID(), before: receipt.before, after: receipt.after,
                    operation: receipt.operation, effects: receipt.effects, visible: receipt.visible))
            } }
            let result = try await f.perform()
            guard case .unqualified(_, let original) = result else { return false }
            return original == f.scene.last?.binding.actualReturned && f.scene.last?.binding.effectCount == 1 && f.cleaned
        }
        await run("nested unqualified response survives the outer entry without normalization") {
            let f = try CompositionFixture()
            f.scene.configure = { binding in binding.response = { command, receipt in
                .unqualified(command: command, originalResponse: .unqualified(command: command, originalResponse: .acknowledged(receipt)))
            } }
            let result = try await f.perform()
            guard case .unqualified(_, let original) = result else { return false }
            return original == f.scene.last?.binding.actualReturned && f.cleaned
        }
        await run("an already busy scene refuses without another retention or admission") {
            let f = try CompositionFixture()
            f.app.contexts[f.scene.sceneID] = f.app.context(sceneID: f.scene.sceneID, origin: .inApp, snapshot: f.app.backend.value)
            do { _ = try await f.perform(); return false }
            catch { return f.scene.retains == 0 && f.app.authority.admits == 0 && f.app.contexts.count == 1 }
        }
        await run("missing original window refuses before context or grant") {
            let f = try CompositionFixture(); f.scene.refusesOriginalWindow = true
            do { _ = try await f.perform(); return false }
            catch { return f.scene.retains == 0 && f.app.authority.admits == 0 && f.cleaned }
        }
        await run("actual cancelled task refuses before original retention") {
            let f = try CompositionFixture()
            let task = Task { @MainActor in
                do { _ = try await f.perform(); return false }
                catch is CancellationError { return true }
                catch { return false }
            }
            task.cancel()
            let refused = await task.value
            return refused && f.scene.retains == 0 && f.app.authority.admits == 0 && f.cleaned
        }
        let passed = rows.filter { $0["pass"] as? Bool == true }.count
        let report: [String: Any] = ["scope": "Exact production Composition entry, actual Core and Host continuation service; explicit app/domain fixture boundaries",
            "passed": passed, "failed": rows.count - passed, "cases": rows,
            "UIKit": "NOT_RUN", "nativeOperations": 0, "providerQueries": 0, "AppleSDK": "NOT_RUN"]
        print(String(decoding: try! JSONSerialization.data(withJSONObject: report, options: [.sortedKeys]), as: UTF8.self))
        if passed != rows.count { exit(1) }
    }
}
