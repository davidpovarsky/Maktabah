from pathlib import Path
import hashlib
import json

root = Path('/workspace/scratch/c1c70cc48453/search-continuation-integration')
relative = Path('Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift')
original = (root / 'baseline' / relative).read_bytes()
assert hashlib.sha256(original).hexdigest() == '4efcc3994a1cd5bf63a2b5c410e77fe0763818ff6b2f001973ec51bd88062573'

methods = '''    /// Metadata is taken from the original mounted scene and its current
    /// committed library. Discovery cannot switch a profile, group or backend.
    private func workspaceSelectionIntentEntities() throws -> [NativeWorkspaceSelectionIntentService.Selection] {
        try Task.checkCancellation()
        let snapshot = try backend.currentBackendSnapshot()
        var values: [NativeWorkspaceSelectionIntentService.Selection] = []
        for (_, entry) in scenes.sorted(by: { $0.key.rawValue < $1.key.rawValue }) where entry.session.mounted {
            values += try entry.session.workspaceSelectionCatalog(
                windowTitle: entry.session.windowLabel(number: entry.windowNumber))
        }
        try Task.checkCancellation()
        guard try backend.currentBackendSnapshot() == snapshot,
              values.allSatisfy({ $0.backend == snapshot.backend }) else {
            throw UIRouteError(.staleState, "intent_source_generation_changed")
        }
        return values
    }

    /// Retain the exact original selection before activation. Original staging,
    /// Core authorization and native publication share this one fixed deadline.
    private func openWorkspaceSelectionIntent(_ target: NativeWorkspaceSelectionIntentService.Selection,
                                             requestID: UUID) async throws -> UISceneAcknowledgement {
        try Task.checkCancellation()
        let snapshot = try backend.currentBackendSnapshot()
        guard target.backend == snapshot.backend, let entry = scenes[target.sceneID],
              entry.session.mounted, let manager = entry.manager,
              entry.managerID == ObjectIdentifier(manager), contexts[target.sceneID] == nil else {
            throw UIRouteError(.staleState, "intent_window_no_longer_available")
        }
        let bound = try entry.session.retainWorkspaceSelection(target, requestID: requestID)
        defer { entry.session.releaseWorkspaceSelection(bound) }
        let end = deadline()
        func validateSource(context expectedContext: ActionExecutionContext?) throws {
            try Task.checkCancellation()
            guard DispatchTime.now().uptimeNanoseconds < end else {
                throw UIRouteError(.cancelled, "deadline_exceeded")
            }
            guard let current = scenes[target.sceneID], current.managerID == entry.managerID,
                  current.manager === manager, current.session === entry.session,
                  current.session.mounted, current.session.foreground,
                  contexts[target.sceneID] == expectedContext,
                  try backend.currentBackendSnapshot() == snapshot else {
                throw UIRouteError(.staleState, "intent_window_changed_during_activation")
            }
            try bound.validate()
        }
        let mountedScene = try await NativeObservationDeadline.run(until: end, clock: SystemActionClock()) { [self] in
            try await waitForMount(managerID: entry.managerID)
        }
        guard mountedScene == target.sceneID else {
            throw UIRouteError(.staleState, "intent_window_changed_during_activation")
        }
        try validateSource(context: nil)
        try entry.session.reserveWorkspaceSelection(bound)
        try validateSource(context: nil)
        // Use the retained record and the original owners to stage/reuse its
        // readers. A later first-group lookup would silently retarget the intent.
        try await NativeObservationDeadline.run(until: end, clock: SystemActionClock()) { @MainActor in
            try await entry.session.prepareWorkspaceSelection(bound) {
                try validateSource(context: nil)
            }
        }
        try validateSource(context: nil)
        let context = context(sceneID: target.sceneID, origin: .appIntent, snapshot: snapshot)
        try issue(context, sceneID: target.sceneID)
        defer { finish(context, sceneID: target.sceneID) }
        let invocation = ActionPortInvocation(requestId: requestID, snapshot: snapshot,
                                             deadlineUptimeNanoseconds: end)
        let scene = try await directory.currentScene(sceneID: target.sceneID, context: context, invocation: invocation)
        try validateSource(context: context)
        let route = try entry.session.prepareWorkspaceSelectionRoute(bound, invocation: invocation, scene: scene)
        let command = try UISceneCommand(route: registry.validate(route), invocation: invocation, scene: scene)
        let result = try await orchestrator.commit(command, context: context)
        if case .acknowledged(let receipt) = result {
            do {
                try validateSource(context: context)
                try entry.session.validateWorkspaceSelectionCompletion(bound, receipt: receipt)
                try validateSource(context: context)
            } catch {
                throw NativeWorkspaceSelectionIntentService.Failure(receipt: receipt, code: "native_effect_uncertain")
            }
        }
        record(result)
        return result
    }

'''

registration = '''        let workspaceSelectionService = NativeWorkspaceSelectionIntentService(discover: { [self] in
            do { return try workspaceSelectionIntentEntities() }
            catch { logIntentFailure(error, stage: "workspace_selection_metadata"); throw error }
        }, navigate: { [self] target, requestID in
            do { return try await openWorkspaceSelectionIntent(target, requestID: requestID) }
            catch { logIntentFailure(error, stage: "workspace_selection_navigation"); throw error }
        })
        AppDependencyManager.shared.add(dependency: workspaceSelectionService)
'''

descriptor = '''            .init(id: NativeWorkspaceSelectionIntentService.destination,
                  title: workspaceText("Study workspace selection", "בחירת סביבת לימוד"), implementation: .implemented,
                  supportedBackends: ActionBackendID.allCases, presentations: [.currentTab], requiredCoreActions: []),
'''

text = original.decode()
anchor = '    func installIntentDependency() {\n'
assert text.count(anchor) == 1
text = text.replace(anchor, methods + anchor, 1)
anchor2 = '        AppDependencyManager.shared.add(dependency: tabService)\n'
assert text.count(anchor2) == 1
text = text.replace(anchor2, anchor2 + registration, 1)
anchor3 = '            .init(id: NativeReaderTabIntentService.destination, title: "Reader tab".localized, implementation: .implemented,\n'
assert text.count(anchor3) == 1
text = text.replace(anchor3, descriptor + anchor3, 1)
assert text.replace(methods, '', 1).replace(registration, '', 1).replace(descriptor, '', 1).encode() == original
target = root / 'candidate' / relative
target.parent.mkdir(parents=True, exist_ok=True)
assert hashlib.sha256(target.read_bytes()).hexdigest() == '4b75088977b9b0ca0843dab9e1f7ebd667f0670cf3a41044dadcd26c316ae43e'
prior = root / 'review' / 'workspace-composition-candidate1.swift'
prior.parent.mkdir(parents=True, exist_ok=True)
assert not prior.exists()
prior.write_bytes(target.read_bytes())
target.write_text(text)
result = {
    'baselineBytes': len(original),
    'baselineSHA256': hashlib.sha256(original).hexdigest(),
    'candidateBytes': len(text.encode()),
    'candidateSHA256': hashlib.sha256(text.encode()).hexdigest(),
    'onlyThreeExactAdditions': True,
    'privateDescriptorHasNoPublicNavigationVariant': True,
    'stageClosureExplicitMainActor': True,
    'source': str(target),
    'compile': 'NOT_RUN',
    'native': 'NOT_RUN',
}
(root / 'WORKSPACE_COMPOSITION_DRAFT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
