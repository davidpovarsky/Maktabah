    /// Continue one already visible ORIGINAL search under one fixed deadline.
    /// The selector sees metadata only; it cannot supply a query or an offset.
    /// Retain the actual scene/window/list before the first await, then consume
    /// Core authority and the original source token for the same operation.
    func continueOriginalSearch(manager: iOSNavigationManager,
        choose: @MainActor (ActionSearchContinuationObservation) throws -> ActionSearchContinuationOperation
    ) async throws -> ActionSearchContinuationOutcome {
        try Task.checkCancellation()
        let end = deadline(), requestID = UUID(), managerID = ObjectIdentifier(manager)
        let matches = scenes.filter { $0.value.managerID == managerID }
        guard matches.count == 1, let (sceneID, entry) = matches.first,
              entry.manager === manager, entry.session.mounted, entry.session.foreground,
              contexts[sceneID] == nil else {
            throw UIRouteError(.unavailable, "native_search_continuation_scene_unavailable")
        }
        let snapshot = try backend.currentBackendSnapshot()
        let owner = try entry.session.retainSearchContinuation(requestID: requestID,
            currentSnapshot: { [self] in try backend.currentBackendSnapshot() })
        defer { entry.session.releaseSearchContinuation(owner) }
        let context = context(sceneID: sceneID, origin: .inApp, snapshot: snapshot)
        try issue(context, sceneID: sceneID)
        defer { finish(context, sceneID: sceneID) }
        let invocation = ActionPortInvocation(requestId: requestID, snapshot: snapshot,
                                             deadlineUptimeNanoseconds: end)
        // This is the same original authority captured BEFORE observation. It
        // only proves freshness; it is never consumed as an operation grant.
        let observationAuthority = try core.prepareNavigationSynchronously(sceneID: sceneID.rawValue,
            invocation: invocation, context: context)
        let check: NativeSearchContinuationService.Check = { [weak self, weak manager, weak owner] in
            try Task.checkCancellation()
            guard let self, let manager, let owner,
                  SystemActionClock().now() < end,
                  let current = self.scenes[sceneID], current.session === entry.session,
                  current.manager === manager, current.managerID == managerID,
                  current.session.mounted, current.session.foreground,
                  self.contexts[sceneID] == context,
                  owner.requestID == requestID, owner.sceneID == sceneID,
                  try self.backend.currentBackendSnapshot() == snapshot else {
                throw UIRouteError(.staleState, "native_search_continuation_lifetime_changed")
            }
            try current.session.validateSearchContinuationOwner(owner)
            try observationAuthority.validateFreshness()
            try current.session.validateSearchContinuationOwner(owner)
        }
        var retainedCommand: ActionSearchContinuationCommand?
        var grant: ActionSearchContinuationAuthority?
        defer { grant?.retire() }
        func refuse(_ command: ActionSearchContinuationCommand, _ error: any Error) -> ActionSearchContinuationOutcome {
            let reason: ActionSearchContinuationRefusal = error is CancellationError ? .cancelled
                : (SystemActionClock().now() >= end ? .deadlineExceeded : .staleSource)
            return .refused(.init(requestID: command.invocation.requestId, reason: reason, effects: [],
                                  source: command.source, operation: command.operation))
        }
        let service = NativeSearchContinuationService(observe: { scene, value in
            guard Data(scene.utf8) == Data(sceneID.rawValue.utf8), value == invocation else {
                throw ActionPortError.staleState
            }
            return try owner.binding.observe(invocation: value, retainAuthority: { check })
        }, apply: { command, serviceAuthority in
            guard retainedCommand == command, let grant else {
                return refuse(command, ActionPortError.staleState)
            }
            do {
                try check()
                try grant.authorizeOriginalOperation(command)
                try serviceAuthority()
                try grant.validateExecution(for: command)
            } catch { return refuse(command, error) }
            // The original binding consumes its own source token and uses this
            // SAME live callback before each mutation and after every await.
            return await owner.binding.perform(command, validateAuthority: {
                try serviceAuthority()
                try grant.validateExecution(for: command)
                try check()
            })
        }, validate: { command, receipt in
            guard retainedCommand == command, let grant else { throw ActionPortError.staleState }
            try grant.validateCompletion(for: command)
            try owner.binding.validateCompletion(command, receipt: receipt)
            try check()
        }, authority: { scene, value in
            guard Data(scene.utf8) == Data(sceneID.rawValue.utf8), value == invocation else {
                throw ActionPortError.staleState
            }
            try check()
            if let command = retainedCommand, let grant { try grant.validateFreshness(for: command) }
        })
        let observation = try service.observe(in: sceneID.rawValue, invocation: invocation)
        let operation = try choose(observation)
        try check()
        let command = ActionSearchContinuationCommand(source: observation.source,
            operation: operation, invocation: invocation)
        retainedCommand = command
        grant = try core.prepareSearchContinuationSynchronously(command, context: context)
        try check()
        // Service joins the exact response BEFORE late validation, preserving
        // actual partial effects and raw unqualified responses. No outer timeout
        // or post-effect throwing check may discard that evidence here.
        return await service.continueSearch(command)
    }

