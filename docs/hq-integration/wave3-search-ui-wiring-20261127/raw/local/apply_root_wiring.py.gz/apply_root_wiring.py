import base64
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE = 'd3dae76f6476836755a562756c3b374ef0c0e00e'
BRANCH = 'codex/otzaria-wave3-integration-20261127'
DOCREL = 'docs/hq-integration/wave3-search-ui-wiring-20261127'
DOC = ROOT / DOCREL
RUN = ROOT / '.git/root-search-ui-wiring-20261127'
FLOOR = 1342177280
sha = lambda b: hashlib.sha256(b).hexdigest()
assert os.geteuid() != 0
assert not RUN.exists()
RUN.mkdir()
events = []

def execute(args, allowed=(0,), timeout=60):
    p = subprocess.run(args, cwd=ROOT, capture_output=True, timeout=timeout)
    record = {'argv': args, 'returncode': p.returncode, 'stdout': p.stdout.decode(errors='replace'), 'stderr': p.stderr.decode(errors='replace')}
    events.append(record)
    (RUN / 'EVENTS.json').write_text(json.dumps(events, indent=2) + '\n')
    if p.returncode not in allowed:
        raise RuntimeError(json.dumps(record))
    return p.stdout.decode().strip()

def git(*args, **kwargs):
    return execute(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', *args], **kwargs)

def identity_commit(message):
    return git('-c', 'user.name=ChatGPT', '-c', 'user.email=chatgpt-agent@users.noreply.github.com', 'commit', '-m', message)

def remote_head():
    value = git('-c', 'credential.helper=!gh auth git-credential', 'ls-remote', 'origin', 'refs/heads/' + BRANCH)
    fields = value.split()
    assert len(fields) == 2 and fields[1] == 'refs/heads/' + BRANCH
    return fields[0]

def blob(path):
    data = (ROOT / path).read_bytes()
    return {'path': path, 'bytes': len(data), 'sha256': sha(data)}

def safe(relative):
    p = Path(relative)
    assert not p.is_absolute() and relative and '..' not in p.parts
    return p

def raw_evidence(relative, data, index):
    target = DOC / 'raw' / (str(safe(relative)) + '.gz')
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, mtime=0)
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == data
    index.append({'path': str(target.relative_to(DOC)), 'bytes': len(packed), 'sha256': sha(packed), 'rawBytes': len(data), 'rawSHA256': sha(data)})

try:
    packed = base64.b64decode(sys.stdin.read(), validate=True)
    assert len(packed) <= 2097152
    raw = gzip.decompress(packed)
    assert len(raw) <= 12582912
    packet = json.loads(raw)
    assert packet['base'] == BASE and len(packet['products']) == 11
    assert git('rev-parse', 'HEAD') == BASE
    assert git('branch', '--show-current') == BRANCH
    assert git('status', '--porcelain=v1') == ''
    assert git('rev-parse', 'HEAD:Source') == 'f42718fcbbaa6780556640f58888f1abebb35ba9'
    vendor = git('rev-parse', 'HEAD:Vendor')
    assert vendor == '9e4f188c5bedeef55ce95d97943f5e5046b6f3d6'
    assert remote_head() == BASE
    assert not DOC.exists()
    assert shutil.disk_usage(ROOT).free >= FLOOR
    for name in ['CHERRY_PICK_HEAD', 'MERGE_HEAD', 'REVERT_HEAD', 'index.lock']:
        assert not (ROOT / '.git' / name).exists(), name
    hooks = git('config', '--show-origin', '--get-regexp', r'^(core\.hooksPath|commit\.gpgsign|gpg\.format|user\.signingkey)$', allowed=(0, 1))
    checked = []
    products = {}
    for row in packet['products']:
        relative = str(safe(row['path']))
        assert relative not in products
        data = base64.b64decode(row['base64'], validate=True)
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        path = ROOT / relative
        assert not path.is_symlink()
        if row['beforeSHA256'] is None:
            assert not path.exists()
            assert git('ls-files', '--', relative) == ''
            before = None
        else:
            before = blob(relative)
            assert before['sha256'] == row['beforeSHA256'], before
            assert git('ls-files', '--', relative) == relative
        checked.append({k: v for k, v in row.items() if k != 'base64'})
        products[relative] = data
    preserved = [blob('Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'), blob('Source/UI/iOS/Managers/iOSNavigationManager.swift')]
    assert preserved[0]['bytes'] == 259080 and preserved[0]['sha256'] == '7f735919df764571929bb858dd21e082c7a52b68d01b9e15b65aa738284ee4ad'
    assert preserved[1]['sha256'] == '2163d9d51b40423a5130b0d9b97e4a063af12c6fb3f1e1ec6b0dc40b753b24a2'
    evidence_rows = []
    # All expected hashes and actual control receipts are checked before product writes.
    controls = [
        ('authority', 'search-continuation-authority-controls-20261127', '744fffb46a384b13c62a191df52e670af7c7e02a81efcddebe18cf49c03c8b34'),
        ('integrated', 'search-continuation-integrated-controls-20261127', 'adade63bed54c1b527e41d0d68f81ac652c6916d878235d82081c20f0f942d96'),
    ]
    for label, directory, result_sha in controls:
        assert sha((ROOT / '.git' / directory / 'RESULT.json').read_bytes()) == result_sha
    DOC.mkdir(parents=True)
    (RUN / 'INPUT_PACKET.json.gz').write_bytes(packed)
    for row in packet['evidence']:
        data = base64.b64decode(row['base64'], validate=True)
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        raw_evidence('local/' + row['path'], data, evidence_rows)
    control_artifacts = []
    for label, directory, _ in controls:
        origin = ROOT / '.git' / directory
        for path in sorted(origin.rglob('*')):
            if not path.is_file():
                continue
            assert not path.is_symlink()
            relative = path.relative_to(origin)
            if relative.parts[0] == 'module-cache':
                continue
            data = path.read_bytes()
            assert len(data) <= 33554432
            record = {'root': str(origin), 'path': str(relative), 'bytes': len(data), 'sha256': sha(data), 'preservedInOriginalRoot': True}
            if len(relative.parts) == 1 or relative.parts[0] == 'inputs' or '.bundle' in str(relative):
                raw_evidence('controls/' + label + '/' + str(relative), data, evidence_rows)
                record['copiedLosslesslyIntoCommit'] = True
            else:
                record['copiedLosslesslyIntoCommit'] = False
            control_artifacts.append(record)
    (DOC / 'CONTROL_ARTIFACTS.json').write_text(json.dumps(control_artifacts, indent=2) + '\n')
    plan = {'schema': packet['schema'], 'base': BASE, 'products': checked, 'payloadGzipBytes': len(packed), 'payloadGzipSHA256': sha(packed), 'payloadRawSHA256': sha(raw), 'inheritedHookAndSigningConfiguration': hooks, 'preserved': preserved, 'coreControls': '24/24 actual Core; integrated Core 24/24 and Composition/service 12/12', 'AppleSDKTypecheck': 'NOT_RUN', 'nativeUI': 'NOT_RUN', 'physical': 'NOT_RUN'}
    (DOC / 'PLAN.json').write_text(json.dumps(plan, indent=2) + '\n')
    (DOC / 'ARTIFACTS.json').write_text(json.dumps(evidence_rows, indent=2) + '\n')
    (DOC / 'README.md').write_text('''# Original Search continuation and shared UI wiring

This is an exact, scoped integration on d3dae76f. It retains the original Search source, page ledger, Core policy, application service and native binding. A single source-bound Core grant is consumed before the original source claim. The original Scene, UIWindow and source observations remain required across suspension; the original Notes setter retires the Search owner synchronously and existing workspace revision observation closes the reviewed ABA gap. Actual effects and unqualified responses are retained without normalization.

The five explicit Session conflicts combine the original Viewer and Profile/Group owners; the raw merge and every resolution are stored losslessly. Seven existing/new app sources are registered only in the original iOS target, with no changes to other targets. Two Profile/Group App Shortcuts and Hebrew/English strings are added while preserving all four previous shortcut definitions and every previous catalog entry.

Actual Linux Swift compilation used the real Core and real application service; 24 authority controls and 12 exact Composition-entry controls passed. Application-domain fixtures surrounding the extracted entry are explicit. Earlier grant-only controls, compiler warnings, raw draft failures, source peer review and all exact inputs are preserved. These results do not establish Apple SDK typechecking, UIKit runtime behavior, native App Intents extraction, provider execution, production acceptance, owner-signature qualification or physical testing. Those gates remain open. Native Search selectors and the narrow active-but-hidden phone Reader follow-up are separate work.

ARTIFACTS.json indexes every lossless gzip evidence member. CONTROL_ARTIFACTS.json also identifies retained compiler outputs in their untouched original private roots. No root, donor or foreign worktree was reset or cleaned. No hooks, signing rules, tests or owner signatures were changed by this integration.
''')
    for relative, data in products.items():
        path = ROOT / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        assert path.read_bytes() == data
    assert shutil.disk_usage(ROOT).free >= FLOOR
    for row in preserved:
        assert blob(row['path']) == row
    git('diff', '--check', '--', *products)
    git('add', '--sparse', '--', *products)
    staged = git('diff', '--cached', '--name-only').splitlines()
    assert set(staged) == set(products), staged
    identity_commit('fix(ios): wire original search continuation and native workspace sources')
    source_commit = git('rev-parse', 'HEAD')
    assert git('rev-parse', 'HEAD^') == BASE
    assert git('rev-parse', 'HEAD:Vendor') == vendor
    for row in checked:
        assert blob(row['path'])['sha256'] == row['sha256']
    result = {'schema': 'otzaria.wave3.root-search-ui-wiring-result.v1', 'completedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'base': BASE, 'sourceCommit': source_commit, 'sourceTree': git('rev-parse', 'HEAD:Source'), 'vendorTree': vendor, 'productFiles': len(products), 'evidenceMembers': len(evidence_rows), 'planSHA256': sha((DOC / 'PLAN.json').read_bytes()), 'artifactIndexSHA256': sha((DOC / 'ARTIFACTS.json').read_bytes()), 'preserved': preserved, 'actualCoreControls': {'passed': 24, 'failed': 0}, 'actualCompositionWithDomainFixtures': {'passed': 12, 'failed': 0}, 'AppleSDK': 'NOT_RUN', 'nativeUI': 'NOT_RUN', 'physical': 'NOT_RUN'}
    (DOC / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    git('add', '--sparse', '--', DOCREL)
    staged_docs = git('diff', '--cached', '--name-only').splitlines()
    assert staged_docs and all(p.startswith(DOCREL + '/') for p in staged_docs)
    git('diff', '--cached', '--check')
    identity_commit('docs: preserve exact search and shared UI integration evidence')
    final = git('rev-parse', 'HEAD')
    assert git('status', '--porcelain=v1') == ''
    assert git('rev-parse', 'HEAD:Source') == result['sourceTree']
    assert git('rev-parse', 'HEAD:Vendor') == vendor
    assert remote_head() == BASE
    git('-c', 'remote.origin.mirror=false', '-c', 'credential.helper=!gh auth git-credential', 'push', 'origin', 'HEAD:refs/heads/' + BRANCH, timeout=120)
    assert remote_head() == final
    terminal = {**result, 'finalCommit': final, 'remoteVerified': final, 'gitStatus': git('status', '--porcelain=v1'), 'resultSHA256': sha((DOC / 'RESULT.json').read_bytes()), 'freeBytes': shutil.disk_usage(ROOT).free, 'floorBytes': FLOOR}
    (RUN / 'RESULT.json').write_text(json.dumps(terminal, indent=2) + '\n')
    print(json.dumps(terminal))
except BaseException as exc:
    failure = {'failedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'type': type(exc).__name__, 'message': str(exc), 'events': events}
    (RUN / 'FAILURE.json').write_text(json.dumps(failure, indent=2) + '\n')
    print(json.dumps(failure))
    raise
