from pathlib import Path
import base64
import gzip
import hashlib
import json

root = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
rows = json.loads((root / 'review/ROOT_WIRING_FILES.json').read_bytes())
old = {
    'Maktabah.xcodeproj/project.pbxproj': 'ab245c2c715d8ee7cb4550f1a6d9d7b26f3955c53faf3bfc295f35cb5b547f43',
    'Source/ChavrusaText/UIRoutingHost/Integration/AppShortcuts.xcstrings': '4951cfaa279a13dd49649babc42587625f3668da2fc54ca3785e7a6f4066741c',
    'Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift': '23404297c83bce209dc710e0ffb22e28d767d224c37ca4ae602eb84aad5836a4',
    'Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeReaderTabBinding.swift': '6726090835fe13b01172014bb5b08dc6bc2ed647e5d4ae9b587360138c9707fa',
    'Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift': '4efcc3994a1cd5bf63a2b5c410e77fe0763818ff6b2f001973ec51bd88062573',
    'Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift': '4853b04ebbdf3ea531ac73175edc38a65871b7cc289a83dca2ec73d8dbf08a1b',
    'Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSearchContinuation.swift': '2d39de55348df1520fd4d8317440ca35e19eedb09b7f28376e3a944a4762fd50',
    'Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSearchContinuationOwner.swift': None,
    'Source/Localizable.xcstrings': '4dc4752b9037289c0c07c30fbb32c05de8a86feb073a6265c9a68c5ed6d0da5c',
    'Source/Otzaria/Actions/Sources/OtzariaActionCore/Engine/ActionExecutor.swift': 'f0d698e6be0c988fc67bf6fe0f786cd3ee46243cc10255b1a022c5100d9977f6',
    'Source/Otzaria/Actions/Sources/OtzariaActionCore/Ports/ActionSearchContinuationAuthority.swift': None,
}
assert len(rows) == 11 and {x['path'] for x in rows} == set(old)
products = []
for row in rows:
    data = (root / 'candidate' / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    products.append({**row, 'beforeSHA256': old[row['path']], 'base64': base64.b64encode(data).decode()})
evidence_paths = sorted(set(
    list((root / 'review').glob('*')) + list((root / 'controls').glob('*')) +
    list(root.glob('*.json')) + [root / 'wire_ui_membership.py', root / 'wire_workspace_selection.py', root / 'ui-baseline/verify_source_registration.py', root / 'prepare_root_wiring_packet.py', root / 'apply_root_wiring.py']
))
evidence = []
for path in evidence_paths:
    if not path.is_file():
        continue
    data = path.read_bytes()
    evidence.append({'path': str(path.relative_to(root)), 'bytes': len(data), 'sha256': sha(data), 'base64': base64.b64encode(data).decode()})
packet = {'schema': 'otzaria.wave3.root-search-ui-wiring-input.v1', 'base': 'd3dae76f6476836755a562756c3b374ef0c0e00e', 'products': products, 'evidence': evidence}
raw = json.dumps(packet, ensure_ascii=False, separators=(',', ':')).encode()
packed = gzip.compress(raw, mtime=0)
(root / 'ROOT_WIRING_PACKET.json.gz').write_bytes(packed)
(root / 'ROOT_WIRING_PACKET.b64').write_text(base64.b64encode(packed).decode())
summary = {'products': len(products), 'evidence': len(evidence), 'rawBytes': len(raw), 'rawSHA256': sha(raw), 'gzipBytes': len(packed), 'gzipSHA256': sha(packed)}
(root / 'ROOT_WIRING_PACKET_META.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
