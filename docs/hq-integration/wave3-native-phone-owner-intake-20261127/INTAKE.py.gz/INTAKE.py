import gzip, hashlib, io, json, os, pathlib, re, shutil, subprocess, sys, time, zipfile

ROOT = pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE = 'c443964ddeaa4716dc5f4c04fa374b0072914e83'
BRANCH = 'codex/otzaria-wave3-integration-20261127'
NAV_REPO = '/home/ubuntu/.codex/worktrees/Maktabah-wave3-hidden-phone-reader-native-20261127'
NAV_SOURCE = '9e28e2a10c1906e3eca8c0cf355b199a3676435d'
NAV_DOCS = '87315a4c16198220ac181181477606d03ad7e79a'
NAV_DIR = 'docs/hq-ui-inventory/wave3-hidden-phone-reader-native-20261127'
OWNER_REPO = '/mnt/development/projects/worktrees/Maktabah-wave3-fresh-sdk-preservation-20261127'
OWNER_DOCS = 'dcd8f369c5493f783449a1dffe1e827a409b3d7a'
OWNER_DIR = 'docs/hq-integration/wave3-final-owner-preflight-20261127'
PROOF = ROOT / 'docs/hq-integration/wave3-native-phone-owner-intake-20261127'
RUN = pathlib.Path(__file__).parent
HELPER = 'Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
TEST = 'Maktabah-iOSUITests/NativeHiddenActivePhoneReaderTabAcceptanceTests.swift'
events = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    argv = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-C', str(ROOT), *args]
    started = time.time()
    p = subprocess.run(argv, capture_output=True)
    events.append({'argv': argv, 'exit': p.returncode, 'seconds': time.time()-started,
                   'stdout': p.stdout.decode(errors='replace'), 'stderr': p.stderr.decode(errors='replace')})
    dump(RUN/'EVENTS.json', events)
    if p.returncode:
        raise RuntimeError('git command failed: ' + repr(args) + '\n' + p.stderr.decode(errors='replace'))
    return p.stdout

def show(commit, path):
    return git('show', commit + ':' + path)

def check(data, size, digest):
    assert len(data) == size, (len(data), size)
    assert sha(data) == digest, (sha(data), digest)

def names(commit, *paths):
    return git('ls-tree', '-r', '--name-only', commit, '--', *paths).decode().splitlines()

def changes(commit):
    return git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines()

def pick(commit):
    git('-c', 'user.name=ChatGPT', '-c', 'user.email=chatgpt-agent@users.noreply.github.com',
        'cherry-pick', '-x', commit)
    return git('rev-parse', 'HEAD').decode().strip()

try:
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert git('symbolic-ref', '--short', 'HEAD').decode().strip() == BRANCH
    assert not git('status', '--porcelain')
    assert shutil.disk_usage(ROOT).free >= 1342177280
    remote_args = ['-c', 'credential.helper=!gh auth git-credential', 'ls-remote', 'origin', 'refs/heads/'+BRANCH]
    assert git(*remote_args).decode().split()[0] == BASE
    initial_trees = {p:git('rev-parse', BASE+':'+p).decode().strip() for p in ['Source','Vendor','Maktabah.xcodeproj']}
    assert initial_trees['Source'] == '1e36b8942c4f43e551f5b1eb814139fac651e56b'
    current = (ROOT/HELPER).read_bytes()
    check(current,259040,'6fb46c9fc02d8abdd29a6926490f231a4cb891948ecd6d5a44d369b3832893f8')
    git('fetch','--no-tags','--no-write-fetch-head',NAV_REPO,NAV_SOURCE,NAV_DOCS)
    git('fetch','--no-tags','--no-write-fetch-head',OWNER_REPO,OWNER_DOCS)
    source_docs = {NAV_DIR+'/'+p for p in ['APPEND_ONLY_HELPER.patch','NATIVE_HELPER_ADDITION.swift','SOURCE_INPUTS.json']}
    assert set(changes(NAV_SOURCE)) == {TEST} | source_docs
    assert set(changes(NAV_DOCS)) == set(names(NAV_DOCS,NAV_DIR)) - source_docs
    for path in source_docs:
        assert show(NAV_SOURCE,path) == show(NAV_DOCS,path)
    assert set(changes(OWNER_DOCS)) == set(names(OWNER_DOCS,OWNER_DIR))
    verified = []
    for commit, directory, pin in [(NAV_DOCS,NAV_DIR,'14c6d0a2eca0dd93b37bc27c3396f27d09ce7dad5752a02d6458984973217902'),
                                    (OWNER_DOCS,OWNER_DIR,'a6ec44b5467281a90a6edeae8c9ebfcbc4f7575afef6ec3206ffa7d32cabb026')]:
        raw = show(commit,directory+'/MANIFEST.json')
        assert sha(raw) == pin
        manifest = json.loads(raw)
        assert len({r['path'] for r in manifest['files']}) == len(manifest['files'])
        assert set(names(commit,directory)) == {directory+'/MANIFEST.json'} | {directory+'/'+r['path'] for r in manifest['files']}
        for row in manifest['files']:
            blob = show(commit,directory+'/'+row['path'])
            check(blob,row['bytes'],row['sha256'])
            verified.append({'commit':commit,'path':directory+'/'+row['path'],**{k:row[k] for k in ['bytes','sha256']}})
    raw_index=json.loads(show(NAV_DOCS,NAV_DIR+'/RAW_INPUTS.json'))
    archive=zipfile.ZipFile(io.BytesIO(show(NAV_DOCS,NAV_DIR+'/EVIDENCE.zip')))
    assert len(set(archive.namelist())) == len(archive.namelist())
    assert set(archive.namelist()) == {'RAW_INPUTS.json'} | {r['path'] for r in raw_index['files']}
    assert archive.read('RAW_INPUTS.json') == show(NAV_DOCS,NAV_DIR+'/RAW_INPUTS.json')
    for row in raw_index['files']:
        check(archive.read(row['path']),row['bytes'],row['sha256'])
    suffix=show(NAV_DOCS,NAV_DIR+'/NATIVE_HELPER_ADDITION.swift')
    check(suffix,13144,'25e48b7aec434f0e279ba03dcccaa3171310209d5da03ab0706bca1e6a66fc9a')
    frozen=show('7fbe04c6eef8c072d6a9ff9c0e6c78791b3db97b',HELPER)
    check(frozen,259080,'7f735919df764571929bb858dd21e082c7a52b68d01b9e15b65aa738284ee4ad')
    assert archive.read('candidate/'+HELPER) == frozen+suffix
    check(show(NAV_SOURCE,TEST),1511,'df2a74beaee99eadd112613a7eca19f75eb68280660d802bb58b24e25fb1871b')
    actual_receipt=pathlib.Path(NAV_REPO)/'build/hidden-phone-reader-native-20261127/attempt-1/RESULT.json'
    assert actual_receipt.read_bytes() == show(NAV_DOCS,NAV_DIR+'/evidence/attempt-1/RESULT.json')
    assert json.loads(actual_receipt.read_bytes())['exit'] == 0
    mappings=[]
    for donor in [NAV_SOURCE,NAV_DOCS,OWNER_DOCS]:
        mappings.append({'donor':donor,'integrated':pick(donor)})
    assert (ROOT/HELPER).read_bytes() == current
    combined=current+suffix
    assert combined[:len(current)] == current
    assert combined[len(current):] == suffix
    (ROOT/HELPER).write_bytes(combined)
    assert git('diff','--name-only').decode().splitlines() == [HELPER]
    PROOF.mkdir(parents=True,exist_ok=False)
    failed_run=pathlib.Path('/home/ubuntu/.codex/diagnostics/otzaria-wave3-native-phone-owner-intake-20261127')
    (PROOF/'initial-intake-failure').mkdir()
    for name in ['RUN.py','EVENTS.json','FAILURE.json']:
        (PROOF/'initial-intake-failure'/(name+'.gz')).write_bytes(gzip.compress((failed_run/name).read_bytes(),mtime=0))
    dump(PROOF/'VERIFIED_FILES.json',verified)
    (PROOF/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
    (PROOF/'CURRENT_PREFIX.swift.gz').write_bytes(gzip.compress(current,mtime=0))
    (PROOF/'EXPLICIT_APPEND.patch').write_bytes(git('diff','--full-index','--',HELPER))
    before = git('rev-parse','HEAD').decode().strip()
    result={'schema':'otzaria.wave3.native-phone-owner-intake.v1','base':BASE,'beforeAppend':before,
            'donorMappings':mappings,'verifiedManifestFiles':len(verified),'verifiedArchiveMembers':len(archive.namelist()),
            'sourceTreesUnchanged':initial_trees,
            'helper':{'path':HELPER,'preservedPrefixBytes':len(current),'preservedPrefixSHA256':sha(current),
                      'suffixBytes':len(suffix),'suffixSHA256':sha(suffix),'resultBytes':len(combined),'resultSHA256':sha(combined)},
            'newTest':{'path':TEST,'bytes':1511,'sha256':sha(show(NAV_SOURCE,TEST))},
            'actualDonorSyntaxReceiptSHA256':sha(actual_receipt.read_bytes()),
            'historyFourCallerRepairs':'Exact entire current prefix retained; no old helper assertion changed',
            'native':'NOT_RUN','appSDK':'NOT_RUN','production':'NOT_RUN','physical':'NOT_RUN',
            'ownerPreflight':'READ_ONLY ec5385 scope; no signatures/registry/gate changed; current source requires final re-inventory',
            'preservedIntakeFailure':'Initial scope assertion expected only the new test in the source commit. Actual immutable commit also included its three reviewed helper proposal documents. The exact 4/14 split was independently read before retry; no application/test modification or cherry-pick occurred before that failure.',
            'pending':'Independent Search debug probe/native suffix intake, then one focused combined syntax check; final Apple SDK/native qualification still required'}
    dump(PROOF/'RESULT.json',result)
    (PROOF/'README.md').write_text('# Native phone selectors and owner preflight intake\n\n'
        'Three exact commits were selectively integrated with normal Git hooks and preserved donor identities. '
        'The live helper was assembled from the already repaired 259,040-byte prefix plus only the exact 13,144-byte phone suffix. '
        'The four History caller fixes, all existing assertions, app Source, Vendor and project trees are unchanged. '
        'The original 17-member source/syntax evidence archive and both manifests were independently verified.\n\n'
        'The five new system selectors are NOT_RUN. Donor Apple-target frontend parsing is syntax-only; it does not qualify an app SDK, device, production fixture or physical test. '
        'The independent Search addition is still pending. New files use the existing synchronized test target, with no PBX edit.\n\n'
        'The exact owner preflight remains scoped to ec5385: 34 matching records, 21 renewals and five additions, not a cryptographic PASS for this candidate. '
        'All 55 existing records remain intact. Actual authentic signing, strict source admission, SDK qualification and the unchanged final release gates remain required.\n')
    git('add','--',HELPER)
    git('add','--sparse','--',str(PROOF.relative_to(ROOT)))
    git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Integrate original hidden phone system tests and owner preflight evidence')
    head=git('rev-parse','HEAD').decode().strip()
    assert not git('status','--porcelain')
    for path,tree in initial_trees.items():
        assert git('rev-parse','HEAD:'+path).decode().strip() == tree
    total=set(git('diff','--name-only',BASE,'HEAD').decode().splitlines())
    allowed={HELPER,TEST}|set(names(NAV_DOCS,NAV_DIR))|set(names(OWNER_DOCS,OWNER_DIR))|set(names('HEAD',str(PROOF.relative_to(ROOT))))
    assert total == allowed
    assert git(*remote_args).decode().split()[0] == BASE
    git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
    assert git(*remote_args).decode().split()[0] == head
    terminal={'ok':True,'head':head,'base':BASE,'mappings':mappings,'source':initial_trees['Source'],'helperSHA256':sha(combined),
              'resultSHA256':sha((PROOF/'RESULT.json').read_bytes()),'freeBytes':shutil.disk_usage(ROOT).free,
              'proof':str(PROOF),'native':'NOT_RUN','ownerGate':'NOT_RUN'}
    dump(RUN/'TERMINAL.json',terminal)
    print(json.dumps(terminal))
except BaseException as error:
    failure={'ok':False,'type':type(error).__name__,'error':str(error),'events':str(RUN/'EVENTS.json')}
    dump(RUN/'FAILURE.json',failure)
    print(json.dumps(failure))
    raise
