# Bounded exact TOC embedded-source lookup

Status: **NO_EXACT_TARGET_IN_BOUNDED_LOOKUP**.

Only the two hash-pinned archives in INPUTS.json were read. Every declared top-level member was read once, with its ZIP CRC checked. Nested ZIP members, JSON string values, individual non-f-string Python literal tokens, complete base64-like/declared literals and gzip payloads were considered under the recorded bounds. No source script was executed or imported; no call/name/dynamic expression or concatenation was evaluated. Individual Python STRING tokens were decoded with ast.literal_eval only after lexical restriction and f-string rejection.

A recovery requires the complete target byte length and SHA-256. No partial source, newline change, guessed edit or reconstructed object is accepted. TOP_LEVEL_MEMBERS.json and DECODE_LEDGER.json record the actual examined scope, duplicates and refused/depth-limited payloads. Any unavailable result is limited to this finite scope, not a claim of global absence.

No existing proposal/recovery directory, original archive, source, Git repository or Data volume was written. No compiler, native operation, test, approval/signing or authentication occurred. The new proof scope is bounded to 4 MiB with the unchanged rootfs floor plus full reserve.
