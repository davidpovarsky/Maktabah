if not __debug__:
    raise SystemExit("Optimized Python refused before lookup.")
import ast
import base64
import collections
import datetime
import gzip
import hashlib
import io
import json
import os
import pathlib
import re
import stat
import tokenize
import zipfile

def require(ok,message):
    if not ok: raise RuntimeError(message)
def sha(data): return hashlib.sha256(data).hexdigest()
def jb(value): return (json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False)+"\n").encode()
def ident(s): return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def free():
    s=os.statvfs("/home/ubuntu")
    return s.f_bavail*s.f_frsize

cfg=CONFIG
limits=cfg["limits"]
out=pathlib.Path(cfg["output"])
require(out.parent==pathlib.Path("/home/ubuntu") and not out.exists() and not out.is_symlink(),"fresh bounded output must be absent")
initial_free=free()
require(initial_free>=cfg["root_floor"]+cfg["cap"],"root floor plus full reserve unavailable")
archives=[]
for item in cfg["archives"]:
    p=pathlib.Path(item["path"]); before=p.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink==1,"archive is not single-link regular")
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        require(ident(os.fstat(fd))==ident(before),"archive changed before read")
        with os.fdopen(fd,"rb",closefd=False) as f: data=f.read()
        require(ident(os.fstat(fd))==ident(before),"archive changed while reading")
    finally: os.close(fd)
    require(len(data)==item["bytes"] and sha(data)==item["sha256"],"pinned full archive mismatch")
    archives.append((item,data,before))

queue=collections.deque()
nodes=[]
seen={}
matches=[]
match_bytes={}
errors=[]
counts=collections.Counter()
decoded_bytes=0
top_members=[]
skips=[]
target_sizes={t["bytes"] for t in cfg["targets"]}
target_map={t["sha256"]:t for t in cfg["targets"]}
def issue(kind,parent,detail):
    counts[kind]+=1
    if len(errors)<limits["error_records"]:
        errors.append({"kind":kind,"parent":parent,"detail":str(detail)[:400]})
def add(data,parent,operation,locator,depth,kind_hint=""):
    global decoded_bytes
    counts["candidate_payloads_seen"]+=1
    size=len(data)
    if size>limits["payload_bytes"]:
        issue("payload_limit",parent,locator); return None
    if depth>limits["decode_depth"]:
        issue("depth_limit",parent,locator); return None
    if decoded_bytes+size>limits["aggregate_decoded_bytes"]:
        issue("aggregate_limit",parent,locator); return None
    decoded_bytes+=size
    digest=sha(data)
    if size in target_sizes and digest in target_map and size==target_map[digest]["bytes"]:
        matches.append({"target":target_map[digest],"parent":parent,"operation":operation,"locator":locator,"depth":depth})
        match_bytes[digest]=data
    if digest in seen:
        counts["duplicate_payloads"]+=1
        return seen[digest]
    if len(nodes)>=limits["nodes"]:
        issue("node_limit",parent,locator); return None
    nid=len(nodes)
    row={"id":nid,"parent":parent,"operation":operation,"locator":locator[:500],"depth":depth,
         "bytes":size,"sha256":digest,"kind_hint":kind_hint}
    nodes.append(row); seen[digest]=nid
    queue.append((nid,data,depth,kind_hint))
    return nid

# Each declared top-level member is read once, which also checks its ZIP CRC.
for item,data,before in archives:
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos=z.infolist()
        require(len(infos)==len({i.filename for i in infos})==item["members"],"pinned ZIP closed member count mismatch")
        for info in infos:
            path=pathlib.PurePosixPath(info.filename)
            require(not path.is_absolute() and ".." not in path.parts and not info.is_dir(),"unexpected top ZIP member path/type")
            require(info.file_size<=limits["payload_bytes"],"top member exceeds fixed per-payload bound")
            require(decoded_bytes+info.file_size<=limits["aggregate_decoded_bytes"],"top-level archive members exceed aggregate allowance")
            raw=z.read(info.filename)
            require(len(raw)==info.file_size,"ZIP declared length mismatch")
            top_members.append({"archive":item["label"],"member":info.filename,"bytes":len(raw),"sha256":sha(raw),"crc32":format(info.CRC,"08x")})
            hint=path.suffix.lower()
            add(raw,None,"archive_member",item["label"]+":"+info.filename,0,hint)

def base64_like(data):
    value=data.strip()
    if value.startswith(b"base64:"):
        value=value[7:].strip()
    elif value.startswith(b"data:") and b";base64," in value[:200]:
        value=value.split(b";base64,",1)[1]
    compact=re.sub(rb"[ \t\r\n]",b"",value)
    if len(compact)<64 or len(compact)%4!=0: return None
    if not re.fullmatch(rb"[A-Za-z0-9+/_-]+={0,2}",compact): return None
    return compact

def relevant_string(data,hint):
    stripped=data.lstrip()
    return (len(data) in target_sizes or len(data)>=min(target_sizes)
            or stripped.startswith((b"{",b"[",b"\x1f\x8b",b"PK\x03\x04"))
            or base64_like(data) is not None
            or (hint.lower() in ("source","code","script","python","payload","command","contents","content") and
                (b"\n" in data or b"base64" in data or b"gzip" in data)))

def json_strings(value,parent,depth):
    pending=[(value,"$",0,"")]
    count=0
    while pending:
        value,path,structure_depth,hint=pending.pop()
        if structure_depth>limits["json_structure_depth"]:
            issue("json_structure_limit",parent,path); continue
        if isinstance(value,str):
            count+=1
            if len(value)>limits["payload_bytes"]:
                issue("json_string_limit",parent,path); continue
            try: raw=value.encode("utf-8")
            except UnicodeError as e:
                issue("json_string_encoding_refused",parent,e); continue
            if relevant_string(raw,hint):
                add(raw,parent,"json_string",path,depth+1,".py" if hint.lower() in ("script","python","code","command") else "")
        elif isinstance(value,list):
            for i in range(len(value)-1,-1,-1):
                pending.append((value[i],path+"["+str(i)+"]",structure_depth+1,hint))
        elif isinstance(value,dict):
            for key,v in reversed(list(value.items())):
                label=str(key)
                # Values only: keys are names, not declared source payloads.
                pending.append((v,path+"."+label[:200],structure_depth+1,label))
    counts["json_strings_inspected"]+=count

def python_literals(text,parent,depth):
    inspected=0
    try:
        stream=tokenize.generate_tokens(io.StringIO(text).readline)
        for tok in stream:
            inspected+=1
            if inspected>limits["python_tokens_per_payload"]:
                issue("python_token_limit",parent,inspected); break
            if tok.type!=tokenize.STRING: continue
            literal=tok.string
            prefix_match=re.match(r"(?i)^([rubf]*)",literal)
            prefix=prefix_match.group(1).lower() if prefix_match else ""
            if "f" in prefix:
                counts["dynamic_f_strings_refused"]+=1
                continue
            if len(literal)>limits["payload_bytes"]:
                issue("python_literal_size_limit",parent,tok.start); continue
            # The input is ONE tokenizer STRING token, with f-strings rejected.
            # literal_eval cannot execute a call/name/expression from this token.
            try:
                value=ast.literal_eval(literal)
            except (ValueError,SyntaxError,MemoryError,RecursionError) as e:
                issue("literal_decode_refused",parent,type(e).__name__); continue
            if isinstance(value,str):
                try: raw=value.encode("utf-8")
                except UnicodeError as e:
                    issue("literal_string_encoding_refused",parent,e); continue
            elif isinstance(value,bytes): raw=value
            else:
                issue("non_string_literal_refused",parent,type(value).__name__); continue
            counts["python_literal_strings_inspected"]+=1
            if relevant_string(raw,""):
                add(raw,parent,"python_literal","line "+str(tok.start[0])+" column "+str(tok.start[1]),depth+1)
    except (tokenize.TokenError,IndentationError,SyntaxError) as e:
        issue("python_tokenization_refused",parent,str(e))
    counts["python_tokens_inspected"]+=inspected

while queue:
    nid,data,depth,hint=queue.popleft()
    if depth>=limits["decode_depth"]:
        counts["nodes_at_decode_depth_bound"]+=1
        continue
    remaining=limits["aggregate_decoded_bytes"]-decoded_bytes
    if remaining<=0:
        issue("aggregate_limit",nid,"no decoded allowance remains")
        continue
    compact=base64_like(data)
    if compact is not None:
        estimated=(len(compact)//4)*3
        if estimated>limits["payload_bytes"] or estimated>remaining:
            issue("base64_bound",nid,estimated)
        else:
            try:
                raw=base64.b64decode(compact,altchars=b"-_",validate=True)
                add(raw,nid,"base64","entire declared/base64-like literal",depth+1)
                counts["base64_payloads_decoded"]+=1
            except (ValueError,base64.binascii.Error) as e:
                issue("base64_decode_refused",nid,type(e).__name__)
    if data.startswith(b"\x1f\x8b"):
        try:
            bound=min(limits["payload_bytes"],limits["aggregate_decoded_bytes"]-decoded_bytes)
            with gzip.GzipFile(fileobj=io.BytesIO(data),mode="rb") as g:
                raw=g.read(bound+1)
            if len(raw)>bound:
                issue("gzip_expansion_bound",nid,len(raw))
            else:
                add(raw,nid,"gzip","bounded gzip payload",depth+1)
                counts["gzip_payloads_decoded"]+=1
        except (OSError,EOFError,ValueError) as e:
            issue("gzip_decode_refused",nid,type(e).__name__)
    if data.startswith(b"PK\x03\x04"):
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as nested:
                infos=nested.infolist()
                require(len(infos)==len({i.filename for i in infos}),"nested ZIP duplicate names")
                for info in infos:
                    name=pathlib.PurePosixPath(info.filename)
                    if name.is_absolute() or ".." in name.parts or info.is_dir():
                        issue("nested_zip_member_refused",nid,info.filename); continue
                    remaining=limits["aggregate_decoded_bytes"]-decoded_bytes
                    if info.file_size>limits["payload_bytes"] or info.file_size>remaining:
                        issue("nested_zip_size_bound",nid,info.filename); continue
                    raw=nested.read(info.filename)
                    add(raw,nid,"nested_zip_member",info.filename,depth+1,name.suffix.lower())
                    counts["nested_zip_members_read"]+=1
        except (zipfile.BadZipFile,RuntimeError,OSError) as e:
            issue("nested_zip_decode_refused",nid,str(e))
    try:
        text=data.decode("utf-8")
    except UnicodeError:
        counts["non_utf8_payloads"]+=1
        continue
    stripped=text.lstrip()
    if stripped.startswith(("{","[","\"")):
        try:
            value=json.loads(text,parse_int=lambda _:0,parse_float=lambda _:0,
                             parse_constant=lambda _:(_ for _ in ()).throw(ValueError("non-JSON constant")))
            json_strings(value,nid,depth)
            counts["json_payloads_parsed"]+=1
        except (ValueError,RecursionError) as e:
            issue("json_decode_refused",nid,type(e).__name__)
    # Only lex source-looking Python or explicitly named Python script payloads.
    # No statement, module or dynamic expression is executed or evaluated.
    looks_python=(hint==".py" or stripped.startswith(("#!","import ","from ","def ","class ","if not __debug__"))
                  or ("base64.b64decode" in text or "gzip.decompress" in text or "b64decode(" in text))
    if looks_python:
        python_literals(text,nid,depth)
        counts["python_payloads_lexed"]+=1

for item,data,before in archives:
    require(ident(pathlib.Path(item["path"]).lstat())==ident(before),"original archive changed during finite walk")
require(decoded_bytes<=limits["aggregate_decoded_bytes"],"aggregate decoder bound exceeded")
require(len(nodes)<=limits["nodes"],"node bound exceeded")
require(free()>=cfg["root_floor"]+cfg["cap"],"root floor lost before proof allocation")
out.mkdir(mode=0o755)
def allocation():
    total=0
    for base,ds,fs in os.walk(out,followlinks=False):
        s=pathlib.Path(base).lstat()
        require(stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode),"proof directory changed")
        total+=s.st_blocks*512
        for name in ds:
            q=(pathlib.Path(base)/name).lstat()
            require(stat.S_ISDIR(q.st_mode) and not stat.S_ISLNK(q.st_mode),"proof directory symlink")
        for name in fs:
            q=(pathlib.Path(base)/name).lstat()
            require(stat.S_ISREG(q.st_mode) and q.st_nlink==1,"proof file not single-link regular")
            total+=q.st_blocks*512
    return total
def write(name,data):
    require("/" not in name and name not in ("",".",".."),"unexpected proof filename")
    require(free()>=cfg["root_floor"]+cfg["cap"],"root floor/reserve lost before proof write")
    require(allocation()+((len(data)+4095)//4096)*4096<=cfg["cap"],"4 MiB proof allocated budget would be exceeded")
    fd=os.open(out/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o644)
    try:
        with os.fdopen(fd,"wb",closefd=False) as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
    finally: os.close(fd)
    require((out/name).read_bytes()==data,"proof artifact readback mismatch")
write("INPUTS.json",jb(cfg))
write("LOOKUP.py",LOOKUP_SOURCE.encode())
write("TOP_LEVEL_MEMBERS.json",jb({"members":top_members,"count":len(top_members),"each_member_crc_checked_on_read":True}))
write("DECODE_LEDGER.json",jb({"nodes":nodes,"node_count":len(nodes),"decoded_bytes_charged_including_duplicates":decoded_bytes,
                             "counts":dict(counts),"errors_and_refusals":errors,
                             "errors_omitted":max(0,sum(v for k,v in counts.items() if k.endswith(("_limit","_refused","_bound")))-len(errors))}))
for digest,data in sorted(match_bytes.items()):
    target=target_map[digest]
    write("RECOVERED_"+target["name"],data)
status="EXACT_SOURCE_RECOVERED" if match_bytes else "NO_EXACT_TARGET_IN_BOUNDED_LOOKUP"
proof={"schema":"otzaria.toc.embedded-exact-source-lookup.result.v1","status":status,
       "time_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"archives":cfg["archives"],"targets":cfg["targets"],
       "top_level_members_read":len(top_members),"top_level_member_bytes":sum(r["bytes"] for r in top_members),
       "unique_payload_nodes":len(nodes),"decoded_bytes_charged_including_duplicates":decoded_bytes,
       "limits":limits,"counts":dict(counts),"matches":matches,"exact_targets_recovered":len(match_bytes),
       "no_partial_source_transformation_or_concatenation":True,"no_dynamic_expression_evaluation":True,
       "python_literal_method":"tokenize STRING only; reject f-strings; ast.literal_eval only on that one literal token",
       "original_archive_bytes_and_identity_unchanged":True,"other_filesystem_scopes_searched":False,
       "compiler_tests_native_or_git_execution":False,"unavailable_scope":"Only the bounded two-archive search; not a global absence claim.",
       "resources":{"root_floor":cfg["root_floor"],"full_reserve_and_cap":cfg["cap"],"free_before":initial_free,"free_before_result":free(),"allocated_before_result":allocation()}}
write("RESULT.json",jb(proof))
readme=("# Bounded exact TOC embedded-source lookup\n\nStatus: **"+status+"**.\n\n"
        "Only the two hash-pinned archives in INPUTS.json were read. Every declared top-level member was read once, with its ZIP CRC checked. "
        "Nested ZIP members, JSON string values, individual non-f-string Python literal tokens, complete base64-like/declared literals and gzip payloads were considered under the recorded bounds. "
        "No source script was executed or imported; no call/name/dynamic expression or concatenation was evaluated. "
        "Individual Python STRING tokens were decoded with ast.literal_eval only after lexical restriction and f-string rejection.\n\n"
        "A recovery requires the complete target byte length and SHA-256. No partial source, newline change, guessed edit or reconstructed object is accepted. "
        "TOP_LEVEL_MEMBERS.json and DECODE_LEDGER.json record the actual examined scope, duplicates and refused/depth-limited payloads. "
        "Any unavailable result is limited to this finite scope, not a claim of global absence.\n\n"
        "No existing proposal/recovery directory, original archive, source, Git repository or Data volume was written. "
        "No compiler, native operation, test, approval/signing or authentication occurred. The new proof scope is bounded to 4 MiB with the unchanged rootfs floor plus full reserve.\n")
write("README.md",readme.encode())
rows=[]
for p in sorted(out.iterdir()):
    require(p.is_file() and not p.is_symlink(),"unexpected proof entry")
    b=p.read_bytes()
    rows.append({"path":p.name,"bytes":len(b),"sha256":sha(b)})
write("MANIFEST.json",jb({"schema":"otzaria.toc.embedded-lookup.manifest.v1","files":rows,"manifest_self_excluded":True}))
require(allocation()<=cfg["cap"] and free()>=cfg["root_floor"]+cfg["cap"],"final proof resource bound lost")
for item,data,before in archives:
    require(ident(pathlib.Path(item["path"]).lstat())==ident(before),"archive changed before final proof")
artifacts=[]
for p in sorted(out.iterdir()):
    b=p.read_bytes()
    artifacts.append({"path":p.name,"bytes":len(b),"sha256":sha(b)})
print(json.dumps({"status":status,"output":str(out),"files":artifacts,"matches":matches,"counts":dict(counts),
                  "top_members":len(top_members),"payload_nodes":len(nodes),"decoded_bytes":decoded_bytes,
                  "allocated_bytes":allocation(),"rootfs_free_after":free(),"no_source_execution":True},sort_keys=True))
