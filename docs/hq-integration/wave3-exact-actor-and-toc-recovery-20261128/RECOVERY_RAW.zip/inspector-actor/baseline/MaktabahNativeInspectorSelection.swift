#if os(iOS)
import Foundation
import SwiftUI
import UIKit
import TorahInspectorCore
import TorahInspectorUI
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

/// Metadata belongs to the ORIGINAL Reader workspace. Every value stays in its
/// existing SwiftUI State/Binding; these counters execute no observer callback.
@MainActor final class MaktabahNativeInspectorWorkspace {
    enum Field { case tool, session, detent, foreign }
    struct Revision: Equatable {
        let mount: UInt64?
        let tool: UInt64?
        let session: UInt64?
        let detent: UInt64?
        let foreign: UInt64?
        var available: Bool { mount != nil && tool != nil && session != nil && detent != nil && foreign != nil }
    }
    struct Access {
        let reader: ReaderViewModel
        let book: BooksData
        let manager: iOSNavigationManager
        let session: @MainActor () -> MaktabahTorahInspectorSession
        let tool: @MainActor () -> TorahStudyTool
        let contentID: @MainActor () -> UUID
        let isPeek: @MainActor () -> Bool
        let blocked: @MainActor () -> Bool
    }
    struct State {
        let access: Access
        let session: MaktabahTorahInspectorSession
        let identity: MaktabahTorahInspectorSession.NativeNavigationSource
        let tool: TorahStudyTool
        let contentID: UUID
        let isPeek: Bool
    }
    let id = UUID()
    private(set) weak var binding: MaktabahNativeInspectorSelection?
    private(set) weak var view: UIView?
    private var access: Access?
    private var mountRevision: UInt64? = 0
    private var toolRevision: UInt64? = 0
    private var sessionRevision: UInt64? = 0
    private var detentRevision: UInt64? = 0
    private var foreignRevision: UInt64? = 0
    var revision: Revision { .init(mount: mountRevision, tool: toolRevision, session: sessionRevision,
                                   detent: detentRevision, foreign: foreignRevision) }
    private var markers: [UUID: WeakMarker] = [:]
    private final class WeakMarker {
        weak var value: MaktabahNativeInspectorMarker?
        init(_ value: MaktabahNativeInspectorMarker) { self.value = value }
    }

    func originalBinding<Value>(_ original: Binding<Value>, field: Field) -> Binding<Value> {
        Binding(get: { original.wrappedValue }, set: { [self] value, transaction in
            originalWillChange(field)
            original.transaction(transaction).wrappedValue = value
        })
    }
    func originalWillChange(_ field: Field) {
        switch field {
        case .tool: Self.advance(&toolRevision)
        case .session: Self.advance(&sessionRevision)
        case .detent: Self.advance(&detentRevision)
        case .foreign: Self.advance(&foreignRevision)
        }
    }
    private static func advance(_ value: inout UInt64?) {
        guard let previous = value else { return }
        value = previous == .max ? nil : previous + 1
    }
    func read() throws -> State {
        let before = revision
        guard before.available, let access, view?.window != nil, !access.blocked() else { throw stale() }
        let session = access.session(), tool = access.tool(), contentID = access.contentID(), peek = access.isPeek()
        guard let identity = session.nativeNavigationSource(for: access.reader),
              revision == before, self.access?.reader === access.reader,
              self.access?.manager === access.manager, self.access?.book === access.book,
              access.session() === session, !access.blocked(), revision == before else { throw stale() }
        return State(access: access, session: session, identity: identity, tool: tool,
                     contentID: contentID, isPeek: peek)
    }
    func attach(binding: MaktabahNativeInspectorSelection?, access: Access, view: UIView) {
        if self.view === view, self.binding === binding,
           self.access?.reader === access.reader, self.access?.manager === access.manager,
           self.access?.book === access.book {
            self.access = access
        } else {
            let old = self.binding
            Self.advance(&mountRevision)
            self.access = access; self.view = view; self.binding = binding
            old?.detachWorkspace(self)
        }
        guard self.view === view, self.binding === binding,
              self.access?.reader === access.reader, self.access?.manager === access.manager else { return }
        let capturedMount = mountRevision
        binding?.attachWorkspace(self)
        // Children may mount before the original workspace's background. Only
        // existing live UIKit markers are replayed, never a fabricated host.
        markers = markers.filter { $0.value.value != nil }
        for marker in Array(markers.values).compactMap(\.value) {
            guard self.view === view, self.binding === binding, mountRevision == capturedMount else { return }
            marker.register()
        }
    }
    func detach(view: UIView) {
        guard self.view === view else { return }
        Self.advance(&mountRevision)
        let old = binding
        access = nil; self.view = nil; binding = nil
        old?.detachWorkspace(self)
    }
    fileprivate func remember(_ marker: MaktabahNativeInspectorMarker) { markers[marker.token] = WeakMarker(marker) }
    fileprivate func forget(_ marker: MaktabahNativeInspectorMarker) { markers.removeValue(forKey: marker.token) }
    func hooks(context: MaktabahNativeInspectorSelection.HostContext) -> TorahInspectorNavigationHooks {
        .init(panel: { [weak self] panel in
            guard let self else { return AnyView(EmptyView()) }
            let marker = MaktabahNativeInspectorMarkerView(workspace: self, context: context, role: .panel(panel))
            return AnyView(marker.id(marker.identity))
        }, witness: { [weak self] ownerID, anchor in
            guard let self else { return AnyView(EmptyView()) }
            let marker = MaktabahNativeInspectorMarkerView(workspace: self, context: context,
                role: .target(ownerID, anchor))
            return AnyView(marker.id(marker.identity))
        })
    }
    private func stale() -> UIRouteError { .init(.staleState, "native_inspector_workspace_changed") }
}

/// Read-only original Reader/mapping identity. The original coordinator's
/// pre-token load proof is captured before any selection read and never reset.
@MainActor private final class MaktabahNativeInspectorReaderSource {
    let reader: ReaderViewModel
    let inspector: MaktabahNativeInspectorBinding
    let workspaceOwner: MaktabahNativeInspectorWorkspace
    let originalSession: MaktabahTorahInspectorSession
    let contentID: UUID
    private let manager: iOSNavigationManager
    private let bindings: MaktabahNativeSceneBindings
    private let workspaceSource: MaktabahNativeWorkspaceProjectionSource
    private let workspace: StudyWorkspaceNavigationAdapter
    private let mapping: StudyWorkspaceMappingObservation
    private let stored: StudyWorkspaceMappingObservation
    private let root: MaktabahNativeRootPublicationSource
    private let rootRevision: UInt64
    private let settingsRevision: UInt64
    private let modeRevision: UInt64
    private let selectedBookRevision: UInt64
    private let selectedBook: BooksData?
    private let selectedBookMode: AppMode?
    private let originalMount: UInt64
    private let originalSessionRevision: UInt64
    private let initialContent: ReaderInitialContentSourceObservation
    private let observation: MaktabahNativeComponentSourceObservation
    private let text: [UInt8]
    private var valid = true
    private var checking = false

    init(sceneID: UIStableID, bindings: MaktabahNativeSceneBindings,
         workspaceSource: MaktabahNativeWorkspaceProjectionSource,
         original: MaktabahNativeInspectorWorkspace) throws {
        let manager = bindings.manager
        guard let reader = MaktabahNativeInspectorBinding.currentReader(in: manager),
              let initial = reader.contentLoadCoordinator.initialContentSourceObservation(),
              initial.pendingRequestID == nil, initial.isCurrent,
              let root = bindings.rootPublications,
              let rootRevision = root.selectionRevision, let settingsRevision = root.settingsRevision,
              let modeRevision = manager.nativeModePresentationRevision,
              let bookRevision = manager.selectedBookPresentationRevision else { throw Self.stale() }
        let publication = try workspaceSource.originalPublication()
        var actual: (MaktabahNativeInspectorWorkspace.State, StudyWorkspaceNavigationAdapter,
                     StudyWorkspaceMappingObservation, StudyWorkspaceMappingObservation)?
        var readError: (any Error)?
        let observation = MaktabahNativeComponentSourceObservation(publications: [publication,
                root.nativePublication, manager.nativeModePresentationPublication]) {
            do {
                let source = try original.read()
                guard source.access.reader === reader, source.access.manager === manager,
                      let workspace = try workspaceSource.read(), workspaceSource.isAuthoritative,
                      workspace.sceneID == sceneID.rawValue, workspace.attached, !workspace.isSwitching,
                      workspace.errorMessage == nil, workspace.store.loadError == nil,
                      let mapping = workspace.mappingOwnershipObservation(),
                      let stored = workspace.store.mappingObservation(scene: sceneID.rawValue),
                      mapping.owner == ObjectIdentifier(manager), mapping.scene == sceneID.rawValue,
                      stored.owner == ObjectIdentifier(workspace.store), stored.scene == sceneID.rawValue,
                      mapping.coverage == .liveNativeSetters, stored.coverage == .workspaceStoreOnly else { throw Self.stale() }
                actual = (source, workspace, mapping, stored)
                _ = workspace.attached; _ = workspace.isSwitching; _ = workspace.errorMessage; _ = workspace.store.loadError
                _ = mapping.source.event; _ = stored.source.event
                _ = manager.openTabs; _ = manager.activeTabId; _ = manager.selectedBook; _ = manager.selectedContentId
                _ = manager.selectedBookPresentationMode; _ = manager.selectedBookForInfo; _ = manager.showingTabsList
                _ = manager.alertMessage; _ = DonationManager.shared.showDonationSheet
                _ = reader.state; _ = reader.currentBook; _ = reader.currentDestination; _ = reader.currentContentId
                _ = reader.currentReaderTextMode; _ = reader.contentText; _ = reader.backendSection
                _ = reader.backendRenderModel; _ = reader.selectedSegmentLocator; _ = reader.selectedSegmentRange
                _ = reader.otzariaSelectedLineAnchor; _ = reader.readerState.selectedRange; _ = reader.isPopoverPresented
            } catch { readError = error }
        }
        if let readError { throw readError }
        guard let (source, workspace, mapping, stored) = actual,
              let mount = original.revision.mount, let sessionRevision = original.revision.session else { throw Self.stale() }
        self.reader = reader; self.manager = manager; self.bindings = bindings
        self.workspaceSource = workspaceSource; self.workspace = workspace
        self.mapping = mapping; self.stored = stored; self.root = root
        self.rootRevision = rootRevision; self.settingsRevision = settingsRevision; self.modeRevision = modeRevision
        selectedBookRevision = bookRevision; selectedBook = manager.selectedBook
        selectedBookMode = manager.selectedBookPresentationMode
        workspaceOwner = original; originalSession = source.session; contentID = source.contentID
        originalMount = mount; originalSessionRevision = sessionRevision
        initialContent = initial; self.observation = observation; text = Array(reader.contentText.utf8)
        inspector = try MaktabahNativeInspectorBinding(manager: manager)
        try validate()
    }
    func retire() { valid = false; observation.invalidate() }
    func validate() throws {
        guard valid, !checking else { throw Self.stale() }
        checking = true; defer { checking = false }
        do {
            try observation.validate()
            guard initialContent.isCurrent, initialContent.pendingRequestID == nil,
                  bindings.rootPublications === root, root.selectionRevision == rootRevision,
                  root.settingsRevision == settingsRevision, !bindings.showSettings.wrappedValue,
                  bindings.selectedTab.wrappedValue == .viewer, manager.currentMode == .viewer,
                  manager.nativeModePresentationRevision == modeRevision,
                  manager.selectedBookPresentationRevision == selectedBookRevision,
                  manager.selectedBook === selectedBook, manager.selectedBookPresentationMode == selectedBookMode,
                  manager.selectedBookForInfo == nil, !manager.showingTabsList, manager.alertMessage == nil,
                  !DonationManager.shared.showDonationSheet, !reader.isPopoverPresented,
                  workspaceSource.isAuthoritative, try workspaceSource.read() === workspace,
                  workspace.attached, !workspace.isSwitching, workspace.errorMessage == nil, workspace.store.loadError == nil,
                  let current = workspace.mappingOwnershipObservation(),
                  let currentStored = workspace.store.mappingObservation(scene: workspace.sceneID),
                  current.source === mapping.source, current.epoch == mapping.epoch,
                  current.owner == mapping.owner, current.projection == mapping.projection,
                  currentStored.source === stored.source, currentStored.epoch == stored.epoch,
                  currentStored.owner == stored.owner, currentStored.projection == stored.projection,
                  workspaceOwner.revision.mount == originalMount,
                  workspaceOwner.revision.session == originalSessionRevision else { throw Self.stale() }
            let source = try workspaceOwner.read()
            guard source.access.reader === reader, source.access.manager === manager,
                  source.session === originalSession, source.contentID == contentID,
                  reader.contentText.utf8.elementsEqual(text) else { throw Self.stale() }
            try inspector.validate(); try observation.validate()
            guard valid, initialContent.isCurrent else { throw Self.stale() }
        } catch { valid = false; observation.invalidate(); throw error }
    }
    private static func stale() -> UIRouteError { .init(.staleState, "native_inspector_reader_source_changed") }
}

/// Scene-owned access to the ORIGINAL Inspector. No renderer, loader or editor
/// is created here. The original Core command authorizes one parent/reveal; the
/// actual original control and its visible geometry independently prove ACK.
@MainActor final class MaktabahNativeInspectorSelection {
    typealias Service = NativeInspectorSelectionIntentService
    typealias Record = Service.Record
    static let destination = Service.destination

    struct HostContext {
        let session: MaktabahTorahInspectorSession
        let repository: TorahInspectorRepository
        let selection: TorahInspectorSelection
        let contentID: UUID
        let expandOriginalPeek: (@MainActor () -> Void)?
        func matches(_ other: Self) -> Bool {
            session === other.session && repository === other.repository
                && selection == other.selection && contentID == other.contentID
        }
    }
    fileprivate final class Host {
        let token: UUID
        let registration: UUID
        let context: HostContext
        weak var view: MaktabahNativeInspectorMarker?
        init(token: UUID, registration: UUID, context: HostContext, view: MaktabahNativeInspectorMarker) {
            self.token = token; self.registration = registration; self.context = context; self.view = view
        }
    }
    fileprivate final class Panel {
        let token: UUID
        let registration: UUID
        let host: Host
        var original: TorahInspectorOriginalPanel
        weak var view: MaktabahNativeInspectorMarker?
        var layoutRevision: UInt64? = 0
        init(token: UUID, registration: UUID, host: Host, original: TorahInspectorOriginalPanel, view: MaktabahNativeInspectorMarker) {
            self.token = token; self.registration = registration; self.host = host; self.original = original; self.view = view
        }
    }
    fileprivate final class Witness {
        let token: UUID
        let registration: UUID
        let ownerID: UUID
        let anchor: TorahInspectorNavigationAnchor
        let host: Host
        weak var view: MaktabahNativeInspectorMarker?
        init(token: UUID, registration: UUID, ownerID: UUID, anchor: TorahInspectorNavigationAnchor, host: Host, view: MaktabahNativeInspectorMarker) {
            self.token = token; self.registration = registration; self.ownerID = ownerID; self.anchor = anchor; self.host = host; self.view = view
        }
    }
    private final class Catalog {
        struct Entry { let record: Record; let target: TorahInspectorNavigationTarget? }
        let reader: MaktabahNativeInspectorReaderSource
        let tools: [Entry]
        var rows: [Entry] = []
        var panel: Panel?
        var originalRows: TorahInspectorNavigationCatalog?
        init(reader: MaktabahNativeInspectorReaderSource, sceneID: UIStableID) throws {
            self.reader = reader
            let backend = ActionAppIdentityBridge.actionBackend(BackendCoordinator.shared.activeBackendID)
            tools = try [TorahStudyTool.commentaries, .links, .notes].map { tool in
                guard let typed = Service.Tool(rawValue: tool.rawValue) else { throw Self.stale() }
                return Entry(record: try Record(reference: .init(backend: backend, kind: .tool,
                    tool: typed, token: UUID()), title: tool.localizedTitle, sceneID: sceneID), target: nil)
            }
        }
        func discardRows() { originalRows?.retire(); originalRows = nil; panel = nil; rows = [] }
        func updateRows(panel: Panel?, sceneID: UIStableID) throws {
            try reader.validate()
            if self.panel === panel, let originalRows, (try? originalRows.validate()) != nil { return }
            discardRows()
            guard let panel else { return }
            let original = try panel.original.retainCatalog()
            let backend = ActionAppIdentityBridge.actionBackend(BackendCoordinator.shared.activeBackendID)
            var entries: [Entry] = []
            for target in original.targets {
                let kind: Service.Kind
                switch target.anchor {
                case .tool: continue
                case .commentaryGroup: kind = .commentaryGroup
                case .source: kind = .source
                case .note: kind = .note
                }
                guard let tool = Service.Tool(rawValue: target.tool.rawValue) else { continue }
                let title = String(String.UnicodeScalarView(target.title.unicodeScalars.prefix(256)))
                guard let record = try? Record(reference: .init(backend: backend, kind: kind, tool: tool,
                    token: UUID()), title: title, sceneID: sceneID) else { continue }
                entries.append(Entry(record: record, target: target))
            }
            try original.validate(); try reader.validate()
            self.panel = panel; originalRows = original; rows = entries
        }
        func entry(_ record: Record) throws -> Entry {
            try reader.validate()
            if record.reference.kind != .tool { try originalRows?.validate() }
            let matches = (tools + rows).filter { $0.record == record }
            guard matches.count == 1, let found = matches.first,
                  record.reference.kind == .tool || originalRows != nil else { throw Self.stale() }
            return found
        }
        private static func stale() -> UIRouteError { .init(.staleState, "native_inspector_catalog_changed") }
    }

    private final class Source {
        enum Phase: Equatable { case retained, applyingParent, presented, retired }
        let requestID: UUID
        let catalog: Catalog
        let entry: Catalog.Entry
        let workspaceRevision: MaktabahNativeInspectorWorkspace.Revision
        let initialTool: TorahStudyTool
        let initialPeek: Bool
        let visibilityRevision: UInt64
        let initiallyVisible: Bool
        let window: MaktabahNativeWindowObservation
        let foreign: @MainActor () throws -> Void
        var host: Host?
        var panel: Panel?
        var reveal: TorahInspectorNavigationRetention?
        var witness: Witness?
        var phase = Phase.retained
        var parentApplied = false
        var expandedPeek = false
        var rendering = false
        init(requestID: UUID, catalog: Catalog, entry: Catalog.Entry,
             workspaceRevision: MaktabahNativeInspectorWorkspace.Revision,
             state: MaktabahNativeInspectorWorkspace.State, visibilityRevision: UInt64, visible: Bool,
             host: Host?, panel: Panel?, window: MaktabahNativeWindowObservation,
             foreign: @escaping @MainActor () throws -> Void) {
            self.requestID = requestID; self.catalog = catalog; self.entry = entry
            self.workspaceRevision = workspaceRevision; initialTool = state.tool; initialPeek = state.isPeek
            self.visibilityRevision = visibilityRevision; initiallyVisible = visible
            self.host = host; self.panel = panel; self.window = window; self.foreign = foreign
        }
        func retire() { phase = .retired; reveal?.retire() }
    }
    private final class Pending {
        let source: Source
        let validate: @MainActor () throws -> Void
        var applying = false
        init(source: Source, validate: @escaping @MainActor () throws -> Void) {
            self.source = source; self.validate = validate
        }
    }

    let sceneID: UIStableID
    private let bindings: MaktabahNativeSceneBindings
    private let workspaceSource: MaktabahNativeWorkspaceProjectionSource
    private let commonReady: @MainActor () -> Bool
    private let windowReady: @MainActor () -> Bool
    private let retainWindow: @MainActor () throws -> MaktabahNativeWindowObservation
    private let retainForeign: @MainActor () throws -> (@MainActor () throws -> Void)
    private var workspace: MaktabahNativeInspectorWorkspace?
    private var host: Host?
    private var panel: Panel?
    private var witnesses: [UUID: Witness] = [:]
    private var catalogSource: Catalog?
    private var retained: Source?
    private var completed: Source?
    private var pending: Pending?
    private var accessing = false
    private var checking = false
    private var validatingSource = false
    private var reporting = false
    private var retiring = false
    private var mounted = true
    private var revision: UInt64? = 0
    private var changed: (@MainActor () -> Void)?
    private var invalidated: (@MainActor () -> Void)?

    init(sceneID: UIStableID, bindings: MaktabahNativeSceneBindings,
         workspaceSource: MaktabahNativeWorkspaceProjectionSource,
         commonReady: @escaping @MainActor () -> Bool, windowReady: @escaping @MainActor () -> Bool,
         retainWindow: @escaping @MainActor () throws -> MaktabahNativeWindowObservation,
         retainForeign: @escaping @MainActor () throws -> (@MainActor () throws -> Void)) {
        self.sceneID = sceneID; self.bindings = bindings; self.workspaceSource = workspaceSource
        self.commonReady = commonReady; self.windowReady = windowReady
        self.retainWindow = retainWindow; self.retainForeign = retainForeign
    }
    func install(changed: @escaping @MainActor () -> Void, invalidated: @escaping @MainActor () -> Void) {
        self.changed = changed; self.invalidated = invalidated
    }
    var isAvailable: Bool {
        guard mounted, !retiring, revision != nil, let workspace,
              let source = try? workspace.read(), source.access.manager === bindings.manager,
              MaktabahNativeInspectorBinding.currentReader(in: bindings.manager) === source.access.reader,
              bindings.selectedTab.wrappedValue == .viewer, !bindings.showSettings.wrappedValue,
              commonReady(), bindings.isPresentationReady,
              source.access.reader.nativeInspectorPresentationRevision != nil,
              let initial = source.access.reader.contentLoadCoordinator.initialContentSourceObservation(),
              initial.pendingRequestID == nil, initial.isCurrent else { return false }
        return true
    }

    func catalog() throws -> [Record] {
        guard !accessing, !retiring, let captureRevision = revision, isAvailable, let workspace else { return [] }
        accessing = true; defer { accessing = false }
        if let active = pending?.source ?? completed {
            try validate(active)
            if active.entry.record.reference.kind == .tool {
                // A tool change can expose a different original loaded list.
                // Refresh discovery metadata only; the retained action/source
                // and its independent visible proof are never replaced.
                try active.catalog.updateRows(panel: panel, sceneID: sceneID)
            } else { try active.catalog.originalRows?.validate() }
            try validate(active)
            guard revision == captureRevision, self.workspace === workspace,
                  (pending?.source ?? completed) === active else { throw stale() }
            return active.catalog.tools.map(\.record) + active.catalog.rows.map(\.record)
        }
        if let existing = catalogSource, (try? existing.reader.validate()) == nil {
            existing.reader.retire(); existing.discardRows(); catalogSource = nil
        }
        if catalogSource == nil {
            let reader = try MaktabahNativeInspectorReaderSource(sceneID: sceneID, bindings: bindings,
                workspaceSource: workspaceSource, original: workspace)
            let next = try Catalog(reader: reader, sceneID: sceneID)
            guard mounted, revision == captureRevision, self.workspace === workspace,
                  retained == nil, pending == nil, catalogSource == nil, isAvailable else {
                reader.retire(); throw stale()
            }
            catalogSource = next
        }
        guard let catalog = catalogSource else { throw stale() }
        try catalog.updateRows(panel: panel, sceneID: sceneID)
        try catalog.reader.validate()
        guard revision == captureRevision, catalogSource === catalog, self.workspace === workspace,
              retained == nil, pending == nil else { throw stale() }
        return catalog.tools.map(\.record) + catalog.rows.map(\.record)
    }

    /// Retain before foregrounding or Core awaits. A cold tool may join only
    /// the first original host/panel of this same retained Reader/workspace.
    /// A loaded row always requires its exact already captured original panel.
    func retain(record: Record, requestID: UUID) throws {
        guard !accessing, !retiring, pending == nil, retained == nil,
              let captureRevision = revision, isAvailable, let workspace,
              let catalog = catalogSource, catalog.reader.workspaceOwner === workspace,
              record.sceneID == sceneID else { throw stale() }
        accessing = true; defer { accessing = false }
        let entry = try catalog.entry(record)
        let before = workspace.revision
        let state = try workspace.read()
        let reader = catalog.reader.reader
        guard let visibilityRevision = reader.nativeInspectorPresentationRevision,
              reader.readerInspectorVisible || visibilityRevision < .max,
              before.available else { throw stale() }
        let visible = reader.readerInspectorVisible
        if !visible { guard host == nil, panel == nil, record.reference.kind == .tool else { throw stale() } }
        if record.reference.kind != .tool {
            guard visible, let panel, catalog.panel === panel, host === panel.host else { throw stale() }
        }
        let window = try retainWindow()
        _ = try window.validate()
        let foreign = try retainForeign()
        try foreign(); try catalog.reader.validate()
        guard before == workspace.revision, self.workspace === workspace,
              catalogSource === catalog, revision == captureRevision,
              reader.nativeInspectorPresentationRevision == visibilityRevision,
              reader.readerInspectorVisible == visible, retained == nil, pending == nil else { throw stale() }
        let source = Source(requestID: requestID, catalog: catalog, entry: entry,
            workspaceRevision: before, state: state, visibilityRevision: visibilityRevision,
            visible: visible, host: host, panel: panel, window: window, foreign: foreign)
        if let panel { source.reveal = try originalReveal(source, panel: panel) }
        completed?.retire(); completed = nil; retained = source
        do { try validate(source) }
        catch { releaseSource(requestID: requestID); throw error }
    }
    func hasRetainedSource(requestID: UUID) -> Bool { retained?.requestID == requestID }
    func validateSource(requestID: UUID) throws {
        guard let source = retained, source.requestID == requestID else { throw stale() }
        try validate(source)
    }
    func selectedItem(requestID: UUID) throws -> UIStableID {
        guard let source = retained, source.requestID == requestID else { throw stale() }
        try validate(source); return source.entry.record.itemID
    }
    func begin(requestID: UUID, validate: @escaping @MainActor () throws -> Void) throws {
        guard !accessing, !retiring, pending == nil, let source = retained,
              source.requestID == requestID, source.phase == .retained else { throw stale() }
        accessing = true; defer { accessing = false }
        try self.validate(source); try validate(); try self.validate(source)
        let rootReady = windowReady()
        try self.validate(source)
        guard try rootReady || originalContainerIsVisible(source) else { throw stale() }
        try self.validate(source)
        guard retained === source, pending == nil else { throw stale() }
        pending = Pending(source: source, validate: validate)
    }
    func apply(requestID: UUID) throws {
        guard !reporting, let value = pending, value.source === retained,
              value.source.requestID == requestID, !value.applying,
              value.source.phase == .retained, !value.source.parentApplied else { throw stale() }
        value.applying = true
        value.source.phase = .applyingParent
        do {
            try validatePending(value)
            let rootReady = windowReady()
            // Readiness is an original host callback. It may synchronously
            // retire this request; recheck the SAME pending owner before any
            // invocation of the original visibility setter.
            try validatePending(value)
            guard try rootReady || originalContainerIsVisible(value.source) else { throw stale() }
            try validatePending(value)
            if !value.source.initiallyVisible {
                // The unchanged original owner is the SOLE visibility writer.
                try value.source.catalog.reader.inspector.validate()
                try value.source.catalog.reader.inspector.apply()
            }
            guard pending === value, retained === value.source, value.applying,
                  value.source.phase == .applyingParent else { throw stale() }
            value.source.phase = .presented
            try value.source.catalog.reader.inspector.validate()
            try validatePending(value)
            guard pending === value, retained === value.source, value.applying else { throw stale() }
            value.source.parentApplied = true; value.applying = false
            changed?()
            try validatePending(value)
        } catch { retire(); throw error }
    }

    /// Only the retained original command/deadline reaches this continuation.
    /// UIKit layout/real load publication merely wakes it; neither grants work.
    func renderOriginalIfReady(requestID: UUID) throws {
        guard let value = pending, value.source === retained,
              value.source.requestID == requestID, value.source.parentApplied,
              value.source.phase == .presented, !value.source.rendering else { return }
        let source = value.source
        source.rendering = true; defer { source.rendering = false }
        do {
            try validatePending(value)
            let rootReady = windowReady()
            try validatePending(value)
            try joinOriginalHostIfReady(source)
            guard let host = source.host, let hostView = host.view else { return }
            // The original phone Inspector is itself a UIKit sheet. Only its
            // exact retained visible container may replace root readiness;
            // unrelated presentations still fail the actual controller walk.
            guard try rootReady || originalContainerIsVisible(source) else { return }
            try validatePending(value)
            let state = try source.catalog.reader.workspaceOwner.read()
            if source.initialPeek && !source.expandedPeek {
                guard state.isPeek, let expansion = host.context.expandOriginalPeek,
                      let detent = source.workspaceRevision.detent, detent < .max,
                      hostView.window === (try source.window.validate()) else { throw stale() }
                // Readiness, workspace and window getters above are callbacks.
                // A retired request has no permission to invoke the original
                // expansion even when those getters returned their old values.
                try validatePending(value)
                // Exactly the existing original Peek expansion callback.
                // It is one declared detent write, never a new sheet/renderer.
                expansion()
                source.expandedPeek = true
                try validatePending(value)
                return
            }
            guard !state.isPeek else { throw stale() }
            try joinOriginalPanelIfReady(source)
            guard let panel = source.panel, let original = source.reveal,
                  let layout = panel.layoutRevision else { return }
            try requireVisibleHost(source)
            _ = try original.reveal(layoutRevision: layout) { [weak self, weak value] in
                guard let self, let value, value.source.rendering else {
                    throw UIRouteError(.staleState, "native_inspector_reveal_retired")
                }
                try self.validatePending(value)
            }
            try validatePending(value)
        } catch { retire(); throw error }
    }

    func observedItem(requestID: UUID) -> UIStableID? {
        guard let source = pending?.source ?? completed, source.requestID == requestID else { return nil }
        do { try validateVisible(source); return source.entry.record.itemID } catch { return nil }
    }
    func hasVisibleSurface(requestID: UUID) -> Bool {
        guard let source = pending?.source ?? completed, source.requestID == requestID else { return false }
        return (try? validateVisible(source)) != nil
    }
    func withValidatedSurface<T>(requestID: UUID, report: @MainActor () throws -> T) throws -> T {
        guard !reporting, let value = pending, value.source.requestID == requestID else { throw stale() }
        reporting = true; defer { reporting = false }
        try requireSurface(value)
        let result = try report()
        try requireSurface(value)
        return result
    }
    func validateCompletedSurface(requestID: UUID) throws {
        guard let source = completed, source.requestID == requestID else { throw stale() }
        try validateVisible(source)
    }
    func finish(requestID: UUID, completed success: Bool) {
        guard !accessing, let value = pending, value.source.requestID == requestID else { return }
        accessing = true; defer { accessing = false }
        let accepted = success && (try? requireSurface(value)) != nil
        guard pending === value, retained === value.source, value.source.phase == .presented else { return }
        pending = nil
        if accepted { completed = value.source } else { retire() }
    }
    func releaseSource(requestID: UUID) {
        guard let source = retained, source.requestID == requestID else { return }
        if pending != nil || completed !== source { retire() }
        if retained === source { retained = nil }
    }
    func clearCompletedProof() { completed?.retire(); completed = nil }

    func attachWorkspace(_ original: MaktabahNativeInspectorWorkspace) {
        guard mounted, !retiring, original.binding === self else { return }
        if workspace === original { return }
        retire(); workspace = original; changed?()
    }
    func detachWorkspace(_ original: MaktabahNativeInspectorWorkspace) {
        guard workspace === original else { return }
        workspace = nil; host = nil; panel = nil; witnesses.removeAll(); retire(); changed?()
    }
    fileprivate func attachHost(token: UUID, registration: UUID, context: HostContext, view: MaktabahNativeInspectorMarker,
                                workspace original: MaktabahNativeInspectorWorkspace) {
        guard mounted, !retiring, workspace === original, original.binding === self,
              view.ownsRegistration(binding: self, workspace: original, attachment: registration, role: .host),
              let window = view.window,
              let state = try? original.read(), state.session === context.session,
              state.contentID == context.contentID, state.identity.repository === context.repository else { return }
        // The original getter may detach this exact marker while no Host has
        // been installed yet. A still-in-window UIView is not registration.
        guard mounted, !retiring, workspace === original, original.binding === self,
              view.window === window,
              view.ownsRegistration(binding: self, workspace: original, attachment: registration, role: .host) else { return }
        if let host, host.token == token, host.registration == registration,
           host.view === view, host.context.matches(context) { return }
        if let previous = host {
            retire()
            guard mounted, !retiring, host === previous, workspace === original, original.binding === self,
                  view.window === window,
                  view.ownsRegistration(binding: self, workspace: original, attachment: registration, role: .host) else { return }
            panel = nil; witnesses.removeAll()
        }
        let next = Host(token: token, registration: registration, context: context, view: view)
        host = next
        if let source = pending?.source ?? retained {
            if source.host == nil, source.entry.record.reference.kind == .tool,
               source.phase == .presented, source.parentApplied {
                do { try joinOriginalHostIfReady(source) } catch { retire() }
            } else if source.host !== next { retire() }
        }
        changed?()
    }
    fileprivate func detachHost(token: UUID, view: UIView) {
        guard let host, host.token == token, host.view === view else { return }
        self.host = nil; panel = nil; witnesses.removeAll(); retire(); changed?()
    }
    fileprivate func attachPanel(token: UUID, registration: UUID, original: TorahInspectorOriginalPanel,
                                 context: HostContext, view: MaktabahNativeInspectorMarker) {
        guard mounted, !retiring, let workspace, workspace.binding === self,
              view.ownsRegistration(binding: self, workspace: workspace, attachment: registration, role: .panel(original)),
              let window = view.window, let host, host.context.matches(context),
              original.repository === context.repository else { return }
        if let panel, panel.token == token, panel.registration == registration, panel.view === view, panel.host === host,
           panel.original.ownerID == original.ownerID, panel.original.focus == original.focus,
           panel.original.repository === original.repository {
            panel.original = original
            return
        }
        if let previous = panel {
            retire()
            guard mounted, !retiring, self.panel === previous, self.host === host,
                  self.workspace === workspace, workspace.binding === self, view.window === window,
                  view.ownsRegistration(binding: self, workspace: workspace, attachment: registration, role: .panel(original)) else { return }
            catalogSource?.discardRows()
        }
        let next = Panel(token: token, registration: registration, host: host, original: original, view: view)
        panel = next
        if let source = pending?.source ?? retained {
            if source.panel == nil, source.entry.record.reference.kind == .tool,
               source.phase == .presented, source.parentApplied {
                do { try joinOriginalPanelIfReady(source) } catch { retire() }
            } else if source.panel !== next { retire() }
        }
        changed?()
    }
    fileprivate func detachPanel(token: UUID, view: UIView) {
        guard let panel, panel.token == token, panel.view === view else { return }
        self.panel = nil; witnesses.removeAll(); retire(); changed?()
    }
    fileprivate func attachWitness(token: UUID, registration: UUID, ownerID: UUID, anchor: TorahInspectorNavigationAnchor,
                                  context: HostContext, view: MaktabahNativeInspectorMarker) {
        guard mounted, !retiring, let workspace, workspace.binding === self,
              view.ownsRegistration(binding: self, workspace: workspace, attachment: registration, role: .target(ownerID, anchor)),
              let window = view.window, let host, host.context.matches(context) else { return }
        let previous = witnesses[token]
        if let old = previous, old.registration == registration, old.host === host, old.view === view,
           old.ownerID == ownerID, old.anchor == anchor { return }
        if let source = pending?.source ?? completed, source.witness?.token == token {
            retire()
            guard mounted, !retiring, witnesses[token] === previous, self.host === host,
                  self.workspace === workspace, workspace.binding === self, view.window === window,
                  view.ownsRegistration(binding: self, workspace: workspace, attachment: registration, role: .target(ownerID, anchor)) else { return }
        }
        witnesses[token] = Witness(token: token, registration: registration, ownerID: ownerID, anchor: anchor, host: host, view: view)
    }
    fileprivate func detachWitness(token: UUID, view: UIView) {
        guard let old = witnesses[token], old.view === view else { return }
        witnesses.removeValue(forKey: token)
        if let source = pending?.source ?? completed, source.witness === old { retire() }
        changed?()
    }
    fileprivate func originalLayout(token: UUID, view: UIView, panelLayout: Bool) {
        guard mounted, !retiring else { return }
        if panelLayout {
            guard let panel, panel.token == token, panel.view === view else { return }
            if let old = panel.layoutRevision { panel.layoutRevision = old == .max ? nil : old + 1 }
        } else if host?.token != token && witnesses[token]?.view !== view { return }
        changed?()
    }

    func retire() {
        guard !retiring else { return }
        retiring = true; defer { retiring = false }
        if let old = revision { revision = old == .max ? nil : old + 1 }
        let active = retained != nil || pending != nil || completed != nil
        retained?.retire(); completed?.retire(); retained = nil; pending = nil; completed = nil
        catalogSource?.reader.retire(); catalogSource?.discardRows(); catalogSource = nil
        if active { invalidated?() }
    }
    func unmount() {
        mounted = false; retire(); workspace = nil; host = nil; panel = nil; witnesses.removeAll()
        changed = nil; invalidated = nil
    }

    private func originalReveal(_ source: Source, panel: Panel) throws -> TorahInspectorNavigationRetention {
        let target: TorahInspectorNavigationTarget
        if let selected = source.entry.target { target = selected }
        else {
            let matches = try panel.original.currentState().targets.filter {
                $0.anchor == .tool(TorahStudyToolID(rawValue: source.entry.record.reference.tool.rawValue))
            }
            guard matches.count == 1, let selected = matches.first else { throw stale() }
            target = selected
        }
        return try panel.original.retain(target)
    }
    private func joinOriginalHostIfReady(_ source: Source) throws {
        guard source.phase == .presented, source.parentApplied else { throw stale() }
        if source.host != nil { guard source.host === host else { throw stale() }; return }
        guard source.entry.record.reference.kind == .tool else { throw stale() }
        guard let host else { return }
        try validate(source)
        let state = try source.catalog.reader.workspaceOwner.read()
        guard host.context.session === source.catalog.reader.originalSession,
              host.context.contentID == source.catalog.reader.contentID,
              state.identity.repository === host.context.repository,
              host.view?.window === (try source.window.validate()) else { throw stale() }
        source.host = host
        try validate(source)
    }
    private func joinOriginalPanelIfReady(_ source: Source) throws {
        if source.panel != nil { guard source.panel === panel else { throw stale() }; return }
        guard source.entry.record.reference.kind == .tool, source.phase == .presented,
              source.parentApplied, let host = source.host else { throw stale() }
        guard let panel, panel.host === host else { return }
        try validate(source)
        guard panel.original.repository === host.context.repository,
              panel.original.focus.selection == host.context.selection,
              panel.view?.window === (try source.window.validate()) else { throw stale() }
        let reveal = try originalReveal(source, panel: panel)
        guard self.panel === panel, self.host === host, source.phase == .presented else { reveal.retire(); throw stale() }
        source.panel = panel; source.reveal = reveal
        try validate(source)
    }
    private func validate(_ source: Source) throws {
        guard !validatingSource, mounted, !retiring, source.phase != .retired, retained === source || completed === source,
              catalogSource === source.catalog, workspace === source.catalog.reader.workspaceOwner else { throw stale() }
        validatingSource = true; defer { validatingSource = false }
        try source.catalog.reader.validate(); try source.foreign(); _ = try source.window.validate()
        let original = source.catalog.reader.workspaceOwner
        let state = try original.read(), current = original.revision
        let toolWritten = source.reveal?.originalToolWriteCommitted == true
        let expectedToolRevision = try advanced(source.workspaceRevision.tool, by: toolWritten ? 1 : 0)
        let expectedDetentRevision = try advanced(source.workspaceRevision.detent, by: source.expandedPeek ? 1 : 0)
        let presented = source.phase == .presented
        let visibility = source.visibilityRevision + ((!source.initiallyVisible && presented) ? 1 : 0)
        guard current.available, current.mount == source.workspaceRevision.mount,
              current.session == source.workspaceRevision.session, current.foreign == source.workspaceRevision.foreign,
              current.tool == expectedToolRevision, current.detent == expectedDetentRevision,
              state.tool.rawValue == (toolWritten ? source.entry.record.reference.tool.rawValue : source.initialTool.rawValue),
              state.isPeek == (source.initialPeek && !source.expandedPeek),
              source.catalog.reader.reader.nativeInspectorPresentationRevision == visibility,
              source.catalog.reader.reader.readerInspectorVisible == (source.initiallyVisible || presented),
              source.host == nil || source.host === host,
              source.panel == nil || source.panel === panel else { throw stale() }
        if let host = source.host {
            guard host.context.session === state.session, host.context.contentID == state.contentID,
                  state.identity.repository === host.context.repository else { throw stale() }
        }
        try validateRegistrations(source)
        if source.entry.record.reference.kind != .tool { try source.catalog.originalRows?.validate() }
        try source.reveal?.validate()
        try source.catalog.reader.validate(); try source.foreign(); _ = try source.window.validate()
        try source.catalog.reader.validate()
        guard mounted, source.phase != .retired, retained === source || completed === source,
              catalogSource === source.catalog, workspace === original,
              original.revision == current,
              source.catalog.reader.reader.nativeInspectorPresentationRevision == visibility,
              source.catalog.reader.reader.readerInspectorVisible == (source.initiallyVisible || presented) else { throw stale() }
        try validateRegistrations(source)
    }
    /// Only fixed marker identities are read here. Source/host callbacks never
    /// supply a substitute registration for a previously captured view.
    private func validateRegistrations(_ source: Source) throws {
        let original = source.catalog.reader.workspaceOwner
        if let host = source.host {
            guard self.host === host, let view = host.view,
                  view.ownsRegistration(binding: self, workspace: original, attachment: host.registration, role: .host) else { throw stale() }
        }
        if let panel = source.panel {
            guard self.panel === panel, panel.host === source.host, let view = panel.view,
                  view.ownsRegistration(binding: self, workspace: original, attachment: panel.registration,
                                        role: .panel(panel.original)) else { throw stale() }
        }
        if let witness = source.witness {
            guard witnesses[witness.token] === witness, witness.host === source.host,
                  source.panel?.original.ownerID == witness.ownerID,
                  source.reveal?.target.anchor == witness.anchor, let view = witness.view,
                  view.ownsRegistration(binding: self, workspace: original, attachment: witness.registration,
                                        role: .target(witness.ownerID, witness.anchor)) else { throw stale() }
        }
    }
    private func validatePending(_ value: Pending) throws {
        guard !checking, pending === value, retained === value.source else { throw stale() }
        checking = true; defer { checking = false }
        try validate(value.source); try value.validate(); try validate(value.source)
        guard pending === value, retained === value.source else { throw stale() }
    }
    private func originalContainerIsVisible(_ source: Source) throws -> Bool {
        try validate(source)
        guard let host = source.host, self.host === host, let view = host.view,
              let window = try? source.window.validate(),
              source.catalog.reader.workspaceOwner.view?.window === window else { return false }
        let visible = MaktabahNativeInspectorGeometry.visible(view, window: window, sceneID: sceneID)
        try validate(source)
        guard source.host === host, self.host === host, host.view === view, view.window === window else { throw stale() }
        return visible
    }
    private func requireVisibleHost(_ source: Source) throws {
        try validate(source)
        guard try originalContainerIsVisible(source),
              !(try source.catalog.reader.workspaceOwner.read()).isPeek else {
            throw UIRouteError(.unavailable, "native_inspector_original_host_not_visible")
        }
        try validate(source)
    }
    private func validateVisible(_ source: Source) throws {
        try validate(source); try requireVisibleHost(source)
        guard source.phase == .presented, source.parentApplied, !source.rendering,
              let reveal = source.reveal, try reveal.isReadyForOriginalWitness(),
              let panel = source.panel, let host = source.host else { throw stale() }
        let matches = witnesses.values.filter {
            $0.host === host && $0.ownerID == panel.original.ownerID && $0.anchor == reveal.target.anchor
        }
        guard matches.count == 1, let witness = matches.first, let view = witness.view,
              source.witness == nil || source.witness === witness,
              view.ownsRegistration(binding: self, workspace: source.catalog.reader.workspaceOwner,
                                    attachment: witness.registration, role: .target(witness.ownerID, witness.anchor)),
              let hostView = host.view, let window = try? source.window.validate(),
              MaktabahNativeInspectorGeometry.within(view, host: hostView, window: window),
              MaktabahNativeInspectorGeometry.visible(view, window: window, sceneID: sceneID) else {
            throw UIRouteError(.unavailable, "native_inspector_original_target_not_visible")
        }
        // This captures actual evidence once, never an execution permission.
        source.witness = witness
        try validate(source)
    }
    private func requireSurface(_ value: Pending) throws {
        try validatePending(value); try validateVisible(value.source); try validatePending(value)
    }
    private func advanced(_ value: UInt64?, by amount: UInt64) throws -> UInt64 {
        guard let value else { throw stale() }
        let (result, overflow) = value.addingReportingOverflow(amount)
        guard !overflow else { throw stale() }; return result
    }
    private func stale() -> UIRouteError { .init(.staleState, "native_inspector_selection_source_changed") }
}

struct MaktabahNativeInspectorWorkspaceWitness: UIViewRepresentable {
    let workspace: MaktabahNativeInspectorWorkspace
    let binding: MaktabahNativeInspectorSelection?
    let access: MaktabahNativeInspectorWorkspace.Access
    func makeUIView(context: Context) -> Marker { Marker(workspace: workspace) }
    func updateUIView(_ view: Marker, context: Context) {
        guard view.workspace === workspace else { view.detach(); return }
        view.binding = binding; view.access = access; view.register()
    }
    static func dismantleUIView(_ view: Marker, coordinator: ()) { view.detach() }
    final class Marker: UIView {
        weak var workspace: MaktabahNativeInspectorWorkspace?
        weak var binding: MaktabahNativeInspectorSelection?
        var access: MaktabahNativeInspectorWorkspace.Access?
        private var active = true
        init(workspace: MaktabahNativeInspectorWorkspace) {
            self.workspace = workspace; super.init(frame: .zero)
            backgroundColor = .clear; isUserInteractionEnabled = false; isAccessibilityElement = false
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
        func register() {
            guard active, window != nil, let workspace, let access else { return }
            workspace.attach(binding: binding, access: access, view: self)
        }
        func detach() {
            guard active else { return }; active = false
            workspace?.detach(view: self); workspace = nil; binding = nil; access = nil
        }
        override func didMoveToWindow() {
            super.didMoveToWindow()
            if window == nil { workspace?.detach(view: self) } else { register() }
        }
        override func layoutSubviews() { super.layoutSubviews(); register() }
    }
}

struct MaktabahNativeInspectorMarkerView: UIViewRepresentable {
    struct Identity: Hashable {
        let workspace: UUID
        let session: ObjectIdentifier
        let repository: ObjectIdentifier
        let selection: TorahInspectorSelection
        let contentID: UUID
        let role: MaktabahNativeInspectorMarker.Role.Identity
    }
    let workspace: MaktabahNativeInspectorWorkspace
    let context: MaktabahNativeInspectorSelection.HostContext
    let role: MaktabahNativeInspectorMarker.Role
    var identity: Identity { .init(workspace: workspace.id, session: ObjectIdentifier(context.session),
        repository: ObjectIdentifier(context.repository), selection: context.selection,
        contentID: context.contentID, role: role.identity) }
    func makeUIView(context: Context) -> MaktabahNativeInspectorMarker {
        MaktabahNativeInspectorMarker(workspace: workspace, context: self.context, role: role)
    }
    func updateUIView(_ view: MaktabahNativeInspectorMarker, context: Context) {
        guard view.matches(workspace: workspace, context: self.context, role: role) else { view.detach(); return }
        view.role = role; view.register()
    }
    static func dismantleUIView(_ view: MaktabahNativeInspectorMarker, coordinator: ()) { view.detach() }
}

@MainActor final class MaktabahNativeInspectorMarker: UIView {
    enum Role {
        case host
        case panel(TorahInspectorOriginalPanel)
        case target(UUID, TorahInspectorNavigationAnchor)
        struct Identity: Hashable {
            let kind: Int
            let owner: UUID?
            let focus: TorahInspectorFocus?
            let anchor: TorahInspectorNavigationAnchor?
        }
        var identity: Identity {
            switch self {
            case .host: .init(kind: 0, owner: nil, focus: nil, anchor: nil)
            case .panel(let panel): .init(kind: 1, owner: panel.ownerID, focus: panel.focus, anchor: nil)
            case .target(let owner, let anchor): .init(kind: 2, owner: owner, focus: nil, anchor: anchor)
            }
        }
    }
    let token = UUID()
    let context: MaktabahNativeInspectorSelection.HostContext
    weak var workspace: MaktabahNativeInspectorWorkspace?
    var role: Role
    private weak var registered: MaktabahNativeInspectorSelection?
    private var active = true
    private var attachment = UUID()
    private var waitingCoordinator: ObjectIdentifier?
    private var previous: MaktabahNativeSavedResultsGeometry.Evidence?
    init(workspace: MaktabahNativeInspectorWorkspace,
         context: MaktabahNativeInspectorSelection.HostContext, role: Role) {
        self.workspace = workspace; self.context = context; self.role = role
        super.init(frame: .zero)
        backgroundColor = .clear; isUserInteractionEnabled = false; isAccessibilityElement = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    func matches(workspace: MaktabahNativeInspectorWorkspace,
                 context: MaktabahNativeInspectorSelection.HostContext, role: Role) -> Bool {
        active && self.workspace === workspace && self.context.matches(context) && self.role.identity == role.identity
    }
    /// Fixed local lifecycle metadata only; never source validation or routing
    /// permission. A detached marker cannot be revived by its still-live view.
    fileprivate func ownsRegistration(binding: MaktabahNativeInspectorSelection,
                                       workspace: MaktabahNativeInspectorWorkspace,
                                       attachment: UUID, role: Role) -> Bool {
        active && registered === binding && self.workspace === workspace
            && self.attachment == attachment && self.role.identity == role.identity && window != nil
    }
    func register() {
        guard active, let workspace, let window else { return }
        workspace.remember(self)
        guard let binding = workspace.binding else { return }
        if let old = registered, old !== binding {
            // Detach can synchronously retire/rebind this actual marker. Clear
            // its old ownership and consume the attachment BEFORE that call.
            registered = nil; attachment = UUID(); waitingCoordinator = nil
            let capturedAttachment = attachment, capturedRole = role.identity
            removeRegistration(from: old)
            guard active, self.workspace === workspace, self.window === window,
                  workspace.binding === binding, attachment == capturedAttachment,
                  role.identity == capturedRole, registered == nil else { return }
        }
        registered = binding
        let capturedAttachment = attachment
        switch role {
        case .host: binding.attachHost(token: token, registration: capturedAttachment, context: context, view: self, workspace: workspace)
        case .panel(let panel): binding.attachPanel(token: token, registration: capturedAttachment, original: panel, context: context, view: self)
        case .target(let owner, let anchor):
            binding.attachWitness(token: token, registration: capturedAttachment, ownerID: owner, anchor: anchor, context: context, view: self)
        }
    }
    func detach() {
        guard active else { return }; active = false
        attachment = UUID(); waitingCoordinator = nil
        if let registered { removeRegistration(from: registered) }
        workspace?.forget(self); workspace = nil; registered = nil
    }
    private func removeRegistration(from binding: MaktabahNativeInspectorSelection) {
        switch role {
        case .host: binding.detachHost(token: token, view: self)
        case .panel: binding.detachPanel(token: token, view: self)
        case .target: binding.detachWitness(token: token, view: self)
        }
    }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window == nil {
            attachment = UUID(); waitingCoordinator = nil; previous = nil
            if let registered { removeRegistration(from: registered) }
            registered = nil
        } else { register(); publishGeometry(originalLayout: false) }
    }
    override func didMoveToSuperview() { super.didMoveToSuperview(); register() }
    override func layoutSubviews() { super.layoutSubviews(); register(); publishGeometry(originalLayout: true) }
    private func publishGeometry(originalLayout: Bool) {
        guard active, let binding = registered, workspace?.binding === binding else { return }
        let actual = MaktabahNativeSavedResultsGeometry.evidence(self)
        let panelLayout: Bool
        if case .panel = role { panelLayout = originalLayout } else { panelLayout = false }
        if actual != previous || panelLayout {
            previous = actual
            binding.originalLayout(token: token, view: self, panelLayout: panelLayout)
        }
        guard active, registered === binding, workspace?.binding === binding else { return }
        guard let coordinator = MaktabahNativeSavedResultsGeometry.transitionCoordinator(self) else {
            waitingCoordinator = nil; return
        }
        let identity = ObjectIdentifier(coordinator as AnyObject)
        guard waitingCoordinator != identity else { return }
        waitingCoordinator = identity
        let capturedAttachment = attachment
        coordinator.animate(alongsideTransition: nil) { [weak self, weak binding] _ in
            guard let self, let binding, self.active, self.registered === binding,
                  self.workspace?.binding === binding, self.attachment == capturedAttachment,
                  self.waitingCoordinator == identity else { return }
            // Real transition completion wakes geometry only. It must not
            // manufacture the strictly newer original expansion-layout event.
            self.publishGeometry(originalLayout: false)
        }
    }
}

@MainActor private enum MaktabahNativeInspectorGeometry {
    static func visible(_ view: UIView, window: UIWindow, sceneID: UIStableID) -> Bool {
        guard view.window === window, window.windowScene?.session.persistentIdentifier == sceneID.rawValue,
              let root = window.rootViewController, root.viewIfLoaded?.window === window else { return false }
        let value = MaktabahNativeSavedResultsGeometry.evidence(view)
        guard value.foreground, !value.hidden, !value.transitioning, value.alpha >= 0.95,
              value.frame.origin.x.isFinite, value.frame.origin.y.isFinite,
              value.frame.width.isFinite, value.frame.height.isFinite,
              value.frame.width > 1, value.frame.height > 1, !value.visible.isNull,
              value.visible.width * value.visible.height >= value.frame.width * value.frame.height * 0.98 else { return false }
        // Preserve the original window's complete controller-tree refusal,
        // allowing only a presentation which ACTUALLY contains this original
        // Inspector view. A foreign child-controller sheet is not root-ready.
        var controllers = [root], visited: Set<ObjectIdentifier> = []
        while let controller = controllers.popLast() {
            guard visited.insert(ObjectIdentifier(controller)).inserted else { continue }
            guard !controller.isBeingPresented, !controller.isBeingDismissed,
                  controller.transitionCoordinator == nil else { return false }
            if let presented = controller.presentedViewController {
                guard let presentedView = presented.viewIfLoaded,
                      view.isDescendant(of: presentedView) else { return false }
                controllers.append(presented)
            }
            controllers.append(contentsOf: controller.children)
        }
        return true
    }
    static func within(_ view: UIView, host: UIView, window: UIWindow) -> Bool {
        guard view.window === window, host.window === window else { return false }
        let row = view.convert(view.bounds, to: window), original = host.convert(host.bounds, to: window)
        let area = row.width * row.height, intersection = row.intersection(original)
        return area.isFinite && area > 1 && !intersection.isNull
            && intersection.width * intersection.height >= area * 0.98
    }
}
#endif
