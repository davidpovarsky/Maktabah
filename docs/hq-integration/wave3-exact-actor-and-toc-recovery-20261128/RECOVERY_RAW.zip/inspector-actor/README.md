# Exact Inspector App source recovery

This scope recovers only the previously recorded Inspector App source `MaktabahNativeInspectorSelection.swift`, 66,811 bytes, SHA-256 `e718da5aef04543036e150278154b854611a75845514286beea5c91113be7c54`.

The full predecessor is an actual existing member of the preserved FFA proposal capsule. The capsule uses content-addressed `blobs/<sha256>` entries, so the initial direct ZIP-filename lookup returned no source-name matches; the original manifest resolves the exact original app-candidate path to the complete 66,789-byte predecessor `04565af26ebe46c6d8ea01c788043f9b4a900dc04c9c01c2794439ee5c47ab8b`. The capsule and its complete manifest are independently hash-joined in RECOVERY.json.

Only the two recorded declaration annotations were added:

- `private final class Catalog` → `@MainActor private final class Catalog`
- `private final class Source` → `@MainActor private final class Source`

The first and only overlay attempt matched both the complete target length and SHA-256. No broad syntax search, candidate invention, hash relaxation, assertion change or test change was used. The exact inverse removes only those two annotations and reproduces all predecessor bytes.

The complete predecessor is retained under baseline/, and the exact recovered source is under candidate/. SOURCE_CAPSULE_MANIFEST.json retains the original manifest bytes, not a reconstructed manifest. INPUT_READS.json preserves the initial no-filename-match observation, the actual content-addressed source join and the successful first attempt. The unavailable original staging-script path is recorded with its actual status observed during recovery; this work does not claim to recover that script or its lost execution outputs.

This is source-byte recovery only. No Swift parse/typecheck, compiler, test, native operation, signing, authentication, Git operation or adoption into Root's product source occurred. Original source/capsule files were not edited. Root retains integration authority.

The fresh rootfs scope is bounded to 4 MiB of actual allocation including directories and all artifacts, with the original floor of 1,593,835,520 bytes plus a 4 MiB reserve checked before allocations. No Data-volume output is created.
