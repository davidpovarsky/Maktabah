if not __debug__:
    raise SystemExit("Optimized Python is refused before recovery actions.")
import datetime
import difflib
import hashlib
import io
import json
import os
import pathlib
import stat
import zipfile

def require(ok,message):
    if not ok:
        raise RuntimeError(message)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def jb(value):
    return (json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False)+"\n").encode()
def ident(s):
    return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def free():
    s=os.statvfs("/home/ubuntu")
    return s.f_bavail*s.f_frsize

cfg=CONFIG
out=pathlib.Path(cfg["output"])
require(out.parent==pathlib.Path("/home/ubuntu"),"unexpected recovery parent")
require(not out.exists() and not out.is_symlink(),"fresh recovery directory must be absent")
free_before=free()
require(free_before>=cfg["root_floor"]+cfg["cap"],"original root floor plus full reserve unavailable")
p=pathlib.Path(cfg["capsule"])
before=p.lstat()
require(stat.S_ISREG(before.st_mode) and before.st_nlink==1,"capsule is not single-link regular")
fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
try:
    require(ident(os.fstat(fd))==ident(before),"capsule identity changed before open")
    with os.fdopen(fd,"rb",closefd=False) as f:
        capsule=f.read()
    require(ident(os.fstat(fd))==ident(before),"capsule changed while reading")
finally:
    os.close(fd)
require(len(capsule)==cfg["capsule_bytes"] and sha(capsule)==cfg["capsule_sha256"],"actual FFA capsule hash/length mismatch")
with zipfile.ZipFile(io.BytesIO(capsule)) as z:
    names=z.namelist()
    require(len(names)==len(set(names))==547,"capsule membership differs from original read")
    manifest_bytes=z.read("MANIFEST.json")
    require(len(manifest_bytes)==cfg["capsule_manifest_bytes"] and sha(manifest_bytes)==cfg["capsule_manifest_sha256"],"original full manifest mismatch")
    manifest=json.loads(manifest_bytes)
    rows=[r for r in manifest["files"] if r["path"]==cfg["source_path"]]
    require(len(rows)==1,"original app source manifest row not unique")
    row=rows[0]
    require(row["bytes"]==cfg["predecessor_bytes"] and row["sha256"]==cfg["predecessor_sha256"] and row["mode"]==420,"predecessor manifest pin mismatch")
    original=z.read("blobs/"+cfg["predecessor_sha256"])
require(len(original)==cfg["predecessor_bytes"] and sha(original)==cfg["predecessor_sha256"],"complete original predecessor mismatch")
candidate=original
changes=[]
for name in ("Catalog","Source"):
    old=("    private final class "+name+" {\n").encode()
    new=("    @MainActor private final class "+name+" {\n").encode()
    require(candidate.count(old)==1,"actual declaration is not unique: "+name)
    changes.append({"declaration":name,"before":old.decode(),"after":new.decode(),"count":1})
    candidate=candidate.replace(old,new,1)
require(len(candidate)==cfg["target_bytes"] and sha(candidate)==cfg["target_sha256"],"two-annotation overlay did not match exact target")
inverse=candidate
for c in reversed(changes):
    old=c["before"].encode()
    new=c["after"].encode()
    require(inverse.count(new)==1,"inverse declaration not unique")
    inverse=inverse.replace(new,old,1)
require(inverse==original,"full inverse is not byte-exact")
patch="".join(difflib.unified_diff(original.decode().splitlines(keepends=True),candidate.decode().splitlines(keepends=True),
                                 fromfile="baseline/MaktabahNativeInspectorSelection.swift",
                                 tofile="candidate/MaktabahNativeInspectorSelection.swift")).encode()
missing_path=pathlib.Path(cfg["unavailable_staging_script"])
try:
    q=missing_path.lstat()
    staging_status={"status":"PRESENT_NOT_READ_OR_EXECUTED","bytes":q.st_size,"mode":stat.S_IMODE(q.st_mode)}
except FileNotFoundError:
    staging_status={"status":"ABSENT","error":"FileNotFoundError"}
except PermissionError:
    staging_status={"status":"UNAVAILABLE_PERMISSION_ERROR","error":"PermissionError"}
require(ident(p.lstat())==ident(before),"capsule identity changed before preservation")
require(free()>=cfg["root_floor"]+cfg["cap"],"root floor lost before output allocation")
out.mkdir(mode=0o755)
def allocation():
    n=0
    for base,ds,fs in os.walk(out,followlinks=False):
        s=pathlib.Path(base).lstat()
        require(stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode),"invalid output directory")
        n+=s.st_blocks*512
        for name in ds:
            q=(pathlib.Path(base)/name).lstat()
            require(stat.S_ISDIR(q.st_mode) and not stat.S_ISLNK(q.st_mode),"output link directory")
        for name in fs:
            q=(pathlib.Path(base)/name).lstat()
            require(stat.S_ISREG(q.st_mode) and q.st_nlink==1,"output linked/nonregular file")
            n+=q.st_blocks*512
    return n
checks=[]
def guard(step,extra=0):
    f=free()
    used=allocation()
    require(f>=cfg["root_floor"]+cfg["cap"],"root floor/reserve lost at "+step)
    require(used+extra<=cfg["cap"],"4 MiB recovery allocated budget exceeded at "+step)
    checks.append({"step":step,"rootfs_free_bytes":f,"allocated_bytes":used,"planned_additional_bytes":extra})
for child in ("baseline","candidate"):
    guard("before directory "+child,4096)
    (out/child).mkdir(mode=0o755)
def write(rel,data):
    target=out/rel
    require(target.parent in (out,out/"baseline",out/"candidate"),"unexpected output path")
    guard("before "+rel,((len(data)+4095)//4096)*4096)
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o644)
    try:
        with os.fdopen(fd,"wb",closefd=False) as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
    finally:
        os.close(fd)
    require(target.read_bytes()==data,"preserved file readback mismatch: "+rel)
    guard("after "+rel)
write("baseline/MaktabahNativeInspectorSelection.swift",original)
write("candidate/MaktabahNativeInspectorSelection.swift",candidate)
write("SOURCE_CAPSULE_MANIFEST.json",manifest_bytes)
write("EXACT_RECOVERY.patch",patch)
write("INPUT_READS.json",jb(cfg))
write("RECOVER.py",RECOVER_SOURCE.encode())
write("README.md",README_TEXT.encode())
require(ident(p.lstat())==ident(before),"original capsule changed during output")
proof={"schema":"otzaria.inspector.exact-source-recovery.v1","status":"EXACT_TARGET_BYTES_RECOVERED",
       "time_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
       "capsule":{"path":str(p),"bytes":len(capsule),"sha256":sha(capsule),"members":547,"modified":False},
       "original_manifest":{"bytes":len(manifest_bytes),"sha256":sha(manifest_bytes),"source_row":row},
       "predecessor":{"path":"baseline/MaktabahNativeInspectorSelection.swift","bytes":len(original),"sha256":sha(original)},
       "recovered":{"path":"candidate/MaktabahNativeInspectorSelection.swift","bytes":len(candidate),"sha256":sha(candidate)},
       "actual_changes":changes,"overlay_attempts":1,"failed_overlay_attempts":0,"full_inverse_byte_exact":True,
       "initial_direct_filename_lookup_matches":0,"direct_lookup_limitation":"Archive is content-addressed; exact original manifest resolved full source bytes.",
       "unavailable_original_staging_script":{"path":str(missing_path),**staging_status},
       "source_reconstruction_scope":"Only the two independently recorded declaration annotations, accepted solely on full target SHA-256 and length.",
       "compiler_typecheck_tests_native_execution":False,"root_git_or_original_source_writes":False,"data_writes":False,
       "integration_or_release_qualification":False,"private_keys_or_authentication":False,
       "resources":{"floor_bytes":cfg["root_floor"],"reserve_and_cap_bytes":cfg["cap"],"free_before":free_before,"guard_events":checks}}
write("RECOVERY.json",jb(proof))
files=[]
for f in sorted(out.rglob("*")):
    if f.is_file():
        b=f.read_bytes()
        files.append({"path":f.relative_to(out).as_posix(),"bytes":len(b),"sha256":sha(b),"mode":stat.S_IMODE(f.stat().st_mode)})
require(len(files)==8,"unexpected artifact set before manifest")
write("RECOVERY_MANIFEST.json",jb({"schema":"otzaria.inspector.exact-recovery.manifest.v1","files":files,"manifest_self_excluded":True,
                                  "final_file_count":9,"raw_candidate_exact":True,"predecessor_preserved":True}))
guard("final scope")
result=[]
for f in sorted(out.rglob("*")):
    if f.is_file():
        b=f.read_bytes()
        result.append({"path":f.relative_to(out).as_posix(),"bytes":len(b),"sha256":sha(b)})
require(len(result)==9,"unexpected final artifact count")
require((out/"candidate/MaktabahNativeInspectorSelection.swift").read_bytes()==candidate,"final target bytes changed")
require((out/"baseline/MaktabahNativeInspectorSelection.swift").read_bytes()==original,"final predecessor bytes changed")
require(ident(p.lstat())==ident(before),"capsule changed before terminal receipt")
print(json.dumps({"status":"EXACT_TARGET_BYTES_RECOVERED","output":str(out),"files":result,"allocated_bytes":allocation(),
                  "rootfs_free_after":free(),"root_floor_plus_reserve":cfg["root_floor"]+cfg["cap"],
                  "source_byte_match":True,"full_inverse_byte_exact":True,"staging_script":staging_status,
                  "no_source_execution_tests_git_writes":True},sort_keys=True))
