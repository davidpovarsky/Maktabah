if not __debug__:
    raise SystemExit("Optimized Python is refused before recovery actions.")
import datetime
import difflib
import hashlib
import io
import json
import os
import pathlib
import stat
import zipfile

def require(ok,message):
    if not ok: raise RuntimeError(message)
def sha(b): return hashlib.sha256(b).hexdigest()
def jb(v): return (json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False)+"\n").encode()
def ident(s): return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def free():
    s=os.statvfs("/home/ubuntu")
    return s.f_bavail*s.f_frsize
def archive(path,size,expected):
    p=pathlib.Path(path); before=p.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink==1,"input archive must be single-link regular")
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        require(ident(os.fstat(fd))==ident(before),"input changed before read")
        with os.fdopen(fd,"rb",closefd=False) as f: data=f.read()
        require(ident(os.fstat(fd))==ident(before),"input changed during read")
    finally: os.close(fd)
    require(len(data)==size and sha(data)==expected,"complete archive pin mismatch")
    require(ident(p.lstat())==ident(before),"input name changed during read")
    return data,before

cfg=CONFIG
out=pathlib.Path(cfg["output"])
require(out.parent==pathlib.Path("/home/ubuntu"),"unexpected output parent")
require(not out.exists() and not out.is_symlink(),"new recovery scope must be absent")
free_before=free()
require(free_before>=cfg["root_floor"]+cfg["cap"],"original root floor plus full reserve unavailable")
ffa,ffa_identity=archive(cfg["ffa_path"],cfg["ffa_bytes"],cfg["ffa_sha256"])
library_zip,library_identity=archive(cfg["library_path"],cfg["library_zip_bytes"],cfg["library_zip_sha256"])
with zipfile.ZipFile(io.BytesIO(ffa)) as z:
    require(len(z.namelist())==len(set(z.namelist()))==547,"FFA membership differs from original")
    manifest_bytes=z.read("MANIFEST.json")
    require(len(manifest_bytes)==cfg["ffa_manifest_bytes"] and sha(manifest_bytes)==cfg["ffa_manifest_sha256"],"original FFA full manifest mismatch")
    manifest=json.loads(manifest_bytes)
    book_rows=[r for r in manifest["files"] if r["sha256"]==cfg["predecessor_sha256"]]
    require(len(book_rows)==2 and all(r["bytes"]==cfg["predecessor_bytes"] and r["mode"]==420 and r["path"].endswith("MaktabahNativeLibraryListPublication.swift") for r in book_rows),"BookInfo original path/hash join mismatch")
    original=z.read("blobs/"+cfg["predecessor_sha256"])
    library_old=z.read("blobs/"+cfg["library_old_sha256"])
with zipfile.ZipFile(io.BytesIO(library_zip)) as z:
    require(len(z.namelist())==len(set(z.namelist()))==2,"Library recovery capsule changed membership")
    library_new=z.read(cfg["library_member"])
for data,size,expected in ((original,cfg["predecessor_bytes"],cfg["predecessor_sha256"]),
                           (library_old,cfg["library_old_bytes"],cfg["library_old_sha256"]),
                           (library_new,cfg["library_new_bytes"],cfg["library_new_sha256"])):
    require(len(data)==size and sha(data)==expected,"full input source mismatch")
old_property=b"        nonisolated let invalidation = NativeComponentSourceObservation(read: {})\n"
new_property=b"        nonisolated let invalidation: NativeComponentSourceObservation\n"
old_init=b"        fileprivate init(owner: MaktabahNativeLibraryListPublication, revision: UInt64) {\n            self.owner = owner; self.revision = revision\n        }\n"
new_init=b"        fileprivate init(owner: MaktabahNativeLibraryListPublication, revision: UInt64) {\n            invalidation = NativeComponentSourceObservation(read: {})\n            self.owner = owner; self.revision = revision\n        }\n"
require(library_old.count(old_property)==1 and library_old.count(old_init)==1,"actual Library before pattern is not unique")
require(library_old.replace(old_property,new_property,1).replace(old_init,new_init,1)==library_new,"mechanical pattern does not reproduce complete actual recovered Library")
old_book_init=b"        fileprivate init(owner: MaktabahNativeLibraryListPublication) { self.owner = owner }\n"
new_book_init=b"        fileprivate init(owner: MaktabahNativeLibraryListPublication) {\n            invalidation = NativeComponentSourceObservation(read: {})\n            self.owner = owner\n        }\n"
changes=[(old_property,new_property,2),(old_init,new_init,1),(old_book_init,new_book_init,1)]
candidate=original
for old,new,count in changes:
    require(candidate.count(old)==count,"finite BookInfo declaration/initializer count mismatch")
    candidate=candidate.replace(old,new,count)
require(len(candidate)==cfg["target_bytes"] and sha(candidate)==cfg["target_sha256"],"finite overlay does not match exact target; recovery refused")
inverse=candidate
for old,new,count in reversed(changes):
    require(inverse.count(new)==count,"inverse replacement count mismatch")
    inverse=inverse.replace(new,old,count)
require(inverse==original,"complete inverse not byte-exact")
patch="".join(difflib.unified_diff(original.decode().splitlines(keepends=True),candidate.decode().splitlines(keepends=True),
                                 fromfile="baseline/MaktabahNativeLibraryListPublication.swift",tofile="candidate/MaktabahNativeLibraryListPublication.swift")).encode()
for path,before in ((cfg["ffa_path"],ffa_identity),(cfg["library_path"],library_identity)):
    require(ident(pathlib.Path(path).lstat())==ident(before),"source archive changed before preservation")
require(free()>=cfg["root_floor"]+cfg["cap"],"root floor/reserve lost before output allocation")
out.mkdir(mode=0o755)
def allocation():
    n=0
    for base,ds,fs in os.walk(out,followlinks=False):
        s=pathlib.Path(base).lstat()
        require(stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode),"invalid output directory")
        n+=s.st_blocks*512
        for name in ds:
            s=(pathlib.Path(base)/name).lstat()
            require(stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode),"output directory link")
        for name in fs:
            s=(pathlib.Path(base)/name).lstat()
            require(stat.S_ISREG(s.st_mode) and s.st_nlink==1,"linked/nonregular output")
            n+=s.st_blocks*512
    return n
checks=[]
def guard(step,extra=0):
    available=free(); used=allocation()
    require(available>=cfg["root_floor"]+cfg["cap"],"root floor/reserve lost at "+step)
    require(used+extra<=cfg["cap"],"4 MiB allocated budget exceeded at "+step)
    checks.append({"step":step,"free_bytes":available,"allocated_bytes":used,"planned_additional_bytes":extra})
for name in ("baseline","candidate","pattern-baseline","pattern-recovered"):
    guard("before directory "+name,4096)
    (out/name).mkdir(mode=0o755)
def write(rel,data):
    p=out/rel
    require(p.parent in (out,out/"baseline",out/"candidate",out/"pattern-baseline",out/"pattern-recovered"),"unexpected output path")
    guard("before "+rel,((len(data)+4095)//4096)*4096)
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o644)
    try:
        with os.fdopen(fd,"wb",closefd=False) as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
    finally: os.close(fd)
    require(p.read_bytes()==data,"artifact readback mismatch")
    guard("after "+rel)
filename="MaktabahNativeLibraryListPublication.swift"
write("baseline/"+filename,original)
write("candidate/"+filename,candidate)
write("pattern-baseline/"+filename,library_old)
write("pattern-recovered/"+filename,library_new)
write("SOURCE_CAPSULE_MANIFEST.json",manifest_bytes)
write("EXACT_RECOVERY.patch",patch)
write("INPUTS.json",jb(cfg))
write("RECOVER.py",RECOVER_SOURCE.encode())
write("README.md",README_TEXT.encode())
proof={"schema":"otzaria.bookinfo.actor-exact-source-recovery.v1","status":"EXACT_TARGET_BYTES_RECOVERED",
       "time_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
       "capsule":{"path":cfg["ffa_path"],"bytes":len(ffa),"sha256":sha(ffa),"modified":False},
       "original_manifest":{"bytes":len(manifest_bytes),"sha256":sha(manifest_bytes),"original_source_rows":book_rows},
       "library_pattern_capsule":{"path":cfg["library_path"],"bytes":len(library_zip),"sha256":sha(library_zip),"member":cfg["library_member"],"modified":False},
       "pattern_baseline":{"bytes":len(library_old),"sha256":sha(library_old)},
       "actual_pattern_recovered":{"bytes":len(library_new),"sha256":sha(library_new)},
       "full_actual_library_pattern_join":True,
       "predecessor":{"path":"baseline/"+filename,"bytes":len(original),"sha256":sha(original)},
       "recovered":{"path":"candidate/"+filename,"bytes":len(candidate),"sha256":sha(candidate)},
       "actual_changes":[{"before":a.decode(),"after":b.decode(),"count":n} for a,b,n in changes],
       "overlay_attempts":1,"failed_overlay_attempts":0,"full_inverse_byte_exact":True,
       "unavailable_original_metadata":cfg["unavailable_metadata"],
       "this_receipt_is_new_recovery_evidence_not_reconstructed_UPDATE":True,
       "compiler_typecheck_tests_native_execution":False,"original_source_or_root_git_writes":False,"data_writes":False,
       "inspector_closed_recovery_scope_touched":False,"integration_or_release_qualification":False,
       "resources":{"root_floor":cfg["root_floor"],"reserve_and_cap":cfg["cap"],"free_before":free_before,"guard_events":checks}}
write("RECOVERY.json",jb(proof))
files=[]
for p in sorted(out.rglob("*")):
    if p.is_file():
        b=p.read_bytes()
        files.append({"path":p.relative_to(out).as_posix(),"bytes":len(b),"sha256":sha(b),"mode":stat.S_IMODE(p.stat().st_mode)})
require(len(files)==10,"unexpected artifact set before manifest")
write("RECOVERY_MANIFEST.json",jb({"schema":"otzaria.bookinfo.actor-source-recovery.manifest.v1","files":files,
                                  "manifest_self_excluded":True,"final_file_count":11,"complete_target_hash_matched":True,"original_UPDATE_recovered":False}))
guard("final scope")
require((out/"candidate"/filename).read_bytes()==candidate and (out/"baseline"/filename).read_bytes()==original,"final source readback mismatch")
for path,before in ((cfg["ffa_path"],ffa_identity),(cfg["library_path"],library_identity)):
    require(ident(pathlib.Path(path).lstat())==ident(before),"source archive changed during preservation")
outputs=[]
for p in sorted(out.rglob("*")):
    if p.is_file():
        b=p.read_bytes()
        outputs.append({"path":p.relative_to(out).as_posix(),"bytes":len(b),"sha256":sha(b)})
require(len(outputs)==11,"unexpected final artifact count")
print(json.dumps({"status":"EXACT_TARGET_BYTES_RECOVERED","output":str(out),"files":outputs,"allocated_bytes":allocation(),
                  "rootfs_free_after":free(),"root_floor_plus_reserve":cfg["root_floor"]+cfg["cap"],
                  "source_byte_match":True,"full_inverse_byte_exact":True,"original_UPDATE_recovered":False,
                  "source_tests_compilation_git_execution":False},sort_keys=True))
