# Exact BookInfo actor-initializer source recovery

The recovered file is `candidate/MaktabahNativeLibraryListPublication.swift`, **10,668 bytes**, SHA-256 `839c4da8ddd9f7795b02046da7c5f778d5f85f744da14ace7819e24d2633558f`.

The complete original BookInfo baseline is **10,530 bytes**, SHA-256 `64b5b72a90a1e6734cbe5285537d70a9b1bf4121f2c91d06e076d7b8a084e065`, read from the existing FFA content-addressed proposal capsule and joined to both original manifest references. No source was recreated from a partial excerpt.

The mechanical correction was taken from the actual complete recovered Library publication, **7,044 bytes**, SHA-256 `3bcb93f70b9352eeeeb196a41e333da69fc7a9c19e314b4ba1198c2d1c217919`, in the previously recovered RAW_SOURCE.zip. Applying the typed-let and initializer-assignment changes to the full original Library predecessor exactly reproduces all bytes of that recovered Library file.

That same finite correction was applied only to the two BookInfo nested classes, Witness and BookWitness: their nonisolated invalidation properties become explicitly typed lets, and the identical NativeComponentSourceObservation initialization moves into each existing MainActor initializer. The compact BookWitness initializer is expanded only to accommodate that assignment. No other source behavior, callbacks, assertions or tests were edited.

The first and only overlay attempt matched the entire required BookInfo length and SHA-256. Reversing the exact replacements returns every baseline byte. The baseline and exact recovered BookInfo file, both complete Library pattern inputs, full original FFA manifest and exact recovery patch are preserved here.

**UPDATE.json was not recovered.** Only its reported 8,687-byte length and reported hash prefix 45c502dc were supplied; this packet does not reconstruct or claim that unavailable metadata. RECOVERY.json is a new recovery receipt, not a substitute for the missing original record.

No compiler, typecheck, tests, native execution, signing, authentication, Data-volume writes or Git changes occurred. This is exact source-byte recovery and does not qualify compilation, runtime behavior or product integration. Root owns any later intake. The prior Inspector nine-file recovery remains closed and untouched.

This new scope is limited to 4 MiB of actual allocated bytes, including directories, all raw sources and proof. The unchanged rootfs floor of 1,593,835,520 bytes plus a 4 MiB reserve is checked before allocation.
