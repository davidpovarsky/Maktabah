#if os(iOS)
import Foundation
import OtzariaUIRouting
import ChavrusaUIRoutingHost

/// Passive metadata of an ORIGINAL Library model or collection publication.
/// It owns no catalog data, query, task, navigation grant or replacement UI.
@MainActor final class MaktabahNativeLibraryListPublication {
    @MainActor final class Witness {
        nonisolated let invalidation = NativeComponentSourceObservation(read: {})
        private weak var owner: MaktabahNativeLibraryListPublication?
        private let revision: UInt64
        fileprivate init(owner: MaktabahNativeLibraryListPublication, revision: UInt64) {
            self.owner = owner; self.revision = revision
        }
        func validate() throws {
            try invalidation.validate()
            guard let owner, owner.revision == revision, !owner.searchPending else {
                throw UIRouteError(.staleState, "native_library_publication_changed")
            }
        }
    }

    /// This stamp describes the exact ORIGINAL array supplied to applyCategories.
    /// It is not a fresh source capture or permission to navigate that array.
    @MainActor final class CategoriesStamp {
        private weak var owner: MaktabahNativeLibraryListPublication?
        private let revision: UInt64
        private let roots: [ObjectIdentifier]
        fileprivate init(owner: MaktabahNativeLibraryListPublication, revision: UInt64,
                         categories: [CategoryData]) {
            self.owner = owner; self.revision = revision
            roots = categories.map(ObjectIdentifier.init)
        }
        func isCurrent(in publication: MaktabahNativeLibraryListPublication,
                       categories: [CategoryData]) -> Bool {
            owner === publication && publication.categoriesRevision == revision
                && categories.map(ObjectIdentifier.init) == roots
        }
        fileprivate var isCurrent: Bool { owner?.categoriesRevision == revision }
    }

    @MainActor final class SnapshotApplication {
        fileprivate let id = UUID()
        fileprivate let stamp: CategoriesStamp?
        fileprivate init(stamp: CategoriesStamp?) { self.stamp = stamp }
    }
    private final class WeakWitness {
        weak var value: Witness?
        init(_ value: Witness) { self.value = value }
    }

    private(set) var revision: UInt64? = 0
    private(set) var categoriesRevision: UInt64? = 0
    private var witnesses: [WeakWitness] = []
    private var search: UUID?
    private var applyingSnapshot: SnapshotApplication?
    private var appliedStamp: CategoriesStamp?
    var searchPending: Bool { search != nil }

    /// Invokes only fixed one-way latches BEFORE the original setter continues.
    /// Equal publication, ABA and overflow can never revive an old witness.
    func willPublish() {
        let original = witnesses
        witnesses.removeAll(keepingCapacity: true)
        for entry in original { entry.value?.invalidation.invalidate() }
        Self.advance(&revision)
    }

    func categoriesWillPublish() {
        willPublish()
        Self.advance(&categoriesRevision)
    }

    func beginOriginalSearch() -> UUID {
        willPublish()
        let token = UUID(); search = token
        return token
    }

    func finishOriginalSearch(_ token: UUID) {
        guard search == token else { return }
        willPublish(); search = nil
    }

    func categoriesStamp(_ categories: [CategoryData]) -> CategoriesStamp? {
        guard let categoriesRevision else { return nil }
        return CategoriesStamp(owner: self, revision: categoriesRevision, categories: categories)
    }

    func beginSnapshot(_ stamp: CategoriesStamp?) -> SnapshotApplication {
        willPublish()
        let application = SnapshotApplication(stamp: stamp)
        applyingSnapshot = application; appliedStamp = nil
        return application
    }

    /// Only the SAME original apply completion may qualify its own source.
    /// The caller still executes its original sync/notification for stale applies.
    func snapshotDidApply(_ application: SnapshotApplication) {
        guard applyingSnapshot === application, revision != nil,
              let stamp = application.stamp, stamp.isCurrent else { return }
        applyingSnapshot = nil; appliedStamp = stamp
    }

    func hasApplied(_ model: MaktabahNativeLibraryListPublication,
                    categories: [CategoryData]) -> Bool {
        applyingSnapshot == nil && appliedStamp?.isCurrent(in: model, categories: categories) == true
    }

    func retireSnapshot() {
        willPublish(); applyingSnapshot = nil; appliedStamp = nil
    }

    func capture() throws -> Witness {
        guard let revision, !searchPending else {
            throw UIRouteError(.unavailable, "native_library_source_not_settled")
        }
        witnesses.removeAll { $0.value == nil }
        guard witnesses.count < 64 else {
            throw UIRouteError(.unavailable, "native_library_observation_busy")
        }
        let witness = Witness(owner: self, revision: revision)
        witnesses.append(WeakWitness(witness))
        try witness.validate()
        return witness
    }

    private static func advance(_ revision: inout UInt64?) {
        guard let current = revision else { return }
        revision = current == .max ? nil : current + 1
    }
}

/// One exact expansion inside the already-admitted, synchronous original row
/// reveal. The controller creates it only after validating the retained row.
/// Its callback is the SAME retained validator, not executable public input.
@MainActor final class MaktabahNativeLibraryExpansionPermit {
    private let controller: ObjectIdentifier
    private let item: LibraryTreeItemIdentifier
    private let validateSource: @MainActor () throws -> Void
    private var consumed = false
    private var retired = false

    init(controller: iOSHierarchicalCollectionViewController, item: LibraryTreeItemIdentifier,
         validate: @escaping @MainActor () throws -> Void) {
        self.controller = ObjectIdentifier(controller); self.item = item; validateSource = validate
    }

    func consume(controller: iOSHierarchicalCollectionViewController,
                 item: LibraryTreeItemIdentifier) throws {
        guard !consumed, !retired, self.controller == ObjectIdentifier(controller), self.item == item else {
            retired = true
            throw UIRouteError(.staleState, "native_library_expansion_reused")
        }
        consumed = true
        try validate()
    }

    func validate() throws {
        guard consumed, !retired else {
            throw UIRouteError(.staleState, "native_library_expansion_retired")
        }
        do {
            try validateSource()
            guard consumed, !retired else {
                throw UIRouteError(.staleState, "native_library_expansion_retired")
            }
        } catch { retired = true; throw error }
    }

    func retire() { retired = true }
}
#endif
