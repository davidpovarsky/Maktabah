import pathlib,subprocess,json,hashlib,datetime,os,time,shutil
w=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-inspector-harness-20261120")
out=w/"build/inspector-harness-baseline-20261120"
source=out/"source-127ee";spec=json.loads((out/"SOURCE.json").read_text(encoding="utf-8"))
attempt=out/"attempt02-trace";assert attempt.exists() and not (attempt/"RESULT.json").exists()
traceInputs=json.loads((attempt/"TRACE_INPUTS.json").read_text(encoding="utf-8"))
env=os.environ.copy()
toolbin=r"C:\Users\DAVID\AppData\Local\Programs\Swift\Toolchains\6.3.3+Asserts\usr\bin"
runtime=r"C:\Users\DAVID\AppData\Local\Programs\Swift\Runtimes\6.3.3\usr\bin"
env["PATH"]=toolbin+";"+runtime+";"+env["PATH"]
swift=str(pathlib.Path(toolbin)/"swiftc.exe")
exe=attempt/"inspector-backend-tests.exe"
paths=list(spec["sources"])[:spec["inputCount"]]
assert all(p.endswith(".swift") for p in paths)
for p in spec["sources"]:assert hashlib.sha256((source/p).read_bytes()).hexdigest()==spec["sources"][p]["sha256"],p
command=[swift,"-D","OTZARIA_INSPECTOR_MAPPING_TESTS",*[str(attempt/"trace"/p if p in traceInputs["traceFiles"] else source/p) for p in paths],"-j","1","-module-cache-path",str(out/"module-cache"),"-o",str(exe)]
report={"startedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sourceRecordSHA256":hashlib.sha256((out/"SOURCE.json").read_bytes()).hexdigest(),"exactOriginalHead":spec["exactHead"],"inputCount":len(paths),"command":command,"invocationDelta":"Diagnostic run of original127ee: only stage/assertion stderr trace in two test files, exact inverse proof in TRACE_INPUTS.json. Production and all original oracles unchanged. Windows Swift6.3.3, explicit jobs1 and reused owned module cache; Apple branches differ.","nativePasses":0,"appleCompile":False,"compile":None,"runtime":None,"status":"RUNNING","diskFreeBefore":shutil.disk_usage(w).free}
(attempt/"RESULT.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
def execute(cmd,label,budget):
 t=time.monotonic();entry={"command":cmd,"timeoutSeconds":budget,"startedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (attempt/(label+".stdout.log")).open("wb") as stdout,(attempt/(label+".stderr.log")).open("wb") as stderr:
  p=subprocess.Popen(cmd,cwd=source,env=env,stdout=stdout,stderr=stderr)
  entry["pid"]=p.pid
  try:entry["exit"]=p.wait(timeout=budget);entry["timedOut"]=False
  except subprocess.TimeoutExpired:
   entry["timedOut"]=True
   cleanup=subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=15)
   entry["ownedTreeCleanup"]={"exit":cleanup.returncode,"stdout":cleanup.stdout,"stderr":cleanup.stderr}
   try:entry["exit"]=p.wait(timeout=10)
   except subprocess.TimeoutExpired:entry["exit"]=None
 entry["elapsedSeconds"]=round(time.monotonic()-t,3)
 entry["finishedUTC"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 return entry
report["swiftVersion"]=subprocess.run([swift,"--version"],env=env,capture_output=True,text=True,encoding="utf-8").stdout
report["traceInputs"]=traceInputs
report["compile"]=execute(command,"compile",240)
if report["compile"]["exit"]==0 and not report["compile"]["timedOut"]:
 report["executable"]={"bytes":exe.stat().st_size,"sha256":hashlib.sha256(exe.read_bytes()).hexdigest()}
 report["runtime"]=execute([str(exe)],"tests",120)
 stdout=(attempt/"tests.stdout.log").read_text(encoding="utf-8",errors="replace")
 report["completedOriginalHarness"]=report["runtime"]["exit"]==0 and "Sefaria native contract tests passed" in stdout
 report["status"]="DIAGNOSTIC_PORTABLE_HARNESS_PASS" if report["completedOriginalHarness"] else "RUNTIME_INCOMPLETE_OR_FAILED"
else:report["status"]="SETUP_COMPILE_FAILED"
report["warnings"]=(attempt/"compile.stderr.log").read_text(encoding="utf-8",errors="replace").count("warning:")
report["traceUnchanged"]=all(hashlib.sha256((attempt/"trace"/p).read_bytes()).hexdigest()==v["traceSHA256"] for p,v in traceInputs["traceFiles"].items())
if report["runtime"]:
 report["traceTail"]=(attempt/"tests.stderr.log").read_text(encoding="utf-8",errors="replace").splitlines()[-40:]
report["sourceUnchanged"]=all(hashlib.sha256((source/p).read_bytes()).hexdigest()==v["sha256"] for p,v in spec["sources"].items())
report["diskFreeAfter"]=shutil.disk_usage(w).free
report["finishedUTC"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(attempt/"RESULT.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report))
print((attempt/"compile.stderr.log").read_text(encoding="utf-8",errors="replace")[-18000:])
if report["runtime"]:print((attempt/"tests.stdout.log").read_text(encoding="utf-8",errors="replace")[-10000:]);print((attempt/"tests.stderr.log").read_text(encoding="utf-8",errors="replace")[-10000:])
raise SystemExit(0 if report.get("completedOriginalHarness") else 1)
