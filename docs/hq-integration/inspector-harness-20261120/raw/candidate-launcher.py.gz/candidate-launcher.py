import pathlib,subprocess,json,hashlib,datetime,os,time,shutil
w=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-inspector-harness-20261120")
out=w/"build/inspector-harness-baseline-20261120";source=out/"source-127ee"
spec=json.loads((out/"SOURCE.json").read_text(encoding="utf-8"))
paths=list(spec["sources"])[:spec["inputCount"]];assert len(paths)==38 and all(p.endswith(".swift") for p in paths)
changed={"Vendor/SefariaNativeTests/DecodingTests.swift","Vendor/SefariaNativeTests/SefariaNativeTestMain.swift"}
actual=set(subprocess.run(["git","diff","--name-only"],cwd=w,capture_output=True,text=True,check=True).stdout.splitlines())
assert actual==changed,actual
env=os.environ.copy();toolbin=r"C:\Users\DAVID\AppData\Local\Programs\Swift\Toolchains\6.3.3+Asserts\usr\bin";runtime=r"C:\Users\DAVID\AppData\Local\Programs\Swift\Runtimes\6.3.3\usr\bin"
env["PATH"]=toolbin+";"+runtime+";"+env["PATH"];swift=str(pathlib.Path(toolbin)/"swiftc.exe")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
original_before={p:sha(source/p) for p in spec["sources"]}
assert all(original_before[p]==v["sha256"] for p,v in spec["sources"].items())
current_before={p:sha(w/p) for p in spec["sources"]}
def execute(cmd,label,budget,attempt,cwd):
 entry={"command":cmd,"timeoutSeconds":budget,"startedUTC":now()};t=time.monotonic()
 with (attempt/(label+".stdout.log")).open("wb") as so,(attempt/(label+".stderr.log")).open("wb") as se:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=so,stderr=se);entry["pid"]=p.pid
  try:entry["exit"]=p.wait(timeout=budget);entry["timedOut"]=False
  except subprocess.TimeoutExpired:
   entry["timedOut"]=True
   q=subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=15)
   entry["ownedTreeCleanup"]={"exit":q.returncode,"stdout":q.stdout,"stderr":q.stderr}
   try:entry["exit"]=p.wait(timeout=10)
   except subprocess.TimeoutExpired:entry["exit"]=None
 entry["elapsedSeconds"]=round(time.monotonic()-t,3);entry["finishedUTC"]=now();return entry
stages=["LocatorAndRefTests","DecodingTests","NavigationAndPackageTests","LegacyIdentityRegistryTests","BackendCoordinatorTests","UnifiedSearchArchitectureTests"]
summary=[]
for name,current in [("attempt03-controlled-green",False),("attempt04-current-green",True)]:
 attempt=out/name;attempt.mkdir(exist_ok=False)
 input_paths=[];witness={}
 for p in paths:
  if current or p in changed:q=w/p
  elif p=="Vendor/SefariaNativeTests/TestSupport.swift":q=out/"attempt02-trace/trace"/p
  else:q=source/p
  input_paths.append(q);witness[p]={"path":str(q),"sha256":sha(q)}
 exe=attempt/"inspector-backend-tests.exe"
 command=[swift,"-D","OTZARIA_INSPECTOR_MAPPING_TESTS",*[str(p) for p in input_paths],"-j","1","-module-cache-path",str(out/"module-cache"),"-o",str(exe)]
 report={"startedUTC":now(),"currentCandidate":current,"baselineHead":spec["exactHead"],"candidateBaseHead":subprocess.run(["git","rev-parse","HEAD"],cwd=w,capture_output=True,text=True,check=True).stdout.strip(),"expectedStages":stages,"inputCount":len(input_paths),"inputs":witness,"fixtureInputs":{p:{"path":str(w/p if current else source/p),"sha256":sha(w/p if current else source/p)} for p in spec["sources"] if p not in paths},"compile":None,"runtime":None,"appleCompile":False,"nativePasses":0,"status":"RUNNING","diskFreeBefore":shutil.disk_usage(w).free,"invocationDelta":"Windows6.3.3, -j1, existing module cache. Same original38 input set and compile definition. Controlled run uses exact127ee production plus candidate fixtures and inverse-proved assertion-only trace; current run uses exact working candidate and unmodified original TestSupport."}
 (attempt/"SOURCE.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
 report["compile"]=execute(command,"compile",240,attempt,w if current else source)
 report["warnings"]=(attempt/"compile.stderr.log").read_text(encoding="utf-8",errors="replace").count("warning:")
 if report["compile"]["exit"]==0 and not report["compile"]["timedOut"]:
  report["executable"]={"bytes":exe.stat().st_size,"sha256":sha(exe)}
  report["runtime"]=execute([str(exe)],"tests",120,attempt,w if current else source)
  stdout=(attempt/"tests.stdout.log").read_text(encoding="utf-8",errors="replace");stderr=(attempt/"tests.stderr.log").read_text(encoding="utf-8",errors="replace")
  report["observedStages"]=[l.removeprefix("STAGE PASS ") for l in stderr.splitlines() if l.startswith("STAGE PASS ")]
  report["completedOriginalHarness"]=report["runtime"]["exit"]==0 and not report["runtime"]["timedOut"] and "Sefaria native contract tests passed" in stdout and report["observedStages"]==stages
  report["assertionsObserved"]=len([l for l in stderr.splitlines() if l.startswith("EXPECT PASS ")]) if not current else None
  report["status"]="PASS_PORTABLE_ONLY" if report["completedOriginalHarness"] else "RUNTIME_INCOMPLETE_OR_FAILED"
  report["stderrTail"]=stderr.splitlines()[-25:]
 else:report["status"]="SETUP_COMPILE_FAILED";report["compileTail"]=(attempt/"compile.stderr.log").read_text(encoding="utf-8",errors="replace").splitlines()[-30:]
 report["inputsUnchanged"]=all(sha(pathlib.Path(v["path"]))==v["sha256"] for v in witness.values())
 report["baselineUnchanged"]=all(sha(source/p)==v for p,v in original_before.items())
 report["currentCandidateUnchanged"]=all(sha(w/p)==v for p,v in current_before.items())
 report["diskFreeAfter"]=shutil.disk_usage(w).free;report["finishedUTC"]=now()
 (attempt/"RESULT.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
 bounded={k:v for k,v in report.items() if k not in ["inputs","fixtureInputs"]}
 print(json.dumps(bounded),flush=True);summary.append({"attempt":name,"status":report["status"],"resultSHA256":sha(attempt/"RESULT.json")})
 if not report.get("completedOriginalHarness"):break
result={"attempts":summary,"allPassed":len(summary)==2 and all(x["status"]=="PASS_PORTABLE_ONLY" for x in summary),"finishedUTC":now()}
(out/"CANDIDATE_RESULTS.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result))
raise SystemExit(0 if result["allPassed"] else 1)
