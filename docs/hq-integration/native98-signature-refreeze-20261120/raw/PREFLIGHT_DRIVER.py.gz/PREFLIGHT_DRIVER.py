import pathlib,subprocess,json,hashlib,datetime,runpy,sys,os,time
root=pathlib.Path.cwd();out=root/"build/native98-signature-refreeze-20261120";M="87b783ac3f0257e8461762e0ea9dfa5248dd06e8"
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip();assert head==M
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
environment=os.environ.copy();environment["PYTHONUTF8"]="1";environment["EXPECTED_CHECKOUT_SHA"]=M
command=[sys.executable,"-X","utf8","Scripts/CI/hq-stage2-focused-apple.py","--preflight-only"]
clock=time.monotonic();p=subprocess.run(command,cwd=root,env=environment,capture_output=True,text=True,encoding="utf-8",timeout=120)
(out/"source-preflight.stdout.log").write_text(p.stdout,encoding="utf-8",newline="\n");(out/"source-preflight.stderr.log").write_text(p.stderr,encoding="utf-8",newline="\n")
record={"startedUTC":started,"head":head,"context":"Precommit source preparation: exact current config hash binds M application source; final commit will preserve these inputs","command":command,"returncode":p.returncode,"elapsedSeconds":time.monotonic()-clock,"nativeExecuted":0,"appleCompile":"NOT_RUN"}
(out/"SOURCE_PREFLIGHT_COMMAND.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n")
assert p.returncode==0,p.stderr+p.stdout
source=json.loads(p.stdout);assert source["application_source_sha"]==M and source["checkout_sha"]==M
(out/"FULL_SOURCE_PREFLIGHT.json").write_text(json.dumps(source,indent=2)+"\n",encoding="utf-8",newline="\n")
native=json.loads((root/"docs/hq-integration/runtime27/R27_CASES.json").read_text(encoding="utf-8"))
ids=native["execution_case_ids"];assert len(ids)==len(set(ids))==98
declaration=runpy.run_path(str(root/"Scripts/CI/verify-faithful-xctest.py"))["validate_selections"](ids,root/"Maktabah-iOSUITests")
(out/"FULL98_DECLARATIONS.json").write_text(json.dumps(declaration,indent=2)+"\n",encoding="utf-8",newline="\n")
assert declaration["status"]=="DECLARATIONS_MATCH",declaration
groups=runpy.run_path(str(root/"Scripts/CI/runtime27.py"))["execution_groups"](native)
assert groups==native["execution_groups"] and len(groups)==7 and sum(len(g["case_ids"]) for g in groups)==98
release=runpy.run_path(str(root/"Scripts/CI/runtime27-release.py"))["load_manifest"](root)
ui=sum(len(x["required_ui_cases"]) for x in release["configurations"]);oracle=sum(len(x.get("required_oracle_cases",[])) for x in release["configurations"]);assert ui==96 and oracle==2
releaseproof={"originalFunction":"runtime27-release.py:load_manifest","status":"ORIGINAL_DECLARATIONS_AND_PREPARED_SOURCE_CHECKS_PASSED","configurations":[{"id":r["id"],"ui":len(r["required_ui_cases"]),"oracle":len(r.get("required_oracle_cases",[]))} for r in release["configurations"]],"requiredUI":ui,"requiredOracle":oracle,"manifestSHA256":hashlib.sha256((root/"Scripts/CI/runtime27-release-manifest.json").read_bytes()).hexdigest(),"nativeExecuted":0}
(out/"RELEASE_MANIFEST_PREFLIGHT.json").write_text(json.dumps(releaseproof,indent=2)+"\n",encoding="utf-8",newline="\n")
summary={"startedUTC":started,"finishedUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"sourcePreflight":"PASS","nativeDeclarations":declaration["status"],"nativeCases":98,"nativeGroups":7,"groupCaseCounts":{g["label"]:len(g["case_ids"]) for g in groups},"releaseUI":96,"releaseOracles":2,"releaseManifestPreflight":releaseproof["status"],"nativeExecuted":0,"appleCompile":"NOT_RUN","scope":"Source, declaration, original group validator and original Release preparation checks only","head":head}
(out/"PREFLIGHT_SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(summary))
