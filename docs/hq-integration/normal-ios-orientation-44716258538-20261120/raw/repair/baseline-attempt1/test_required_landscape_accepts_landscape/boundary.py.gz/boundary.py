
import json, os, pathlib, shutil, struct, sys, zlib
tool, args = sys.argv[1], sys.argv[2:]
with open(os.environ["CAPTURE_TEST_CALLS"], "a", encoding="utf-8") as f:
 f.write(json.dumps({"tool":tool,"args":args})+"\n")
def png(w,h):
 def chunk(kind,payload):
  return struct.pack(">I",len(payload))+kind+payload+struct.pack(">I",zlib.crc32(kind+payload)&0xffffffff)
 data=(b"\0"+b"\x32\x64\x96\xff"*w)*h
 return b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",w,h,8,6,0,0,0))+chunk(b"IDAT",zlib.compress(data,0))+chunk(b"IEND",b"")
if tool=="xcrun":
 if args[:2]==["simctl","io"] and len(args)==5 and args[3]=="screenshot":
  if os.environ.get("CAPTURE_TEST_FAIL_CAPTURE")=="1": sys.exit(37)
  shutil.copyfile(os.environ["CAPTURE_TEST_RAW"],args[4])
 elif args[:2]==["simctl","launch"]:
  print("fixture.application: 1234")
 elif args[:2]!=["simctl","terminate"]:
  raise RuntimeError("unexpected simctl boundary")
elif tool=="idb":
 if args[:2]==["ui","rotate"]:
  if os.environ.get("CAPTURE_TEST_FAIL_ROTATE")=="1": sys.exit(38)
 elif args[:2]==["ui","describe-all"]:
  print("[]")
 else: raise RuntimeError("unexpected IDB boundary")
elif tool=="stat":
 assert args[:2]==["-f","%z"]
 print(pathlib.Path(args[2]).stat().st_size)
elif tool=="sips":
 if args[0]=="-g":
  data=pathlib.Path(args[2]).read_bytes()
  if data[:8]!=b"\x89PNG\r\n\x1a\n" or len(data)<24: sys.exit(39)
  w,h=struct.unpack(">II",data[16:24])
  assert args[1] in ("pixelWidth","pixelHeight")
  print(args[1]+": "+str(w if args[1]=="pixelWidth" else h))
 elif args[0]=="-r":
  # Explicit geometry-only model of the historical external rotation command.
  # This is not macOS sips and is never used on an authentic captured image.
  assert args[3]=="--out"
  data=pathlib.Path(args[2]).read_bytes()
  w,h=struct.unpack(">II",data[16:24])
  degrees=int(args[1])
  assert degrees in (90,-90,180)
  if abs(degrees)==90: w,h=h,w
  pathlib.Path(args[4]).write_bytes(png(w,h))
 else: raise RuntimeError("unexpected sips boundary")
else: raise RuntimeError("unknown external boundary")
