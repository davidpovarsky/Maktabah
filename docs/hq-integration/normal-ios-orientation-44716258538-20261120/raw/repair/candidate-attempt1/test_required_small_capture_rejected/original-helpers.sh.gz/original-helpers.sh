set -euo pipefail

xcrun() { "$CAPTURE_TEST_PYTHON" "$CAPTURE_TEST_BOUNDARY" xcrun "$@"; }
idb() { "$CAPTURE_TEST_PYTHON" "$CAPTURE_TEST_BOUNDARY" idb "$@"; }
sips() { "$CAPTURE_TEST_PYTHON" "$CAPTURE_TEST_BOUNDARY" sips "$@"; }
stat() { "$CAPTURE_TEST_PYTHON" "$CAPTURE_TEST_BOUNDARY" stat "$@"; }
sleep() { :; }
UDID=fixture-simulator
BUNDLE_ID=fixture.application
SCREENSHOT_DIR='C:/Users/DAVID/Code/Maktabah-normalios-toolchain-20261120/build/normal-ios-orientation-repair-20261120/candidate-attempt1/test_required_small_capture_rejected'
REPORT_DIR='C:/Users/DAVID/Code/Maktabah-normalios-toolchain-20261120/build/normal-ios-orientation-repair-20261120/candidate-attempt1/test_required_small_capture_rejected'
CURRENT_ORIENTATION=landscapeLeft
capture_current_ui() {
  local name="$1"
  xcrun simctl io "$UDID" screenshot "$SCREENSHOT_DIR/$name" >/dev/null
  idb ui describe-all \
    --key AXUniqueId --key AXLabel --key AXValue --key help --key frame \
    --udid "$UDID" > "$REPORT_DIR/${name%.png}-accessibility.json"
}

capture_screen() {
  local output="$1"
  local lang="$2"
  local locale="$3"
  local wait_seconds="${CAPTURE_WAIT_SECONDS:-10}"
  local ready_file="${SMOKE_READY_FILE:-}"
  local settle_seconds="${SMOKE_SETTLE_SECONDS:-1}"
  shift 3

  echo "--> [SCREENSHOT] $output (lang: $lang, locale: $locale, wait: ${wait_seconds}s, args: ${*:-none})"
  xcrun simctl terminate "$UDID" "$BUNDLE_ID" >/dev/null 2>&1 || true
  sleep 1
  if [ -n "$ready_file" ]; then
    rm -f "$ready_file"
  fi
  SIMCTL_CHILD_OTZARIA_DATA_PROFILE=miniTest10 \
  SIMCTL_CHILD_MAKTABAH_SMOKE_READY_FILE="$ready_file" \
  xcrun simctl launch "$UDID" "$BUNDLE_ID" -OtzariaDataProfile miniTest10 -AppleLanguages "($lang)" -AppleLocale "$locale" "$@"
  if [ "$CURRENT_ORIENTATION" != "portrait" ]; then
    rotate_simulator "$CURRENT_ORIENTATION"
  fi
  if [ -n "$ready_file" ]; then
    local waited=0
    while [ ! -s "$ready_file" ] && [ "$waited" -lt "$wait_seconds" ]; do
      sleep 1
      waited=$((waited + 1))
    done
    if [ ! -s "$ready_file" ]; then
      echo "Smoke scenario did not become ready within ${wait_seconds}s: $output" >&2
      xcrun simctl terminate "$UDID" "$BUNDLE_ID" >/dev/null 2>&1 || true
      return 1
    fi
    if ! grep -qx 'success' "$ready_file"; then
      echo "Smoke scenario reported failure: $output" >&2
      cat "$ready_file" >&2
      xcrun simctl terminate "$UDID" "$BUNDLE_ID" >/dev/null 2>&1 || true
      return 1
    fi
    sleep "$settle_seconds"
  else
    sleep "$wait_seconds"
  fi
  xcrun simctl io "$UDID" screenshot "$SCREENSHOT_DIR/$output" >/dev/null 2>&1 || echo "Warning: failed to capture $output"
  xcrun simctl terminate "$UDID" "$BUNDLE_ID" >/dev/null 2>&1 || true
  sleep 1
}

rotate_simulator() {
  local orientation="$1"
  local idb_orientation
  case "$orientation" in
    portrait) idb_orientation="PORTRAIT" ;;
    portraitUpsideDown) idb_orientation="PORTRAIT_UPSIDE_DOWN" ;;
    landscapeLeft) idb_orientation="LANDSCAPE_LEFT" ;;
    landscapeRight) idb_orientation="LANDSCAPE_RIGHT" ;;
    *) echo "Unsupported simulator orientation: $orientation" >&2; return 64 ;;
  esac
  echo "Setting simulator orientation to $orientation"
  idb ui rotate "$idb_orientation" --udid "$UDID" || {
    echo "IDB failed to rotate simulator $UDID to $idb_orientation." >&2
    exit 1
  }
  sleep 2
}


require_screenshot() {
  local name="$1"
  local expected_orientation="$2"
  local path="$SCREENSHOT_DIR/$name"
  if [ ! -s "$path" ] || [ "$(stat -f '%z' "$path")" -le 10000 ]; then
    echo "Missing or empty required screenshot: $name" >&2
    return 1
  fi
  local width height
  width="$(sips -g pixelWidth "$path" 2>/dev/null | awk '/pixelWidth/ {print $2}')"
  height="$(sips -g pixelHeight "$path" 2>/dev/null | awk '/pixelHeight/ {print $2}')"
  if [ "$expected_orientation" = landscape ] && [ "$width" -le "$height" ]; then
    echo "Expected landscape screenshot but got ${width}x${height}: $name" >&2
    return 1
  fi
  if [ "$expected_orientation" = portrait ] && [ "$height" -le "$width" ]; then
    echo "Expected portrait screenshot but got ${width}x${height}: $name" >&2
    return 1
  fi
  echo "Verified $name (${width}x${height})"
}

require_screenshot capture.png landscape
