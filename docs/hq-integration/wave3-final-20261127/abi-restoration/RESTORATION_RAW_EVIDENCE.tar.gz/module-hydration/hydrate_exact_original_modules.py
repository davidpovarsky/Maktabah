from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime,time,shutil,signal,uuid,stat,traceback
TASK=Path(__file__).resolve().parent
ORIGINAL=Path('/Users/m1/builds/otzaria-shared-agent1-20261126/anytype-formal-original-swift-abi-e973cc74/source')
RECOVERY=Path('/Users/m1/builds/otzaria-root-actions-acceptance-20261126.wjQnLNJl/wave3-e973-original-input-restoration-20261127.elt9gekq')
PLAN=RECOVERY/'EXACT_MODULE_HYDRATION_PLAN.json'
PLAN_SHA='d755052f0eae0967c8d704fa9390a5a330c8dd3d7e8f1e8b4c3f397d785c201f'
GO=Path('/Users/m1/toolchains/go1.26.5/bin/go')
GO_SHA='3925fc3221ac440ebf7c35361ff663bed0c7bdb2e0a157b75fe993607ffe0a19'
OLD_CACHE=Path('/Users/m1/go/pkg/mod')
RESERVE=512*1024*1024
os.umask(0o022)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def require(v,m):
 if not v:raise RuntimeError(m)
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while block:=f.read(8*1024*1024):h.update(block)
 return h.hexdigest()
def row(p):
 p=Path(p);require(p.is_file() and not p.is_symlink(),'Expected regular file: '+str(p));a=p.stat();sha=hashlib.sha256();blob=hashlib.sha1(('blob '+str(a.st_size)+'\0').encode())
 with p.open('rb') as f:
  while block:=f.read(8*1024*1024):sha.update(block);blob.update(block)
 b=p.stat();require((a.st_ino,a.st_size,a.st_mtime_ns)==(b.st_ino,b.st_size,b.st_mtime_ns),'File changed during verification: '+str(p))
 return {'path':str(p),'bytes':a.st_size,'sha256':sha.hexdigest(),'git_blob':blob.hexdigest()}
def identity(v):return {k:v[k] for k in ('bytes','sha256','git_blob')}
def save(path,value,mutable=False):
 data=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode();path=Path(path)
 if mutable:
  tmp=path.with_name('.'+path.name+'.'+str(uuid.uuid4()));tmp.write_bytes(data);os.replace(tmp,path)
 else:
  with path.open('xb') as f:f.write(data)
def space():return shutil.disk_usage(TASK).free
def cmd(args,cwd,env,folder,label,timeout=180):
 start=now();out=folder/(label+'.stdout.log');err=folder/(label+'.stderr.log');reason=None
 with out.open('xb') as so,err.open('xb') as se:
  process=subprocess.Popen(args,cwd=cwd,env=env,stdout=so,stderr=se,start_new_session=True)
  command={'argv':args,'cwd':str(cwd),'pid':process.pid,'started_at':start,'timeout_seconds':timeout,'owned_process_group':process.pid}
  save(folder/(label+'.started.json'),command)
  deadline=time.monotonic()+timeout
  while process.poll() is None:
   if space()<RESERVE:reason='Capacity reserve reached during owned command'
   elif time.monotonic()>deadline:reason='Owned command exceeded bounded timeout'
   if reason:
    os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=8)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=8)
    break
   time.sleep(0.5)
  rc=process.wait()
 command.update(finished_at=now(),returncode=rc,stop_reason=reason,stdout=row(out),stderr=row(err));save(folder/(label+'.command.json'),command)
 require(rc==0 and reason is None,label+' failed: exit '+str(rc)+' '+str(reason)+'; '+err.read_text(errors='replace')[-5000:])
 return json.loads(out.read_text()) if label=='download' else command

def main():
 result={'status':'RUNNING','started_at':now(),'scope':'exact original198 Go module versions; publish only original-declared missing/identical files','plan':str(PLAN),'plan_sha256':PLAN_SHA,'source_pin':'e973cc7432419778f0342624a3b7052055fd270d','pid':os.getpid(),'pins_modified':False,'sdk_or_app_build_started':False,'modules':[],'restored_files':0,'already_identical_files':0,'free_start_bytes':space()}
 save(TASK/'STATUS.json',result,True)
 try:
  require(digest(PLAN)==PLAN_SHA,'Original approved plan differs');plan=json.loads(PLAN.read_text());require(len(plan['modules'])==198,'Plan module count differs');require(sum(len(m['files']) for m in plan['modules'])==4444,'Plan file count differs');require(digest(GO)==GO_SHA,'Original Go tool differs')
  head=subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ORIGINAL),'rev-parse','HEAD'],text=True).strip();require(head==result['source_pin'],'Original source HEAD differs')
  finalsource=ORIGINAL/'build/ABI-Candidate-Work/tmp/gomobile-work-2591336864/ios/src-arm64'
  inputs={n:row(finalsource/n) for n in ('go.mod','go.sum')};require(inputs['go.mod']['sha256']=='775988dc753bd2c95c4bdb46c3a4d2c00f0bc0c8568d11d1cbe675d39cdbecdb' and inputs['go.sum']['sha256']==plan['heart_go_sum_sha256'],'Original final module inputs differ')
  workspace=TASK/'workspace';workspace.mkdir();(TASK/'modules').mkdir();(TASK/'owned-cache').mkdir();(TASK/'gopath').mkdir();(TASK/'go-build-cache').mkdir()
  for n in inputs:shutil.copy2(finalsource/n,workspace/n)
  env=os.environ.copy();env.update(GOMODCACHE=str(TASK/'owned-cache'),GOCACHE=str(TASK/'go-build-cache'),GOPATH=str(TASK/'gopath'),GOWORK='off',GOTOOLCHAIN='local',GOFLAGS='-mod=readonly',GO111MODULE='on',GIT_TERMINAL_PROMPT='0',GIT_NO_LAZY_FETCH='1')
  save(TASK/'INPUTS.json',{'original_go':row(GO),'final_module_inputs':inputs,'plan':row(PLAN),'owned_environment':{k:env[k] for k in ['GOMODCACHE','GOCACHE','GOPATH','GOWORK','GOTOOLCHAIN','GOFLAGS','GO111MODULE']},'capacity_stop_reserve_bytes':RESERVE})
  print(json.dumps({'event':'ACTUAL_DRIVER_STARTED','pid':os.getpid(),'task':str(TASK),'time':now(),'free_bytes':space()}),flush=True)
  for index,module in enumerate(plan['modules'],1):
   folder=TASK/'modules'/('%03d'%index);folder.mkdir();cache=TASK/'owned-cache'
   require(cache==cache.resolve() and cache.is_relative_to(TASK) and not cache.is_symlink(),'Owned cache boundary changed')
   require(space()>RESERVE+module['bytes']*2,'Capacity insufficient for next module declared output')
   result.update(current_module=index,current_identity=module['module']+'@'+module['version'],free_before_module_bytes=space());save(TASK/'STATUS.json',result,True)
   print(json.dumps({'event':'DOWNLOAD_START','index':index,'module':result['current_identity'],'time':now(),'free_bytes':space()}),flush=True)
   actual=cmd([str(GO),'mod','download','-json',result['current_identity']],workspace,env,folder,'download',180)
   require(isinstance(actual,dict) and actual.get('Path')==module['module'] and actual.get('Version')==module['version'] and not actual.get('Error'),'Original module download identity failed')
   require(actual.get('Sum')==module['archive_h1'] and actual.get('GoModSum')==module['go_mod_h1'],'Original module h1 identity differs')
   for n in inputs:require(row(finalsource/n)==inputs[n] and identity(row(workspace/n))==identity(inputs[n]),'Original/final module lock changed during download')
   module_dir=Path(actual['Dir']);module_mod=Path(actual['GoMod']);module_zip=Path(actual['Zip']);require(all(p.is_relative_to(cache) and p==p.resolve() for p in [module_dir,module_mod,module_zip]),'Downloader output escapes private cache')
   candidates=[]
   for expected in module['files']:
    target=Path(expected['path']);require(target.is_relative_to(OLD_CACHE) and target==target.resolve(),'Original target escapes retained module cache')
    relative=target.relative_to(OLD_CACHE);donor=cache/relative;observed=row(donor);require(identity(observed)==identity(expected),'Downloaded original declared file differs: '+str(target))
    if os.path.lexists(target):require(row(target)==expected,'Existing original target differs: '+str(target))
    candidates.append((expected,donor,observed))
   receipt={'status':'ALL_ORIGINAL_MODULE_INPUTS_MATCH_BEFORE_PUBLICATION','module':module['module'],'version':module['version'],'archive_h1':actual['Sum'],'go_mod_h1':actual['GoModSum'],'archive':row(module_zip),'declared_inputs':[{'expected':a,'donor':c} for a,b,c in candidates],'free_before_publication_bytes':space()};save(folder/'VERIFIED_BEFORE_PUBLICATION.json',receipt)
   published=[]
   for expected,donor,observed in candidates:
    target=Path(expected['path'])
    if os.path.lexists(target):
     require(row(target)==expected,'Original target changed during publication');published.append({'status':'ALREADY_IDENTICAL','row':expected});result['already_identical_files']+=1;continue
    require(space()>RESERVE+expected['bytes'],'Capacity insufficient for atomic input publication');target.parent.mkdir(parents=True,exist_ok=True);require(target.parent==target.parent.resolve(),'Original target parent resolves through symlink')
    temporary=target.with_name('.'+target.name+'.e973-restore-'+str(uuid.uuid4()))
    copy=subprocess.run(['/bin/cp','-c',str(donor),str(temporary)],capture_output=True,text=True);require(copy.returncode==0,'Scoped temporary clone failed: '+copy.stderr)
    require(identity(row(temporary))==identity(expected),'Staged input differs')
    created=True
    try:os.link(temporary,target)
    except FileExistsError:
     require(row(target)==expected,'Concurrent different target appeared');created=False
    require(row(target)==expected,'Final original input differs');temporary.unlink();published.append({'status':'RESTORED_EXACT' if created else 'CONCURRENT_ALREADY_IDENTICAL','row':expected});result['restored_files' if created else 'already_identical_files']+=1
   receipt.update(status='ORIGINAL_DECLARED_MODULE_FILES_RESTORED_EXACT',published=published,free_after_publication_bytes=space(),finished_at=now());save(folder/'RESULT.json',receipt)
   cleanup=cmd([str(GO),'clean','-modcache'],workspace,env,folder,'clean-owned-module-cache',60)
   require(not cache.exists(),'Owned module cache cleanup left undeclared state');cache.mkdir()
   summary={'index':index,'module':module['module'],'version':module['version'],'files':len(published),'bytes':module['bytes'],'receipt':str(folder/'RESULT.json'),'receipt_sha256':digest(folder/'RESULT.json'),'free_after_owned_cleanup_bytes':space()};result['modules'].append(summary);save(TASK/'STATUS.json',result,True)
   print(json.dumps({'event':'MODULE_RESTORED_EXACT','index':index,'total':198,'files':len(published),'restored_total':result['restored_files'],'already_identical':result['already_identical_files'],'time':now(),'free_bytes':space()}),flush=True)
  require(len(result['modules'])==198 and result['restored_files']+result['already_identical_files']==4444,'Final exact restoration inventory incomplete')
  for module in plan['modules']:
   for expected in module['files']:require(row(Path(expected['path']))==expected,'Final declared file changed after publication')
  require(digest(PLAN)==PLAN_SHA and digest(GO)==GO_SHA,'Original plan/tool changed')
  for n in inputs:require(row(finalsource/n)==inputs[n],'Original final module input changed')
  result['status']='ALL4444_ORIGINAL_DECLARED_MODULE_INPUTS_RESTORED_EXACT'
 except BaseException as error:
  result.update(status='STOPPED_WITH_FAILURE_EVIDENCE_PRESERVED',error_type=type(error).__name__,error=str(error));print(traceback.format_exc(),flush=True)
 finally:
  result.update(finished_at=now(),free_final_bytes=space());save(TASK/'RESULT.json',result);save(TASK/'STATUS.json',result,True);print(json.dumps({'event':'DRIVER_FINISHED','status':result['status'],'modules':len(result['modules']),'restored_files':result['restored_files'],'already_identical_files':result['already_identical_files'],'result':str(TASK/'RESULT.json'),'sha256':digest(TASK/'RESULT.json'),'error':result.get('error'),'time':now()}),flush=True)
 return 0 if result['status']=='ALL4444_ORIGINAL_DECLARED_MODULE_INPUTS_RESTORED_EXACT' else 1
if __name__=='__main__':sys.exit(main())
