import os,sys,pathlib,subprocess,json,hashlib,datetime,shutil,time,signal,shlex,traceback
Q=pathlib.Path('/Users/m1/builds/otzaria-wave1-sdk-20261127/source')
SUP=Q.parent/'evidence/sdk-1be-framework-after-restoration-attempt2-20261127'
EV=Q/'build/SDK-Wave1-1be97035-Debug-Evidence'
WORK=Q/'build/SDK-Wave1-1be97035-Debug-Work'
MACRO=Q/'build/SDK-Wave1-1be97035-Debug-ReviewedMacro-AfterRestorationAttempt2-20261127'
ABI=Q/'build/SDK-Wave3-1be97035-NativeABI-AfterRestoration-20261127/ABI_DONOR_INPUT.json'
PY='/opt/homebrew/opt/python@3.12/libexec/bin/python3'
SOURCE='1be970356c655bcef3688ddf1d129d5029bbc533'
IDENTITY_SHA='37147361fcaad1521fc3f3d47279341dd3c6b25db619f801babfab3ce0ff0528'
ABI_SHA='adab56b1ad2c6fc06d7b154b4df0112a9a3dfdde4230a576e5064bd15bd04496'
RESERVE=2*1024**3
STOP_FREE=RESERVE+256*1024**2
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(name,value):
 p=SUP/name;t=p.with_name(p.name+'.tmp')
 t.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');os.replace(t,p)
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(Q),*args],text=True).strip()
def preflight():
 if git('rev-parse','HEAD')!=SOURCE or git('status','--porcelain','--untracked-files=no'):raise RuntimeError('Source is not clean exact 1be')
 if sha(EV/'local-execution.json')!=IDENTITY_SHA or sha(ABI)!=ABI_SHA:raise RuntimeError('Genuine identity or prepared ABI digest differs')
 if WORK.exists() or MACRO.exists() or (EV/'execution.json').exists():raise RuntimeError('Original framework output is not fresh')
 processes=subprocess.check_output(['ps','axo','pid,ppid,pgid,command'],text=True)
 conflicts=[l for l in processes.splitlines() if ('run_framework_acceptance.py' in l or 'prepare_reviewed_macro.py' in l or ('xcodebuild' in l and str(Q) in l))]
 if conflicts:raise RuntimeError('Competing original SDK process: '+str(conflicts))
 free=shutil.disk_usage(Q).free
 if free<=STOP_FREE:raise RuntimeError('Capacity reserve unavailable before launch')
 return {'source_sha':SOURCE,'tracked_clean':True,'work_absent':True,'macro_output_absent':True,'framework_execution_absent':True,'free_bytes':free,'reserve_bytes':RESERVE,'early_stop_free_bytes':STOP_FREE,'provisional_growth_budget_bytes':free-RESERVE,'checked_at':now(),'conflicting_processes':conflicts}
ENV=dict(os.environ)
for key in ['GITHUB_SHA','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT']:ENV.pop(key,None)
env_rows={}
for line in (EV/'local-execution.env').read_text().splitlines():
 words=shlex.split(line)
 if len(words)!=2 or words[0]!='export' or '=' not in words[1]:raise RuntimeError('Unexpected original local execution environment line')
 k,v=words[1].split('=',1);env_rows[k]=v
if env_rows!={'OTZARIA_LOCAL_EXECUTION':str(EV/'local-execution.json'),'OTZARIA_LOCAL_EXECUTION_SHA256':IDENTITY_SHA}:raise RuntimeError('Original local environment differs')
ENV.update(env_rows)
ENV['PYTHONDONTWRITEBYTECODE']='1'
ENV['GIT_NO_LAZY_FETCH']='1'
ENV['GIT_TERMINAL_PROMPT']='0'
state={'schema':'otzaria.wave3.original-sdk-supervision/1','source_sha':SOURCE,'owner':'root coordinated SDK window; navigation_fix execution','supervisor_pid':os.getpid(),'supervisor_pgid':os.getpgrp(),'started_at':now(),'status':'PRELAUNCH','framework_invoked':False,'commands':[],'capacity_signals':[],'reserve_bytes':RESERVE,'early_stop_free_bytes':STOP_FREE,'cache_seed_reuse':False,'automatic_artifact_cleanup':False,'original_controller_owned_simulator_cleanup_unchanged':True}
write('STATUS.json',state)
def run(name,argv,monitor=True):
 stdout=SUP/(name+'.stdout.log');stderr=SUP/(name+'.stderr.log')
 row={'name':name,'argv':argv,'cwd':str(Q),'started_at':now(),'free_before_bytes':shutil.disk_usage(Q).free}
 with stdout.open('xb') as out,stderr.open('xb') as err:
  p=subprocess.Popen(argv,cwd=str(Q),env=ENV,stdout=out,stderr=err,start_new_session=True)
  row.update(pid=p.pid,pgid=os.getpgid(p.pid));state['commands'].append(row);state['phase']=name;state['active_pid']=p.pid
  if name=='framework':state['framework_invoked']=True;write('FRAMEWORK_ACTUAL_LAUNCH.json',row)
  write(name+'.ACTUAL_LAUNCH.json',row);write('STATUS.json',state)
  print(json.dumps({'event':'ACTUAL_COMMAND_STARTED','name':name,'pid':p.pid,'pgid':row['pgid'],'at':row['started_at']}),flush=True)
  signaled=False
  with (SUP/'disk-samples.jsonl').open('a') as samples:
   while True:
    free=shutil.disk_usage(Q).free
    phase=None
    if name=='framework' and (EV/'execution.json').is_file():
     try:phase=json.loads((EV/'execution.json').read_text()).get('phase')
     except Exception:pass
    sample={'at':now(),'command':name,'pid':p.pid,'free_bytes':free,'controller_phase':phase}
    samples.write(json.dumps(sample,sort_keys=True)+'\n');samples.flush()
    state['last_sample']=sample;write('STATUS.json',state)
    if monitor and free<=STOP_FREE and p.poll() is None and not signaled:
     if os.getpgid(p.pid)!=p.pid:raise RuntimeError('Own controller process-group identity differs')
     evidence={'at':now(),'pid':p.pid,'pgid':p.pid,'signal':'SIGINT','free_bytes':free,'reason':'APPROACHING_RECORDED_2_GIB_CAPACITY_RESERVE','scope':'Only this launched original controller group; its unchanged command() owns child-group draining'}
     state['capacity_signals'].append(evidence);write('STATUS.json',state)
     os.killpg(p.pid,signal.SIGINT);signaled=True
     print(json.dumps(evidence),flush=True)
    try:
     rc=p.wait(timeout=5);break
    except subprocess.TimeoutExpired:pass
  row.update(returncode=rc,finished_at=now(),free_after_bytes=shutil.disk_usage(Q).free,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),capacity_stop_requested=signaled)
  write(name+'.COMMAND_RESULT.json',row);state['active_pid']=None;write('STATUS.json',state)
  print(json.dumps({'event':'ACTUAL_COMMAND_FINISHED','name':name,'returncode':rc,'at':row['finished_at']}),flush=True)
 return rc
error=None;framework_rc=None;restore_rc=None
try:
 check=preflight();write('PREFLIGHT.json',check);state['preflight']=check
 state['status']='ORIGINAL_REVIEWED_MACRO_PREPARATION';write('STATUS.json',state)
 rc=run('macro-prepare',[PY,'-B','Tools/OriginalEditor/prepare_reviewed_macro.py','--root',str(Q),'--evidence',str(MACRO)])
 if rc!=0:raise RuntimeError('Original reviewed macro preparation failed with exit '+str(rc))
 if git('rev-parse','HEAD')!=SOURCE or git('status','--porcelain','--untracked-files=no') or WORK.exists():raise RuntimeError('Source/work changed before original framework launch')
 if shutil.disk_usage(Q).free<=STOP_FREE:raise RuntimeError('Capacity reserve unavailable before framework launch')
 state['status']='ORIGINAL_FRAMEWORK_ACCEPTANCE_RUNNING';write('STATUS.json',state)
 framework_rc=run('framework',[PY,'-B','Tools/OriginalEditor/run_framework_acceptance.py','--root',str(Q),'--evidence',str(EV),'--work',str(WORK),'--import-abi-receipt',str(ABI),'--import-abi-sha256',ABI_SHA])
 if framework_rc!=0:raise RuntimeError('Original framework acceptance failed with exit '+str(framework_rc))
except BaseException as exc:
 error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
finally:
 if (MACRO/'owned-trust-state.json').is_file():
  try:
   restore_rc=run('macro-restore',[PY,'-B','Tools/OriginalEditor/prepare_reviewed_macro.py','--root',str(Q),'--evidence',str(MACRO),'--restore'],monitor=False)
  except BaseException as exc:
   state['macro_restoration_error']={'type':type(exc).__name__,'message':str(exc)}
 if (EV/'execution.json').is_file():
  try:
   x=json.loads((EV/'execution.json').read_text())
   state['original_execution']={'path':str(EV/'execution.json'),'sha256':sha(EV/'execution.json'),'status':x.get('status'),'phase':x.get('phase'),'source_sha':x.get('source_sha'),'original_framework_build':x.get('original_framework_build'),'external_consumer_build':x.get('external_consumer_build'),'verified_runtime_observations':len(x.get('verified_runtime_observations',[])),'error':x.get('error')}
  except BaseException as exc:state['execution_read_error']=str(exc)
 state.update(error=error,framework_returncode=framework_rc,macro_restore_returncode=restore_rc,finished_at=now(),free_after_bytes=shutil.disk_usage(Q).free,source_after=git('rev-parse','HEAD'),tracked_status_after=git('status','--porcelain','--untracked-files=no'))
 ok=(error is None and framework_rc==0 and restore_rc==0 and not state['capacity_signals'] and state.get('original_execution',{}).get('status')=='ACTUAL_ORIGINAL_FRAMEWORK_EXTERNAL_IMPORT_LINK_RESOURCES_PASS' and state['source_after']==SOURCE and not state['tracked_status_after'])
 state['status']='ORIGINAL_FRAMEWORK_CONTROLLER_COMPLETE' if ok else 'NOT_COMPLETE'
 write('STATUS.json',state);write('RESULT.json',state)
 print(json.dumps({'event':'SUPERVISION_FINISHED','status':state['status'],'result':str(SUP/'RESULT.json'),'sha256':sha(SUP/'RESULT.json'),'error':error}),flush=True)
sys.exit(0 if ok else 1)
