#!/usr/bin/env python3
"""Local Python authority/preservation controls, never Apple/Swift execution."""
from contextlib import ExitStack, redirect_stdout
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import yaml

ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT / "candidate"
SPEC = importlib.util.spec_from_file_location("sdk_guard", CANDIDATE / "Scripts/CI/verify-ui-sdk-intermediate-source.py")
guard = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(guard)


class ExistingJobPreservation(unittest.TestCase):
    def testOriginalSelectorCompileWorkspaceAndArtifactStepsAreExact(self):
        old = yaml.load((ROOT / "original-workflow.yml").read_text(), Loader=yaml.BaseLoader)
        new = yaml.load((CANDIDATE / guard.WORKFLOW).read_text(), Loader=yaml.BaseLoader)
        old_job, new_job = old["jobs"]["ui-sdk-check-only"], new["jobs"]["ui-sdk-check-only"]
        self.assertEqual(new_job["timeout-minutes"], old_job["timeout-minutes"])
        self.assertEqual(new_job["name"], old_job["name"])
        names = ["Select the same existing SDK and runtime pair as Native acceptance",
                 "Typecheck black-box tests with the actual iPad SDK",
                 "Verify actual portable workspace contracts on macOS",
                 "Upload exact SDK and compiler diagnostics"]
        for name in names:
            a = [step for step in old_job["steps"] if step.get("name") == name]
            b = [step for step in new_job["steps"] if step.get("name") == name]
            self.assertEqual(len(a), 1); self.assertEqual(a, b)
        self.assertEqual(new["permissions"], old["permissions"])
        self.assertEqual(new_job["runs-on"], "xcode-27")

    def testOnlyExactPushBranchCanActivate(self):
        new = yaml.load((CANDIDATE / guard.WORKFLOW).read_text(), Loader=yaml.BaseLoader)
        self.assertEqual(new["on"], {"push": {"branches": [guard.BRANCH.removeprefix("refs/heads/")]}})
        self.assertEqual(new["concurrency"]["cancel-in-progress"], "false")
        job = new["jobs"]["ui-sdk-check-only"]
        self.assertIn(guard.BRANCH, job["if"])
        self.assertIn("github.event_name == 'push'", job["if"])
        self.assertEqual(len(new["jobs"]), 1)
        self.assertFalse(any("workflow_dispatch" in str(step) for step in job["steps"]))
        self.assertEqual(job["steps"][0]["with"]["ref"], "${{ github.sha }}")

    def testCurrentScopeIsElevenCompleteSourcesAndFourBoundTrees(self):
        self.assertEqual(len(guard.UI_FILES), 11)
        self.assertEqual(len(set(guard.UI_FILES)), 11)
        self.assertIn("FaithfulReaderUIAcceptanceTests.swift", guard.UI_FILES)
        self.assertIn("GlobalSearchNativeAcceptanceTests.swift", guard.UI_FILES)
        self.assertEqual(set(guard.SOURCE_TREES), {"Source", "Vendor", "Maktabah.xcodeproj", "Maktabah-iOSUITests"})
        self.assertEqual(guard.REVIEWED_SOURCE_COMMIT, "e603d8182a1c10c4b37b14c92b5f0bc3829edea8")


class SourceAdmission(unittest.TestCase):
    def testActualFileMatchesCommittedBytes(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(guard, "ROOT", Path(directory)):
            data = b"actual temporary source\n"; path = Path(directory) / "source.swift"; path.write_bytes(data)
            blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            with patch.object(guard, "git", return_value=blob):
                row = guard.source_record("source.swift", "a" * 40)
                self.assertEqual(row["bytes"], len(data)); self.assertEqual(row["git_blob"], blob)
                path.write_bytes(data + b"changed")
                with self.assertRaises(ValueError): guard.source_record("source.swift", "a" * 40)

    def testMissingAndSymlinkInputsAreRejected(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(guard, "ROOT", Path(directory)):
            with self.assertRaises(ValueError): guard.source_record("missing", "a" * 40)
            (Path(directory) / "actual").write_bytes(b"owned")
            (Path(directory) / "alias").symlink_to("actual")
            with self.assertRaises(ValueError): guard.source_record("alias", "a" * 40)

    def testOriginalPinnedDriverCannotBeReplacedByAnotherCommittedFile(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(guard, "ROOT", Path(directory)):
            (Path(directory) / "original").write_bytes(b"different")
            data = b"different"; blob = hashlib.sha1(b"blob 9\0" + data).hexdigest()
            with patch.object(guard, "ORIGINAL_INPUTS", {"original": "0" * 40}), patch.object(guard, "git", return_value=blob):
                with self.assertRaises(ValueError): guard.source_record("original", "a" * 40)

    def identity(self, env=None, dirty=False, wrong_head=False, wrong_tree=False):
        observed_env = {"GITHUB_EVENT_NAME": "push", "GITHUB_REPOSITORY": "davidpovarsky/Maktabah",
                        "GITHUB_REF": guard.BRANCH, "GITHUB_SHA": "a" * 40}
        observed_env.update(env or {})
        def git(*args):
            if args == ("rev-parse", "HEAD"): return ("b" if wrong_head else "a") * 40
            if args[0] == "status": return " M source" if dirty else ""
            name = args[1].split(":", 1)[1]
            return "0" * 40 if wrong_tree else guard.SOURCE_TREES[name]
        with patch.dict(os.environ, observed_env, clear=True), patch.object(guard, "git", side_effect=git), patch.object(
                guard, "source_record", side_effect=lambda path, head: {"path": path, "head": head}):
            return guard.observe_source()

    def testActualPushIdentityAndTreeCanBeObserved(self):
        value = self.identity()
        self.assertEqual(value["head"], "a" * 40)
        self.assertEqual(value["source_trees"], guard.SOURCE_TREES)

    def testWrongRepositoryEventRefOrHeadFailClosed(self):
        for env in [{"GITHUB_EVENT_NAME": "workflow_dispatch"}, {"GITHUB_REPOSITORY": "other/repository"},
                    {"GITHUB_REF": "refs/heads/main"}, {"GITHUB_SHA": "not-a-sha"}]:
            with self.subTest(env=env), self.assertRaises(ValueError): self.identity(env)
        with self.assertRaises(ValueError): self.identity(wrong_head=True)

    def testDirtyOrDifferentApplicationTreeFailClosed(self):
        with self.assertRaises(ValueError): self.identity(dirty=True)
        with self.assertRaises(ValueError): self.identity(wrong_tree=True)


class PersistentFailureEvidence(unittest.TestCase):
    def invoke(self, root, phase, observed=None, error=None):
        with patch.object(guard, "ROOT", root), patch.object(guard, "observe_source", return_value=observed, side_effect=error), patch(
                "sys.argv", ["guard", "--phase", phase]), redirect_stdout(io.StringIO()):
            return guard.main()

    def testBeforeAfterExactSourceRetainsBothReceipts(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); value = {"head": "a" * 40}
            self.assertEqual(self.invoke(root, "before", value), 0)
            self.assertEqual(self.invoke(root, "after", value), 0)
            self.assertEqual(json.loads((root / (guard.PREFIX + ".after.json")).read_text())["status"], "SOURCE_UNCHANGED")

    def testChangedSourceOrMissingBeforeCannotBecomeSuccess(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertEqual(self.invoke(root, "after", {"head": "a" * 40}), 1)
            self.assertEqual(self.invoke(root, "before", {"head": "a" * 40}), 0)
            self.assertEqual(self.invoke(root, "after", {"head": "b" * 40}), 1)
            self.assertEqual(json.loads((root / (guard.PREFIX + ".after.json")).read_text())["status"], "SOURCE_BINDING_FAILED")

    def testObservedFailureIsWrittenAndHasNoNativeCredit(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertEqual(self.invoke(root, "before", error=ValueError("actual rejected source")), 1)
            report = json.loads((root / (guard.PREFIX + ".before.json")).read_text())
            self.assertEqual(report["status"], "SOURCE_BINDING_FAILED")
            self.assertEqual(report["native_ui_executed"], 0)
            self.assertEqual(report["error_type"], "ValueError")


if __name__ == "__main__":
    unittest.main(verbosity=2)
