import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

actor SefariaHTTPClient {
    private let session: URLSession
    private let decoder: JSONDecoder
    private let maximumAttempts = 3

    init(session: URLSession = .shared) {
        self.session = session
        self.decoder = JSONDecoder()
    }

    func get<T: Decodable & Sendable>(
        _ type: T.Type,
        url: URL,
        timeoutInterval: TimeInterval = 30,
        maxAttempts: Int? = nil
    ) async throws -> T {
        var request = URLRequest(url: url, timeoutInterval: timeoutInterval)
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        return try await send(type, request: request, maxAttempts: maxAttempts ?? maximumAttempts)
    }

    func post<T: Decodable & Sendable, Body: Encodable & Sendable>(
        _ type: T.Type, url: URL, body: Body,
        timeoutInterval: TimeInterval = 30, maxAttempts: Int? = nil
    ) async throws -> T {
        var request = URLRequest(url: url, timeoutInterval: timeoutInterval)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        request.httpBody = try JSONEncoder().encode(body)
        return try await send(type, request: request, maxAttempts: maxAttempts ?? maximumAttempts)
    }

    func postData<Body: Encodable & Sendable>(url: URL, body: Body) async throws -> (Data, HTTPURLResponse) {
        var request = URLRequest(url: url, timeoutInterval: 300)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        request.httpBody = try JSONEncoder().encode(body)
        do {
            let (data, response) = try await session.data(for: request)
            try validate(response)
            guard let http = response as? HTTPURLResponse else {
                throw LibraryBackendError.invalidResponse("missing HTTP response")
            }
            return (data, http)
        } catch {
            throw Self.userFacing(error)
        }
    }

    func data(url: URL) async throws -> Data {
        var request = URLRequest(url: url, timeoutInterval: 120)
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        do {
            let (data, response) = try await session.data(for: request)
            try validate(response)
            return data
        } catch {
            throw Self.userFacing(error)
        }
    }

    func download(url: URL) async throws -> (URL, HTTPURLResponse) {
        var request = URLRequest(url: url, timeoutInterval: 300)
        request.setValue("Maktabah/1 SefariaNative", forHTTPHeaderField: "User-Agent")
        do {
            let (temporary, response) = try await session.download(for: request)
            try validate(response)
            guard let response = response as? HTTPURLResponse else {
                throw LibraryBackendError.invalidResponse("missing HTTP response")
            }
            return (temporary, response)
        } catch {
            throw Self.userFacing(error)
        }
    }

    private func send<T: Decodable>(
        _ type: T.Type,
        request: URLRequest,
        maxAttempts: Int = 3
    ) async throws -> T {
        var attempt = 1
        while true {
            try Task.checkCancellation()
            do {
                let (data, response) = try await session.data(for: request)
                try validate(response)
                do { return try decoder.decode(type, from: data) }
                catch { throw LibraryBackendError.invalidResponse(String(describing: error)) }
            } catch {
                try Task.checkCancellation()
                guard attempt < maxAttempts, Self.isTransient(error) else {
                    throw Self.userFacing(error)
                }
                try await Task.sleep(nanoseconds: UInt64(attempt) * 500_000_000)
                try Task.checkCancellation()
                attempt += 1
            }
        }
    }

    nonisolated static func userFacing(_ error: Error) -> Error {
        guard let urlError = error as? URLError else { return error }
        switch urlError.code {
        case .timedOut, .networkConnectionLost, .cannotFindHost, .cannotConnectToHost,
             .dnsLookupFailed, .notConnectedToInternet, .internationalRoamingOff,
             .dataNotAllowed:
            return LibraryBackendError.unavailableOffline
        default:
            return error
        }
    }

    private nonisolated static func isTransient(_ error: Error) -> Bool {
        if let backendError = error as? LibraryBackendError,
           case .httpStatus(let status) = backendError {
            return status == 429 || status == 500 || status == 502 || status == 503 || status == 504
        }
        guard let urlError = error as? URLError else { return false }
        switch urlError.code {
        case .timedOut, .networkConnectionLost, .cannotConnectToHost,
             .dnsLookupFailed, .notConnectedToInternet:
            return true
        default:
            return false
        }
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else {
            throw LibraryBackendError.invalidResponse("missing HTTP status")
        }
        guard (200...299).contains(http.statusCode) else {
            throw LibraryBackendError.httpStatus(http.statusCode)
        }
    }
}
