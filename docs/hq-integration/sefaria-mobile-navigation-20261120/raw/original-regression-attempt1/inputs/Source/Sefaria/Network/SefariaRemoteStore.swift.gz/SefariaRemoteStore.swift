import Foundation

actor SefariaRemoteStore: LibraryCatalogProviding, LibraryTextProviding,
    LibraryNavigationProviding, LibrarySearchProviding, LibraryMetadataProviding,
    LibraryRelationshipsProviding, LibraryWorkMetadataProviding {
    private let configuration: SefariaNetworkConfiguration
    private let client: SefariaHTTPClient
    private let cache: SefariaDiskCache
    private var knownTitles: Set<String> = []
    private var catalogTask: Task<[SefariaTOCEntryDTO], Error>?
    private var sectionRefByReference: [String: String] = [:]
    private var relatedRowsBySection: [String: [SefariaRelationshipLinkDTO]] = [:]
    private var relatedTasksBySection: [String: Task<[SefariaRelationshipLinkDTO], Error>] = [:]
    private var activeSession: BooleanSearchSession?
    private var activeSessionKey: BooleanSearchSessionKey?
    private var searchServiceObservation: (available: Bool, until: UInt64)?
    private var searchServiceProbe: Task<Bool, Error>?
    private var searchServiceGeneration: UInt64 = 0

    init(
        configuration: SefariaNetworkConfiguration = .production,
        client: SefariaHTTPClient = SefariaHTTPClient(),
        cache: SefariaDiskCache = SefariaDiskCache()
    ) {
        self.configuration = configuration
        self.client = client
        self.cache = cache
    }

    /// A bounded, read-only observation of the actual existing search endpoint.
    /// It does not reset UI search sessions, write a disk cache, use user query
    /// text, or infer availability from generic connectivity/downloaded books.
    func observeSearchService() async throws -> Bool {
        try Task.checkCancellation()
        let now = DispatchTime.now().uptimeNanoseconds
        if let observation = searchServiceObservation, now < observation.until { return observation.available }
        let generation = searchServiceGeneration
        if let probe = searchServiceProbe {
            let value = try await probe.value
            try Task.checkCancellation()
            guard generation == searchServiceGeneration else { throw LibraryBackendError.staleRequest }
            return value
        }
        let url = try configuration.apiURL(path: "/api/search-wrapper")
        var options = LibrarySearchOptions()
        options.matchMode = .exact; options.wordDistance = 0
        let body = SefariaSearchBody(query: "maktabah_readiness_" + UUID().uuidString,
            start: 0, size: 1, options: options)
        let probe = Task { [client] in
            let response = try await client.post(SefariaSearchResponseDTO.self, url: url, body: body,
                timeoutInterval: 2, maxAttempts: 1)
            return response.hits.hits.count <= 1
        }
        searchServiceProbe = probe
        do {
            let available = try await probe.value
            guard generation == searchServiceGeneration else { throw LibraryBackendError.staleRequest }
            searchServiceProbe = nil
            searchServiceObservation = (available, DispatchTime.now().uptimeNanoseconds + 5_000_000_000)
            try Task.checkCancellation()
            return available
        } catch {
            if generation == searchServiceGeneration { searchServiceProbe = nil }
            throw error
        }
    }

    func catalog(forceRefresh: Bool) async throws -> [LibraryCatalogNode] {
        if !forceRefresh, let cached: [SefariaTOCEntryDTO] = await cache.decode("catalog.json") {
            rememberTitles(cached)
            return cached.map { Self.mapCatalog($0, parentPath: []) }
        }
        let dto: [SefariaTOCEntryDTO]
        if let catalogTask {
            dto = try await catalogTask.value
        } else {
            let url = try configuration.apiURL(path: "/api/index")
            let task = Task { try await client.get([SefariaTOCEntryDTO].self, url: url) }
            catalogTask = task
            do {
                dto = try await task.value
                catalogTask = nil
            } catch {
                catalogTask = nil
                throw error
            }
        }
        try await cache.encode(dto, as: "catalog.json")
        rememberTitles(dto)
        return dto.map { Self.mapCatalog($0, parentPath: []) }
    }

    func section(at locator: TextLocator) async throws -> LibraryTextSection {
        try await section(at: locator, redirectDepth: 0)
    }

    private func section(at locator: TextLocator, redirectDepth: Int) async throws -> LibraryTextSection {
        guard redirectDepth <= 3 else {
            throw LibraryBackendError.invalidResponse("Exceeded maximum redirects for section \(locator)")
        }
        guard locator.backend == .sefaria, case .canonicalRef(let ref) = locator.position else {
            throw LibraryBackendError.invalidLocator
        }
        if LibraryReadingUnitPolicy.isWorkRoot(locator) {
            let work = LibraryWork(locator: locator, title: locator.workKey, heTitle: nil,
                categories: [], description: nil)
            let items = try await navigationItems(for: work)
            return try await section(at: LibraryReadingUnitPolicy.resolve(locator, navigationItems: items), redirectDepth: redirectDepth)
        }
        let cacheName = "section-\(Data(ref.utf8).base64EncodedString().replacingOccurrences(of: "/", with: "_"))"
        if let cached: SefariaTextsV3DTO = await cache.decode(cacheName) {
            rememberSectionReferences(cached)
            if cached.sectionRef != ref {
                return try await section(at: TextLocator(backend: .sefaria, workKey: locator.workKey, position: .canonicalRef(cached.sectionRef)), redirectDepth: redirectDepth + 1)
            }
            return map(cached, origin: .diskCache).asLibrarySection()
        }
        let url = try configuration.apiURL(pathPrefix: "/api/v3/texts/", pathComponent: ref, queryItems: [
            URLQueryItem(name: "version", value: "source"),
            URLQueryItem(name: "version", value: "translation"),
            URLQueryItem(name: "fill_in_missing_segments", value: "1"),
            URLQueryItem(name: "return_format", value: "text_only")
        ])
        let dto = try await client.get(SefariaTextsV3DTO.self, url: url)
        try await cache.encode(dto, as: cacheName)
        rememberSectionReferences(dto)
        if dto.sectionRef != ref {
            return try await section(at: TextLocator(backend: .sefaria, workKey: locator.workKey, position: .canonicalRef(dto.sectionRef)), redirectDepth: redirectDepth + 1)
        }
        return map(dto, origin: .remote).asLibrarySection()
    }

    func normalizedLocator(for input: String) async throws -> TextLocator {
        let normalized = SefariaRef.canonicalInput(input)
        let url = try configuration.apiURL(pathPrefix: "/api/name/", pathComponent: normalized)
        let response = try await client.get(SefariaNameDTO.self, url: url)
        guard response.isRef == true, let ref = response.ref else { throw LibraryBackendError.invalidLocator }
        if knownTitles.isEmpty { _ = try? await catalog(forceRefresh: false) }
        guard let work = SefariaRef.workKey(from: ref, knownTitles: Array(knownTitles)) else {
            throw LibraryBackendError.invalidLocator
        }
        return TextLocator(backend: .sefaria, workKey: work, position: .canonicalRef(ref))
    }

    func navigationStructures(for work: LibraryWork) async throws -> [LibraryNavigationStructure] {
        let indexURL = try configuration.apiURL(
            pathPrefix: "/api/v2/raw/index/",
            pathComponent: work.locator.workKey
        )
        let shapeURL = try configuration.apiURL(
            pathPrefix: "/api/shape/",
            pathComponent: work.locator.workKey
        )
        async let indexRequest = client.get(SefariaIndexDTO.self, url: indexURL)
        async let shapeRequest = client.get([SefariaShapeDTO].self, url: shapeURL)
        let index = try await indexRequest
        let shapes = try? await shapeRequest
        return SefariaNavigationParser.structures(
            shapes: shapes,
            schema: index.schema,
            alternateStructures: index.alternateStructures,
            indexTitle: index.title
        )
    }

    func tableOfContents(for work: LibraryWork) async throws -> [LibraryTOCNode] {
        let structs = try await navigationStructures(for: work)
        return structs.first?.nodes ?? []
    }

    func navigationItems(for work: LibraryWork) async throws -> [LibraryNavigationItem] {
        let toc = try await tableOfContents(for: work)
        var items: [LibraryNavigationItem] = []
        func collectLeaves(_ nodes: [LibraryTOCNode]) {
            for node in nodes {
                if node.children.isEmpty {
                    items.append(LibraryNavigationItem(
                        locator: node.locator,
                        title: node.title,
                        index: items.count
                    ))
                } else {
                    collectLeaves(node.children)
                }
            }
        }
        collectLeaves(toc)
        return items
    }

    func workMetadata(for workKey: String) async throws -> LibraryWorkMetadata? {
        let indexURL = try configuration.apiURL(
            pathPrefix: "/api/v2/raw/index/",
            pathComponent: workKey
        )
        let index = try await client.get(SefariaIndexDTO.self, url: indexURL)
        return index.asWorkMetadata(workKey: workKey)
    }
    func search(_ request: LibrarySearchRequest) async throws -> LibrarySearchPage {
        if !request.scopeWorkKeys.isEmpty, request.filters.isEmpty {
            return try await searchWithinWorksFallback(request)
        }
        let terms = Self.extractSearchTerms(from: request.query)
        if request.options.searchMode == .or && terms.count > 1 {
            return try await searchOr(terms: terms, request: request)
        }
        if request.options.searchMode == .contains && terms.count > 1 {
            return try await searchContains(terms: terms, request: request)
        }

        invalidateSearchSession()

        let url = try configuration.apiURL(path: "/api/search-wrapper")
        let response = try await client.post(SefariaSearchResponseDTO.self, url: url, body: SefariaSearchBody(
            query: request.query,
            start: request.offset,
            size: request.limit,
            filters: request.filters,
            options: request.options
        ))
        let page = try projectSearchResponse(response, request: request)
        hydrateCatalogInBackgroundIfNeeded()
        return page
    }

    /// Preserve actual source evidence at the existing provider boundary.
    /// No second provider, query, catalog parser or action-wire DTO is created.
    func projectSearchResponse(_ response: SefariaSearchResponseDTO, request: LibrarySearchRequest) throws -> LibrarySearchPage {
        let hits = mapSearchHits(response.hits.hits)
        let receivedCount = response.hits.hits.count
        guard hits.count == receivedCount else {
            throw LibraryBackendError.invalidResponse("A search source row has no usable work identity")
        }
        let consumed = request.offset.addingReportingOverflow(receivedCount)
        guard !consumed.overflow else { throw LibraryBackendError.invalidResponse("Search cursor overflow") }
        let next = receivedCount > 0 && (response.hits.total.relation != "eq" || consumed.partialValue < response.hits.total.value)
            ? consumed.partialValue : nil
        return LibrarySearchPage(hits: hits, total: response.hits.total.value, nextOffset: next,
            sourceEvidence: .init(backend: .sefaria, rawHitCount: receivedCount,
                allRowsMapped: hits.count == receivedCount, totalRelation: response.hits.total.relation))
    }

    private func searchWithinWorksFallback(_ request: LibrarySearchRequest) async throws -> LibrarySearchPage {
        let requestedWorks = Set(request.scopeWorkKeys)
        var remoteOffset = 0
        var remoteExhausted = false
        var matches: [LibrarySearchHit] = []
        var seen = Set<String>()
        let targetCount = request.offset + request.limit
        let batchSize = max(100, request.limit)

        while matches.count < targetCount, !remoteExhausted {
            try Task.checkCancellation()
            let page = try await search(LibrarySearchRequest(
                query: request.query,
                offset: remoteOffset,
                limit: batchSize,
                filters: [],
                scopeWorkKeys: [],
                options: request.options
            ))
            for hit in page.hits where requestedWorks.contains(hit.locator.workKey) {
                if seen.insert(hit.id).inserted { matches.append(hit) }
            }
            guard let next = page.nextOffset, next > remoteOffset else {
                remoteExhausted = true
                break
            }
            remoteOffset = next
        }

        let slice = Array(matches.dropFirst(min(request.offset, matches.count)).prefix(request.limit))
        let hasMore = matches.count > request.offset + slice.count || !remoteExhausted
        let nextOffset = hasMore && !slice.isEmpty ? request.offset + slice.count : nil
        let total = remoteExhausted
            ? matches.count
            : max(matches.count + 1, request.offset + slice.count + (hasMore ? 1 : 0))
        return LibrarySearchPage(hits: slice, total: total, nextOffset: nextOffset)
    }

    nonisolated static func extractSearchTerms(from query: String) -> [String] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }

        // Protect internal quotes between letters (Hebrew gershayim abbreviations like רש"י)
        let protected = trimmed.replacingOccurrences(
            of: #"(\S)"(\S)"#,
            with: "$1\u{05F4}$2",
            options: .regularExpression
        )

        var terms: [String] = []
        var inQuotes = false
        var current = ""

        for char in protected {
            if char == "\"" {
                if inQuotes {
                    let term = current.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !term.isEmpty {
                        terms.append(term)
                    }
                    current = ""
                    inQuotes = false
                } else {
                    let term = current.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !term.isEmpty {
                        terms.append(contentsOf: term.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty })
                    }
                    current = ""
                    inQuotes = true
                }
            } else {
                current.append(char)
            }
        }
        let remainder = current.trimmingCharacters(in: .whitespacesAndNewlines)
        if !remainder.isEmpty {
            if inQuotes {
                terms.append(remainder)
            } else {
                terms.append(contentsOf: remainder.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty })
            }
        }
        return terms
    }

    private struct BooleanSearchSessionKey: Equatable {
        let query: String
        let searchMode: LibrarySearchMode
        let matchMode: LibrarySearchMatchMode
        let filters: [String]
        let sortOrder: LibrarySearchSortOrder
        let reverseSort: Bool

        init(request: LibrarySearchRequest) {
            self.query = request.query
            self.searchMode = request.options.searchMode
            self.matchMode = request.options.matchMode
            self.filters = request.filters
            self.sortOrder = request.options.sortOrder
            self.reverseSort = request.options.reverseSort
        }
    }

    private final class TermStreamState {
        let term: String
        var nextRemoteStart: Int = 0
        var total: Int = 0
        var hasMoreRemote: Bool = true
        var hitsByLocator: [String: LibrarySearchHit] = [:]
        var orderedLocators: [String] = []

        init(term: String) {
            self.term = term
        }
    }

    private final class BooleanSearchSession {
        let key: BooleanSearchSessionKey
        let streams: [TermStreamState]
        var uniqueHitsMap: [String: LibrarySearchHit] = [:]

        init(key: BooleanSearchSessionKey, terms: [String]) {
            self.key = key
            self.streams = terms.map { TermStreamState(term: $0) }
        }
    }

    private func searchOr(terms: [String], request: LibrarySearchRequest) async throws -> LibrarySearchPage {
        hydrateCatalogInBackgroundIfNeeded()
        try Task.checkCancellation()

        let key = BooleanSearchSessionKey(request: request)
        let session: BooleanSearchSession
        if let existing = activeSession, activeSessionKey == key {
            session = existing
        } else {
            session = BooleanSearchSession(key: key, terms: terms)
            activeSession = session
            activeSessionKey = key
        }

        let targetCount = request.offset + request.limit
        let batchSize = max(request.limit, 25)
        let maxBatchesPerCall = 15

        typealias BatchResult = (termIndex: Int, rawHits: [SefariaSearchResponseDTO.Hit], total: Int)
        var iterations = 0

        while session.streams.contains(where: { $0.hasMoreRemote }) {
            try Task.checkCancellation()
            let activeIndices = session.streams.indices.filter { session.streams[$0].hasMoreRemote }
            guard !activeIndices.isEmpty else { break }

            iterations += 1

            let batchResults = try await withThrowingTaskGroup(of: BatchResult.self) { group in
                for idx in activeIndices {
                    let term = session.streams[idx].term
                    let start = session.streams[idx].nextRemoteStart
                    let filters = request.filters
                    var termOptions = request.options
                    termOptions.searchMode = .phrase
                    termOptions.wordDistance = 0
                    let apiURL = try self.configuration.apiURL(path: "/api/search-wrapper")

                    group.addTask {
                        let response = try await self.client.post(
                            SefariaSearchResponseDTO.self,
                            url: apiURL,
                            body: SefariaSearchBody(
                                query: term,
                                start: start,
                                size: batchSize,
                                filters: filters,
                                options: termOptions
                            )
                        )
                        return (termIndex: idx, rawHits: response.hits.hits, total: response.hits.total.value)
                    }
                }
                var results: [BatchResult] = []
                for try await item in group {
                    results.append(item)
                }
                return results
            }

            for result in batchResults {
                let idx = result.termIndex
                let rawHits = result.rawHits
                let total = result.total
                let stream = session.streams[idx]
                stream.total = total
                stream.nextRemoteStart += rawHits.count
                if rawHits.isEmpty || stream.nextRemoteStart >= total {
                    stream.hasMoreRemote = false
                }
                let hits = mapSearchHits(rawHits)
                for hit in hits {
                    let locatorKey = hit.id
                    if let existing = session.uniqueHitsMap[locatorKey] {
                        if (hit.score ?? 0) > (existing.score ?? 0) {
                            session.uniqueHitsMap[locatorKey] = hit
                        }
                    } else {
                        session.uniqueHitsMap[locatorKey] = hit
                    }
                }
            }

            let hasReachedTarget = session.uniqueHitsMap.count >= targetCount
            let hasAtLeastOneForOffset = session.uniqueHitsMap.count > request.offset
            let allStreamsExhausted = !session.streams.contains(where: { $0.hasMoreRemote })

            if allStreamsExhausted || hasReachedTarget {
                break
            }
            if iterations >= maxBatchesPerCall && hasAtLeastOneForOffset {
                break
            }
        }

        let sortedHits = session.uniqueHitsMap.values.sorted { a, b in
            let sa = a.score ?? 0
            let sb = b.score ?? 0
            if sa != sb {
                return sa > sb
            }
            return a.locator.persistenceKey < b.locator.persistenceKey
        }

        let slice = Array(sortedHits.dropFirst(min(request.offset, sortedHits.count)).prefix(request.limit))
        let anyStreamHasMore = session.streams.contains { $0.hasMoreRemote }
        let hasMoreHits = (sortedHits.count > request.offset + slice.count) || anyStreamHasMore
        let nextOffset = (hasMoreHits && !slice.isEmpty) ? request.offset + slice.count : nil

        let maxTermTotal = session.streams.map(\.total).max() ?? sortedHits.count
        let total = anyStreamHasMore
            ? max(sortedHits.count + (hasMoreHits ? 1 : 0), maxTermTotal)
            : sortedHits.count

        return LibrarySearchPage(hits: slice, total: total, nextOffset: nextOffset)
    }

    private func searchContains(terms: [String], request: LibrarySearchRequest) async throws -> LibrarySearchPage {
        hydrateCatalogInBackgroundIfNeeded()
        try Task.checkCancellation()

        let key = BooleanSearchSessionKey(request: request)
        let session: BooleanSearchSession
        if let existing = activeSession, activeSessionKey == key {
            session = existing
        } else {
            session = BooleanSearchSession(key: key, terms: terms)
            activeSession = session
            activeSessionKey = key
        }

        let targetCount = request.offset + request.limit
        let batchSize = max(request.limit, 25)
        let maxBatchesPerCall = 15

        typealias BatchResult = (termIndex: Int, rawHits: [SefariaSearchResponseDTO.Hit], total: Int)
        var candidateKeys: [String] = []
        var iterations = 0

        while session.streams.contains(where: { $0.hasMoreRemote }) {
            try Task.checkCancellation()
            let activeIndices = session.streams.indices.filter { session.streams[$0].hasMoreRemote }
            guard !activeIndices.isEmpty else { break }

            iterations += 1

            let batchResults = try await withThrowingTaskGroup(of: BatchResult.self) { group in
                for idx in activeIndices {
                    let term = session.streams[idx].term
                    let start = session.streams[idx].nextRemoteStart
                    let filters = request.filters
                    var termOptions = request.options
                    termOptions.searchMode = .phrase
                    termOptions.wordDistance = 0
                    let apiURL = try self.configuration.apiURL(path: "/api/search-wrapper")

                    group.addTask {
                        let response = try await self.client.post(
                            SefariaSearchResponseDTO.self,
                            url: apiURL,
                            body: SefariaSearchBody(
                                query: term,
                                start: start,
                                size: batchSize,
                                filters: filters,
                                options: termOptions
                            )
                        )
                        return (termIndex: idx, rawHits: response.hits.hits, total: response.hits.total.value)
                    }
                }
                var results: [BatchResult] = []
                for try await item in group {
                    results.append(item)
                }
                return results
            }

            for result in batchResults {
                let idx = result.termIndex
                let rawHits = result.rawHits
                let total = result.total
                let stream = session.streams[idx]
                stream.total = total
                stream.nextRemoteStart += rawHits.count
                if rawHits.isEmpty || stream.nextRemoteStart >= total {
                    stream.hasMoreRemote = false
                }
                let hits = mapSearchHits(rawHits)
                for hit in hits {
                    let locatorKey = hit.id
                    if stream.hitsByLocator[locatorKey] == nil {
                        stream.orderedLocators.append(locatorKey)
                        stream.hitsByLocator[locatorKey] = hit
                    }
                }
            }

            guard !session.streams.isEmpty else { break }
            candidateKeys = session.streams[0].orderedLocators.filter { key in
                session.streams.dropFirst().allSatisfy { $0.hitsByLocator[key] != nil }
            }

            let hasReachedTarget = candidateKeys.count >= targetCount
            let hasAtLeastOneForOffset = candidateKeys.count > request.offset
            let allStreamsExhausted = !session.streams.contains(where: { $0.hasMoreRemote })

            if allStreamsExhausted || hasReachedTarget {
                break
            }
            if iterations >= maxBatchesPerCall && hasAtLeastOneForOffset {
                break
            }
        }

        if !session.streams.isEmpty {
            candidateKeys = session.streams[0].orderedLocators.filter { key in
                session.streams.dropFirst().allSatisfy { $0.hitsByLocator[key] != nil }
            }
        }

        var commonHits: [LibrarySearchHit] = []
        for key in candidateKeys {
            guard let first = session.streams[0].hitsByLocator[key] else { continue }
            var totalScore: Double = 0
            var scoreCount = 0
            for stream in session.streams {
                if let h = stream.hitsByLocator[key], let s = h.score {
                    totalScore += s
                    scoreCount += 1
                }
            }
            let combinedScore = scoreCount > 0 ? totalScore / Double(scoreCount) : nil
            commonHits.append(LibrarySearchHit(
                locator: first.locator,
                displayRef: first.displayRef,
                heRef: first.heRef,
                snippet: first.snippet,
                score: combinedScore
            ))
        }

        commonHits.sort { a, b in
            let sa = a.score ?? 0
            let sb = b.score ?? 0
            if sa != sb {
                return sa > sb
            }
            return a.locator.persistenceKey < b.locator.persistenceKey
        }

        let slice = Array(commonHits.dropFirst(min(request.offset, commonHits.count)).prefix(request.limit))
        let anyStreamHasMore = session.streams.contains { $0.hasMoreRemote }
        let hasMoreCandidates = (commonHits.count > request.offset + slice.count) || anyStreamHasMore
        let nextOffset = (hasMoreCandidates && !slice.isEmpty) ? request.offset + slice.count : nil

        let total = anyStreamHasMore
            ? max(commonHits.count + (hasMoreCandidates ? 1 : 0), request.offset + slice.count + (hasMoreCandidates ? 1 : 0))
            : commonHits.count

        return LibrarySearchPage(hits: slice, total: total, nextOffset: nextOffset)
    }


    private func mapSearchHits(_ rawHits: [SefariaSearchResponseDTO.Hit]) -> [LibrarySearchHit] {
        rawHits.compactMap { hit -> LibrarySearchHit? in
            guard let work = SefariaRef.workKey(from: hit.source.ref, knownTitles: Array(knownTitles))
                ?? hit.source.indexTitle
                ?? hit.source.path?.split(separator: "/").last.map(String.init)
                ?? hit.source.title else { return nil }
            let snippet = hit.highlight?.values.first?.first
                ?? hit.source.content
                ?? hit.source.naiveLemmatizer
                ?? hit.source.exact
                ?? ""
            return LibrarySearchHit(
                locator: TextLocator(backend: .sefaria, workKey: work, position: .canonicalRef(hit.source.ref)),
                displayRef: hit.source.ref,
                heRef: hit.source.heRef,
                snippet: snippet,
                score: hit.score,
                versionTitle: hit.source.version,
                language: hit.source.lang
            )
        }
    }

    private func hydrateCatalogInBackgroundIfNeeded() {
        guard knownTitles.isEmpty else { return }
        // Search hits already carry an index title/path. Catalog hydration improves
        // later reference parsing, but must not delay an otherwise successful search.
        Task { _ = try? await self.catalog(forceRefresh: false) }
    }

    func versions(for workKey: String) async throws -> [TextVersionMetadata] {
        let url = try configuration.apiURL(pathPrefix: "/api/texts/versions/", pathComponent: workKey)
        return try await client.get([SefariaVersion].self, url: url).map(\.metadata)
    }

    func related(to locator: TextLocator) async throws -> [TextLocator] {
        guard case .canonicalRef(let ref) = locator.position else { throw LibraryBackendError.invalidLocator }
        let url = try configuration.apiURL(pathPrefix: "/api/related/", pathComponent: ref)
        let response = try await client.get(SefariaRelatedDTO.self, url: url)
        return response.links.compactMap { link in
            guard let ref = link.ref ?? link.sourceRef,
                  let work = SefariaRef.workKey(from: ref, knownTitles: Array(knownTitles)) else { return nil }
            return TextLocator(backend: .sefaria, workKey: work, position: .canonicalRef(ref))
        }
    }

    func links(for locator: TextLocator) async throws -> [LibraryRelatedSource] {
        guard locator.backend == .sefaria, case .canonicalRef(let ref) = locator.position else {
            throw LibraryBackendError.invalidLocator
        }
        let requestedRef = SefariaRef.canonicalInput(ref)
        let sectionRef = relationshipSectionRef(for: requestedRef, workKey: locator.workKey)
        let rows = try await relationshipRows(for: sectionRef)
        var results: [LibraryRelatedSource] = []
        var seen = Set<String>()
        let matchingRows = rows
            .filter { relationship($0, includes: requestedRef, sectionRef: sectionRef) }
            .sorted { relationshipSpecificity($0) < relationshipSpecificity($1) }
        for row in matchingRows {
            if let source = SefariaRelationshipMapper.source(row, knownTitles: knownTitles),
               seen.insert(source.id).inserted {
                results.append(source)
            }
        }
        return results
    }


    func topics(for locator: TextLocator) async throws -> [LibraryRelatedTopic] {
        guard locator.backend == .sefaria, case .canonicalRef(let ref) = locator.position else {
            throw LibraryBackendError.invalidLocator
        }
        let url = try configuration.apiURL(
            pathPrefix: "/api/ref-topic-links/",
            pathComponent: ref,
            queryItems: [URLQueryItem(name: "interface_lang", value: "english")]
        )
        let rows = try await client.get([SefariaRelationshipTopicDTO].self, url: url)
        return SefariaRelationshipMapper.topics(rows)
    }

    func invalidateSearchSession() {
        activeSession = nil
        activeSessionKey = nil
    }

    func clearTransientState() {
        searchServiceGeneration &+= 1
        searchServiceProbe?.cancel()
        searchServiceProbe = nil
        searchServiceObservation = nil
        knownTitles.removeAll()
        sectionRefByReference.removeAll()
        relatedRowsBySection.removeAll()
        relatedTasksBySection.values.forEach { $0.cancel() }
        relatedTasksBySection.removeAll()
        catalogTask?.cancel()
        catalogTask = nil
        invalidateSearchSession()
    }

    private func rememberSectionReferences(_ dto: SefariaTextsV3DTO) {
        let canonicalSection = SefariaRef.canonicalInput(dto.sectionRef)
        sectionRefByReference[SefariaRef.canonicalInput(dto.ref)] = canonicalSection
        sectionRefByReference[canonicalSection] = canonicalSection
        for segment in map(dto, origin: .diskCache).asLibrarySection().segments {
            if case .canonicalRef(let reference) = segment.locator.position {
                sectionRefByReference[SefariaRef.canonicalInput(reference)] = canonicalSection
            }
        }
    }

    private func relationshipSectionRef(for requestedRef: String, workKey: String) -> String {
        if let known = sectionRefByReference[requestedRef] { return known }
        let suffix = requestedRef.hasPrefix(workKey + " ")
            ? String(requestedRef.dropFirst(workKey.count + 1))
            : ""
        let addressDepth = suffix.split(separator: ":").count
        let workUsuallyAddsCommentDepth = workKey.localizedCaseInsensitiveContains(" on ")
        if addressDepth > (workUsuallyAddsCommentDepth ? 2 : 1),
           let parent = SefariaRef.sectionAncestors(of: requestedRef).dropFirst().first {
            return parent
        }
        return requestedRef
    }

    private func relationshipRows(for sectionRef: String) async throws -> [SefariaRelationshipLinkDTO] {
        if let cached = relatedRowsBySection[sectionRef] { return cached }
        if let task = relatedTasksBySection[sectionRef] { return try await task.value }
        let task = Task { try await loadRelationshipRows(for: sectionRef) }
        relatedTasksBySection[sectionRef] = task
        do {
            let rows = try await task.value
            relatedRowsBySection[sectionRef] = rows
            relatedTasksBySection.removeValue(forKey: sectionRef)
            return rows
        } catch {
            relatedTasksBySection.removeValue(forKey: sectionRef)
            throw error
        }
    }

    private func loadRelationshipRows(
        for sectionRef: String
    ) async throws -> [SefariaRelationshipLinkDTO] {
        let cacheName = "related-\(Data(sectionRef.utf8).base64EncodedString().replacingOccurrences(of: "/", with: "_"))"
        if let disk: SefariaRelatedResponseDTO = await cache.decode(cacheName) {
            return disk.links
        }
        let url = try configuration.apiURL(pathPrefix: "/api/related/", pathComponent: sectionRef)
        let response = try await client.get(SefariaRelatedResponseDTO.self, url: url, timeoutInterval: 15, maxAttempts: 2)
        try? await cache.encode(response, as: cacheName)
        return response.links
    }

    private func relationship(
        _ row: SefariaRelationshipLinkDTO,
        includes requestedRef: String,
        sectionRef: String
    ) -> Bool {
        guard requestedRef != sectionRef else { return true }
        let anchors = row.anchorRefExpanded.isEmpty
            ? [row.anchorRef].compactMap { $0 }
            : row.anchorRefExpanded
        return anchors.contains { SefariaRef.anchorReference($0, contains: requestedRef) }
    }

    /// Sefaria can return book-wide essays before links anchored to the exact
    /// segment. Exact/small anchors are the useful default for Inspector cards
    /// and also preserve deterministic linked-source navigation.
    private func relationshipSpecificity(_ row: SefariaRelationshipLinkDTO) -> Int {
        row.anchorRefExpanded.isEmpty ? 1 : row.anchorRefExpanded.count
    }

    private func map(_ dto: SefariaTextsV3DTO, origin: LibraryTextSection.Origin) -> SefariaSection {
        SefariaSection(ref: dto.ref, heRef: dto.heRef, sectionRef: dto.sectionRef,
            indexTitle: dto.indexTitle, next: dto.next, prev: dto.prev,
            versions: dto.versions, linksBySegment: [], origin: origin)
    }

    private func rememberTitles(_ entries: [SefariaTOCEntryDTO]) {
        for entry in entries {
            if let title = entry.title { knownTitles.insert(title) }
            rememberTitles(entry.contents)
        }
    }

    private static func mapCatalog(_ entry: SefariaTOCEntryDTO, parentPath: [String]) -> LibraryCatalogNode {
        if let title = entry.title {
            let locator = TextLocator(backend: .sefaria, workKey: title, position: .canonicalRef(title))
            var work = LibraryWork(locator: locator, title: title, heTitle: entry.heTitle,
                categories: parentPath, description: nil)
            work.searchPath = SefariaCatalogIdentity.searchPath(parentPath: parentPath, title: title)
            return LibraryCatalogNode(id: locator.persistenceKey, kind: .work, title: title,
                heTitle: entry.heTitle, work: work, children: [])
        }
        let title = entry.category ?? ""
        let path = parentPath + [title]
        return LibraryCatalogNode(id: SefariaCatalogIdentity.categoryID(path: path), kind: .category,
            title: title, heTitle: entry.heCategory, work: nil,
            children: entry.contents.map { mapCatalog($0, parentPath: path) })
    }

}
