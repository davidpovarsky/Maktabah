import Foundation
@main enum SefariaNavigationLanguageMain {
    static func main() throws {
        let checks = try sefariaNavigationLanguageChecks()
        let rows: [[String: Any]] = checks.map {
            ["name": $0.name, "passed": $0.passed, "actual": $0.actual, "expected": $0.expected]
        }
        let data = try JSONSerialization.data(withJSONObject: rows, options: [.sortedKeys])
        FileHandle.standardOutput.write(data)
        FileHandle.standardOutput.write(Data("\n".utf8))
        exit(checks.allSatisfy(\.passed) ? 0 : 1)
    }
}
