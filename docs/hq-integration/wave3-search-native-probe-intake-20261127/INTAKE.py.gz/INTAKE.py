import gzip, hashlib, json, pathlib, re, shutil, subprocess, time

ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='108fa6ca8ec7fd5b96439130399c1ac87ce8f123'
BRANCH='codex/otzaria-wave3-integration-20261127'
DONOR='ff4d8809e3314aedf74ce09fe74a62c4fc1ca636'
DONOR_REPO='/home/ubuntu/.codex/worktrees/Maktabah-wave3-search-continuation-native-20261127'
DOCS='docs/hq-ui-inventory/wave3-search-continuation-native-20261127'
PROOF=ROOT/'docs/hq-integration/wave3-search-native-probe-intake-20261127'
RUN=pathlib.Path(__file__).parent
HELPER='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
NEW_TEST='Maktabah-iOSUITests/NativeSearchContinuationAcceptanceTests.swift'
PHONE_TEST='Maktabah-iOSUITests/NativeHiddenActivePhoneReaderTabAcceptanceTests.swift'
COMPOSITION='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift'
events=[]

def sha(raw): return hashlib.sha256(raw).hexdigest()
def dump(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def run(argv):
    begin=time.time();p=subprocess.run(argv,cwd=ROOT,capture_output=True)
    events.append({'argv':argv,'exit':p.returncode,'seconds':time.time()-begin,
                   'stdout':{'bytes':len(p.stdout),'sha256':sha(p.stdout)},
                   'stderr':{'bytes':len(p.stderr),'sha256':sha(p.stderr),'text':p.stderr.decode(errors='replace')[:6000]}})
    dump(RUN/'EVENTS.json',events)
    if p.returncode: raise RuntimeError(str(argv)+'\n'+p.stderr.decode(errors='replace')[:6000])
    return p.stdout
def git(*args): return run(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args])
def show(commit,path): return git('show',commit+':'+path)
def check(raw,row):
    assert len(raw)==row['bytes'],(len(raw),row['bytes'])
    assert sha(raw)==row['sha256'],(sha(raw),row['sha256'])
def names(commit,path): return git('ls-tree','-r','--name-only',commit,'--',path).decode().splitlines()

try:
    assert git('rev-parse','HEAD').decode().strip()==BASE
    assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
    assert not git('status','--porcelain')
    assert shutil.disk_usage(ROOT).free>=1342177280
    remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
    assert git(*remote).decode().split()[0]==BASE
    git('fetch','--no-tags','--no-write-fetch-head',DONOR_REPO,DONOR)
    files=names(DONOR,DOCS)
    changed=set(git('diff-tree','--no-commit-id','--name-only','-r',DONOR).decode().splitlines())
    assert changed=={HELPER,NEW_TEST}|set(files)
    index_raw=show(DONOR,DOCS+'/ARTIFACTS.json')
    assert sha(index_raw)=='c0420b23144cf3c9b0aa0eb8eee93171d607a2962a28de097be1fae7effce817'
    index=json.loads(index_raw)
    assert len(index)==83 and set(files)=={DOCS+'/ARTIFACTS.json'}|{DOCS+'/'+n for n in index}
    blobs={'ARTIFACTS.json':index_raw};verified=[]
    for name,row in index.items():
        assert pathlib.PurePosixPath(name).as_posix()==name and '..' not in pathlib.PurePosixPath(name).parts and not name.startswith('/')
        raw=show(DONOR,DOCS+'/'+name);check(raw,row);blobs[name]=raw
        if 'decompressed' in row: check(gzip.decompress(raw),row['decompressed'])
        verified.append({'path':DOCS+'/'+name,**row})
    packet=json.loads(blobs['SOURCE_PACKET.json']);receipt=json.loads(blobs['PROBE_PATCH_RECEIPT.json'])
    original=show('ec5385e863a478e368c7de47264474a440fd0734',HELPER)
    check(original,receipt['nativeOriginalPrefix'])
    suffix=blobs['NATIVE_HELPER_ADDITION.swift'];check(suffix,{'bytes':35124,'sha256':'a3480902e1d970a02e28b98ad79989d5fc9f40f60e2836ce97c4dfca8d19bdc7'})
    donor_helper=show(DONOR,HELPER);check(donor_helper,receipt['nativeCandidate']);assert donor_helper==original+suffix
    new_test=show(DONOR,NEW_TEST);check(new_test,packet['sources'][NEW_TEST])
    current=(ROOT/HELPER).read_bytes()
    check(current,{'bytes':272184,'sha256':'f6772365dab46378628d2086f9293004e02b42deac0c30d5e6f12e2713d41e59'})
    prefix=current[:259040];phone_suffix=current[259040:]
    assert sha(prefix)=='6fb46c9fc02d8abdd29a6926490f231a4cb891948ecd6d5a44d369b3832893f8'
    assert sha(phone_suffix)=='25e48b7aec434f0e279ba03dcccaa3171310209d5da03ab0706bca1e6a66fc9a'
    current_functions=set(re.findall(rb'\bfunc\s+([A-Za-z_][A-Za-z_0-9]*)',current))
    new_functions=set(re.findall(rb'\bfunc\s+([A-Za-z_][A-Za-z_0-9]*)',suffix))
    assert not current_functions & new_functions, current_functions & new_functions
    assert len(re.findall(rb'\bfunc\s+test',new_test))==8
    before=(ROOT/COMPOSITION).read_bytes();check(before,receipt['compositionBase'])
    candidate=gzip.decompress(blobs['source-snapshots/composition-candidate.swift.gz']);check(candidate,receipt['compositionCandidate'])
    assert gzip.decompress(blobs['source-snapshots/composition-base.swift.gz'])==before
    patch=gzip.decompress(blobs['SEARCH_CONTINUATION_DEBUG.patch.gz']);check(patch,receipt['patch'])
    (RUN/'composition.patch').write_bytes(patch)
    git('apply','--check',str(RUN/'composition.patch'))
    actual_controls=pathlib.Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-profile-group-controls-20261127/search-continuation-reporting-attempt-1/RESULT.json')
    assert actual_controls.read_bytes()==blobs['controls/actual-attempt-1/RESULT.json']
    actual_syntax=pathlib.Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-profile-group-controls-20261127/search-continuation-final-native-syntax-2/RESULT.json')
    assert actual_syntax.read_bytes()==blobs['controls/final-native-syntax-2/RESULT.json']
    for root in ['Vendor','Maktabah.xcodeproj']:
        assert git('rev-parse','HEAD:'+root)==git('rev-parse',BASE+':'+root)
    for name,raw in blobs.items():
        dest=ROOT/DOCS/name;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f: f.write(raw)
    with (ROOT/NEW_TEST).open('xb') as f: f.write(new_test)
    (ROOT/HELPER).write_bytes(current+suffix)
    git('apply',str(RUN/'composition.patch'))
    assert (ROOT/COMPOSITION).read_bytes()==candidate
    git('apply','--reverse','--check',str(RUN/'composition.patch'))
    # A separate temporary preimage reconstruction cannot disturb the live source.
    inverse_root=RUN/'inverse';(inverse_root/pathlib.Path(COMPOSITION).parent).mkdir(parents=True)
    (inverse_root/COMPOSITION).write_bytes(candidate)
    p=subprocess.run(['git','apply','--reverse',str(RUN/'composition.patch')],cwd=inverse_root,capture_output=True)
    assert p.returncode==0,p.stderr.decode()
    assert (inverse_root/COMPOSITION).read_bytes()==before
    PROOF.mkdir(parents=True,exist_ok=False)
    parse_paths=[COMPOSITION,HELPER,NEW_TEST,PHONE_TEST]
    parse_inputs=[{'path':name,'bytes':len((ROOT/name).read_bytes()),'sha256':sha((ROOT/name).read_bytes())} for name in parse_paths]
    argv=['/usr/local/bin/swiftc','-frontend','-parse','-target','arm64-apple-ios27.0-simulator','-D','DEBUG',*[str(ROOT/name) for name in parse_paths]]
    begin=time.time();p=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=30)
    (PROOF/'combined-parse.stdout').write_bytes(p.stdout);(PROOF/'combined-parse.stderr').write_bytes(p.stderr)
    parse={'argv':argv,'exit':p.returncode,'seconds':time.time()-begin,'inputs':parse_inputs,
           'stdout':{'bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'bytes':len(p.stderr),'sha256':sha(p.stderr)},
           'scope':'Actual combined four-file frontend syntax only on Linux Swift; no Apple SDK imports/typecheck/link/native execution'}
    dump(PROOF/'COMBINED_SYNTAX.json',parse)
    assert p.returncode==0,p.stderr.decode()
    for row in parse_inputs:check((ROOT/row['path']).read_bytes(),row)
    assert set(git('diff','--name-only').decode().splitlines())=={COMPOSITION,HELPER}
    dump(PROOF/'VERIFIED_FILES.json',verified)
    (PROOF/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
    (PROOF/'EXPLICIT_PRODUCT_AND_TEST_DELTA.patch.gz').write_bytes(gzip.compress(git('diff','--full-index','--',COMPOSITION,HELPER),mtime=0))
    result={'schema':'otzaria.wave3.search-native-probe-intake.v1','base':BASE,'donor':DONOR,
            'adoption':'Explicit reviewed merge; current helper prefix plus exact donor suffix; exact reversible DEBUG Composition patch; new test and complete84-file evidence packet',
            'artifactIndexSHA256':sha(index_raw),'verifiedArtifactRows':len(verified),'verifiedDocsFiles':len(blobs),
            'helper':{'preservedPrefixBytes':len(current),'preservedPrefixSHA256':sha(current),'newSuffixBytes':len(suffix),'newSuffixSHA256':sha(suffix),
                      'resultBytes':len(current+suffix),'resultSHA256':sha(current+suffix),'noNewHelperNameCollisions':True},
            'composition':{'before':receipt['compositionBase'],'after':receipt['compositionCandidate'],'patch':receipt['patch'],'exactInverse':True},
            'actualSourceControlReceiptSHA256':sha(actual_controls.read_bytes()),'sourceControls':'13cases/112checks PASS; first draft negative exit1 preserved; explicit storage/serialization boundary substitutes',
            'actualDonorFinalSyntaxSHA256':sha(actual_syntax.read_bytes()),'combinedSyntax':parse,
            'systemNative':'NOT_RUN','appSDK':'NOT_RUN','production':'NOT_RUN','physical':'NOT_RUN',
            'voiceOverScope':'New selectors test actual speech title/snippet reachability only; unique expanded-row/full-context focus still OPEN',
            'publicProductionContinuation':'Still OPEN: this intake adds only finite DEBUG probe callsites; no claim of a public system hit/page entry',
            'preserved':'All current272184 helper bytes, four History caller fixes, Nav suffix/selectors, Core, original acceptance selectors, PBX, catalog, Vendor and authority/deadline unchanged'}
    dump(PROOF/'RESULT.json',result)
    (PROOF/'README.md').write_text('# Original Search native probe intake\n\n'
        'The donor packet ff4d8809 was reviewed and incorporated explicitly. The live native helper retains the full root History-corrected prefix and phone suffix, then adds only the exact Search suffix. '
        'The Composition delta is the original reversible DEBUG-only finite probe and lossless reporting helper; no production action schema or Core authority changed. '
        'All 83 artifact joins, compressed original bytes, actual original control receipt and final donor syntax receipt were independently verified.\n\n'
        'One focused parser invocation checked the actual four combined source files for composition syntax risk. This is Linux frontend syntax, not Apple SDK typechecking or native acceptance. '
        'The original failed report, failed transfer/readback/publication attempts and final source controls are retained. '
        'All eight new selectors remain NOT_RUN; original Native116/Release114+2 and production-v40 obligations remain open. '
        'Actual VoiceOver speech reachability is the intended limited oracle; unique full-context focus and a production/public hit/page entry are still open.\n')
    git('add','--',COMPOSITION,HELPER,NEW_TEST)
    git('add','--sparse','--',DOCS,str(PROOF.relative_to(ROOT)))
    git('diff','--cached','--check')
    git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Integrate original Search continuation native probes and combined selectors','-m','Source packet: '+DONOR+'; explicit shared-file composition preserving History and hidden-phone changes.')
    head=git('rev-parse','HEAD').decode().strip()
    assert not git('status','--porcelain')
    assert git('diff','--name-only',BASE,'HEAD','--','Source').decode().splitlines()==[COMPOSITION]
    assert not git('diff','--name-only',BASE,'HEAD','--','Vendor','Maktabah.xcodeproj')
    allowed={COMPOSITION,HELPER,NEW_TEST}|set(files)|set(names('HEAD',str(PROOF.relative_to(ROOT))))
    assert set(git('diff','--name-only',BASE,'HEAD').decode().splitlines())==allowed
    assert git(*remote).decode().split()[0]==BASE
    git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
    assert git(*remote).decode().split()[0]==head
    terminal={'ok':True,'head':head,'source':git('rev-parse','HEAD:Source').decode().strip(),
              'helperBytes':len(current+suffix),'helperSHA256':sha(current+suffix),'resultSHA256':sha((PROOF/'RESULT.json').read_bytes()),
              'combinedSyntaxExit':p.returncode,'native':'NOT_RUN','free':shutil.disk_usage(ROOT).free,'proof':str(PROOF)}
    dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
    failure={'ok':False,'type':type(error).__name__,'error':str(error),'events':str(RUN/'EVENTS.json')}
    dump(RUN/'FAILURE.json',failure);print(json.dumps(failure));raise
