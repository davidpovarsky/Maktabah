import base64,gzip,hashlib,io,json,pathlib,re,runpy,shutil,subprocess,tarfile,time,traceback,zipfile

ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='e33fc140c84d20f8e595e9e4f032b9f44d426be5'
BRANCH='codex/otzaria-wave3-integration-20261127'
RUN=pathlib.Path(__file__).parent
PROOF='docs/hq-integration/wave3-original-entry-wiring-20261127'
PACKET=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-original-entry-wiring-final-candidate-20261127.tar.gz')
H='1dd19d4bffe143f85c14568f155d51e4d88ae868';HD='docs/hq-ui-inventory/wave3-history-search-publication-20261127'
P='a27694faab405399b9c99c3b76074d70ecc1b7c0';PD='docs/ui-routing/wave3-public-search-native-20261127'
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def git(*a):
    p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
    row={'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')}
    if len(p.stdout)<4096 and a[0]not in ['show','cat-file']:row['stdout']=p.stdout.decode(errors='replace')
    events.append(row);dump(RUN/'EVENTS.json',events)
    if p.returncode:raise RuntimeError('Git failure '+repr(a))
    return p.stdout
def show(ref,path):return git('show',ref+':'+path)
def rev(ref):return git('rev-parse',ref).decode().strip()
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row['path']

try:
    assert rev('HEAD')==BASE and git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
    assert not git('status','--porcelain') and shutil.disk_usage(ROOT).free>=1342177280
    remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
    assert git(*remote).decode().split()[0]==BASE
    archive=PACKET.read_bytes();assert len(archive)==315918 and sha(archive)=='c56330ae5ce5f2c330dc4e58f765b1645daf8d024853e5b48b9311d1fa7bcf07'
    inputs=RUN/'inputs';inputs.mkdir(exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tar:
        members=tar.getmembers();assert len(members)==36 and len({m.name for m in members})==36
        for m in members:
            assert m.isfile() and not m.name.startswith('/') and '..'not in pathlib.PurePosixPath(m.name).parts
            p=inputs/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read())
    manifest=json.loads((inputs/'MANIFEST.json').read_text());assert len(manifest['files'])==35 and manifest['base']==BASE
    assert {m.name for m in members}=={r['path']for r in manifest['files']}|{'MANIFEST.json'}
    for row in manifest['files']:pin((inputs/row['path']).read_bytes(),row)
    root_rows=json.loads((inputs/'proof/ROOT_PREIMAGES.json').read_text())['files'];assert len(root_rows)==15
    candidates={r['path']:(inputs/'candidate'/r['path']).read_bytes()for r in root_rows}
    before={}
    for row in root_rows:
        path=row['path'];pin(candidates[path],row)
        if row['beforeSHA256']is None:assert not git('ls-tree',BASE,'--',path)
        else:
            b=show(BASE,path);before[path]=b
            assert len(b)==row['beforeBytes']and sha(b)==row['beforeSHA256']and rev(BASE+':'+path)==row['beforeBlob']
    assert sum(r['beforeSHA256']is None for r in root_rows)==4

    deliveries=[];doc_paths=[]
    for ref,parent,d,m,expected,count in [
        (H,'b0fd2d88c7f51db3b2004dccd5ecef10a58d9551',HD,'MANIFEST.json','8894a1eee604cfd2e42e154fd00c6ce2f6e14198d91d85ce85be01675c7e0c60',39),
        (P,'9b69c8c06826ad64c5802d8587bd21ff91fbac4e',PD,'ARTIFACTS.json','a3d72bcf92bbb1c2f7c4be3f8781802bb888fbad41febd39ae523762ea4de30e',24)]:
        assert rev(ref+'^')==parent
        paths=git('diff-tree','--no-commit-id','--name-only','-r',ref).decode().splitlines();assert len(paths)==count
        raw=show(ref,d+'/'+m);assert sha(raw)==expected;data=json.loads(raw)
        expected_paths={d+'/'+r['path']for r in data['files']}|{d+'/'+m}
        if ref==P:
            test=data['testFile'];pin(show(ref,test['path']),test);assert show(ref,test['path'])==candidates[test['path']]
            expected_paths.add(test['path'])
        assert set(paths)==expected_paths
        for row in data['files']:pin(show(ref,d+'/'+row['path']),row)
        for path in ['Source','Vendor','Maktabah.xcodeproj','Scripts/CI','.github','docs/architecture']:
            assert rev(ref+':'+path)==rev(parent+':'+path)
        if ref==H:assert rev(ref+':Maktabah-iOSUITests')==rev(parent+':Maktabah-iOSUITests')
        deliveries.append({'donor':ref,'parent':parent,'paths':count,'manifestSHA256':expected,'manifestRows':len(data['files'])})
        doc_paths+=paths

    history_raw=show(H,HD+'/evidence/RESULT.json')
    assert sha(history_raw)=='4faaf2f3c647a2cac66d46c565b0767032afee7898290dcc92501ed46aceed3f'
    hr=json.loads(history_raw);assert [(r['variant'],r['passed'],r['failed'])for r in hr['results']]==[('baseline',6,15),('intermediate',20,1),('candidate',21,0)]
    assert all(r['exit']==0 for r in hr['steps']if r['name'].endswith('-compile'))
    history_origin=pathlib.Path('/home/ubuntu/otzaria-wave3-history-search-publication-controls-20261127')
    assert (history_origin/'RESULT.json').read_bytes()==history_raw
    with zipfile.ZipFile(io.BytesIO(show(H,HD+'/evidence/RAW_RESULTS.zip')))as z:
        assert len(z.namelist())==len(set(z.namelist()))==15
        for name in z.namelist():
            b=z.read(name);assert b==show(H,HD+'/evidence/'+name)==(history_origin/name).read_bytes()
    session_path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
    assert candidates[session_path]==show(H,HD+'/inputs/candidate/OriginalSession.swift')

    packed=show(P,PD+'/evidence/RAW_CONTROLS.json.gz');index=json.loads(show(P,PD+'/evidence/RAW_CONTROLS.json.gz.manifest.json'))
    assert len(packed)==index['gzipBytes']and sha(packed)==index['gzipSHA256']
    raw=gzip.decompress(packed);assert len(raw)==index['rawBytes']and sha(raw)==index['rawSHA256']
    capsule=json.loads(raw);assert len(capsule['files'])==len(index['members'])==36
    raw_index={r['path']:r for r in index['members']};assert len(raw_index)==36
    native_origin=pathlib.Path('/home/ubuntu/.codex/artifacts/otzaria-wave3-profile-group-controls-20261127/public-search-native-controls-attempt-1')
    for row in capsule['files']:
        b=base64.b64decode(row['base64'],validate=True);pin(b,row);pin(b,raw_index[row['path']]);assert (native_origin/row['path']).read_bytes()==b
    pr=json.loads(show(P,PD+'/evidence/RESULT.json'))
    assert sha(show(P,PD+'/evidence/RESULT.json'))=='f5ae47a07ecc836149e888a76c8c19d916124d920916743a07d254b6110525b6'
    assert len([r for r in pr['cases']if r['variant']=='candidate'and r['pass']])==6
    assert len([r for r in pr['cases']if r['variant']=='counterfactual'and not r['pass']])==2
    assert len([r for r in pr['steps']if r['name'].startswith('syntax-')and r['exit']==0])==3
    composition_path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift'
    assert sha(candidates[composition_path])==json.loads(show(P,PD+'/proposal/COMPOSITION_JOIN.json'))['candidate']['sha256']
    edits=json.loads(gzip.decompress(show(P,PD+'/proposal/COMPOSITION_EDITS.json.gz')))
    assert edits==json.loads((inputs/'proof/PUBLIC_COMPOSITION_EDITS.json').read_text())and len(edits)==7
    inverse=candidates[composition_path].decode()
    for edit in reversed(edits):
        assert inverse.count(edit['after'])==1;inverse=inverse.replace(edit['after'],edit['before'])
    assert sha(inverse.encode())=='eeb1b4b4758df16bacbcc5cf12d69b12a0bf08cff2ac8017aada2d8916435926'
    helper_path='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
    suffix=show(P,PD+'/NATIVE_HELPER_ADDITION.swift');assert candidates[helper_path].endswith(suffix)
    assert sha(candidates[helper_path][:-len(suffix)])=='e5e5d6fa742aa88ab49f8159f9d413cd8b1de4cd244b8cb60b16c2a4e3e20acd'

    # Complete graph checks supplement the exact inverse checks from both registration stages.
    parser_path=inputs/'proof/verify_source_registration.py'
    assert sha(parser_path.read_bytes())=='eff5cf3c0935562f9e9b1bbcd296f192c4daf2922cc9185d8fa5ad0ab3246a18'
    parser=runpy.run_path(str(parser_path));project='Maktabah.xcodeproj/project.pbxproj'
    old,old_duplicates=parser['parse'](before[project].decode());new,new_duplicates=parser['parse'](candidates[project].decode())
    assert old_duplicates==new_duplicates
    old_objects=old['objects'];objects=new['objects'];phases=parser['target_sources'](new)
    first=json.loads((inputs/'proof/WIRING_CANDIDATE.json').read_text());saved=json.loads((inputs/'proof/SAVED_REGISTRATION.json').read_text())
    registrations=[]
    for e in first['projectEntries']:registrations.append({**e,'builds':{'Maktabah-iOS':e['build']}})
    registrations+=saved['additionalAppEntries'];assert len(registrations)==6
    additions={e['ref']for e in registrations}|{v for e in registrations for v in e['builds'].values()}
    assert len(additions)==14 and set(objects)-set(old_objects)==additions
    allowed_changes={'CFEE00000000000000000001'}|{phases[n][0]for n in ['Maktabah','Maktabah-Direct','Maktabah-iOS']}
    assert {k for k in old_objects if old_objects[k]!=objects[k]}==allowed_changes
    for object_id in allowed_changes:
        field='children'if object_id=='CFEE00000000000000000001'else'files'
        assert {k:v for k,v in objects[object_id].items()if k!=field}=={k:v for k,v in old_objects[object_id].items()if k!=field}
        assert [x for x in objects[object_id][field]if x in old_objects[object_id][field]]==old_objects[object_id][field]
    for e in registrations:
        assert objects[e['ref']]['path']==e['relative']
        assert objects['CFEE00000000000000000001']['children'].count(e['ref'])==1
        for target,build in e['builds'].items():
            assert objects[build]['fileRef']==e['ref']
            assert [n for n,(_,ids)in phases.items()if build in ids]==[target]
        if e['path']not in candidates:
            b=show(BASE,e['path'])
            if 'sha256'in e:pin(b,e)
        else:b=candidates[e['path']]
        assert b
    for path in ['Source/Localizable.xcstrings','Source/ChavrusaText/UIRoutingHost/Integration/AppShortcuts.xcstrings']:
        a=json.loads(before[path]);b=json.loads(candidates[path]);assert a['sourceLanguage']==b['sourceLanguage']=='en'
        assert all(b['strings'][k]==v for k,v in a['strings'].items())
        for k in set(b['strings'])-set(a['strings']):
            value=b['strings'][k]['localizations']['he']['stringUnit']['value']
            assert re.findall(r'\$\{[^}]+\}',k)==re.findall(r'\$\{[^}]+\}',value)
    assert candidates['Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift'].count(b'AppShortcut(intent:')==10
    assert b'path = "Maktabah-iOSUITests";'in candidates[project]

    swift=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
    assert sha(swift.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
    syntax=[]
    for mode in ['debug','release']:
        for path in sorted(p for p in candidates if p.endswith('.swift')):
            name=mode+'-'+pathlib.Path(path).stem
            args=[str(swift),'-frontend','-parse','-target','arm64-apple-ios27.0-simulator']
            if mode=='debug':args+=['-D','DEBUG']
            args+=[str(inputs/'candidate'/path)]
            start=time.time();p=subprocess.run(args,capture_output=True,timeout=30)
            (RUN/(name+'.stdout')).write_bytes(p.stdout);(RUN/(name+'.stderr')).write_bytes(p.stderr)
            syntax.append({'name':name,'path':path,'mode':mode,'argv':args,'exit':p.returncode,'started':start,'finished':time.time(),'sourceSHA256':sha(candidates[path]),'stdoutSHA256':sha(p.stdout),'stderrSHA256':sha(p.stderr)})
            dump(RUN/'SYNTAX.json',syntax)
            assert p.returncode==0,name
    assert len(syntax)==24
    dump(RUN/'PREFLIGHT.json',{'ok':True,'base':BASE,'candidateFiles':15,'registrationFiles':6,'newPBXObjects':14,'syntaxOnly':syntax,'nativeRuns':0,'AppleSDK':'NOT_RUN'})

    protected=['Source/Otzaria','Source/ZayitSearch','Source/Features','Vendor','Scripts/CI','.github','docs/architecture']
    trees={p:rev(BASE+':'+p)for p in protected}
    for ref in [H,P]:
        git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',ref)
        next(r for r in deliveries if r['donor']==ref)['integrated']=rev('HEAD')
    after_donors=rev('HEAD');assert not git('status','--porcelain')
    for path,b in candidates.items():
        p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    git('diff','--check')
    expected_changed=set(candidates)-{'Maktabah-iOSUITests/NativePublicSearchContinuationAcceptanceTests.swift'}
    changed=set(git('diff','--name-only').decode().splitlines())|{r['path']for r in root_rows if r['beforeSHA256']is None and r['path'].startswith('Source/')}
    assert changed==expected_changed,(changed,expected_changed)
    git('add','--sparse','--',*sorted(candidates))
    assert set(git('diff','--cached','--name-only').decode().splitlines())==expected_changed
    git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Wire original History Search and Saved Results entry lifetimes')
    source_commit=rev('HEAD');assert not git('status','--porcelain')
    for row in root_rows:pin(show('HEAD',row['path']),row)
    for p,h in trees.items():assert rev('HEAD:'+p)==h
    proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
    (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
    first=RUN.parent/'integration-attempt-1'
    failure=json.loads((first/'FAILURE.json').read_text());assert failure['error']=="KeyError('text')"
    for name in ['RUN.py','EVENTS.json','FAILURE.json']:
        (proof/('ATTEMPT_1_'+name+'.gz')).write_bytes(gzip.compress((first/name).read_bytes(),mtime=0))
    second=RUN.parent/'integration-attempt-2'
    failure=json.loads((second/'FAILURE.json').read_text());assert failure['error']=='AssertionError()'and 'fa5bd9db9b1e651a' in failure['traceback']
    for name in ['RUN.py','EVENTS.json','FAILURE.json']:
        (proof/('ATTEMPT_2_'+name+'.gz')).write_bytes(gzip.compress((second/name).read_bytes(),mtime=0))
    (proof/'FINAL_CANDIDATE.tar.gz').write_bytes(archive)
    for name in ['ROOT_PREIMAGES.json','PUBLIC_NATIVE_WIRING.json','SAVED_REGISTRATION.json','ORIGINAL_SEARCH_TRACE_FIX.json','HISTORY_UNMOUNT_ORDER_FIX.json']:
        shutil.copyfile(inputs/'proof'/name,proof/name)
    dump(proof/'SYNTAX.json',syntax)
    for row in syntax:
        for suffix in ['stdout','stderr']:
            (proof/'syntax').mkdir(exist_ok=True);shutil.copyfile(RUN/(row['name']+'.'+suffix),proof/'syntax'/(row['name']+'.'+suffix))
    history=pathlib.Path('/home/ubuntu/.codex/diagnostics/otzaria-wave3-original-entry-wiring-20261127/history')
    assert sha((history/'RESULT.json').read_bytes())=='6d350afb7d0525dd23d037c5ded8aa143ba7c5788e1eaccdb4c47f210a6c9478'
    assert sha((history/'ACTUAL_RAW_CONTROLS.tar.gz').read_bytes())=='96337748292f4ead138fcb149970faefa0a571b3359aed5996c30fd98c2c1ab5'
    (proof/'history').mkdir()
    for name in ['SOURCE_AND_PRESERVED_DRAFT.tar.gz','LOCAL_SOURCE_INDEX.json','ACTUAL_RAW_CONTROLS.tar.gz','ACTUAL_RAW_CONTROL_INDEX.json','ORIGINAL_RUN_ALL_FILES.json','RESULT.json']:
        shutil.copyfile(history/name,proof/'history'/name)
    result={'schema':'otzaria.wave3.original-entry-wiring-intake.v1','base':BASE,'deliveries':deliveries,'sourceCommit':source_commit,
        'sourceTree':rev('HEAD:Source'),'candidateFiles':15,'sourceChangedPaths':len(expected_changed),'exactPreimages':11,'newHistoryFiles':3,'newNativeSelectorFile':1,
        'actualHistoryPublicationControls':{'originalPassed':6,'originalFailed':15,'intermediatePassed':20,'intermediateFailed':1,'finalPassed':21,'finalFailed':0},
        'publicReturnRetentionControls':{'passed':6,'counterfactualExpectedFailures':2},'nativeSelectorsAdded':8,'nativeSelectorsExecuted':0,
        'registration':{'appFiles':6,'newPBXObjects':14,'existingObjectsAndOrderPreserved':True,'shortcutCount':10},
        'completeFrontendParsesOnly':{'debug':12,'release':12,'failures':0},'protectedTrees':trees,
        'firstIntakeFailurePreserved':'Before mutation: raw capsule uses lossless base64 bytes, not a text field. Exact publisher shape was read; all36 decoded files still require full byte/hash and original receipt equality.',
        'secondIntakeFailurePreserved':'Before mutation: one-character compiler SHA transcription error (fa5 instead of actual fa3); original actual binary/known toolchain hash re-read. No compiler, source, control or gate changed.',
        'historyOtherEvidence':'Actual33 service +22 source +16 method controls retain explicit substitutes; all prior raw failures preserved. Separate21 publication controls join final Session exactly.',
        'publicDiagnosticBoundary':'Debug I/O occurs before final public service deadline qualification; actual public Intent success and real OS refusal remain separately required.',
        'remaining':'Actual Apple SDK/app/native/production/Release acceptance; URL transport finite additions; cross-root/cold restoration and other original UI gaps.',
        'AppleSDK':'NOT_RUN','Native116':'NOT_RUN_ON_THIS_SOURCE','Release114plus2':'NOT_RUN_ON_THIS_SOURCE','ownerApproval':'NOT_GRANTED','TestFlight':'NOT_UPLOADED'}
    dump(proof/'RESULT.json',result)
    (proof/'README.md').write_text('# Original History, Search and Saved Results wiring\n\nThe final fifteen-file candidate is joined to eleven exact existing integration preimages and four new files. Two narrow donor commits preserve39 History proof files and24 public Search selector/evidence files; the root product commit applies the remaining fourteen source/test/registration paths. No lab branch was merged. The original raw source controls and failed attempts remain immutable.\n\nThe History/Search publication correction passes21 actual caller/callback/unmount controls, versus6 passes15 failures in the real original and20 passes1 failure in the intermediate. Public DEBUG return retention passes six bounded controls; removing retention fails two meaningful cases. These are explicit source boundaries, not Core/native/Apple execution.\n\nSix app files receive fourteen new PBX objects with original object fields and order retained. Shared load metadata keeps all three original model targets; iOS-only integration stays iOS-only. All existing English/Hebrew catalog entries and ten total Shortcut definitions are preserved. The existing native helper retains its assertions; its namespace correction archives the first raw trace before the second original launch, and the new eight selectors append a separate helper suffix.\n\nThe complete twelve Swift files were frontend-parsed in both DEBUG and release conditional configurations for iOS27:24 successful syntax checks. This does not resolve Apple imports, link an app, extract AppIntents metadata, execute UIKit, qualify production data, or pass Native116/Release114+2. Cold/foreign-root and other original UI acceptance remains open. Real device archive, signing, upload, Apple processing and owner physical QA remain separate gates.\n')
    git('add','--sparse','--',PROOF)
    git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record exact original-entry integration source and raw controls')
    head=rev('HEAD');assert not git('status','--porcelain')
    assert git(*remote).decode().split()[0]==BASE
    git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
    assert git(*remote).decode().split()[0]==head
    terminal={'ok':True,'head':head,'sourceCommit':source_commit,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'deliveries':deliveries,'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'syntaxOnlyPassed':24,'nativeRuns':0,'freeBytes':shutil.disk_usage(ROOT).free}
    dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
    dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
