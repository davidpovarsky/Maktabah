from pathlib import Path
import hashlib,json

P='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
base=Path('public-search-native-implementation/baseline')/P
out=Path('wave3-all-original-entry-wiring/candidate')/P
raw=base.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(raw)==307308 and sha(raw)=='e0fff6e19dc8bdea7b2f6e9a6a79f874f652c60816b6302dc6993f1a79019b1d'
text=raw.decode();start=text.index('    func runOriginalSearchContinuation(')
prefix,body=text[:start],text[start:]
old='''        for language in ["en", "he"] {
            let token = UUID(), traceNamespace = UUID().uuidString
            XCTAssertEqual(isPad, expectedPad)
'''
new='''        for (iteration, language) in ["en", "he"].enumerated() {
            let token = UUID(), traceNamespace = workspaceNamespace
            if iteration > 0 {
                // miniTest10's ORIGINAL trace uses the workspace namespace.
                // Preserve the complete preceding launch before starting a
                // fresh one-process trace; never filter away unexpected events.
                app.terminate()
                let trace = try continuationTraceURL(traceNamespace)
                let originalBytes = try continuationRead(trace, maximum: 8 * 1024 * 1024)
                let preserved = trace.deletingLastPathComponent().appendingPathComponent(
                    "search-native-\\(traceNamespace)-before-relaunch-\\(token.uuidString).jsonl")
                XCTAssertFalse(FileManager.default.fileExists(atPath: preserved.path))
                try FileManager.default.moveItem(at: trace, to: preserved)
                XCTAssertEqual(try continuationRead(preserved, maximum: 8 * 1024 * 1024), originalBytes,
                    "The complete previous original trace must remain byte-identical")
                XCTAssertFalse(FileManager.default.fileExists(atPath: trace.path))
            }
            XCTAssertEqual(isPad, expectedPad)
'''
assert body.count(old)==1
candidate=prefix+body.replace(old,new)
assert candidate.replace(new,old)==text
assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_text(candidate)
proof={'schema':'otzaria.wave3.original-search-trace-namespace-correction.v1','path':P,
    'beforeBytes':len(raw),'beforeSHA256':sha(raw),'afterBytes':len(candidate.encode()),'afterSHA256':sha(candidate.encode()),
    'edits':[{'old':old,'new':new,'occurrences':1}],
    'originalController':'Source/ZayitSearch/UnifiedSearchSessionController.swift',
    'originalControllerSHA256':'252849ada7ce942c1d934e35f5ee486e636ea49f00663308e99bbff37185b60f',
    'reason':'miniTest10 writes its original append-only trace under the existing per-test workspace namespace. The old helper read a separate random namespace. The two language launches must also retain separate complete traces, so the prior owned log is moved, byte-verified and retained after terminating that app process.',
    'allOriginalAssertionsPreserved':True,'oldPrefixOtherwiseByteIdentical':True,
    'productSourceChanges':0,'native':'NOT_RUN','AppleSDK':'NOT_RUN'}
Path('wave3-all-original-entry-wiring/ORIGINAL_SEARCH_TRACE_FIX.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items()if k!='edits'}))
