from pathlib import Path
import hashlib,io,json,tarfile,gzip

ROOT=Path(__file__).parent
WORK=ROOT/'wave3-all-original-entry-wiring'
OUT=WORK/'delivery';OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for p in sorted((WORK/'candidate').rglob('*')):
    if p.is_file():files['candidate/'+str(p.relative_to(WORK/'candidate'))]=p.read_bytes()
for p in sorted(WORK.glob('*.json')):files['proof/'+p.name]=p.read_bytes()
for name in ['wire_original_entry_candidates.py','merge_saved_results_shared.py','fix_history_search_presentation_lifetime.py','fix_history_unmount_publication_order.py','register_saved_results_original_sources.py','fix_original_search_trace_namespace.py','merge_public_native_wiring.py','prepare_original_entry_capsule.py']:
    files['proof/controllers/'+name]=(ROOT/name).read_bytes()
files['proof/WIRING_CANDIDATE.json']=(ROOT/'wave3-original-entry-wiring/WIRING_CANDIDATE.json').read_bytes()
files['proof/verify_source_registration.py']=(ROOT/'search-continuation-integration/ui-baseline/verify_source_registration.py').read_bytes()
files['proof/PUBLIC_COMPOSITION_EDITS.json']=(ROOT/'public-search-native-implementation/proposal/COMPOSITION_EDITS.json').read_bytes()
files['proof/EXACT_HISTORY_WIRING_EDITS.json']=(ROOT/'root-history-reader-implementation/EXACT_WIRING_EDITS.json').read_bytes()
manifest={'schema':'otzaria.wave3.original-entry-final-capsule.v1','base':'e33fc140c84d20f8e595e9e4f032b9f44d426be5','files':[{'path':p,'bytes':len(b),'sha256':sha(b)}for p,b in sorted(files.items())]}
files['MANIFEST.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as tar:
    for path,b in sorted(files.items()):
        member=tarfile.TarInfo(path);member.size=len(b);member.mode=0o644;member.mtime=0
        tar.addfile(member,io.BytesIO(b))
archive=gzip.compress(buffer.getvalue(),mtime=0)
p=OUT/'ORIGINAL_ENTRY_WIRING.tar.gz';p.write_bytes(archive)
receipt={'path':str(p),'bytes':len(archive),'sha256':sha(archive),'members':len(files),'files':manifest['files']}
(OUT/'CAPSULE_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k!='files'}))
