from pathlib import Path
import hashlib,json

ROOT=Path('wave3-all-original-entry-wiring')
P='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
target=ROOT/'candidate'/P
before=target.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(before)=='5d3c30b6a119ce445cc343b17ff7c3aad7e70a0bb49b9d56622007d6d3da91f8'
preserve=ROOT/'preserved-before-history-search-publication'/P
preserve.parent.mkdir(parents=True,exist_ok=True)
assert not preserve.exists();preserve.write_bytes(before)
text=before.decode();edits=[]
def change(old,new):
    global text
    assert text.count(old)==1,(old[:100],text.count(old))
    text=text.replace(old,new)
    edits.append({'path':P,'old':old,'new':new,'occurrences':1})
change('    @ObservationIgnored private var searchPresentationOwner: UUID?\n',
'''    @ObservationIgnored private var searchPresentationOwner: UUID?
    @ObservationIgnored private var searchPresentationPublicationRevision: UInt64? = 0
''')
change('''        if searchPresentationOwner != owner {
            searchContinuationOwner?.retire(); publicSearchContinuationCatalog?.retire()
''','''        if searchPresentationOwner != owner {
            advanceOriginalSearchPresentationPublication()
            searchContinuationOwner?.retire(); publicSearchContinuationCatalog?.retire()
''')
change('''    func originalSearchPresentationWillChange(owner: UUID) {
        searchEntryBinding?.originalPresentationWillChange(owner: owner)
''','''    func originalSearchPresentationWillChange(owner: UUID) {
        if searchPresentationOwner == owner { advanceOriginalSearchPresentationPublication() }
        searchEntryBinding?.originalPresentationWillChange(owner: owner)
''')
change('''    func removeSearchPresentation(owner: UUID) {
        guard searchPresentationOwner == owner else { return }
        searchContinuationOwner?.retire()
''','''    func removeSearchPresentation(owner: UUID) {
        guard searchPresentationOwner == owner else { return }
        advanceOriginalSearchPresentationPublication()
        searchContinuationOwner?.retire()
''')
helper='''    private func advanceOriginalSearchPresentationPublication() {
        guard let revision = searchPresentationPublicationRevision, revision < .max else {
            searchPresentationPublicationRevision = nil
            return
        }
        searchPresentationPublicationRevision = revision + 1
    }

    /// Original Search State publications include its existing Saved Results,
    /// Save and FTS presentations. Retain their history before foreground waits:
    /// an open/close or owner replacement cannot restore an earlier observation.
    /// This reads the original owner and never changes its UI or grants access.
    private func retainHistorySearchPresentationObservation() throws -> @MainActor () throws -> Void {
        guard mounted, let revision = searchPresentationPublicationRevision else {
            throw UIRouteError(.unavailable, "history_reader_search_presentation_unavailable")
        }
        let owner = searchPresentationOwner
        let validate: @MainActor () throws -> Void = { [weak self] in
            guard let self, self.mounted,
                  self.searchPresentationPublicationRevision == revision,
                  self.searchPresentationOwner == owner,
                  self.searchPresentationBlocked?() != true else {
                throw UIRouteError(.staleState, "history_reader_search_presentation_changed")
            }
            // The original blocker is a callback. It cannot publish a new
            // owner/state and then return a value that rearms this observation.
            guard self.searchPresentationPublicationRevision == revision,
                  self.searchPresentationOwner == owner else {
                throw UIRouteError(.staleState, "history_reader_search_presentation_changed")
            }
        }
        try validate()
        return validate
    }

'''
change('    private func validateSearchPresentation() throws {\n',helper+'    private func validateSearchPresentation() throws {\n')
change('''    func captureHistoryReaderWindow() throws -> @MainActor () throws -> Void {
        let originalWindow = try retainOriginalWindowObservation()
''','''    func captureHistoryReaderWindow() throws -> @MainActor () throws -> Void {
        let searchPresentation = try retainHistorySearchPresentationObservation()
        let originalWindow = try retainOriginalWindowObservation()
''')
change('''        let validate: @MainActor () throws -> Void = { [weak self, weak manager, weak workspace] in
            _ = try originalWindow.validate()
            try observation.validate()
''','''        let validate: @MainActor () throws -> Void = { [weak self, weak manager, weak workspace] in
            try searchPresentation()
            _ = try originalWindow.validate()
            try observation.validate()
''')
change('''            try observation.validate()
            _ = try originalWindow.validate()
        }
        try validate()
        return validate
''','''            try observation.validate()
            _ = try originalWindow.validate()
            try searchPresentation()
        }
        try validate()
        return validate
''')
change('''        windowSource = nil; searchPresentationOwner = nil; searchPresentationBlocked = nil
''','''        advanceOriginalSearchPresentationPublication()
        windowSource = nil; searchPresentationOwner = nil; searchPresentationBlocked = nil
''')
inverse=text
for e in reversed(edits):
    assert inverse.count(e['new'])==1
    inverse=inverse.replace(e['new'],e['old'])
assert inverse.encode()==before
target.write_text(text)
(ROOT/'HISTORY_SEARCH_PUBLICATION_EDITS.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
proof={'path':P,'beforeBytes':len(before),'beforeSHA256':sha(before),'afterBytes':len(text.encode()),'afterSHA256':sha(text.encode()),
    'exactEditGroups':len(edits),'inverseRestoresCombinedSavedHistorySearch':True,
    'reason':'Actual existing Saved Search-state open/close can leave the same window/root/mapping. The original exact-owner callback now retires the captured publication history before existing callbacks; original UI assignments and callback order are preserved.',
    'controls':'PENDING','AppleSDK':'NOT_RUN','native':'NOT_RUN'}
(ROOT/'HISTORY_SEARCH_PUBLICATION_FIX.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
