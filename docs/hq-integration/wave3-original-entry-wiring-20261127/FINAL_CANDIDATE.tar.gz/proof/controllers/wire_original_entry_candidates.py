from pathlib import Path
import hashlib,json,re,runpy

WORK=Path(__file__).parent
ROOT=WORK/'wave3-original-entry-wiring'
OUT=ROOT/'candidate'
BASE=WORK/'search-continuation-integration/candidate'
HISTORY=WORK/'root-history-reader-implementation'
PUBLIC=WORK/'public-search-entry-implementation/proposals'
sha=lambda b:hashlib.sha256(b).hexdigest()
ROOT.mkdir(exist_ok=True);OUT.mkdir(exist_ok=True)
rows=[]
def put(path,b,before=None,scope='root-owned exact wiring'):
 p=OUT/path;p.parent.mkdir(exist_ok=True,parents=True);assert not p.exists(),str(p);p.write_bytes(b)
 rows.append({'path':path,'bytes':len(b),'sha256':sha(b),'beforeSHA256':before,'scope':scope})

# The public Search shared proposals are exact reviewed source against24cd.
proposal=json.loads((PUBLIC/'INPUTS.json').read_text())
files={}
preimages={}
for row in proposal['files']:
 path=row['path'];data=(PUBLIC/path).read_bytes()
 assert len(data)==row['candidateBytes'] and sha(data)==row['candidateSHA256']
 patch=(PUBLIC/(Path(path).name+'.patch')).read_bytes()
 assert len(patch)==row['patchBytes'] and sha(patch)==row['patchSHA256']
 files[path]=data.decode();preimages[path]=row['baseSHA256']

# Apply only the17 reviewed History insertions/replacements, preserving every
# public Search proposal byte outside those exact old spans. No fuzz/merge guess.
edits=json.loads((HISTORY/'EXACT_WIRING_EDITS.json').read_text())
for path in {e['path']for e in edits}:
 if path not in files:
  data=(HISTORY/'baseline'/path).read_bytes();files[path]=data.decode();preimages[path]=sha(data)
before_history=dict(files)
for edit in edits:
 path=edit['path'];assert files[path].count(edit['old'])==1,(path,edit['old'][:70])
 files[path]=files[path].replace(edit['old'],edit['new'])
for path,text in files.items():
 restored=text
 for edit in reversed([e for e in edits if e['path']==path]):
  assert restored.count(edit['new'])==1;restored=restored.replace(edit['new'],edit['old'])
 assert restored==before_history[path]
 put(path,text.encode(),preimages[path],'exact public Search proposal + inverse-verified History hunks')
for path in sorted((HISTORY/'candidate').rglob('*.swift')):
 relative=str(path.relative_to(HISTORY/'candidate'))
 if relative not in files:put(relative,path.read_bytes(),None,'root History source with33service/22source controls; app acceptance pending')

# Add only the two new downstream app integration files. Host files are
# discovered by their existing Swift package; no duplicate Xcode membership.
parser_path=WORK/'search-continuation-integration/ui-baseline/verify_source_registration.py'
assert sha(parser_path.read_bytes())=='eff5cf3c0935562f9e9b1bbcd296f192c4daf2922cc9185d8fa5ad0ab3246a18'
parser=runpy.run_path(str(parser_path))
project_path='Maktabah.xcodeproj/project.pbxproj';original=(BASE/project_path).read_bytes()
assert sha(original)=='909679eccc56d8ac8ec5be5947fd7f99fc855d62390a330836f28d9deee770bc'
before,old_duplicates=parser['parse'](original.decode());objects=before['objects']
phases=parser['target_sources'](before);group='CFEE00000000000000000001';phase=phases['Maktabah-iOS'][0]
assert phase=='F30576E22FA46222005732C6'
source_paths=['UIRoutingHost/Integration/MaktabahNativeHistoryReaderSource.swift','UIRoutingHost/Integration/MaktabahNativeSearchContinuationCatalog.swift']
entries=[]
for path in source_paths:
 item={'path':'Source/ChavrusaText/'+path,'relative':path,'name':Path(path).name,
       'ref':sha(('wave3-original-entry-ref:'+path).encode())[:24].upper(),
       'build':sha(('wave3-original-entry-ios:'+path).encode())[:24].upper()}
 assert item['ref']not in objects and item['build']not in objects
 assert not any(v.get('isa')=='PBXFileReference'and v.get('path')in[path,item['path']]for v in objects.values())
 entries.append(item)
text=original.decode();insertions=[]
def insert(offset,value):
 global text
 text=text[:offset]+value+text[offset:];insertions.append({'offset':offset,'text':value})
insert(text.index('/* End PBXBuildFile section */'),''.join('\t\t'+x['build']+' /* '+x['name']+' in Sources */ = {isa = PBXBuildFile; fileRef = '+x['ref']+' /* '+x['name']+' */; };\n'for x in entries))
insert(text.index('/* End PBXFileReference section */'),''.join('\t\t'+x['ref']+' /* '+x['name']+' */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = "'+x['relative']+'"; sourceTree = "<group>"; };\n'for x in entries))
for obj,field,body in [(group,'children',''.join('\t\t\t\t'+x['ref']+' /* '+x['name']+' */,\n'for x in entries)),(phase,'files',''.join('\t\t\t\t'+x['build']+' /* '+x['name']+' in Sources */,\n'for x in entries))]:
 start=re.search(r'(?m)^\t\t'+obj+r' /\*[^*]+\*/ = \{\n',text).start();anchor='\t\t\t'+field+' = (\n'
 insert(text.index(anchor,start)+len(anchor),body)
after,duplicates=parser['parse'](text);new=after['objects']
assert duplicates==old_duplicates and {k for k in objects if objects[k]!=new[k]}=={group,phase}
assert set(new)-set(objects)=={v for x in entries for v in[x['ref'],x['build']]}
for obj,field in[(group,'children'),(phase,'files')]:
 assert {k:v for k,v in objects[obj].items()if k!=field}=={k:v for k,v in new[obj].items()if k!=field}
 assert [v for v in new[obj][field]if v in objects[obj][field]]==objects[obj][field]
for item in entries:
 assert new[group]['children'].count(item['ref'])==1 and new[phase]['files'].count(item['build'])==1
 assert [name for name,(_,values)in parser['target_sources'](after).items()if item['build']in values]==['Maktabah-iOS']
inverse=text
for x in reversed(insertions):
 assert inverse[x['offset']:x['offset']+len(x['text'])]==x['text']
 inverse=inverse[:x['offset']]+inverse[x['offset']+len(x['text']):]
assert inverse.encode()==original
put(project_path,text.encode(),sha(original),'two exact additional original iOS memberships; inverse equals baseline')

catalogs=[]
def catalog(path,translations,english=True):
 original=(BASE/path).read_bytes();parsed=json.loads(original);assert parsed['sourceLanguage']=='en'
 inherited={k:parsed['strings'][k]for k in translations if k in parsed['strings']}
 additions={}
 for key,he in translations.items():
  assert re.findall(r'\$\{[^}]+\}',key)==re.findall(r'\$\{[^}]+\}',he)
  if key in inherited:
   assert inherited[key].get('localizations',{}).get('he',{}).get('stringUnit',{}).get('value'),key
   continue
  localizations={'he':{'stringUnit':{'state':'translated','value':he}}}
  if english:localizations={'en':{'stringUnit':{'state':'translated','value':key}},**localizations}
  additions[key]={'localizations':localizations}
 anchor='  "strings": {\n';source=original.decode();assert source.count(anchor)==1
 block='\n'.join('  '+line for line in json.dumps(additions,ensure_ascii=False,indent=2)[2:-2].splitlines())+',\n'
 candidate=source.replace(anchor,anchor+block,1);new=json.loads(candidate)
 assert {k:v for k,v in new['strings'].items()if k not in additions}==parsed['strings']
 assert candidate.replace(anchor+block,anchor,1).encode()==original
 put(path,candidate.encode(),sha(original),'additive EN/HE catalog; all original entries and bytes preserved')
 catalogs.append({'path':path,'added':list(additions),'inherited':list(inherited),'inverseExact':True})
catalog('Source/Localizable.xcstrings',{
 'Saved reading position':'מיקום קריאה שמור',
 'Resume reading from history':'המשך קריאה מההיסטוריה',
 'Resume reading':'המשך קריאה',
 'Reader window':'חלון הקריאה',
 'Open in a new tab':'פתיחה בכרטיסייה חדשה',
 'Open the original Reader at an existing saved history position in the selected Maktabah window.':'פתיחת הקורא במיקום הקריאה השמור בהיסטוריה, בחלון אוצריא שנבחר.',
 'Search target':'יעד בחיפוש',
 'Show a loaded search result':'הצגת תוצאת חיפוש שנטענה',
 'Show search result':'הצגת תוצאת חיפוש',
 'Loaded search result':'תוצאת חיפוש שנטענה',
 'Reveal an existing result in its original search window. The current query and filters are preserved.':'הצגת תוצאה קיימת בחלון החיפוש שלה, תוך שמירת השאילתה והסינון הנוכחיים.',
 'Search result':'תוצאת חיפוש',
 'Show ${result}':'הצגת ${result}',
 'Load the next search page':'טעינת עמוד החיפוש הבא',
 'Next search page':'עמוד החיפוש הבא',
 'Load the next page of the selected existing search. The original search determines the next page.':'טעינת העמוד הבא בחיפוש הקיים שנבחר. העמוד נקבע לפי מצב החיפוש הנוכחי.',
 'Search page':'עמוד חיפוש',
 'Load ${page}':'טעינת ${page}',
 'Get a search link':'קבלת קישור לחיפוש',
 'Create a link to a current search result or next page. The link contains no query text and expires when the original search changes.':'יצירת קישור לתוצאת חיפוש קיימת או לעמוד הבא. הקישור אינו מכיל את השאילתה ותוקפו פג כאשר החיפוש משתנה.',
 'Get a link to ${target}':'קבלת קישור אל ${target}',
})
catalog('Source/ChavrusaText/UIRoutingHost/Integration/AppShortcuts.xcstrings',{
 'Resume reading ${entry} in ${applicationName}':'המשך לקרוא את ${entry} באפליקציה ${applicationName}',
 'Show search result ${result} in ${applicationName}':'הצג את תוצאת החיפוש ${result} באפליקציה ${applicationName}',
 'Load next search page in ${applicationName}':'טען את עמוד החיפוש הבא באפליקציה ${applicationName}',
},False)
path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift'
original=(BASE/path).read_text();assert sha(original.encode())=='cf7a6176a4e1ff9a36b2b87350265ba74aa140ffd932ded48659997c873aa7b4'
addition='''        AppShortcut(intent: ResumeHistoryReadingIntent(),
                    phrases: ["Resume reading \\(\\.$entry) in \\(.applicationName)"],
                    shortTitle: "Resume reading", systemImageName: "clock.arrow.circlepath")
        AppShortcut(intent: RevealLoadedSearchResultIntent(),
                    phrases: ["Show search result \\(\\.$result) in \\(.applicationName)"],
                    shortTitle: "Show search result", systemImageName: "text.magnifyingglass")
        AppShortcut(intent: LoadNextOriginalSearchPageIntent(),
                    phrases: ["Load next search page in \\(.applicationName)"],
                    shortTitle: "Next search page", systemImageName: "arrow.down.doc")
'''
anchor='    }\n}\n#endif\n';assert original.count(anchor)==1
candidate=original.replace(anchor,addition+anchor)
assert original.count('AppShortcut(intent:')==6 and candidate.count('AppShortcut(intent:')==9
assert candidate.replace(addition,'')==original
put(path,candidate.encode(),sha(original.encode()),'three new system shortcuts; six original definitions byte-preserved')
proof={'baseSource':'23cdfce49553927656ef79c6db10f654c889e2fc','sharedSourceMerge':'17 History hunks applied exactly after3 independently reviewed public Search proposals; inverse restores each proposal','files':rows,'projectEntries':entries,'projectInsertions':insertions,'catalogs':catalogs,'originalShortcuts':6,'newShortcuts':3,'AppleSDK':'NOT_RUN','native':'NOT_RUN','pending':'SavedResults shared proposals/registration are separate; History exact method control and public source sealing pending'}
(ROOT/'WIRING_CANDIDATE.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(rows),'projectObjectsAdded':4,'shortcutsAfter':9,'addedCatalogKeys':sum(len(c['added'])for c in catalogs),'sourceJoinInverseVerified':True,'products':rows},ensure_ascii=False))
