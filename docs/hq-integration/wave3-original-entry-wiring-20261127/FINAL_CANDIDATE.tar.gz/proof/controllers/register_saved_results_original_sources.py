from pathlib import Path
import hashlib,json,re,runpy

ROOT=Path('wave3-all-original-entry-wiring')
OUT=ROOT/'candidate'
SAVED=Path('saved-results-reveal/shared-proposals')
sha=lambda b:hashlib.sha256(b).hexdigest()
parser=runpy.run_path('search-continuation-integration/ui-baseline/verify_source_registration.py')
path='Maktabah.xcodeproj/project.pbxproj';original=(OUT/path).read_bytes()
assert sha(original)=='ebdfc5173ce3b5a4f5893374bf7ba0ceaae42366deef6f30f4939fd6f3eb229b'
before,duplicates=parser['parse'](original.decode());objects=before['objects'];phases=parser['target_sources'](before)
old_ref='4B58EDCD2EE3DDEE00073495'
assert objects[old_ref]['path']=='ResultsViewModel.swift'
old_build={k for k,v in objects.items()if v.get('isa')=='PBXBuildFile' and v.get('fileRef')==old_ref}
original_targets=[name for name,(_,members)in phases.items()if any(x in old_build for x in members)]
assert set(original_targets)=={'Maktabah','Maktabah-Direct','Maktabah-iOS'}
membership=json.loads((SAVED/'MEMBERSHIP.json').read_text())['new_files']
entries=[]
for row in membership:
    if '/Sources/ChavrusaUIRoutingHost/'in row['path']:continue
    raw=(Path('saved-results-reveal/candidate')/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    relative=row['path'].removeprefix('Source/ChavrusaText/')
    assert relative!=row['path']
    targets=original_targets if relative=='Bookmarks/OriginalSavedResultsLoadLifetime.swift' else ['Maktabah-iOS']
    ref=sha(('wave3-saved-results-ref:'+relative).encode())[:24].upper()
    builds={target:sha(('wave3-saved-results-build:'+target+':'+relative).encode())[:24].upper()for target in targets}
    assert ref not in objects and not any(x in objects for x in builds.values())
    assert not any(v.get('isa')=='PBXFileReference'and v.get('path')in[row['path'],relative]for v in objects.values())
    entries.append({**row,'relative':relative,'name':Path(relative).name,'ref':ref,'builds':builds})
assert len(entries)==4 and sum(len(x['builds'])for x in entries)==6
text=original.decode();insertions=[]
def insert(offset,value):
    global text
    text=text[:offset]+value+text[offset:];insertions.append({'offset':offset,'text':value})
insert(text.index('/* End PBXBuildFile section */'),''.join('\t\t'+build+' /* '+x['name']+' in Sources */ = {isa = PBXBuildFile; fileRef = '+x['ref']+' /* '+x['name']+' */; };\n'for x in entries for build in x['builds'].values()))
insert(text.index('/* End PBXFileReference section */'),''.join('\t\t'+x['ref']+' /* '+x['name']+' */ = {isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = "'+x['relative']+'"; sourceTree = "<group>"; };\n'for x in entries))
group='CFEE00000000000000000001'
updates=[(group,'children',''.join('\t\t\t\t'+x['ref']+' /* '+x['name']+' */,\n'for x in entries))]
for target in original_targets:
    updates.append((phases[target][0],'files',''.join('\t\t\t\t'+x['builds'][target]+' /* '+x['name']+' in Sources */,\n'for x in entries if target in x['builds'])))
for object_id,field,value in updates:
    start=re.search(r'(?m)^\t\t'+object_id+r' /\*[^*]+\*/ = \{\n',text).start()
    anchor='\t\t\t'+field+' = (\n';insert(text.index(anchor,start)+len(anchor),value)
after,after_duplicates=parser['parse'](text);new=after['objects']
assert duplicates==after_duplicates
assert {k for k in objects if objects[k]!=new[k]}=={row[0]for row in updates}
assert set(new)-set(objects)=={x['ref']for x in entries}|{v for x in entries for v in x['builds'].values()}
for object_id,field,_ in updates:
    assert {k:v for k,v in objects[object_id].items()if k!=field}=={k:v for k,v in new[object_id].items()if k!=field}
    assert [x for x in new[object_id][field]if x in objects[object_id][field]]==objects[object_id][field]
for x in entries:
    assert new[group]['children'].count(x['ref'])==1
    for target,build in x['builds'].items():
        assert [name for name,(_,members)in parser['target_sources'](after).items()if build in members]==[target]
inverse=text
for i in reversed(insertions):
    assert inverse[i['offset']:i['offset']+len(i['text'])]==i['text']
    inverse=inverse[:i['offset']]+inverse[i['offset']+len(i['text']):]
assert inverse.encode()==original
(OUT/path).write_text(text)
rows=[{'path':path,'beforeSHA256':sha(original),'afterSHA256':sha(text.encode()),'afterBytes':len(text.encode()),'inverseExact':True}]

def append_catalog(path,entries,english=True):
    original=(OUT/path).read_bytes();old=json.loads(original);assert old['sourceLanguage']=='en'
    added={}
    for key,he in entries.items():
        assert key not in old['strings'],key
        assert re.findall(r'\$\{[^}]+\}',key)==re.findall(r'\$\{[^}]+\}',he)
        translations={'he':{'stringUnit':{'state':'translated','value':he}}}
        if english:translations={'en':{'stringUnit':{'state':'translated','value':key}},**translations}
        added[key]={'localizations':translations}
    anchor='  "strings": {\n';source=original.decode();assert source.count(anchor)==1
    block='\n'.join('  '+l for l in json.dumps(added,ensure_ascii=False,indent=2)[2:-2].splitlines())+',\n'
    candidate=source.replace(anchor,anchor+block,1);parsed=json.loads(candidate)
    assert {k:v for k,v in parsed['strings'].items()if k not in added}==old['strings']
    assert candidate.replace(anchor+block,anchor,1).encode()==original
    (OUT/path).write_text(candidate)
    rows.append({'path':path,'beforeSHA256':sha(original),'afterSHA256':sha(candidate.encode()),'afterBytes':len(candidate.encode()),'addedKeys':list(added),'inverseExact':True})

keys=json.loads((SAVED/'LOCALIZATION_KEYS.json').read_text())
append_catalog('Source/Localizable.xcstrings',{x['key']:x['he']for x in keys['new_literals']})
assert json.loads((OUT/'Source/Localizable.xcstrings').read_text())['strings']['Saved Results']['localizations']['he']['stringUnit']['value']
append_catalog('Source/ChavrusaText/UIRoutingHost/Integration/AppShortcuts.xcstrings',{
    'Show saved search result in ${applicationName}':'הצגת תוצאת חיפוש שמורה ב־${applicationName}',
},False)
path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeIntents.swift'
original=(OUT/path).read_bytes();source=original.decode();addition=(SAVED/'APP_SHORTCUT_ADDITION.swift').read_text()
anchor='    }\n}\n#endif\n';assert source.count(anchor)==1
candidate=source.replace(anchor,addition+anchor)
assert source.count('AppShortcut(intent:')==9 and candidate.count('AppShortcut(intent:')==10
assert candidate.replace(addition,'').encode()==original
(OUT/path).write_text(candidate)
rows.append({'path':path,'beforeSHA256':sha(original),'afterSHA256':sha(candidate.encode()),'afterBytes':len(candidate.encode()),'shortcutCount':10,'inverseExact':True})
proof={'schema':'otzaria.wave3.saved-results-registration.v1','originalResultsViewModelTargets':original_targets,
    'files':rows,'additionalAppEntries':entries,'projectInsertions':insertions,'originalObjectsAndOrderingPreserved':True,
    'allExistingCatalogEntriesPreserved':True,'AppleSDK':'NOT_RUN','AppIntentsMetadata':'NOT_RUN','native':'NOT_RUN'}
(ROOT/'SAVED_REGISTRATION.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':rows,'appFilesAdded':4,'pbxObjectsAdded':10,'originalTargets':original_targets},ensure_ascii=False))
