from pathlib import Path
import hashlib,json,re

ROOT=Path(__file__).parent
WORK=ROOT/'wave3-all-original-entry-wiring'
OUT=WORK/'candidate'
PROPOSAL=ROOT/'public-search-native-implementation/proposal'
sha=lambda b:hashlib.sha256(b).hexdigest()
report={'schema':'otzaria.wave3.public-native-exact-wiring.v1','AppleSDK':'NOT_RUN','native':'NOT_RUN'}

path='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift'
original=(OUT/path).read_bytes()
assert len(original)==246040 and sha(original)=='eeb1b4b4758df16bacbcc5cf12d69b12a0bf08cff2ac8017aada2d8916435926'
edits=json.loads((PROPOSAL/'COMPOSITION_EDITS.json').read_text());assert len(edits)==7
text=original.decode()
for edit in edits:
    assert text.count(edit['before'])==1,edit['label']
    text=text.replace(edit['before'],edit['after'])
inverse=text
for edit in reversed(edits):
    assert inverse.count(edit['after'])==1,edit['label']
    inverse=inverse.replace(edit['after'],edit['before'])
assert inverse.encode()==original
candidate=text.encode()
assert len(candidate)==253472 and sha(candidate)=='9ebdf1237a1cd9cb0d64e7fd31542c2c3aee3907c7ce24488c966a14a4f4a720'
assert candidate==(ROOT/'public-search-native-implementation/candidate'/path).read_bytes()
preserved=WORK/'preserved-before-public-native-observer'/path
preserved.parent.mkdir(parents=True,exist_ok=True);assert not preserved.exists();preserved.write_bytes(original)
(OUT/path).write_bytes(candidate)
report['composition']={'path':path,'beforeBytes':len(original),'beforeSHA256':sha(original),'bytes':len(candidate),'sha256':sha(candidate),'exactHunks':7,'inverseExact':True}

path='Maktabah-iOSUITests/NativeRoutingAcceptanceTests.swift'
original=(OUT/path).read_bytes()
assert len(original)==308429 and sha(original)=='e5e5d6fa742aa88ab49f8159f9d413cd8b1de4cd244b8cb60b16c2a4e3e20acd'
suffix=(PROPOSAL/'NATIVE_HELPER_ADDITION.swift').read_bytes()
assert len(suffix)==29295 and sha(suffix)=='e3d87de5d04582471341381983c11afda7f1d1f7cd46326f83c1e22da87e510b'
old_native=(ROOT/'public-search-native-implementation/baseline'/path).read_bytes()
assert len(old_native)==307308 and sha(old_native)=='e0fff6e19dc8bdea7b2f6e9a6a79f874f652c60816b6302dc6993f1a79019b1d'
assert (ROOT/'public-search-native-implementation/candidate'/path).read_bytes()==old_native+suffix
new_functions=set(re.findall(rb'\bfunc\s+(\w+)\(',suffix))
assert not (new_functions & set(re.findall(rb'\bfunc\s+(\w+)\(',original)))
candidate=original+suffix
assert candidate[:len(original)]==original
preserved=WORK/'preserved-before-public-native-observer'/path
preserved.parent.mkdir(parents=True,exist_ok=True);assert not preserved.exists();preserved.write_bytes(original)
(OUT/path).write_bytes(candidate)
report['nativeHelper']={'path':path,'beforeBytes':len(original),'beforeSHA256':sha(original),'bytes':len(candidate),'sha256':sha(candidate),'suffixBytes':len(suffix),'suffixSHA256':sha(suffix),'correctedExistingPrefixExact':True,'oldAssertionEdits':0}

path='Maktabah-iOSUITests/NativePublicSearchContinuationAcceptanceTests.swift'
candidate=(PROPOSAL/Path(path).name).read_bytes()
assert len(candidate)==1937 and sha(candidate)=='822da13472beeed20ac2e02a234ea74e86d9586929316b12065b0b661707d35e'
assert len(re.findall(rb'\bfunc\s+test\w+\(',candidate))==8
assert not (OUT/path).exists();(OUT/path).write_bytes(candidate)
report['newSelectors']={'path':path,'bytes':len(candidate),'sha256':sha(candidate),'selectorCount':8,'targetRegistration':'Existing filesystem-synchronized Maktabah-iOSUITests root; no new PBX mutation'}
report['instrumentationBoundary']='DEBUG capture after actual Composition execution and before final service deadline qualification. Real Intent.run success or original URL refusal is independently required. No production trigger/grant/fallback or deadline change.'
report['urlTransportPrerequisite']='Two finite public Search paths require a separately controlled exact runtime27-url-delivery allowlist addition; native execution remains pending.'
(WORK/'PUBLIC_NATIVE_WIRING.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
