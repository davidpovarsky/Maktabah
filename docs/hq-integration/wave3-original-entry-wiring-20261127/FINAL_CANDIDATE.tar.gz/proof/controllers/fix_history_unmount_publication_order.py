from pathlib import Path
import hashlib,json
root=Path('wave3-all-original-entry-wiring')
name='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift'
p=root/'candidate'/name;before=p.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(before)=='bbf93e364f006428f1db86de7845ab1f6ecb4a2bfca0366c3ea00246c65e3ea7'
old=root/'preserved-before-unmount-order-fix'/name;old.parent.mkdir(parents=True,exist_ok=True)
assert not old.exists();old.write_bytes(before)
edits=[{
 'path':name,'old':'        advanceOriginalSearchPresentationPublication()\n        windowSource = nil; searchPresentationOwner = nil; searchPresentationBlocked = nil\n',
 'new':'        windowSource = nil; searchPresentationOwner = nil; searchPresentationBlocked = nil\n','occurrences':1,
},{
 'path':name,'old':'    func unmount() {\n        guard mounted else { return }\n        lastCompletedSurface = nil\n',
 'new':'    func unmount() {\n        guard mounted else { return }\n        advanceOriginalSearchPresentationPublication()\n        lastCompletedSurface = nil\n','occurrences':1,
}]
text=before.decode()
for e in edits:
 assert text.count(e['old'])==1;text=text.replace(e['old'],e['new'])
inverse=text
for e in reversed(edits):
 assert inverse.count(e['new'])==1;inverse=inverse.replace(e['new'],e['old'])
assert inverse.encode()==before
p.write_text(text)
proof={'path':name,'beforeBytes':len(before),'beforeSHA256':sha(before),'afterBytes':len(text.encode()),'afterSHA256':sha(text.encode()),
 'edits':edits,'inverseExact':True,'reason':'The existing unmount invokes external retirement callbacks while mounted is still true. Publish invalidation immediately after its original mounted guard, before every existing callback; keep all original effects and their order.',
 'controls':'PENDING','AppleSDK':'NOT_RUN','native':'NOT_RUN'}
(root/'HISTORY_UNMOUNT_ORDER_FIX.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items()if k!='edits'}))
