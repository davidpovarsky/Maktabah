from pathlib import Path
import hashlib,json,shutil

BASE=Path('wave3-original-entry-wiring')
SAVED=Path('saved-results-reveal/shared-proposals')
OUT=Path('wave3-all-original-entry-wiring')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not OUT.exists()
OUT.mkdir()
manifest=json.loads((BASE/'WIRING_CANDIDATE.json').read_text())
edits_raw=(SAVED/'EXACT_WIRING_EDITS.json').read_bytes()
edits=json.loads(edits_raw)
assert len(edits)==45
candidate=OUT/'candidate'
shutil.copytree(BASE/'candidate',candidate)
originals={}
for path in {e['path']for e in edits}:
    p=candidate/path
    if not p.exists():
        source=SAVED/'baseline'/path
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(source.read_bytes())
    originals[path]=p.read_text()
files=dict(originals)
for index,e in enumerate(edits):
    text=files[e['path']]
    assert text.count(e['old'])==e['occurrences'],(index,e['path'],text.count(e['old']),e['occurrences'])
    files[e['path']]=text.replace(e['old'],e['new'])
rows=[]
for path,text in files.items():
    inverse=text
    for e in reversed([x for x in edits if x['path']==path]):
        assert inverse.count(e['new'])==e['occurrences'],(path,e['new'][:80])
        inverse=inverse.replace(e['new'],e['old'])
    assert inverse==originals[path]
    p=candidate/path;p.write_text(text)
    rows.append({'path':path,'beforeBytes':len(originals[path].encode()),'beforeSHA256':sha(originals[path].encode()),
        'afterBytes':len(text.encode()),'afterSHA256':sha(text.encode()),'inverseRestoresPriorCombinedSource':True})
proof={'schema':'otzaria.wave3.original-entry-shared-merge.v1','priorWiringSHA256':sha((BASE/'WIRING_CANDIDATE.json').read_bytes()),
    'savedEditsSHA256':sha(edits_raw),'editGroups':45,'actualReplacements':sum(e['occurrences']for e in edits),
    'files':rows,'AppleSDK':'NOT_RUN','native':'NOT_RUN',
    'pending':'Saved donor/source registration and tenth shortcut; actual History method control; combined source parsing; root intake'}
(OUT/'SHARED_MERGE.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(proof,ensure_ascii=False))
