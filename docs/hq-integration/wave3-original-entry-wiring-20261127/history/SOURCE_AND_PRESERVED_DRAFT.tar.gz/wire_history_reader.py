import hashlib,json,pathlib

root=pathlib.Path(__file__).parent
base=root/"baseline"
candidate=root/"candidate"
pins={
 "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift":"134a01ada9114405437d8c1f655b13cd321ea64ddf3a0b9d3c1b5837e48bd3b4",
 "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift":"902b93bfdc8beea69779b7fa5f0acb85d65bcf8178600c3b2d6e38ea0c4201e5",
 "Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneBindings.swift":"b18518dbf450cf5e923632df17f660169bca3e86b029790645da1f5aaf69e81f",
}
files={}
edits=[]
for path,sha in pins.items():
 b=(base/path).read_bytes()
 assert hashlib.sha256(b).hexdigest()==sha
 assert (candidate/path).read_bytes()==b
 files[path]=b.decode()
def replace(path,old,new):
 assert files[path].count(old)==1,(path,old[:120],files[path].count(old))
 files[path]=files[path].replace(old,new)
 edits.append({"path":path,"old":old,"new":new})

binding="Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneBindings.swift"
replace(binding,"    private let reservation: StudyWorkspaceNativeReaderReservation?\n",
"""    private let reservation: StudyWorkspaceNativeReaderReservation?
    private let historySource: MaktabahNativeHistoryReaderSource?
""")
replace(binding,"""         workspace: StudyWorkspaceNavigationAdapter?, requestID: UUID, content: ActionReaderDestination,
         revoke: @escaping @MainActor () -> Void) throws {
        let destination = try Self.appDestination(content)
""","""         workspace: StudyWorkspaceNavigationAdapter?, requestID: UUID, content: ActionReaderDestination,
         historySource: MaktabahNativeHistoryReaderSource? = nil,
         revoke: @escaping @MainActor () -> Void) throws {
        if let historySource {
            try historySource.validate()
            guard historySource.request.invocation.requestId == requestID,
                  (content.focusLocator ?? content.sectionLocator) == historySource.locator,
                  (content.presentationMode == .newTab) == historySource.request.newTab else {
                throw UIRouteError(.staleState, "history_reader_request_changed")
            }
        }
        let destination = try Self.appDestination(content)
""")
replace(binding,"        self.workspace = workspace; reservation = reserved\n",
"""        self.workspace = workspace; reservation = reserved
        self.historySource = historySource
""")
replace(binding,"""        guard valid, installed else { throw UIRouteError(.staleState, "reader_binding_revoked") }
        if let reservation {
""","""        guard valid, installed else { throw UIRouteError(.staleState, "reader_binding_revoked") }
        try historySource?.validate()
        if let reservation {
""")
replace(binding,"""        if let reservation {
            guard let workspace else { throw ActionPortError.staleState }
            try workspace.applyNativeReader(reservation, operation: operation)
        } else { try operation() }
        try validate()
""","""        try withHistorySource {
            if let reservation {
                guard let workspace else { throw ActionPortError.staleState }
                try workspace.applyNativeReader(reservation, operation: operation)
            } else { try operation() }
        }
        try validate()
""")
replace(binding,"""    func release() {
        guard installed else { return }
""","""    private func withHistorySource(_ operation: () throws -> Void) throws {
        if let historySource { try historySource.performOriginalApply(operation) }
        else { try operation() }
    }
    func release() {
        guard installed else { return }
""")

session="Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeSceneSession.swift"
replace(session,"""    func retainReader(_ content: ActionReaderDestination, requestID: UUID,
                      revoke: @escaping @MainActor () -> Void) throws -> MaktabahNativeReaderBinding {
""","""    func retainReader(_ content: ActionReaderDestination, requestID: UUID,
                      historySource: MaktabahNativeHistoryReaderSource? = nil,
                      revoke: @escaping @MainActor () -> Void) throws -> MaktabahNativeReaderBinding {
""")
replace(session,"""            currentTabID: identity.activeTabID, workspace: workspace, requestID: requestID, content: content, revoke: revoke)
""","""            currentTabID: identity.activeTabID, workspace: workspace, requestID: requestID, content: content,
            historySource: historySource, revoke: revoke)
""")
window_capture=r'''
    /// Retain the selected original window before system foreground activation.
    /// This read-only witness ends at the existing Reader reservation handoff;
    /// the original mapping/Core owners govern all later native awaits.
    func captureHistoryReaderWindow() throws -> @MainActor () throws -> Void {
        let originalWindow = try retainOriginalWindowObservation()
        _ = try originalWindow.validate()
        let manager = bindings.manager
        guard mounted, !bindings.showSettings.wrappedValue, bindings.isPresentationReady,
              let root = bindings.rootPublications,
              let rootRevision = root.selectionRevision, let settingsRevision = root.settingsRevision,
              let modeRevision = manager.nativeModePresentationRevision,
              let bookRevision = manager.selectedBookPresentationRevision,
              let source = workspaceProjectionSource, source.isAuthoritative,
              let workspace = try source.read(), workspace.attached, !workspace.isSwitching,
              let mapping = workspace.mappingOwnershipObservation(),
              mapping.coverage == .liveNativeSetters, mapping.scene == sceneID.rawValue,
              mapping.owner == ObjectIdentifier(manager), mapping.source.event.phase == .available,
              mapping.source.event.epoch == mapping.epoch else {
            throw UIRouteError(.unavailable, "history_reader_window_owner_unavailable")
        }
        let selected = bindings.selectedTab.wrappedValue
        guard selected == selected.canonical, manager.currentMode == selected.appMode else {
            throw UIRouteError(.unavailable, "history_reader_window_not_committed")
        }
        let observation = MaktabahNativeComponentSourceObservation {
            _ = manager.openTabs; _ = manager.activeTabId; _ = manager.selectedBook
            _ = manager.selectedContentId; _ = manager.currentMode
            _ = manager.selectedBookForInfo; _ = manager.showingTabsList; _ = manager.alertMessage
            _ = manager.activeReaderViewModel?.isPopoverPresented
            _ = manager.activeReaderViewModel?.readerInspectorVisible
            _ = DonationManager.shared.showDonationSheet
            _ = workspace.attached; _ = workspace.isSwitching
            _ = workspace.mappingOwnershipSource.event
        }
        let validate: @MainActor () throws -> Void = { [weak self, weak manager, weak workspace] in
            _ = try originalWindow.validate()
            try observation.validate()
            guard let self, let manager, let workspace, self.mounted,
                  self.bindings.manager === manager, self.bindings.rootPublications === root,
                  root.selectionRevision == rootRevision, root.settingsRevision == settingsRevision,
                  self.bindings.selectedTab.wrappedValue == selected,
                  manager.currentMode == selected.appMode,
                  manager.nativeModePresentationRevision == modeRevision,
                  manager.selectedBookPresentationRevision == bookRevision,
                  !self.bindings.showSettings.wrappedValue, self.bindings.isPresentationReady,
                  self.workspaceProjectionSource === source, source.isAuthoritative,
                  let current = try source.read(), current === workspace,
                  workspace.attached, !workspace.isSwitching,
                  let actual = workspace.mappingOwnershipObservation(),
                  actual.coverage == .liveNativeSetters, actual.source === mapping.source,
                  actual.owner == mapping.owner, actual.scene == mapping.scene,
                  actual.epoch == mapping.epoch, actual.projection == mapping.projection,
                  actual.source.event.phase == .available, actual.source.event.epoch == actual.epoch else {
                throw UIRouteError(.staleState, "history_reader_window_owner_changed")
            }
            try observation.validate()
            _ = try originalWindow.validate()
        }
        try validate()
        return validate
    }
'''
replace(session,"    /// Typed record metadata is converted into private route state only by the\n",
        window_capture+"\n    /// Typed record metadata is converted into private route state only by the\n")

composition="Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeRoutingComposition.swift"
replace(composition,"    private var intentsInstalled = false\n",
"""    private var intentsInstalled = false
    private var historyReaderCatalog: MaktabahNativeHistoryReaderCatalog?
""")
replace(composition,"""                      until end: UInt64, requestID: UUID = UUID()) async throws -> UISceneAcknowledgement {
""","""                      until end: UInt64, requestID: UUID = UUID(),
                      historySource: MaktabahNativeHistoryReaderSource? = nil,
                      didObserveReader: (@MainActor (ActionResult?, UISceneReceipt?) -> Void)? = nil) async throws -> UISceneAcknowledgement {
""")
replace(composition,"""        let invocation = ActionPortInvocation(requestId: requestID, snapshot: snapshot, deadlineUptimeNanoseconds: end)
        // Retain the exact ORIGINAL parent first; a component must inherit
""","""        let invocation = ActionPortInvocation(requestId: requestID, snapshot: snapshot, deadlineUptimeNanoseconds: end)
        if let historySource {
            try historySource.validate()
            guard historySource.request.invocation.requestId == requestID,
                  historySource.request.invocation.snapshot == snapshot,
                  historySource.request.invocation.deadlineUptimeNanoseconds == end,
                  historySource.request.window.sceneID == sceneID,
                  intent.destination.rawValue == "native.reader" else {
                throw UIRouteError(.staleState, "history_reader_invocation_changed")
            }
        }
        // Retain the exact ORIGINAL parent first; a component must inherit
""")
replace(composition,"""            try entry.session.retainReader(content, requestID: invocation.requestId) { [weak self, weak session = entry.session] in
""","""            try entry.session.retainReader(content, requestID: invocation.requestId,
                historySource: historySource) { [weak self, weak session = entry.session] in
""")
replace(composition,"""        case .surface(let prepared):
            result = await orchestrator.commitPrepared(prepared, admitted: admitted)
        case .reader(let route):
""","""        case .surface(let prepared):
            guard historySource == nil else {
                throw UIRouteError(.failed, "history_reader_plan_not_reader")
            }
            result = await orchestrator.commitPrepared(prepared, admitted: admitted)
        case .reader(let route):
""")
replace(composition,"""            defer { readerInvocations.removeValue(forKey: invocation.requestId) }
            let coreResult = try await orchestrator.executeReaderPlan(route, originalInvocation: invocation, admitted: admitted)
            guard coreResult.status == .completed, let receipt = pending.receipt else {
""","""            var observedCoreResult: ActionResult?
            defer {
                // The actual Core return and native receipt survive a later
                // refusal or thrown cancellation. This callback grants nothing.
                didObserveReader?(observedCoreResult, pending.receipt)
                readerInvocations.removeValue(forKey: invocation.requestId)
            }
            let coreResult = try await orchestrator.executeReaderPlan(route, originalInvocation: invocation, admitted: admitted)
            observedCoreResult = coreResult
            guard coreResult.status == .completed, let receipt = pending.receipt else {
""")

entry=r'''
    private func originalHistoryReaderCatalog() -> MaktabahNativeHistoryReaderCatalog {
        if let historyReaderCatalog { return historyReaderCatalog }
        let value = MaktabahNativeHistoryReaderCatalog(snapshot: { [weak self] in
            guard let self else { throw ActionPortError.unavailable }
            return try backend.currentBackendSnapshot()
        })
        historyReaderCatalog = value
        return value
    }

    private func openHistoryReading(_ request: NativeHistoryReaderIntentService.OpenRequest) async throws
        -> NativeHistoryReaderIntentService.Execution {
        try Task.checkCancellation()
        let window = request.window, invocation = request.invocation
        let matches = try intentRootEntities().filter { $0 == window }
        guard matches.count == 1, window.destination.rawValue == "native.library",
              window.component == nil, window.backend == invocation.snapshot.backend,
              let original = scenes[window.sceneID], original.session.mounted,
              let manager = original.manager, ObjectIdentifier(manager) == original.managerID,
              try backend.currentBackendSnapshot() == invocation.snapshot else {
            throw UIRouteError(.staleState, "history_reader_window_no_longer_available")
        }
        let catalog = originalHistoryReaderCatalog()
        let source = try catalog.retain(request)
        defer { catalog.finish(source) }
        let validateWindow = try original.session.captureHistoryReaderWindow()
        try source.validate()
        let activated = try await NativeObservationDeadline.run(
            until: invocation.deadlineUptimeNanoseconds, clock: SystemActionClock()) { [self] in
                try await waitForMount(managerID: original.managerID)
            }
        try source.validate(); try validateWindow()
        guard activated == window.sceneID, let current = scenes[window.sceneID],
              current.session === original.session, current.manager === manager,
              current.managerID == original.managerID, current.session.mounted, current.session.foreground,
              try backend.currentBackendSnapshot() == invocation.snapshot else {
            throw UIRouteError(.staleState, "history_reader_window_changed_during_activation")
        }
        let locator = try ActionAppIdentityBridge.appLocator(source.locator)
        let resolved = ReaderDestinationResolver.resolve(locator: locator)
        let content = ActionReaderDestination(
            sectionLocator: try ActionAppIdentityBridge.actionRef(resolved.sectionLocator),
            focusLocator: try resolved.focusLocator.map(ActionAppIdentityBridge.actionRef),
            presentationMode: request.newTab ? .newTab : .sameTab)
        let intent = PublicNavigationSpecV2(destination: UIDestinationID(rawValue: "native.reader")!,
            backend: invocation.snapshot.backend, content: content,
            presentation: request.newTab ? .newTab : .currentTab)
        var execution: NativeHistoryReaderIntentService.Execution?
        var repeatedReport = false
        do {
            // No await separates the frozen original window check above from
            // the existing public binder's retained Reader/mapping reservation.
            let acknowledgement = try await open(public: intent, sceneID: window.sceneID,
                managerID: original.managerID, expectedSnapshot: invocation.snapshot, origin: .appIntent,
                until: invocation.deadlineUptimeNanoseconds, requestID: invocation.requestId,
                historySource: source, didObserveReader: { core, receipt in
                    if execution != nil { repeatedReport = true; return }
                    execution = .init(coreResult: core, acknowledgement: nil, nativeReceipt: receipt)
                })
            // Only the existing binder's actual returned acknowledgement is
            // authoritative. A pending native receipt alone cannot become ACK.
            execution = .init(coreResult: execution?.coreResult, acknowledgement: acknowledgement,
                nativeReceipt: execution?.nativeReceipt)
            guard let actual = execution, !repeatedReport else {
                throw UIRouteError(.failed, "native_effect_uncertain")
            }
            if case .acknowledged(let receipt) = acknowledgement {
                guard source.didApply, let current = scenes[window.sceneID],
                      current.session === original.session, current.manager === manager,
                      current.managerID == original.managerID,
                      try backend.currentBackendSnapshot() == invocation.snapshot else {
                    throw UIRouteError(.staleState, "history_reader_completion_owner_changed")
                }
                // The original Reader/TextKit witness must belong to this
                // exact request; a visible unrelated Reader is not evidence.
                try current.session.validateCompletedJourneySurface(receipt)
            }
            return actual
        } catch {
            if let execution {
                throw NativeHistoryReaderIntentService.Failure(execution: execution, underlying: error)
            }
            throw error
        }
    }
'''
replace(composition,"    private func openReaderIntent(_ request: NativeReaderIntentService.OpenRequest) async throws -> UISceneAcknowledgement {\n",
        entry+"\n    private func openReaderIntent(_ request: NativeReaderIntentService.OpenRequest) async throws -> UISceneAcknowledgement {\n")
replace(composition,"""        AppDependencyManager.shared.add(dependency: historyService)
        let readerService = NativeReaderIntentService(execute: { [self] in
""","""        AppDependencyManager.shared.add(dependency: historyService)
        let historyReaderService = NativeHistoryReaderIntentService(snapshot: { [self] in
            try backend.currentBackendSnapshot()
        }, catalog: { [self] in
            try originalHistoryReaderCatalog().records($0)
        }, windows: { [self] in
            try intentRootEntities()
        }, navigate: { [self] in
            do { return try await openHistoryReading($0) }
            catch { logIntentFailure(error, stage: "history_reader"); throw error }
        })
        AppDependencyManager.shared.add(dependency: historyReaderService)
        let readerService = NativeReaderIntentService(execute: { [self] in
""")

for path,text in files.items():
 restored=text
 for edit in reversed([e for e in edits if e["path"]==path]):
  assert restored.count(edit["new"])==1
  restored=restored.replace(edit["new"],edit["old"])
 assert restored.encode()==(base/path).read_bytes()
for path,text in files.items():(candidate/path).write_text(text)
(root/"EXACT_WIRING_EDITS.json").write_text(json.dumps(edits,indent=2)+"\n")
print(json.dumps({"edits":len(edits),"inverseReconstructsEveryBaseline":True,"files":[{"path":p,"bytes":len(t.encode()),"sha256":hashlib.sha256(t.encode()).hexdigest()} for p,t in files.items()]}))
