import base64,gzip,hashlib,json,os,pathlib,subprocess,time,traceback,signal
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
PARENT=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-reader-controls-20261127')
OWN=PARENT/'source-attempt-1'
CORE=ROOT/'.git/search-continuation-integrated-controls-20261127/output'
HOST=PARENT/'output'
SWIFTC=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.run(['git','-C',str(ROOT),*args],capture_output=True,check=True).stdout
def free(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize
def size():return sum(p.stat().st_blocks*512 for p in OWN.rglob('*') if p.is_file())
def save(name,obj):(OWN/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
steps=[]
def run(name,argv,allowed=(0,)):
 assert free(OWN)>2147483648 and free(ROOT)>1342177280 and size()<268435456
 step={'name':name,'argv':list(map(str,argv)),'startedEpoch':time.time()};steps.append(step)
 with (OWN/(name+'.stdout')).open('wb') as out,(OWN/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(list(map(str,argv)),stdout=out,stderr=err,env={**os.environ,'TMPDIR':str(OWN/'tmp')},start_new_session=True)
  step['pid']=p.pid;step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21]
  deadline=time.time()+120
  while p.poll() is None:
   if time.time()>deadline or free(OWN)<2147483648 or free(ROOT)<1342177280 or size()>268435456:
    step['interrupted']='owned deadline/capacity guard';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
  step['exit']=p.returncode
 step['finishedEpoch']=time.time();step['logs']={s:{'bytes':(OWN/(name+s)).stat().st_size,'sha256':sha((OWN/(name+s)).read_bytes())}for s in ['.stdout','.stderr']}
 save('STATUS.json',{'steps':steps})
 if p.returncode not in allowed:raise RuntimeError(name+' failed, exit '+str(p.returncode))
OWN.mkdir(exist_ok=False)
for n in ['inputs','output','tmp','module-cache']:(OWN/n).mkdir()
try:
 assert git('rev-parse','HEAD:Source').decode().strip()=='23cdfce49553927656ef79c6db10f654c889e2fc'
 assert sha((PARENT/'RESULT.json').read_bytes())=='e547715ea4e70a8be52c63724be1acdc2c70e18fd8d8610be671b11d2b8c212e'
 raw=gzip.decompress(base64.b64decode(PAYLOAD_B64));assert sha(raw)==PAYLOAD_SHA;payload=json.loads(raw)
 files=[]
 def put(name,data,kind,source=None):
  p=OWN/'inputs'/name;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(data)
  files.append({'path':name,'bytes':len(data),'sha256':sha(data),'kind':kind,'source':source});return p
 for row in payload['files']:
  data=base64.b64decode(row['base64']);assert len(data)==row['bytes'] and sha(data)==row['sha256'];put(row['path'],data,'candidate/control as labeled')
 def actual(path,expected):
  data=git('show','HEAD:'+path);assert sha(data)==expected;return data
 modelpath='Source/LibraryBackend/LibraryBackendModels.swift'
 model=actual(modelpath,'b05a2e40eca5577441992d6fa1648ec7ae9ef617a23d52ef8a7f1e46e2c9d14d')
 marker=b'/// A navigable unit within a work, supplied by the backend provider.'
 assert model.count(marker)==1
 put('ActualLibraryIdentityTypes.swift',model.split(marker)[0],'unchanged exact original source prefix',{'path':modelpath,'sha256':sha(model)})
 fixed=payload['actualPins']
 all_original={p:actual(p,s)for p,s in fixed.items()}
 p='Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativeComponentBinding.swift';b=all_original[p]
 start=b'@MainActor final class MaktabahNativeComponentSourceObservation {';end=b'/// A passive view'
 assert b.count(start)==1 and b.count(end)==1
 put('ActualBackendPublicationObservation.swift',b'import Foundation\nimport OtzariaUIRouting\nimport ChavrusaUIRoutingHost\n'+start+b.split(start)[1].split(end)[0],'unchanged exact original class; Combine types explicitly substituted',{'path':p,'sha256':sha(b)})
 p='Source/Features/History/ViewModel/HistoryViewModel.swift';b=all_original[p]
 marker=b'/// Source-owned correlation between the actual original cards'
 assert b.count(marker)==1
 put('ActualHistoryQualifiedPublication.swift',b'import Foundation\n'+marker+b.split(marker)[1],'unchanged exact original class',{'path':p,'sha256':sha(b)})
 p='Source/Otzaria/Actions/Integration/ActionAppIdentityBridge.swift';b=all_original[p]
 marker=b'struct ActionAppCatalogSnapshot: Sendable {';assert b.count(marker)==1
 put('ActualActionAppIdentityBridge.swift',b.split(marker)[0],'unchanged exact original identity bridge prefix',{'path':p,'sha256':sha(b)})
 for p in ['Source/Features/History/Models/ReadingEntry.swift','Source/ChavrusaText/Navigation/ReaderDestinationResolver.swift']:
  put(pathlib.Path(p).name,all_original[p],'unchanged full original source',{'path':p,'sha256':sha(all_original[p])})
 p='Source/LibraryBackend/QualifiedLocatorStore.swift';b=all_original[p]
 accessor=b'\n// TEST-ONLY token publication controls; never part of app source.\nextension QualifiedLocatorStore.PublicationSource {\n    func controlCapture() -> Observation? { capture() }\n    func controlAdvance() { willChange() }\n}\n'
 put('ActualQualifiedLocatorStore.swift',b+accessor,'unchanged full source plus explicit additive test-only token accessor',{'path':p,'sha256':sha(b),'accessorSha256':sha(accessor)})
 for name in ['candidate','initial']:
  p=OWN/'inputs'/name/'MaktabahNativeHistoryReaderSource.swift';b=p.read_bytes()
  assert b.startswith(b'#if os(iOS)\n') and b.rstrip().endswith(b'#endif')
  body=b[len(b'#if os(iOS)\n'):].rstrip()[:-len(b'#endif')]
  put(name+'/EnabledHistoryReaderSource.swift',body,'exact production body; only outer os(iOS) guard removed for declared fixtures',{'sha256':sha(b)})
 save('INPUTS.json',{'files':files,'rootSourceTree':git('rev-parse','HEAD:Source').decode().strip(),'reusedActualPortableProducts':str(HOST),'reusedProductsResultSha256':sha((PARENT/'RESULT.json').read_bytes()),'noNative':True})
 common=[p for p in (OWN/'inputs').glob('*.swift')]
 flags=[SWIFTC,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',OWN/'module-cache','-I',CORE,'-L',CORE,'-lOtzariaActionCore','-I',HOST,'-L',HOST,'-lOtzariaUIRouting','-lChavrusaUIRoutingHost','-Xlinker','-rpath','-Xlinker',CORE,'-Xlinker','-rpath','-Xlinker',HOST]
 for name in ['initial','candidate']:
  run('compile-'+name,flags+common+[OWN/'inputs'/name/'EnabledHistoryReaderSource.swift','-o',OWN/'output'/name])
  run('run-'+name,[OWN/'output'/name],allowed=(0,1) if name=='initial' else (0,))
 before=json.loads((OWN/'run-initial.stdout').read_text());after=json.loads((OWN/'run-candidate.stdout').read_text())
 assert after['failed']==0
 regressions=['metadata query reentry is rejected before source capture','backend publisher invalidates even when all final values match','claimed source refuses operation reentry from a live validator','retirement inside original operation cannot be overwritten by applied phase','publication detached during another record claim cannot return a new source']
 by_name={r['name']:r['pass']for r in before['cases']};assert all(by_name[n] is False for n in regressions)
 save('RESULT.json',{'status':'PASSED_ACTUAL_SOURCE_CONTROLS_WITH_DECLARED_APP_BOUNDARIES','steps':steps,'initial':before,'candidate':after,'expectedCounterexamples':regressions,'nativeRuns':0,'AppleSDK':'NOT_RUN','ownedAllocatedBytes':size()})
except BaseException as error:
 save('RESULT.json',{'status':'FAILED','steps':steps,'error':repr(error),'traceback':traceback.format_exc(),'nativeRuns':0,'AppleSDK':'NOT_RUN','ownedAllocatedBytes':size()});raise
finally:
 p=OWN/'RESULT.json'
 if p.exists():
  r=json.loads(p.read_text());print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'status':r.get('status'),'steps':[{'name':s['name'],'exit':s.get('exit')}for s in steps],'candidate':{k:r.get('candidate',{}).get(k)for k in ['passed','failed']},'initial':{k:r.get('initial',{}).get(k)for k in ['passed','failed']}}))
