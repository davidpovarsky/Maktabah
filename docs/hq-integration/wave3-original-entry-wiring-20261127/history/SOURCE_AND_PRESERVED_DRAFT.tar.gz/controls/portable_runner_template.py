import base64,gzip,hashlib,json,os,pathlib,subprocess,time,traceback,signal

# The outer launch runs this body as the existing ubuntu project owner. No
# source checkout, shared cache, package or toolchain is mutated.
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
OWN=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-history-reader-controls-20261127')
CACHE=ROOT/'.git/search-continuation-integrated-controls-20261127'
SWIFTC=pathlib.Path('/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc')
CAP=256*1024*1024
DATA_FLOOR=2*1024*1024*1024
ROOT_FLOOR=1342177280
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.run(['git','-C',str(ROOT),*args],capture_output=True,check=True).stdout
def free(path):
 s=os.statvfs(path);return s.f_bavail*s.f_frsize
def size():return sum(p.stat().st_blocks*512 for p in OWN.rglob('*') if p.is_file())
def save(name,obj):(OWN/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
steps=[]
def run(name,argv,timeout=150):
 assert free(OWN)>=DATA_FLOOR and free(ROOT)>=ROOT_FLOOR and size()<CAP
 start=time.time(); step={'name':name,'argv':list(map(str,argv)),'startedEpoch':start}
 steps.append(step);save('STATUS.json',{'steps':steps,'state':'running'})
 with (OWN/(name+'.stdout')).open('wb') as out,(OWN/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(list(map(str,argv)),stdout=out,stderr=err,env={**os.environ,'TMPDIR':str(OWN/'tmp')},start_new_session=True)
  step['pid']=p.pid;step['startTicks']=pathlib.Path('/proc/'+str(p.pid)+'/stat').read_text().split()[21]
  deadline=start+timeout
  while p.poll() is None:
   if time.time()>deadline or free(OWN)<DATA_FLOOR or free(ROOT)<ROOT_FLOOR or size()>CAP:
    step['interrupted']='owned deadline/capacity guard'
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.5)
  step['exit']=p.returncode
 step['finishedEpoch']=time.time();step['ownedAllocatedBytes']=size()
 step['logs']={s:{'bytes':(OWN/(name+s)).stat().st_size,'sha256':sha((OWN/(name+s)).read_bytes())} for s in ['.stdout','.stderr']}
 save('STATUS.json',{'steps':steps,'state':'running'})
 if p.returncode:raise RuntimeError(name+' failed, exit '+str(p.returncode))

OWN.mkdir(exist_ok=False)
for d in ['inputs','output','module-cache','tmp']:(OWN/d).mkdir()
try:
 assert git('rev-parse','HEAD:Source').decode().strip()=='23cdfce49553927656ef79c6db10f654c889e2fc'
 assert sha((CACHE/'RESULT.json').read_bytes())=='adade63bed54c1b527e41d0d68f81ac652c6916d878235d82081c20f0f942d96'
 assert sha(SWIFTC.read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 reused=json.loads((CACHE/'INPUTS.json').read_text())
 core=[r for r in reused['files'] if r['path'].startswith('Source/Otzaria/Actions/Sources/OtzariaActionCore/')]
 assert len(core)==31
 for row in core:
  data=git('show','HEAD:'+row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
  assert (CACHE/'inputs'/row['path']).read_bytes()==data
 accessor=CACHE/'inputs/original-generated-resource_bundle_accessor.swift'
 assert sha(accessor.read_bytes())==reused['resourceAccessor']['sha256']
 copied=[]
 for item in ['OtzariaActionCore.swiftmodule','libOtzariaActionCore.so']:
  p=CACHE/'output'/item;copied.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'use':'readonly existing validated actual Core product'})
 data=gzip.decompress(base64.b64decode(PAYLOAD_B64));assert sha(data)==PAYLOAD_SHA
 payload=json.loads(data)
 inputs=[]
 def put(path,b,kind):
  p=OWN/'inputs'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  inputs.append({'path':path,'bytes':len(b),'sha256':sha(b),'kind':kind});return p
 for row in payload['files']:
  b=base64.b64decode(row['base64']);assert len(b)==row['bytes'] and sha(b)==row['sha256'];put(row['path'],b,'candidate/control as labeled by path')
 edits=payload['wiringEdits']
 for path,expected in payload['baselinePins'].items():
  b=git('show','HEAD:'+path);assert sha(b)==expected;text=b.decode()
  own_edits=[e for e in edits if e['path']==path]
  for edit in own_edits:
   assert text.count(edit['old'])==1;text=text.replace(edit['old'],edit['new'])
  restored=text
  for edit in reversed(own_edits):
   assert restored.count(edit['new'])==1;restored=restored.replace(edit['new'],edit['old'])
  assert restored.encode()==b
  put(path,text.encode(),'exact additive source hunks; inverse equals current Git')
 paths=git('ls-tree','-r','--name-only','HEAD','Source/Otzaria/UIRouting/Sources/OtzariaUIRouting').decode().splitlines()
 ui=[]
 for path in paths:
  if path.endswith('.swift'):ui.append(put(path,git('show','HEAD:'+path),'unchanged actual UIRouting source'))
 assert len(ui)==13
 host=[]
 hostroot='Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost/'
 for name in ['NativeIntentService.swift','NativeIntentOutcome.swift','NativeComponentSourceObservation.swift']:
  path=hostroot+name;host.append(put(path,git('show','HEAD:'+path),'unchanged actual Host dependency'))
 host.append(OWN/'inputs'/hostroot/'NativeHistoryReaderIntentService.swift')
 save('INPUTS.json',{'head':git('rev-parse','HEAD').decode().strip(),'sourceTree':git('rev-parse','HEAD:Source').decode().strip(),'files':inputs,'coreSourcesRejoined':core,'reusedProducts':copied,'actualGeneratedAccessorSHA256':sha(accessor.read_bytes()),'scope':'Actual portable source compilation and service controls, source syntax only for Apple integration; no app/Core execution or native qualification'})
 base=[SWIFTC,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',OWN/'module-cache']
 link=['-I',CACHE/'output','-L',CACHE/'output','-lOtzariaActionCore','-Xlinker','-rpath','-Xlinker',CACHE/'output']
 run('compile-actual-ui-routing',base+link+['-emit-module','-emit-library','-module-name','OtzariaUIRouting','-emit-module-path',OWN/'output/OtzariaUIRouting.swiftmodule','-o',OWN/'output/libOtzariaUIRouting.so']+ui)
 hostlink=link+['-I',OWN/'output','-L',OWN/'output','-lOtzariaUIRouting','-Xlinker','-rpath','-Xlinker',OWN/'output']
 run('compile-actual-history-service',base+hostlink+['-emit-module','-emit-library','-module-name','ChavrusaUIRoutingHost','-emit-module-path',OWN/'output/ChavrusaUIRoutingHost.swiftmodule','-o',OWN/'output/libChavrusaUIRoutingHost.so']+host)
 run('compile-service-controls',base+hostlink+['-lChavrusaUIRoutingHost',OWN/'inputs/controls/HistoryReaderServiceControls.swift','-o',OWN/'output/history-service-controls'])
 run('run-service-controls',[OWN/'output/history-service-controls'],30)
 native=[OWN/'inputs'/r['path'] for r in inputs if r['path'].endswith('.swift') and (r['path'].startswith('Source/ChavrusaText/UIRoutingHost/Integration/') or r['path'].endswith('NativeHistoryReaderIntents.swift'))]
 run('parse-apple-integration-only',[SWIFTC,'-frontend','-parse','-target','arm64-apple-ios26.0-simulator']+native)
 report=json.loads((OWN/'run-service-controls.stdout').read_text());assert report['failed']==0
 save('RESULT.json',{'status':'PASSED_PORTABLE_SERVICE_CONTROLS_AND_APP_SYNTAX_ONLY','steps':steps,'verdict':report,'nativeRuns':0,'CoreExecution':'NOT_RUN','AppleSDK':'NOT_RUN','ownedAllocatedBytes':size(),'rootFree':free(ROOT),'dataFree':free(OWN)})
except BaseException as error:
 save('RESULT.json',{'status':'FAILED','steps':steps,'error':repr(error),'traceback':traceback.format_exc(),'nativeRuns':0,'AppleSDK':'NOT_RUN','ownedAllocatedBytes':size()})
 raise
finally:
 p=OWN/'RESULT.json'
 if p.exists():print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'status':json.loads(p.read_text()).get('status'),'steps':[{'name':s['name'],'exit':s.get('exit')}for s in steps]}))
