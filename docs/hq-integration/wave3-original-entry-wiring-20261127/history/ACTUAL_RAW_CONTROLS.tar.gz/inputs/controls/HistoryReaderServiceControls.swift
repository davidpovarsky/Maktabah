import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

// Actual portable production service and real Core/UIRouting value contracts.
// Navigation, clocks and app metadata are explicit test boundaries. This file
// does not launch an app, invoke Siri, execute Core or count a native UI pass.
struct ControlFailure: Error { let message: String }
@MainActor func require(_ condition: @autoclosure () -> Bool, _ message: String) throws {
    if !condition() { throw ControlFailure(message: message) }
}
@MainActor func refuses(_ operation: () async throws -> Void) async throws {
    do { try await operation() }
    catch is ControlFailure { throw ControlFailure(message: "control assertion failed inside refusal") }
    catch { return }
    throw ControlFailure(message: "expected refusal")
}

@MainActor final class Fixture {
    typealias Service = NativeHistoryReaderIntentService
    var snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 7)
    var ticks: UInt64 = 1_000
    var records: [Service.Record] = []
    var windows: [NativeIntentService.Destination] = []
    var navigations = 0
    var catalogReads = 0
    var afterCatalog: (() -> Void)?
    var afterNavigation: (() -> Void)?
    var result: Service.Execution?
    var request: Service.OpenRequest?
    var mode = "ok"
    init(backend: ActionBackendID = .otzaria) {
        snapshot = .init(backend: backend, generation: 7)
        let locator = ActionTextRef(backend: backend, workKey: backend == .otzaria ? "book:42" : "Genesis",
            position: backend == .otzaria ? .legacyLine(37) : .canonicalRef("Genesis 1:3"))
        records = [.init(reference: .init(backend: backend, metadataID: UUID()),
            title: "בראשית — Original title", locator: locator)]
        windows = [.init(backend: backend, destination: UIDestinationID(rawValue: "native.library")!,
            title: "Library window", sceneID: UIStableID(rawValue: "original-window")!)]
    }
    func service() -> Service {
        Service(snapshot: { self.snapshot }, catalog: { _ in
            self.catalogReads += 1
            let value = self.records; self.afterCatalog?(); return value
        }, windows: { self.windows }, navigate: { request in
            self.navigations += 1; self.request = request
            let value = self.execution(request)
            self.result = value; self.afterNavigation?()
            if self.mode == "throw-after-effect" {
                throw Service.Failure(execution: value, underlying: UIRouteError(.staleState, "actual_late_refusal"))
            }
            return value
        }, now: { self.ticks })
    }
    func execution(_ request: Service.OpenRequest) -> Service.Execution {
        let id = request.invocation.requestId
        let scene = request.window.sceneID
        let original = request.invocation.snapshot
        let content = ActionReaderDestination(sectionLocator: request.record.locator,
            focusLocator: request.record.locator, presentationMode: request.newTab ? .newTab : .sameTab)
        let wrongContent = ActionReaderDestination(sectionLocator: .init(backend: original.backend,
            workKey: "foreign-work", position: .legacyLine(4)), presentationMode: .sameTab)
        let destination = mode == "wrong-locator" ? wrongContent : content
        let route = RouteSpec(requestId: mode == "wrong-route-request" ? UUID() : id,
            destination: UIDestinationID(rawValue: mode == "wrong-route" ? "native.history" : "native.reader")!,
            backend: original.backend, content: destination,
            presentation: .init(kind: request.newTab ? .newTab : .currentTab),
            scene: .init(kind: .specific, sceneID: scene, expectedRevision: 10),
            expectedBackendSnapshot: original)
        let native = ActionUIReceipt(requestId: mode == "wrong-native-request" ? UUID() : id,
            snapshot: original, sceneID: scene.rawValue, destination: destination)
        let receipt = UISceneReceipt(requestId: id, route: route, backendSnapshot: original,
            sceneID: mode == "wrong-window" ? UIStableID(rawValue: "foreign-window")! : scene,
            basedOnSceneRevision: 10, appliedSceneRevision: mode == "no-revision" ? 10 : 11,
            coreReceipt: mode == "missing-native-receipt" ? nil : native)
        let command = ActionRequest(requestId: mode == "wrong-core-request" ? UUID() : id,
            action: mode == "wrong-core-action" ? "search.query" : "reader.open")
        let core = ActionResult(request: command, status: mode == "core-failed" ? .failed : .completed,
            backend: original.backend, backendGeneration: original.generation, effects: ["fixture-original-reader"])
        let ack: UISceneAcknowledgement?
        if mode == "no-ack" { ack = nil }
        else if mode == "refused-with-receipt" { ack = .staleState(.init(code: "original_refusal", message: "fixture")) }
        else { ack = .acknowledged(receipt) }
        return .init(coreResult: mode == "missing-core" ? nil : core, acknowledgement: ack,
            nativeReceipt: receipt)
    }
    func open(_ service: Service, newTab: Bool = true) async throws -> Service.Execution {
        try await service.open(identifier: records[0].id, windowIdentifier: windows[0].id, newTab: newTab)
    }
}

@main struct Controls {
    @MainActor static func main() async {
        var cases: [[String: Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            do { try await body(); cases.append(["name": name, "pass": true]) }
            catch { cases.append(["name": name, "pass": false, "error": String(describing: error)]) }
        }
        for backend in ActionBackendID.allCases {
            for newTab in [false, true] {
                await run("exact remembered \(backend.rawValue) position in \(newTab ? "new" : "current") tab") {
                    let f = Fixture(backend: backend), s = f.service()
                    let value = try await f.open(s, newTab: newTab)
                    try NativeIntentOutcome.requireVisibleAcknowledgement(value.acknowledgement!)
                    try require(f.navigations == 1 && f.request?.newTab == newTab, "one selected native request")
                    try require(f.request?.invocation.deadlineUptimeNanoseconds == 5_000_001_000, "one original deadline")
                    try require(value.coreResult == f.result?.coreResult && value.nativeReceipt == f.result?.nativeReceipt, "actual returns preserved")
                }
            }
        }
        await run("metadata discovery reads no navigation and IDs contain no private locator") {
            let f = Fixture(), s = f.service()
            let rows = try s.records(matching: "בראשית")
            let windows = try s.windows()
            try require(rows.count == 1 && windows.count == 1 && f.navigations == 0, "metadata only")
            let reference = try NativeHistoryReaderIntentService.Reference(identifier: rows[0].id)
            try require(reference == rows[0].reference, "canonical opaque reference")
            try require(!rows[0].id.contains("book:") && !rows[0].id.contains("בראשית") && !rows[0].id.contains("original-window"), "no locator/title/window in metadata ID")
        }
        await run("noncanonical and foreign-shaped references refuse before navigation") {
            let f = Fixture(), s = f.service(), id = f.records[0].id
            for bad in [id.uppercased(), id + ".extra", id + "?line=9", "maktabah.history.v1.otzaria." + UUID().uuidString, "x", String(repeating: "x", count: 161)] {
                try await refuses { _ = try await s.open(identifier: bad, windowIdentifier: f.windows[0].id, newTab: true) }
            }
            try require(f.navigations == 0, "invalid references did not navigate")
        }
        await run("retired opaque metadata cannot select another current row") {
            let f = Fixture(), s = f.service(), old = f.records[0]
            f.records = [.init(reference: .init(backend: .otzaria, metadataID: UUID()), title: old.title, locator: old.locator)]
            try await refuses { _ = try await s.open(identifier: old.id, windowIdentifier: f.windows[0].id, newTab: true) }
            try require(f.navigations == 0, "retired reference refused")
        }
        await run("backend mismatch refuses without metadata or navigation") {
            let f = Fixture(), s = f.service()
            f.snapshot = .init(backend: .sefaria, generation: 8)
            try await refuses { _ = try await f.open(s) }
            try require(f.catalogReads == 0 && f.navigations == 0, "no cross-backend discovery or execution")
        }
        await run("backend generation changing during catalog reads refuses before navigation") {
            let f = Fixture(), s = f.service()
            f.afterCatalog = { f.snapshot = .init(backend: .otzaria, generation: 8) }
            try await refuses { _ = try await f.open(s) }
            try require(f.navigations == 0, "stale metadata refused")
        }
        await run("ambiguous catalog is rejected") {
            let f = Fixture(), s = f.service(); f.records += f.records
            try await refuses { _ = try s.records() }
            try require(f.navigations == 0, "no ambiguous execution")
        }
        await run("ambiguous window is rejected") {
            let f = Fixture(), s = f.service(); f.windows += f.windows
            try await refuses { _ = try await f.open(s) }
            try require(f.navigations == 0, "no ambiguous window execution")
        }
        await run("history component is not a generic Reader window") {
            let f = Fixture(), s = f.service(), window = f.windows[0]
            f.windows = [.init(backend: .otzaria, destination: .init(rawValue: "native.history")!, title: window.title, sceneID: window.sceneID)]
            try await refuses { _ = try await f.open(s) }
            try require(f.navigations == 0, "wrong original root refused")
        }
        await run("bounded discovery and input limits") {
            let f = Fixture(), s = f.service(), old = f.records[0]
            f.records = (0..<100).map { _ in .init(reference: .init(backend: .otzaria, metadataID: UUID()), title: old.title, locator: old.locator) }
            let rows = try s.records(); try require(rows.count == 64, "bounded suggestions")
            try await refuses { _ = try s.records(identifiers: Array(repeating: old.id, count: 65)) }
            try await refuses { _ = try s.records(matching: String(repeating: "א", count: 257)) }
            f.records = (0..<501).map { _ in .init(reference: .init(backend: .otzaria, metadataID: UUID()), title: old.title, locator: old.locator) }
            try await refuses { _ = try s.records() }
        }
        await run("a real refusal with pending receipt remains refusal") {
            let f = Fixture(), s = f.service(); f.mode = "refused-with-receipt"
            let value = try await f.open(s)
            try require(value.acknowledgement == f.result?.acknowledgement && value.nativeReceipt != nil, "preserved separate refusal and receipt")
            try await refuses { try NativeIntentOutcome.requireVisibleAcknowledgement(value.acknowledgement!) }
        }
        await run("late host failure retains actual original returns") {
            let f = Fixture(), s = f.service(); f.mode = "throw-after-effect"
            do { _ = try await f.open(s); throw ControlFailure(message: "late failure lost") }
            catch let failure as NativeHistoryReaderIntentService.Failure {
                try require(failure.execution.coreResult == f.result?.coreResult && failure.execution.nativeReceipt == f.result?.nativeReceipt, "actual values retained")
                try require(failure.code == "actual_late_refusal", "original refusal code retained")
            }
        }
        for mode in ["no-ack", "wrong-locator", "wrong-route-request", "wrong-route", "wrong-native-request", "wrong-window", "no-revision", "missing-native-receipt", "wrong-core-request", "wrong-core-action", "core-failed", "missing-core"] {
            await run("refuse incomplete or mismatched completion: \(mode)") {
                let f = Fixture(), s = f.service(); f.mode = mode
                do { _ = try await f.open(s); throw ControlFailure(message: "incomplete completion accepted") }
                catch let failure as NativeHistoryReaderIntentService.Failure {
                    try require(failure.execution.coreResult == f.result?.coreResult && failure.execution.acknowledgement == f.result?.acknowledgement && failure.execution.nativeReceipt == f.result?.nativeReceipt, "raw actual evidence retained")
                }
            }
        }
        await run("generation change after effect retains actual evidence and refuses") {
            let f = Fixture(), s = f.service()
            f.afterNavigation = { f.snapshot = .init(backend: .otzaria, generation: 8) }
            do { _ = try await f.open(s); throw ControlFailure(message: "late generation accepted") }
            catch let failure as NativeHistoryReaderIntentService.Failure {
                try require(failure.status == .staleState && failure.execution.coreResult == f.result?.coreResult && f.navigations == 1, "late stale result retained")
            }
        }
        await run("deadline overflow refuses without navigation") {
            let f = Fixture(), s = f.service(); f.ticks = UInt64.max
            try await refuses { _ = try await f.open(s) }
            try require(f.navigations == 0 && f.catalogReads == 0, "overflow refused before discovery")
        }
        await run("original deadline is not renewed after effects") {
            let f = Fixture(), s = f.service()
            f.afterNavigation = { f.ticks = 5_000_001_000 }
            do { _ = try await f.open(s); throw ControlFailure(message: "late deadline accepted") }
            catch let failure as NativeHistoryReaderIntentService.Failure {
                try require(failure.execution.nativeReceipt == f.result?.nativeReceipt && f.navigations == 1, "late receipt preserved")
            }
        }
        await run("actual task cancellation refuses before metadata and navigation") {
            let f = Fixture(), s = f.service()
            let task = Task { @MainActor in try await f.open(s) }
            task.cancel()
            try await refuses { _ = try await task.value }
            try require(f.navigations == 0 && f.catalogReads == 0, "cancelled request did not execute")
        }
        let failed = cases.filter { ($0["pass"] as? Bool) != true }.count
        let report: [String: Any] = ["scope": "Actual History Reader portable service; original Core and UIRouting values; synthetic metadata, clock and navigation only", "cases": cases, "passed": cases.count - failed, "failed": failed, "nativeRuns": 0, "AppleSDK": "NOT_RUN", "CoreExecution": "NOT_RUN"]
        let bytes = try! JSONSerialization.data(withJSONObject: report, options: [.sortedKeys])
        print(String(decoding: bytes, as: UTF8.self))
        if failed > 0 { exit(1) }
    }
}
