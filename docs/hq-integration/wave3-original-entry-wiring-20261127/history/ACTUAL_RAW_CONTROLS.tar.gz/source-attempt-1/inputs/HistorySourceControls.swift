import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

@main struct SourceControls {
    @MainActor static func main() async {
        var cases: [[String: Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            do { try await body(); cases.append(["name": name, "pass": true]) }
            catch { cases.append(["name": name, "pass": false, "error": String(describing: error)]) }
        }
        await run("original numeric saved position remains exact without opening a book") {
            let f = SourceFixture(), rows = try f.records()
            try insist(rows.count == 1 && rows[0].locator.position == .legacyLine(37) && rows[0].locator.workKey == "book:42", "actual saved ID retained")
            try insist(OtzariaMaktabahBridge.shared.readCount == 1, "read-only original work qualification")
            let source = try await f.retain(); var effects = 0
            try source.performOriginalApply { effects += 1 }
            try insist(effects == 1 && source.didApply, "one authorized-operation boundary")
            try sourceRefuses { try source.performOriginalApply { effects += 1 } }
            try insist(effects == 1, "no replay")
        }
        await run("missing remembered position does not fall back to first line") {
            let f = SourceFixture(); HistoryViewModel.shared.entriesByBookId[42]?.lastContentId = nil
            let rows = try f.records(); try insist(rows.isEmpty, "missing position unavailable")
        }
        await run("unregistered negative original ID is refused") {
            let f = SourceFixture(); HistoryViewModel.shared.entriesByBookId[42]?.lastContentId = -4
            try sourceRefuses { _ = try f.records() }
        }
        await run("registered own saved legacy ID keeps its original exact locator") {
            let f = SourceFixture(); HistoryViewModel.shared.entriesByBookId[42]?.lastContentId = -4
            LegacyIdentityRegistry.shared.known[-4] = .init(backend: .otzaria, workKey: "book:42", position: .legacyLine(71))
            let rows = try f.records(); try insist(rows[0].locator.position == .legacyLine(71), "registered original position")
        }
        for foreign in [TextLocator(backend: .otzaria, workKey: "book:99", position: .legacyLine(7)), TextLocator(backend: .sefaria, workKey: "book:42", position: .canonicalRef("Genesis 1"))] {
            await run("original resolver refuses foreign saved identity \(foreign.backend.rawValue) \(foreign.workKey)") {
                let f = SourceFixture(); HistoryViewModel.shared.entriesByBookId[42]?.lastContentId = -4
                LegacyIdentityRegistry.shared.known[-4] = foreign
                try sourceRefuses { _ = try f.records() }
            }
        }
        await run("query ABA cannot revive retained original History publication") {
            let f = SourceFixture(), source = try await f.retain(), model = HistoryViewModel.shared
            model.searchText = "other"; model.searchText = ""
            try sourceRefuses { try source.validate() }
            var effects = 0; try sourceRefuses { try source.performOriginalApply { effects += 1 } }
            try insist(effects == 0, "ABA refused before native boundary")
        }
        await run("remembered position ABA cannot revive retained source") {
            let f = SourceFixture(), source = try await f.retain(), model = HistoryViewModel.shared
            model.entriesByBookId[42]?.lastContentId = 50; model.entriesByBookId[42]?.lastContentId = 37
            try sourceRefuses { try source.validate() }
        }
        await run("equal original book values on a replacement object are not the same source") {
            let f = SourceFixture(), source = try await f.retain(), model = HistoryViewModel.shared
            model.historyBooks = [BooksData(id: 42, book: "Original book 0")]
            try sourceRefuses { try source.validate() }
        }
        await run("backend publisher invalidates even when all final values match") {
            let f = SourceFixture(), source = try await f.retain()
            BackendCoordinator.shared.objectWillChange.send()
            try sourceRefuses { try source.validate() }
        }
        await run("retained exact legacy ID mapping must still match before apply") {
            let f = SourceFixture(), source = try await f.retain()
            LegacyIdentityRegistry.shared.known[37] = .init(backend: .otzaria, workKey: "book:99", position: .legacyLine(37))
            try sourceRefuses { try source.validate() }
        }
        await run("metadata query reentry is rejected before source capture") {
            let f = SourceFixture(); var reentryRefused = false
            f.afterSnapshot = {
                f.afterSnapshot = nil
                do { _ = try f.records() } catch { reentryRefused = true }
            }
            let rows = try f.records()
            try insist(rows.count == 1 && reentryRefused, "no recursive source discovery")
        }
        await run("claimed source refuses operation reentry from a live validator") {
            let f = SourceFixture(), source = try await f.retain(); var reentryRefused = false, effects = 0
            f.afterSnapshot = {
                f.afterSnapshot = nil
                do { try source.performOriginalApply { effects += 1 } } catch { reentryRefused = true }
            }
            try source.performOriginalApply { effects += 1 }
            try insist(reentryRefused && effects == 1 && source.didApply, "claimed before live callbacks")
        }
        await run("retirement inside source validation prevents original effect") {
            let f = SourceFixture(), source = try await f.retain(); var effects = 0
            f.afterSnapshot = { f.afterSnapshot = nil; f.catalog.finish(source) }
            try sourceRefuses { try source.performOriginalApply { effects += 1 } }
            try insist(effects == 0 && !source.didApply, "retired claim refused")
        }
        await run("retirement inside original operation cannot be overwritten by applied phase") {
            let f = SourceFixture(), source = try await f.retain(); var effects = 0
            try sourceRefuses { try source.performOriginalApply { effects += 1; f.catalog.finish(source) } }
            try insist(effects == 1 && !source.didApply, "effect retained as refused completion")
            try sourceRefuses { try source.performOriginalApply { effects += 1 } }
            try insist(effects == 1, "retired source never rearmed")
        }
        await run("publication detached during another record claim cannot return a new source") {
            let f = SourceFixture(count: 2), first = try await f.retain()
            f.beforeRetain = {
                f.afterSnapshot = { f.afterSnapshot = nil; f.catalog.finish(first) }
            }
            do { _ = try await f.retain(); throw SourceControlFailure(message: "detached publication was returned") }
            catch is SourceControlFailure { throw SourceControlFailure(message: "detached publication was returned") }
            catch { }
        }
        await run("operation failure retires exactly once after its effect") {
            let f = SourceFixture(), source = try await f.retain(); var effects = 0
            try sourceRefuses { try source.performOriginalApply { effects += 1; throw ActionPortError.staleState } }
            try sourceRefuses { try source.performOriginalApply { effects += 1 } }
            try insist(effects == 1 && !source.didApply, "partial failure retained without replay")
        }
        await run("own synchronous History update after apply does not rearm source metadata") {
            let f = SourceFixture(), source = try await f.retain(), oldID = f.lastRequest!.record.id
            try source.performOriginalApply { HistoryViewModel.shared.entriesByBookId[42]?.lastContentId = 99 }
            try insist(source.didApply, "own original effect completed")
            try source.validate()
            f.catalog.finish(source)
            let rows = try f.records(); try insist(rows.first?.id != oldID && rows.first?.locator.position == .legacyLine(99), "fresh metadata after own effect")
        }
        for backend in [BackendID.sefaria, .sefariaEmbedded] {
            await run("qualified \(backend.rawValue) card retains actual saved locator and token") {
                let f = SourceFixture(backend: backend), token = f.qualify()
                let rows = try f.records(); try insist(rows.count == 1 && rows[0].locator.position == .canonicalRef("Genesis 1:3"), "qualified saved locator")
                let source = try await f.retain(); token.controlAdvance()
                try sourceRefuses { try source.validate() }
            }
        }
        await run("qualified store change during original apply refuses completion after effect") {
            let f = SourceFixture(backend: .sefaria), token = f.qualify(), source = try await f.retain(); var effects = 0
            try sourceRefuses { try source.performOriginalApply { effects += 1; token.controlAdvance() } }
            try insist(effects == 1 && !source.didApply, "original locked store token refuses late completion")
        }
        await run("actual task cancellation cannot claim the original operation") {
            let f = SourceFixture(), source = try await f.retain(); var effects = 0
            let task = Task { @MainActor in try source.performOriginalApply { effects += 1 } }
            task.cancel()
            do { try await task.value; throw SourceControlFailure(message: "cancelled operation applied") }
            catch is CancellationError { }
            try insist(effects == 0, "cancelled before original effect")
        }
        let failed = cases.filter { ($0["pass"] as? Bool) != true }.count
        let report: [String: Any] = ["scope": "Actual History publication/source + real Observation + unchanged original qualified token and Otzaria resolver; explicit app, database, legacy registry and Combine command-boundary fixtures", "cases": cases, "passed": cases.count - failed, "failed": failed, "nativeRuns": 0, "AppleSDK": "NOT_RUN", "SefariaCanonicalResolver": "NOT_RUN", "RealDatabase": "NOT_RUN", "Combine": "BOUNDARY_SUBSTITUTE"]
        print(String(decoding: try! JSONSerialization.data(withJSONObject: report, options: [.sortedKeys]), as: UTF8.self))
        if failed > 0 { exit(1) }
    }
}
