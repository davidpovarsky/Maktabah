import Foundation
import OtzariaActionCore

/// App-internal persistence types stay outside the portable package.
enum ActionAppIdentityBridge {
    static func actionBackend(_ value: BackendID) -> ActionBackendID {
        switch value { case .otzaria: .otzaria; case .sefaria: .sefaria; case .sefariaEmbedded: .sefariaEmbedded }
    }
    static func appBackend(_ value: ActionBackendID) -> BackendID {
        switch value { case .otzaria: .otzaria; case .sefaria: .sefaria; case .sefariaEmbedded: .sefariaEmbedded }
    }
    static func appPosition(_ value: ActionTextPosition) throws -> TextPosition {
        switch value {
        case .legacyLine(let line):
            guard line >= 0, let exact = Int(exactly: line) else { throw ActionPortError.invalidResponse }
            return .legacyLine(exact)
        case .canonicalRef(let ref):
            guard !ref.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, ref.count <= 1_000 else { throw ActionPortError.invalidResponse }
            return .canonicalRef(ref)
        }
    }
    static func actionPosition(_ value: TextPosition) throws -> ActionTextPosition {
        switch value {
        case .legacyLine(let line):
            guard line >= 0, let exact = Int64(exactly: line) else { throw ActionPortError.invalidResponse }
            return .legacyLine(exact)
        case .canonicalRef(let ref):
            guard !ref.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, ref.count <= 1_000 else { throw ActionPortError.invalidResponse }
            return .canonicalRef(ref)
        }
    }
    static func appLocator(_ ref: ActionTextRef) throws -> TextLocator {
        guard !ref.workKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, ref.workKey.count <= 512 else { throw ActionPortError.invalidResponse }
        // The old persistence format has no revision fields: never silently lose them.
        guard ref.catalogRevision == nil, ref.dataRevision == nil else { throw ActionPortError.notSupported }
        return TextLocator(backend: appBackend(ref.backend), workKey: ref.workKey, position: try appPosition(ref.position))
    }
    static func actionRef(_ locator: TextLocator) throws -> ActionTextRef {
        guard !locator.workKey.isEmpty else { throw ActionPortError.invalidResponse }
        return ActionTextRef(backend: actionBackend(locator.backend), workKey: locator.workKey,
                             position: try actionPosition(locator.position))
    }
    static func capabilityNames(_ value: BackendCapabilities) -> Set<String> {
        let fields: [(String, BackendCapabilities)] = [
            ("catalog", .catalog), ("reading", .reading), ("navigation", .navigation), ("search", .search),
            ("authors", .authors), ("links", .links), ("versions", .versions), ("offlineLibrary", .offlineLibrary),
            ("offlineSearch", .offlineSearch), ("workMetadata", .workMetadata)
        ]
        return Set(fields.compactMap { value.contains($0.1) ? $0.0 : nil })
    }
}

