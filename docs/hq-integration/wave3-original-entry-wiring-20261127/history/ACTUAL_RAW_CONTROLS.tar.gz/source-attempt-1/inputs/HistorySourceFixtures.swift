import Foundation
import Observation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

// Explicit Linux app/Combine boundary. The actual production publication,
// retained-source implementation, original qualified token, original legacy
// resolver and real Observation latch are compiled separately without edits.
// These fixtures are not UIKit, the real database, Combine, or a native run.
final class AnyCancellable: @unchecked Sendable {
    private let cancel: @Sendable () -> Void
    init(_ cancel: @escaping @Sendable () -> Void) { self.cancel = cancel }
    deinit { cancel() }
}
final class FixturePublisher: @unchecked Sendable {
    private let lock = NSLock()
    private var callbacks: [UUID: @Sendable (Int) -> Void] = [:]
    func sink(_ callback: @escaping @Sendable (Int) -> Void) -> AnyCancellable {
        let id = UUID(); lock.lock(); callbacks[id] = callback; lock.unlock()
        return AnyCancellable { [weak self] in
            guard let self else { return }; self.lock.lock(); self.callbacks.removeValue(forKey: id); self.lock.unlock()
        }
    }
    func send() {
        lock.lock(); let current = Array(callbacks.values); lock.unlock()
        current.forEach { $0(0) }
    }
}
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    // Deliberately NOT @Observable: the real backend publishes through Combine.
    let objectWillChange = FixturePublisher()
    var activeBackendID = BackendID.otzaria
    var generation: UInt64 = 7
    var activeTransitionToken: UInt64 = 2
    var isTransitioning = false
    var usesNativeMaktabahDataPath = true
}
@MainActor enum OtzariaBackendActivation { static var isActive = true }
final class BooksData {
    let id: Int
    let book: String
    var backendLocator: TextLocator?
    init(id: Int, book: String, backendLocator: TextLocator? = nil) {
        self.id = id; self.book = book; self.backendLocator = backendLocator
    }
}
@MainActor @Observable final class HistoryViewModel {
    static let shared = HistoryViewModel()
    var historyBooks: [BooksData] = []
    var favoriteBooks: [BooksData] = []
    var entriesByBookId: [Int: ReadingEntry] = [:]
    var historyOrder: [Int] = []
    var searchText = ""
    var qualifiedPublication: HistoryQualifiedPublication?
    var filteredHistory: [BooksData] {
        searchText.isEmpty ? historyBooks : historyBooks.filter { $0.book.localizedCaseInsensitiveContains(searchText) }
    }
}
@MainActor final class OtzariaMaktabahBridge {
    static let shared = OtzariaMaktabahBridge()
    var books: [Int: BooksData] = [:]
    var readCount = 0
    func resolveBook(stableKey: String, expectedBookId: Int) throws -> BooksData {
        readCount += 1
        guard stableKey == "book:\(expectedBookId)", let value = books[expectedBookId] else {
            throw ActionPortError.unavailable
        }
        return value
    }
}
@MainActor final class LegacyIdentityRegistry {
    static let shared = LegacyIdentityRegistry()
    var known: [Int: TextLocator] = [:]
    func locator(for id: Int) -> TextLocator? { known[id] }
}
enum SefariaRef {
    // Source controls exercise the original resolver's Otzaria branch only.
    // A use of this unexecuted platform dependency must fail, not infer a ref.
    static func canonicalInput(_ value: String) -> String { fatalError("Sefaria resolver outside these source controls") }
    static func sectionAncestors(of value: String) -> [String] { fatalError("Sefaria resolver outside these source controls") }
}

struct SourceControlFailure: Error { let message: String }
@MainActor func insist(_ condition: @autoclosure () -> Bool, _ message: String) throws {
    if !condition() { throw SourceControlFailure(message: message) }
}
@MainActor func sourceRefuses(_ body: () throws -> Void) throws {
    do { try body() }
    catch is SourceControlFailure { throw SourceControlFailure(message: "control assertion failed inside refusal") }
    catch { return }
    throw SourceControlFailure(message: "expected refusal")
}

@MainActor final class SourceFixture {
    typealias Service = NativeHistoryReaderIntentService
    var snapshot = ActionBackendSnapshot(backend: .otzaria, generation: 7)
    var afterSnapshot: (() -> Void)?
    var beforeRetain: (() -> Void)?
    var lastRequest: Service.OpenRequest?
    var retained: MaktabahNativeHistoryReaderSource?
    lazy var catalog = MaktabahNativeHistoryReaderCatalog { [unowned self] in
        let value = self.snapshot; self.afterSnapshot?(); return value
    }
    let window = NativeIntentService.Destination(backend: .otzaria,
        destination: .init(rawValue: "native.library")!, title: "Original window",
        sceneID: .init(rawValue: "source-window")!)
    var sourceWindow: NativeIntentService.Destination {
        .init(backend: snapshot.backend, destination: window.destination, title: window.title, sceneID: window.sceneID)
    }
    init(backend: BackendID = .otzaria, count: Int = 1) {
        let backendSource = BackendCoordinator.shared
        backendSource.objectWillChange.send()
        backendSource.activeBackendID = backend; backendSource.generation = 7
        backendSource.activeTransitionToken = 2; backendSource.isTransitioning = false
        backendSource.usesNativeMaktabahDataPath = backend == .otzaria
        snapshot = .init(backend: ActionAppIdentityBridge.actionBackend(backend), generation: 7)
        OtzariaBackendActivation.isActive = true
        let model = HistoryViewModel.shared
        model.qualifiedPublication = nil; model.searchText = ""; model.favoriteBooks = []
        model.historyBooks = (0..<count).map { BooksData(id: 42 + $0, book: "Original book \($0)") }
        model.historyOrder = model.historyBooks.map(\.id)
        model.entriesByBookId = Dictionary(uniqueKeysWithValues: model.historyBooks.map {
            ($0.id, ReadingEntry(bookId: $0.id, lastContentId: 37 + $0.id - 42, lastOpenedAt: Date()))
        })
        OtzariaMaktabahBridge.shared.books = Dictionary(uniqueKeysWithValues: model.historyBooks.map { ($0.id, $0) })
        OtzariaMaktabahBridge.shared.readCount = 0
        LegacyIdentityRegistry.shared.known = [:]
    }
    func records() throws -> [Service.Record] { try catalog.records(snapshot) }
    func retain(index: Int = 0) async throws -> MaktabahNativeHistoryReaderSource {
        let row = try records()[index]
        let service = Service(snapshot: { self.snapshot }, catalog: { try self.catalog.records($0) },
            windows: { [self.sourceWindow] }, navigate: { request in
                self.lastRequest = request; self.beforeRetain?()
                self.retained = try self.catalog.retain(request)
                return .init(coreResult: nil, acknowledgement: .unavailable(.init(code: "fixture_no_ui", message: "No native operation")))
            })
        _ = try await service.open(identifier: row.id, windowIdentifier: sourceWindow.id, newTab: true)
        return retained!
    }
    func qualify() -> QualifiedLocatorStore.PublicationSource {
        let model = HistoryViewModel.shared
        for book in model.historyBooks {
            book.backendLocator = .init(backend: BackendCoordinator.shared.activeBackendID,
                workKey: "Genesis", position: .canonicalRef("Genesis 1:3"))
        }
        let tokens = QualifiedLocatorStore.PublicationSource()
        let entries = model.historyBooks.map { QualifiedLocatorStore.HistoryEntry(locator: $0.backendLocator!, title: $0.book, lastOpened: Date(), isFavorite: false) }
        model.qualifiedPublication = HistoryQualifiedPublication(model: model, load: .init(revision: 1),
            entries: entries, observation: tokens.controlCapture()!)!
        return tokens
    }
}
