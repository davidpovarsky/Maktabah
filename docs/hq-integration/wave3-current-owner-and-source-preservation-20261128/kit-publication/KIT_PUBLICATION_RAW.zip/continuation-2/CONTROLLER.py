import os,sys,pathlib,stat,hashlib,json,zipfile,tarfile,io,subprocess,time,signal,pwd,difflib
if not __debug__: raise RuntimeError('Optimized Python refused')
BASE='26beca175d64a4d34e3567f2bbb4bf308d714478'
BRANCH='codex/otzaria-wave3-inspector-selection-qualified-20261128'
DONOR=pathlib.Path('/mnt/development/projects/worktrees/TorahInspectorKit-wave3-original-selection-20261127')
OBJECTS=DONOR/'.git/objects'
ROOT=pathlib.Path('/home/ubuntu/otzaria-wave3-inspector-kit-source-20261128')
REPO=ROOT/'repo'; EVIDENCE=ROOT/'continuation-2'
ZIP=pathlib.Path('/var/lib/sentinelx/uploads/otzaria-wave3-primary-bookinfo-proposals-20261128.zip')
ORIGIN='https://github.com/davidpovarsky/TorahInspectorKit.git'
FLOOR=1593835520; BUDGET=48*1024**2; LANE_EXISTING=39452672; LANE_CAP=300*1024**2
EXPECTED=json.loads("{\"Sources/TorahInspectorUI/TorahInspectorNavigationSurface.swift\":[20634,\"8ebf45c900f30ccf48fd5f6efa61a0d204f4bb08c178f1b3fa473b9307e31114\"],\"Sources/TorahInspectorUI/TorahInspectorView.swift\":[30948,\"00e26fa48c0f5313fb223bd0025d370f66e46ea7421b14dbe4da535fadb44a36\"],\"Sources/TorahInspectorUI/TorahSegmentDetailView.swift\":[63385,\"9410237c166e262f601c5db8be5bb4ce7200ae4d56afef458e6f758382680ac4\"],\"docs/validation/20261127-original-inspector-selection/ORIGINAL_SOURCE_PRESERVATION.json\":[7009,\"9289aec9df7c040bd1a3bfe94248d4ffb4a413b4d6425b446ada19cef166ed59\"],\"docs/validation/20261127-original-inspector-selection/POLICY_READ.json\":[2038,\"89563bfe5316a5e9d165f1e0a74dfc879e35fe559518c8ac80143ed052eb09a5\"],\"docs/validation/20261127-original-inspector-selection/RAW_EVIDENCE_INDEX.json\":[9885,\"6e70f040b16a0b1a3e963407b4125b4ccac5bc6063dca0c0a9b8279fa0c61477\"],\"docs/validation/20261127-original-inspector-selection/README.md\":[5189,\"d61a6ad0ba9a31d3532db384f061df9e9d76b67a07bb79980e9b94efc6c942af\"],\"docs/validation/20261127-original-inspector-selection/controls/KitNavigationBoundary.swift\":[4027,\"a972522df6597b934c77b50bea30e4db9be873c30f2896b627e19c59ef271747\"],\"docs/validation/20261127-original-inspector-selection/controls/KitNavigationControls.swift\":[14643,\"f046daeef0a509cd730c911cc2814367afde02d05225c4631d7bca89730aeb97\"],\"docs/validation/20261127-original-inspector-selection/controls/generate_kit_controls.py\":[8139,\"543af1a056802d7bbda6653c0f11eb010bd1a017185a7523357677fc4069e7f7\"],\"docs/validation/20261127-original-inspector-selection/controls/run_kit_controls.py\":[6106,\"212cafe8b9ee6da55558939b926c63edf996dfb03a3f803900ae6c29a1bda346\"],\"docs/validation/20261127-original-inspector-selection/original-source-controls.tar.gz\":[46279,\"f863871af4bef7a793dfd0f8d5b7431432f456155cd94731c4af4608ecb68f7f\"],\"docs/validation/20261127-original-inspector-selection/provenance/CHECKOUT_PROVENANCE.json\":[5587,\"5fe6069b01a446ef5e5832d332d7fc4a58cb40aaf0e02192386eb3a454736cdf\"],\"docs/validation/20261127-original-inspector-selection/provenance/PEER_BASE_PREEDIT_PROOF.json\":[4817,\"d76920e8c182046f2a8e32145720252d28559a72ea42befdf2fc62fd91a7f20a\"],\"docs/validation/20261127-original-inspector-selection/provenance/PEER_KIT26_PROVENANCE.json\":[16738,\"9d451f5bafb10254988663b144dc998ed154c672078c8e6da3156091918334d8\"],\"docs/validation/20261127-original-inspector-selection/provenance/PEER_KIT26_SOURCE_REVIEW.json\":[4136,\"31c535910d864c35b28fd60e9de139b329ad86774de11f4129c64118d14fb88a\"]}")
PREIMAGES={'Sources/TorahInspectorUI/TorahInspectorView.swift':(26545,'d68b95a931f2dedec125a50e233c6844d518895e49d13c6d520bd448cac55655'),'Sources/TorahInspectorUI/TorahSegmentDetailView.swift':(56161,'5ac7fad544a637c5e0ae0e2c497ac7e4c6fb0cde3bc232a620e44f390dab8464')}
OWNER=pwd.getpwnam('ubuntu'); seq=0; commands=[]; result={'schema':'otzaria.kit-selective-rootfs-publication/1','scope':'Exact 3 product + 13 evidence paths only; no compiler, App pin, SDK or native run','base':BASE,'branch':BRANCH,'newRoot':str(ROOT),'status':'STARTING'}
def require(ok,message):
 if not ok: raise RuntimeError(message)
def canonical(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def ident(s):return [s.st_dev,s.st_ino,s.st_size,str(s.st_mtime_ns),str(s.st_ctime_ns)]
def allocated():
 if not ROOT.exists():return 0
 total=0
 for parent,dirs,files in os.walk(ROOT,followlinks=False):
  for name in dirs+files:
   p=pathlib.Path(parent)/name;s=p.lstat()
   require(not stat.S_ISLNK(s.st_mode),'No new-scope symlink')
   total+=s.st_blocks*512
 return total
def guard(extra=0):
 v=os.statvfs('/home/ubuntu');free=v.f_bavail*v.f_frsize
 require(free>=FLOOR+extra,'Root filesystem admission floor')
 used=allocated();require(used+extra<=BUDGET,'New source/evidence 48 MiB budget')
 require(LANE_EXISTING+used+extra<=LANE_CAP,'Original Inspector lane 300 MiB ceiling')
 return {'freeBytes':free,'newScopeAllocatedBytes':used,'laneKnownPriorAllocatedBytes':LANE_EXISTING}
def own_dir(p):
 p.mkdir(mode=0o700);os.chown(p,OWNER.pw_uid,OWNER.pw_gid)
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(fd)
 finally:os.close(fd)
def write(p,raw,replace=False):
 guard(len(raw)+4096)
 p.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 current=p.parent
 while current!=ROOT.parent and current.is_relative_to(ROOT):
  os.chown(current,OWNER.pw_uid,OWNER.pw_gid);current=current.parent
 flags=os.O_WRONLY|os.O_NOFOLLOW|(os.O_TRUNC if replace else os.O_CREAT|os.O_EXCL)
 fd=os.open(p,flags,0o644)
 try:
  os.fchown(fd,OWNER.pw_uid,OWNER.pw_gid);os.fchmod(fd,0o644)
  view=memoryview(raw)
  while view:
   n=os.write(fd,view);require(n>0,'Short durable file write');view=view[n:]
  os.fsync(fd)
 finally:os.close(fd)
 pd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(pd)
 finally:os.close(pd)
def start_id(pid):
 try:
  raw=pathlib.Path('/proc/'+str(pid)+'/stat').read_text();tail=raw.rsplit(')',1)[1].split()
  return tail[19]
 except FileNotFoundError:return None
def git(repo,args,allowed=(0,),timeout=30,record=True):
 global seq
 guard();seq+=1
 argv=['runuser','-u','ubuntu','--','git','-c','gc.auto=0','-c','maintenance.auto=false','-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','-C',str(repo)]+args
 env=dict(os.environ);env['GIT_OPTIONAL_LOCKS']='0';env['GIT_TERMINAL_PROMPT']='0'
 proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env=env)
 out=err=b'';birth=None
 try:
  birth=start_id(proc.pid)
  require(birth is not None,'Owned Git process identity unavailable')
  try:out,err=proc.communicate(timeout=timeout)
  except subprocess.TimeoutExpired:
   if proc.poll() is None and start_id(proc.pid)==birth and os.getpgid(proc.pid)==proc.pid:os.killpg(proc.pid,signal.SIGTERM)
   try:out,err=proc.communicate(timeout=5)
   except subprocess.TimeoutExpired:
    if proc.poll() is None and start_id(proc.pid)==birth and os.getpgid(proc.pid)==proc.pid:os.killpg(proc.pid,signal.SIGKILL)
    out,err=proc.communicate(timeout=5)
   raise RuntimeError('Owned Git command timeout')
  require(len(out)+len(err)<=2*1024**2,'Bounded Git command output')
 finally:
  if proc.poll() is None:
   if birth is not None and start_id(proc.pid)==birth and os.getpgid(proc.pid)==proc.pid:os.killpg(proc.pid,signal.SIGTERM)
   try:proc.communicate(timeout=5)
   except subprocess.TimeoutExpired:
    if proc.poll() is None and birth is not None and start_id(proc.pid)==birth and os.getpgid(proc.pid)==proc.pid:os.killpg(proc.pid,signal.SIGKILL)
    proc.communicate(timeout=5)
 if record:
  item={'sequence':seq,'repository':str(repo),'args':args,'exitCode':proc.returncode,'stdoutBytes':len(out),'stdoutSHA256':hashlib.sha256(out).hexdigest(),'stderrBytes':len(err),'stderrSHA256':hashlib.sha256(err).hexdigest()}
  commands.append(item)
  write(EVIDENCE/(str(seq).zfill(2)+'.stdout'),out);write(EVIDENCE/(str(seq).zfill(2)+'.stderr'),err)
 require(proc.returncode in allowed,'Git command refused: '+args[0])
 return proc.returncode,out,err

COMMIT='414e0d3e95d53509381d233a23fcdd28ef24167a'
try:
 require(not EVIDENCE.exists(),'Exclusive push continuation required');guard();own_dir(EVIDENCE)
 write(EVIDENCE/'CONTROLLER.py',pathlib.Path(__file__).read_bytes())
 require(hashlib.sha256((ROOT/'continuation-1/239.stderr').read_bytes()).hexdigest()=='2e554a39e2bb4414b5e2c3f5a90ebc87b405b5b8231d692704ec6df4580e8f60','Exact credential-helper failure retained')
 require(git(REPO,['rev-parse','HEAD'])[1].decode().strip()==COMMIT and git(REPO,['rev-parse','HEAD^'])[1].decode().strip()==BASE,'Exact unchanged source commit/parent')
 require(git(REPO,['symbolic-ref','--short','HEAD'])[1].decode().strip()==BRANCH and git(REPO,['remote','get-url','origin'])[1].decode().strip()==ORIGIN,'Exact branch/origin')
 require(git(REPO,['status','--porcelain=v1','--untracked-files=all'])[1]==b'','Clean candidate required')
 changed=git(REPO,['diff','--name-only','-z',BASE,COMMIT])[1]
 require(sorted(x.decode() for x in changed.split(b'\0') if x)==sorted(EXPECTED),'Only exact 16 committed paths')
 for path,(size,sha) in EXPECTED.items():
  body=git(REPO,['show',COMMIT+':'+path],record=False)[1]
  require(len(body)==size and hashlib.sha256(body).hexdigest()==sha and (REPO/path).read_bytes()==body,'Exact committed/physical afterimage')
 code,remote,_=git(REPO,['ls-remote','--exit-code','--heads','origin','refs/heads/'+BRANCH],allowed=(0,2),timeout=30)
 require(code==2 and remote==b'','No duplicate remote publication')
 git(REPO,['-c','credential.helper=!gh auth git-credential','push','--porcelain','origin','HEAD:refs/heads/'+BRANCH],timeout=90)
 remote=git(REPO,['ls-remote','--heads','origin','refs/heads/'+BRANCH],timeout=30)[1].decode().strip()
 require(remote==COMMIT+'\trefs/heads/'+BRANCH,'Exact remote immutable readback')
 require(git(REPO,['status','--porcelain=v1','--untracked-files=all'])[1]==b'','Candidate clean after push')
 require(git(DONOR,['rev-parse','HEAD'])[1].decode().strip()==BASE and git(DONOR,['status','--porcelain=v1','--untracked-files=all'])[1]==b'','Original donor unchanged')
 report={'schema':'otzaria.kit-selective-publication-final/1','status':'PUBLISHED_SOURCE_AND_EXISTING_EVIDENCE_ONLY','commit':COMMIT,'parent':BASE,'branch':BRANCH,'remoteReadback':remote,'repo':str(REPO),'sourceFiles':3,'evidenceFiles':13,'sourceAfterimages':EXPECTED,'recoveredParentBlobs':52,'allParentUniqueBlobsVerified':153,'rawEvidenceMembersVerified':49,'originalKitControls':{'passed':28,'failed':0,'rerun':False},'pathCounterfactual':{'passed':27,'failed':1,'rerun':False},'AppleSDKRuns':0,'nativeRuns':0,'compilerRuns':0,'AppPinChanged':False,'App52':'Actual earlier compile failure and capacity refusal remain, no cases promoted','firstCommitFailureSHA256':'f1b99a63f03fe1c0b0e85561ce440dadf35146ed471c6211b905ef084202c12b','firstPushFailureSHA256':'b56462b17a71724a35060a79e7bb264d2d678bdc58aa509757125c34773ebc78','unchangedDonor':str(DONOR),'finalCapacity':guard(),'credentialUse':'Existing gh auth git-credential only, per-command; no token logging/export/global configuration change'}
 write(EVIDENCE/'COMMANDS.json',canonical(commands));write(EVIDENCE/'RESULT.json',canonical(report))
 print(json.dumps({'status':report['status'],'commit':COMMIT,'parent':BASE,'branch':BRANCH,'result':str(EVIDENCE/'RESULT.json'),'resultSHA256':hashlib.sha256((EVIDENCE/'RESULT.json').read_bytes()).hexdigest(),'files':16,'capacity':report['finalCapacity']},separators=(',',':')))
except BaseException as error:
 failure={'status':'FAILED','errorType':type(error).__name__,'error':str(error)[:500],'commit':COMMIT,'commandCount':len(commands)}
 if EVIDENCE.is_dir():
  try:write(EVIDENCE/'FAILED.json',canonical(failure));write(EVIDENCE/'COMMANDS.json',canonical(commands))
  except BaseException:pass
 print(json.dumps(failure,separators=(',',':')));raise
