#!/usr/bin/env python3
"""Require exact, recent, complete real UI artifacts before TestFlight signing."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import runpy
import stat
import subprocess
import sys
import tempfile
import zipfile
import copy
import shutil

ROOT = Path(__file__).resolve().parents[2]
GUARD = runpy.run_path(str(ROOT / "tools/verify_xcresult_zero_skips.py"))
FINAL_PUSH = runpy.run_path(str(ROOT / "Scripts/CI/runtime27_final_push.py"))


def require(value, reason):
    if not value:
        raise ValueError(reason)


def read(root, relative):
    part = PurePosixPath(relative)
    require(not part.is_absolute() and ".." not in part.parts, "Unsafe evidence path")
    path = (root / relative).resolve()
    require(path.is_relative_to(root.resolve()) and path.is_file(), "Required evidence missing: " + relative)
    return path


def verify_final_push_receipts(run, root, tested_sha, manifest_sha, application_trees):
    """Admit the original exact push route using its real final-stage receipts.

    The existing producer source auditor is reused against the candidate's
    actual checkout. An arbitrary push or locally asserted run cannot qualify.
    """
    prefix = "artifacts/runtime27/final-push-production."
    before = json.loads(read(root, prefix + "before.json").read_text(encoding="utf-8"))
    after = json.loads(read(root, prefix + "after.json").read_text(encoding="utf-8"))
    require(before.get("status") == "FINAL_PUSH_SOURCE_BOUND"
            and after.get("status") == "FINAL_PUSH_SOURCE_UNCHANGED"
            and all(receipt.get("mode") == "release" and receipt.get("stage") == "production"
                    for receipt in [before, after])
            and before.get("phase") == "before" and after.get("phase") == "after",
            "Missing successful final push production source receipts")
    source = before.get("source")
    require(isinstance(source, dict) and source == after.get("source"),
            "Final push source changed during production acceptance")
    authority = FINAL_PUSH["authority"]("release")
    require(source.get("authority") == authority and source.get("checkout_sha") == tested_sha,
            "Final push receipt has a different authority or checkout")
    FINAL_PUSH["validate_release_run"](run, {
        "workflow": authority["workflow"], "push_authority": authority,
        "checkout_sha": tested_sha, "run_id": source.get("run_id"),
        "run_attempt": source.get("run_attempt"),
    })
    # Documentation-only descendants can retain this proof only while the
    # exact original application, tests, source pins and runtime closure match.
    head = FINAL_PUSH["git"](ROOT, "rev-parse", "HEAD")
    observed = FINAL_PUSH["reviewed_source"](ROOT, head)
    recorded = {key: value for key, value in source.items()
                if key not in {"authority", "checkout_sha", "run_id", "run_attempt"}}
    require(observed == recorded, "Final push reviewed candidate inputs differ")
    require({key: observed["application_trees"][key] for key in application_trees} == application_trees,
            "Final push application trees differ from the candidate")
    pins = {row["path"]: row["sha256"] for row in observed["source_pins"]}
    require(pins.get("Scripts/CI/runtime27-release-manifest.json") == manifest_sha,
            "Final push full Release manifest differs")
    return authority


def verify(run, root, expected_sha, manifest, manifest_sha, application_trees, now=None, reuse_proof=None, *, required_inputs):
    require(manifest.get("full_release_acceptance_required") is True and manifest.get("configurations"), "Missing full release requirements")
    require(re.fullmatch(r"[a-f0-9]{40}", expected_sha) is not None, "Missing exact candidate SHA")
    require(run.get("status") == "completed" and run.get("conclusion") == "success", "UI acceptance run did not complete successfully")
    tested_sha = run.get("head_sha")
    if tested_sha != expected_sha:
        require(reuse_proof and reuse_proof.get("kind") == "DOCUMENTATION_ONLY_DESCENDANT"
                and reuse_proof.get("tested_sha") == tested_sha and reuse_proof.get("candidate_sha") == expected_sha
                and all(path.startswith("docs/hq-integration/") for path in reuse_proof.get("changed_paths", [])),
                "Stale/different acceptance checkout without bounded input-equivalence proof")
    if run.get("event") == "push":
        verify_final_push_receipts(run, root, tested_sha, manifest_sha, application_trees)
    else:
        require(run.get("event") == "workflow_dispatch", "Unexpected acceptance trigger")
        require(run.get("path", "").split("@")[0] == ".github/workflows/sefaria-embedded-validation.yml", "Unexpected acceptance workflow")
    completed = datetime.fromisoformat(run["updated_at"].replace("Z", "+00:00"))
    age = ((now or datetime.now(timezone.utc)) - completed).total_seconds()
    require(0 <= age <= manifest["max_age_hours"] * 3600, "Stale/future acceptance result")
    checked = verify_artifact_evidence(root, tested_sha, manifest, manifest_sha, application_trees,
                                       required_inputs=required_inputs)
    return {"status": "RELEASE_UI_GATE_PASS", "checkout_sha": expected_sha, "tested_checkout_sha": tested_sha,
            "bounded_reuse_proof": reuse_proof, **checked,
            "database_effect_claim": "NONE; actual data report and real UI assertions checked separately"}


def verify_artifact_evidence(root, tested_sha, manifest, manifest_sha, application_trees, *, required_inputs, result=None):
    """Validate real files independently of the later GitHub completion check.

    The producer may check an in-memory candidate payload before publishing it.
    It never fabricates a completed workflow record to call the release gate.
    """
    require(manifest.get("full_release_acceptance_required") is True and manifest.get("configurations"),
            "Missing full release requirements")
    if result is None:
        result = json.loads(read(root, "artifacts/runtime27/result.json").read_text())
    require(result.get("status") == "EXECUTED_PASS" and result.get("full_release_acceptance") is True,
            "Missing full real UI acceptance; focused subsets/build/probe do not satisfy release")
    require(result.get("checkout_sha") == tested_sha, "Acceptance artifact checkout mismatch")
    require(result.get("release_manifest_sha256") == manifest_sha, "Missing/stale full acceptance manifest")
    require(result.get("scope") == manifest["scope"] == "full-release-ui", "Partial/non-release UI scope")
    build = json.loads(read(root, "hq-stage2/result.json").read_text())
    require(build.get("status") == "SIMULATOR_BUILD_FOR_REAL_UI_PASS" and build.get("checkout_sha") == tested_sha, "Missing actual matching app/test build")
    require(build.get("application_trees") == application_trees, "Application/dependency project fingerprints changed")
    expected_pins = required_inputs["package_pins"]
    require(expected_pins and build.get("package_pins") == expected_pins,
            "Package revisions do not match the candidate's committed lock")
    require(build.get("package_resolved_sha256") == required_inputs["package_resolved_sha256"],
            "Package lock bytes do not match the accepted candidate")
    require(build.get("actual_source_inputs_verified", 0) > 0
            and set(build.get("actual_package_checkouts", {})) == set(expected_pins),
            "Missing or unexpected actual app/package inputs")
    for package, revision in expected_pins.items():
        require(build["actual_package_checkouts"][package] == {"head": revision, "status": "CLEAN"},
                "Actual pinned package source mismatch")
    expected_sdk = required_inputs["hanlin_sdk_source"]
    require(build.get("hanlin_gitlink") == expected_sdk["sha"] and build.get("hanlin_sdk_source") == expected_sdk,
            "Original Hanlin source does not match the candidate")
    for name in ["hanlin-sdk-inputs.json", "hanlin-sdk-inputs-after.json"]:
        require(json.loads(read(root, "hq-stage2/" + name).read_text()) == expected_sdk,
                "Missing or changed original SDK source proof: " + name)
    required_configs = {row["id"]: row for row in manifest["configurations"]}
    configs = result.get("configurations", [])
    require(len(configs) == len(required_configs) and {row.get("id") for row in configs} == required_configs.keys(),
            "Missing/duplicate/partial device configurations")
    passed = 0
    oracle_executed = 0
    for actual in configs:
        required = required_configs[actual["id"]]
        require(actual.get("status") == "EXECUTED_PASS" and actual.get("device_size") == required["device_size"], "Device acceptance incomplete")
        require(str(actual.get("os_version", "")).split(".")[0] == str(manifest["required_os_major"])
                and actual.get("os_build") and actual.get("device_udid"), "Missing/wrong actual OS/device fingerprint")
        require(actual.get("data_profile") == required["data_profile"], "Wrong/missing data profile")
        for field in ["content_size", "configuration"]:
            if field in required:
                require(actual.get(field) == required[field], "Wrong/missing actual " + field)
        require(actual.get("locale") and actual.get("orientations") and actual.get("app_binary_sha256")
                and actual.get("test_binary_sha256"), "Missing locale/orientation/binary fingerprints")
        summary = json.loads(read(root, actual["summary_path"]).read_text())
        tree = json.loads(read(root, actual["tests_path"]).read_text())
        devices = tree.get("devices", [])
        require(len(devices) == 1 and devices[0].get("deviceId") == actual["device_udid"]
                and devices[0].get("osVersion") == actual["os_version"], "xcresult actual device/OS does not match configuration")
        log = read(root, actual["log_path"]).read_text()
        oracles = required.get("required_oracle_cases", [])
        checked = GUARD["verify"](summary, tree, log, required["required_ui_cases"], len(required["required_ui_cases"]),
                                  min_total_tests=len(required["required_ui_cases"]) + len(oracles), required_executed_cases=oracles)
        passed += checked["required_ui_passed"]
        oracle_executed += len(oracles)
        data = json.loads(read(root, actual["data_evidence_path"]).read_text())
        require(data.get("passed") is True and data.get("profileID") == required["data_profile"]
                and data.get("shaMatched") is True and data.get("expectedSHA256")
                and data.get("expectedSHA256") == data.get("actualSHA256")
                and data.get("quickCheck", "").lower() == "ok" and data.get("bookCount", 0) > 0,
                "Missing positive real native data installation evidence")
        if required["data_profile"] == "production":
            require(data.get("bookCount", 0) >= 7000 and data.get("extractedBytes", 0) >= 1_500_000_000,
                    "Production UI gate lacks full real corpus evidence")
    return {"required_ui_passed": passed, "separate_oracle_executed": oracle_executed,
            "configurations": sorted(required_configs), "release_manifest_sha256": manifest_sha}



def api(path):
    return json.loads(subprocess.check_output(["gh", "api", path], text=True))


def documentation_reuse(tested_sha, candidate_sha):
    require(re.fullmatch(r"[a-f0-9]{40}", tested_sha or "") is not None, "Missing tested SHA")
    if tested_sha == candidate_sha:
        return None
    subprocess.run(["git", "merge-base", "--is-ancestor", tested_sha, candidate_sha], check=True)
    delta = subprocess.check_output(["git", "diff", "--name-only", tested_sha, candidate_sha], text=True).splitlines()
    require(all(path.startswith("docs/hq-integration/") for path in delta),
            "Changed app/test/data/dependency/tool/configuration inputs require affected-case validation")
    diff = subprocess.check_output(["git", "diff", "--binary", tested_sha, candidate_sha])
    return {"kind": "DOCUMENTATION_ONLY_DESCENDANT", "tested_sha": tested_sha, "candidate_sha": candidate_sha,
            "changed_paths": delta, "diff_sha256": hashlib.sha256(diff).hexdigest(),
            "impact": "All application, test, data-profile, dependency, tool and execution configuration bytes unchanged"}


def sha256(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def candidate_dependency_requirements():
    # Read the committed lock, not a mutable/cache-generated replacement.
    path = "Maktabah.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved"
    raw = subprocess.check_output(["git", "show", "HEAD:" + path], cwd=ROOT)
    rows = json.loads(raw)["pins"]
    package_pins = {row["identity"]: row["state"]["revision"] for row in rows}
    require(bool(package_pins) and len(package_pins) == len(rows)
            and all(re.fullmatch(r"[a-f0-9]{40}", revision) for revision in package_pins.values()),
            "Invalid or duplicate candidate package revisions")
    sdk_pin = subprocess.check_output(["git", "rev-parse", "HEAD:Vendor/HanlinSDK"], cwd=ROOT, text=True).strip()
    original = runpy.run_path(str(ROOT / "Scripts/CI/prepare-hanlin-sdk.py"))
    sdk_source = original["verify"](sdk_pin)
    return {"package_pins": package_pins, "package_resolved_sha256": hashlib.sha256(raw).hexdigest(),
            "hanlin_sdk_source": sdk_source}


def verify_prepared_inputs(approved_path):
    approved = json.loads(approved_path.read_text())
    build = copy.deepcopy(approved["tested_build_report"])
    native = build["native_context"]
    expected_dependencies = candidate_dependency_requirements()
    require(build.get("package_pins") == expected_dependencies["package_pins"] and build.get("hanlin_sdk_source") == expected_dependencies["hanlin_sdk_source"],
            "Prepared original package sources differ from accepted UI inputs")
    require(subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == approved["candidate_sha"], "Candidate moved after UI gate")
    for path, expected in [("Podfile", native["podfile_sha256"]), ("Podfile.lock", native["pod_lock_sha256"]),
                           ("Vendor/SefariaMobile/Upstream/package-lock.json", native["npm_lock_sha256"]),
                           ("Maktabah.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved", build["package_resolved_sha256"])]:
        require(sha256(ROOT / path) == expected, "Prepared input differs from real UI acceptance: " + path)
    require(subprocess.check_output(["git", "-C", "Vendor/SefariaMobile/Upstream", "rev-parse", "HEAD"], text=True).strip() == native["gitlink"], "Sefaria source pin changed")
    for command, expected in [(["xcodebuild", "-version"], build["xcode"]), (["node", "--version"], native["node"]),
                              (["pod", "--version"], native["cocoapods"])]:
        require(subprocess.check_output(command, text=True).strip() == expected.strip(), "Prepared toolchain differs from real UI acceptance")
    for provider in native["generated_expo_providers"]:
        require(sha256(ROOT / provider["path"]) == provider["sha256"], "Generated Expo source differs from UI acceptance")
    for generated in build.get("generated_configuration", []):
        require(sha256(ROOT / generated["path"]) == generated["compiled_sha256"], "Generated source context differs from UI acceptance")
    # Reuse the existing actual-files/package auditor. No duplicate source guard
    # or blanket dirty-source exception is introduced for the signing workflow.
    helper = runpy.run_path(str(ROOT / "Scripts/CI/hq-stage2-focused-apple.py"))
    evidence = approved_path.parent / "runtime27-prepared-inputs"
    evidence.mkdir(parents=True, exist_ok=True)
    helper["verify_actual_sources"].__globals__["OUT"] = evidence
    helper["verify_actual_sources"](build)
    return {"status": "RELEASE_UI_INPUTS_PASS", "checkout_sha": approved["candidate_sha"],
            "tested_checkout_sha": approved["tested_sha"], "actual_source_inputs_verified": build["actual_source_inputs_verified"],
            "actual_package_checkouts": build["actual_package_checkouts"], "hanlin_sdk_sha": expected_dependencies["hanlin_sdk_source"]["sha"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run")
    parser.add_argument("--expected-sha")
    parser.add_argument("--check-prepared-inputs", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = {"status": "FAIL", "distribution_started": False}
    try:
        if args.check_prepared_inputs:
            report.update(verify_prepared_inputs(args.check_prepared_inputs))
            return 0
        require(re.fullmatch(r"[1-9][0-9]*", args.run or "") is not None, "A successful full UI acceptance run ID is mandatory")
        require(subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == args.expected_sha, "Candidate SHA must match the actual checkout")
        repository = os.environ.get("GITHUB_REPOSITORY")
        require(repository == "davidpovarsky/Maktabah", "Unexpected repository")
        run = api(f"repos/{repository}/actions/runs/{args.run}")
        # Reject stale/failure before downloading potentially large artifacts.
        require(run.get("conclusion") == "success", "UI run failed")
        reuse = documentation_reuse(run.get("head_sha"), args.expected_sha)
        artifacts = api(f"repos/{repository}/actions/runs/{args.run}/artifacts?per_page=100")["artifacts"]
        selected = [v for v in artifacts if v["name"] == "runtime27-evidence" and not v["expired"]]
        require(len(selected) == 1, "Exactly one live runtime27-evidence artifact is mandatory")
        artifact = selected[0]
        with tempfile.TemporaryDirectory(prefix="runtime27-release-gate-") as folder:
            folder = Path(folder)
            archive = folder / "evidence.zip"
            with archive.open("wb") as output:
                subprocess.run(["gh", "api", f"repos/{repository}/actions/artifacts/{artifact['id']}/zip"], stdout=output, check=True)
            with archive.open("rb") as source:
                digest = hashlib.file_digest(source, "sha256").hexdigest()
            require(artifact.get("digest") == "sha256:" + digest, "Artifact ZIP digest missing/mismatched")
            destination = folder / "extracted"
            with zipfile.ZipFile(archive) as value:
                require(sum(member.file_size for member in value.infolist()) < 8 * 1024**3, "Oversized UI evidence")
                for member in value.infolist():
                    part = PurePosixPath(member.filename.replace("\\", "/"))
                    require(not part.is_absolute() and ".." not in part.parts and not re.match(r"^[A-Za-z]:", member.filename)
                            and not stat.S_ISLNK(member.external_attr >> 16), "Unsafe artifact member")
                value.extractall(destination)
            manifest_path = ROOT / "Scripts/CI/runtime27-release-manifest.json"
            manifest = json.loads(manifest_path.read_text())
            manifest_sha = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
            trees = {path: subprocess.check_output(["git", "rev-parse", "HEAD:" + path], text=True).strip()
                     for path in ["Source", "Vendor", "Maktabah.xcodeproj"]}
            verified = verify(run, destination, args.expected_sha, manifest, manifest_sha, trees, reuse_proof=reuse,
                              required_inputs=candidate_dependency_requirements())
            build = json.loads(read(destination, "hq-stage2/result.json").read_text())
            lock = read(destination, "hq-stage2/resolved-Podfile.lock")
            require(sha256(lock) == build["native_context"]["pod_lock_sha256"], "UI Podfile.lock bytes missing/mismatched")
            candidate_lock = ROOT / "Podfile.lock"
            require(not candidate_lock.is_symlink(), "Occupied native lock path is a symlink")
            require(not candidate_lock.exists() or sha256(candidate_lock) == sha256(lock), "Committed/current native lock differs from tested UI")
            shutil.copyfile(lock, candidate_lock)
            args.out.parent.mkdir(parents=True, exist_ok=True)
            (args.out.parent / "runtime27-approved-inputs.json").write_text(json.dumps({"candidate_sha": args.expected_sha,
                "tested_sha": run["head_sha"], "tested_build_report": build}, indent=2) + "\n")
            report.update(verified, acceptance_run=args.run, artifact_id=artifact["id"], artifact_zip_sha256=digest)
    except (ValueError, KeyError, OSError, RuntimeError, subprocess.SubprocessError) as error:
        report.update(status="FAIL", error=str(error))
        print("::error::" + str(error), file=sys.stderr)
    finally:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report, indent=2))
    return 0 if report["status"] == "RELEASE_UI_GATE_PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
