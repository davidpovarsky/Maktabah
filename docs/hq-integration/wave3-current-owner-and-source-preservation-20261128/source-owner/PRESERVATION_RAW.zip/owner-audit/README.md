# Current owner-release gate reconciliation — 2026-11-28

## Result

**Current source coverage is BLOCKED.** At commit `55845d215d8e6ff4559dab04ef63791920c4053a`, Source tree `182dd74229c04959cecae82a59d16268dcbd80bc`, the unchanged gate's full baseline contains **69 protected modified paths**. **31** match both the original signed blob and canonical patch, **24** have authentic historical signatures whose source binding is stale, and **14** have no approved path record.

The one public-signature re-verification completed at **2026-11-28T01:54:40 UTC**, exit **0**, with **55/55 valid Ed25519 signatures and 55/55 unexpired attestations**. That process exit reports successful verification/classification work; it is not an owner-release-gate PASS. No new approval or signature was created. The original wrapper's full `audit` was not run. Current external environment key provisioning was not probed.

| Scope | Protected paths | Exact current signed source | Stale signed records | Missing approved records |
|---|---:|---:|---:|---:|
| Actual prior gate at 9c6d3b96 | 56 | 38 | 17 | 1 |
| Actual prior gate at eb532cca | 60 | 38 | 17 | 5 |
| Prior read-only inventory at ec5385e8 | 60 | 34 | 21 | 5 |
| This immutable 55845d21 classification | **69** | **31** | **24** | **14** |

The two actual prior full gates failed. The latter two rows are source classifications, explicitly separate from executing the full release wrapper. Their differing counts follow differing source versions.

## Exact trust and execution boundary

The actual wrapper and its trusted source were read before execution. The classifier uses the unchanged original functions for path protection, raw Git differences, canonical full-index patches, alias binding, canonical signed payload construction, Ed25519 verification, expiry, public-key fingerprinting, checkout identity and policy-baseline verification. It does not patch or substitute their behavior, sign, change policy, or write the registry.

| Input | Exact identity |
|---|---|
| Original release wrapper | `Scripts/CI/verify-owner-release-approval.py`, SHA-256 `ab0da734ad6328da65da410e4d09d4e2911e423c82d7808df452fe8dae90aaaa` |
| Trusted verifier commit | `978db8b37256d4dd2d58e91a0ea8d531798221c0` |
| Trusted verifier file | `tools/verify_upstream_boundary.py`, SHA-256 `9733798a242382f59da99cb999a169e2c69c59010b336742e9a8fa151e837676` |
| Approved policy baseline | `157729471b649a023a81f923be33fb7bfa6e41c9`, direct parent `031df35710ab2c6015efb1acd1e65154dbcd3f24` |
| Gate upstream snapshot | `a0ed0df908a6cb38bc459d4baaeb400f447b2fc4` |
| Current architecture policy | SHA-256 `ce022884d2a28ae5e9186d2a5cddc3f2bf2f6be5a36076240b752c39742bcd63`, Git blob `8999f5329b0045f56f280c903f40a91e500fd36b` |
| Trusted-base PR guard | SHA-256 `70cf39a26e0010122467c9775d9290a93da2a82dcc792c48b679251a4e93baca`, Git blob `1b40d104b261c2b86821d9681cc4b08b79fb2f9a` |
| Original registry | 88,477 bytes; SHA-256 `5bd809034fa0c97cc05655ae216af4201543a6754ea3408013ed48d4eab85a1a`; Git blob `bc4f30808a2e7fa0ad48e406891bed5399583fc3` |
| Independent historical external public-key anchor | SHA-256 of 32 public bytes `b0f0fa39ad1b59595699cd7eaef340a17567c9ff8dbe1408c2372c2a5866818b` |
| Exact anchor receipt | Original actual 9c6d owner-gate receipt SHA-256 `b8e0d96cc518240e102fb3b5dd4ae8c04a18a0d93c1b69ee1a0d81a4adffa51b` |

The original registry is byte-identical to signed commit `322d582b9f2e005b1efa493a190d9c82c2cb1209`. That commit changes only the registry relative to parent `5a51b37a8470fb81b2376bd69e350a32d504e57e`: 49 approved records remain exact, five are renewed and one Reader-tab path is added. Its five informational entries also remain untouched. This audit preserves all original IDs and records.

The old preflight cites the original 55/55 receipt `309e25bf9a4adb350abdad9970fd101946cd7d02eb4c38c339c2f838cd894986` and Asana story `1220938102945251`. Its primary bytes were not located by the bounded retained-evidence lookup, and the coordinator did not have an exact path. This is why one fresh verification of the unchanged signatures was justified. The new receipt is not labeled as that missing original receipt.

The registry public key was accepted for this read-only math only after matching the independently recorded external key fingerprint. Each signed key, repository, baseline, aliases and expiry was checked; candidate metadata did not choose a different trust anchor. The actual installed runtime was Python **3.12.3**, cryptography **41.0.7**. The unchanged release CI job specifies Python 3.11 / cryptography **43.0.3**; that CI execution is **NOT_RUN** here. No dependency was installed.

The 31 current matches also independently match the same attestations in the retained actual eb532 verified-warning set. All 24 stale records differ in **both** current blob and canonical patch. Their signatures remain valid for the old payload only.

## Current protected scope

All 69 changes are modification status `M`, and all paths existed in the policy baseline. There are no protected additions, deletions or renames in this scope. “New protected record” means a newly modified path without an approved record, not a newly created file.

Of the 69 paths, 66 are tracked by the gate's pinned upstream snapshot. Three are protected by namespace and already existed in the policy baseline: `iOSBookInfoAnchoredCard.swift`, `iOSReaderWorkspaceView.swift`, and `iOSReaderSessionManager.swift`. Gate classification is not a substitute for tracing ultimate ownership/lineage.

### 24 records requiring source-bound renewal

| Existing ID | Current protected path |
|---|---|
| OWNER_PATCH_003 | `Maktabah.xcodeproj/project.pbxproj` |
| OWNER_PATCH_006 | `Source/Core/Database/SQLiteDatabase.swift` |
| OWNER_PATCH_008 | `Source/Features/Annotations/iOS/AnnotationListView.swift` |
| OWNER_PATCH_015 | `Source/Features/Library/iOS/iOSLibraryView.swift` |
| OWNER_PATCH_017 | `Source/Features/Reader/ViewModel/BookTOCViewModel.swift` |
| OWNER_PATCH_018 | `Source/Features/Reader/ViewModel/Extensions/Reader+Content.swift` |
| OWNER_PATCH_021 | `Source/Features/Reader/ViewModel/ReaderViewModel.swift` |
| OWNER_PATCH_023 | `Source/Features/Reader/iOS/Toolbar/TOCNodeRow.swift` |
| OWNER_PATCH_026 | `Source/Features/Reader/iOS/Toolbar/iOSReaderBottomToolbarView.swift` |
| OWNER_PATCH_028 | `Source/Features/Reader/iOS/Toolbar/iOSTOCView.swift` |
| OWNER_PATCH_029 | `Source/Features/Reader/iOS/iOSAnnotationEditorSheet.swift` |
| OWNER_PATCH_055 | `Source/Features/Reader/iOS/iOSReaderTabView.swift` |
| OWNER_PATCH_031 | `Source/Features/Reader/iOS/iOSReaderWorkspaceView.swift` |
| OWNER_PATCH_033 | `Source/Features/Search/ViewModel/Extensions/Search+Execution.swift` |
| OWNER_PATCH_034 | `Source/Features/Search/ViewModel/SearchViewModel.swift` |
| OWNER_PATCH_036 | `Source/Features/Search/iOS/SearchModeView.swift` |
| OWNER_PATCH_037 | `Source/Features/Search/iOS/SearchResultsListView.swift` |
| OWNER_PATCH_038 | `Source/Features/Search/iOS/iOSSearchFilterViewController.swift` |
| OWNER_PATCH_039 | `Source/Features/Setting/SettingsView.swift` |
| OWNER_PATCH_040 | `Source/Localizable.xcstrings` |
| OWNER_PATCH_043 | `Source/UI/iOS/Managers/iOSNavigationManager.swift` |
| OWNER_PATCH_047 | `Source/UI/iOS/Views/iOSMainView.swift` |
| OWNER_PATCH_048 | `Source/UI/iOS/Views/iPadLayout.swift` |
| OWNER_PATCH_049 | `Source/UI/iOS/Views/iPhoneLayout.swift` |

### 14 paths requiring an authentic approved record

| Existing ID | Current protected path |
|---|---|
| No approved record | `Source/Features/Annotations/ViewModel/AnnotationViewModel.swift` |
| No approved record | `Source/Features/Annotations/iOS/AnnotationViewControllerWrapper.swift` |
| No approved record | `Source/Features/Annotations/iOS/iOSAnVC+TagFilter.swift` |
| No approved record | `Source/Features/Annotations/iOS/iOSAnnotationViewController.swift` |
| No approved record | `Source/Features/Bookmarks/ViewModel/Extensions/Results+Load.swift` |
| No approved record | `Source/Features/Bookmarks/ViewModel/ResultsViewModel.swift` |
| No approved record | `Source/Features/Bookmarks/iOS/iOSSavedResultsView.swift` |
| No approved record | `Source/Features/History/ViewModel/Extensions/History+Database.swift` |
| No approved record | `Source/Features/History/ViewModel/HistoryViewModel.swift` |
| No approved record | `Source/Features/History/iOS/HistoryComponents.swift` |
| No approved record | `Source/Features/History/iOS/iOSHistoryView.swift` |
| No approved record | `Source/Features/Reader/iOS/ViewOptionsView.swift` |
| No approved record | `Source/Features/Reader/iOS/iOSBookInfoAnchoredCard.swift` |
| No approved record | `Source/Features/Reader/iOS/iOSBookInfoView.swift` |

The 31 exact matches and every current/approved blob, full-baseline patch digest, signature-payload digest and prior-state comparison are retained in `CURRENT_COVERAGE.json` and `HISTORICAL_SIGNATURES.json`. Preserve those unchanged records; do not renumber the existing IDs or use a sequential regenerated list as an identity mapping.

## Delta since the prior ec5385 inventory

Nine paths entered the protected modified set: four Annotation view/model/controller paths, three original Saved Results paths, and the two original BookInfo loader/view paths listed above. Eight previously protected blobs also changed. Three of those became newly stale: `OWNER_PATCH_018` Reader+Content, `OWNER_PATCH_021` ReaderViewModel and `OWNER_PATCH_029` iOSAnnotationEditorSheet. The other five were already stale in that earlier inventory.

Across Source, Vendor, project, UI tests, Scripts, tools and workflows, **107 paths** changed since ec5385: 50 additions and 57 modifications. They comprise 17 protected paths, 57 candidate downstream source paths, seven native-test paths, six Vendor paths and 20 build/tool paths. Against retained integration 29a731e2 the same bounded inventory contains **304 paths** (152 additions, 152 modifications), including 38 protected changes. `SOURCE_DELTA.json` retains all paths and current Git object identities; these are scope counts, not test counts or provenance approvals.

## Mandatory new-code and final-source obligations

These come from the unchanged architecture policy and existing actual source gates. They are not new approval categories introduced by this audit.

1. **Trace ownership of every affected file.** The policy requires origin + SHA, exact downstream hook, task scope, alternative, verification and rollback. A downstream namespace alone does not prove lineage. UNKNOWN origin stays unresolved. Imported engine sources and shared project/entry/navigation/catalog seams retain their own original boundaries.

2. **Bind the exact complete protected delta.** The release route uses the full 157729-to-final-candidate scope. Preserve the existing 31 matching records and original historical evidence; renew the 24 stale payloads and supply authentic records for the 14 uncovered paths through the established owner process after final source freeze. No signing is performed by this packet. A later source or catalog change changes the required binding again.

3. **Bind actual downstream behavior and native completion.** New Core/UIRouting/Host and original-UI adapters still require their real source controls: immutable request/scene/window/backend/record identity, one-use authority, same absolute deadline, pre-await source capture, synchronous publication/ABA retirement, cancellation and reentry, preserved real effects/ACK on late failure, and actual original geometry/focus/row/child completion. This audit does not rerun or promote any source controls to native acceptance.

4. **Preserve original tests and app membership.** Every added source and native selector needs exact target/source discovery, original assertions, correct Pad/Phone test owner, and actual original production/setup oracles. String Catalog, AppIntent/shortcut metadata, PBX/resource and dependency identities are part of the final source. No test count or acceptance assertion is relaxed here.

5. **Complete current build/source admission.** The committed legacy product manifest remains SHA `4dc9fbeb212b248cfc3b464d688b1b5e08ee6d647012571bd5c696c406ddfa15`, naming source `64c1e74a5888f807e127e43611c3aab8fa702755`, 80 component entries and 141 product objects; all four product trees differ from this current target. The actual current source verifier requires exact current trees/rows. Its newer closed Vendor contracts are already integrated: `43e166c8…` and semantic `8423dae0…` (current Vendor tree `2fb868bd…`), so the older preflight's statement that this contract was missing is no longer current. Those contracts preserve source/producer identity; they do not themselves qualify the SDK, Metro/native bridge, app or runtime. Final source/admission/SDK inputs must be bound through the existing strict routes.

6. **Keep PR admission and release verification distinct.** The actual PR guard loads records from its trusted base; the release wrapper loads the authentic full-baseline candidate records. A full-baseline signature is not automatically a signature for another merge-base diff. This task does not fetch, merge or alter the target branch, admit records, change workflow trust, configure external keys, or claim the actual target is ready.

7. **Freeze before qualifying runtime acceptance.** The actual release-gate source permits reuse only for a descendant whose changes are exclusively under `docs/hq-integration/`, with the existing input-equivalence proof. Registry changes under `docs/architecture/`, product/admission/SDK/PBX/catalog/test changes are outside that exception. Final authentic approval, source, build and test inputs must precede the qualifying original app/native run. Required Native116, complete Release114+2, production-v40/backend journeys, accessibility/RTL/keyboard/resize, exact SDK/resource/entitlement/bundle evidence and owner physical checks remain separate real gates.

## Scope exclusions and preserved limits

The current target includes the original BookInfo loading fixes in `iOSBookInfoView` and `iOSBookInfoAnchoredCard`, and these are counted. It does **not** include the new typed BookInfo presentation/Library coverage/setter proposals or the new TOC query/focus/common-source proposals. No unintegrated proposal is counted as current source.

This packet does not assert all 294 components pass; their source mapping and runtime acceptance remain separate. It does not assert all 304 changed-path origins have been fully qualified. No current trusted-target PR admission, full release wrapper, CI cryptography environment, SDK, app build, native test, physical-device check, signing, export, upload or release occurred.

Only the new bounded rootfs evidence directory was written. Application/Git/registry/policy/trust-anchor bytes and Data volume remained unchanged. Initial malformed JSON results were SentinelX stdout truncation during read-only retrieval; their metadata is preserved, and bounded reads recovered the needed bytes. They were not verification failures and caused no source mutation.

## Evidence and reproduction

- `RUN_RECEIPT.json`: actual SentinelX command/terminal return and source-only scope.
- `CLASSIFY.py`: exact executed classifier body. The actual command supplies its `__audit_source__` bootstrap so its own bytes are preserved; use the retained command when reproducing, never silently alter the body.
- `HISTORICAL_SIGNATURES.json`: per-record original payload/record hashes, installed runtime, valid/unexpired results.
- `CURRENT_COVERAGE.json`: 69 exact current source joins and deltas.
- `SOURCE_DELTA.json`: bounded 107/304 path inventory.
- `TRUST_AND_INPUTS.json`: original source/hash anchors, unchanged wrapper checkout/policy checks and resource limits.
- `ADDITIONAL_SOURCE_PINS.json`, `NEW_CODE_OBLIGATIONS.json`: current admission/policy references and obligation scope.
- `FINAL_MANIFEST.json`: exact per-file byte/hash inventory; `HANDOFF.json` pins the final capsule.

The raw signature/coverage receipts remain immutable. No optional rerun was performed.
