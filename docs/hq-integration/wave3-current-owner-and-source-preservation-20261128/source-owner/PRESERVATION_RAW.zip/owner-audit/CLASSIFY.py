#!/usr/bin/env python3
"""Read-only current-source classification plus one public-signature re-verification.
This is evidence; it is not a replacement release gate or an approval writer.
"""
import sys
if not __debug__:
    raise SystemExit("Optimized Python is forbidden before audit actions")
sys.dont_write_bytecode = True
import os, json, hashlib, subprocess, types, gzip, collections
from pathlib import Path
from datetime import datetime, timezone
REPO = Path("/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127")
OUT = Path("/home/ubuntu/otzaria-wave3-current-owner-verification-20261128")
TARGET = "55845d215d8e6ff4559dab04ef63791920c4053a"
EXPECTED_SOURCE = "182dd74229c04959cecae82a59d16268dcbd80bc"
BASE = "157729471b649a023a81f923be33fb7bfa6e41c9"
UPSTREAM = "a0ed0df908a6cb38bc459d4baaeb400f447b2fc4"
TRUSTED = "978db8b37256d4dd2d58e91a0ea8d531798221c0"
TRUSTED_HASH = "9733798a242382f59da99cb999a169e2c69c59010b336742e9a8fa151e837676"
REGISTRY_HASH = "5bd809034fa0c97cc05655ae216af4201543a6754ea3408013ed48d4eab85a1a"
SIGNED_COMMIT = "322d582b9f2e005b1efa493a190d9c82c2cb1209"
PRIOR_AUDIT = "ec5385e863a478e368c7de47264474a440fd0734"
PRIOR_GATE = "eb532ccad28ec78d456fba8c5064abf9c9fdfecc"
RETAINED = "29a731e273f9a757c743c49e182fece0e8047d46"
FLOOR = 1593835520
CAP = 4 * 1024 * 1024
PRODUCT = ("Source", "Vendor", "Maktabah.xcodeproj", "Maktabah-iOSUITests")
INVENTORY_ROOTS = PRODUCT + ("Scripts", "tools", ".github")
os.environ["GIT_OPTIONAL_LOCKS"] = "0"
os.environ["GIT_TERMINAL_PROMPT"] = "0"
written = 0
inputs = []
def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def free_root():
    v = os.statvfs("/home/ubuntu")
    return v.f_bavail * v.f_frsize
def resource_guard():
    available = free_root()
    require(available >= FLOOR + CAP, "ROOTFS_FLOOR_REFUSAL:" + str(available))
    return available
def git(*args):
    return subprocess.check_output(
        ["git", "--no-optional-locks", "-c", "gc.auto=0", "-c",
         "maintenance.auto=false", "-C", str(REPO), *args],
        timeout=45)
def write(relative, raw):
    global written
    require(isinstance(raw, bytes), "Byte artifact required")
    p = Path(relative)
    require(not p.is_absolute() and ".." not in p.parts, "Invalid artifact path")
    require(written + len(raw) <= CAP, "TASK_CAP_REFUSAL")
    resource_guard()
    target = OUT / p
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as f:
        f.write(raw)
    written += len(raw)
    return {"path": relative, "bytes": len(raw), "sha256": sha(raw)}
def write_json(relative, value):
    return write(relative, (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode())
def read_input(ref, path, label, expected=None):
    raw = git("show", ref + ":" + path)
    if expected is not None:
        require(sha(raw) == expected, "INPUT_HASH_MISMATCH:" + path)
    meta = {"ref": ref, "path": path, "bytes": len(raw), "sha256": sha(raw),
            "git_blob": git("rev-parse", ref + ":" + path).decode().strip()}
    meta["preserved"] = write("inputs/" + label, raw)
    inputs.append(meta)
    return raw
def loaded(name, raw):
    module = types.ModuleType(name)
    module.__file__ = "<immutable-git-" + name + ">"
    exec(compile(raw, module.__file__, "exec"), module.__dict__)
    return module
def tree_map(ref):
    result = {}
    for item in git("ls-tree", "-r", "-l", "-z", ref, "--", *INVENTORY_ROOTS).split(b"\0"):
        if not item:
            continue
        head, path = item.split(b"\t", 1)
        mode, kind, blob, size = head.decode().split()
        result[path.decode()] = {"mode": mode, "kind": kind, "git_blob": blob,
                                "bytes": None if size == "-" else int(size)}
    return result
def scope_kind(path, protected):
    if protected:
        return "PROTECTED_ORIGINAL_OR_COLOCATED_PATH"
    if path.startswith("Vendor/"):
        return "VENDOR_REQUIRES_ORIGINAL_LINEAGE_AND_SOURCE_ADMISSION"
    if path.startswith("Maktabah-iOSUITests/"):
        return "NATIVE_TEST_REQUIRES_SOURCE_DISCOVERY_AND_ORIGINAL_ASSERTIONS"
    if path.startswith("Maktabah.xcodeproj/"):
        return "SHARED_PROJECT_REQUIRES_MEMBERSHIP_AND_RESOURCE_REVIEW"
    if path.startswith("Source/"):
        return "CANDIDATE_DOWNSTREAM_REQUIRES_LINEAGE_AND_BEHAVIOR_REVIEW"
    return "BUILD_OR_TOOL_OR_WORKFLOW_REQUIRES_EXACT_INPUT_REVIEW"
started = datetime.now(timezone.utc).isoformat()
initial_free = resource_guard()
require(not OUT.exists() and not OUT.is_symlink(), "NEW_OUTPUT_ALREADY_EXISTS")
OUT.mkdir(mode=0o755)
try:
    write("CLASSIFY.py", __audit_source__.encode())
    head_before = git("rev-parse", "HEAD").decode().strip()
    source = git("rev-parse", TARGET + ":Source").decode().strip()
    require(source == EXPECTED_SOURCE, "TARGET_SOURCE_MISMATCH")
    wrapper_raw = read_input(TARGET, "Scripts/CI/verify-owner-release-approval.py",
                             "release-wrapper.py",
                             "ab0da734ad6328da65da410e4d09d4e2911e423c82d7808df452fe8dae90aaaa")
    trusted_raw = read_input(TRUSTED, "tools/verify_upstream_boundary.py",
                            "trusted-verifier.py", TRUSTED_HASH)
    policy_raw = read_input(TARGET, "docs/architecture/UPSTREAM_INTEGRITY_POLICY.md",
                           "UPSTREAM_INTEGRITY_POLICY.md",
                           "ce022884d2a28ae5e9186d2a5cddc3f2bf2f6be5a36076240b752c39742bcd63")
    read_input(TARGET, "Scripts/CI/verify-upstream-boundary.py", "trusted-base-pr-guard.py",
               "70cf39a26e0010122467c9775d9290a93da2a82dcc792c48b679251a4e93baca")
    read_input(TARGET, "Scripts/CI/test-owner-release-approval.py", "original-wrapper-controls.py",
               "45a6917073d8153e84e7aab075fb1046842dde297e93e15a77656ba1d1c3210a")
    registry_raw = read_input(TARGET, "docs/architecture/UPSTREAM_EXCEPTION_REGISTER.json",
                              "registry-current.json", REGISTRY_HASH)
    signed_registry = git("show", SIGNED_COMMIT + ":docs/architecture/UPSTREAM_EXCEPTION_REGISTER.json")
    require(registry_raw == signed_registry, "ORIGINAL_SIGNED_REGISTRY_CHANGED")
    parent = git("rev-parse", SIGNED_COMMIT + "^").decode().strip()
    prior_registry = json.loads(read_input(parent, "docs/architecture/UPSTREAM_EXCEPTION_REGISTER.json",
                                          "registry-before-six-path-signing.json"))
    signed_paths = git("diff", "--name-only", "--no-renames", parent, SIGNED_COMMIT).decode().splitlines()
    require(signed_paths == ["docs/architecture/UPSTREAM_EXCEPTION_REGISTER.json"],
            "SIGNED_COMMIT_NOT_REGISTRY_ONLY")
    old_gate_path = "docs/hq-integration/wave3-owner-current-9c6d-20261127/owner-approval-gate.json"
    old_gate = json.loads(read_input(TARGET, old_gate_path, "historical-9c6d-owner-gate.json",
                                     "b8e0d96cc518240e102fb3b5dd4ae8c04a18a0d93c1b69ee1a0d81a4adffa51b"))
    old_report_path = "docs/hq-integration/wave3-oracle-capacity-and-owner-gate-20261127/owner-eb532/boundary-guard-report.json.gz"
    old_report_raw = gzip.decompress(read_input(TARGET, old_report_path, "historical-eb532-boundary-report.json.gz",
                                                "ac8ac8f19bbc1440891a1cbfcda01329967363a55a0206f37072731e79a5ce85"))
    require(sha(old_report_raw) == "ecddd27bb371135fecac7ecbc6db36a707284ffa7d9b8bfa40238562c78353f9",
            "PRIOR_REPORT_DECODED_HASH")
    old_report = json.loads(old_report_raw)
    audit_path = "docs/hq-integration/wave3-final-owner-preflight-20261127/FINAL_SOURCE_INVENTORY.json"
    old_inventory = json.loads(read_input(TARGET, audit_path, "historical-ec5385-inventory.json",
                                          "33089825ede3f673dab414c0b2e77ea70a90726880c992aee543933e963ccd7b"))
    admission = json.loads(read_input(TARGET, "Scripts/CI/final-integration-source.inputs.json",
                                     "historical-build-admission.json",
                                     "4dc9fbeb212b248cfc3b464d688b1b5e08ee6d647012571bd5c696c406ddfa15"))
    gate = loaded("unchanged_owner_release_wrapper", wrapper_raw)
    guard = loaded("unchanged_trusted_verifier", trusted_raw)
    gate.validate_policy_baseline(REPO, TARGET)
    require(gate.trusted_verifier_bytes(REPO) == trusted_raw, "TRUSTED_WRAPPER_READ_MISMATCH")
    checkout = {"requested": TARGET, "actual_head": head_before}
    try:
        checkout["trees"] = gate.checkout_identity(REPO, TARGET, gate.REPOSITORY)
        checkout["unchanged_wrapper_check"] = "PASS"
    except Exception as e:
        checkout["unchanged_wrapper_check"] = "REFUSED"
        checkout["error"] = type(e).__name__ + ": " + str(e)
    trees = {p: git("rev-parse", TARGET + ":" + p).decode().strip() for p in PRODUCT}
    registry = json.loads(registry_raw)
    approved_list = [e for e in registry["exceptions"] if e.get("status") == "APPROVED"]
    require(len(approved_list) == 55, "ORIGINAL_55_RECORD_COUNT_CHANGED")
    records = {e["path"]: e for e in approved_list}
    require(len(records) == 55, "DUPLICATE_APPROVED_PATH")
    require(len({e["patch_id"] for e in approved_list}) == 55, "DUPLICATE_APPROVAL_ID")
    public_key = registry["owner_verification_public_key"]
    anchor = old_gate["external_public_key_sha256"]
    require(anchor == "b0f0fa39ad1b59595699cd7eaef340a17567c9ff8dbe1408c2372c2a5866818b",
            "INDEPENDENT_PUBLIC_ANCHOR_CHANGED")
    require(old_gate["external_public_key_configured"] is True, "NO_PRIOR_EXTERNAL_ANCHOR")
    require(gate.public_key_fingerprint(public_key) == anchor, "REGISTRY_KEY_NOT_PRIOR_EXTERNAL_ANCHOR")
    signature_rows = []
    verified_records = {}
    try:
        import cryptography
        crypto_runtime = {"version": cryptography.__version__, "module": cryptography.__file__}
    except ImportError:
        crypto_runtime = {"status": "UNAVAILABLE_NO_INSTALL_ATTEMPT"}
    for path, entry in sorted(records.items()):
        a = entry["owner_attestation"]
        blob, digest, approval_id = guard.attested_record_fields(entry, a)
        require(a.get("repo") == gate.REPOSITORY and a.get("base_sha") == BASE,
                "ORIGINAL_ATTESTATION_SCOPE_MISMATCH")
        require(a.get("signer_public_key", "").strip() == public_key.strip(), "SIGNER_NOT_PINNED")
        payload = guard.construct_canonical_attestation_payload(
            a["repo"], path, a["base_sha"], blob, digest, approval_id, a["expires_at"])
        valid, message = guard.verify_ed25519_signature(public_key, a["signature"], payload)
        expired, expiry_problem = guard.is_attestation_expired(a["expires_at"])
        now = datetime.now(timezone.utc)
        expiry = datetime.fromisoformat(a["expires_at"].replace("Z", "+00:00"))
        strict_expiry_valid = expiry.tzinfo is not None and expiry > now
        ok = valid and not expired and strict_expiry_valid
        verified_records[path] = ok
        signature_rows.append({
            "path": path, "approval_id": approval_id, "signature_valid": valid,
            "signature_result": message, "expires_at": a["expires_at"],
            "expiry_valid_at_observation": not expired and strict_expiry_valid,
            "expiry_error": expiry_problem, "base_sha": a["base_sha"],
            "repo": a["repo"], "approved_blob": blob, "approved_patch_sha256": digest,
            "payload_sha256": sha(payload),
            "attestation_sha256": sha(json.dumps(a,sort_keys=True,separators=(",",":")).encode()),
            "record_sha256": sha(json.dumps(entry,sort_keys=True,separators=(",",":")).encode())})
    prior_by_path = {e.get("path"): e for e in prior_registry["exceptions"] if e.get("path")}
    unchanged_prior = [p for p, e in records.items() if prior_by_path.get(p) == e]
    changed_prior = [p for p, e in records.items() if p in prior_by_path and prior_by_path[p] != e]
    added_prior = [p for p in records if p not in prior_by_path]
    sig_result = {
        "schema": "otzaria.owner-historical-signature-reverification.v1",
        "scope": "EXISTING_55_ATTESTATIONS_ONLY_NOT_NEW_APPROVAL",
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "reason_for_one_reverification": "Primary receipt309e25bf bytes unavailable; historical citation preserved",
        "unchanged_registry_sha256": REGISTRY_HASH, "original_signed_commit": SIGNED_COMMIT,
        "original_signed_commit_parent": parent, "original_signed_commit_changed_paths": signed_paths,
        "six_path_signing_delta": {"unchanged_approved": len(unchanged_prior),
             "changed_existing": changed_prior, "new_paths": added_prior},
        "trusted_verifier_commit": TRUSTED, "trusted_verifier_sha256": TRUSTED_HASH,
        "independent_public_key_fingerprint": anchor,
        "trust_anchor_receipt_exact_sha256": "b8e0d96cc518240e102fb3b5dd4ae8c04a18a0d93c1b69ee1a0d81a4adffa51b",
        "current_external_environment_key_configuration": "NOT_PROBED",
        "python_runtime": sys.version, "crypto_runtime": crypto_runtime,
        "record_count": len(signature_rows), "signature_valid_count": sum(r["signature_valid"] for r in signature_rows),
        "unexpired_count": sum(r["expiry_valid_at_observation"] for r in signature_rows),
        "rows": signature_rows, "private_key_accessed": False, "signing_performed": False}
    write_json("HISTORICAL_SIGNATURES.json", sig_result)
    upstream = guard.get_tree_files(UPSTREAM, str(REPO))
    base_files = guard.get_tree_files(BASE, str(REPO))
    changes = guard.parse_raw_diff(["git","diff","--raw","--no-renames","-z",BASE,TARGET],str(REPO))
    prior_rows = {r["path"]: r for r in old_inventory["protected_rows"]}
    historical_verified = {r["path"]:r for r in old_report["warnings"]}
    rows = []
    for change in changes:
        path, status = change["path"], change["status"]
        if not guard.is_protected_path(path, upstream):
            continue
        blob_code = subprocess.run(["git","--no-optional-locks","-C",str(REPO),"rev-parse",TARGET+":"+path],
                                   capture_output=True,text=True,timeout=45)
        actual_blob = blob_code.stdout.strip() if blob_code.returncode == 0 else None
        patch = guard.canonical_patch_bytes(BASE,TARGET,path,str(REPO))
        digest = sha(patch)
        entry = records.get(path)
        aliases = guard.attested_record_fields(entry,entry["owner_attestation"]) if entry else None
        same_blob = bool(aliases and actual_blob == aliases[0])
        same_patch = bool(aliases and digest == aliases[1])
        namespace_addition = "A" in status and path not in base_files and path not in upstream
        if "D" in status:
            binding = "PROTECTED_DELETION_REFUSED"
        elif namespace_addition:
            binding = "PROTECTED_NAMESPACE_ADDITION_REFUSED"
        elif entry is None:
            binding = "NEW_PROTECTED_RECORD_REQUIRED"
        elif same_blob and same_patch:
            binding = "UNCHANGED_SIGNED_RECORD_SOURCE_BINDING"
        else:
            binding = "RENEW_EXISTING_SIGNATURE"
        old = prior_rows.get(path)
        prior_warning = historical_verified.get(path)
        rows.append({
            "path":path,"status":status,"current_blob":actual_blob,
            "canonical_full_baseline_patch_sha256":digest,"canonical_patch_bytes":len(patch),
            "in_baseline":path in base_files,"in_gate_upstream":path in upstream,
            "approval_id":aliases[2] if aliases else None,"approval_blob":aliases[0] if aliases else None,
            "approval_patch_sha256":aliases[1] if aliases else None,
            "same_blob":same_blob,"same_patch":same_patch,
            "historical_signature_valid_and_unexpired":verified_records.get(path,False),
            "source_binding":binding,
            "covered_current_source":bool(same_blob and same_patch and verified_records.get(path,False)
                                          and binding=="UNCHANGED_SIGNED_RECORD_SOURCE_BINDING"),
            "prior_ec5385_source_binding":old.get("source_binding") if old else None,
            "prior_ec5385_blob":old.get("current_blob") if old else None,
            "blob_changed_since_ec5385":old is None or old.get("current_blob") != actual_blob,
            "same_attestation_also_in_prior_eb532_verified_report":
                bool(entry and prior_warning and prior_warning.get("attestation")==entry["owner_attestation"])})
    rows.sort(key=lambda r:r["path"])
    counts = dict(collections.Counter(r["source_binding"] for r in rows))
    delta = {"prior_audit":PRIOR_AUDIT,"prior_counts":old_inventory["counts"],
             "new_protected_paths":[r["path"] for r in rows if r["path"] not in prior_rows],
             "removed_protected_paths":sorted(set(prior_rows)-{r["path"] for r in rows}),
             "changed_protected_paths":[r["path"] for r in rows if r["path"] in prior_rows and r["blob_changed_since_ec5385"]],
             "newly_stale_records":[r["path"] for r in rows if r["prior_ec5385_source_binding"]=="UNCHANGED_SIGNED_RECORD_SOURCE_BINDING" and r["source_binding"]!="UNCHANGED_SIGNED_RECORD_SOURCE_BINDING"]}
    coverage = {"schema":"otzaria.current-owner-source-coverage.v1","target":TARGET,"source_tree":source,
                "baseline":BASE,"upstream":UPSTREAM,"registry_sha256":REGISTRY_HASH,
                "protected_path_count":len(rows),"counts":counts,"delta_from_ec5385":delta,
                "protected_rows":rows,"full_release_gate_executed":False,
                "current_coverage_status":"BLOCKED" if any(not r["covered_current_source"] for r in rows) else "SOURCE_BINDING_COMPLETE_GATE_STILL_REQUIRED"}
    write_json("CURRENT_COVERAGE.json",coverage)
    current_tree = tree_map(TARGET)
    incremental = {}
    for label, base in [("since_ec5385",PRIOR_AUDIT),("since_original_29a",RETAINED)]:
        entries=guard.parse_raw_diff(["git","diff","--raw","--no-renames","-z",base,TARGET],str(REPO))
        filtered=[]
        for e in entries:
            p=e["path"]
            if not any(p.startswith(r+"/") for r in INVENTORY_ROOTS):
                continue
            protected=guard.is_protected_path(p,upstream)
            filtered.append(dict(e,gate_protected=protected,review_kind=scope_kind(p,protected),
                                 current_object=current_tree.get(p)))
        incremental[label]={"base":base,"count":len(filtered),
                            "status_counts":dict(collections.Counter(e["status"] for e in filtered)),
                            "kind_counts":dict(collections.Counter(e["review_kind"] for e in filtered)),
                            "rows":filtered}
    write_json("SOURCE_DELTA.json",incremental)
    pins={"target":TARGET,"source_tree":source,"product_trees":trees,"head_before":head_before,
          "head_after":git("rev-parse","HEAD").decode().strip(),"checkout_check":checkout,
          "policy_baseline_check":"PASS_USING_UNCHANGED_WRAPPER_FUNCTION",
          "policy_files":gate.POLICY_BLOBS,"trusted_verifier_exact":TRUSTED_HASH,
          "inputs":inputs,"registry_preserved_equal_original_signed_commit":True,
          "signed_commit_registry_only":True,"current_build_admission":{
             "application_source_sha":admission["application_source_sha"],
             "application_trees":admission["application_trees"],
             "native_qualified":admission["native_qualified"],
             "matches_current_trees":admission["application_trees"]==trees,
             "accepted_component_count":len(admission["accepted_components"]),
             "product_delta_count":len(admission["product_delta"])},
          "source_or_git_writes":False,"data_volume_writes":False,"new_keys_or_signatures":False,
          "resources":{"initial_root_free":initial_free,"root_floor":FLOOR,"reserve":CAP,
                       "task_cap":CAP,"written_bytes_before_manifest":written,
                       "root_free_after":free_root()}}
    require(pins["head_after"]==head_before,"REPOSITORY_HEAD_CHANGED_DURING_CLASSIFICATION")
    write_json("TRUST_AND_INPUTS.json",pins)
    result={"scope":"READ_ONLY_CURRENT_OWNER_SOURCE_CLASSIFICATION_AND_EXISTING_SIGNATURE_REVERIFICATION",
            "target":TARGET,"source_tree":source,"started_at":started,"finished_at":datetime.now(timezone.utc).isoformat(),
            "status":coverage["current_coverage_status"],"historical_signature_count":55,
            "historical_signatures_valid":sig_result["signature_valid_count"],
            "historical_unexpired":sig_result["unexpired_count"],"current_protected_paths":len(rows),
            "current_coverage_counts":counts,"delta_from_ec5385":delta,
            "current_source_covered":sum(r["covered_current_source"] for r in rows),
            "full_release_gate_executed":False,"new_approval_created":False,
            "original_309e25bf_primary_receipt":"NOT_LOCATED; citation only, fresh math is separate",
            "current_external_key_provisioning":"NOT_PROBED",
            "unintegrated_toc_bookinfo":"EXCLUDED_FROM_TARGET_GIT_SOURCE",
            "native_or_sdk_execution":False}
    write_json("RESULT.json",result)
    manifest=[]
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            b=p.read_bytes();manifest.append({"path":str(p.relative_to(OUT)),"bytes":len(b),"sha256":sha(b)})
    write_json("MANIFEST.json",{"files":manifest,"payload_bytes":sum(x["bytes"] for x in manifest)})
    print(json.dumps({"result":result,"source_delta_summary":{k:{a:b for a,b in v.items() if a!="rows"} for k,v in incremental.items()},
                      "artifacts":{p.name:{"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())} for p in OUT.iterdir() if p.is_file()},
                      "total_written":written},ensure_ascii=False))
except Exception as e:
    failure={"status":"FAILED","error":type(e).__name__+": "+str(e),"target":TARGET,
             "source_or_git_writes":False,"signing_performed":False}
    try:
        write_json("FAILURE.json",failure)
    except Exception as save:
        failure["failure_receipt_write_error"]=type(save).__name__+": "+str(save)
    print(json.dumps(failure),file=sys.stderr)
    raise
