    /// Read-only proof of the exact ORIGINAL pending parent before its effect.
    /// The query owner may borrow this proof only inside its one consumed
    /// first-parent-validator scope. This does not call that validator, admit
    /// presentation, publish state, or grant navigation permission.
    func captureOriginalParentPreEffectReadiness(
        requestID: UUID
    ) throws -> @MainActor () throws -> Void {
        guard let value = pending, let source = activeSource,
              value.source === source, source.requestID == requestID,
              source.valid, source.phase == .retained,
              !value.applied, !value.rendering, !value.rendered else {
            throw UIRouteError(.staleState, "native_phone_toc_parent_readiness_unavailable")
        }
        let validateRetained: @MainActor () throws -> Void = { [weak self, weak value, weak source] in
            guard let self, let value, let source,
                  self.pending === value, self.activeSource === source,
                  value.source === source, source.requestID == requestID,
                  source.valid, source.phase == .retained,
                  !value.applied, !value.rendering, !value.rendered else {
                throw UIRouteError(.staleState, "native_phone_toc_parent_readiness_changed")
            }
            try self.validate(source)
            guard self.pending === value, self.activeSource === source,
                  value.source === source, source.requestID == requestID,
                  source.valid, source.phase == .retained,
                  !value.applied, !value.rendering, !value.rendered else {
                throw UIRouteError(.staleState, "native_phone_toc_parent_readiness_changed")
            }
        }
        try validateRetained()
        return validateRetained
    }

