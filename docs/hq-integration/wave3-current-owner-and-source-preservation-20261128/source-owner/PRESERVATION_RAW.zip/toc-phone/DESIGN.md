# TOC query: original phone pre-effect readiness proposal

Status: SOURCE PROPOSAL ONLY. Swift compilation, controls, UIKit and native acceptance are NOT_RUN.
This proposal does not modify the live worktree, Git, the existing query source, or any shared integration.

## Exact original source

Immutable Git revision: 87ccd4625115eb43c650180174825b288ba2e592
Source tree: 182dd74229c04959cecae82a59d16268dcbd80bc
Path: Source/ChavrusaText/UIRoutingHost/Integration/MaktabahNativePhoneTOCPresentation.swift
Full original bytes: 22872
Full original SHA-256: 3be167a7855d74e854765c4ae885eec2f07bf9ba0c22028a795a5007b9a2653d
Git blob: 00c74bdb81eb976d86ec4625c85763c3260b3bd1

The original phone apply has exactly two direct Pending.validate calls:
- original line 336: validate(Source), then Pending.validate, with Source.phase retained; the original pending/source postcheck follows before any effect.
- original line 351: after presentReader, source data and book-transition validation, Source.phase is presented; then validate(Source) and Pending.validate.
No direct Pending.validate call occurs while the phone Source is applying. begin has one separate validator before Pending installation. render has two later validators in presented phase.
These are static direct-call counts. Callback-driven reentry can add dynamic calls and is not assumed absent.

## The single actual source addition

captureOriginalParentPreEffectReadiness(requestID:) returns a MainActor read validator capturing weak references to the SAME existing Pending and active Source. It requires same request, valid retained phase, and applied/rendering/rendered all false, before and after the original validate(Source).
Every existing method is byte-exact. No original setter, revision, phase, callback or effect is modified. The method creates no navigation authority. It does not call Pending.validate or Session readiness. It must not be exposed as general root readiness.
An expired/replaced Pending or Source cannot be recovered by a later lookup. Weak captures do not keep that original parent invocation alive.

## Required query/Root integration (DESIGN, NOT IMPLEMENTED)

The existing local query binding is 38,462 B SHA-256 59f2b638ef961479cf0ca8efb972cd949a67255142802d70ab81ed594f86623f.
The existing local field source is 23,765 B SHA-256 cf5fa39557a48db48456ed2f0f380f3180835480bf53858f55114c1d3266883a.
Those full bytes are unavailable in this environment. They are not reconstructed, copied, or changed by this proposal.

Only destination native.reader.toc with explicit anchor native.reader.toc.query may use this integration. Existing root discovery, destination-only lookup, old TOC component owners and availability remain unchanged.

1. After the original phone Pending is installed, and while the query Source is still valid and retained, query.apply captures the new exact phone read proof before entering its own applying phase. It captures the SAME existing settled original field/scope/window/data if a warm already-presented search controller needs the readiness exception. Cold/no-search entry keeps ordinary readiness.
2. A private query readiness lease has armed, insideFirstParentValidation, and permanently spent/closed states. It is not a token in a URL, entity, command payload or registry descriptor.
3. Root wraps only the validator installed on that exact phone.begin. The initial begin validation occurs before a lease exists and runs normally. During the first original phone.apply validator, consume the armed lease BEFORE any callback, enter a temporary read scope, invoke the unchanged bounded validator, revalidate the same query/phone/window/root pre-effect proof, and close before returning to the original phone pending/source postcheck.
4. Only finite query-anchor readiness inside that invocation may consult the lease. Each read guards against nested reads, checks the same captured data/common/window/settled search-controller ancestry and pre-effect phone proof, then finishes with pure identity/revision joins. Sequential reads within this one invocation can be allowed; a second validator invocation cannot spend the lease again.
5. Any recursive validator invocation or nested readiness callback poisons the outer lease permanently before throwing/returning refusal. Catching a nested error cannot restore outer validity. Do not retry, rearm, recapture, or treat a later equal value as recovery.
6. After the original effect, the phone is presented. Its existing isContinuingOriginalReaderPresentation(requestID:) supplies command liveness for the second apply validator and later render callbacks. The pre-effect lease is already closed. No general query-applying or UISearchController-transition exception is added.
7. Return, throw, finish, release, retire and unmount close the exact lease before other callbacks. Final query focus/ACK still requires the real settled original field, geometry, physical first-responder state, source, same command and original deadline.
8. The separate passive warm metadata facet is available only without an active/capturing request. Retained-source readiness is limited to valid retained/presented phases. Neither may be a fallback after an active Source has become stale.
9. captureWindow remains read-only original identity capture. commonReady must not call query readiness, projection or field getters. parentVisible uses the original TOC projection directly. The common/Notes source proposal is independently owned by navigation_fix.

## Actual window recursion boundary

Original retainOriginalWindowObservation captures mounted + exact windowSource object/revision.
Original WindowSource.retainOriginalWindow checks the exact UIView/UIWindow identity, scene, lifetime revision and that source-identity closure. It never invokes isPresentationReady.
Full MaktabahNativeWindowObservation source is SHA-256 b9500b0abb21230a85f73f9814ef4e7ce2b75b12ab382d950ba336ace32c9570, 956 bytes.
The necessary source excerpts and their containing-file pin are retained in READ_CONTEXT.json.

## Required focused controls (NOT_RUN)

Use the full original phone apply/begin/render/validation bodies and declared renderer/window/domain boundaries. Preserve original negative behavior and exact product inputs.
- Warm existing original search: original first parent gate refuses; finite scoped proposal accepts only the same Source/Pending and then uses the unchanged presented continuation.
- Cold/no-search entry uses ordinary readiness and does not spend an invented warm witness.
- begin validation, first apply validation, second apply validation and render validations have their actual distinct scopes; no new grant or deadline.
- Source/Pending/request replacement, finish/release/unmount, pre-effect book/Reader/window/query publication and ABA all refuse before further effects.
- Callback before the first actual parent validator cannot borrow an armed lease.
- Nested validator/read attempt closes the lease irreversibly; swallowing that nested error still makes the outer validator fail.
- Multiple sequential readiness reads in the one wrapped invocation are distinct from a second validator invocation; no allowance leaks past return or throw.
- The post-effect validator uses the existing presented-phone predicate, never the spent pre-effect lease.
- Generic TOC root/old anchors never acquire the new field-specific exception.
- Final settled field evidence remains required. Actual UIKit first-responder, VoiceOver, hardware keyboard and native acceptance remain unrun.
