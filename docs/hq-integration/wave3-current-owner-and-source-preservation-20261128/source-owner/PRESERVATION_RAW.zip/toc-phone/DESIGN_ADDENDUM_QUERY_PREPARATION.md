# Additive design and requirements note

This note does not rewrite PROOF.json, DESIGN.md, the baseline, candidate, or frozen patch.
The original phone proposal remains SOURCE_REVIEW_ACCEPTED by Root, UNCOMPILED, UNINTEGRATED, and NOT_RUN.

## Claim the query preparation before the callback-bearing capture

The proposed phone method captureOriginalParentPreEffectReadiness(requestID:) invokes the unchanged original validate(Source). That call can read original getters/callbacks.
Before calling it, the query owner must reserve a unique one-use parent-preparation identity while keeping its Source in the retained phase. The reservation must be tied to the SAME existing query Source, request, pending application and Root invocation.
A second capture/apply or a reentrant callback must permanently poison that exact preparation before returning refusal. If a nested error is caught by another callback, the outer preparation must still fail.
After the new phone capture returns, revalidate the SAME preparation and Source identity as well as the captured proof. Never recapture a current Source as a substitute.
Only after those checks may the query enter applying and call the full unchanged original parent closure. The original Core authority and deadline remain unchanged.
This is an integration requirement; the unavailable query source has not been rewritten or claimed to implement it. The read-only phone append cannot enforce the query owner's separate reservation.

## Required behavior and remaining acceptance

The target is the actual original TOC query field under the same original native.reader.toc parent, with exact finite anchor native.reader.toc.query. A destination/anchor declaration is not a field or focus witness.
The first proposed slice starts from the actual Viewer root, including its hidden or cold TOC. Foreign-root query continuation remains OPEN.
The original phone field is absent when its original filtered-list branch does not mount the standalone searchable content; this limitation remains OPEN. No synthetic field or new query-value write is permitted.
A manually focused, settled original UISearchController needs a separate passive finite-anchor metadata facet. An active retained Source must never fall back to that passive proof after retirement.
The required scoped first-parent-validator lease, retained-helper phase adjustment, passive warm facet, concrete Root readiness placement, and Nav's common/Notes source join are distinct integration obligations. This phone append alone completes none of those flows.
Original old TOC destinations/anchors/availability and generic component discovery must remain unchanged.
Actual Apple SDK compilation, original UIKit first-responder/geometry, system intent/URL execution, Hebrew/English, keyboard/VoiceOver and physical-device/production Release acceptance remain NOT_RUN.

## Unavailable source is not reconstructed

Latest known local query source pin: 38,462 bytes, SHA-256 59f2b638ef961479cf0ca8efb972cd949a67255142802d70ab81ed594f86623f.
Latest known local field source pin: 23,765 bytes, SHA-256 cf5fa39557a48db48456ed2f0f380f3180835480bf53858f55114c1d3266883a.
The local execution environment is unavailable. No full payload was recovered from the explicitly checked tool-state keys; this is not proof of global absence from every historical log.
Root reports its FFA779 logical manifest has no TOC/query source scope. No full query or field bytes are present in this remote proposal.
Only actual retained source bytes may be recovered later. The summaries and hashes are not substitutes, and these files must not be recreated from a summary.
Current Root docs-only HEAD reported 55845d215d8e6ff4559dab04ef63791920c4053a; product Source 182dd74229c04959cecae82a59d16268dcbd80bc remains the immutable87c product used here.
No Data capacity recovery or compiler admission is implied by this small source-document allocation.
