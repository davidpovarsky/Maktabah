#if os(iOS)
import Foundation
import Observation
import SwiftUI
import UIKit
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

/// The original root identity view owns this observation. Both UIKit references
/// are weak, and a detached older view cannot erase a newer registration.
@MainActor final class MaktabahNativeWindowSource {
    let nativePublication = NativeComponentSourcePublication()
    private weak var source: UIView?
    private weak var window: UIWindow?
    private var observationRevision: UInt64? = 0

    @discardableResult
    func observe(_ window: UIWindow?, from source: UIView) -> Bool {
        if window == nil {
            guard self.source === source else { return false }
            nativePublication.invalidateRetainedSources()
            self.source = nil; self.window = nil
            advanceObservation()
            return true
        }
        guard self.source !== source || self.window !== window else { return false }
        nativePublication.invalidateRetainedSources()
        self.source = source; self.window = window
        advanceObservation()
        return true
    }

    private func advanceObservation() {
        guard let revision = observationRevision, revision < .max else {
            observationRevision = nil; return
        }
        observationRevision = revision + 1
    }

    /// Retain identity before foreground/layout awaits. Actual presentation
    /// readiness remains the independent unchanged original predicate below.
    func retainOriginalWindow(in sceneID: UIStableID,
                              isCurrentSource: @escaping @MainActor () -> Bool) throws -> MaktabahNativeWindowObservation {
        guard let originalSource = source, let originalWindow = window,
              let revision = observationRevision,
              originalSource.window === originalWindow,
              originalWindow.windowScene?.session.persistentIdentifier == sceneID.rawValue,
              isCurrentSource(), source === originalSource, window === originalWindow,
              observationRevision == revision else {
            throw UIRouteError(.staleState, "native_original_window_source_unavailable")
        }
        return MaktabahNativeWindowObservation(window: originalWindow) { [weak self, weak originalSource] actual in
            guard let self, let originalSource,
                  self.source === originalSource, self.window === actual,
                  originalSource.window === actual, self.observationRevision == revision,
                  actual.windowScene?.session.persistentIdentifier == sceneID.rawValue,
                  isCurrentSource() else { return false }
            return self.source === originalSource && self.window === actual
                && originalSource.window === actual && self.observationRevision == revision
        }
    }

    func isPresentationReady(in sceneID: UIStableID) -> Bool {
        guard let source, let window, source.window === window,
              window.isKeyWindow, !window.isHidden, window.alpha >= 0.95,
              let scene = window.windowScene, scene.activationState == .foregroundActive,
              scene.session.persistentIdentifier == sceneID.rawValue,
              let root = window.rootViewController, root.viewIfLoaded?.window === window else { return false }
        // Read the original controller tree now, including the dismissal
        // interval after a SwiftUI sheet binding has already become false.
        var controllers = [root]
        while let controller = controllers.popLast() {
            guard controller.presentedViewController == nil,
                  !controller.isBeingPresented, !controller.isBeingDismissed,
                  controller.transitionCoordinator == nil else { return false }
            controllers.append(contentsOf: controller.children)
        }
        return true
    }
}

/// The RN sheet may cover the original root, but it never selects a tab, pops a
/// book or dismisses Settings. Retain those ORIGINAL publication histories at
/// +0, separately from the feature's runtime/React/host proof. Values stay in
/// their original owners; equal writes and A→B→A cannot renew this observation.
@MainActor private final class MaktabahNativeSefariaRootSource {
    private let observation: NativeComponentSourceObservation
    private let originalWindow: MaktabahNativeWindowObservation?
    private let annotationValidation: @MainActor () throws -> Void
    private let managerID: ObjectIdentifier
    private let root: MaktabahNativeRootPublicationSource
    private weak var workspacePresentation: MaktabahNativeWorkspacePresentationBinding?
    private let workspaceRevision: UInt64
    private let selectionRevision: UInt64
    private let settingsRevision: UInt64
    private let modeRevision: UInt64
    private let bookRevision: UInt64
    private let tab: iOSTab
    private let mode: AppMode
    private let bookID: ObjectIdentifier?
    private let bookMode: AppMode?

    static func isAvailable(_ bindings: MaktabahNativeSceneBindings,
                            workspace: MaktabahNativeWorkspacePresentationBinding?) -> Bool {
        bindings.rootPublications?.selectionRevision != nil
            && bindings.rootPublications?.settingsRevision != nil
            && bindings.manager.nativeModePresentationRevision != nil
            && bindings.manager.selectedBookPresentationRevision != nil
            && workspace?.originalStateRevision != nil
            && bindings.selectedTab.wrappedValue == bindings.selectedTab.wrappedValue.canonical
            && bindings.manager.currentMode == bindings.selectedTab.wrappedValue.appMode
            && !bindings.showSettings.wrappedValue && bindings.isPresentationReady
    }

    init(bindings: MaktabahNativeSceneBindings,
         workspace: MaktabahNativeWorkspacePresentationBinding,
         originalWindow: MaktabahNativeWindowObservation? = nil,
         windowPublication: NativeComponentSourcePublication? = nil,
         annotationPublication: NativeComponentSourcePublication,
         retainAnnotationObservation: @MainActor () throws -> (@MainActor () throws -> Void),
         readForeignPresentations: @MainActor () -> Void) throws {
        let manager = bindings.manager
        self.originalWindow = originalWindow
        let publications = [bindings.rootPublications?.nativePublication,
            manager.nativeModePresentationPublication, windowPublication, annotationPublication].compactMap { $0 }
        var retainedAnnotation: (@MainActor () throws -> Void)?
        var annotationError: (any Error)?
        let captured = NativeComponentSourceObservation(publications: publications) {
            // The fixed publisher is registered before the first original
            // modal getter. Its callback cannot make an old source current.
            do { retainedAnnotation = try retainAnnotationObservation() }
            catch { annotationError = error }
            _ = bindings.rootPublications?.selectionRevision; _ = bindings.rootPublications?.settingsRevision
            _ = manager.nativeModePresentationRevision; _ = manager.selectedBookPresentationRevision
            _ = manager.currentMode; _ = manager.selectedBook; _ = manager.selectedBookPresentationMode
            _ = manager.selectedBookForInfo; _ = manager.showingTabsList
            _ = manager.activeReaderViewModel?.isPopoverPresented
            _ = DonationManager.shared.showDonationSheet
            _ = bindings.sidebar?.overview.blocksRouting
            _ = workspace.originalStateRevision
            readForeignPresentations()
        }
        if let annotationError { throw annotationError }
        guard let retainedAnnotation else {
            throw UIRouteError(.unavailable, "native_sefaria_annotation_source_unavailable")
        }
        try captured.validate()
        observation = captured; annotationValidation = retainedAnnotation
        guard Self.isAvailable(bindings, workspace: workspace),
              let root = bindings.rootPublications,
              let selection = root.selectionRevision, let settings = root.settingsRevision,
              let mode = manager.nativeModePresentationRevision,
              let book = manager.selectedBookPresentationRevision,
              let workspaceRevision = workspace.originalStateRevision else {
            throw UIRouteError(.unavailable, "native_sefaria_original_root_unavailable")
        }
        self.root = root; managerID = ObjectIdentifier(manager)
        workspacePresentation = workspace; self.workspaceRevision = workspaceRevision
        selectionRevision = selection; settingsRevision = settings
        modeRevision = mode; bookRevision = book
        tab = bindings.selectedTab.wrappedValue; self.mode = manager.currentMode
        bookID = manager.selectedBook.map(ObjectIdentifier.init)
        bookMode = manager.selectedBookPresentationMode
        try validate(bindings, workspace: workspace)
    }

    func validate(_ bindings: MaktabahNativeSceneBindings,
                  workspace: MaktabahNativeWorkspacePresentationBinding?) throws {
        try observation.validate()
        _ = try originalWindow?.validate()
        try annotationValidation()
        try observation.validate()
        let manager = bindings.manager
        guard ObjectIdentifier(manager) == managerID, bindings.rootPublications === root,
              let workspace, workspacePresentation === workspace,
              workspace.originalStateRevision == workspaceRevision,
              root.selectionRevision == selectionRevision, root.settingsRevision == settingsRevision,
              manager.nativeModePresentationRevision == modeRevision,
              manager.selectedBookPresentationRevision == bookRevision,
              bindings.selectedTab.wrappedValue == tab, manager.currentMode == mode,
              manager.selectedBook.map(ObjectIdentifier.init) == bookID,
              manager.selectedBookPresentationMode == bookMode,
              !bindings.showSettings.wrappedValue, bindings.isPresentationReady else {
            throw UIRouteError(.staleState, "native_sefaria_original_root_changed")
        }
        try observation.validate()
        _ = try originalWindow?.validate()
        try annotationValidation()
        try observation.validate()
    }
    var claimObservation: NativeComponentSourceObservation { observation }
    func invalidate() { observation.invalidate() }
}

/// One instance per actual UIKit session. The app supplies the SAME directory /
/// S facade used by Core and its current lifetime validator at composition.
/// Native mutations remain behind P's canonical precommit guard.
@MainActor @Observable
final class MaktabahNativeSceneSession: NativeParentSelectionSceneDriver {
    let sceneID: UIStableID
    let presentation: NativePresentationObserver
    private(set) var submissionID: UUID?
    private(set) var mounted = true
    var foreground = false
    private let directory: NativeSceneDirectory
    private var project: @MainActor () throws -> MaktabahNativeSceneProjection
    private let bindings: MaktabahNativeSceneBindings
    let workspaceProjectionSource: MaktabahNativeWorkspaceProjectionSource?
    private(set) var workspacePresentation: MaktabahNativeWorkspacePresentationBinding?
    private(set) var phoneTOCPresentation: MaktabahNativePhoneTOCPresentationBinding?
    private(set) var sefariaSurfaceBinding: MaktabahNativeSefariaSurfaceBinding?
    @ObservationIgnored private var sefariaRootSources: [UUID: MaktabahNativeSefariaRootSource] = [:]
    @ObservationIgnored private var completedSefariaRootSource: MaktabahNativeSefariaRootSource?
    @ObservationIgnored private var retainedSefariaSurface = false
    @ObservationIgnored private var retainedPhoneTOC = false
    @ObservationIgnored private weak var forwardingWorkspaceOwner: MaktabahNativeWorkspaceOwner?
    @ObservationIgnored private var retainedWorkspaceParent: MaktabahNativeWorkspacePresentationBinding.Parent?
    private var lease: NativeSceneDirectory.Lease?
    private var command: UISceneCommand?
    @ObservationIgnored private var lastCompletedSurface: (route: RouteSpec, evidence: NativeSurfaceWitness.Evidence)?
    var readerBinding: MaktabahNativeReaderBinding?
    var searchResultsBinding: MaktabahNativeSearchResultsBinding?
    @ObservationIgnored private var searchContinuationOwner: MaktabahNativeSearchContinuationOwner?
    @ObservationIgnored private var publicSearchContinuationCatalog: MaktabahNativeSearchContinuationCatalog?
    @ObservationIgnored private var readerTabBinding: MaktabahNativeReaderTabBinding?
    @ObservationIgnored private var workspaceSelectionBinding: MaktabahNativeWorkspaceSelectionBinding?
    private(set) var viewerParentHost: MaktabahNativeViewerParentHost?
    @ObservationIgnored private var readerTabParentObservation: NativeOriginalParentObservation?
    @ObservationIgnored private var workspaceSelectionParentObservation: NativeOriginalParentObservation?
    @ObservationIgnored private weak var nativeSearchField: UISearchTextField?
    @ObservationIgnored private var retainedSearchField: UISearchTextField?
    private(set) var searchEntryBinding: MaktabahNativeSearchEntryBinding?
    private(set) var historyRecordBinding: MaktabahNativeHistoryRecordBinding?
    @ObservationIgnored private var retainedHistoryRecord = false
    private(set) var annotationEditorOpening: MaktabahNativeAnnotationEditorOpening?
    @ObservationIgnored private var retainedAnnotationEditorOpening = false
    private(set) var annotationEditorControls: MaktabahNativeAnnotationEditorControls?
    @ObservationIgnored private var retainedAnnotationEditor = false
    private(set) var annotationSelectionBinding: MaktabahNativeAnnotationSelectionBinding?
    @ObservationIgnored private var retainedAnnotationSelection = false
    private(set) var savedResultsBinding: MaktabahNativeSavedResultsBinding?
    @ObservationIgnored private var retainedSavedResults = false
    @ObservationIgnored private var searchFieldUpdateScheduled = false
    @ObservationIgnored private var inspectorBinding: MaktabahNativeInspectorBinding?
    @ObservationIgnored private var noteEditorOwner: MaktabahNativeNoteEditorOwner?
    @ObservationIgnored private var noteDraftBinding: MaktabahNativeNoteDraftBinding?
    @ObservationIgnored private var readerToolEditorPublicationRevision: UInt64? = 0
    private var searchFieldRevision: UInt64 = 0
    @ObservationIgnored private weak var windowSource: MaktabahNativeWindowSource?
    @ObservationIgnored private var windowSourceRevision: UInt64? = 0
    @ObservationIgnored let originalAnnotationPresentationPublication = NativeComponentSourcePublication()
    @ObservationIgnored private var annotationPresentationOwner: UUID?
    @ObservationIgnored private var annotationPresentationBlocked: (@MainActor () -> Bool)?
    @ObservationIgnored private var annotationPresentationPublicationRevision: UInt64? = 0
    @ObservationIgnored private var searchPresentationOwner: UUID?
    @ObservationIgnored private var searchPresentationPublicationRevision: UInt64? = 0
    @ObservationIgnored private var searchPresentationBlocked: (@MainActor () -> Bool)?
    @ObservationIgnored private var componentOwners: [UIDestinationID: MaktabahNativeComponentOwner] = [:]
    @ObservationIgnored private var retainedComponentOwner: MaktabahNativeComponentOwner?
    @ObservationIgnored private var componentValidation: (@MainActor (UISceneCommand) throws -> (@MainActor () throws -> Void))?
    @ObservationIgnored private var componentUpdateScheduled = false
    private var componentRevision: UInt64 = 0

    // Root owns construction/finite capture-slot wiring for these two fields.
    private(set) var tocQueryFocusBinding: MaktabahNativeTOCQueryFocusBinding?
    @ObservationIgnored private var tocQueryCaptureRequestID: UUID?
    @ObservationIgnored private var tocQueryCommonSource: TOCQueryCommonSource?
    @ObservationIgnored private weak var completedTOCQueryCommonSource: TOCQueryCommonSource?
    @ObservationIgnored private var tocQueryNoteAttachmentTransitions: Set<ObjectIdentifier> = []
    @ObservationIgnored private var tocQueryCommonUnmounting = false

    // MARK: TOC query common source (isolated, uncompiled proposal)
    //
    // The finite Root dispatch/canonical apply wiring is an external prerequisite.
    // This metadata never grants a UI effect, changes a deadline, or changes an
    // original readiness predicate. All original presentation remains with Phone
    // TOC / bindings and the exact query field owner.
    @MainActor
    private final class TOCQueryCommonSource {
        enum Phase: Equatable { case capturing, retained, bound, finished, retired }
        enum IdleRegistration: Equatable { case unavailable, eligible, claimed, joined, closed }
        let requestID: UUID
        let lease: NativeSceneDirectory.Lease
        let isPhone: Bool
        weak var query: MaktabahNativeTOCQueryFocusBinding?
        weak var manager: iOSNavigationManager?
        weak var workspace: MaktabahNativeWorkspacePresentationBinding?
        let hadWorkspace: Bool
        let workspaceRevision: UInt64?
        weak var annotationList: MaktabahNativeAnnotationSelectionBinding?
        let hadAnnotationList: Bool
        let annotationOwner: UUID?
        let annotationRevision: UInt64
        let searchOwner: UUID?
        let searchRevision: UInt64
        weak var notesOwner: MaktabahNativeNoteEditorOwner?
        var hadNotesOwner: Bool
        var notesRevision: UInt64
        let initiallyHadNotesOwner: Bool
        weak var phone: MaktabahNativePhoneTOCPresentationBinding?
        weak var reader: ReaderViewModel?
        var phoneWasMounted = false
        var window: MaktabahNativeWindowObservation?
        var search: (@MainActor () throws -> Void)?
        var annotations: (@MainActor () throws -> Void)?
        var phoneSource: (@MainActor () throws -> Void)?
        var foreignObservation: MaktabahNativeComponentSourceObservation?
        var readerObservation: MaktabahNativeComponentSourceObservation?
        var phase: Phase = .capturing
        var idleRegistration: IdleRegistration = .unavailable
        var command: UISceneCommand?
        var validating = false
        var parentStarted = false
        weak var attachment: TOCQueryNoteRegistration?

        init(requestID: UUID, lease: NativeSceneDirectory.Lease, isPhone: Bool,
             query: MaktabahNativeTOCQueryFocusBinding, manager: iOSNavigationManager,
             workspace: MaktabahNativeWorkspacePresentationBinding?, workspaceRevision: UInt64?,
             annotationList: MaktabahNativeAnnotationSelectionBinding?,
             annotationOwner: UUID?, annotationRevision: UInt64,
             searchOwner: UUID?, searchRevision: UInt64,
             notesOwner: MaktabahNativeNoteEditorOwner?, notesRevision: UInt64) {
            self.requestID = requestID; self.lease = lease; self.isPhone = isPhone
            self.query = query; self.manager = manager
            self.workspace = workspace; hadWorkspace = workspace != nil
            self.workspaceRevision = workspaceRevision
            self.annotationList = annotationList; hadAnnotationList = annotationList != nil
            self.annotationOwner = annotationOwner; self.annotationRevision = annotationRevision
            self.searchOwner = searchOwner; self.searchRevision = searchRevision
            self.notesOwner = notesOwner; hadNotesOwner = notesOwner != nil
            initiallyHadNotesOwner = notesOwner != nil; self.notesRevision = notesRevision
        }
        func retire() {
            phase = .retired; idleRegistration = .closed; attachment = nil
        }
    }

    /// One token for one actual non-idempotent original attach call. The Set in
    /// Session contains identities only; the original function's defer owns the
    /// token lifetime. A nested call cannot finish an outer call's transition.
    @MainActor
    private final class TOCQueryNoteRegistration {
        let id: UUID
        weak var reader: ReaderViewModel?
        var source: TOCQueryCommonSource?
        var nextRevision: UInt64?
        init(id: UUID, reader: ReaderViewModel) { self.id = id; self.reader = reader }
    }

    private static func sameTOCQueryObject<T: AnyObject>(_ current: T?, _ original: T?,
                                                        wasPresent: Bool) -> Bool {
        if wasPresent { return original != nil && current === original }
        return current == nil && original == nil
    }

    /// Pure metadata only: no original blockers, query validator, Reader getter,
    /// window getter, observation registration, or user callback.
    private func requireTOCQueryCommonMetadata(_ source: TOCQueryCommonSource,
        notesOwner: MaktabahNativeNoteEditorOwner?, hadNotesOwner: Bool,
        notesRevision: UInt64, attachment: TOCQueryNoteRegistration? = nil) throws {
        guard mounted, !tocQueryCommonUnmounting, source.phase != .retired,
              tocQueryCommonSource === source || completedTOCQueryCommonSource === source,
              lease == source.lease, source.lease.sceneID == sceneID,
              let query = source.query, tocQueryFocusBinding === query, query.sceneID == sceneID,
              let manager = source.manager, bindings.manager === manager,
              Self.sameTOCQueryObject(workspacePresentation, source.workspace, wasPresent: source.hadWorkspace),
              workspacePresentation?.originalStateRevision == source.workspaceRevision,
              Self.sameTOCQueryObject(annotationSelectionBinding, source.annotationList,
                                     wasPresent: source.hadAnnotationList),
              annotationPresentationOwner == source.annotationOwner,
              annotationPresentationPublicationRevision == source.annotationRevision,
              searchPresentationOwner == source.searchOwner,
              searchPresentationPublicationRevision == source.searchRevision,
              Self.sameTOCQueryObject(noteEditorOwner, notesOwner, wasPresent: hadNotesOwner),
              readerToolEditorPublicationRevision == notesRevision,
              noteDraftBinding == nil else {
            throw UIRouteError(.staleState, "native_toc_query_common_source_changed")
        }
        if let attachment {
            guard tocQueryNoteAttachmentTransitions.count == 1,
                  tocQueryNoteAttachmentTransitions.contains(ObjectIdentifier(attachment)),
                  attachment.source === source, source.attachment === attachment,
                  source.idleRegistration == .claimed, source.phase == .bound else {
                throw UIRouteError(.staleState, "native_toc_query_note_registration_changed")
            }
        } else {
            guard tocQueryNoteAttachmentTransitions.isEmpty,
                  source.idleRegistration != .claimed else {
                throw UIRouteError(.staleState, "native_toc_query_note_registration_in_progress")
            }
        }
        if source.isPhone {
            guard let phone = source.phone, phoneTOCPresentation === phone,
                  source.phase == .capturing || source.reader != nil else {
                throw UIRouteError(.staleState, "native_toc_query_phone_owner_changed")
            }
        }
        if let bound = source.command {
            guard bound.invocation.requestId == source.requestID,
                  bound.route.route.requestId == source.requestID,
                  bound.scene.sceneID == sceneID,
                  SystemActionClock().now() < bound.invocation.deadlineUptimeNanoseconds else {
                throw UIRouteError(.cancelled, "native_toc_query_common_deadline_or_request_changed")
            }
            if source.phase == .finished {
                guard (command == nil || command == bound),
                      (submissionID == nil || submissionID == source.requestID) else {
                    throw UIRouteError(.staleState, "native_toc_query_completed_command_replaced")
                }
            } else {
                guard command == bound, submissionID == source.requestID else {
                    throw UIRouteError(.staleState, "native_toc_query_bound_command_changed")
                }
            }
        } else if let current = command {
            // beginObservation assigns its command after all original begin
            // callbacks. The actual immutable command is bound only by the
            // canonical apply hook; this read grants no registration permission.
            guard source.phase == .retained,
                  current.invocation.requestId == source.requestID,
                  current.route.route.requestId == source.requestID,
                  current.scene.sceneID == sceneID,
                  submissionID == source.requestID,
                  current.route.route.destination.rawValue == "native.reader.toc",
                  current.route.route.focus?.kind == .component,
                  current.route.route.focus?.anchor?.rawValue == "native.reader.toc.query",
                  current.route.route.focus?.locator == nil,
                  current.route.route.focus?.range == nil,
                  SystemActionClock().now() < current.invocation.deadlineUptimeNanoseconds else {
                throw UIRouteError(.staleState, "native_toc_query_unbound_command_changed")
            }
        } else {
            guard source.phase == .capturing || source.phase == .retained,
                  submissionID == nil else {
                throw UIRouteError(.staleState, "native_toc_query_common_command_missing")
            }
        }
    }

    /// The wrapper's validate() also reads the original backend. This final
    /// read uses its SAME retained one-way latch only, after the last backend/
    /// window/getter callback; it does not capture or claim another observation.
    private func requireTOCQueryCommonLatches(_ source: TOCQueryCommonSource) throws {
        guard let foreign = source.foreignObservation, let reader = source.readerObservation else {
            throw UIRouteError(.staleState, "native_toc_query_common_latches_missing")
        }
        try foreign.retainedClaimObservation.validate()
        try reader.retainedClaimObservation.validate()
    }

    /// Brackets every callback-bearing original proof with the same complete
    /// metadata join. The last operation is the pure join, never another blocker.
    private func validateTOCQueryCommonSource(_ source: TOCQueryCommonSource,
        notesOwner: MaktabahNativeNoteEditorOwner? = nil, notesOverride: Bool = false,
        notesRevision: UInt64? = nil, attachment: TOCQueryNoteRegistration? = nil) throws {
        guard !source.validating, source.phase != .capturing, source.phase != .retired else {
            source.retire()
            throw UIRouteError(.staleState, "native_toc_query_common_validation_reentered")
        }
        source.validating = true
        defer { source.validating = false }
        let owner = notesOverride ? notesOwner : source.notesOwner
        let hadOwner = notesOverride ? notesOwner != nil : source.hadNotesOwner
        let revision = notesRevision ?? source.notesRevision
        func same() throws {
            try requireTOCQueryCommonMetadata(source, notesOwner: owner,
                hadNotesOwner: hadOwner, notesRevision: revision, attachment: attachment)
        }
        do {
            try Task.checkCancellation()
            try same()
            guard let window = source.window, let search = source.search,
                  let annotations = source.annotations, let observation = source.foreignObservation,
                  let readerObservation = source.readerObservation else {
                throw UIRouteError(.staleState, "native_toc_query_common_capture_incomplete")
            }
            _ = try window.validate(); try same()
            try search(); try same()
            try annotations(); try same()
            try observation.validate(); try same()
            try readerObservation.validate(); try same()
            if let phoneSource = source.phoneSource { try phoneSource(); try same() }
            guard let manager = source.manager else {
                throw UIRouteError(.staleState, "native_toc_query_common_manager_released")
            }
            guard let reader = source.reader, manager.activeReaderViewModel === reader else {
                throw UIRouteError(.staleState, "native_toc_query_original_reader_changed")
            }
            try same()
            guard studyChatPresentationID == nil, !hasOriginalWorkspacePresentation else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_workspace_presented")
            }
            try same()
            guard !hasOriginalSefariaSurface else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_sefaria_presented")
            }
            try same()
            guard savedResultsBinding?.isRequestedOrMounted != true else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_saved_results_presented")
            }
            try same()
            guard manager.selectedBookForInfo == nil, !manager.showingTabsList,
                  manager.alertMessage == nil, !DonationManager.shared.showDonationSheet,
                  source.reader?.isPopoverPresented != true,
                  source.reader?.readerInspectorVisible != true else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_reader_presentation")
            }
            try same()
            guard owner?.current == nil, owner?.presentationActive != true else {
                throw UIRouteError(.unavailable, "native_toc_query_original_notes_presented")
            }
            try same()
            _ = try window.validate(); try same()
            // Full wrapper validations include their original backend checks.
            // The SAME underlying latches are read again after those getters.
            try observation.validate(); try same()
            try readerObservation.validate(); try same()
            try requireTOCQueryCommonLatches(source)
            try Task.checkCancellation()
            try same()
        } catch { source.retire(); throw error }
    }

    func retainTOCQueryCommonSource() throws -> @MainActor () throws -> Void {
        if let current = tocQueryCommonSource {
            current.retire()
            throw UIRouteError(.staleState, "native_toc_query_common_capture_reentered")
        }
        guard mounted, !tocQueryCommonUnmounting, command == nil, submissionID == nil,
              tocQueryNoteAttachmentTransitions.isEmpty,
              let requestID = tocQueryCaptureRequestID, let lease,
              let query = tocQueryFocusBinding, query.sceneID == sceneID,
              let notesRevision = readerToolEditorPublicationRevision,
              let searchRevision = searchPresentationPublicationRevision,
              let annotationRevision = annotationPresentationPublicationRevision,
              workspacePresentation == nil || workspacePresentation?.originalStateRevision != nil,
              noteDraftBinding == nil else {
            throw UIRouteError(.unavailable, "native_toc_query_common_capture_unavailable")
        }
        completedTOCQueryCommonSource?.retire(); completedTOCQueryCommonSource = nil
        // Capture the ignored histories before ANY original callback getter.
        let source = TOCQueryCommonSource(requestID: requestID, lease: lease,
            isPhone: !MaktabahApp.isIpad, query: query, manager: bindings.manager,
            workspace: workspacePresentation, workspaceRevision: workspacePresentation?.originalStateRevision,
            annotationList: annotationSelectionBinding, annotationOwner: annotationPresentationOwner,
            annotationRevision: annotationRevision, searchOwner: searchPresentationOwner,
            searchRevision: searchRevision, notesOwner: noteEditorOwner, notesRevision: notesRevision)
        if source.isPhone { source.phone = phoneTOCPresentation }
        tocQueryCommonSource = source
        func sameCapture() throws {
            guard tocQueryCaptureRequestID == requestID, source.phase == .capturing,
                  !source.validating else {
                throw UIRouteError(.staleState, "native_toc_query_common_capture_changed")
            }
            source.validating = true
            defer { source.validating = false }
            func same() throws {
                try requireTOCQueryCommonMetadata(source, notesOwner: source.notesOwner,
                    hadNotesOwner: source.hadNotesOwner, notesRevision: source.notesRevision)
            }
            try same()
            // Only already-retained proofs are used here. A later callback may
            // invalidate an earlier one; finish with both latches and pure joins.
            if let window = source.window { _ = try window.validate(); try same() }
            if let observation = source.foreignObservation { try observation.validate(); try same() }
            if let observation = source.readerObservation { try observation.validate(); try same() }
            if let observation = source.foreignObservation { try observation.retainedClaimObservation.validate() }
            if let observation = source.readerObservation { try observation.retainedClaimObservation.validate() }
            try same()
        }
        do {
            try sameCapture()
            let manager = bindings.manager
            // Install non-Reader foreign history BEFORE phone/model/window/
            // blocker callbacks can open and close an unrelated presentation.
            source.foreignObservation = MaktabahNativeComponentSourceObservation { [weak self, weak manager] in
                guard let self, let manager else { return }
                _ = manager.selectedBookForInfo; _ = manager.showingTabsList; _ = manager.alertMessage
                _ = DonationManager.shared.showDonationSheet
                _ = self.studyChatPresentationID
                _ = self.hasOriginalSefariaSurface
                _ = self.savedResultsBinding?.isRequestedOrMounted
            }
            try sameCapture()
            source.window = try retainOriginalWindowObservation(); try sameCapture()
            if source.isPhone {
                guard let phone = source.phone else {
                    throw UIRouteError(.unavailable, "native_toc_query_phone_owner_missing")
                }
                source.phoneWasMounted = phone.isMounted
                source.reader = try phone.retainedReader()
                try sameCapture()
            } else {
                source.reader = manager.activeReaderViewModel
                try sameCapture()
            }
            guard let reader = source.reader else {
                throw UIRouteError(.unavailable, "native_toc_query_original_reader_missing")
            }
            // The original Reader is now known. Its own facet is installed
            // before the remaining original source/blocker getters.
            source.readerObservation = MaktabahNativeComponentSourceObservation { [weak reader] in
                _ = reader?.isPopoverPresented
                _ = reader?.readerInspectorVisible
            }
            try sameCapture()
            if let phone = source.phone {
                source.phoneSource = try phone.captureComponentSource()
                try sameCapture()
            }
            source.search = try retainHistorySearchPresentationObservation(); try sameCapture()
            source.annotations = try retainOriginalAnnotationPresentationObservation(); try sameCapture()
            source.phase = .retained
            try validateTOCQueryCommonSource(source)
            return { [weak self, source] in
                guard let self else {
                    source.retire()
                    throw UIRouteError(.staleState, "native_toc_query_common_session_released")
                }
                try self.validateTOCQueryCommonSource(source)
            }
        } catch {
            source.retire()
            if tocQueryCommonSource === source { tocQueryCommonSource = nil }
            throw error
        }
    }

    func bindTOCQueryCommonCommand(_ value: UISceneCommand) throws {
        guard let source = tocQueryCommonSource else {
            throw UIRouteError(.staleState, "native_toc_query_common_source_missing")
        }
        guard source.phase == .retained, !source.validating, source.command == nil,
              command == value, submissionID == source.requestID,
              value.invocation.requestId == source.requestID,
              value.route.route.requestId == source.requestID, value.scene.sceneID == sceneID,
              value.route.route.destination.rawValue == "native.reader.toc",
              value.route.route.focus?.kind == .component,
              value.route.route.focus?.anchor?.rawValue == "native.reader.toc.query",
              value.route.route.focus?.locator == nil, value.route.route.focus?.range == nil else {
            source.retire()
            throw UIRouteError(.staleState, "native_toc_query_common_bind_rejected")
        }
        // Consume the bind before any live callback. Failed validation is final.
        source.command = value; source.phase = .bound
        try validateTOCQueryCommonSource(source)
    }

    func applyOriginalTOCQueryPhoneParent(requestID: UUID,
        originalParent: @MainActor () throws -> Void) throws {
        guard let source = tocQueryCommonSource, source.requestID == requestID,
              source.isPhone, source.phase == .bound, !source.parentStarted else {
            tocQueryCommonSource?.retire()
            throw UIRouteError(.staleState, "native_toc_query_phone_parent_not_bound")
        }
        // This flag is metadata, not another effect grant. Canonical Core apply
        // is the only permitted caller; Root supplies its unchanged phone.apply.
        source.parentStarted = true
        do {
            try validateTOCQueryCommonSource(source)
            if !source.initiallyHadNotesOwner && !source.phoneWasMounted {
                guard source.notesRevision < UInt64.max, source.hadNotesOwner == false else {
                    throw UIRouteError(.unavailable, "native_toc_query_idle_note_revision_unavailable")
                }
                source.idleRegistration = .eligible
            }
            try originalParent()
            try validateTOCQueryCommonSource(source)
            // Eligible may remain only for this actual command's deferred
            // original Reader appearance, and never after finish/release.
        } catch { source.retire(); throw error }
    }

    private func beginTOCQueryIdleNoteRegistration(id: UUID, reader: ReaderViewModel,
        annotation: Binding<Annotation?>) -> TOCQueryNoteRegistration {
        let transition = TOCQueryNoteRegistration(id: id, reader: reader)
        tocQueryNoteAttachmentTransitions.insert(ObjectIdentifier(transition))
        guard let source = tocQueryCommonSource else {
            completedTOCQueryCommonSource?.retire()
            return transition
        }
        guard tocQueryNoteAttachmentTransitions.count == 1,
              source.phase == .bound, !source.validating,
              source.idleRegistration == .eligible, source.parentStarted,
              !source.initiallyHadNotesOwner, !source.hadNotesOwner,
              !source.phoneWasMounted, source.reader === reader,
              noteEditorOwner == nil, source.notesRevision < UInt64.max else {
            source.retire()
            return transition
        }
        // Claim BEFORE incoming annotation.get or any original validator.
        source.idleRegistration = .claimed; source.attachment = transition
        transition.source = source; transition.nextRevision = source.notesRevision + 1
        do {
            try validateTOCQueryCommonSource(source, attachment: transition)
            guard let phone = source.phone,
                  phone.isContinuingOriginalReaderPresentation(requestID: source.requestID) else {
                throw UIRouteError(.staleState, "native_toc_query_idle_note_parent_not_presented")
            }
            try requireTOCQueryCommonLatches(source)
            try requireTOCQueryCommonMetadata(source, notesOwner: nil, hadNotesOwner: false,
                notesRevision: source.notesRevision, attachment: transition)
            guard annotation.wrappedValue == nil else {
                throw UIRouteError(.unavailable, "native_toc_query_incoming_note_not_idle")
            }
            try validateTOCQueryCommonSource(source, attachment: transition)
        } catch { source.retire() }
        return transition
    }

    private func endTOCQueryIdleNoteRegistration(_ transition: TOCQueryNoteRegistration) {
        defer { tocQueryNoteAttachmentTransitions.remove(ObjectIdentifier(transition)) }
        guard let source = transition.source else { return }
        guard source.phase == .bound, source.idleRegistration == .claimed,
              source.attachment === transition, !source.validating,
              let reader = transition.reader, source.reader === reader,
              let owner = noteEditorOwner, owner.id == transition.id, owner.reader === reader,
              let next = transition.nextRevision,
              readerToolEditorPublicationRevision == next else {
            source.retire()
            return
        }
        do {
            try validateTOCQueryCommonSource(source, notesOwner: owner, notesOverride: true,
                notesRevision: next, attachment: transition)
            guard let phone = source.phone,
                  phone.isContinuingOriginalReaderPresentation(requestID: source.requestID) else {
                throw UIRouteError(.staleState, "native_toc_query_idle_note_parent_changed")
            }
            try requireTOCQueryCommonMetadata(source, notesOwner: owner, hadNotesOwner: true,
                notesRevision: next, attachment: transition)
            guard owner.current == nil, !owner.presentationActive, owner.textView == nil else {
                throw UIRouteError(.staleState, "native_toc_query_registered_note_not_idle")
            }
            try requireTOCQueryCommonLatches(source)
            try requireTOCQueryCommonMetadata(source, notesOwner: owner, hadNotesOwner: true,
                notesRevision: next, attachment: transition)
            // No callback follows this exact one-use publication. The defer then
            // removes only this transition; no nested call can rearm the source.
            source.notesOwner = owner; source.hadNotesOwner = true; source.notesRevision = next
            source.idleRegistration = .joined; source.attachment = nil
        } catch { source.retire() }
    }

    func finishTOCQueryCommonSource(requestID: UUID, completed: Bool) {
        guard let source = tocQueryCommonSource, source.requestID == requestID else { return }
        // Close BEFORE any callback-bearing original owner.finish invocation.
        if source.idleRegistration == .eligible { source.idleRegistration = .closed }
        guard completed, source.phase == .bound, !source.validating,
              source.idleRegistration != .claimed, source.command != nil else {
            source.retire(); return
        }
        do {
            try requireTOCQueryCommonLatches(source)
            try requireTOCQueryCommonMetadata(source, notesOwner: source.notesOwner,
                hadNotesOwner: source.hadNotesOwner, notesRevision: source.notesRevision)
            source.phase = .finished
        } catch { source.retire() }
    }

    func releaseTOCQueryCommonSource(requestID: UUID) {
        guard let source = tocQueryCommonSource, source.requestID == requestID else { return }
        if source.idleRegistration == .eligible { source.idleRegistration = .closed }
        if source.phase == .finished, !source.validating {
            completedTOCQueryCommonSource?.retire()
            completedTOCQueryCommonSource = source
        } else { source.retire() }
        if tocQueryCommonSource === source { tocQueryCommonSource = nil }
    }

    func unmountTOCQueryCommonSource() {
        // This permanent metadata flag closes capture while the original unmount
        // body still has mounted=true and publishes its foreign callbacks.
        tocQueryCommonUnmounting = true
        tocQueryCommonSource?.retire(); tocQueryCommonSource = nil
        completedTOCQueryCommonSource?.retire(); completedTOCQueryCommonSource = nil
        // Do not clear attachment identities here: each actual attach defer
        // removes its own token, including when unmount reenters that call.
    }

    func componentOwner(for destination: UIDestinationID) -> MaktabahNativeComponentOwner? { componentOwners[destination] }

    func forwardRouting(to owner: MaktabahNativeWorkspaceOwner) throws {
        guard usesWorkspaceOwner(owner) else { throw UIRouteError(.staleState, "native_workspace_owner_changed") }
        try owner.attachNativeRoutingSession(self)
        forwardingWorkspaceOwner = owner
    }

    /// The original parent source is retained before its component source and
    /// before any public binding/Core await. Read-only discovery does not retain.
    func retainParentSource(destination: UIDestinationID, requestID: UUID) throws {
        if destination == MaktabahNativeAnnotationEditorControls.destination {
            guard mounted, isOriginalAnnotationEditorRootReady, let original = annotationEditorControls else {
                throw UIRouteError(.unavailable, "original_annotation_editor_owner_missing")
            }
            try original.retainSource(requestID: requestID)
            return
        }
        if destination == MaktabahNativeSavedResultsBinding.destination {
            guard mounted, let original = savedResultsBinding else {
                throw UIRouteError(.unavailable, "native_saved_results_owner_missing")
            }
            try original.retain(record: nil, requestID: requestID)
            return
        }
        if MaktabahNativeSefariaSurfaceBinding.accepts(destination) {
            guard mounted, foreground, isPresentationReady(for: destination),
                  sefariaRootSources[requestID] == nil,
                  let original = sefariaSurfaceBinding, let workspacePresentation else {
                throw UIRouteError(.unavailable, "native_sefaria_parent_unavailable")
            }
            let target = MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: destination)
            let originalWindow = try target.map { _ in try retainOriginalWindowObservation() }
            let originalWindowSource = windowSource
            let root = try MaktabahNativeSefariaRootSource(bindings: bindings, workspace: workspacePresentation,
                originalWindow: originalWindow,
                windowPublication: target == nil ? nil : originalWindowSource?.nativePublication,
                annotationPublication: originalAnnotationPresentationPublication,
                retainAnnotationObservation: { [weak self] in
                    guard let self else {
                        throw UIRouteError(.staleState, "native_sefaria_annotation_owner_released")
                    }
                    return try self.retainOriginalAnnotationPresentationObservation()
                }) { [weak self] in
                guard let self else { return }
                _ = mounted; _ = foreground; _ = studyChatPresentationID
                // The original note editor owns SwiftUI State, not Observable
                // fields. Its exact setter invalidates this source synchronously.
            }
            try original.retainSource(requestID: requestID, target: target,
                parentClaimObservation: target == nil ? nil : root.claimObservation)
            do { try root.validate(bindings, workspace: workspacePresentation) }
            catch { original.releaseSource(requestID: requestID); throw error }
            sefariaRootSources[requestID] = root
            return
        }
        if usesOriginalPhoneTOC(destination) {
            guard mounted, foreground, isPresentationReady(for: destination), let phoneTOCPresentation else {
                throw UIRouteError(.unavailable, "native_phone_toc_parent_unavailable")
            }
            try phoneTOCPresentation.retainSource(requestID: requestID)
            return
        }
        guard let parent = MaktabahNativeWorkspacePresentationBinding.Parent(rawValue: destination.rawValue) else { return }
        guard mounted, foreground, isPresentationReady(for: destination), let workspacePresentation else {
            throw UIRouteError(.unavailable, "native_workspace_parent_unavailable")
        }
        try workspacePresentation.retainSource(parent: parent, requestID: requestID)
    }
    func validateParentSource(destination: UIDestinationID, requestID: UUID) throws {
        if destination == MaktabahNativeAnnotationEditorOpening.destination {
            guard let original = annotationEditorOpening else {
                throw UIRouteError(.staleState, "original_annotation_editor_opening_detached")
            }
            try original.validateSource(requestID: requestID)
            return
        }
        if destination == MaktabahNativeAnnotationEditorControls.destination {
            guard let original = annotationEditorControls else {
                throw UIRouteError(.staleState, "original_annotation_editor_owner_detached")
            }
            try original.validateSource(requestID: requestID)
            return
        }
        if destination == MaktabahNativeAnnotationSelectionBinding.destination {
            guard let original = annotationSelectionBinding else {
                throw UIRouteError(.staleState, "native_annotation_owner_detached")
            }
            try original.validateSource(requestID: requestID)
            return
        }
        if destination == MaktabahNativeSavedResultsBinding.destination {
            guard let original = savedResultsBinding else {
                throw UIRouteError(.staleState, "native_saved_results_owner_detached")
            }
            try original.validateSource(requestID: requestID)
            return
        }
        if MaktabahNativeSefariaSurfaceBinding.accepts(destination) {
            guard let original = sefariaSurfaceBinding, let root = sefariaRootSources[requestID] else {
                throw UIRouteError(.staleState, "native_sefaria_parent_not_retained")
            }
            try root.validate(bindings, workspace: workspacePresentation)
            try original.validateSource(requestID: requestID,
                target: MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: destination))
            guard sefariaRootSources[requestID] === root else {
                throw UIRouteError(.staleState, "native_sefaria_parent_released")
            }
            return
        }
        if usesOriginalPhoneTOC(destination) {
            guard let phoneTOCPresentation else { throw UIRouteError(.staleState, "native_phone_toc_parent_detached") }
            try phoneTOCPresentation.validateSource(requestID: requestID)
            return
        }
        guard let parent = MaktabahNativeWorkspacePresentationBinding.Parent(rawValue: destination.rawValue) else { return }
        guard let workspacePresentation else { throw UIRouteError(.staleState, "native_workspace_parent_detached") }
        try workspacePresentation.validateSource(parent: parent, requestID: requestID)
    }
    func releaseParentSource(destination: UIDestinationID, requestID: UUID) {
        if destination == MaktabahNativeAnnotationEditorControls.destination {
            annotationEditorControls?.releaseSource(requestID: requestID)
            return
        }
        if destination == MaktabahNativeSavedResultsBinding.destination {
            savedResultsBinding?.releaseSource(requestID: requestID)
            return
        }
        if MaktabahNativeSefariaSurfaceBinding.accepts(destination) {
            if let root = sefariaRootSources.removeValue(forKey: requestID), root !== completedSefariaRootSource {
                root.invalidate()
            }
            sefariaSurfaceBinding?.releaseSource(requestID: requestID)
            return
        }
        if usesOriginalPhoneTOC(destination) {
            phoneTOCPresentation?.releaseSource(requestID: requestID)
            return
        }
        guard MaktabahNativeWorkspacePresentationBinding.Parent(rawValue: destination.rawValue) != nil else { return }
        workspacePresentation?.releaseSource(requestID: requestID)
    }
    func retainComponentSource(destination: UIDestinationID, anchor: UIDestinationID, requestID: UUID) throws -> MaktabahNativeComponentOwner {
        guard let owner = componentOwners[destination] else { throw UIRouteError(.notSupported, "native_component_not_installed") }
        let searchEntry = destination == MaktabahNativeSearchEntryBinding.destination
            && anchor == MaktabahNativeSearchEntryBinding.anchor
        if searchEntry {
            guard let searchEntryBinding, searchEntryBinding.owner === owner else {
                throw UIRouteError(.unavailable, "native_search_entry_source_missing")
            }
            try searchEntryBinding.retainSource(requestID: requestID)
        }
        do { try owner.retainSource(requestID: requestID, anchor: anchor) }
        catch {
            if searchEntry { searchEntryBinding?.releaseSource(requestID: requestID) }
            throw error
        }
        return owner
    }
    func releaseComponentSource(_ owner: MaktabahNativeComponentOwner, requestID: UUID) {
        if tocQueryFocusBinding?.owner === owner { releaseTOCQueryCommonSource(requestID: requestID) }
        owner.releaseSource(requestID: requestID)
        if searchEntryBinding?.owner === owner { searchEntryBinding?.releaseSource(requestID: requestID) }
    }
    func validateComponentSource(destination: UIDestinationID, anchor: UIDestinationID, requestID: UUID) throws {
        if destination == NativeSearchFieldVisibility.destination, anchor == NativeSearchFieldVisibility.focus.anchor { return }
        guard let owner = componentOwners[destination] else { throw UIRouteError(.notSupported, "native_component_not_installed") }
        try owner.validateSource(requestID: requestID, anchor: anchor)
    }
    func attachComponentOwner(_ owner: MaktabahNativeComponentOwner) {
        guard componentOwners[owner.destination] == nil else { return }
        componentOwners[owner.destination] = owner
        owner.install(changed: { [weak self, weak owner] in
            guard let self, let owner else { return }
            componentStateDidChange(owner)
        }, invalidated: { [weak self] in self?.presentation.revoke() })
    }
    func detachComponentOwner(_ owner: MaktabahNativeComponentOwner) {
        guard componentOwners[owner.destination] === owner else { return }
        owner.retirePresentation(); componentOwners.removeValue(forKey: owner.destination)
        try? nativeStateChanged()
    }
    func configureComponentValidation(_ validation: @escaping @MainActor (UISceneCommand) throws -> (@MainActor () throws -> Void)) {
        componentValidation = validation
    }
    func componentStateDidChange(_ owner: MaktabahNativeComponentOwner) {
        guard mounted, componentOwners[owner.destination] === owner else { return }
        originalPresentationStateDidChange()
    }
    private func originalPresentationStateDidChange() {
        guard mounted else { return }
        try? nativeStateChanged()
        // UIKit layout may call this while SwiftUI updates. Only the graph
        // notification is deferred; ownership invalidation is synchronous.
        guard !componentUpdateScheduled else { return }
        componentUpdateScheduled = true
        Task { @MainActor [weak self] in
            guard let self else { return }
            componentUpdateScheduled = false; componentRevision &+= 1
        }
    }

    func attachWindowSource(_ source: MaktabahNativeWindowSource) {
        guard mounted else { return }
        if windowSource !== source {
            // Retire the old exact owner before publishing its replacement;
            // the queued native-to-JS handoff cannot borrow the old window.
            sefariaRootSources.values.forEach { $0.invalidate() }
            completedSefariaRootSource?.invalidate()
            if let revision = windowSourceRevision, revision < .max { windowSourceRevision = revision + 1 }
            else { windowSourceRevision = nil }
        }
        windowSource = source
    }
    func retainOriginalWindowObservation() throws -> MaktabahNativeWindowObservation {
        guard mounted, let originalSource = windowSource, let revision = windowSourceRevision else {
            throw UIRouteError(.staleState, "native_original_window_source_unavailable")
        }
        return try originalSource.retainOriginalWindow(in: sceneID) { [weak self, weak originalSource] in
            guard let self, let originalSource else { return false }
            return self.mounted && self.windowSource === originalSource && self.windowSourceRevision == revision
        }
    }
    func nativeWindowDidChange(_ source: MaktabahNativeWindowSource) {
        guard mounted, windowSource === source else { return }
        readerTabBinding?.invalidate()
        workspaceSelectionBinding?.invalidate()
        viewerParentHost?.originalWindowSourceDidChange()
        searchContinuationOwner?.retire()
        publicSearchContinuationCatalog?.retire()
        searchEntryBinding?.retire()
        historyRecordBinding?.retire()
        savedResultsBinding?.retire()
        annotationSelectionBinding?.retire()
        annotationEditorControls?.retire()
        annotationEditorOpening?.retire()
        sefariaRootSources.values.forEach { $0.invalidate() }
        completedSefariaRootSource?.invalidate()
        presentation.revoke()
        try? nativeStateChanged()
    }
    /// The original list's existing modal State owner, not a second UI model.
    /// Equal modal writes and owner A-B-A all invalidate retained sources.
    func observeAnnotationPresentation(owner: UUID, isBlocked: @escaping @MainActor () -> Bool) {
        guard mounted else { return }
        if annotationPresentationOwner != owner {
            advanceOriginalAnnotationPresentationPublication()
            annotationPresentationOwner = owner; annotationPresentationBlocked = isBlocked
            annotationSelectionBinding?.retire()
            annotationEditorOpening?.retire()
        } else { annotationPresentationBlocked = isBlocked }
    }
    func originalAnnotationPresentationWillChange(owner: UUID) {
        guard mounted, annotationPresentationOwner == owner else { return }
        annotationEditorOpening?.originalModalWillChange(owner: owner)
        advanceOriginalAnnotationPresentationPublication()
        annotationSelectionBinding?.originalModalWillChange(owner: owner)
    }
    func removeAnnotationPresentation(owner: UUID) {
        guard annotationPresentationOwner == owner else { return }
        advanceOriginalAnnotationPresentationPublication()
        let revision = annotationPresentationPublicationRevision
        annotationSelectionBinding?.retire()
        // The original list can be covered by its own editor/import/export
        // presentation. Preserve its blocker until that actual owner clears it.
        guard annotationPresentationBlocked?() != true,
              annotationPresentationOwner == owner,
              annotationPresentationPublicationRevision == revision else { return }
        annotationPresentationOwner = nil; annotationPresentationBlocked = nil
    }
    private func advanceOriginalAnnotationPresentationPublication() {
        // Fixed weak one-way latches only. No user/State callback runs under a
        // source lock; RN claims can be refused before the original setter.
        originalAnnotationPresentationPublication.invalidateRetainedSources()
        defer { annotationEditorControls?.retire() }
        guard let revision = annotationPresentationPublicationRevision, revision < .max else {
            annotationPresentationPublicationRevision = nil
            return
        }
        annotationPresentationPublicationRevision = revision + 1
    }
    private var hasOriginalAnnotationPresentation: Bool {
        guard let revision = annotationPresentationPublicationRevision else { return true }
        let owner = annotationPresentationOwner
        let blocked = annotationPresentationBlocked?() == true
            || annotationSelectionBinding?.hasOriginalUIKitPresentation == true
        return blocked || annotationPresentationPublicationRevision != revision || annotationPresentationOwner != owner
    }
    /// Retain before foreground activation. The caller must register the fixed
    /// originalAnnotationPresentationPublication BEFORE this first getter if it
    /// needs a synchronous off-MainActor claim (RN); this closure is no grant.
    func retainOriginalAnnotationPresentationObservation() throws -> @MainActor () throws -> Void {
        guard mounted, let revision = annotationPresentationPublicationRevision else {
            throw UIRouteError(.unavailable, "original_annotation_presentation_unavailable")
        }
        let owner = annotationPresentationOwner
        let originalList = annotationSelectionBinding
        let validate: @MainActor () throws -> Void = { [weak self, weak originalList] in
            guard let self, self.mounted,
                  self.annotationSelectionBinding === originalList,
                  originalList?.hasOriginalUIKitPresentation != true,
                  self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  self.annotationPresentationBlocked?() != true else {
                throw UIRouteError(.staleState, "original_annotation_presentation_changed")
            }
            // The original blocker is a getter callback. It may publish a new
            // owner/state; final equality alone cannot restore that source.
            guard self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  self.annotationSelectionBinding === originalList,
                  originalList?.hasOriginalUIKitPresentation != true else {
                throw UIRouteError(.staleState, "original_annotation_presentation_changed")
            }
        }
        try validate()
        return validate
    }

    /// This finite internal facet describes the ALREADY OPEN original List
    /// editor. The public URL carries no owner/record/draft identity.
    private func retainOriginalAnnotationEditorPresentationObservation(owner: UUID) throws
        -> @MainActor () throws -> Void {
        guard mounted, let revision = annotationPresentationPublicationRevision,
              annotationPresentationOwner == owner, let original = annotationEditorControls,
              original.originalListOwner == owner else {
            throw UIRouteError(.unavailable, "original_annotation_editor_parent_unavailable")
        }
        let validate: @MainActor () throws -> Void = { [weak self, weak original] in
            guard let self, let original, self.mounted,
                  self.annotationEditorControls === original,
                  self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  original.originalListOwner == owner,
                  self.annotationPresentationBlocked?() == true,
                  original.isAvailable() else {
                throw UIRouteError(.staleState, "original_annotation_editor_parent_changed")
            }
            // Both getters above may synchronously publish/detach an owner.
            guard self.mounted, self.annotationEditorControls === original,
                  self.annotationPresentationPublicationRevision == revision,
                  self.annotationPresentationOwner == owner,
                  original.originalListOwner == owner else {
                throw UIRouteError(.staleState, "original_annotation_editor_parent_changed")
            }
        }
        try validate()
        return validate
    }

    /// Exact opening exception. One original Edit publication and at most one
    /// matching List coverage publication; all other owner/State changes fail.
    private func retainOriginalAnnotationOpeningPresentationObservation(owner: UUID,
        annotation: Annotation, requestID: UUID) throws -> @MainActor () throws -> Void {
        guard mounted, let revision = annotationPresentationPublicationRevision, revision < .max,
              annotationPresentationOwner == owner, let opening = annotationEditorOpening,
              let originalList = annotationSelectionBinding,
              !originalList.hasOriginalUIKitPresentation else {
            throw UIRouteError(.unavailable, "original_annotation_opening_parent_unavailable")
        }
        let validate: @MainActor () throws -> Void = { [weak self, weak opening, weak originalList] in
            guard let self, let opening, let originalList, self.mounted,
                  self.annotationEditorOpening === opening, self.annotationSelectionBinding === originalList,
                  self.annotationPresentationOwner == owner,
                  opening.allowsOriginalPresentationRevision(requestID: requestID, owner: owner,
                    initial: revision, current: self.annotationPresentationPublicationRevision) else {
                throw UIRouteError(.staleState, "original_annotation_opening_parent_changed")
            }
            let editing = try opening.originalListIsEditing(requestID: requestID, owner: owner, annotation: annotation)
            guard self.annotationPresentationBlocked?() == editing,
                  editing || !originalList.hasOriginalUIKitPresentation else {
                throw UIRouteError(.staleState, "original_annotation_opening_parent_changed")
            }
            // Recheck both the callback's original owner and monotonic revision.
            guard self.mounted, self.annotationEditorOpening === opening,
                  self.annotationSelectionBinding === originalList, self.annotationPresentationOwner == owner,
                  opening.allowsOriginalPresentationRevision(requestID: requestID, owner: owner,
                    initial: revision, current: self.annotationPresentationPublicationRevision),
                  try opening.originalListIsEditing(requestID: requestID, owner: owner, annotation: annotation) == editing,
                  editing || !originalList.hasOriginalUIKitPresentation else {
                throw UIRouteError(.staleState, "original_annotation_opening_parent_changed")
            }
        }
        try validate()
        return validate
    }

    func observeSearchPresentation(owner: UUID, isBlocked: @escaping @MainActor () -> Bool) {
        guard mounted else { return }
        if searchPresentationOwner != owner {
            advanceOriginalSearchPresentationPublication()
            searchContinuationOwner?.retire(); publicSearchContinuationCatalog?.retire()
        }
        searchEntryBinding?.observeOriginalPresentation(owner: owner)
        searchPresentationOwner = owner; searchPresentationBlocked = isBlocked
    }
    func originalSearchPresentationWillChange(owner: UUID) {
        if searchPresentationOwner == owner { advanceOriginalSearchPresentationPublication() }
        searchEntryBinding?.originalPresentationWillChange(owner: owner)
        if searchPresentationOwner == owner {
            searchContinuationOwner?.retire()
            publicSearchContinuationCatalog?.retire()
            historyRecordBinding?.originalForeignStateWillChange()
        }
    }
    func renderSearchEntryFromOriginalView() {
        guard mounted, foreground else { return }
        searchEntryBinding?.renderOriginalFieldIfReady()
    }
    func removeSearchPresentation(owner: UUID) {
        guard searchPresentationOwner == owner else { return }
        advanceOriginalSearchPresentationPublication()
        searchContinuationOwner?.retire()
        publicSearchContinuationCatalog?.retire()
        searchEntryBinding?.originalPresentationDidDisappear(owner: owner)
        // A hidden Search tab can retain its opaque FTS overlay state. Keep
        // that original blocker until the actual owner clears/replaces it;
        // reopening Search semantically must not submit behind a restored mask.
        guard searchPresentationBlocked?() != true else { return }
        searchPresentationOwner = nil; searchPresentationBlocked = nil
    }
    private func advanceOriginalSearchPresentationPublication() {
        // This original foreign State publication cannot rearm an annotation source.
        defer { annotationSelectionBinding?.retire(); annotationEditorControls?.retire(); annotationEditorOpening?.retire() }
        guard let revision = searchPresentationPublicationRevision, revision < .max else {
            searchPresentationPublicationRevision = nil
            return
        }
        searchPresentationPublicationRevision = revision + 1
    }

    /// Original Search State publications include its existing Saved Results,
    /// Save and FTS presentations. Retain their history before foreground waits:
    /// an open/close or owner replacement cannot restore an earlier observation.
    /// This reads the original owner and never changes its UI or grants access.
    private func retainHistorySearchPresentationObservation() throws -> @MainActor () throws -> Void {
        guard mounted, let revision = searchPresentationPublicationRevision else {
            throw UIRouteError(.unavailable, "history_reader_search_presentation_unavailable")
        }
        let owner = searchPresentationOwner
        let validate: @MainActor () throws -> Void = { [weak self] in
            guard let self, self.mounted,
                  self.searchPresentationPublicationRevision == revision,
                  self.searchPresentationOwner == owner,
                  self.searchPresentationBlocked?() != true else {
                throw UIRouteError(.staleState, "history_reader_search_presentation_changed")
            }
            // The original blocker is a callback. It cannot publish a new
            // owner/state and then return a value that rearms this observation.
            guard self.searchPresentationPublicationRevision == revision,
                  self.searchPresentationOwner == owner else {
                throw UIRouteError(.staleState, "history_reader_search_presentation_changed")
            }
        }
        try validate()
        return validate
    }

    private func validateSearchPresentation() throws {
        guard windowSource?.isPresentationReady(in: sceneID) == true,
              searchPresentationBlocked?() != true else {
            throw UIRouteError(.unavailable, "native_search_presentation_in_progress")
        }
    }

    // This is the original scene-owned UIKit control, installed by its existing
    // representable. No lookup through global windows or runtime class names.
    func attachSearchField(_ field: UISearchTextField) {
        guard nativeSearchField !== field else { return }
        if retainedSearchField != nil { presentation.revoke() }
        nativeSearchField = field
        searchEntryBinding?.attachOriginalField(field)
        searchFieldStateDidChange(field)
    }

    func detachSearchField(_ field: UISearchTextField) {
        guard nativeSearchField === field else { return }
        searchEntryBinding?.detachOriginalField(field)
        if retainedSearchField === field { presentation.revoke() }
        nativeSearchField = nil
        // Ownership invalidation is synchronous even if the SwiftUI graph has
        // not rendered yet, including detach/reattach ABA during Core awaits.
        try? nativeStateChanged()
        scheduleSearchFieldObservation()
    }

    func searchFieldStateDidChange(_ field: UISearchTextField) {
        guard nativeSearchField === field else { return }
        searchEntryBinding?.originalFieldStateDidChange(field)
        try? nativeStateChanged()
        scheduleSearchFieldObservation()
    }
    func searchFieldDidLayout(_ field: UISearchTextField) {
        guard nativeSearchField === field else { return }
        searchEntryBinding?.originalFieldDidLayout(field)
    }

    private func scheduleSearchFieldObservation() {
        // UIKit attachment can happen inside updateUIView. Only the graph
        // notification is deferred; the original directory revision has already
        // changed synchronously above. Never defer authority invalidation.
        guard !searchFieldUpdateScheduled else { return }
        searchFieldUpdateScheduled = true
        Task { @MainActor [weak self] in
            guard let self else { return }
            searchFieldUpdateScheduled = false
            searchFieldRevision &+= 1
        }
    }

    private var searchFieldAvailable: Bool {
        guard mounted, foreground, isPresentationReady, let field = nativeSearchField,
              (try? project().surface(.search)) != nil,
              let evidence = visibilityChecks[NativeSearchFieldVisibility.destination]?(),
              evidence.isVisible, evidence.sceneID == sceneID,
              evidence.surface.destination == NativeSearchFieldVisibility.destination else { return false }
        return NativeSearchFieldVisibility.isVisible(field, in: sceneID)
    }
    private var visible: [UIDestinationID: NativeSurfaceWitness.Evidence] = [:]
    @ObservationIgnored private var visibilityChecks: [UIDestinationID: @MainActor () -> NativeSurfaceWitness.Evidence?] = [:]
    private(set) var studyChatPresentationID: UUID?
    private var hasOriginalWorkspacePresentation: Bool {
        guard let workspacePresentation else { return false }
        return MaktabahNativeWorkspacePresentationBinding.Parent.allCases.contains {
            let actual = workspacePresentation.presentationFacets(for: $0)
            return actual.requested || actual.mounted || actual.transitioning
        }
    }
    private var hasOriginalSefariaSurface: Bool {
        guard let actual = sefariaSurfaceBinding?.presentationFacets else { return false }
        return actual.requested || actual.mounted || actual.transitioning
    }
    private var isSefariaOriginalRootReady: Bool {
        !hasOriginalAnnotationPresentation && mounted && foreground && !bindings.showSettings.wrappedValue && bindings.isPresentationReady
            && !hasOriginalWorkspacePresentation && studyChatPresentationID == nil
            && noteEditorOwner?.current == nil && noteEditorOwner?.presentationActive != true
            && MaktabahNativeSefariaRootSource.isAvailable(bindings, workspace: workspacePresentation)
    }
    var isPresentationReady: Bool {
        readerTabBinding == nil && workspaceSelectionBinding == nil && bindings.isPresentationReady && !hasOriginalAnnotationPresentation && !hasOriginalWorkspacePresentation && !hasOriginalSefariaSurface
            && savedResultsBinding?.isRequestedOrMounted != true
            && studyChatPresentationID == nil
            && ((noteEditorOwner?.current == nil && noteEditorOwner?.presentationActive != true)
                || (command?.route.route.destination.rawValue == "native.reader.noteDraft" && noteDraftBinding?.isApplied == true))
    }

    private func usesOriginalPhoneTOC(_ destination: UIDestinationID) -> Bool {
        !MaktabahApp.isIpad && destination == MaktabahNativeTOCComponents.destination
    }

    /// Stable original Workspace sheets may navigate their own components.
    /// Every unrelated modal keeps the existing blockers. A transition can be
    /// awaited only by its already-applied command, never by fresh discovery.
    private var isOriginalAnnotationEditorRootReady: Bool {
        mounted && readerBinding == nil && readerTabBinding == nil && workspaceSelectionBinding == nil
            && searchResultsBinding == nil && searchContinuationOwner == nil
            && bindings.selectedTab.wrappedValue.canonical == .annotations
            && bindings.manager.currentMode == .annotations
            && bindings.isPresentationReady && !bindings.showSettings.wrappedValue
            && !hasOriginalWorkspacePresentation && !hasOriginalSefariaSurface
            && savedResultsBinding?.isRequestedOrMounted != true
            && studyChatPresentationID == nil && searchPresentationBlocked?() != true
            && noteEditorOwner?.current == nil && noteEditorOwner?.presentationActive != true
    }

    func isPresentationReady(for destination: UIDestinationID) -> Bool {
        if destination == MaktabahNativeAnnotationEditorOpening.destination {
            guard foreground, isOriginalAnnotationEditorRootReady, let original = annotationEditorOpening else { return false }
            if let requestID = submissionID, command?.invocation.requestId == requestID,
               command?.route.route.destination == destination,
               original.isContinuingAppliedRequest(requestID: requestID) { return true }
            return original.isAvailable && windowSource?.isPresentationReady(in: sceneID) == true
        }
        if destination == MaktabahNativeAnnotationEditorControls.destination {
            // The stable own editor supplies its original top-sheet witness.
            // Every other route retains the existing no-Annotations-modal gate.
            return foreground && isOriginalAnnotationEditorRootReady
                && annotationEditorControls?.isAvailable() == true
        }
        guard !hasOriginalAnnotationPresentation else { return false }
        if destination == MaktabahNativeAnnotationSelectionBinding.destination {
            return mounted && foreground && annotationSelectionBinding?.isAvailable == true
                && windowSource?.isPresentationReady(in: sceneID) == true
        }
        if destination == MaktabahNativeSavedResultsBinding.destination {
            guard mounted, foreground, let original = savedResultsBinding, original.isAvailable else { return false }
            if let requestID = submissionID, command?.invocation.requestId == requestID,
               command?.route.route.destination == destination,
               original.isContinuingAppliedRequest(requestID: requestID) { return true }
            if original.isRequestedOrMounted { return original.isStableOriginalPresentation }
            return windowSource?.isPresentationReady(in: sceneID) == true
        }
        guard savedResultsBinding?.isRequestedOrMounted != true else { return false }
        if destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            guard mounted, foreground, isReaderTabSourceReady, let bound = workspaceSelectionBinding,
                  (try? bound.validate()) != nil else { return false }
            if bound.isApplied, submissionID == bound.requestID,
               command?.invocation.requestId == bound.requestID,
               command?.route.route.destination == destination { return true }
            return windowSource?.isPresentationReady(in: sceneID) == true
        }
        guard workspaceSelectionBinding == nil else { return false }
        if destination == MaktabahNativeReaderTabBinding.destination {
            guard mounted, foreground, isReaderTabSourceReady, let bound = readerTabBinding,
                  (try? bound.validate()) != nil else { return false }
            if bound.isApplied, submissionID == bound.requestID,
               command?.invocation.requestId == bound.requestID,
               command?.route.route.destination == destination { return true }
            return windowSource?.isPresentationReady(in: sceneID) == true
        }
        guard readerTabBinding == nil else { return false }
        if MaktabahNativeSefariaSurfaceBinding.accepts(destination) {
            guard isSefariaOriginalRootReady, let original = sefariaSurfaceBinding,
                  original.isAvailable else { return false }
            let actual = original.presentationFacets
            if let requestID = submissionID, command?.invocation.requestId == requestID,
               command?.route.route.destination == destination,
               original.isContinuingAppliedRequest(requestID: requestID) {
                return true
            }
            if actual.requested || actual.mounted || actual.transitioning {
                return actual.requested && actual.mounted && actual.visible && !actual.transitioning
            }
            // Only a cold request uses the original root window. A stable own
            // sheet supplies its exact host; unrelated modal transitions block.
            return windowSource?.isPresentationReady(in: sceneID) == true
        }
        if usesOriginalPhoneTOC(destination) {
            guard !bindings.showSettings.wrappedValue, isPresentationReady,
                  isRootAvailable(destination), let phoneTOCPresentation else { return false }
            if let requestID = submissionID, command?.invocation.requestId == requestID,
               command?.route.route.destination == destination,
               phoneTOCPresentation.isContinuingOriginalReaderPresentation(requestID: requestID) {
                return true
            }
            // A cold request cannot dismiss or borrow a foreign transition.
            // Only its already committed exact Reader source may await its push.
            return windowSource?.isPresentationReady(in: sceneID) == true
        }
        guard let parent = MaktabahNativeWorkspacePresentationBinding.Parent(rawValue: destination.rawValue) else {
            return isPresentationReady
        }
        guard bindings.isWorkspaceParentPresentationReady, !hasOriginalSefariaSurface, studyChatPresentationID == nil,
              noteEditorOwner?.current == nil, noteEditorOwner?.presentationActive != true,
              let binding = workspacePresentation, binding.isAvailable(parent: parent) else { return false }
        let profiles = binding.presentationFacets(for: .profiles)
        let overview = binding.presentationFacets(for: .overview)
        let continuing: Bool
        if let requestID = submissionID, command?.invocation.requestId == requestID,
           command?.route.route.destination == destination {
            continuing = binding.isContinuingAppliedRequest(parent: parent, requestID: requestID)
        } else {
            continuing = false
        }
        // Before the first canonical apply, the ORIGINAL window must have no
        // unrelated presented controller or unfinished dismissal. A false
        // SwiftUI sheet binding alone does not prove that UIKit has finished.
        // Warm original Workspace sheets instead use their exact host evidence.
        if !profiles.requested && !profiles.mounted && !overview.requested && !overview.mounted
            && !continuing {
            guard windowSource?.isPresentationReady(in: sceneID) == true else { return false }
        }
        if profiles.requested || profiles.mounted {
            guard parent == .profiles,
                  continuing || (profiles.visible && !profiles.transitioning) else { return false }
        }
        if overview.requested || overview.mounted || bindings.manager.showingTabsList
            || bindings.sidebar?.overview.blocksRouting == true {
            guard parent == .overview || (!MaktabahApp.isIpad && parent == .profiles),
                  overview.requested else { return false }
            let coveredByOriginalProfiles = parent == .profiles && profiles.requested
                && profiles.mounted && profiles.visible && !profiles.transitioning
            guard continuing || coveredByOriginalProfiles
                || (overview.mounted && overview.visible && !overview.transitioning) else { return false }
        }
        return true
    }

    private func boundedRenderValidation(for value: UISceneCommand,
                                         owner: MaktabahNativeComponentOwner? = nil,
                                         anchor: UIDestinationID? = nil) throws -> @MainActor () throws -> Void {
        guard let componentValidation else { throw UIRouteError(.unavailable, "native_render_lifetime_missing") }
        let originalLifetime = try componentValidation(value)
        return { [weak self, weak owner] in
            try originalLifetime()
            guard let self, mounted, foreground, isPresentationReady(for: value.route.route.destination) else {
                throw UIRouteError(.staleState, "native_original_presentation_changed")
            }
            try validateParentSource(destination: value.route.route.destination, requestID: value.invocation.requestId)
            if let anchor {
                guard let owner, componentOwners[owner.destination] === owner, owner.isAvailable(anchor) else {
                    throw UIRouteError(.staleState, "native_component_owner_changed")
                }
            }
            let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
            guard value.route.route.state.workspaceID == identity.state.workspaceID,
                  value.route.route.state.profileID == identity.state.profileID else {
                throw UIRouteError(.staleState, "native_workspace_changed")
            }
        }
    }

    private func advanceReaderToolEditorPublication() {
        guard let revision = readerToolEditorPublicationRevision else { return }
        let (next, overflow) = revision.addingReportingOverflow(1)
        readerToolEditorPublicationRevision = overflow ? nil : next
    }

    func attachNoteEditor(id: UUID, reader: ReaderViewModel, annotation: Binding<Annotation?>,
                          presentationID: @escaping @MainActor () -> UUID) {
        if noteEditorOwner?.id == id, noteEditorOwner?.reader === reader { return }
        let tocQueryRegistration = beginTOCQueryIdleNoteRegistration(id: id, reader: reader, annotation: annotation)
        defer { endTOCQueryIdleNoteRegistration(tocQueryRegistration) }
        advanceReaderToolEditorPublication()
        if noteDraftBinding != nil { presentation.revoke() }
        noteEditorOwner = .init(id: id, reader: reader, annotation: annotation, presentationID: presentationID)
        try? nativeStateChanged()
    }
    func originalNoteEditorStateWillChange(id: UUID, reader: ReaderViewModel) {
        guard mounted, let owner = noteEditorOwner,
              owner.id == id, owner.reader === reader else { return }
        advanceReaderToolEditorPublication()
        readerTabBinding?.invalidate()
        workspaceSelectionBinding?.invalidate()
        searchContinuationOwner?.retire()
        publicSearchContinuationCatalog?.retire()
        // Observe the original setter BEFORE its SwiftUI State/presentation
        // mutation. This also covers a retained source before beginObservation
        // and completed proof; final-value equality cannot revive either one.
        sefariaRootSources.values.forEach { $0.invalidate() }
        completedSefariaRootSource?.invalidate()
        historyRecordBinding?.originalForeignStateWillChange()
        savedResultsBinding?.retire()
        annotationSelectionBinding?.retire()
        annotationEditorControls?.retire()
        annotationEditorOpening?.retire()
        if retainedSefariaSurface { presentation.revoke() }
    }
    func detachNoteEditor(id: UUID) {
        guard let owner = noteEditorOwner, owner.id == id else { return }
        advanceReaderToolEditorPublication()
        // Leaving the Reader normally unmounts its idle editor registration.
        // Revoke only a note-owned presentation, not the admitted Search/root
        // transition that caused this original Reader to disappear.
        let hadNotePresentation = noteDraftBinding != nil || owner.current != nil || owner.presentationActive
        noteEditorOwner = nil
        if hadNotePresentation { presentation.revoke() }
        try? nativeStateChanged()
    }
    func noteEditorTextViewChanged(id: UUID, reader: ReaderViewModel, presentationID: UUID, textView: UITextView?) {
        guard let owner = noteEditorOwner, owner.id == id, owner.reader === reader else { return }
        guard owner.observeTextView(textView, presentationID: presentationID) else { return }
        try? nativeStateChanged()
    }
    func noteEditorDidDismiss(id: UUID, presentationID: UUID) {
        guard let owner = noteEditorOwner, owner.id == id else { return }
        guard owner.didDismiss(presentationID: presentationID) else { return }
        try? nativeStateChanged()
    }
    #if DEBUG
    /// Passive acceptance observation of the existing exact Reader/editor owner.
    /// Missing ownership is unknown, distinct from an owned dismissed draft.
    struct NoteDraftAcceptanceState {
        let ownerID: UUID
        let draft: Annotation?
        let presentationActive: Bool
    }
    func noteDraftAcceptanceState(reader: ReaderViewModel) -> NoteDraftAcceptanceState? {
        guard mounted, foreground,
              MaktabahNativeInspectorBinding.currentReader(in: bindings.manager) === reader,
              let owner = noteEditorOwner, owner.reader === reader else { return nil }
        return .init(ownerID: owner.id, draft: owner.current,
                     presentationActive: owner.presentationActive)
    }
    #endif

    #if DEBUG
    /// Passive flags for the actual owner/marker seam. Never publishes a
    /// receipt, forces TextKit layout, changes selection, or logs note content.
    func diagnoseNoteDraftSurface(stage: String, reader: ReaderViewModel? = nil, draft: Annotation? = nil) {
        let bound = noteDraftBinding, owner = noteEditorOwner
        var validation = "no_binding"
        if let bound {
            do { try bound.validate(); validation = "valid" }
            catch { validation = (error as? UIRouteError)?.code ?? String(describing: type(of: error)) }
        }
        let projected = (try? project().surface(.noteDraft)) != nil
        let surfaceAvailable = (try? surface(.noteDraft)) != nil
        let destination = UIDestinationID(rawValue: "native.reader.noteDraft")!
        let check = visibilityChecks[destination], evidence = check?()
        let textView = owner?.textView
        let sameOwner = bound.map { owner === $0.owner } ?? false
        let currentMatches = bound.map { owner?.current == $0.draft } ?? false
        let passedReaderMatches = reader.map { owner?.reader === $0 } ?? false
        let passedDraftMatches = draft.map { owner?.current == $0 } ?? false
        let proposalMatches = bound.flatMap { bound in
            textView.map { ($0.text ?? "").utf8.elementsEqual((bound.request.proposedText ?? "").utf8) }
        } ?? false
        let source = bound?.sourceDiagnostic() ?? "no_binding"
        OtzariaFileLogger.shared.log("[NativeNoteDraftDiagnostic] stage=\(stage)"
            + " mounted=\(mounted) foreground=\(foreground) pending=\(submissionID != nil)"
            + " owner=\(owner != nil) binding=\(bound != nil) applied=\(bound?.isApplied == true)"
            + " sameOwner=\(sameOwner) currentDraft=\(currentMatches)"
            + " passedReader=\(passedReaderMatches) passedDraft=\(passedDraftMatches)"
            + " sourceValidation=\(validation) source={\(source)}"
            + " projected=\(projected) surface=\(surfaceAvailable)"
            + " markerRegistered=\(check != nil) markerVisible=\(evidence?.isVisible == true)"
            + " textView=\(textView != nil) textWindow=\(textView?.window != nil)"
            + " textScene=\(textView?.window?.windowScene?.session.persistentIdentifier == sceneID.rawValue)"
            + " proposalMatches=\(proposalMatches)")
    }
    #endif

    // MARK: Existing Reader-tab intent

    private var isReaderTabSourceReady: Bool {
        !hasOriginalAnnotationPresentation && bindings.isPresentationReady && !bindings.showSettings.wrappedValue
            && !hasOriginalWorkspacePresentation && !hasOriginalSefariaSurface
            && savedResultsBinding?.isRequestedOrMounted != true
            && studyChatPresentationID == nil
            && noteEditorOwner?.current == nil && noteEditorOwner?.presentationActive != true
    }

    func readerTabCatalog(windowTitle: String) throws -> [NativeReaderTabIntentService.Tab] {
        guard mounted, readerTabBinding == nil, workspaceSelectionBinding == nil, isReaderTabSourceReady,
              let source = workspaceProjectionSource else { return [] }
        let originalViewer = bindings.selectedTab.wrappedValue == .viewer && bindings.manager.currentMode == .viewer
        guard originalViewer || viewerParentHost?.isAvailable(bindings: bindings) == true else { return [] }
        return try MaktabahNativeReaderTabBinding.catalog(sceneID: sceneID, manager: bindings.manager,
                                                         source: source, windowTitle: windowTitle)
    }

    func retainReaderTabSelection(_ target: NativeReaderTabIntentService.Tab,
                                  requestID: UUID) throws -> MaktabahNativeReaderTabBinding {
        guard mounted, target.sceneID == sceneID, command == nil,
              readerTabBinding == nil, workspaceSelectionBinding == nil, readerBinding == nil, searchResultsBinding == nil,
              isReaderTabSourceReady, let source = workspaceProjectionSource else {
            throw UIRouteError(.unavailable, "native_reader_tab_scene_busy")
        }
        let bound = try MaktabahNativeReaderTabBinding(requestID: requestID, target: target,
            bindings: bindings, source: source, viewerParentHost: viewerParentHost,
            foreignReady: { [weak self] in self?.isReaderTabSourceReady == true },
            readForeignPresentations: { [weak self] in
                guard let self else { return }
                _ = workspacePresentation?.originalStateRevision
                _ = studyChatPresentationID
                _ = hasOriginalSefariaSurface
            })
        readerTabBinding = bound
        return bound
    }

    func reserveReaderTabSelection(_ bound: MaktabahNativeReaderTabBinding) throws {
        guard readerTabBinding === bound, mounted, foreground, command == nil,
              isReaderTabSourceReady, windowSource?.isPresentationReady(in: sceneID) == true else {
            throw UIRouteError(.unavailable, "native_reader_tab_presentation_unavailable")
        }
        try bound.reserve()
    }

    func releaseReaderTabSelection(_ bound: MaktabahNativeReaderTabBinding) {
        guard readerTabBinding === bound else { return }
        readerTabBinding = nil; readerTabParentObservation = nil
        bound.release()
        originalPresentationStateDidChange()
    }

    func prepareReaderTabRoute(_ bound: MaktabahNativeReaderTabBinding,
                               invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard readerTabBinding === bound, bound.isReserved, !bound.isApplied,
              invocation.requestId == bound.requestID, scene.sceneID == sceneID,
              invocation.snapshot.backend == bound.target.backend else {
            throw UIRouteError(.staleState, "native_reader_tab_request_changed")
        }
        try bound.validate()
        return .init(requestId: invocation.requestId, destination: MaktabahNativeReaderTabBinding.destination,
            backend: invocation.snapshot.backend,
            presentation: .init(kind: .currentTab, tabID: UIStableID(rawValue: bound.target.tabID.uuidString)),
            state: .init(workspaceID: UIStableID(rawValue: bound.target.groupID.uuidString),
                         profileID: UIStableID(rawValue: bound.target.profileID.uuidString)),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }

    func validateReaderTabCompletion(_ bound: MaktabahNativeReaderTabBinding,
                                     receipt: UISceneReceipt) throws {
        guard readerTabBinding === bound, bound.isApplied, receipt.requestId == bound.requestID,
              receipt.route.destination == MaktabahNativeReaderTabBinding.destination else {
            throw UIRouteError(.staleState, "native_reader_tab_completed_owner_changed")
        }
        try bound.validate()
        try validateCompletedJourneySurface(receipt)
        guard readerTabBinding === bound else { throw UIRouteError(.staleState, "native_reader_tab_completed_owner_changed") }
        try bound.validate()
    }

    func workspaceSelectionCatalog(windowTitle: String) throws -> [NativeWorkspaceSelectionIntentService.Selection] {
        guard mounted, workspaceSelectionBinding == nil, readerTabBinding == nil, isReaderTabSourceReady,
              let source = workspaceProjectionSource else { return [] }
        let originalViewer = bindings.selectedTab.wrappedValue == .viewer && bindings.manager.currentMode == .viewer
        guard originalViewer || viewerParentHost?.isAvailable(bindings: bindings) == true else { return [] }
        return try MaktabahNativeWorkspaceSelectionBinding.catalog(sceneID: sceneID, manager: bindings.manager,
                                                                    source: source, windowTitle: windowTitle)
    }

    func retainWorkspaceSelection(_ target: NativeWorkspaceSelectionIntentService.Selection,
                                  requestID: UUID) throws -> MaktabahNativeWorkspaceSelectionBinding {
        guard mounted, target.sceneID == sceneID, command == nil,
              workspaceSelectionBinding == nil, readerTabBinding == nil, readerBinding == nil,
              searchResultsBinding == nil, isReaderTabSourceReady, let source = workspaceProjectionSource else {
            throw UIRouteError(.unavailable, "native_workspace_selection_scene_busy")
        }
        let bound = try MaktabahNativeWorkspaceSelectionBinding(requestID: requestID, target: target,
            bindings: bindings, source: source, viewerParentHost: viewerParentHost,
            foreignReady: { [weak self] in self?.isReaderTabSourceReady == true },
            readForeignPresentations: { [weak self] in
                guard let self else { return }
                _ = workspacePresentation?.originalStateRevision
                _ = studyChatPresentationID; _ = hasOriginalSefariaSurface
            })
        workspaceSelectionBinding = bound
        return bound
    }

    func reserveWorkspaceSelection(_ bound: MaktabahNativeWorkspaceSelectionBinding) throws {
        guard workspaceSelectionBinding === bound, mounted, foreground, command == nil,
              isReaderTabSourceReady, windowSource?.isPresentationReady(in: sceneID) == true else {
            throw UIRouteError(.unavailable, "native_workspace_selection_presentation_unavailable")
        }
        try bound.reserve()
    }

    func prepareWorkspaceSelection(_ bound: MaktabahNativeWorkspaceSelectionBinding,
                                   validateLifetime: @escaping @MainActor () throws -> Void) async throws {
        guard workspaceSelectionBinding === bound, command == nil, mounted, foreground else {
            throw UIRouteError(.staleState, "native_workspace_selection_owner_changed")
        }
        try await bound.prepare { [weak self] in
            try validateLifetime()
            guard let self, self.workspaceSelectionBinding === bound, self.command == nil,
                  self.mounted, self.foreground, self.isReaderTabSourceReady else {
                throw UIRouteError(.staleState, "native_workspace_selection_scene_changed")
            }
        }
    }

    func releaseWorkspaceSelection(_ bound: MaktabahNativeWorkspaceSelectionBinding) {
        guard workspaceSelectionBinding === bound else { return }
        workspaceSelectionBinding = nil; workspaceSelectionParentObservation = nil
        bound.release()
        originalPresentationStateDidChange()
    }

    func prepareWorkspaceSelectionRoute(_ bound: MaktabahNativeWorkspaceSelectionBinding,
                                        invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard workspaceSelectionBinding === bound, bound.isPrepared, !bound.isApplied,
              invocation.requestId == bound.requestID, scene.sceneID == sceneID,
              invocation.snapshot.backend == bound.target.backend else {
            throw UIRouteError(.staleState, "native_workspace_selection_request_changed")
        }
        try bound.validate()
        return .init(requestId: invocation.requestId, destination: MaktabahNativeWorkspaceSelectionBinding.destination,
            backend: invocation.snapshot.backend,
            presentation: .init(kind: .currentTab, tabID: bound.target.activeDocumentID.flatMap { UIStableID(rawValue: $0.uuidString) }),
            state: .init(workspaceID: UIStableID(rawValue: bound.target.groupID.uuidString),
                         profileID: UIStableID(rawValue: bound.target.profileID.uuidString)),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }

    func validateWorkspaceSelectionCompletion(_ bound: MaktabahNativeWorkspaceSelectionBinding,
                                              receipt: UISceneReceipt) throws {
        guard workspaceSelectionBinding === bound, bound.isApplied, receipt.requestId == bound.requestID,
              receipt.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination else {
            throw UIRouteError(.staleState, "native_workspace_selection_completed_owner_changed")
        }
        try bound.validate()
        try validateCompletedJourneySurface(receipt)
        guard workspaceSelectionBinding === bound else {
            throw UIRouteError(.staleState, "native_workspace_selection_completed_owner_changed")
        }
        try bound.validate()
        try bound.didValidateCompletion()
    }

    /// Capture before the first catalog await. Source metadata does not open a
    /// Reader, construct an Annotation, select a range or acquire a Core grant.
    func captureReaderToolSource(_ start: NativeReaderToolIntentService.Start,
        validateOwner: @escaping @MainActor @Sendable () throws -> Void) throws -> MaktabahNativeReaderToolSource {
        let validateWindow = try captureHistoryReaderWindow()
        guard let editorRevision = readerToolEditorPublicationRevision,
              noteEditorOwner?.current == nil, noteEditorOwner?.presentationActive != true else {
            throw UIRouteError(.unavailable, "reader_tool_original_editor_unavailable")
        }
        let editor = noteEditorOwner, manager = bindings.manager
        let selection: MaktabahNativeReaderToolSelection?
        switch start.operation {
        case .commentary: selection = nil
        case .noteDraft:
            guard let editor else { throw UIRouteError(.unavailable, "exact_note_selection_unavailable") }
            selection = try MaktabahNativeReaderToolSelection(manager: manager, owner: editor, locator: start.locator)
        }
        return try MaktabahNativeReaderToolSource(start: start, sceneID: sceneID, selection: selection) { [weak self, weak manager] in
            try validateOwner()
            try validateWindow()
            guard let self, let manager, self.bindings.manager === manager,
                  self.readerToolEditorPublicationRevision == editorRevision,
                  self.noteEditorOwner === editor, editor?.current == nil,
                  editor?.presentationActive != true else {
                throw UIRouteError(.staleState, "reader_tool_original_editor_changed")
            }
            try validateWindow()
            try validateOwner()
        }
    }

    func canPrepareNoteDraft() -> Bool {
        guard mounted, foreground, isPresentationReady, noteDraftBinding == nil,
              let owner = noteEditorOwner, owner.current == nil,
              (try? publicBindingPresentation().witnessedReader) != nil else { return false }
        return (try? MaktabahNativeNoteDraftBinding.selection(manager: bindings.manager, owner: owner, sceneID: sceneID)) != nil
    }
    func retainNoteDraft(_ request: ActionNoteDraftRequest,
                         sourceFence: (@MainActor () throws -> Void)? = nil) throws -> MaktabahNativeNoteDraftBinding {
        guard canPrepareNoteDraft(), let owner = noteEditorOwner else { throw ActionPortError.unavailable }
        let bound = try MaktabahNativeNoteDraftBinding(manager: bindings.manager, owner: owner,
            request: request, sceneID: sceneID, sourceFence: sourceFence)
        noteDraftBinding = bound
        return bound
    }
    func releaseNoteDraft(_ bound: MaktabahNativeNoteDraftBinding) {
        #if DEBUG
        if noteDraftBinding === bound { diagnoseNoteDraftSurface(stage: "before-binding-release") }
        #endif
        if noteDraftBinding === bound {
            noteDraftBinding = nil
            visibilityChecks[UIDestinationID(rawValue: "native.reader.noteDraft")!] = nil
        }
        // The original unsaved editor remains under the user's Save/Cancel.
    }
    func prepareNoteDraftRoute(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard let bound = noteDraftBinding else { throw ActionPortError.unavailable }
        try bound.validate()
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: UIDestinationID(rawValue: "native.reader.noteDraft")!,
            backend: invocation.snapshot.backend, presentation: .init(kind: .sheet),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }
    func validateNoteDraftCompletion(_ bound: MaktabahNativeNoteDraftBinding, route: RouteSpec) throws {
        guard mounted, foreground, noteDraftBinding === bound, noteEditorOwner === bound.owner else { throw ActionPortError.staleState }
        try bound.validateVisible()
        let id = UIDestinationID(rawValue: "native.reader.noteDraft")!
        guard let actual = visibilityChecks[id]?(), actual.isVisible, actual.sceneID == sceneID,
              actual.surface == (try surface(.noteDraft)),
              actual.surface.destination == route.destination, actual.surface.presentation == route.presentation,
              actual.surface.state == route.state, actual.surface.content == nil, actual.surface.focus == nil else {
            throw ActionPortError.staleState
        }
    }

    func beginStudyChatPresentation(_ id: UUID) throws {
        guard mounted, foreground, isPresentationReady else {
            throw UIRouteError(.unavailable, "native_presentation_in_progress")
        }
        studyChatPresentationID = id
        do { try nativeStateChanged() }
        catch { studyChatPresentationID = nil; throw error }
        presentation.revoke()
    }
    func finishStudyChatPresentation(_ id: UUID) {
        guard studyChatPresentationID == id else { return }
        studyChatPresentationID = nil
        try? nativeStateChanged()
    }
    /// Only this exact app-owned sheet may use its underlying source identity.
    /// Other native routes stay unavailable until actual onDismiss, including
    /// the period after the SDK lease is revoked but its sheet is still visible.
    func isStudyChatContextReady(allowing id: UUID?) -> Bool {
        bindings.isPresentationReady && !hasOriginalWorkspacePresentation && !hasOriginalSefariaSurface
            && noteEditorOwner?.current == nil && noteEditorOwner?.presentationActive != true
            && (studyChatPresentationID == nil || studyChatPresentationID == id)
    }
    func isRootAvailable(_ destination: UIDestinationID) -> Bool {
        if destination == MaktabahNativeAnnotationEditorControls.destination {
            return isOriginalAnnotationEditorRootReady && annotationEditorControls?.isAvailable() == true
        }
        if destination == MaktabahNativeSavedResultsBinding.destination {
            return savedResultsBinding?.isAvailable == true
        }
        if MaktabahNativeSefariaSurfaceBinding.accepts(destination) {
            return sefariaSurfaceBinding?.isAvailable == true
                && MaktabahNativeSefariaRootSource.isAvailable(bindings, workspace: workspacePresentation)
        }
        if usesOriginalPhoneTOC(destination) {
            return MaktabahNativeRootDestination.library.isAvailable
                && phoneTOCPresentation?.isAvailable() == true
        }
        if let parent = MaktabahNativeWorkspacePresentationBinding.Parent(rawValue: destination.rawValue) {
            return workspacePresentation?.isAvailable(parent: parent) == true
        }
        guard let root = MaktabahNativeRootDestination(rawValue: destination.rawValue) else { return false }
        return bindings.isRootAvailable(root)
    }

    init(sceneID: UIStableID, directory: NativeSceneDirectory, bindings: MaktabahNativeSceneBindings,
         workspaceSource: MaktabahNativeWorkspaceProjectionSource? = nil,
         project: @escaping @MainActor () throws -> MaktabahNativeSceneProjection) {
        self.sceneID = sceneID; self.directory = directory; self.project = project
        self.bindings = bindings
        workspaceProjectionSource = workspaceSource
        presentation = NativePresentationObserver(sceneID: sceneID)
        if let workspaceSource, workspaceSource.isAuthoritative {
            viewerParentHost = MaktabahNativeViewerParentHost(sceneID: sceneID, manager: bindings.manager,
                isCurrentSession: { [weak self] in self?.mounted == true && self?.foreground == true },
                captureOriginalWindow: { [weak self] in
                    guard let self else { throw UIRouteError(.staleState, "native_viewer_parent_session_changed") }
                    return try self.retainOriginalWindowObservation()
                }, originalRootIsReady: { [weak self] in
                    guard let self else { return false }
                    return self.isReaderTabSourceReady && self.windowSource?.isPresentationReady(in: self.sceneID) == true
                })
            let searchEntry = MaktabahNativeSearchEntryBinding(sceneID: sceneID, bindings: bindings,
                workspaceSource: workspaceSource,
                commonReady: { [weak self] in
                    guard let self else { return false }
                    return mounted && foreground && isPresentationReady && searchPresentationBlocked?() != true
                }, windowReady: { [weak self] in
                    guard let self else { return false }
                    return windowSource?.isPresentationReady(in: sceneID) == true
                }, parentVisible: { [weak self] in
                    guard let self else { return false }
                    return (try? project().surface(.search)) != nil
                })
            searchEntryBinding = searchEntry
            attachComponentOwner(searchEntry.owner)
            let original = MaktabahNativeWorkspacePresentationBinding(sceneID: sceneID,
                manager: bindings.manager, workspaceSource: workspaceSource, sidebar: bindings.sidebar,
                selectViewer: { bindings.selectOriginalWorkspaceParent() })
            workspacePresentation = original
            original.install(changed: { [weak self, weak original] in
                guard let self, let original, workspacePresentation === original else { return }
                originalPresentationStateDidChange()
            }, invalidated: { [weak self] in self?.presentation.revoke() })
            for owner in MaktabahNativeWorkspaceComponents.makeOwners(binding: original) { attachComponentOwner(owner) }
            let history = MaktabahNativeHistoryRecordBinding(sceneID: sceneID, bindings: bindings,
                workspaceSource: workspaceSource, workspacePresentation: original,
                commonReady: { [weak self] in
                    guard let self else { return false }
                    // Source is retained before system foreground activation.
                    // Foreground and the real window are mandatory at begin.
                    return mounted && isPresentationReady && !bindings.showSettings.wrappedValue
                        && searchPresentationBlocked?() != true
                }, windowReady: { [weak self] in
                    guard let self else { return false }
                    return foreground && windowSource?.isPresentationReady(in: sceneID) == true
                }, readForeignPresentations: { [weak self] in
                    guard let self else { return }
                    _ = mounted; _ = studyChatPresentationID
                    // Original Notes/Search local State invalidates through
                    // their existing exact-owner pre-mutation callbacks.
                })
            historyRecordBinding = history
            history.install(changed: { [weak self, weak history] in
                guard let self, let history, historyRecordBinding === history else { return }
                originalPresentationStateDidChange()
            }, invalidated: { [weak self] in
                guard let self, retainedHistoryRecord else { return }
                presentation.revoke()
            })
            let annotations = MaktabahNativeAnnotationSelectionBinding(sceneID: sceneID, bindings: bindings,
                workspaceSource: workspaceSource, workspacePresentation: original,
                commonReady: { [weak self] in
                    guard let self else { return false }
                    return mounted && isPresentationReady && !bindings.showSettings.wrappedValue
                        && readerBinding == nil && searchResultsBinding == nil && searchContinuationOwner == nil
                        && searchPresentationBlocked?() != true
                }, windowReady: { [weak self] in
                    guard let self else { return false }
                    return foreground && windowSource?.isPresentationReady(in: sceneID) == true
                }, retainWindow: { [weak self] in
                    guard let self else { throw UIRouteError(.staleState, "native_annotation_window_detached") }
                    return try retainOriginalWindowObservation()
                }, readForeignPresentations: { [weak self] in
                    guard let self else { return }
                    _ = mounted; _ = studyChatPresentationID; _ = workspacePresentation?.originalStateRevision
                }, originalUIKitPresentationWillChange: { [weak self] owner in
                    self?.originalAnnotationPresentationWillChange(owner: owner)
                })
            annotationSelectionBinding = annotations
            annotations.install(changed: { [weak self, weak annotations] in
                guard let self, let annotations, annotationSelectionBinding === annotations else { return }
                originalPresentationStateDidChange()
            }, invalidated: { [weak self] in
                guard let self, retainedAnnotationSelection else { return }
                presentation.revoke()
            })
            let editor = MaktabahNativeAnnotationEditorControls(sceneID: sceneID,
                retainWindow: { [weak self] in
                    guard let self else { throw UIRouteError(.staleState, "original_annotation_editor_window_detached") }
                    return try retainOriginalWindowObservation()
                }, retainParent: { [weak self] owner in
                    guard let self else { throw UIRouteError(.staleState, "original_annotation_editor_parent_detached") }
                    return try captureAnnotationEditorWindow(owner: owner)
                })
            annotationEditorControls = editor
            editor.install(changed: { [weak self, weak editor] in
                guard let self, let editor, annotationEditorControls === editor else { return }
                annotationEditorOpening?.originalEditorHostDidChange()
                originalPresentationStateDidChange()
            }, invalidated: { [weak self] in
                guard let self, retainedAnnotationEditor else { return }
                presentation.revoke()
            })
            attachComponentOwner(editor.componentOwner)
            let opening = MaktabahNativeAnnotationEditorOpening(sceneID: sceneID, selection: annotations, editor: editor,
                retainWindow: { [weak self] in
                    guard let self else { throw UIRouteError(.staleState, "original_annotation_opening_window_detached") }
                    return try retainOriginalWindowObservation()
                }, retainParent: { [weak self] owner, annotation, requestID in
                    guard let self else { throw UIRouteError(.staleState, "original_annotation_opening_parent_detached") }
                    return try captureAnnotationOpeningWindow(owner: owner, annotation: annotation, requestID: requestID)
                }, windowReady: { [weak self] in
                    guard let self else { return false }
                    return foreground && windowSource?.isPresentationReady(in: sceneID) == true
                })
            annotationEditorOpening = opening
            opening.install(changed: { [weak self, weak opening] in
                guard let self, let opening, annotationEditorOpening === opening else { return }
                originalPresentationStateDidChange()
            }, invalidated: { [weak self] in
                guard let self, retainedAnnotationEditorOpening else { return }
                presentation.revoke()
            })
            let saved = MaktabahNativeSavedResultsBinding(sceneID: sceneID, bindings: bindings,
                workspaceSource: workspaceSource, workspacePresentation: original,
                commonReady: { [weak self] in
                    guard let self else { return false }
                    // Primitive foreign-presentation checks, deliberately not
                    // recursive isPresentationReady (which blocks this own sheet).
                    return mounted && readerBinding == nil && readerTabBinding == nil
                        && workspaceSelectionBinding == nil && searchResultsBinding == nil
                        && searchContinuationOwner == nil && bindings.isPresentationReady
                        && !bindings.showSettings.wrappedValue && !hasOriginalWorkspacePresentation
                        && !hasOriginalSefariaSurface && studyChatPresentationID == nil
                        && noteEditorOwner?.current == nil && noteEditorOwner?.presentationActive != true
                }, windowReady: { [weak self] in
                    guard let self else { return false }
                    return foreground && windowSource?.isPresentationReady(in: sceneID) == true
                }, retainWindow: { [weak self] in
                    guard let self else { throw UIRouteError(.staleState, "native_saved_results_window_detached") }
                    return try retainOriginalWindowObservation()
                }, readForeignPresentations: { [weak self] in
                    guard let self else { return }
                    _ = mounted; _ = studyChatPresentationID
                    _ = workspacePresentation?.originalStateRevision
                })
            savedResultsBinding = saved
            saved.install(changed: { [weak self, weak saved] in
                guard let self, let saved, savedResultsBinding === saved else { return }
                originalPresentationStateDidChange()
            }, invalidated: { [weak self] in
                guard let self, retainedSavedResults else { return }
                presentation.revoke()
            })
            let sefaria = MaktabahNativeSefariaSurfaceBinding(sceneID: sceneID,
                manager: bindings.manager, workspaceSource: workspaceSource)
            sefariaSurfaceBinding = sefaria
            sefaria.install(changed: { [weak self, weak sefaria] in
                guard let self, let sefaria, sefariaSurfaceBinding === sefaria else { return }
                originalPresentationStateDidChange()
            }, invalidated: { [weak self] in self?.presentation.revoke() })
            if !MaktabahApp.isIpad {
                let phone = MaktabahNativePhoneTOCPresentationBinding(sceneID: sceneID,
                    manager: bindings.manager, workspaceSource: workspaceSource,
                    presentReader: { try bindings.presentOriginalPhoneTOCReader($0) })
                phoneTOCPresentation = phone
                phone.install(changed: { [weak self, weak phone] in
                    guard let self, let phone, phoneTOCPresentation === phone else { return }
                    originalPresentationStateDidChange()
                }, invalidated: { [weak self] in self?.presentation.revoke() })
            }
        }
        attachComponentOwner(MaktabahNativeSettingsComponents.makeOwner())
        attachComponentOwner(MaktabahNativeTOCComponents.makeOwner(manager: bindings.manager,
                                                                  phonePresentation: phoneTOCPresentation))
        attachComponentOwner(MaktabahNativeLibraryComponents.makeOwner(manager: bindings.manager))
    }

    func mount(validateLifetime: @escaping NativeSceneDirectory.ValidateLifetime) throws {
        guard lease == nil, mounted else { throw UIRouteError(.staleState, "scene_session_already_mounted") }
        lease = try directory.mount(sceneID: sceneID, observe: { [weak self] in
            guard let self, mounted else { throw UIRouteError(.unavailable, "scene_missing") }
            let projection = try project()
            var route: RouteSpec?
            var surface: NativeSurfaceState?
            if let command, isPresentationReady(for: command.route.route.destination),
               let evidence = visible[command.route.route.destination], evidence.isVisible,
               let currentEvidence = visibilityChecks[command.route.route.destination]?(), currentEvidence == evidence,
               evidence.sceneID == sceneID, evidence.submissionID == command.invocation.requestId,
               let kind = surfaceKind(command.route.route.destination), let current = try self.surface(kind),
               current == evidence.surface,
               (kind != .reader || projection.hasRenderedReaderEvidence(sceneID: sceneID,
                    includingContainingSection: command.route.route.destination == MaktabahNativeReaderTabBinding.destination)),
               (kind != .noteDraft || (try? noteDraftBinding?.validateVisible()) != nil),
               (kind != .annotationEditor || (command.route.route.destination == MaktabahNativeAnnotationEditorOpening.destination
                    ? annotationEditorOpening?.hasVisibleSurface(requestID: command.invocation.requestId) == true
                    : (try? annotationEditorControls?.validateVisible(requestID: command.invocation.requestId)) != nil)) {
                surface = current
                route = current.observedRoute(for: command, backend: command.invocation.snapshot)
            }
            return .init(isForeground: foreground, isMounted: mounted, visibleRoute: route, surface: surface,
                         identity: try projection.identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls))
        }, validateLifetime: validateLifetime)
    }

    /// Preparation for the observer only; caller must possess the canonical
    /// Core grant before invoking any native binding/model mutation afterwards.
    func beginObservation(_ value: UISceneCommand) throws {
        guard mounted, lease != nil, value.scene.sceneID == sceneID else { throw UIRouteError(.staleState, "scene_lifetime_changed") }
        let field: UISearchTextField?
        if value.route.route.focus != nil, value.route.route.destination == NativeSearchFieldVisibility.destination,
           value.route.route.focus?.anchor != MaktabahNativeSearchEntryBinding.anchor {
            guard value.route.route.focus == NativeSearchFieldVisibility.focus,
                  searchFieldAvailable, let original = nativeSearchField else {
                throw UIRouteError(.unavailable, "native_search_field_not_visible")
            }
            field = original
        } else { field = nil }
        let component: MaktabahNativeComponentOwner?
        let renderValidation: (@MainActor () throws -> Void)?
        if let focus = value.route.route.focus, field == nil {
            guard focus.kind == .component, focus.locator == nil, focus.range == nil,
                  let anchor = focus.anchor, let owner = componentOwners[value.route.route.destination],
                  owner.isAvailable(anchor) else {
                throw UIRouteError(.unavailable, "native_component_unavailable")
            }
            component = owner
            renderValidation = try boundedRenderValidation(for: value, owner: owner, anchor: anchor)
        } else { component = nil; renderValidation = nil }
        let workspaceParent = MaktabahNativeWorkspacePresentationBinding.Parent(rawValue: value.route.route.destination.rawValue)
        let phoneTOC = usesOriginalPhoneTOC(value.route.route.destination)
        let sefaria = MaktabahNativeSefariaSurfaceBinding.accepts(value.route.route.destination)
        let historyRecord = value.route.route.destination == MaktabahNativeHistoryRecords.destination
            && value.route.route.state.selectedItemID != nil
        let workspaceSelection = value.route.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination
        let annotationSelection = value.route.route.destination == MaktabahNativeAnnotationSelectionBinding.destination
        let annotationEditor = value.route.route.destination == MaktabahNativeAnnotationEditorControls.destination
        let annotationOpening = value.route.route.destination == MaktabahNativeAnnotationEditorOpening.destination
        let savedResults = value.route.route.destination == MaktabahNativeSavedResultsBinding.destination
        let parentValidation: (@MainActor () throws -> Void)?
        if workspaceParent != nil || phoneTOC || sefaria || historyRecord || savedResults || annotationSelection || annotationEditor || annotationOpening {
            parentValidation = try renderValidation ?? boundedRenderValidation(for: value)
        } else { parentValidation = nil }
        let inspector: MaktabahNativeInspectorBinding?
        if value.route.route.destination.rawValue == "native.reader.inspector" {
            guard try publicBindingPresentation().inspectorAvailable else {
                throw UIRouteError(.unavailable, "native_inspector_reader_unavailable")
            }
            inspector = try MaktabahNativeInspectorBinding(manager: bindings.manager)
        } else { inspector = nil }
        try presentation.begin(value)
        do {
            if workspaceSelection {
                guard let bound = workspaceSelectionBinding, bound.requestID == value.invocation.requestId,
                      let componentValidation else {
                    throw UIRouteError(.staleState, "native_workspace_selection_owner_missing")
                }
                workspaceSelectionParentObservation = nil
                try bound.viewerParent?.bind(value)
                let originalLifetime = try componentValidation(value)
                try bound.begin(deadlineUptimeNanoseconds: value.invocation.deadlineUptimeNanoseconds) { [weak self, weak bound] in
                    try originalLifetime()
                    guard let self, let bound, self.workspaceSelectionBinding === bound,
                          self.mounted, self.foreground, self.isReaderTabSourceReady else {
                        throw UIRouteError(.staleState, "native_workspace_selection_lifetime_changed")
                    }
                    try bound.validate()
                }
            }
            if value.route.route.destination == MaktabahNativeReaderTabBinding.destination {
                guard let bound = readerTabBinding, bound.requestID == value.invocation.requestId else {
                    throw UIRouteError(.staleState, "native_reader_tab_owner_missing")
                }
                readerTabParentObservation = nil
                try bound.viewerParent?.bind(value)
            }
            if let workspaceParent, let parentValidation, let workspacePresentation {
                try workspacePresentation.begin(parent: workspaceParent, requestID: value.invocation.requestId,
                                                validate: parentValidation)
            }
            if phoneTOC {
                guard let phoneTOCPresentation, let parentValidation else {
                    throw UIRouteError(.unavailable, "native_phone_toc_parent_detached")
                }
                try phoneTOCPresentation.begin(requestID: value.invocation.requestId, validate: parentValidation)
            }
            if sefaria {
                guard let sefariaSurfaceBinding, let parentValidation else {
                    throw UIRouteError(.unavailable, "native_sefaria_parent_detached")
                }
                try sefariaSurfaceBinding.begin(requestID: value.invocation.requestId,
                    target: MaktabahNativeSefariaSurfaceBinding.semanticTarget(for: value.route.route.destination),
                    deadlineUptimeNanoseconds: value.invocation.deadlineUptimeNanoseconds, validate: parentValidation)
            }
            if annotationOpening {
                guard let original = annotationEditorOpening, let parentValidation else {
                    throw UIRouteError(.staleState, "original_annotation_opening_parent_not_retained")
                }
                try original.begin(requestID: value.invocation.requestId, validate: parentValidation)
            }
            if annotationEditor {
                guard let annotationEditorControls, let parentValidation else {
                    throw UIRouteError(.staleState, "original_annotation_editor_parent_not_retained")
                }
                try annotationEditorControls.begin(requestID: value.invocation.requestId, validate: parentValidation)
            }
            if annotationSelection {
                guard let annotationSelectionBinding, let parentValidation else {
                    throw UIRouteError(.staleState, "native_annotation_parent_not_retained")
                }
                try annotationSelectionBinding.begin(requestID: value.invocation.requestId, validate: parentValidation)
            }
            if savedResults {
                guard let savedResultsBinding, let parentValidation else {
                    throw UIRouteError(.unavailable, "native_saved_results_owner_missing")
                }
                try savedResultsBinding.begin(requestID: value.invocation.requestId, validate: parentValidation)
            }
            if historyRecord {
                guard let historyRecordBinding, let parentValidation else {
                    throw UIRouteError(.unavailable, "native_history_record_owner_missing")
                }
                try historyRecordBinding.begin(requestID: value.invocation.requestId, validate: parentValidation)
            }
            if let component, let anchor = value.route.route.focus?.anchor, let renderValidation {
                if component === searchEntryBinding?.owner {
                    try searchEntryBinding?.begin(requestID: value.invocation.requestId, validate: renderValidation)
                }
                try component.begin(requestID: value.invocation.requestId, anchor: anchor, validate: renderValidation)
            }
        } catch {
            if workspaceSelection { workspaceSelectionBinding?.invalidate() }
            workspacePresentation?.finish(requestID: value.invocation.requestId, completed: false)
            phoneTOCPresentation?.finish(requestID: value.invocation.requestId, completed: false)
            searchEntryBinding?.finish(requestID: value.invocation.requestId, completed: false)
            sefariaSurfaceBinding?.finish(requestID: value.invocation.requestId, completed: false)
            historyRecordBinding?.finish(requestID: value.invocation.requestId, completed: false)
            savedResultsBinding?.finish(requestID: value.invocation.requestId, completed: false)
            annotationSelectionBinding?.finish(requestID: value.invocation.requestId, completed: false)
            annotationEditorControls?.finish(requestID: value.invocation.requestId, completed: false)
            annotationEditorOpening?.finish(requestID: value.invocation.requestId, completed: false)
            presentation.end(requestID: value.invocation.requestId)
            throw error
        }
        retainedWorkspaceParent = workspaceParent
        retainedPhoneTOC = phoneTOC
        retainedSefariaSurface = sefaria
        retainedHistoryRecord = historyRecord
        retainedSavedResults = savedResults
        retainedAnnotationSelection = annotationSelection
        retainedAnnotationEditor = annotationEditor
        retainedAnnotationEditorOpening = annotationOpening
        if !annotationOpening { annotationEditorOpening?.clearCompletedProof() }
        if !annotationSelection { annotationSelectionBinding?.clearCompletedProof() }
        if !savedResults { savedResultsBinding?.clearCompletedProof() }
        if !historyRecord { historyRecordBinding?.clearCompletedProof() }
        retainedComponentOwner = component
        inspectorBinding = inspector
        retainedSearchField = field
        lastCompletedSurface = nil
        completedSefariaRootSource = nil
        command = value; submissionID = value.invocation.requestId
    }

    func retainReader(_ content: ActionReaderDestination, requestID: UUID,
                      historySource: MaktabahNativeHistoryReaderSource? = nil,
                      revoke: @escaping @MainActor () -> Void) throws -> MaktabahNativeReaderBinding {
        guard readerBinding == nil else { throw UIRouteError(.unavailable, "reader_binding_busy") }
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        let workspace = try workspaceProjectionSource?.read()
        if content.presentationMode == .newTab, workspaceProjectionSource?.isAuthoritative != true {
            throw UIRouteError(.unavailable, "new_reader_workspace_unavailable")
        }
        let retained = try MaktabahNativeReaderBinding(manager: bindings.manager,
            currentTabID: identity.activeTabID, workspace: workspace, requestID: requestID, content: content,
            historySource: historySource, revoke: revoke)
        readerBinding = retained
        return retained
    }
    func releaseReader(_ retained: MaktabahNativeReaderBinding) {
        guard readerBinding === retained else { return }
        retained.release(); readerBinding = nil
    }


    /// Retain the selected original window before system foreground activation.
    /// This read-only witness ends at the existing Reader reservation handoff;
    /// the original mapping/Core owners govern all later native awaits.
    func captureHistoryReaderWindow() throws -> @MainActor () throws -> Void {
        try captureHistoryReaderWindow(annotationEditorOwner: nil)
    }
    private func captureHistoryReaderWindow(annotationEditorOwner: UUID?) throws -> @MainActor () throws -> Void {
        let searchPresentation = try retainHistorySearchPresentationObservation()
        let annotationPresentation: @MainActor () throws -> Void
        if let annotationEditorOwner {
            annotationPresentation = try retainOriginalAnnotationEditorPresentationObservation(owner: annotationEditorOwner)
        } else { annotationPresentation = try retainOriginalAnnotationPresentationObservation() }
        return try captureHistoryReaderWindow(searchPresentation: searchPresentation,
            annotationPresentation: annotationPresentation)
    }
    private func captureHistoryReaderWindow(searchPresentation: @escaping @MainActor () throws -> Void,
        annotationPresentation: @escaping @MainActor () throws -> Void) throws -> @MainActor () throws -> Void {
        let originalWindow = try retainOriginalWindowObservation()
        _ = try originalWindow.validate()
        let manager = bindings.manager
        guard mounted, !bindings.showSettings.wrappedValue, bindings.isPresentationReady,
              let root = bindings.rootPublications,
              let rootRevision = root.selectionRevision, let settingsRevision = root.settingsRevision,
              let modeRevision = manager.nativeModePresentationRevision,
              let bookRevision = manager.selectedBookPresentationRevision,
              let source = workspaceProjectionSource, source.isAuthoritative,
              let workspace = try source.read(), workspace.attached, !workspace.isSwitching,
              let mapping = workspace.mappingOwnershipObservation(),
              mapping.coverage == .liveNativeSetters, mapping.scene == sceneID.rawValue,
              mapping.owner == ObjectIdentifier(manager), mapping.source.event.phase == .available,
              mapping.source.event.epoch == mapping.epoch else {
            throw UIRouteError(.unavailable, "history_reader_window_owner_unavailable")
        }
        let selected = bindings.selectedTab.wrappedValue
        guard selected == selected.canonical, manager.currentMode == selected.appMode else {
            throw UIRouteError(.unavailable, "history_reader_window_not_committed")
        }
        let observation = MaktabahNativeComponentSourceObservation {
            _ = manager.openTabs; _ = manager.activeTabId; _ = manager.selectedBook
            _ = manager.selectedContentId; _ = manager.currentMode
            _ = manager.selectedBookForInfo; _ = manager.showingTabsList; _ = manager.alertMessage
            _ = manager.activeReaderViewModel?.isPopoverPresented
            _ = manager.activeReaderViewModel?.readerInspectorVisible
            _ = DonationManager.shared.showDonationSheet
            _ = workspace.attached; _ = workspace.isSwitching
            _ = workspace.mappingOwnershipSource.event
        }
        let validate: @MainActor () throws -> Void = { [weak self, weak manager, weak workspace] in
            try searchPresentation()
            try annotationPresentation()
            _ = try originalWindow.validate()
            try observation.validate()
            guard let self, let manager, let workspace, self.mounted,
                  self.bindings.manager === manager, self.bindings.rootPublications === root,
                  root.selectionRevision == rootRevision, root.settingsRevision == settingsRevision,
                  self.bindings.selectedTab.wrappedValue == selected,
                  manager.currentMode == selected.appMode,
                  manager.nativeModePresentationRevision == modeRevision,
                  manager.selectedBookPresentationRevision == bookRevision,
                  !self.bindings.showSettings.wrappedValue, self.bindings.isPresentationReady,
                  self.workspaceProjectionSource === source, source.isAuthoritative,
                  let current = try source.read(), current === workspace,
                  workspace.attached, !workspace.isSwitching,
                  let actual = workspace.mappingOwnershipObservation(),
                  actual.coverage == .liveNativeSetters, actual.source === mapping.source,
                  actual.owner == mapping.owner, actual.scene == mapping.scene,
                  actual.epoch == mapping.epoch, actual.projection == mapping.projection,
                  actual.source.event.phase == .available, actual.source.event.epoch == actual.epoch else {
                throw UIRouteError(.staleState, "history_reader_window_owner_changed")
            }
            try observation.validate()
            _ = try originalWindow.validate()
            try searchPresentation()
            try annotationPresentation()
        }
        try validate()
        return validate
    }

    /// Reuse the unchanged original root/window/workspace fence. Only the
    /// exact warm editor substitutes its own captured modal facet; no caller
    /// supplies a new scene, editor, record, backend or lifetime.
    private func captureAnnotationEditorWindow(owner: UUID) throws -> @MainActor () throws -> Void {
        guard isOriginalAnnotationEditorRootReady, let original = annotationEditorControls,
              original.originalListOwner == owner else {
            throw UIRouteError(.unavailable, "original_annotation_editor_root_unavailable")
        }
        let observation = MaktabahNativeComponentSourceObservation {
            _ = mounted; _ = studyChatPresentationID
            _ = workspacePresentation?.originalStateRevision
            _ = sefariaSurfaceBinding?.presentationFacets
            _ = savedResultsBinding?.isRequestedOrMounted
        }
        let originalRoot = try captureHistoryReaderWindow(annotationEditorOwner: owner)
        let validate: @MainActor () throws -> Void = { [weak self, weak original] in
            try observation.validate(); try originalRoot()
            guard let self, let original, self.annotationEditorControls === original,
                  original.originalListOwner == owner, self.isOriginalAnnotationEditorRootReady else {
                throw UIRouteError(.staleState, "original_annotation_editor_root_changed")
            }
            try originalRoot(); try observation.validate()
        }
        try validate()
        return validate
    }

    private func captureAnnotationOpeningWindow(owner: UUID, annotation: Annotation, requestID: UUID) throws
        -> @MainActor () throws -> Void {
        guard isOriginalAnnotationEditorRootReady, let original = annotationEditorOpening else {
            throw UIRouteError(.unavailable, "original_annotation_opening_root_unavailable")
        }
        let observation = MaktabahNativeComponentSourceObservation {
            _ = mounted; _ = studyChatPresentationID
            _ = workspacePresentation?.originalStateRevision
            _ = sefariaSurfaceBinding?.presentationFacets
            _ = savedResultsBinding?.isRequestedOrMounted
        }
        let search = try retainHistorySearchPresentationObservation()
        let annotations = try retainOriginalAnnotationOpeningPresentationObservation(owner: owner,
            annotation: annotation, requestID: requestID)
        let root = try captureHistoryReaderWindow(searchPresentation: search, annotationPresentation: annotations)
        let validate: @MainActor () throws -> Void = { [weak self, weak original] in
            try observation.validate(); try root()
            guard let self, let original, self.annotationEditorOpening === original,
                  self.isOriginalAnnotationEditorRootReady else {
                throw UIRouteError(.staleState, "original_annotation_opening_root_changed")
            }
            try root(); try observation.validate()
        }
        try validate()
        return validate
    }
    func retainAnnotationEditor(_ record: NativeAnnotationSelectionIntentService.Record, requestID: UUID) throws
        -> MaktabahNativeAnnotationEditorOpening {
        guard mounted, let original = annotationEditorOpening else {
            throw UIRouteError(.unavailable, "original_annotation_opening_owner_missing")
        }
        try original.retain(record: record, requestID: requestID)
        return original
    }
    func prepareAnnotationEditor(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard mounted, foreground, scene.sceneID == sceneID, let original = annotationEditorOpening else {
            throw UIRouteError(.staleState, "original_annotation_opening_window_changed")
        }
        let selected = try original.selectedItem(requestID: invocation.requestId)
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding,
            savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: MaktabahNativeAnnotationEditorOpening.destination,
            backend: invocation.snapshot.backend, presentation: .init(kind: .sheet),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID, selectedItemID: selected),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }
    func validateCompletedAnnotationEditor(_ receipt: UISceneReceipt,
        original: MaktabahNativeAnnotationEditorOpening) throws {
        guard annotationEditorOpening === original,
              receipt.route.destination == MaktabahNativeAnnotationEditorOpening.destination,
              original.hasVisibleSurface(requestID: receipt.requestId),
              original.observedItem(requestID: receipt.requestId) == receipt.route.state.selectedItemID else {
            throw UIRouteError(.staleState, "original_annotation_opening_completion_changed")
        }
        try original.validateCompletedSurface(requestID: receipt.requestId)
        try validateCompletedJourneySurface(receipt)
        try original.validateSource(requestID: receipt.requestId)
    }

    func retainAnnotation(_ record: NativeAnnotationSelectionIntentService.Record, requestID: UUID) throws
        -> MaktabahNativeAnnotationSelectionBinding {
        guard mounted, let original = annotationSelectionBinding else {
            throw UIRouteError(.unavailable, "native_annotation_owner_missing")
        }
        try original.retain(record: record, requestID: requestID)
        return original
    }
    func prepareAnnotation(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard mounted, foreground, scene.sceneID == sceneID, let original = annotationSelectionBinding else {
            throw UIRouteError(.staleState, "native_annotation_window_changed")
        }
        let selected = try original.selectedItem(requestID: invocation.requestId)
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: MaktabahNativeAnnotationSelectionBinding.destination,
            backend: invocation.snapshot.backend, presentation: .init(kind: .currentTab),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID, selectedItemID: selected),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }
    func validateCompletedAnnotation(_ receipt: UISceneReceipt,
                                     original: MaktabahNativeAnnotationSelectionBinding) throws {
        guard annotationSelectionBinding === original,
              receipt.route.destination == MaktabahNativeAnnotationSelectionBinding.destination,
              original.hasVisibleSurface(requestID: receipt.requestId),
              original.observedItem(requestID: receipt.requestId) == receipt.route.state.selectedItemID else {
            throw UIRouteError(.staleState, "native_annotation_completion_changed")
        }
        try original.validateCompletedSurface(requestID: receipt.requestId)
        try validateCompletedJourneySurface(receipt)
        try original.validateSource(requestID: receipt.requestId)
    }

    func retainSavedResult(_ record: NativeSavedResultIntentService.Record, requestID: UUID) throws
        -> MaktabahNativeSavedResultsBinding {
        guard mounted, let original = savedResultsBinding else {
            throw UIRouteError(.unavailable, "native_saved_results_owner_missing")
        }
        try original.retain(record: record, requestID: requestID)
        return original
    }
    func prepareSavedResult(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard mounted, foreground, scene.sceneID == sceneID, let original = savedResultsBinding else {
            throw UIRouteError(.staleState, "native_saved_results_window_changed")
        }
        let selected = try original.selectedItem(requestID: invocation.requestId)
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: MaktabahNativeSavedResultsBinding.destination,
            backend: invocation.snapshot.backend, presentation: .init(kind: .sheet),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID, selectedItemID: selected),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }
    func validateCompletedSavedResult(_ receipt: UISceneReceipt,
                                     original: MaktabahNativeSavedResultsBinding) throws {
        guard savedResultsBinding === original,
              receipt.route.destination == MaktabahNativeSavedResultsBinding.destination,
              original.hasVisibleSurface(requestID: receipt.requestId),
              original.observedItem(requestID: receipt.requestId) == receipt.route.state.selectedItemID else {
            throw UIRouteError(.staleState, "native_saved_results_completion_changed")
        }
        try original.validateCompletedSurface(requestID: receipt.requestId)
        try validateCompletedJourneySurface(receipt)
        try original.validateSource(requestID: receipt.requestId)
    }

    /// Typed record metadata is converted into private route state only by the
    /// exact scene which retained its actual original publication before await.
    func retainHistoryRecord(_ record: NativeHistoryRecordIntentService.Record, requestID: UUID) throws
        -> MaktabahNativeHistoryRecordBinding {
        guard mounted, let original = historyRecordBinding else {
            throw UIRouteError(.unavailable, "native_history_record_owner_missing")
        }
        try original.retain(record: record, requestID: requestID)
        return original
    }
    func prepareHistoryRecord(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard mounted, foreground, scene.sceneID == sceneID, let original = historyRecordBinding else {
            throw UIRouteError(.staleState, "native_history_record_window_changed")
        }
        let itemID = try original.selectedItem(requestID: invocation.requestId)
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: MaktabahNativeHistoryRecords.destination,
            backend: invocation.snapshot.backend,
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID, selectedItemID: itemID),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }
    func validateCompletedHistoryRecord(_ receipt: UISceneReceipt,
                                        original: MaktabahNativeHistoryRecordBinding) throws {
        guard historyRecordBinding === original,
              receipt.route.destination == MaktabahNativeHistoryRecords.destination,
              try original.selectedItem(requestID: receipt.requestId) == receipt.route.state.selectedItemID,
              try original.observedItem() == receipt.route.state.selectedItemID else {
            throw UIRouteError(.staleState, "native_history_record_completion_changed")
        }
        try validateCompletedJourneySurface(receipt)
        try original.validateSource(requestID: receipt.requestId)
    }

    func validateSurface(_ command: UISceneCommand) throws {
        guard mounted, foreground else { throw UIRouteError(.requiresForeground, "exact_foreground_scene_required") }
        guard isPresentationReady(for: command.route.route.destination) else {
            throw UIRouteError(.unavailable, "native_presentation_in_progress")
        }
        let route = command.route.route, projection = try project()
        let identity = try projection.identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        try validateParentSource(destination: route.destination, requestID: command.invocation.requestId)
        if route.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            guard command.scene.sceneID == sceneID, route.content == nil, route.focus == nil,
                  let bound = workspaceSelectionBinding, bound.isReserved,
                  bound.requestID == command.invocation.requestId,
                  route.backend == bound.target.backend,
                  route.presentation == .init(kind: .currentTab,
                    tabID: bound.target.activeDocumentID.flatMap { UIStableID(rawValue: $0.uuidString) }),
                  route.state == UIStateSpec(workspaceID: UIStableID(rawValue: bound.target.groupID.uuidString),
                                             profileID: UIStableID(rawValue: bound.target.profileID.uuidString)) else {
                throw UIRouteError(.staleState, "native_workspace_selection_route_changed")
            }
            // This private route's original one-use Store/native reservation
            // validates BOTH sides of its authorized workspace change. Generic
            // roots retain the unchanged-workspace guard below.
            try bound.validate()
            return
        }
        guard command.scene.sceneID == sceneID, route.state.workspaceID == identity.state.workspaceID,
              route.state.profileID == identity.state.profileID else { throw UIRouteError(.staleState, "native_workspace_changed") }
        if route.destination == MaktabahNativeAnnotationEditorOpening.destination {
            guard route.content == nil, route.focus == nil, route.presentation == .init(kind: .sheet),
                  let original = annotationEditorOpening,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID,
                    selectedItemID: try original.selectedItem(requestID: command.invocation.requestId)) else {
                throw UIRouteError(.staleState, "original_annotation_opening_route_changed")
            }
            return
        }
        if route.destination == MaktabahNativeAnnotationSelectionBinding.destination {
            guard route.content == nil, route.focus == nil, route.presentation == .init(kind: .currentTab),
                  let annotationSelectionBinding,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID,
                      selectedItemID: try annotationSelectionBinding.selectedItem(requestID: command.invocation.requestId)) else {
                throw UIRouteError(.staleState, "native_annotation_route_changed")
            }
            return
        }
        if route.destination == MaktabahNativeSavedResultsBinding.destination {
            guard route.backend == .otzaria, route.content == nil, route.focus == nil,
                  route.presentation == .init(kind: .sheet), let savedResultsBinding,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID,
                      profileID: identity.state.profileID,
                      selectedItemID: try savedResultsBinding.selectedItem(requestID: command.invocation.requestId)) else {
                throw UIRouteError(.staleState, "native_saved_results_route_changed")
            }
            return
        }
        if route.destination == MaktabahNativeHistoryRecords.destination, let itemID = route.state.selectedItemID {
            guard route.content == nil, route.focus == nil, route.presentation.kind == .currentTab,
                  route.presentation.tabID == nil, let historyRecordBinding,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID,
                      profileID: identity.state.profileID, selectedItemID: itemID),
                  try historyRecordBinding.selectedItem(requestID: command.invocation.requestId) == itemID else {
                throw UIRouteError(.staleState, "native_history_record_route_changed")
            }
            return
        }
        if route.destination == MaktabahNativeReaderTabBinding.destination {
            guard route.content == nil, route.focus == nil, route.presentation.kind == .currentTab,
                  let bound = readerTabBinding, bound.isReserved,
                  bound.requestID == command.invocation.requestId,
                  route.presentation.tabID?.rawValue == bound.target.tabID.uuidString,
                  route.state == UIStateSpec(workspaceID: UIStableID(rawValue: bound.target.groupID.uuidString),
                                             profileID: UIStableID(rawValue: bound.target.profileID.uuidString)) else {
                throw UIRouteError(.staleState, "native_reader_tab_route_changed")
            }
            try bound.validate()
            return
        }
        if route.destination.rawValue == "native.reader.noteDraft" {
            guard route.content == nil, route.focus == nil, route.presentation.kind == .sheet,
                  route.presentation.tabID == nil,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID),
                  let bound = noteDraftBinding, noteEditorOwner === bound.owner else {
                throw UIRouteError(.unavailable, "original_note_editor_unavailable")
            }
            try bound.validate()
            return
        }
        if route.destination.rawValue == "native.search.results" {
            try validateSearchPresentation()
            guard route.content == nil, route.focus == nil, route.presentation.kind == .currentTab,
                  route.presentation.tabID == nil, let searchResultsBinding,
                  searchResultsBinding.requestID == command.invocation.requestId,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID) else {
                throw UIRouteError(.notSupported, "native_search_results_variant_not_installed")
            }
            try searchResultsBinding.validate()
            return
        }
        if route.destination.rawValue == "native.reader.inspector" {
            guard route.content == nil, route.focus == nil, route.presentation.kind == .inspector,
                  route.presentation.tabID == nil,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID,
                      profileID: identity.state.profileID, inspectorVisible: true),
                  try publicBindingPresentation().inspectorAvailable else {
                throw UIRouteError(.unavailable, "native_inspector_reader_unavailable")
            }
            try inspectorBinding?.validate()
            return
        }
        if route.destination.rawValue == "native.reader" {
            guard let content = route.content, let readerBinding, readerBinding.accepts(content),
                  route.presentation.kind == (readerBinding.isNewTab ? .newTab : .currentTab),
                  route.presentation.tabID == readerBinding.targetTabID, route.focus == nil,
                  route.state == UIStateSpec(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID,
                                              inspectorVisible: readerBinding.inspectorVisible) else {
                throw UIRouteError(.notSupported, "native_reader_variant_not_installed")
            }
            try readerBinding.validate()
            return
        }
        if let focus = route.focus {
            if route.destination == NativeSearchFieldVisibility.destination,
               focus.anchor != MaktabahNativeSearchEntryBinding.anchor {
                guard focus == NativeSearchFieldVisibility.focus, searchFieldAvailable,
                      retainedSearchField == nil || retainedSearchField === nativeSearchField else {
                    throw UIRouteError(.unavailable, "native_search_field_not_visible")
                }
            } else {
                guard focus.kind == .component, focus.locator == nil, focus.range == nil,
                      let anchor = focus.anchor, let owner = componentOwners[route.destination],
                      owner.presentation == route.presentation.kind, owner.isAvailable(anchor),
                      retainedComponentOwner == nil || retainedComponentOwner === owner else {
                    throw UIRouteError(.unavailable, "native_component_unavailable")
                }
            }
        }
        guard route.content == nil, route.presentation.tabID == nil,
              route.state == UIStateSpec(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID) else {
            throw UIRouteError(.notSupported, "native_surface_variant_not_installed")
        }
        switch route.destination.rawValue {
        case "native.sefariaEmbedded", "native.sefariaEmbedded.library", "native.sefariaEmbedded.topics",
             "native.sefariaEmbedded.learningSchedules", "native.sefariaEmbedded.dedication":
            guard route.presentation.kind == .sheet, route.focus == nil,
                  isRootAvailable(route.destination) else {
                throw UIRouteError(.unavailable, "native_sefaria_surface_unavailable")
            }
        case "native.annotations.editor":
            guard route.presentation.kind == .sheet, isRootAvailable(route.destination) else {
                throw UIRouteError(.unavailable, "original_annotation_editor_unavailable")
            }
        case "native.workspace.profiles", "native.workspace.overview":
            guard route.presentation.kind == .sheet, isRootAvailable(route.destination) else {
                throw UIRouteError(.unavailable, "native_workspace_parent_unavailable")
            }
        case "native.settings":
            guard route.presentation.kind == .sheet else { throw UIRouteError(.notSupported, "settings_presentation_not_installed") }
        case "native.library", "native.reader.toc", "native.history", "native.search", "native.annotations":
            guard route.presentation.kind == .currentTab, isRootAvailable(route.destination) else {
                throw UIRouteError(.notSupported, "native_root_presentation_unavailable")
            }
        default: throw UIRouteError(.notSupported, "native_surface_not_installed")
        }
    }

    // Opt-in ONLY for the finite original Reader-tab or prepared workspace
    // selection retained on a foreign root. The same preparation owns both effects; these
    // methods grant nothing and never call an async feature action from render.
    func originalParentSelectionKind(for value: UISceneCommand) throws -> UIOriginalParentSelectionKind? {
        if value.route.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            guard command == value, let bound = workspaceSelectionBinding,
                  bound.requestID == value.invocation.requestId, bound.isPrepared else {
                throw UIRouteError(.staleState, "native_workspace_selection_owner_missing")
            }
            guard let kind = try bound.originalParentSelectionKind(), let parent = bound.viewerParent else { return nil }
            try parent.validates(value)
            guard workspaceSelectionBinding === bound, command == value, bound.viewerParent === parent else {
                throw UIRouteError(.staleState, "native_workspace_selection_owner_changed")
            }
            try bound.validate()
            return kind
        }
        guard value.route.route.destination == MaktabahNativeReaderTabBinding.destination else { return nil }
        guard command == value, let bound = readerTabBinding, bound.requestID == value.invocation.requestId,
              bound.isReserved else { throw UIRouteError(.staleState, "native_reader_tab_owner_missing") }
        try bound.validate()
        guard let parent = bound.viewerParent else { return nil }
        try parent.validates(value)
        return .readerTab
    }
    func applyOriginalParent(_ value: UISceneCommand) throws {
        if value.route.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            try validateSurface(value)
            guard command == value, let bound = workspaceSelectionBinding, let parent = bound.viewerParent,
                  bound.requestID == value.invocation.requestId, bound.isPrepared, !bound.isApplied else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            try bound.validate()
            try parent.applyParent(value)
            guard workspaceSelectionBinding === bound, command == value, bound.viewerParent === parent else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            try bound.validate()
            originalPresentationStateDidChange()
            return
        }
        try validateSurface(value)
        guard command == value, let bound = readerTabBinding, let parent = bound.viewerParent,
              bound.requestID == value.invocation.requestId, !bound.isApplied else {
            throw UIRouteError(.staleState, "native_viewer_parent_owner_changed")
        }
        try bound.validate()
        try parent.applyParent(value)
        guard readerTabBinding === bound, command == value else {
            throw UIRouteError(.staleState, "native_viewer_parent_owner_changed")
        }
        try bound.validate()
        originalPresentationStateDidChange()
    }
    func waitUntilOriginalParentReady(_ value: UISceneCommand) async throws -> NativeOriginalParentObservation {
        if value.route.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            guard command == value, let bound = workspaceSelectionBinding, let parent = bound.viewerParent,
                  bound.requestID == value.invocation.requestId, !bound.isApplied else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            try bound.validate()
            let actual = try await parent.waitUntilReady(value)
            guard workspaceSelectionBinding === bound, command == value, bound.viewerParent === parent else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            try bound.validate()
            try parent.validateParent(actual, command: value)
            guard workspaceSelectionBinding === bound, command == value, bound.viewerParent === parent else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            workspaceSelectionParentObservation = actual
            return actual
        }
        guard command == value, let bound = readerTabBinding, let parent = bound.viewerParent,
              bound.requestID == value.invocation.requestId else {
            throw UIRouteError(.staleState, "native_viewer_parent_owner_changed")
        }
        try bound.validate()
        let actual = try await parent.waitUntilReady(value)
        guard readerTabBinding === bound, command == value, bound.viewerParent === parent else {
            throw UIRouteError(.staleState, "native_viewer_parent_owner_changed")
        }
        try bound.validate()
        try parent.validateParent(actual, command: value)
        readerTabParentObservation = actual
        return actual
    }
    func validateOriginalParent(_ actual: NativeOriginalParentObservation, for value: UISceneCommand) throws {
        if value.route.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            guard command == value, let bound = workspaceSelectionBinding, let parent = bound.viewerParent,
                  bound.requestID == value.invocation.requestId, workspaceSelectionParentObservation == actual else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            try bound.validate()
            try parent.validateParent(actual, command: value)
            guard workspaceSelectionBinding === bound, command == value, bound.viewerParent === parent,
                  workspaceSelectionParentObservation == actual else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            try bound.validate()
            return
        }
        guard command == value, let bound = readerTabBinding, let parent = bound.viewerParent,
              bound.requestID == value.invocation.requestId,
              readerTabParentObservation == actual else {
            throw UIRouteError(.staleState, "native_viewer_parent_owner_changed")
        }
        try bound.validate()
        try parent.validateParent(actual, command: value)
        guard readerTabBinding === bound, command == value else {
            throw UIRouteError(.staleState, "native_viewer_parent_owner_changed")
        }
    }
    func applyOriginalSelection(_ value: UISceneCommand) throws {
        if value.route.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            guard command == value, let bound = workspaceSelectionBinding, let parent = bound.viewerParent,
                  bound.requestID == value.invocation.requestId, let actual = workspaceSelectionParentObservation else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            try validateOriginalParent(actual, for: value)
            try parent.beginSelection(actual, command: value)
            guard workspaceSelectionBinding === bound, command == value, bound.viewerParent === parent else {
                throw UIRouteError(.staleState, "native_workspace_selection_parent_changed")
            }
            // The SAME Core terminal capability was just consumed. The complete
            // original group flush/Store/native publisher stays synchronous.
            try apply(value)
            return
        }
        guard command == value, let bound = readerTabBinding, let parent = bound.viewerParent,
              bound.requestID == value.invocation.requestId, let actual = readerTabParentObservation else {
            throw UIRouteError(.staleState, "native_viewer_parent_owner_changed")
        }
        try validateOriginalParent(actual, for: value)
        try parent.beginSelection(actual, command: value)
        // This is the unchanged canonical Reader-tab apply owner. It calls
        // the original manager.selectTab and its original Store checkpoint.
        try apply(value)
    }

    func apply(_ command: UISceneCommand) throws {
        if command.route.route.destination == MaktabahNativeAnnotationEditorOpening.destination {
            try validateSurface(command)
            guard retainedAnnotationEditorOpening, let original = annotationEditorOpening else {
                throw UIRouteError(.staleState, "original_annotation_opening_owner_missing")
            }
            try original.apply(requestID: command.invocation.requestId)
            return
        }
        if command.route.route.destination == MaktabahNativeAnnotationEditorControls.destination {
            try validateSurface(command)
            guard retainedAnnotationEditor, let original = annotationEditorControls else {
                throw UIRouteError(.staleState, "original_annotation_editor_owner_missing")
            }
            try original.apply(requestID: command.invocation.requestId)
            if let owner = retainedComponentOwner { try owner.apply(requestID: command.invocation.requestId) }
            try original.validateSource(requestID: command.invocation.requestId)
            return
        }
        if command.route.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            try validateSurface(command)
            guard let bound = workspaceSelectionBinding else {
                throw UIRouteError(.unavailable, "native_workspace_selection_owner_missing")
            }
            try bound.apply()
            originalPresentationStateDidChange()
            return
        }
        if command.route.route.destination == MaktabahNativeAnnotationSelectionBinding.destination {
            try validateSurface(command)
            guard retainedAnnotationSelection, let annotationSelectionBinding else {
                throw UIRouteError(.staleState, "native_annotation_owner_missing")
            }
            try annotationSelectionBinding.apply(requestID: command.invocation.requestId)
            return
        }
        if command.route.route.destination == MaktabahNativeSavedResultsBinding.destination {
            try validateSurface(command)
            guard retainedSavedResults, let savedResultsBinding else {
                throw UIRouteError(.staleState, "native_saved_results_not_prepared")
            }
            try savedResultsBinding.apply(requestID: command.invocation.requestId)
            return
        }
        if command.route.route.destination == MaktabahNativeHistoryRecords.destination,
           command.route.route.state.selectedItemID != nil {
            try validateSurface(command)
            guard retainedHistoryRecord, let historyRecordBinding else {
                throw UIRouteError(.staleState, "native_history_record_not_prepared")
            }
            try historyRecordBinding.apply(requestID: command.invocation.requestId)
            return
        }
        if command.route.route.destination == MaktabahNativeReaderTabBinding.destination {
            try validateSurface(command)
            guard let bound = readerTabBinding else { throw UIRouteError(.unavailable, "native_reader_tab_owner_missing") }
            try bound.apply()
            originalPresentationStateDidChange()
            return
        }
        if MaktabahNativeSefariaSurfaceBinding.accepts(command.route.route.destination) {
            try validateSurface(command)
            guard retainedSefariaSurface, let original = sefariaSurfaceBinding else {
                throw UIRouteError(.staleState, "native_sefaria_parent_not_prepared")
            }
            // The sole Core-authorized commit opens the original RN sheet.
            // A semantic target additionally retains its exact private one-use
            // handoff; Maktabah's root/Reader/Settings remain untouched.
            try original.apply(requestID: command.invocation.requestId)
            return
        }
        if usesOriginalPhoneTOC(command.route.route.destination) {
            try validateSurface(command)
            guard retainedPhoneTOC, let phoneTOCPresentation else {
                throw UIRouteError(.staleState, "native_phone_toc_parent_not_prepared")
            }
            if let owner = retainedComponentOwner { try owner.apply(requestID: command.invocation.requestId) }
            try phoneTOCPresentation.apply(requestID: command.invocation.requestId)
            return
        }
        if let parent = MaktabahNativeWorkspacePresentationBinding.Parent(rawValue: command.route.route.destination.rawValue) {
            try validateSurface(command)
            guard retainedWorkspaceParent == parent, let workspacePresentation else {
                throw UIRouteError(.staleState, "native_workspace_parent_not_prepared")
            }
            if let owner = retainedComponentOwner { try owner.apply(requestID: command.invocation.requestId) }
            // One canonical commit. Only the captured original parent setter
            // runs; any cold host continuation keeps this same source/deadline.
            try workspacePresentation.apply(parent: parent, requestID: command.invocation.requestId)
            return
        }
        if command.route.route.destination.rawValue == "native.reader.noteDraft" {
            try validateSurface(command)
            guard let bound = noteDraftBinding else { throw ActionPortError.unavailable }
            try bound.apply()
            // Observe the actual editor's UITextView. Its binding checks the
            // frontmost sheet, scene, text and TextKit layout on each read.
            observeVisibility(for: command.route.route.destination) { [weak self, weak bound] in
                guard let self, let bound, noteDraftBinding === bound,
                      noteEditorOwner === bound.owner, (try? bound.validateVisible()) != nil,
                      let actual = try? surface(.noteDraft) else { return nil }
                return .init(sceneID: sceneID, surface: actual, isVisible: true,
                             submissionID: command.invocation.requestId)
            }
            #if DEBUG
            diagnoseNoteDraftSurface(stage: "after-apply")
            #endif
            return
        }
        if command.route.route.destination.rawValue == "native.search.results" {
            try validateSurface(command)
            guard let searchResultsBinding else { throw UIRouteError(.unavailable, "native_search_owner_missing") }
            try searchResultsBinding.apply {
                bindings.showSettings.wrappedValue = false
                if !MaktabahApp.isIpad { bindings.manager.selectedBook = nil }
                bindings.selectedTab.wrappedValue = .search
                bindings.manager.switchToMode(.search)
            }
            return
        }
        if command.route.route.destination.rawValue == "native.reader.inspector" {
            try validateSurface(command)
            guard let inspectorBinding else { throw UIRouteError(.unavailable, "native_inspector_owner_missing") }
            try inspectorBinding.apply()
            return
        }
        if let owner = retainedComponentOwner, command.route.route.focus != nil {
            try validateSurface(command)
            try owner.apply(requestID: command.invocation.requestId)
            if let searchEntryBinding, owner === searchEntryBinding.owner {
                try searchEntryBinding.apply(requestID: command.invocation.requestId)
                searchEntryBinding.renderOriginalFieldIfReady()
                return
            }
            // One guarded, synchronous navigation commit publishes BOTH parent
            // visibility and exact target. The original view renders that state.
            try bindings.apply(command)
            return
        }
        if command.route.route.focus != nil {
            // Focus only an ALREADY VISIBLE original field. A caller first
            // opens the Search root through this same orchestrator, then
            // requests its component; no deferred mutation borrows a grant.
            try validateSurface(command)
            guard let field = retainedSearchField, nativeSearchField === field,
                  field.isFirstResponder || field.becomeFirstResponder(),
                  nativeSearchField === field, field.isFirstResponder,
                  NativeSearchFieldVisibility.isVisible(field, in: sceneID) else {
                throw UIRouteError(.unavailable, "native_search_focus_not_applied")
            }
            searchFieldStateDidChange(field)
            return
        }
        if command.route.route.destination.rawValue == "native.reader" {
            guard let readerBinding else { throw UIRouteError(.unavailable, "native_reader_owner_missing") }
            try readerBinding.apply { try bindings.apply(command, reservedTab: readerBinding.reservedTab) }
        } else { try bindings.apply(command) }
    }

    func waitUntilVisible(_ command: UISceneCommand) async throws -> NativeSurfaceState {
        if MaktabahNativeSefariaSurfaceBinding.accepts(command.route.route.destination) {
            guard retainedSefariaSurface, let original = sefariaSurfaceBinding,
                  submissionID == command.invocation.requestId else {
                throw UIRouteError(.staleState, "native_sefaria_wait_not_owned")
            }
            try validateSurface(command)
            // This awaits the original RPC/host children inside the existing
            // orchestrator deadline. No detached task, new grant or new timer
            // extends that admission. Cancellation joins the original child.
            try await original.awaitOriginalSurface(requestID: command.invocation.requestId)
            try Task.checkCancellation()
            try validateSurface(command)
            if let actual = visibilityChecks[command.route.route.destination]?() { observe(actual) }
        }
        #if DEBUG
        if command.route.route.destination.rawValue == "native.reader.noteDraft" {
            diagnoseNoteDraftSurface(stage: "wait-begin")
        }
        #endif
        // A container's deduplicated layout callback can precede final geometry
        // or TextKit paint/scroll restoration. Observe the same live UIKit
        // witness only while its original request is waiting; never echo the route.
        let readerObservation: Task<Void, Never>?
        if retainedComponentOwner != nil || retainedHistoryRecord || retainedSavedResults || retainedAnnotationSelection || retainedAnnotationEditor || retainedAnnotationEditorOpening || ["native.reader", "native.reader.tab", "native.workspace.selection", "native.reader.noteDraft", "native.library", "native.reader.toc", "native.annotations",
                                             "native.workspace.profiles", "native.workspace.overview", "native.sefariaEmbedded"].contains(command.route.route.destination.rawValue) {
            readerObservation = Task { @MainActor [weak self] in
                while !Task.isCancelled {
                    guard let self, mounted, submissionID == command.invocation.requestId else { return }
                    if retainedHistoryRecord { historyRecordBinding?.renderOriginalContainer() }
                    if let actual = visibilityChecks[command.route.route.destination]?() { observe(actual) }
                    do { try await Task.sleep(for: .milliseconds(33)) } catch { return }
                }
            }
        } else { readerObservation = nil }
        defer { readerObservation?.cancel() }
        do { return try await presentation.wait(for: command).surface }
        catch {
            #if DEBUG
            OtzariaFileLogger.shared.log("[NativePresentationWait] code=\((error as? UIRouteError)?.code ?? (error is CancellationError ? "cancelled" : "unavailable")) mounted=\(mounted) foreground=\(foreground) ready=\(isPresentationReady)")
            if command.route.route.destination.rawValue == "native.reader.noteDraft" {
                diagnoseNoteDraftSurface(stage: "wait-error")
            }
            #endif
            throw error
        }
    }

    func nativeStateChanged() throws {
        guard let lease else { return }
        try directory.invalidate(lease)
    }

    func updateProjection(_ project: @escaping @MainActor () throws -> MaktabahNativeSceneProjection) {
        self.project = project
    }
    func surface(_ kind: MaktabahNativeSceneProjection.Surface) throws -> NativeSurfaceState? {
        if kind == .sefariaEmbedded {
            let source = submissionID.flatMap { sefariaRootSources[$0] } ?? completedSefariaRootSource
            guard let source, isSefariaOriginalRootReady else { return nil }
            try source.validate(bindings, workspace: workspacePresentation)
        }
        if kind == .inspector { try inspectorBinding?.validate() }
        if kind == .noteDraft {
            guard let bound = noteDraftBinding, bound.isApplied, noteEditorOwner === bound.owner else { return nil }
            try bound.validate()
        }
        if kind == .searchResults {
            // Allow the native witness to mount during this route's own
            // transition so UIKit can report viewDidAppear. The exact window
            // is rechecked at completion; local overlays must hide the witness.
            guard searchPresentationBlocked?() != true else { return nil }
            guard let searchResultsBinding else { return nil }
            try searchResultsBinding.validateCompleted()
        }
        _ = componentRevision
        _ = phoneTOCPresentation?.stateRevision
        _ = sefariaSurfaceBinding?.renderRevision
        let historySource = kind == .history && (retainedHistoryRecord
            || (command == nil && lastCompletedSurface?.route.destination == MaktabahNativeHistoryRecords.destination
                && lastCompletedSurface?.route.state.selectedItemID != nil)) ? historyRecordBinding : nil
        let annotationOpening = kind == .annotationEditor && (retainedAnnotationEditorOpening
            || (command == nil && lastCompletedSurface?.route.destination == MaktabahNativeAnnotationEditorOpening.destination))
            ? annotationEditorOpening : nil
        let annotationSource = kind == .annotations && (retainedAnnotationSelection
            || (command == nil && lastCompletedSurface?.route.destination == MaktabahNativeAnnotationSelectionBinding.destination))
            ? annotationSelectionBinding : nil
        guard let state = try project().surface(kind, workspacePresentation: workspacePresentation,
                                               phoneTOCPresentation: phoneTOCPresentation,
                                               sefariaSurface: sefariaSurfaceBinding,
                                               historyRecord: historySource,
                                               annotationSelection: annotationSource,
                                               annotationRequestID: annotationSource != nil ? submissionID ?? lastCompletedSurface?.route.requestId : nil,
                                               annotationOpening: annotationOpening,
                                               annotationOpeningRequestID: annotationOpening != nil
                                                   ? submissionID ?? lastCompletedSurface?.route.requestId : nil,
                                               annotationEditor: annotationEditorControls,
                                               annotationEditorRequestID: kind == .annotationEditor
                                                   ? submissionID ?? lastCompletedSurface?.route.requestId : nil,
                                               savedResults: savedResultsBinding,
                                               savedResultsRequestID: kind == .savedResults
                                                   ? submissionID ?? lastCompletedSurface?.route.requestId : nil) else { return nil }
        if let bound = workspaceSelectionBinding, kind == bound.observedSurface {
            return try bound.selectionSurface(from: state)
        }
        if kind == .reader, let bound = readerTabBinding {
            return try bound.selectionSurface(from: state)
        }
        if command?.route.route.focus != nil, let owner = retainedComponentOwner, owner.destination == state.destination {
            _ = componentRevision
            return .init(destination: state.destination, presentation: state.presentation,
                         content: state.content, state: state.state, focus: owner.actualFocus(in: sceneID))
        }
        // Root navigation does not request or report keyboard focus. For the
        // registered component, the optional focus facet is projected ONLY
        // from the same retained, visible UIKit field's actual responder state.
        // The incoming anchor is never copied into native evidence.
        guard state.destination == NativeSearchFieldVisibility.destination,
              command?.route.route.focus != nil else { return state }
        _ = searchFieldRevision
        let actual: FocusSpec?
        if let field = retainedSearchField, nativeSearchField === field, field.isFirstResponder,
           NativeSearchFieldVisibility.isVisible(field, in: sceneID) {
            actual = NativeSearchFieldVisibility.focus
        } else { actual = nil }
        return .init(destination: state.destination, presentation: state.presentation,
            content: state.content, state: state.state, focus: actual)
    }
    /// Recheck the original UIKit surface after the navigation request has been retired.
    func guidePresentationIdentity(for route: RouteSpec) throws -> NativeSceneIdentity? {
        guard mounted, foreground, isPresentationReady(for: route.destination), let kind = surfaceKind(route.destination),
              let evidence = visibilityChecks[route.destination]?(), evidence.isVisible, evidence.sceneID == sceneID,
              let actual = try surface(kind), actual == evidence.surface,
              actual.destination == route.destination, actual.presentation == route.presentation,
              actual.content == route.content, actual.state == route.state else { return nil }
        if kind == .reader {
            guard try project().hasRenderedReaderEvidence(sceneID: sceneID,
                includingContainingSection: route.destination == MaktabahNativeReaderTabBinding.destination
                    || route.destination == MaktabahNativeWorkspaceSelectionBinding.destination) else { return nil }
        }
        if actual.focus != route.focus {
            let searchFocus = route.destination == NativeSearchFieldVisibility.destination
                && route.focus == NativeSearchFieldVisibility.focus
                && nativeSearchField?.isFirstResponder == true && searchFieldAvailable
            let componentFocus = route.focus != nil && componentOwners[route.destination]?.actualFocus(in: sceneID) == route.focus
            guard searchFocus || componentFocus else { return nil }
        }
        return try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
    }

    func usesWorkspaceOwner(_ owner: MaktabahNativeWorkspaceOwner) -> Bool { workspaceProjectionSource?.uses(owner) == true }
    /// Passive independent evidence only. With the reader marker absent this
    /// stays nil even if a reader model contains the requested destination.
    func publicBindingPresentation() throws -> MaktabahNativePublicPresentation {
        let readerID = UIDestinationID(rawValue: "native.reader")!
        var reader: NativeSurfaceState?
        if let evidence = visibilityChecks[readerID]?(), evidence.isVisible, evidence.sceneID == sceneID,
           let current = try project().surface(.reader),
           current == evidence.surface,
           try project().hasRenderedReaderEvidence(sceneID: sceneID, includingContainingSection: true) { reader = current }
        let inspectorID = UIDestinationID(rawValue: "native.reader.inspector")!
        let inspectorWitnessed: Bool
        if let evidence = visibilityChecks[inspectorID]?(), evidence.isVisible, evidence.sceneID == sceneID,
           let actual = try surface(.inspector), actual == evidence.surface { inspectorWitnessed = true }
        else { inspectorWitnessed = false }
        let inspectorAvailable = MaktabahNativeInspectorBinding.currentReader(in: bindings.manager) != nil
            && (reader != nil || inspectorWitnessed)
        return .init(ready: mounted && foreground && isPresentationReady,
            historyRootAvailable: HistoryViewModel.shared.searchText.isEmpty,
            tableOfContentsAvailable: isRootAvailable(MaktabahNativeTOCComponents.destination), witnessedReader: reader,
            searchFieldAvailable: searchFieldAvailable,
            readyTableOfContents: mounted && foreground && isPresentationReady(for: MaktabahNativeTOCComponents.destination),
            readySefariaSurface: mounted && foreground && isPresentationReady(for: MaktabahNativeSefariaSurfaceBinding.destination),
            readySavedResults: mounted && foreground && isPresentationReady(for: MaktabahNativeSavedResultsBinding.destination),
            readyAnnotationEditor: mounted && foreground && isPresentationReady(for: MaktabahNativeAnnotationEditorControls.destination),
            readyWorkspaceParents: Set(MaktabahNativeWorkspacePresentationBinding.Parent.allCases
                .filter { mounted && foreground && isPresentationReady(for: $0.destination) }.map(\.destination)),
            availableComponents: Dictionary(uniqueKeysWithValues: componentOwners.map { destination, owner in
                // A pushed Settings child is not the original Form. Do not
                // pretend setting its existing sheet flag can pop that stack.
                let presentable = destination != MaktabahNativeSettingsComponents.destination
                    || !bindings.showSettings.wrappedValue || owner.isMounted
                return (destination, Set(owner.descriptors.filter { presentable && owner.isAvailable($0.anchor) }.map(\.anchor)))
            }), inspectorAvailable: inspectorAvailable,
            witnessedInspectorVisible: inspectorWitnessed ? true : reader?.state.inspectorVisible)
    }
    /// Independent source identity for the explicit current-work consent offer;
    /// this does not relax the native route's surface or visibility receipt.
    func hanlinCurrentWorkReadSource() throws -> MaktabahNativeSceneProjection.HanlinCurrentWorkReadSource? {
        try project().hanlinCurrentWorkReadSource()
    }
    /// A freshness facet from the existing scene projection; no selected text or content grant.
    func hanlinSelectionRange() throws -> UIUTF16Range? { try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls).selectedRange }
    func ownsInspectorReader(_ reader: ReaderViewModel) -> Bool {
        MaktabahNativeInspectorBinding.currentReader(in: bindings.manager) === reader
    }
    func observeVisibility(for destination: UIDestinationID, check: @escaping @MainActor () -> NativeSurfaceWitness.Evidence?) {
        visibilityChecks[destination] = check
    }

    /// Retain the exact mounted original Search BEFORE any asynchronous work.
    /// Source metadata never selects a window or submits a new query.
    func retainSearchContinuation(requestID: UUID,
        currentSnapshot: @escaping @MainActor () throws -> ActionBackendSnapshot) throws
        -> MaktabahNativeSearchContinuationOwner {
        try validateSearchPresentation()
        guard mounted, foreground, isPresentationReady, command == nil,
              searchContinuationOwner == nil, searchResultsBinding == nil,
              readerBinding == nil, readerTabBinding == nil, workspaceSelectionBinding == nil,
              let source = workspaceProjectionSource, let originalPresentation = searchPresentationOwner,
              bindings.selectedTab.wrappedValue == .search, bindings.manager.currentMode == .search else {
            throw UIRouteError(.unavailable, "native_search_continuation_scene_busy")
        }
        let window = try retainOriginalWindowObservation()
        let owner = try MaktabahNativeSearchContinuationOwner(requestID: requestID, sceneID: sceneID,
            bindings: bindings, workspaceSource: source, window: window,
            readForeign: { [weak self] in
                guard let self else { return }
                _ = self.mounted; _ = self.foreground; _ = self.studyChatPresentationID
                _ = self.workspacePresentation?.originalStateRevision
                // Notes uses original SwiftUI State, not Observation. Its exact
                // original setter retires this owner synchronously above.
            }, validateScene: { [weak self] in
                guard let self, self.mounted, self.foreground, self.isPresentationReady,
                      self.command == nil, self.searchResultsBinding == nil,
                      self.readerBinding == nil, self.readerTabBinding == nil, self.workspaceSelectionBinding == nil,
                      self.searchPresentationOwner == originalPresentation else {
                    throw UIRouteError(.staleState, "native_search_continuation_scene_changed")
                }
                try self.validateSearchPresentation()
            }, currentSnapshot: currentSnapshot)
        searchContinuationOwner = owner
        return owner
    }

    func validateSearchContinuationOwner(_ owner: MaktabahNativeSearchContinuationOwner) throws {
        guard searchContinuationOwner === owner, owner.sceneID == sceneID else {
            throw UIRouteError(.staleState, "native_search_continuation_scene_owner_replaced")
        }
        try owner.validate()
    }

    func releaseSearchContinuation(_ owner: MaktabahNativeSearchContinuationOwner) {
        guard searchContinuationOwner === owner else { return }
        owner.retire(); searchContinuationOwner = nil
    }

    /// Metadata queries neither select a scene nor prepare Core/source claims.
    /// A background window is eligible only while its SAME original Search
    /// and original attached list/window remain identifiable; execution still
    /// requires the unchanged foreground/geometry owner above.
    func publicSearchContinuationTargets(_ query: NativeSearchContinuationIntentService.Query,
        windowTitle: String, currentSnapshot: @escaping @MainActor () throws -> ActionBackendSnapshot)
        throws -> [NativeSearchContinuationIntentService.Target] {
        guard mounted, command == nil, searchResultsBinding == nil, searchContinuationOwner == nil,
              readerBinding == nil, readerTabBinding == nil, workspaceSelectionBinding == nil,
              isPresentationReady, !bindings.showSettings.wrappedValue,
              searchPresentationOwner != nil, searchPresentationBlocked?() != true,
              bindings.selectedTab.wrappedValue == .search, bindings.manager.currentMode == .search,
              MaktabahApp.isIpad || bindings.manager.selectedBook == nil else { return [] }
        if publicSearchContinuationCatalog == nil {
            publicSearchContinuationCatalog = .init(sceneID: sceneID, capture: { [weak self] in
                guard let self, mounted, let source = workspaceProjectionSource,
                      let originalPresentation = searchPresentationOwner,
                      let workspacePresentation,
                      let originalWorkspaceRevision = workspacePresentation.originalStateRevision else {
                    throw ActionPortError.unavailable
                }
                let window = try retainOriginalWindowObservation()
                return try MaktabahNativeSearchContinuationCatalog.captureOriginal(sceneID: sceneID,
                    readBindings: { [weak self] in
                        guard let self, mounted else { throw ActionPortError.staleState }
                        return bindings
                    }, workspaceSource: source, window: window, windowTitle: windowTitle,
                    readForeign: { [weak self] in
                        guard let self else { return }
                        _ = mounted; _ = studyChatPresentationID
                        _ = self.workspacePresentation?.originalStateRevision
                        // Exact original Search/Notes local-State setters retire
                        // the catalog synchronously. Foreground is not metadata.
                    }, validateScene: { [weak self, weak source, weak workspacePresentation] in
                        guard let self, let source, let workspacePresentation,
                              mounted, isPresentationReady, command == nil,
                              searchResultsBinding == nil, readerBinding == nil,
                              readerTabBinding == nil, workspaceSelectionBinding == nil,
                              workspaceProjectionSource === source,
                              self.workspacePresentation === workspacePresentation,
                              workspacePresentation.originalStateRevision == originalWorkspaceRevision,
                              searchPresentationOwner == originalPresentation,
                              searchPresentationBlocked?() != true,
                              MaktabahApp.isIpad || bindings.manager.selectedBook == nil else {
                            throw ActionPortError.staleState
                        }
                        if let owner = searchContinuationOwner,
                           publicSearchContinuationCatalog?.ownsSelection(requestID: owner.requestID) != true {
                            throw ActionPortError.staleState
                        }
                    }, currentSnapshot: currentSnapshot)
            })
        }
        guard let catalog = publicSearchContinuationCatalog else { throw ActionPortError.unavailable }
        do { return try catalog.targets(query) }
        catch ActionPortError.unavailable { return [] }
        catch ActionPortError.staleState { return [] }
    }

    func retainPublicSearchContinuation(_ request: NativeSearchContinuationIntentService.OpenRequest)
        throws -> MaktabahNativeSearchContinuationCatalog.Selection {
        guard mounted, searchContinuationOwner == nil, command == nil,
              let catalog = publicSearchContinuationCatalog else { throw ActionPortError.staleState }
        return try catalog.retain(request)
    }

    /// Synchronous readiness for Core capability/availability checks. This
    /// observes only the original scene, presentation and search model; it
    /// neither submits a query nor acquires a request-specific binding.
    func canPrepareSearchResults() -> Bool {
        let manager = bindings.manager, session = bindings.manager.unifiedSearchSession
        guard mounted, foreground, isPresentationReady, searchResultsBinding == nil,
              (try? validateSearchPresentation()) != nil,
              session.searchViewModel === manager.searchViewModel,
              session.selectedBookIds == manager.searchViewModel.selectedBookIds,
              session.availableScopes.contains(.exact),
              !session.showsBookFilterSheet, !session.showsSearchDataSheet,
              !session.showsAdvancedOptions else { return false }
        return true
    }

    func retainSearchResults(_ query: ActionSearchResultsQuery, requestID: UUID) throws -> MaktabahNativeSearchResultsBinding {
        try validateSearchPresentation()
        guard canPrepareSearchResults() else {
            throw UIRouteError(.unavailable, "native_search_owner_unavailable")
        }
        let retained = try MaktabahNativeSearchResultsBinding(manager: bindings.manager, query: query, requestID: requestID)
        searchResultsBinding = retained
        return retained
    }
    func releaseSearchResults(_ binding: MaktabahNativeSearchResultsBinding) {
        if searchResultsBinding === binding { searchResultsBinding = nil }
    }
    func prepareSearchResults(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        try validateSearchPresentation()
        guard let searchResultsBinding, searchResultsBinding.requestID == invocation.requestId else {
            throw UIRouteError(.unavailable, "native_search_owner_missing")
        }
        try searchResultsBinding.validate()
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: UIDestinationID(rawValue: "native.search.results")!,
            backend: invocation.snapshot.backend, presentation: .init(kind: .currentTab),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision),
            expectedBackendSnapshot: invocation.snapshot)
    }
    func validateSearchResultsCompletion(requestID: UUID) throws {
        try validateSearchPresentation()
        guard let searchResultsBinding, searchResultsBinding.requestID == requestID,
              mounted, foreground, isPresentationReady,
              let surface = try surface(.searchResults),
              let evidence = visibilityChecks[surface.destination]?(),
              evidence.isVisible, evidence.sceneID == sceneID, evidence.surface == surface else {
            throw UIRouteError(.staleState, "native_search_results_no_longer_visible")
        }
        try searchResultsBinding.validateCompleted()
    }

    func windowLabel(number: Int) -> String {
        let projection = try? project()
        let names = [projection?.workspace?.profile?.name, projection?.workspace?.group?.name]
            .compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: " / ")
        let window = String(localized: "Window \(number)")
        return names.isEmpty ? window : names + " — " + window
    }

    func prepare(_ route: PublicRouteSpec, invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard !MaktabahNativeSefariaSurfaceBinding.accepts(route.destination),
              !usesOriginalPhoneTOC(route.destination), isRootAvailable(route.destination),
              route.content == nil, route.presentation == .currentTab else {
            throw UIRouteError(.notSupported, "public_native_variant_not_installed")
        }
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: route.destination, backend: invocation.snapshot.backend,
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision), expectedBackendSnapshot: invocation.snapshot)
    }

    /// Only the private original Guide branch calls this finite preparation.
    /// It creates no grant; the existing Core/orchestrator owns the same commit.
    func prepareOriginalSefariaGuide(invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        let destination = UIDestinationID(rawValue: SefariaEmbeddedSemanticTarget.dedication.destinationID)!
        guard scene.sceneID == sceneID, invocation.snapshot.backend == .sefariaEmbedded,
              scene.backendSnapshot == invocation.snapshot, isRootAvailable(destination),
              isPresentationReady(for: destination) else {
            throw UIRouteError(.unavailable, "native_sefaria_guide_unavailable")
        }
        try validateParentSource(destination: destination, requestID: invocation.requestId)
        let identity = try project().identity(workspacePresentation: workspacePresentation,
            sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: destination, backend: invocation.snapshot.backend,
            presentation: .init(kind: .sheet),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision), expectedBackendSnapshot: invocation.snapshot)
    }

    func prepare(destination: UIDestinationID, invocation: ActionPortInvocation, scene: UISceneSnapshot) throws -> RouteSpec {
        guard !MaktabahNativeSefariaSurfaceBinding.accepts(destination) else {
            throw UIRouteError(.unavailable, "native_sefaria_parent_binding_required")
        }
        guard !usesOriginalPhoneTOC(destination) else {
            throw UIRouteError(.unavailable, "native_phone_toc_parent_binding_required")
        }
        guard destination.rawValue == "native.settings"
            || (MaktabahNativeRootDestination(rawValue: destination.rawValue) != nil && isRootAvailable(destination)) else {
            throw UIRouteError(.notSupported, "native_surface_not_installed")
        }
        let identity = try project().identity(workspacePresentation: workspacePresentation, sefariaSurface: sefariaSurfaceBinding, savedResults: savedResultsBinding, annotationEditor: annotationEditorControls)
        return RouteSpec(requestId: invocation.requestId, destination: destination, backend: invocation.snapshot.backend,
            presentation: .init(kind: destination.rawValue == "native.settings" ? .sheet : .currentTab),
            state: .init(workspaceID: identity.state.workspaceID, profileID: identity.state.profileID),
            scene: .init(kind: .specific, sceneID: sceneID, expectedRevision: scene.revision), expectedBackendSnapshot: invocation.snapshot)
    }

    func observe(_ evidence: NativeSurfaceWitness.Evidence) {
        guard mounted, evidence.sceneID == sceneID else { return }
        if evidence.isVisible, evidence.surface.destination == MaktabahNativeAnnotationEditorOpening.destination {
            do {
                guard retainedAnnotationEditorOpening, let original = annotationEditorOpening,
                      let requestID = evidence.submissionID, submissionID == requestID,
                      command?.invocation.requestId == requestID else {
                    throw UIRouteError(.staleState, "original_annotation_opening_report_not_owned")
                }
                try original.withValidatedSurface(requestID: requestID) {
                    guard isPresentationReady(for: evidence.surface.destination),
                          let actual = try surface(.annotationEditor), actual == evidence.surface else {
                        throw UIRouteError(.staleState, "original_annotation_opening_report_changed")
                    }
                    recordNativeObservation(evidence)
                }
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        if evidence.isVisible, evidence.surface.destination == MaktabahNativeAnnotationEditorControls.destination {
            do {
                guard retainedAnnotationEditor, let original = annotationEditorControls,
                      let requestID = evidence.submissionID, submissionID == requestID,
                      command?.invocation.requestId == requestID else {
                    throw UIRouteError(.staleState, "original_annotation_editor_report_not_owned")
                }
                try original.withValidatedSurface(requestID: requestID) {
                    guard isPresentationReady(for: evidence.surface.destination),
                          let actual = try surface(.annotationEditor), actual == evidence.surface else {
                        throw UIRouteError(.staleState, "original_annotation_editor_report_changed")
                    }
                    recordNativeObservation(evidence)
                }
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        if evidence.isVisible, evidence.surface.destination == MaktabahNativeAnnotationSelectionBinding.destination {
            do {
                guard retainedAnnotationSelection, let original = annotationSelectionBinding,
                      let requestID = evidence.submissionID, submissionID == requestID,
                      command?.invocation.requestId == requestID else {
                    throw UIRouteError(.staleState, "native_annotation_report_not_owned")
                }
                try original.withValidatedSurface(requestID: requestID) {
                    guard isPresentationReady(for: evidence.surface.destination),
                          let actual = try surface(.annotations), actual == evidence.surface else {
                        throw UIRouteError(.staleState, "native_annotation_report_changed")
                    }
                    recordNativeObservation(evidence)
                }
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        if evidence.isVisible, evidence.surface.destination == MaktabahNativeSavedResultsBinding.destination {
            do {
                guard retainedSavedResults, let original = savedResultsBinding,
                      let requestID = evidence.submissionID, submissionID == requestID,
                      command?.invocation.requestId == requestID else {
                    throw UIRouteError(.staleState, "native_saved_results_report_not_owned")
                }
                try original.withValidatedSurface(requestID: requestID) {
                    guard isPresentationReady(for: evidence.surface.destination),
                          let actual = try surface(.savedResults), actual == evidence.surface else {
                        throw UIRouteError(.staleState, "native_saved_results_report_changed")
                    }
                    recordNativeObservation(evidence)
                }
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        if evidence.isVisible, evidence.surface.destination == MaktabahNativeHistoryRecords.destination,
           evidence.surface.state.selectedItemID != nil, let requestID = evidence.submissionID {
            do {
                guard retainedHistoryRecord, let original = historyRecordBinding,
                      submissionID == requestID, command?.invocation.requestId == requestID else {
                    throw UIRouteError(.staleState, "native_history_record_report_not_owned")
                }
                // The actor's exact publication token remains locked across
                // final row/root revalidation and the original native report.
                try original.withValidatedRecord(requestID: requestID) {
                    guard let current = try surface(.history), current == evidence.surface else {
                        throw UIRouteError(.staleState, "native_history_record_report_changed")
                    }
                    recordNativeObservation(evidence)
                }
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        if evidence.isVisible, evidence.surface.destination.rawValue == "native.reader.noteDraft",
           (try? noteDraftBinding?.validateVisible()) == nil {
            if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
            return
        }
        if evidence.isVisible, evidence.surface.destination.rawValue == "native.reader",
           (try? project().hasRenderedReaderEvidence(sceneID: sceneID)) != true {
            if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
            return
        }
        if evidence.isVisible, evidence.surface.destination == MaktabahNativeWorkspaceSelectionBinding.destination {
            do {
                guard let bound = workspaceSelectionBinding, bound.isApplied,
                      evidence.submissionID == bound.requestID, submissionID == bound.requestID,
                      command?.invocation.requestId == bound.requestID,
                      isPresentationReady(for: evidence.surface.destination),
                      let current = try surface(bound.observedSurface), current == evidence.surface else {
                    throw UIRouteError(.staleState, "native_workspace_selection_report_changed")
                }
                if !bound.isEmpty {
                    guard try project().hasRenderedReaderEvidence(sceneID: sceneID, includingContainingSection: true) else {
                        throw UIRouteError(.staleState, "native_workspace_selection_reader_not_rendered")
                    }
                }
                try bound.validate()
                recordNativeObservation(evidence)
                guard workspaceSelectionBinding === bound else {
                    throw UIRouteError(.staleState, "native_workspace_selection_report_owner_changed")
                }
                try bound.validate()
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        if evidence.isVisible, evidence.surface.destination == MaktabahNativeReaderTabBinding.destination {
            do {
                guard let bound = readerTabBinding, bound.isApplied,
                      evidence.submissionID == bound.requestID, submissionID == bound.requestID,
                      command?.invocation.requestId == bound.requestID,
                      isPresentationReady(for: evidence.surface.destination),
                      let current = try surface(.reader), current == evidence.surface,
                      try project().hasRenderedReaderEvidence(sceneID: sceneID, includingContainingSection: true) else {
                    throw UIRouteError(.staleState, "native_reader_tab_report_changed")
                }
                try bound.validate()
                recordNativeObservation(evidence)
                guard readerTabBinding === bound else { throw UIRouteError(.staleState, "native_reader_tab_report_owner_changed") }
                try bound.validate()
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        if evidence.isVisible, MaktabahNativeSefariaSurfaceBinding.accepts(evidence.surface.destination),
           let requestID = evidence.submissionID {
            do {
                guard let original = sefariaSurfaceBinding, submissionID == requestID,
                      command?.invocation.requestId == requestID else {
                    throw UIRouteError(.staleState, "native_sefaria_report_not_owned")
                }
                try original.withValidatedSurface(requestID: requestID) {
                    try validateParentSource(destination: evidence.surface.destination, requestID: requestID)
                    guard isSefariaOriginalRootReady, let current = try surface(.sefariaEmbedded),
                          current == evidence.surface else {
                        throw UIRouteError(.staleState, "native_sefaria_report_changed")
                    }
                    recordNativeObservation(evidence)
                }
            } catch {
                if visible.removeValue(forKey: evidence.surface.destination) != nil { try? nativeStateChanged() }
                presentation.revoke()
            }
            return
        }
        recordNativeObservation(evidence)
    }

    private func recordNativeObservation(_ evidence: NativeSurfaceWitness.Evidence) {
        #if DEBUG
        if evidence.submissionID != nil {
            let matches = command.map { evidence.surface.observedRoute(for: $0, backend: $0.invocation.snapshot) == $0.route.route } ?? false
            OtzariaFileLogger.shared.log("[NativeSurfaceObservation] destination=\(evidence.surface.destination.rawValue) visible=\(evidence.isVisible) matches=\(matches)")
        }
        #endif
        let prior = visible[evidence.surface.destination]
        if evidence.isVisible { visible[evidence.surface.destination] = evidence }
        else { visible.removeValue(forKey: evidence.surface.destination) }
        if prior != visible[evidence.surface.destination] { try? nativeStateChanged() }
        guard evidence.isVisible, let requestID = evidence.submissionID else { return }
        presentation.report(.init(sceneID: evidence.sceneID, submissionID: requestID, surface: evidence.surface))
    }

    func endObservation(requestID: UUID) {
        guard submissionID == requestID else { return }
        if let command, let observed = visible[command.route.route.destination],
           observed.isVisible, observed.submissionID == requestID,
           observed.surface.observedRoute(for: command, backend: command.invocation.snapshot) == command.route.route {
            lastCompletedSurface = (command.route.route, observed)
        }
        let completed = lastCompletedSurface?.route.requestId == requestID
        finishTOCQueryCommonSource(requestID: requestID, completed: completed)
        retainedComponentOwner?.finish(requestID: requestID, completed: completed)
        workspacePresentation?.finish(requestID: requestID, completed: completed)
        phoneTOCPresentation?.finish(requestID: requestID, completed: completed)
        searchEntryBinding?.finish(requestID: requestID, completed: completed)
        historyRecordBinding?.finish(requestID: requestID, completed: completed && retainedHistoryRecord)
        savedResultsBinding?.finish(requestID: requestID, completed: completed && retainedSavedResults)
        annotationSelectionBinding?.finish(requestID: requestID, completed: completed && retainedAnnotationSelection)
        annotationEditorControls?.finish(requestID: requestID, completed: completed && retainedAnnotationEditor)
        annotationEditorOpening?.finish(requestID: requestID, completed: completed && retainedAnnotationEditorOpening)
        if retainedSefariaSurface, completed, let root = sefariaRootSources[requestID],
           (try? root.validate(bindings, workspace: workspacePresentation)) != nil {
            completedSefariaRootSource = root
        }
        sefariaSurfaceBinding?.finish(requestID: requestID, completed: completedSefariaRootSource != nil)
        retainedComponentOwner = nil; retainedWorkspaceParent = nil; retainedPhoneTOC = false
        retainedSefariaSurface = false
        retainedHistoryRecord = false
        retainedSavedResults = false
        retainedAnnotationSelection = false
        retainedAnnotationEditor = false
        retainedAnnotationEditorOpening = false
        presentation.end(requestID: requestID); submissionID = nil
        // Keep only the independently observed surface. Clear private request
        // metadata after its owner has validated the complete visible receipt.
        command = nil; retainedSearchField = nil; inspectorBinding = nil
        readerTabParentObservation = nil
        workspaceSelectionParentObservation = nil
    }

    func validateCompletedJourneySurface(_ receipt: UISceneReceipt) throws {
        let projection = try project()
        guard mounted, foreground, isPresentationReady(for: receipt.route.destination), receipt.sceneID == sceneID,
              let completed = lastCompletedSurface, completed.route == receipt.route,
              completed.evidence.submissionID == receipt.requestId,
              let visible = visibilityChecks[receipt.route.destination]?(),
              visible.isVisible, visible.sceneID == sceneID,
              let kind = surfaceKind(receipt.route.destination), let actual = try surface(kind),
              actual == visible.surface, actual == completed.evidence.surface,
              kind != .reader || projection.hasRenderedReaderEvidence(sceneID: sceneID,
                includingContainingSection: receipt.route.destination == MaktabahNativeReaderTabBinding.destination
                    || receipt.route.destination == MaktabahNativeWorkspaceSelectionBinding.destination) else {
            throw ActionPortError.staleState
        }
    }

    func originalSefariaSurfaceAcceptanceEvidence(for receipt: UISceneReceipt) throws -> SefariaEmbeddedSurfaceAcceptanceEvidence {
        guard receipt.route.destination == MaktabahNativeSefariaSurfaceBinding.destination,
              let original = sefariaSurfaceBinding, let source = completedSefariaRootSource else {
            throw UIRouteError(.staleState, "native_sefaria_completed_source_missing")
        }
        try source.validate(bindings, workspace: workspacePresentation)
        try validateCompletedJourneySurface(receipt)
        let evidence = try original.acceptanceEvidence(for: receipt)
        try source.validate(bindings, workspace: workspacePresentation)
        return evidence
    }

    func unmount() {
        guard mounted else { return }
        unmountTOCQueryCommonSource()
        annotationEditorOpening?.originalSessionWillUnmount()
        advanceOriginalAnnotationPresentationPublication()
        advanceOriginalSearchPresentationPublication()
        lastCompletedSurface = nil
        searchContinuationOwner?.retire(); searchContinuationOwner = nil
        publicSearchContinuationCatalog?.unmount(); publicSearchContinuationCatalog = nil
        readerTabBinding?.release(); readerTabBinding = nil; readerTabParentObservation = nil
        viewerParentHost?.unmount(); viewerParentHost = nil
        workspaceSelectionBinding?.release(); workspaceSelectionBinding = nil; workspaceSelectionParentObservation = nil
        forwardingWorkspaceOwner?.detachNativeRoutingSession(self); forwardingWorkspaceOwner = nil
        workspacePresentation?.retire(); workspacePresentation = nil; retainedWorkspaceParent = nil
        phoneTOCPresentation?.unmount(); phoneTOCPresentation = nil; retainedPhoneTOC = false
        searchEntryBinding?.unmount(); searchEntryBinding = nil
        historyRecordBinding?.unmount(); historyRecordBinding = nil; retainedHistoryRecord = false
        savedResultsBinding?.unmount(); savedResultsBinding = nil; retainedSavedResults = false
        annotationSelectionBinding?.unmount(); annotationSelectionBinding = nil; retainedAnnotationSelection = false
        annotationEditorControls?.unmount(); annotationEditorControls = nil; retainedAnnotationEditor = false
        annotationEditorOpening?.unmount(); annotationEditorOpening = nil; retainedAnnotationEditorOpening = false
        sefariaRootSources.values.forEach { $0.invalidate() }; sefariaRootSources.removeAll()
        completedSefariaRootSource?.invalidate(); completedSefariaRootSource = nil
        sefariaSurfaceBinding?.unmount(); sefariaSurfaceBinding = nil; retainedSefariaSurface = false
        mounted = false; presentation.revoke(); submissionID = nil; command = nil; visible.removeAll(); visibilityChecks.removeAll()
        nativeSearchField = nil; retainedSearchField = nil; inspectorBinding = nil
        for owner in componentOwners.values { owner.retirePresentation() }
        componentOwners.removeAll(); retainedComponentOwner = nil; componentValidation = nil
        noteEditorOwner = nil; noteDraftBinding = nil
        windowSource = nil; searchPresentationOwner = nil; searchPresentationBlocked = nil
        annotationPresentationOwner = nil; annotationPresentationBlocked = nil
        searchResultsBinding = nil
        if let lease { directory.unmount(lease) }
        lease = nil
    }

    private func surfaceKind(_ destination: UIDestinationID) -> MaktabahNativeSceneProjection.Surface? {
        switch destination.rawValue {
        case "native.library": .library
        case "native.reader.toc": .tableOfContents
        case "native.reader", "native.reader.tab": .reader
        case "native.workspace.selection": workspaceSelectionBinding?.observedSurface
        case "native.reader.inspector": .inspector
        case "native.reader.noteDraft": .noteDraft
        case "native.history": .history
        case "native.search": .search
        case "native.search.results": .searchResults
        case "native.annotations", "native.annotations.record": .annotations
        case "native.annotations.editor", "native.annotations.editor.record": .annotationEditor
        case "native.settings": .settings
        case "native.workspace.profiles": .workspaceProfiles
        case "native.workspace.overview": .workspaceOverview
        case "native.sefariaEmbedded", "native.sefariaEmbedded.library", "native.sefariaEmbedded.topics",
             "native.sefariaEmbedded.learningSchedules", "native.sefariaEmbedded.dedication": .sefariaEmbedded
        case "native.savedResults": .savedResults
        default: nil
        }
    }
}

/// Geometry and responder ownership belong to UIKit, independently of route
/// metadata. Only the control explicitly supplied by its own representable is
/// inspected; walking its actual ancestors does not discover arbitrary views.
@MainActor private enum NativeSearchFieldVisibility {
    static let destination = UIDestinationID(rawValue: "native.search")!
    static let focus = FocusSpec(kind: .component, anchor: UIDestinationID(rawValue: "native.search.query")!)

    static func isVisible(_ field: UISearchTextField, in expectedScene: UIStableID) -> Bool {
        guard field.isEnabled, field.canBecomeFirstResponder,
              let window = field.window, window.isKeyWindow, !window.isHidden,
              let scene = window.windowScene, scene.activationState == .foregroundActive,
              scene.session.persistentIdentifier == expectedScene.rawValue else { return false }
        let target = field.convert(field.bounds, to: window)
        let intersection = target.intersection(window.bounds), area = target.width * target.height
        guard !target.isEmpty, area.isFinite, area > 0, !intersection.isNull,
              intersection.width * intersection.height >= area * 0.98 else { return false }
        var current: UIView? = field
        var alpha: CGFloat = 1
        while let view = current {
            guard !view.isHidden else { return false }
            alpha *= view.alpha; current = view.superview
        }
        guard alpha >= 0.95 else { return false }
        var top = window.rootViewController
        while let presented = top?.presentedViewController { top = presented }
        if let top, top !== window.rootViewController, !field.isDescendant(of: top.view) { return false }
        return true
    }
}
#endif
