# TOC query common source — isolated source proposal

This directory is an uncompiled proposal against exact Root87ccd4625115eb43c650180174825b288ba2e592. It is not a live integration checkout. No compiler, cache, native UI, SDK, product Git or Data-volume write is part of this scope.

## Source basis and actual finding

The original iOSReaderWorkspaceView877129c0 unconditionally attaches its passive NoteEditor owner from original onAppear / initial session observation, including when editingAnnotation is nil. The existing Phone TOC original presentation can cause that cold Reader mount. A strict captured nil-owner/unchanged-revision rule therefore needs a finite allowance for that exact original event.

The full current Session66b97176 and actual NativeSceneDirectory61028bdb are copied from immutable87c Git blobs. The actual original attachNoteEditor514-byte method is preserved. Its same-id/same-Reader early return, revision advance, optional original revoke, owner assignment and nativeStateChanged order remain unchanged. The two inserted begin/defer lines are passive metadata only. Every ordinary attach continues even if the metadata refuses.

## Defined proposal

The common source captures the same Session, scene, actual Lease, request, query binding and original modal histories before external getters. Its ignored Notes, Search, Annotations and Workspace metadata is compared after every callback-bearing proof. Actual window, old Search/Annotation validators and original phone component source are retained once. Query RootSource and original phone still own their exact root/mode/book transitions.

The actual immutable command is bound once, immediately before canonical query.apply. Its existing absolute invocation deadline is checked; no new deadline, Core grant or effect authorization is created.

Only the canonical phone wrapper may arm one nil-to-same-Reader idle attachment when the original parent was not mounted at capture. The actual hook consumes the permit before incoming Binding.get. A token spans the complete original attachment and blocks capture during an intermediate owner publication. Nested tokens cannot clear each other. Postconditions require the same actual new owner/id/Reader, nil annotation, inactive editor/TextView, exact one original counter increment and unchanged retained foreign source. Ordinary idempotent no-write attachments retain their original early return.

Finish closes registration eligibility before original owner finish callbacks. The same read-only completed source may remain through generic completion validation. Release preserves only a weak completed association; next capture and unmount invalidate it. The unmount flag closes capture before original unmount callbacks while mounted is still true.

## External integration prerequisites — not supplied or assumed

1. UI's exact MaktabahNativeTOCQueryFocusBinding implementation and original view hooks are external. UI confirmed the type, readonly sceneID and owner; no exported retained-reader accessor exists. Verified finite literals are native.reader.toc and native.reader.toc.query. The command's actual focus shape is observed in the original Session beginObservation.
2. Root must construct and store that same query object and supply captureCommonSource. Root must set tocQueryCaptureRequestID only around its finite query retainSource call, reject a nested occupied capture slot and clear only its own slot. These surrounding wrappers have not been observed here and are not reconstructed.
3. Root must call bindTOCQueryCommonCommand with the actual current UISceneCommand immediately before both canonical query.apply branches. Phone invokes the proposed original-parent wrapper around the unchanged phone.apply. The wrapper is not an independent public effect entry.
4. The separate warm pre-effect parent-readiness issue belongs to Root/UI. Their captured original pending-source readiness lease is external. This proposal neither calls query.isAvailable/validateSource recursively nor admits generic .applying readiness.
5. A first Notes attachment while the original phone source is still applying is refused. Permitted attachment requires its same actual request to have published original presentation. No SwiftUI timing guarantee is claimed.
6. Root must merge the two declared Root-owned slot fields and three lifecycle callsite additions with its actual finite wiring, avoiding duplicate declarations or callbacks. The old root source file itself is unchanged.
7. This is not a full application compile or source qualification. Type checking, actual parent/common interaction, runtime callback ordering and final original native field/receipt acceptance remain NOT_RUN.

## Preservation and checks

EXACT_EDITS.json describes six reversible edits. The complete inverse reproduces exact Session66b97176. Attach method preimage is514B/SHA311e4397a32a0c2f2b2c7103c0c123e7fa8267e221f5e6f98c473ffc81acd121. Prior in-memory helper draft1 and the narrow draft1→2 correction are retained separately; neither was compiled or intaken.

Textual verification checks unique old spans, complete inverse, unchanged original attachment order/body, exact source sizes/hashes and the own4MiB scope. These are artifact/provenance checks, not executable Swift source controls.

## Planned bounded controls, all NOT_RUN

Warm zero-write; one cold actual idle registration after original presentation publication; deferred same-command registration; wrong Reader; unarmed/preapply/afterfinish; nested attachment; incoming/current Binding getter release/replacement; capture between original counter and owner assignment; equal/ABA Notes publication; detach; final Search/Annotation/Workspace callback ABA; overflow; original deadline expiration; exact command/request/Lease mismatch; completed read-only source through release; unmount callback reentry. No false mock ACK is permitted.

## Resource boundary

Only this new rootfs directory, at most4MiB additional. The dispatch checks the unchanged task-specific root floor1,593,835,520B plus4,194,304B reserve before each allocation. The aggregate lane ceiling remains300MiB; no old controls, products, source repositories or caches are altered.
