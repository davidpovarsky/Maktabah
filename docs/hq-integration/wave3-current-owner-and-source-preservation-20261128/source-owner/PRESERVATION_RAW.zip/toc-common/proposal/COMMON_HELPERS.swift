    // MARK: TOC query common source (isolated, uncompiled proposal)
    //
    // The finite Root dispatch/canonical apply wiring is an external prerequisite.
    // This metadata never grants a UI effect, changes a deadline, or changes an
    // original readiness predicate. All original presentation remains with Phone
    // TOC / bindings and the exact query field owner.
    @MainActor
    private final class TOCQueryCommonSource {
        enum Phase: Equatable { case capturing, retained, bound, finished, retired }
        enum IdleRegistration: Equatable { case unavailable, eligible, claimed, joined, closed }
        let requestID: UUID
        let lease: NativeSceneDirectory.Lease
        let isPhone: Bool
        weak var query: MaktabahNativeTOCQueryFocusBinding?
        weak var manager: iOSNavigationManager?
        weak var workspace: MaktabahNativeWorkspacePresentationBinding?
        let hadWorkspace: Bool
        let workspaceRevision: UInt64?
        weak var annotationList: MaktabahNativeAnnotationSelectionBinding?
        let hadAnnotationList: Bool
        let annotationOwner: UUID?
        let annotationRevision: UInt64
        let searchOwner: UUID?
        let searchRevision: UInt64
        weak var notesOwner: MaktabahNativeNoteEditorOwner?
        var hadNotesOwner: Bool
        var notesRevision: UInt64
        let initiallyHadNotesOwner: Bool
        weak var phone: MaktabahNativePhoneTOCPresentationBinding?
        weak var reader: ReaderViewModel?
        var phoneWasMounted = false
        var window: MaktabahNativeWindowObservation?
        var search: (@MainActor () throws -> Void)?
        var annotations: (@MainActor () throws -> Void)?
        var phoneSource: (@MainActor () throws -> Void)?
        var foreignObservation: MaktabahNativeComponentSourceObservation?
        var phase: Phase = .capturing
        var idleRegistration: IdleRegistration = .unavailable
        var command: UISceneCommand?
        var validating = false
        var parentStarted = false
        weak var attachment: TOCQueryNoteRegistration?

        init(requestID: UUID, lease: NativeSceneDirectory.Lease, isPhone: Bool,
             query: MaktabahNativeTOCQueryFocusBinding, manager: iOSNavigationManager,
             workspace: MaktabahNativeWorkspacePresentationBinding?, workspaceRevision: UInt64?,
             annotationList: MaktabahNativeAnnotationSelectionBinding?,
             annotationOwner: UUID?, annotationRevision: UInt64,
             searchOwner: UUID?, searchRevision: UInt64,
             notesOwner: MaktabahNativeNoteEditorOwner?, notesRevision: UInt64) {
            self.requestID = requestID; self.lease = lease; self.isPhone = isPhone
            self.query = query; self.manager = manager
            self.workspace = workspace; hadWorkspace = workspace != nil
            self.workspaceRevision = workspaceRevision
            self.annotationList = annotationList; hadAnnotationList = annotationList != nil
            self.annotationOwner = annotationOwner; self.annotationRevision = annotationRevision
            self.searchOwner = searchOwner; self.searchRevision = searchRevision
            self.notesOwner = notesOwner; hadNotesOwner = notesOwner != nil
            initiallyHadNotesOwner = notesOwner != nil; self.notesRevision = notesRevision
        }
        func retire() {
            phase = .retired; idleRegistration = .closed; attachment = nil
        }
    }

    /// One token for one actual non-idempotent original attach call. The Set in
    /// Session contains identities only; the original function's defer owns the
    /// token lifetime. A nested call cannot finish an outer call's transition.
    @MainActor
    private final class TOCQueryNoteRegistration {
        let id: UUID
        weak var reader: ReaderViewModel?
        var source: TOCQueryCommonSource?
        var nextRevision: UInt64?
        init(id: UUID, reader: ReaderViewModel) { self.id = id; self.reader = reader }
    }

    private static func sameTOCQueryObject<T: AnyObject>(_ current: T?, _ original: T?,
                                                        wasPresent: Bool) -> Bool {
        if wasPresent { return original != nil && current === original }
        return current == nil && original == nil
    }

    /// Pure metadata only: no original blockers, query validator, Reader getter,
    /// window getter, observation registration, or user callback.
    private func requireTOCQueryCommonMetadata(_ source: TOCQueryCommonSource,
        notesOwner: MaktabahNativeNoteEditorOwner?, hadNotesOwner: Bool,
        notesRevision: UInt64, attachment: TOCQueryNoteRegistration? = nil) throws {
        guard mounted, !tocQueryCommonUnmounting, source.phase != .retired,
              tocQueryCommonSource === source || completedTOCQueryCommonSource === source,
              lease == source.lease, source.lease.sceneID == sceneID,
              let query = source.query, tocQueryFocusBinding === query, query.sceneID == sceneID,
              let manager = source.manager, bindings.manager === manager,
              Self.sameTOCQueryObject(workspacePresentation, source.workspace, wasPresent: source.hadWorkspace),
              workspacePresentation?.originalStateRevision == source.workspaceRevision,
              Self.sameTOCQueryObject(annotationSelectionBinding, source.annotationList,
                                     wasPresent: source.hadAnnotationList),
              annotationPresentationOwner == source.annotationOwner,
              annotationPresentationPublicationRevision == source.annotationRevision,
              searchPresentationOwner == source.searchOwner,
              searchPresentationPublicationRevision == source.searchRevision,
              Self.sameTOCQueryObject(noteEditorOwner, notesOwner, wasPresent: hadNotesOwner),
              readerToolEditorPublicationRevision == notesRevision,
              noteDraftBinding == nil else {
            throw UIRouteError(.staleState, "native_toc_query_common_source_changed")
        }
        if let attachment {
            guard tocQueryNoteAttachmentTransitions.count == 1,
                  tocQueryNoteAttachmentTransitions.contains(ObjectIdentifier(attachment)),
                  attachment.source === source, source.attachment === attachment,
                  source.idleRegistration == .claimed, source.phase == .bound else {
                throw UIRouteError(.staleState, "native_toc_query_note_registration_changed")
            }
        } else {
            guard tocQueryNoteAttachmentTransitions.isEmpty,
                  source.idleRegistration != .claimed else {
                throw UIRouteError(.staleState, "native_toc_query_note_registration_in_progress")
            }
        }
        if source.isPhone {
            guard let phone = source.phone, phoneTOCPresentation === phone,
                  source.phase == .capturing || source.reader != nil else {
                throw UIRouteError(.staleState, "native_toc_query_phone_owner_changed")
            }
        }
        if let bound = source.command {
            guard bound.invocation.requestId == source.requestID,
                  bound.route.route.requestId == source.requestID,
                  bound.scene.sceneID == sceneID,
                  SystemActionClock().now() < bound.invocation.deadlineUptimeNanoseconds else {
                throw UIRouteError(.cancelled, "native_toc_query_common_deadline_or_request_changed")
            }
            if source.phase == .finished {
                guard (command == nil || command == bound),
                      (submissionID == nil || submissionID == source.requestID) else {
                    throw UIRouteError(.staleState, "native_toc_query_completed_command_replaced")
                }
            } else {
                guard command == bound, submissionID == source.requestID else {
                    throw UIRouteError(.staleState, "native_toc_query_bound_command_changed")
                }
            }
        } else if let current = command {
            // beginObservation assigns its command after all original begin
            // callbacks. The actual immutable command is bound only by the
            // canonical apply hook; this read grants no registration permission.
            guard source.phase == .retained,
                  current.invocation.requestId == source.requestID,
                  current.route.route.requestId == source.requestID,
                  current.scene.sceneID == sceneID,
                  submissionID == source.requestID,
                  current.route.route.destination.rawValue == "native.reader.toc",
                  current.route.route.focus?.kind == .component,
                  current.route.route.focus?.anchor?.rawValue == "native.reader.toc.query",
                  current.route.route.focus?.locator == nil,
                  current.route.route.focus?.range == nil,
                  SystemActionClock().now() < current.invocation.deadlineUptimeNanoseconds else {
                throw UIRouteError(.staleState, "native_toc_query_unbound_command_changed")
            }
        } else {
            guard source.phase == .capturing || source.phase == .retained,
                  submissionID == nil else {
                throw UIRouteError(.staleState, "native_toc_query_common_command_missing")
            }
        }
    }

    /// Brackets every callback-bearing original proof with the same complete
    /// metadata join. The last operation is the pure join, never another blocker.
    private func validateTOCQueryCommonSource(_ source: TOCQueryCommonSource,
        notesOwner: MaktabahNativeNoteEditorOwner? = nil, notesOverride: Bool = false,
        notesRevision: UInt64? = nil, attachment: TOCQueryNoteRegistration? = nil) throws {
        guard !source.validating, source.phase != .capturing, source.phase != .retired else {
            source.retire()
            throw UIRouteError(.staleState, "native_toc_query_common_validation_reentered")
        }
        source.validating = true
        defer { source.validating = false }
        let owner = notesOverride ? notesOwner : source.notesOwner
        let hadOwner = notesOverride ? notesOwner != nil : source.hadNotesOwner
        let revision = notesRevision ?? source.notesRevision
        func same() throws {
            try requireTOCQueryCommonMetadata(source, notesOwner: owner,
                hadNotesOwner: hadOwner, notesRevision: revision, attachment: attachment)
        }
        do {
            try Task.checkCancellation()
            try same()
            guard let window = source.window, let search = source.search,
                  let annotations = source.annotations, let observation = source.foreignObservation else {
                throw UIRouteError(.staleState, "native_toc_query_common_capture_incomplete")
            }
            _ = try window.validate(); try same()
            try search(); try same()
            try annotations(); try same()
            try observation.validate(); try same()
            if let phoneSource = source.phoneSource { try phoneSource(); try same() }
            guard let manager = source.manager else {
                throw UIRouteError(.staleState, "native_toc_query_common_manager_released")
            }
            guard let reader = source.reader, manager.activeReaderViewModel === reader else {
                throw UIRouteError(.staleState, "native_toc_query_original_reader_changed")
            }
            try same()
            guard studyChatPresentationID == nil, !hasOriginalWorkspacePresentation else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_workspace_presented")
            }
            try same()
            guard !hasOriginalSefariaSurface else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_sefaria_presented")
            }
            try same()
            guard savedResultsBinding?.isRequestedOrMounted != true else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_saved_results_presented")
            }
            try same()
            guard manager.selectedBookForInfo == nil, !manager.showingTabsList,
                  manager.alertMessage == nil, !DonationManager.shared.showDonationSheet,
                  source.reader?.isPopoverPresented != true,
                  source.reader?.readerInspectorVisible != true else {
                throw UIRouteError(.unavailable, "native_toc_query_foreign_reader_presentation")
            }
            try same()
            guard owner?.current == nil, owner?.presentationActive != true else {
                throw UIRouteError(.unavailable, "native_toc_query_original_notes_presented")
            }
            try same()
            try observation.validate(); try same()
            _ = try window.validate(); try same()
            try Task.checkCancellation()
            try same()
        } catch { source.retire(); throw error }
    }

    func retainTOCQueryCommonSource() throws -> @MainActor () throws -> Void {
        if let current = tocQueryCommonSource {
            current.retire()
            throw UIRouteError(.staleState, "native_toc_query_common_capture_reentered")
        }
        guard mounted, !tocQueryCommonUnmounting, command == nil, submissionID == nil,
              tocQueryNoteAttachmentTransitions.isEmpty,
              let requestID = tocQueryCaptureRequestID, let lease,
              let query = tocQueryFocusBinding, query.sceneID == sceneID,
              let notesRevision = readerToolEditorPublicationRevision,
              let searchRevision = searchPresentationPublicationRevision,
              let annotationRevision = annotationPresentationPublicationRevision,
              workspacePresentation == nil || workspacePresentation?.originalStateRevision != nil,
              noteDraftBinding == nil else {
            throw UIRouteError(.unavailable, "native_toc_query_common_capture_unavailable")
        }
        completedTOCQueryCommonSource?.retire(); completedTOCQueryCommonSource = nil
        // These original ignored histories are captured before any original
        // window, model, availability, Binding, or presentation getter.
        let source = TOCQueryCommonSource(requestID: requestID, lease: lease,
            isPhone: !MaktabahApp.isIpad, query: query, manager: bindings.manager,
            workspace: workspacePresentation, workspaceRevision: workspacePresentation?.originalStateRevision,
            annotationList: annotationSelectionBinding, annotationOwner: annotationPresentationOwner,
            annotationRevision: annotationRevision, searchOwner: searchPresentationOwner,
            searchRevision: searchRevision, notesOwner: noteEditorOwner, notesRevision: notesRevision)
        // Phone identity is installed before the first callback so the pure
        // capture join can require the same actual retained original parent.
        if source.isPhone { source.phone = phoneTOCPresentation }
        tocQueryCommonSource = source
        func sameCapture() throws {
            guard tocQueryCaptureRequestID == requestID, source.phase == .capturing,
                  !source.validating else {
                throw UIRouteError(.staleState, "native_toc_query_common_capture_changed")
            }
            try requireTOCQueryCommonMetadata(source, notesOwner: source.notesOwner,
                hadNotesOwner: source.hadNotesOwner, notesRevision: source.notesRevision)
        }
        do {
            try sameCapture()
            // No callback precedes these snapshots. The first retained Reader
            // getter is itself enclosed by all non-Reader metadata comparisons.
            if source.isPhone {
                guard let phone = source.phone else {
                    throw UIRouteError(.unavailable, "native_toc_query_phone_owner_missing")
                }
                source.phoneWasMounted = phone.isMounted
                source.reader = try phone.retainedReader()
                try sameCapture()
                source.phoneSource = try phone.captureComponentSource()
                try sameCapture()
            } else {
                source.reader = bindings.manager.activeReaderViewModel
                try sameCapture()
            }
            guard source.reader != nil else {
                throw UIRouteError(.unavailable, "native_toc_query_original_reader_missing")
            }
            source.window = try retainOriginalWindowObservation(); try sameCapture()
            source.search = try retainHistorySearchPresentationObservation(); try sameCapture()
            source.annotations = try retainOriginalAnnotationPresentationObservation(); try sameCapture()
            let manager = bindings.manager
            let reader = source.reader
            source.foreignObservation = MaktabahNativeComponentSourceObservation { [weak self, weak manager, weak reader] in
                guard let self, let manager else { return }
                _ = self.studyChatPresentationID
                _ = self.hasOriginalSefariaSurface
                _ = self.savedResultsBinding?.isRequestedOrMounted
                _ = manager.selectedBookForInfo; _ = manager.showingTabsList; _ = manager.alertMessage
                _ = reader?.isPopoverPresented; _ = reader?.readerInspectorVisible
                _ = DonationManager.shared.showDonationSheet
            }
            try sameCapture()
            source.phase = .retained
            try validateTOCQueryCommonSource(source)
            return { [weak self, source] in
                guard let self else {
                    source.retire()
                    throw UIRouteError(.staleState, "native_toc_query_common_session_released")
                }
                try self.validateTOCQueryCommonSource(source)
            }
        } catch {
            source.retire()
            if tocQueryCommonSource === source { tocQueryCommonSource = nil }
            throw error
        }
    }

    func bindTOCQueryCommonCommand(_ value: UISceneCommand) throws {
        guard let source = tocQueryCommonSource else {
            throw UIRouteError(.staleState, "native_toc_query_common_source_missing")
        }
        guard source.phase == .retained, !source.validating, source.command == nil,
              command == value, submissionID == source.requestID,
              value.invocation.requestId == source.requestID,
              value.route.route.requestId == source.requestID, value.scene.sceneID == sceneID,
              value.route.route.destination.rawValue == "native.reader.toc",
              value.route.route.focus?.kind == .component,
              value.route.route.focus?.anchor?.rawValue == "native.reader.toc.query",
              value.route.route.focus?.locator == nil, value.route.route.focus?.range == nil else {
            source.retire()
            throw UIRouteError(.staleState, "native_toc_query_common_bind_rejected")
        }
        // Consume the bind before any live callback. Failed validation is final.
        source.command = value; source.phase = .bound
        try validateTOCQueryCommonSource(source)
    }

    func applyOriginalTOCQueryPhoneParent(requestID: UUID,
        originalParent: @MainActor () throws -> Void) throws {
        guard let source = tocQueryCommonSource, source.requestID == requestID,
              source.isPhone, source.phase == .bound, !source.parentStarted else {
            tocQueryCommonSource?.retire()
            throw UIRouteError(.staleState, "native_toc_query_phone_parent_not_bound")
        }
        // This flag is metadata, not another effect grant. Canonical Core apply
        // is the only permitted caller; Root supplies its unchanged phone.apply.
        source.parentStarted = true
        do {
            try validateTOCQueryCommonSource(source)
            if !source.initiallyHadNotesOwner && !source.phoneWasMounted {
                guard source.notesRevision < UInt64.max, source.hadNotesOwner == false else {
                    throw UIRouteError(.unavailable, "native_toc_query_idle_note_revision_unavailable")
                }
                source.idleRegistration = .eligible
            }
            try originalParent()
            try validateTOCQueryCommonSource(source)
            // Eligible may remain only for this actual command's deferred
            // original Reader appearance, and never after finish/release.
        } catch { source.retire(); throw error }
    }

    private func beginTOCQueryIdleNoteRegistration(id: UUID, reader: ReaderViewModel,
        annotation: Binding<Annotation?>) -> TOCQueryNoteRegistration {
        let transition = TOCQueryNoteRegistration(id: id, reader: reader)
        tocQueryNoteAttachmentTransitions.insert(ObjectIdentifier(transition))
        guard let source = tocQueryCommonSource else {
            completedTOCQueryCommonSource?.retire()
            return transition
        }
        guard tocQueryNoteAttachmentTransitions.count == 1,
              source.phase == .bound, !source.validating,
              source.idleRegistration == .eligible, source.parentStarted,
              !source.initiallyHadNotesOwner, !source.hadNotesOwner,
              !source.phoneWasMounted, source.reader === reader,
              noteEditorOwner == nil, source.notesRevision < UInt64.max else {
            source.retire()
            return transition
        }
        // Claim BEFORE incoming annotation.get or any original validator.
        source.idleRegistration = .claimed; source.attachment = transition
        transition.source = source; transition.nextRevision = source.notesRevision + 1
        do {
            try validateTOCQueryCommonSource(source, attachment: transition)
            guard let phone = source.phone,
                  phone.isContinuingOriginalReaderPresentation(requestID: source.requestID) else {
                throw UIRouteError(.staleState, "native_toc_query_idle_note_parent_not_presented")
            }
            try requireTOCQueryCommonMetadata(source, notesOwner: nil, hadNotesOwner: false,
                notesRevision: source.notesRevision, attachment: transition)
            guard annotation.wrappedValue == nil else {
                throw UIRouteError(.unavailable, "native_toc_query_incoming_note_not_idle")
            }
            try validateTOCQueryCommonSource(source, attachment: transition)
        } catch { source.retire() }
        return transition
    }

    private func endTOCQueryIdleNoteRegistration(_ transition: TOCQueryNoteRegistration) {
        defer { tocQueryNoteAttachmentTransitions.remove(ObjectIdentifier(transition)) }
        guard let source = transition.source else { return }
        guard source.phase == .bound, source.idleRegistration == .claimed,
              source.attachment === transition, !source.validating,
              let reader = transition.reader, source.reader === reader,
              let owner = noteEditorOwner, owner.id == transition.id, owner.reader === reader,
              let next = transition.nextRevision,
              readerToolEditorPublicationRevision == next else {
            source.retire()
            return
        }
        do {
            try validateTOCQueryCommonSource(source, notesOwner: owner, notesOverride: true,
                notesRevision: next, attachment: transition)
            guard let phone = source.phone,
                  phone.isContinuingOriginalReaderPresentation(requestID: source.requestID) else {
                throw UIRouteError(.staleState, "native_toc_query_idle_note_parent_changed")
            }
            try requireTOCQueryCommonMetadata(source, notesOwner: owner, hadNotesOwner: true,
                notesRevision: next, attachment: transition)
            guard owner.current == nil, !owner.presentationActive, owner.textView == nil else {
                throw UIRouteError(.staleState, "native_toc_query_registered_note_not_idle")
            }
            try requireTOCQueryCommonMetadata(source, notesOwner: owner, hadNotesOwner: true,
                notesRevision: next, attachment: transition)
            // No callback follows this exact one-use publication. The defer then
            // removes only this transition; no nested call can rearm the source.
            source.notesOwner = owner; source.hadNotesOwner = true; source.notesRevision = next
            source.idleRegistration = .joined; source.attachment = nil
        } catch { source.retire() }
    }

    func finishTOCQueryCommonSource(requestID: UUID, completed: Bool) {
        guard let source = tocQueryCommonSource, source.requestID == requestID else { return }
        // Close BEFORE any callback-bearing original owner.finish invocation.
        if source.idleRegistration == .eligible { source.idleRegistration = .closed }
        guard completed, source.phase == .bound, !source.validating,
              source.idleRegistration != .claimed, source.command != nil else {
            source.retire(); return
        }
        do {
            try requireTOCQueryCommonMetadata(source, notesOwner: source.notesOwner,
                hadNotesOwner: source.hadNotesOwner, notesRevision: source.notesRevision)
            source.phase = .finished
        } catch { source.retire() }
    }

    func releaseTOCQueryCommonSource(requestID: UUID) {
        guard let source = tocQueryCommonSource, source.requestID == requestID else { return }
        if source.idleRegistration == .eligible { source.idleRegistration = .closed }
        if source.phase == .finished, !source.validating {
            completedTOCQueryCommonSource?.retire()
            completedTOCQueryCommonSource = source
        } else { source.retire() }
        if tocQueryCommonSource === source { tocQueryCommonSource = nil }
    }

    func unmountTOCQueryCommonSource() {
        // This permanent metadata flag closes capture while the original unmount
        // body still has mounted=true and publishes its foreign callbacks.
        tocQueryCommonUnmounting = true
        tocQueryCommonSource?.retire(); tocQueryCommonSource = nil
        completedTOCQueryCommonSource?.retire(); completedTOCQueryCommonSource = nil
        // Do not clear attachment identities here: each actual attach defer
        // removes its own token, including when unmount reenters that call.
    }

