from pathlib import Path
import hashlib,json,subprocess,re
ROOT=Path(__file__).resolve().parent
REPO=Path(r'C:\Users\DAVID\Code\Maktabah-index-read-compatibility-20261120')
SOURCE='b07f229e85fe894722566ad9444de31d0ba4490f'
APP='2e6f08659b347a755aef4e4fe6c00d9592ba700d'
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
def sha(b): return hashlib.sha256(b).hexdigest()
refs=json.loads((ROOT/'SOURCE_HASH_REFERENCES.json').read_bytes())
results={}
for path,record in refs.items():
 blob=git('show',SOURCE+':'+path)
 actual=sha(blob)
 assert actual==record['sha256'],(path,actual,record['sha256'])
 results[path]={'sha256':actual,'bytes':len(blob),'gitBlob':git('rev-parse',SOURCE+':'+path).decode().strip(),'equal':True}
trees={}
for path in ['Source','Vendor','Maktabah.xcodeproj/project.pbxproj','Maktabah-iOSUITests']:
 a=git('rev-parse',SOURCE+':'+path).decode().strip(); b=git('rev-parse',APP+':'+path).decode().strip()
 assert a==b,(path,a,b)
 trees[path]={'workflow':a,'application':b,'equal':True}
policy_path='Source/Otzaria/Search/Distribution/OtzariaSearchArtifactPolicy.swift'
policy=git('show',SOURCE+':'+policy_path)
registry=re.findall(rb'private static let qualifiedContracts: Set<Contract> = (\[[^\n]+\])',policy)
assert registry==[b'[.original265ToExactOccurrencesD5]'],registry
controls={}
for path in ['Scripts/CI/typecheck-faithful-ui-tests.py','.github/workflows/sefaria-embedded-validation.yml']:
 data=git('show',SOURCE+':'+path)
 controls[path]={'bytes':len(data),'sha256':sha(data)}
report={'status':'PASS_EXACT_GIT_SOURCE_BINDING','checkout':SOURCE,'application':APP,'references':len(results),'allArtifactSourceHashesMatchGit':True,'sourceHashes':results,'trees':trees,'registry':{'path':policy_path,'sha256':sha(policy),'declaration':registry[0].decode(),'qualifiedContracts':['original265ToExactOccurrencesD5'],'runtimeQualifiedByThisSDKJob':False},'controlSources':controls,'boundary':'Immutable Git source verification only; no compiler, engine or Native runtime executed by this reviewer.'}
(ROOT/'SOURCE_BINDING_REVIEW.json').write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'status':report['status'],'references':len(results),'trees':trees,'registry':report['registry'],'reviewSHA256':sha((ROOT/'SOURCE_BINDING_REVIEW.json').read_bytes())},ensure_ascii=False))
