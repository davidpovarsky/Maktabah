import pathlib,json,subprocess,hashlib,gzip,zipfile,re,datetime,collections,shutil,sys
W=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-native98-evidence-20261120")
N=pathlib.Path(r"C:\Users\DAVID\Code\Maktabah-native98-signature-refreeze-20261120")
R=N/"build/native98-44723902453-result-20261120";T=N/"build/native98-44723902453-monitor3-20261120"
D=W/"docs/hq-integration/native98-observed-20261120";D.mkdir(parents=True,exist_ok=True)
F="60a57972acb28739ec738565083bf17fb7503028";M="87b783ac3f0257e8461762e0ea9dfa5248dd06e8";B="f63284d90e48f89229eaa3c06b5275adec741b96"
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(["git","-C",str(W),*a])
def j(p):return json.loads(p.read_text(encoding="utf-8"))
def writej(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
assert git("rev-parse","HEAD").decode().strip()==B and not git("diff","--name-only").strip()
assert all(p.startswith("docs/hq-integration/native98-observed-20261120/") for p in git("ls-files","--others","--exclude-standard").decode().splitlines())
mb=git("show",F+":docs/hq-integration/runtime27/R27_CASES.json");mf=json.loads(mb)
assert mb==(T/"EXPECTED_R27_CASES.git-lf.json").read_bytes() and mf["app_source"]==M and mf["source_test_commit"]==M
expected=mf["execution_case_ids"];assert len(expected)==98==len(set(expected))
groups={g["label"]:g for g in mf["execution_groups"]}
assert {k:len(v["case_ids"]) for k,v in groups.items()}=={"11":9,"11-search":22,"11-index":5,"11-reader":35,"11-sidebar":5,"11-window":2,"phone":20}
assert set(x for g in groups.values() for x in g["case_ids"])==set(expected) and groups["11-window"]["hid_comparison"] is True
run=j(T/"AFTER_WATCH_RUN.json");jobs=j(T/"FINAL_JOBS.json");arts=j(T/"FINAL_ARTIFACTS.json")
assert run["id"]==44723902453 and run["head_sha"]==F and run["head_branch"]=="codex/otzaria-native98-signature-reviewed-20261120" and run["run_attempt"]==1
assert run["status"]=="completed" and run["conclusion"]=="cancelled"
rj=[x for x in jobs["jobs"] if x["id"]==136246398292];assert len(rj)==1;rj=rj[0]
assert rj["head_sha"]==F and rj["conclusion"]=="cancelled"
step=[s for s in rj["steps"] if s["name"]=="Inspect real Xcode27 tools or execute reviewed native cases"];assert len(step)==1
art=[x for x in arts["artifacts"] if x["id"]==14632383919];assert len(art)==1;art=art[0]
arc=R/"runtime27-evidence-14632383919.zip";ab=arc.read_bytes()
assert len(ab)==35944918 and sha(ab)=="1dec4baa131deaa5cfdb1f2f62b3dea6a84ee7713bccf67a2e62a41f1ff72310"
assert art["digest"]=="sha256:"+sha(ab) and art["workflow_run"]["id"]==run["id"] and art["workflow_run"]["head_sha"]==F
with zipfile.ZipFile(arc) as z:
 assert len(z.infolist())==102 and z.testzip() is None
 archive_names=set(z.namelist())
build=j(R/"selected/hq-stage2/result.json")
assert build["status"]=="SIMULATOR_BUILD_FOR_REAL_UI_PASS" and build["checkout_sha"]==F and build["application_source_sha"]==M and build["actual_source_inputs_verified"]==996
trees={p:git("rev-parse",F+":"+p).decode().strip() for p in ("Source","Vendor","Maktabah-iOSUITests","Maktabah.xcodeproj")}
for p in ("Source","Vendor","Maktabah.xcodeproj"):assert build["application_trees"][p]==trees[p]
def leaves(v):
 if isinstance(v,dict):
  if v.get("nodeType")=="Test Case":yield v
  for a in v.values():yield from leaves(a)
 elif isinstance(v,list):
  for a in v:yield from leaves(a)
rows={};ge=[]
for label in ("11","11-search"):
 pre=R/"selected/artifacts/runtime27";sp=pre/f"verified-{label}.summary.json";tp=pre/f"verified-{label}.tests.json";receipt=j(pre/f"verified-{label}.json")
 s=j(sp);actual=list(leaves(j(tp)));ids=[x["nodeIdentifier"].removesuffix("()") for x in actual]
 assert receipt["summary_sha256"]==sha(json.dumps(s,sort_keys=True).encode()) and receipt["tests_sha256"]==sha(json.dumps(j(tp),sort_keys=True).encode())
 with zipfile.ZipFile(arc) as z:
  assert sp.read_bytes()==z.read(f"artifacts/runtime27/verified-{label}.summary.json") and tp.read_bytes()==z.read(f"artifacts/runtime27/verified-{label}.tests.json")
 assert len(ids)==len(set(ids)) and set(ids)==set(groups[label]["case_ids"])
 c=collections.Counter(x["result"] for x in actual)
 assert s["totalTestCount"]==len(actual) and s["passedTests"]==c["Passed"] and s["failedTests"]==c["Failed"] and s["skippedTests"]==c["Skipped"]==0
 failures={x["testIdentifierString"].removesuffix("()"):x["failureText"] for x in s.get("testFailures",[])}
 for node,case in zip(actual,ids):
  assert case not in rows
  rows[case]={"caseID":case,"group":label,"evidenceLevel":"COMPLETE_XCRESULT_LEAF","result":node["result"],"durationSeconds":node.get("durationInSeconds"),"failure":failures.get(case)}
 ge.append({"group":label,"selected":len(ids),"passed":c["Passed"],"failed":c["Failed"],"skipped":0,"summarySHA256":sha(sp.read_bytes()),"treeSHA256":sha(tp.read_bytes()),"receiptCanonicalJSONSummarySHA256":receipt["summary_sha256"],"receiptCanonicalJSONTreeSHA256":receipt["tests_sha256"],"receiptHashEncoding":"json.dumps(value,sort_keys=True).encode(utf-8), separately recomputed; raw hashes above match original ZIP bytes","startUnix":s["startTime"],"finishUnix":s["finishTime"]})
assert len(rows)==31 and collections.Counter(x["result"] for x in rows.values())=={"Passed":22,"Failed":9}
it=(R/"selected/artifacts/test-simulator-11-index.log").read_text(encoding="utf-8");events=[]
for mt in re.finditer(r"Test Case '-\[([^\s]+) ([^\]]+)\]' (started|passed|failed)(?: \(([\d.]+) seconds\))?",it):
 cls,method,state,sec=mt.groups();events.append({"caseID":cls.split(".")[-1]+"/"+method,"state":state,"durationSeconds":float(sec) if sec else None,"line":it.count("\n",0,mt.start())+1})
corrupt="SearchDataNativeAcceptanceTests/testCorruptIndexShowsRepairRequiredAndOriginalRepairSurvivesColdLaunch"
healthy="SearchDataNativeAcceptanceTests/testHealthySearchDataAndColdLaunchMatchInstalledDocumentCount"
assert set(e["caseID"] for e in events)=={corrupt,healthy},events
assert [e["state"] for e in events if e["caseID"]==corrupt]==["started","failed"],events
assert [e["state"] for e in events if e["caseID"]==healthy]==["started"],events
assert [e for e in events if e["state"]=="failed"][0]["durationSeconds"]==203.536
assert not any("verified-11-index.summary.json" in n or "verified-11-index.tests.json" in n for n in archive_names)
for case in expected:
 if case in rows:continue
 group=next(k for k,g in groups.items() if case in g["case_ids"])
 if case==corrupt:level="RAW_LOG_COMPLETED_FAILURE_NO_COMPLETE_XCRESULT";result="RAW_FAILED"
 elif case==healthy:level="RAW_LOG_STARTED_NO_COMPLETION";result="UNKNOWN_AFTER_START"
 else:level="NO_START_OBSERVED_IN_RETAINED_ARTIFACTS";result="NOT_OBSERVED_STARTED"
 rows[case]={"caseID":case,"group":group,"evidenceLevel":level,"result":result}
assert len(rows)==98 and sum(v["result"]=="NOT_OBSERVED_STARTED" for v in rows.values())==65
cr=[]
for name in ("captures-central","captures-manifests","captures-selected","captures-profile-interaction"):
 base=R/name;rp=base/"RANGE_EVIDENCE.json";rr=j(rp)
 assert rr["artifactID"]==14632274701 and rr["archiveBytes"]==775094118 and rr["fullArchiveHashVerified"] is False
 for e in rr["ranges"]:
  b=(base/e["file"]).read_bytes();assert len(b)==e["bytes"] and sha(b)==e["sha256"]
 cr.append({"directory":name,"artifactID":rr["artifactID"],"archiveBytes":rr["archiveBytes"],"fullArchiveSHA256Verified":False,"networkBytes":rr["transferredBytes"],"selectedCount":len(rr.get("selected",[])),"receiptSHA256":sha(rp.read_bytes())})
ev={"schema":1,"sealedAtUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),
"run":{"id":run["id"],"url":run["html_url"],"attempt":1,"head":F,"appTestSource":M,"branch":run["head_branch"],"status":run["status"],"conclusion":run["conclusion"],"createdAt":run["created_at"],"updatedAt":run["updated_at"],"runtimeJobID":rj["id"],"runtimeJobStartedAt":rj["started_at"],"runtimeJobCompletedAt":rj["completed_at"],"runtimeStep":step[0],"cancellationActor":"UNKNOWN","cancellationCause":"NOT_ESTABLISHED","watcherObservation":j(T/"WATCH_RESULT.json")},
"build":{"status":build["status"],"xcode":build["xcode"],"swift":build["swift"],"sdkVersion":build["sdk_version"],"actualSourceInputsVerified":996,"applicationTrees":trees,"buildStageRuntimeNOT_RUN":"Stage-local record only; later UI leaves evaluated separately"},
"selection":{"manifestSHA256":sha(mb),"required":98,"requiredIPad":78,"requiredIPhone":20,"groups":{k:{"count":len(v["case_ids"]),"hid":v["hid_comparison"]} for k,v in groups.items()},"allOriginalOraclesUnchanged":True},
"verified":{"leaves":31,"passed":22,"failed":9,"skipped":0,"IPad":31,"IPhone":0,"groups":ge},
"unverified":{"count":67,"rawCompletedFailures":1,"rawStartedUnknown":1,"noStartObserved":65,"rawIndexEvents":events,"absenceLimit":"No complete INDEX result export in retained small artifact; no PASS inferred from incomplete xcresult data or missing files."},
"fullAcceptance":"NOT_ACCEPTED","HID":"NOT_OBSERVED_STARTED","physicalDevice":"NOT_RUN","newerSourceAcceptance":"NOT_TRANSFERRED",
"smallArtifact":{"id":art["id"],"bytes":len(ab),"sha256":sha(ab),"members":102,"allCRCVerified":True},
"captureArtifact":{"id":14632274701,"bytes":775094118,"advertisedSHA256":"7ce28dc10dbdfb6a52fe15e0eb0ec4bfaef746f8165974d060367cf61594a69d","fullArchiveSHA256Verified":False,"selectedOnly":True,"collections":cr},
"cases":[rows[x] for x in expected]}
writej(D/"EVALUATION.json",ev)
mapping=[
("HanlinReaderConsumerAcceptanceTests/testOriginalReaderChatReturnsToSameNativeWorkspace","128-character identifier restriction; exact full label is151 characters","8d42b1c8a03b8344ed70f0cd3e46a7ec1d01c1b9","Exact label NSPredicate repair; Native pending"),
("HanlinReaderConsumerAcceptanceTests/testOriginalIPadCurrentWorkReadConsentReopensAndRevokesWithoutSending","Actual AX shows original consent Section ID on children","b371edc6a8709c727c43401fffcc4ad00b06de70","Identifier moved only to unchanged original header; Native pending"),
("NativeRoutingAcceptanceTests/testCoreNoteDraftUsesOriginalUnsavedEditorAndCancelOnPad","Real editor/proposal exist; cancelled/deadline_exceeded; note marker unregistered",None,"B owns original witness diagnosis; no new acceptance"),
("NativeRoutingAcceptanceTests/testCoreSearchOpenResultsUsesOriginalCompletedEngineOnPad","Unavailable/backend_unavailable; original submission revision zero",None,"B owns explicit-execution cold readiness; initial UI status does not prove missing database"),
("NativeRoutingAcceptanceTests/testCoreCommentaryOpensVerifiedSourceLinkAndPreservesBaseOnPad","Public Reader setup fails TextKit/locator before Core commentary invocation",None,"B owns diagnosis; no commentary success claimed"),
("StudyProfileNativeAcceptanceTests/testProfileColorSaveCancelAndColdRelaunchPreserveWorkspace","Synthesized tap centers whole Picker row, outside visible current-value text",None,"Narrow interaction repair authorized after seal; Native pending"),
("StudyGroupStressNativeAcceptanceTests/testOneHundredConsecutiveOriginalGroupSwitchesPreserveDocumentsAndColdRestore","Actual600-second allowance exceeded before100 completion",None,"Root owns diagnosis; newer process metrics do not establish100 or performance PASS"),
("GlobalSearchNativeAcceptanceTests/testHeaderAndHistoryNativeAccessibilityAudit","Dynamic Type UILabel issue; attached element unavailable",None,"Unlocalized; full audit retained"),
("R27NativePadTests/testNormalBootstrapGlobalHistoryUsesActualSubmit","Owned preferences unreadable before/after Return; settlement+persistence wait fails",None,"History diagnosis ongoing; no synchronize, seed, query or timeout change"),
(corrupt,"All9 hashes retained; only secondary engine metadata changes after explicit reinstall",None,"Root investigates original-created timestamp; raw bytes absent; derived hash-matching bytes are not raw captures")]
writej(D/"FAILURE_TRIAGE.json",{"comparisonSource":B,"scope":"Source findings and assigned remediation; no newer-source Native acceptance","failures":[{"caseID":c,"observed":o,"sourceFix":s,"remaining":r} for c,o,s,r in mapping]})
payloads=[]
def preserve_bytes(name,data,origin):
 p=D/"raw"/(name+".gz");p.parent.mkdir(parents=True,exist_ok=True);gb=gzip.compress(data,compresslevel=6,mtime=0);p.write_bytes(gb)
 assert gzip.decompress(gb)==data
 payloads.append({"path":p.relative_to(D).as_posix(),"origin":origin,"bytes":len(data),"sha256":sha(data),"gzipBytes":len(gb),"gzipSHA256":sha(gb)})
def preserve(p,name):preserve_bytes(name,p.read_bytes(),str(p))
preserve(arc,"runtime27-evidence-14632383919.zip")
for p in sorted(T.rglob("*")):
 if p.is_file():preserve(p,"monitor3/"+p.relative_to(T).as_posix())
for name in ("ARTIFACT_VERIFIED.json","ZIP_MEMBERS.json","RAW_CASE_TIMELINES.json","SELECTED_CAPTURE_REQUEST.json","ARTIFACTS_134720.json"):preserve(R/name,name)
for label in ("11","11-search"):
 for suf in ("json","summary.json","tests.json"):
  p=R/"selected/artifacts/runtime27"/f"verified-{label}.{suf}";preserve(p,"selected/"+p.relative_to(R/"selected").as_posix())
for rel in ("artifacts/test-simulator-11.log","artifacts/test-simulator-11-search.log","artifacts/test-simulator-11-index.log","artifacts/test-case-execution-11.json","artifacts/test-case-execution-11-search.json","artifacts/faithful-ipad-matrix.json","artifacts/native-routing-logs-11/otzaria-reader.log","artifacts/runtime27/native-matrix-driver.log","hq-stage2/result.json"):
 p=R/"selected"/rel;assert p.is_file(),p;preserve(p,"selected/"+rel)
for name in ("captures-central","captures-manifests","captures-selected","captures-profile-interaction"):
 for p in sorted((R/name).rglob("*")):
  if p.is_file():preserve(p,name+"/"+p.relative_to(R/name).as_posix())
for p in ("docs/hq-integration/runtime27/R27_CASES.json",):
 preserve_bytes("source/F/"+p,git("show",F+":"+p),"git:"+F+":"+p)
p="Maktabah-iOSUITests/FaithfulReaderUIAcceptanceTests.swift";preserve_bytes("source/M/FaithfulReaderUIAcceptanceTests.swift",git("show",M+":"+p),"git:"+M+":"+p)
preserve_bytes("source/seal.py",pathlib.Path(__file__).read_bytes(),"executed evidence-only sealer")
preserve_bytes("sealing/attempt1-result.json",sys.argv[1].encode("utf-8"),"Failed evidence-sealer assertion; no app or test execution")
preserve_bytes("sealing/attempt1-source.py",sys.argv[2].encode("utf-8"),"First evidence-only sealer source; raw and canonical JSON hashes initially conflated")
preserve_bytes("sealing/attempt2-result.json",sys.argv[3].encode("utf-8"),"Second evidence-only sealer stopped on nonexistent optional source path; no app or test execution")
preserve_bytes("sealing/attempt2-source.py",sys.argv[4].encode("utf-8"),"Second evidence-only sealer; original run and all31 leaves validated before optional path failure")
writej(D/"ARTIFACTS.json",{"schema":1,"encoding":"Lossless gzip exact source bytes; canonical LF only for new JSON/Markdown","entries":payloads})
table="\n".join("| "+x["caseID"]+" | "+x["failure"].replace("|","\\|").replace("\n"," ")+" |" for x in rows.values() if x["result"]=="Failed")
readme=f"""# Native98 observed result — run44723902453

This is a **CANCELLED workflow with incomplete Native acceptance**, not a whole-suite PASS or a zero-test result. Checkout: {F}; app/tests: {M}; attempt1. The real Simulator build succeeded. Complete XCresult exports prove **31 unique leaves:22 PASS,9 FAIL,0 SKIP**, all on iPad. Each leaf matches the exact original98 selection. No older/newer source credit is transferred.

## Verified and incomplete scope

| Group | Required | Complete leaves | PASS | FAIL | SKIP | Remaining observation |
|---|---:|---:|---:|---:|---:|---|
|11|9|9|2|7|0|Complete group; acceptance failed|
|11-search|22|22|20|2|0|Complete group; acceptance failed|
|11-index|5|0|0|0|0|One raw completed failure; one raw start without completion; three starts not observed|
|11-reader|35|0|0|0|0|Starts not observed in retained artifacts|
|11-sidebar|5|0|0|0|0|Starts not observed|
|11-window/HID|2|0|0|0|0|Starts not observed; no HID acceptance|
|phone|20|0|0|0|0|Starts not observed; no iPhone acceptance|
|Total|98|31|22|9|0|67 lack complete XCresult leaves|

The INDEX raw failure is {corrupt} (203.536s). {healthy} started without a retained terminal result. They are not folded into the31 verified leaves. The other65 selected cases have no observed start in retained evidence; that statement is bounded by collected logs, not a fabricated execution result.

Original600s per-case budgets, queries, book counts, assertions and manifests remain unchanged. The100-switch case exceeded600s; it supplies no100-completion or performance PASS. Physical devices, full-corpus UI and newer-source Native acceptance remain unverified.

## Source and actual build

The build record reports SIMULATOR_BUILD_FOR_REAL_UI_PASS,996 actual source inputs verified, Xcode27.2 (27B52), Apple Swift6.4.2, Simulator SDK27.2. Its stage-local runtime NOT_RUN precedes later UI execution and does not erase actual leaves. EVALUATION.json binds exact Source/Vendor/UI-test/project trees. Complete package/resource provenance is retained in the full build JSON and the untouched original manifest.

## Chronology and limits

GitHub runtime job136246398292 started {rj['started_at']} and completed/cancelled {rj['completed_at']}. The runtime step records {step[0]['started_at']} through {step[0]['completed_at']} with conclusion cancelled. The sole watcher observed process finish13:41:21.564231UTC. These are separate observations.

INDEX raw output continues after the API runtime-step completion timestamp. Both observations are preserved. **Cancellation actor and causal mechanism are not established.** Elapsed time or a cancelled step does not identify a specific timeout, user action, compiler failure or app fault. This collector did not dispatch, retry or cancel the workflow.

## Nine verified failures

| Exact case | Actual exported failure |
|---|---|
{table}

FAILURE_TRIAGE.json distinguishes later source repairs from open diagnosis. At comparison source {B}, Hanlin exact-label repair8d42 and consent header-ID repairb371 are integrated but receive no Native PASS from this older run. Other follow-up remains source-specific. The passing canonical-history relaunch case does not override failing normal-bootstrap UUID submission.

## Artifact integrity

Full small artifact14632383919:35,944,918 bytes; SHA256 1dec4baa131deaa5cfdb1f2f62b3dea6a84ee7713bccf67a2e62a41f1ff72310;102 original ZIP members; all CRC verified. The original ZIP is retained losslessly.

Capture artifact14632274701:775,094,118 bytes. Its advertised digest is retained, **not claimed as a verified full-archive SHA**. Only authenticated exact206 ranges were downloaded. All range hashes, central-directory records, selected CRC-verified members, metadata and collector source are retained. Selections include Notes/Search JSON, Hanlin/Profile/History AX/screens, partial INDEX diagnostics and the ProfileColor synthesized event. No full large capture archive was downloaded.

ProfileColor event originalOffset254/17.25 is the midpoint of its508x34.5 Picker row; visible current-value text is in a separate left-side rectangle. This is event/AX geometry evidence, not a new hit-test result. INDEX metadata hashes are retained; source-derived candidate metadata bytes must not be represented as captured raw bytes.

## Sealing verification distinction

The first evidence-only sealing attempt stopped because it compared receipt canonical JSON hashes to raw pretty-printed JSON bytes. The original ZIP and extracted bytes are identical. The final sealer independently recomputes the receipt encoding (sorted-key JSON with default separators) and separately records raw byte hashes. Both failed sealer sources/results are retained. The second attempt validated the actual run and31 leaves, then stopped on an assumed optional inputs path that does not exist. The report retains the actual original manifest and complete build provenance instead. Neither attempt ran an application or acceptance test, and no tested input was changed.

## Sealed evidence

ARTIFACTS.json binds all gzip payloads by compressed/uncompressed size and SHA256. raw/source/seal.py.gz is the executed evidence-only validator. It verifies run/head/attempt, original98 selection, unique31 leaves and summary counts, full small ZIP SHA/CRC, range hashes, source trees and raw INDEX accounting. It runs no app, engine or test.

No task is closed by this report. All98 Native cases must satisfy their original criteria on the final source before full acceptance.
"""
(D/"README.md").write_text(readme,encoding="utf-8",newline="\n")
for e in payloads:
 b=(D/e["path"]).read_bytes();raw=gzip.decompress(b)
 assert len(b)==e["gzipBytes"] and sha(b)==e["gzipSHA256"] and len(raw)==e["bytes"] and sha(raw)==e["sha256"]
print(json.dumps({"status":"SEALED","directory":str(D),"base":B,"verified":{"passed":22,"failed":9,"skipped":0},"unverified":{"rawFailure":1,"rawStartedUnknown":1,"noObservedStart":65},"gzipFiles":len(payloads),"gzipBytes":sum(x["gzipBytes"] for x in payloads),"indexSHA256":sha((D/"ARTIFACTS.json").read_bytes()),"indexBytes":(D/"ARTIFACTS.json").stat().st_size,"freeBytes":shutil.disk_usage(W).free}))
