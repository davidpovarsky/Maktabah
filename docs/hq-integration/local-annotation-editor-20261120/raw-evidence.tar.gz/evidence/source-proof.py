from pathlib import Path
import datetime
import difflib
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "base"
CANDIDATE = ROOT / "candidate"


def sha(value): return hashlib.sha256(value).hexdigest()
def blob(value): return hashlib.sha1(b"blob " + str(len(value)).encode() + b"\0" + value).hexdigest()


inputs = json.loads((ROOT / "BASE_INPUTS.json").read_bytes())
originals = []
modified = {
    "Source/Features/Annotations/Database/AnnotationRepository.swift",
    "Source/ChavrusaText/Annotations/Exchange/AnnotationExchangeLedger.swift",
    "Maktabah.xcodeproj/project.pbxproj",
}
for row in inputs["files"]:
    data = (BASE / row["path"]).read_bytes()
    assert blob(data) == row["blob"] and sha(data) == row["sha256"] and len(data) == row["bytes"], row["path"]
    candidate = (CANDIDATE / row["path"]).read_bytes()
    if row["path"] not in modified: assert data == candidate, row["path"]
    originals.append({**row, "candidate_sha256": sha(candidate), "unchanged": data == candidate})

path = "Source/Features/Annotations/Database/AnnotationRepository.swift"
repository = (CANDIDATE / path).read_text()
inverse = repository
inverse = inverse.replace("        var localEditorLifetime = AnnotationLocalEditorLifetime()\n", "", 1)
setup = """        state.withLock { s in
            s.localEditorLifetime.retire()
            s.localEditorLifetime = AnnotationLocalEditorLifetime()
            s.dbURL = url
        }"""
assert inverse.count(setup) == 1
inverse = inverse.replace(setup, "        state.withLock { $0.dbURL = url }")
connect = """                    s.localEditorLifetime.retire()
                    s.localEditorLifetime = AnnotationLocalEditorLifetime()
"""
assert inverse.count(connect) == 1
inverse = inverse.replace(connect, "")
disconnect = "            s.localEditorLifetime.retire()\n"
assert inverse.count(disconnect) == 1
inverse = inverse.replace(disconnect, "")
start = inverse.index("    // Captures an existing handle only; no setup, UUID backfill, or migration.")
end = inverse.index("    // MARK: - Schema", start)
inverse = inverse[:start] + inverse[end:]
assert inverse.encode() == (BASE / path).read_bytes(), "Repository inverse changed original statements"
repository_inverse = sha(inverse.encode())

path = "Source/ChavrusaText/Annotations/Exchange/AnnotationExchangeLedger.swift"
ledger = (CANDIDATE / path).read_text()
inverse = ledger
start = inverse.index("/// Validated immutable version bytes.")
end = inverse.index("/// Explicit component on the original injected handle.", start)
inverse = inverse[:start] + inverse[end:]
start = inverse.index("    func commit(mutationID:")
body = inverse.index("        try Task.checkCancellation()", start)
original = (BASE / path).read_text()
old_start = original.index("    func commit(mutationID:")
old_body = original.index("        try Task.checkCancellation()", old_start)
inverse = inverse[:start] + original[old_start:old_body] + inverse[body:]
scope = """        let scopes: String
        if localOnly { scopes = "[]" }
        else { scopes = try AnnotationExchangeValidation.destinationList(destinations) }"""
assert inverse.count(scope) == 1
inverse = inverse.replace(scope, "        let scopes = try AnnotationExchangeValidation.destinationList(destinations)")
start = inverse.index("    /// Read-only schema discovery for legacy notes.")
end = inverse.index("    func currentRevision(namespace:", start)
inverse = inverse[:start] + inverse[end:]
assert inverse.encode() == (BASE / path).read_bytes(), "Ledger inverse changed original live exchange behavior"
ledger_inverse = sha(inverse.encode())

path = "Maktabah.xcodeproj/project.pbxproj"
project = (CANDIDATE / path).read_text()
lines = project.splitlines(keepends=True)
added = [line for line in lines if re.search(r"AnnotationLocalEditor(?:Models|Persistence|Session)\.swift", line)]
assert len(added) == 24
inverse = "".join(line for line in lines if line not in added)
assert inverse.encode() == (BASE / path).read_bytes(), "Project change beyond three additive source memberships"
registrations = json.loads((ROOT / "TARGET_REGISTRATION.json").read_text())
phases = re.findall(r"\t\t([A-F0-9]{24}) /\* Sources \*/ = \{\n\s+isa = PBXSourcesBuildPhase;\n\s+files = \((.*?)\n\s+\);", project, re.S)
targets = re.findall(r"\t\t([A-F0-9]{24}) /\* ([^\n]+) \*/ = \{\n\s+isa = PBXNativeTarget;(.*?)\n\t\t\};", project, re.S)
membership = []
for registration in registrations:
    assert project.count(registration["file_ref"]) == 5
    assert registration["file_ref"] not in (BASE / path).read_text()
    for build_id in registration["build_ids"]:
        assert project.count(build_id) == 2
        matches = [(key, body) for key, body in phases if build_id in body]
        assert len(matches) == 1 and "AnnotationExchangeLedger.swift in Sources" in matches[0][1]
        actual_targets = [(key, name) for key, name, body in targets if matches[0][0] in body]
        assert len(actual_targets) == 1
        membership.append({"source": registration["name"], "phase": matches[0][0], "target_id": actual_targets[0][0], "target": actual_targets[0][1], "build_id": build_id})
assert len(membership) == 9 and len({x["target_id"] for x in membership}) == 3

tests = (CANDIDATE / "Tests/HQ/local-annotation-editor/LocalAnnotationEditorAcceptance.swift").read_text()
names = re.findall(r'await run\("([a-z0-9_]+)"\)', tests)
assert len(names) == len(set(names)) == 43
session = (CANDIDATE / "Source/ChavrusaText/Annotations/LocalEditor/AnnotationLocalEditorSession.swift").read_text()
persistence = (CANDIDATE / "Source/ChavrusaText/Annotations/LocalEditor/AnnotationLocalEditorPersistence.swift").read_text()
assert "let snapshot = try await worker.value\n            try storage.requireUnchanged(snapshot)" in session
assert "updatedPayload(intent: intent, inherited: before.version?.payload, source: source)" in persistence
assert "version.payload == document.originalBytes" in persistence
assert "try TorahAnnotationEnvelopeCodec.decode(version.payload) == document" in persistence
assert "case (nil, nil):\n            guard snapshot.revision == 0" in persistence
assert "expectedRevision: expectedRevision, destinations: [], localOnly: true)" in ledger
assert "static let liveExchangeEnabled = false" in (CANDIDATE / "Source/ChavrusaText/Annotations/Exchange/TorahAnnotationEnvelope.swift").read_text()
production_sources = sorted(str(p.relative_to(CANDIDATE)) for p in (CANDIDATE / "Source/ChavrusaText/Annotations/LocalEditor").glob("*.swift"))
all_new = production_sources + ["Tests/HQ/local-annotation-editor/LocalAnnotationEditorBoundary.swift", "Tests/HQ/local-annotation-editor/LocalAnnotationEditorAcceptance.swift", "tools/hq-local-annotation-editor-acceptance.py", "tools/test-local-annotation-editor-sql.py", "tools/test-local-annotation-editor-gate.py"]
source_index = [{"path": p, "bytes": len((CANDIDATE / p).read_bytes()), "sha256": sha((CANDIDATE / p).read_bytes()), "blob": blob((CANDIDATE / p).read_bytes())} for p in sorted(modified | set(all_new))]
patch = ""
for p in sorted(modified):
    patch += "".join(difflib.unified_diff((BASE / p).read_text().splitlines(keepends=True), (CANDIDATE / p).read_text().splitlines(keepends=True), fromfile="a/"+p, tofile="b/"+p))
(ROOT / "evidence/SOURCE.patch").write_bytes(patch.encode())
report = {
    "observed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "status": "PASS_SOURCE_PRESERVATION_ONLY", "base": inputs["base"],
    "swift_executed": 0, "native_executed": 0,
    "originals": originals, "changed_existing_files": sorted(modified),
    "repository_inverse_sha256": repository_inverse, "ledger_inverse_sha256": ledger_inverse,
    "project_inverse_sha256": sha(inverse.encode()),
    "existing_live_commit_body_preserved_except_explicit_local_scopes": True,
    "normal_store_sheet_model_cloudkit_sqlite_queue_bytes_unchanged": True,
    "live_exchange_enabled": False, "target_registration": membership,
    "apple_component_declarations": names, "apple_component_count": len(names),
    "apple_process_modes": ["cold-write", "cold-reopen", "cold-reopen-final"],
    "apple_cold_reopen_gates": 2, "apple_execution": "NOT_RUN",
    "candidate_files": source_index,
}
(ROOT / "evidence/SOURCE_PROOF.json").write_bytes((json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode())
print(json.dumps({"status": report["status"], "original_inputs": len(originals), "unchanged": sum(x["unchanged"] for x in originals), "candidate_files": len(source_index), "target_memberships": len(membership), "apple_declared": len(names), "swift_executed": 0}))
