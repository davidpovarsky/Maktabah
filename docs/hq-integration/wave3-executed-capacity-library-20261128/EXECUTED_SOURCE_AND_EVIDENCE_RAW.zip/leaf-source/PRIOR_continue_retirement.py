#!/usr/bin/env python3
"""One Root-admitted continuation of a refused retirement; original restoration stays exact."""
if not __debug__:
    raise RuntimeError('Optimized Python is refused')
import argparse, hashlib, importlib.util, json, os, stat, sys
from pathlib import Path
P=Path('/home/ubuntu/otzaria-wave3-preserved-untracked-leaf-git-endpoint-continuation-20261128')
ORIGINAL=Path('/home/ubuntu/otzaria-wave3-preserved-untracked-leaf-transport-review2-proposal-20261128')
BASE=Path('/home/ubuntu/otzaria-wave3-preserved-untracked-leaf-transport-20261128')
BIND=Path('/home/ubuntu/otzaria-wave3-preserved-untracked-leaf-root-binding-20261128')
PROOF=Path('/home/ubuntu/otzaria-wave3-retained-untracked-leaf-git-intake-20261128/DURABLE_GIT_PROOF.json')
PHASE='retire-commit-git-endpoint-20261128'
OLD_SEAL='b3fb30020b2bafffd741829e78974f1fa088e20c70d5291d8d35648463ab0e1e'
def require(ok,message):
    if not ok: raise RuntimeError(message)
def read(path,maximum=2*1024**2):
    path=Path(path); fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        require(path.is_absolute() and '..' not in path.parts,'Fixed absolute input required')
        for part in path.parts[1:-1]:
            child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
            os.close(fd);fd=child
        filefd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME,dir_fd=fd)
        try:
            before=os.fstat(filefd)
            require(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_size<=maximum,'Bounded input shape')
            raw=os.pread(filefd,maximum+1,0);after=os.fstat(filefd)
            key=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
            require(len(raw)==before.st_size and key(before)==key(after)==key(os.stat(path.name,dir_fd=fd,follow_symlinks=False)),'Stable exact input')
            return raw
        finally:os.close(filefd)
    finally:os.close(fd)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load_module(name,path,raw):
    m=importlib.util.module_from_spec(importlib.util.spec_from_loader(name,loader=None))
    m.__file__=str(path)
    exec(compile(raw,str(path),'exec'),m.__dict__)
    return m
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-manifest-sha256',required=True)
    a=p.parse_args()
    require(os.geteuid()==0 and sys.flags.isolated and sys.dont_write_bytecode and 'GH_DEBUG' not in os.environ,'Original Root isolated no-debug admission')
    require(Path(__file__).absolute()==P/'continue_retirement.py','Exact continuation path')
    mr=read(P/'SOURCE_MANIFEST.json')
    require(sha(mr)==a.source_manifest_sha256,'Root-reviewed continuation manifest')
    manifest=json.loads(mr)
    require(manifest['schema']=='otzaria.retained-leaf-endpoint-continuation/1' and manifest['phase']==PHASE,'Exact continuation identity')
    for name,pin in manifest['files'].items():
        require(Path(name).name==name,'Closed flat source leaf')
        raw=read(P/name)
        require(len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],'Full closed source bytes')
    failure=json.loads(read(P/'ORIGINAL_FAILURE_PINS.json'))
    require(set(os.listdir(BASE/'retire-commit'))==set(failure),'Original failed phase retained exactly')
    for name,pin in failure.items():
        raw=read(BASE/'retire-commit'/name)
        require(len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],'Actual prior failure unchanged')
    failed=json.loads(read(BASE/'retire-commit'/'TERMINAL_RESULT.json'))
    require(failed['status']=='FAILED_WITH_EXACT_PARTIAL_STATE_PRESERVED' and failed['removed'] is False and failed['stage']=='FULL_DURABLE_GIT_READBACK' and failed['freeBefore'] is None,'Only observed pre-removal failure continuation')
    proc=json.loads(read(BASE/'retire-commit'/'01-git-repository.PROCESS.json'))
    require(proc['argv']==['sudo','-u','ubuntu','-H','gh','api','--hostname','github.com','repos/davidpovarsky/Maktabah/'],'Exact failed endpoint')
    require(read(BASE/'retire-commit'/'01-git-repository.stderr')==b'gh: Not Found (HTTP 404)\n','Observed canonical-endpoint defect')
    original_helper=read(ORIGINAL/'leaf_common.py')
    original_retire=read(ORIGINAL/'retire_untracked_leaf.py')
    require(sha(original_helper)=='a9bfb63bfd5538b51450051ddd8a0260d4396d856d6f4b9a64d255216b63afa7' and sha(original_retire)=='ec5ad989426b3cc2d6637092c7cdbbe70221a2a6653fa5c1ce76cc8afdae098f','Original reviewed implementation retained')
    require(read(P/'PRIOR_leaf_common.py')==original_helper and read(P/'PRIOR_retire_untracked_leaf.py')==original_retire,'Exact preserved original code')
    new_helper=read(P/'leaf_common_endpoint.py')
    h=load_module('retained_leaf_endpoint_common',P/'leaf_common_endpoint.py',new_helper)
    old=load_module('retained_leaf_original_retire',ORIGINAL/'retire_untracked_leaf.py',original_retire)
    args=argparse.Namespace(source_seal_sha256=OLD_SEAL,
        binding=BIND/'ACTUAL_TRANSPORT_BINDING.json',
        binding_sha256='3213427846b4312d31dc614b9f74b66ceda345702b790db9e01b6cfa981346f8',
        closure=BIND/'CLOSURE_REVIEW.json',
        closure_sha256='c5f49d3f2168ba9bdcc36d5830040b386c90ec2af3d9315f9a246066294f5b0e',
        ack_predelete_sha256='bd1a444ff3b7fe334f1e7a12e92a719d4dfb532cd0eacbd9531f2dca4e811f19',
        git_proof=PROOF,git_proof_sha256='da5b4fcb57746b19efc814bbcab43b904dbd36d51e796a266f065492054ec56d')
    require(sha(read(PROOF))==args.git_proof_sha256,'Actual full-readback Git proof unchanged')
    seal,_=h.verify_seal(OLD_SEAL)
    h.bound_transport(args.binding,args.binding_sha256,OLD_SEAL)
    old.closure_review(h,args.closure,args.closure_sha256)
    require(not os.path.lexists(BASE/PHASE),'Fresh explicit continuation only; never reuse failed phase')
    rt=None
    try:
        rt=h.Runtime(PHASE)
        rt.write('SOURCE_SEAL_CURRENT.json',seal)
        rt.write('CONTINUATION_SOURCE_BINDING.json',{'schema':manifest['schema'],'phase':PHASE,
            'sourceManifestSHA256':a.source_manifest_sha256,'controllerSHA256':sha(read(P/'continue_retirement.py')),
            'helperSHA256':sha(new_helper),'originalHelperSHA256':sha(original_helper),
            'originalRetireSHA256':sha(original_retire),'originalSourceSealSHA256':OLD_SEAL,
            'priorFailureSHA256':failure['TERMINAL_RESULT.json']['sha256'],
            'change':'Canonical repository metadata endpoint; fresh explicit phase; original sealed restoration inputs and full original commit function unchanged.'})
        old.commit(h,rt,args,seal)
    finally:
        if rt is not None:rt.close()
if __name__=='__main__':main()
