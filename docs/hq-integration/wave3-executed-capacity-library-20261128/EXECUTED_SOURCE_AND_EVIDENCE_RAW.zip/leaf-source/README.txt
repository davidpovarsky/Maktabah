Source-only endpoint2 continuation of two preserved pre-unlink failures.

First failure: job_17ceda4bc7e9 reached GitHub through the original slash-suffixed repository metadata URL and received HTTP404. Its six raw phase files remain exact.

Second failure: job_e93bc4dc39c6 terminated 2026-11-28T06:40:08.201243+00:00 with exit1. The canonical endpoint was refused locally by the unchanged Runtime.api predicate before any gh/API child or unlink. Exactly three phase files remain. The terminal suppresses exception text; the local predicate cause is established by source/Root diagnosis, not invented terminal text.

Correction: preserve both existing Runtime.api prefixes and add equality for the exact already-authorized repos/davidpovarsky/Maktabah metadata endpoint. Add only the named endpoint2 phase under the same BASE and original guards. No generic repository expansion, auth change, upload/retry or restoration-mode change.

The wrapper preserves first-failure checks and additionally pins all three second-failure bytes plus the prior source binding before creating the fresh phase. Original ec5ad989 commit implementation, b3fb3002 six-file seal, binding32134278, closurec5f49d3f, PREDELETEbd1a444f and durable Git proofda5b4fcb at607bd0a7 remain exact.

Original 4MiB runtime metadata cap, rootfloor1593835520,2700s deadline, reserved terminal, full remote Git/private-asset joins,85 source hashes,no-use/FD checks and sole691303419-byte archive unlink remain unchanged.

The complete old19-file source scope is retained byte-for-byte by ORIGINAL_SOURCE_PACKET_RAW.zip (17 fully read-back members), ORIGINAL_SOURCE_HANDOFF.json and the exact ZIP itself. Additional direct preimage copies are for review. The old scope and both original failed phases remain in place unchanged.

No controller was imported/executed, no test/compiler/SDK ran, and no credentials/API/upload/retirement/source-data mutation occurred while authoring. The parent is the sole executor and must review this packet and its exact manifest before any new invocation.

Future CLI only after Root authorization: /usr/bin/python3 -I -B <this scope>/continue_retirement.py --source-manifest-sha256 <exact SOURCE_MANIFEST.json SHA256>. Run as Root with GH_DEBUG absent. No automatic retry.

This packet's allocated size is limited to2MiB; it grants no current source closure, storage capacity, compiler admission or source-tree restoration acceptance.
