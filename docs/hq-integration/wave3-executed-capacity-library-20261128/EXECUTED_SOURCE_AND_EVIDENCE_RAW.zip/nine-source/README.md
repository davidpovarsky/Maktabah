# Nine-scope relocation proposal — source only

This separate derivative excludes exactly the RN vendor-transition diagnostic that the actual ten-scope prepare refused. No relocation controller was imported, parsed, executed or tested while authoring this packet. No workspace, Data source, Git repository, branch registration or runtime destination was changed. Root retains execution and cutover ownership.

## Exact reason and scope

Root reported job job_c329a660bfd5 at 2026-11-28T06:24:31Z refused the nested controls-attempt-1/previous39/control-checkout/.git under /mnt/development/projects/diagnostics/otzaria-wave3-rn-vendor-transition-20261127, during inventory before destination creation or copy. TEN_SCOPE_ACTUAL_PREPARE_REFUSAL.json retains those actual reported facts and explicitly states that the full job transport envelope was not independently downloaded here. The nested-Git refusal is preserved without an admission exception.

The excluded diagnostic's observed allocation is 33,046,528 bytes. These nine unchanged scope rows retain their original identifiers and total 418,410,496 observed allocated bytes:

| Original ID | Exact original path | Kind | Observed allocated bytes |
|---|---|---|---:|
| 01 | /mnt/development/projects/worktrees/Maktabah-wave3-integration-20261127 | linked | 141475840 |
| 02 | /mnt/development/projects/worktrees/Maktabah-wave3-vendor-admission-private-20261127 | private | 73125888 |
| 03 | /mnt/development/projects/worktrees/Maktabah-wave3-search-results-intent-20261127 | linked | 52645888 |
| 04 | /mnt/development/projects/worktrees/Maktabah-wave3-reader-tab-intent-20261127 | linked | 44769280 |
| 05 | /mnt/development/projects/worktrees/Maktabah-wave3-sefaria-native-surface-20261127 | linked | 40628224 |
| 06 | /mnt/development/projects/diagnostics/otzaria-wave3-hidden-group-current-bindings-20261127 | diagnostic | 22233088 |
| 08 | /mnt/development/projects/worktrees/Maktabah-wave3-abi-restoration-evidence-20261127 | linked | 15499264 |
| 09 | /mnt/development/projects/worktrees/Maktabah-wave3-phone-routing-20261127 | linked | 14721024 |
| 10 | /mnt/development/projects/worktrees/Maktabah-wave3-parent-routing-20261127 | linked | 13312000 |

## Exact source and preservation

RELOCATE_CLOSED_WORKSPACES.py is 61,483 bytes, SHA-256 a729ef49eb039a7f66b6a0447044d2f198310018e60652e37087b03ed1d79b76. PLAN.json is 34,004 bytes, SHA-256 5fd869b434cf887eadc4e56cc05bc7959f47f8b0998f0f760cc682054746b3d7.

The 14 exact source replacements change only the scope description, proposal/destination paths, exact exclusion/counts, receipt labels and plan pin. Five plan fields change. All other source bytes and parsed plan fields are identical to the reviewed ten-scope predecessor. Both forward and inverse text joins, and both lossless ndiff reconstructions, were checked as data operations. NINE_SCOPE_DELTA.json records them; the patches are reviewable full text. The original compact plan serialization is retained. An earlier unexecuted pretty-JSON draft and all its hashes remain under review/before-original-canonical-plan-format/.

prior/TEN_SCOPE_SOURCE_RAW.zip preserves the closed prior packet's complete raw payload and manifest; its exact original manifest and handoff are also retained. The prior controller269613 and plan2db5, original inputs777e, dependency observation40e0, original fa0ea controller and peer reviews remain byte-exact. This packet does not rewrite the earlier closed27 or reclassify the actual prepare refusal.

## Unchanged operational gates

The seven absolute linked-worktree Git pointers and one independent private Git root keep their original state/dependency pins. Only exact admitted top-level Git types are permitted; nested Git remains refused. The surviving diagnostic is unchanged. Full raw bytes, metadata, xattrs, link/hardlink safeguards, no-use FD/CWD/exe/maps checks, exact aliases, original-path Git identity checks, PREPARED hash separation, per-scope failures and rollback/removal logic retain the reviewed bodies.

The runtime copy cap is 536,870,912 bytes, metadata reserve 16,777,216 bytes, original deadline 360 seconds, and root floor 1,593,835,520 bytes. Current Root HEAD is not a runtime gate; protected dependencies and the eight old Git states remain pinned. Runtime reads may still refuse changed state, no-use uncertainty, capacity or any other original guard. Source review does not establish actual Git runtime or copy/alias correctness. No prospective capacity recovery is claimed.

The fresh future destination is /home/ubuntu/otzaria-wave3-closed-workspaces-nine-relocated-20261128. At the recorded read-only check, both it and the prior attempted destination were absent; DESTINATION_ABSENCE_READ.json gives that observation's time. This is a point-in-time fact, not execution admission. Root must independently admit preparation, then review the actual PREPARED hash before any separate cutover.

## Limits and closure

This proposal scope is bounded to 2 MiB including source, prior raw archive, metadata and its new ZIP. Every allocation checks the original root floor plus that reserve. No controller import/execution, compiler, build, test, native app action, source approval, signature, process signal or Data/Git mutation is part of this handoff. The raw ZIP and manifest preserve bytes without normalizing line endings. Any later peer review belongs in an additive record, leaving this closed source packet unchanged.
