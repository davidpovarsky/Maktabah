"""Exact nine-scope, two-phase lossless relocation proposal.

This is a separate controller, not an imported or edited prior fifteen-scope
controller. Root must separately admit prepare and cutover. Neither phase runs
builds/tests, repairs Git, changes refs/config/index, contacts a remote, or signals
processes. A failed phase is retained and is never automatically retried.
"""
import sys
if sys.flags.optimize:
    raise SystemExit("Optimized Python is not admitted")
if __name__ != "__main__":
    raise SystemExit("Import is not an execution/admission interface")

from pathlib import Path, PurePosixPath
import base64, datetime, errno, hashlib, json, os, pwd, re, stat, subprocess, time

PROPOSAL = Path("/home/ubuntu/otzaria-wave3-closed-workspace-nine-scope-proposal-20261128")
DEST = Path("/home/ubuntu/otzaria-wave3-closed-workspaces-nine-relocated-20261128")
META = DEST / ".relocation-metadata"
INPUT_SHA = "777e2f3608bcb6589741bac56ce83e33a8aad27cbb6ad79b381e046cb2785f30"
PLAN_SHA = "c967db0185109fe563023eb960546d50076f6b60b0a2cfa2f53f5e2c3dbf72d5"
DEPENDENCIES_SHA = "40e0a69f2569f0a9a4543237c6d9d325ea853f0d186eb38b5a877c67f50c333c"
ROOT_FLOOR = 1593835520
COPY_CAP = 536870912
META_CAP = 16777216
FAILURE_RESERVE = 131072
DEADLINE_SECONDS = 360
WORKTREE_PARENT = Path("/mnt/development/projects/worktrees")
DIAGNOSTIC_PARENT = Path("/mnt/development/projects/diagnostics")
MIRROR = Path("/mnt/development/projects/git-mirrors/Maktabah.git")
RFLAGS = os.O_RDONLY | os.O_NOFOLLOW | os.O_NOATIME
DFLAGS = RFLAGS | os.O_DIRECTORY
PLAN = None
INPUTS = None
DEPENDENCIES = None
DEADLINE = None
PHASE = None
CURRENT_SCOPE = None
EVENT_NUMBER = 0
LIVE_CHILD = None
COPY_BLOCKS = {}
META_BLOCKS = {}
SELF_RAW = None
PLAN_RAW = None
METADATA_ADMITTED = False
GIT_USER = None
GIT_GROUPS = None

def require(value, message):
    if not value:
        raise RuntimeError(message)

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def check_time():
    require(time.monotonic() < DEADLINE,
            "Original 360-second deadline reached; retained state is not cleaned up")

def free(path="/"):
    v = os.statvfs(path)
    return v.f_bavail * v.f_frsize

def guard(next_allocation=0, emergency=False):
    if not emergency:
        check_time()
    reserve = FAILURE_RESERVE if emergency else META_CAP
    require(free("/") >= ROOT_FLOOR + reserve + next_allocation,
            "Root floor plus metadata/allocation reserve unavailable")
    require(sum(COPY_BLOCKS.values()) <= COPY_CAP, "Copied allocation cap exceeded")
    require(sum(META_BLOCKS.values()) <= META_CAP, "Phase metadata cap exceeded")

def stat_identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid,
            s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)

def stable(s, row):
    return stat_identity(s) == tuple(row[k] for k in
        ("device", "inode", "mode", "uid", "gid", "nlink", "size", "mtime_ns", "ctime_ns"))

def safe_parts(relative):
    p = PurePosixPath(relative)
    require(not p.is_absolute() and all(x not in ("", "..") for x in p.parts),
            "Unsafe relative member")
    return () if relative == "." else p.parts

def absolute_directory(path):
    """Open every component without following links; caller closes result."""
    path = Path(path)
    require(path.is_absolute() and str(path) == os.path.normpath(str(path)),
            "Noncanonical absolute directory")
    fd = os.open("/", DFLAGS)
    try:
        for name in path.parts[1:]:
            nxt = os.open(name, DFLAGS, dir_fd=fd)
            os.close(fd)
            fd = nxt
        return fd
    except BaseException:
        os.close(fd)
        raise

def beneath_parent(root_fd, relative):
    parts = safe_parts(relative)
    require(parts, "A leaf is required")
    fd = os.dup(root_fd)
    try:
        for name in parts[:-1]:
            nxt = os.open(name, DFLAGS, dir_fd=fd)
            os.close(fd)
            fd = nxt
        return fd, parts[-1]
    except BaseException:
        os.close(fd)
        raise

def beneath_open(root_fd, relative, flags, mode=0o600):
    if relative == ".":
        return os.dup(root_fd)
    fd, name = beneath_parent(root_fd, relative)
    try:
        return os.open(name, flags, mode, dir_fd=fd)
    finally:
        os.close(fd)

def read_regular(path, maximum=8388608):
    p = Path(path)
    pfd = absolute_directory(p.parent)
    try:
        fd = os.open(p.name, RFLAGS, dir_fd=pfd)
    finally:
        os.close(pfd)
    try:
        a = os.fstat(fd)
        require(stat.S_ISREG(a.st_mode) and a.st_nlink == 1 and a.st_size <= maximum,
                "Unexpected regular metadata input: " + str(p))
        chunks = []
        left = a.st_size
        while left:
            check_time()
            b = os.read(fd, min(1048576, left))
            require(b, "Short metadata read")
            chunks.append(b)
            left -= len(b)
        require(os.read(fd, 1) == b"" and stat_identity(os.fstat(fd)) == stat_identity(a),
                "Metadata changed during read")
        return b"".join(chunks), a
    finally:
        os.close(fd)

def update_blocks(kind, key, fd):
    table = COPY_BLOCKS if kind == "copy" else META_BLOCKS
    table[key] = os.fstat(fd).st_blocks * 512
    require(sum(COPY_BLOCKS.values()) <= COPY_CAP, "Copied allocation cap exceeded")
    require(sum(META_BLOCKS.values()) <= META_CAP, "Phase metadata cap exceeded")

def durable(name, value, emergency=False):
    """Exclusive metadata file; never rewrites a prior receipt."""
    data = value if isinstance(value, bytes) else canonical(value)
    require("/" not in name and name not in ("", ".", ".."), "Bad receipt name")
    limit = META_CAP if emergency else META_CAP - FAILURE_RESERVE
    need = ((len(data) + 4095) // 4096) * 4096 + 8192
    require(sum(META_BLOCKS.values()) + need <= limit, "Metadata reserve would be exhausted")
    guard(need, emergency=emergency)
    mfd = absolute_directory(META)
    try:
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=mfd)
        try:
            offset = 0
            while offset < len(data):
                n = os.write(fd, data[offset:offset + 1048576])
                require(n > 0, "Short metadata write")
                offset += n
            os.fsync(fd)
            update_blocks("meta", name, fd)
        finally:
            os.close(fd)
        os.fsync(mfd)
        update_blocks("meta", ".", mfd)
    finally:
        os.close(mfd)
    return {"file": name, "bytes": len(data), "sha256": digest(data)}

def event(label, data, emergency=False):
    global EVENT_NUMBER
    EVENT_NUMBER += 1
    safe = re.sub("[^A-Za-z0-9_-]", "_", label)
    name = "%s-%03d-%s.json" % (PHASE.upper(), EVENT_NUMBER, safe)
    return durable(name, {"utc": utc(), "phase": PHASE, "scope": CURRENT_SCOPE,
                          "event": label, "data": data}, emergency=emergency)

def xattrs_fd(fd):
    return {k: base64.b64encode(os.getxattr(fd, k)).decode()
            for k in sorted(os.listxattr(fd))}

def link_xattrs(parent_fd, name):
    path = "/proc/self/fd/%d/%s" % (parent_fd, name)
    return {k: base64.b64encode(os.getxattr(path, k, follow_symlinks=False)).decode()
            for k in sorted(os.listxattr(path, follow_symlinks=False))}

def regular_hash(fd, expected):
    require(stable(os.fstat(fd), expected), "File identity changed before hashing")
    h = hashlib.sha256()
    remaining = expected["size"]
    while remaining:
        check_time()
        b = os.read(fd, min(1048576, remaining))
        require(b, "Short file read")
        h.update(b)
        remaining -= len(b)
    require(os.read(fd, 1) == b"" and stable(os.fstat(fd), expected),
            "File changed while hashing")
    return h.hexdigest()

def git_entry_allowed(config, relative, mode):
    parts = safe_parts(relative)
    if ".git" not in parts:
        return
    kind = config.get("git", {}).get("kind")
    require(parts[0] == ".git" and ".git" not in parts[1:],
            "Nested Git entry is not admitted: " + relative)
    if relative == ".git":
        expected_kind = stat.S_ISREG(mode) if kind == "linked" else stat.S_ISDIR(mode)
        require(kind in ("linked", "private") and expected_kind, "Top-level Git type mismatch")
    else:
        require(kind == "private", "Linked Git pointer cannot contain descendants")
    if kind == "private":
        require(parts[:2] not in ((".git", "worktrees"), (".git", "modules")),
                "Private nested Git registration not admitted")

def inventory(root, config):
    """Full no-follow byte/metadata inventory; no source writes."""
    check_time()
    root = Path(root)
    rfd = absolute_directory(root)
    device = os.fstat(rfd).st_dev
    rows = []
    allowed_links = config.get("symlinks", {})
    def walk(parent_fd, name, relative):
        guard()
        s = os.fstat(parent_fd) if relative == "." else os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        require(s.st_dev == device, "Cross-device member refused")
        git_entry_allowed(config, relative, s.st_mode)
        row = {"path": relative, "mode": s.st_mode, "uid": s.st_uid, "gid": s.st_gid,
               "atime_ns": s.st_atime_ns, "mtime_ns": s.st_mtime_ns, "ctime_ns": s.st_ctime_ns,
               "device": s.st_dev, "inode": s.st_ino, "nlink": s.st_nlink,
               "blocks": s.st_blocks, "size": s.st_size}
        if stat.S_ISREG(s.st_mode):
            require(s.st_nlink == 1, "Hardlinked regular member refused")
            fd = os.open(name, RFLAGS, dir_fd=parent_fd)
            try:
                row["type"] = "file"
                row["xattrs"] = xattrs_fd(fd)
                row["sha256"] = regular_hash(fd, row)
            finally:
                os.close(fd)
        elif stat.S_ISDIR(s.st_mode):
            fd = os.dup(parent_fd) if relative == "." else os.open(name, DFLAGS, dir_fd=parent_fd)
            try:
                require(stable(os.fstat(fd), row), "Directory changed before traversal")
                row["type"] = "directory"
                row["xattrs"] = xattrs_fd(fd)
                rows.append(row)
                with os.scandir(fd) as entries:
                    names = sorted(e.name for e in entries)
                for child in names:
                    walk(fd, child, child if relative == "." else relative + "/" + child)
                require(stable(os.fstat(fd), row), "Directory changed during traversal")
                return
            finally:
                os.close(fd)
        elif stat.S_ISLNK(s.st_mode):
            row["type"] = "symlink"
            row["target"] = os.readlink(name, dir_fd=parent_fd)
            row["xattrs"] = link_xattrs(parent_fd, name)
            require(allowed_links.get(relative) == row["target"], "Undeclared symlink refused")
            require(not os.path.isabs(row["target"]), "Only declared internal relative links are admitted")
            lexical = os.path.normpath(os.path.join(os.path.dirname(relative), row["target"]))
            require(lexical != ".." and not lexical.startswith("../") and not os.path.isabs(lexical),
                    "Escaping relative link refused")
            require(stat_identity(os.stat(name, dir_fd=parent_fd, follow_symlinks=False)) == stat_identity(s),
                    "Symlink changed during read")
        else:
            raise RuntimeError("Special file refused: " + relative)
        rows.append(row)
    try:
        walk(rfd, "", ".")
    finally:
        os.close(rfd)
    require(set(allowed_links) == {r["path"] for r in rows if r["type"] == "symlink"},
            "Declared symlink set changed")
    for r in rows:
        if r["type"] == "symlink":
            target = os.path.normpath(os.path.join(os.path.dirname(r["path"]), r["target"]))
            require(any(x["path"] == target and x["type"] == "file" for x in rows),
                    "Declared relative link no longer resolves to an internal regular file")
    return rows

def content_metadata(rows, include_atime=False):
    ignored = {"inode", "device", "ctime_ns", "blocks"}
    if not include_atime:
        ignored.add("atime_ns")
    return [{k: v for k, v in r.items() if k not in ignored and
             not (r["type"] == "directory" and k == "size")} for r in rows]

def same_original(rows, expected, top_rename=False):
    require(content_metadata(rows) == content_metadata(expected), "Original content/metadata changed")
    for a,b in zip(rows, expected):
        keys = ("device", "inode", "ctime_ns") if not (top_rename and a["path"] == ".") else ("device", "inode")
        require(all(a[k] == b[k] for k in keys), "Original identity/history changed")

def set_metadata(root_fd, row, scope_key):
    metadata_bound=16384+sum(((len(base64.b64decode(v,validate=True))+4095)//4096)*4096
                            for v in row["xattrs"].values())
    guard(metadata_bound)
    require(sum(COPY_BLOCKS.values())+metadata_bound<=COPY_CAP,"Metadata copy allocation bound exceeded")
    if row["type"] == "symlink":
        pfd, name = beneath_parent(root_fd, row["path"])
        try:
            os.chown(name, row["uid"], row["gid"], dir_fd=pfd, follow_symlinks=False)
            p = "/proc/self/fd/%d/%s" % (pfd, name)
            existing = set(os.listxattr(p, follow_symlinks=False))
            require(existing <= set(row["xattrs"]), "Unexpected copied link xattr")
            for k,v in row["xattrs"].items():
                os.setxattr(p, k, base64.b64decode(v, validate=True), follow_symlinks=False)
            os.utime(name, ns=(row["atime_ns"], row["mtime_ns"]), dir_fd=pfd, follow_symlinks=False)
            st = os.stat(name, dir_fd=pfd, follow_symlinks=False)
            COPY_BLOCKS[(scope_key, row["path"])] = st.st_blocks * 512
            update_blocks("copy", (scope_key, str(PurePosixPath(row["path"]).parent)), pfd)
            os.fsync(pfd)
        finally:
            os.close(pfd)
        return
    flags = DFLAGS if row["type"] == "directory" else RFLAGS
    fd = beneath_open(root_fd, row["path"], flags)
    try:
        os.fchown(fd, row["uid"], row["gid"])
        os.fchmod(fd, stat.S_IMODE(row["mode"]))
        existing = set(os.listxattr(fd))
        for k in existing - set(row["xattrs"]):
            os.removexattr(fd, k)
        for k,v in row["xattrs"].items():
            os.setxattr(fd, k, base64.b64decode(v, validate=True))
        os.utime(fd, ns=(row["atime_ns"], row["mtime_ns"]))
        os.fsync(fd)
        update_blocks("copy", (scope_key, row["path"]), fd)
    finally:
        os.close(fd)

def restore_times_and_sync(target, rows, scope_key):
    """Only destination metadata changes; source atime is kept in its manifest."""
    root_fd = absolute_directory(target)
    try:
        for row in reversed(rows):
            guard()
            if row["type"] == "symlink":
                pfd,name = beneath_parent(root_fd, row["path"])
                try:
                    os.utime(name, ns=(row["atime_ns"],row["mtime_ns"]), dir_fd=pfd, follow_symlinks=False)
                    os.fsync(pfd)
                finally:
                    os.close(pfd)
            else:
                fd = beneath_open(root_fd, row["path"], DFLAGS if row["type"] == "directory" else RFLAGS)
                try:
                    os.utime(fd, ns=(row["atime_ns"],row["mtime_ns"]))
                    os.fsync(fd)
                    update_blocks("copy", (scope_key,row["path"]), fd)
                finally:
                    os.close(fd)
        os.fsync(root_fd)
    finally:
        os.close(root_fd)
    parent = absolute_directory(Path(target).parent)
    try:
        os.fsync(parent)
        update_blocks("meta", "destination-container", parent)
    finally:
        os.close(parent)

def copy_scope(config, original):
    """Fixed-size no-follow copy, never following a source link or Git pointer."""
    key = config["id"]
    source = Path(config["path"])
    target = DEST / source.name
    source_fd = absolute_directory(source)
    dest_parent_fd = absolute_directory(DEST)
    try:
        require(stable(os.fstat(source_fd), original[0]), "Source root changed before copy")
        guard(16384)
        os.mkdir(source.name, 0o700, dir_fd=dest_parent_fd)
        os.fsync(dest_parent_fd)
        update_blocks("meta", "destination-container", dest_parent_fd)
        target_fd = os.open(source.name, DFLAGS, dir_fd=dest_parent_fd)
        try:
            update_blocks("copy",(key,"."),target_fd)
            for row in original[1:]:
                guard(16384)
                require(sum(COPY_BLOCKS.values()) + 16384 <= COPY_CAP, "Copy reserve exhausted")
                dp,leaf = beneath_parent(target_fd,row["path"])
                sp,sleaf = beneath_parent(source_fd,row["path"])
                try:
                    st = os.stat(sleaf,dir_fd=sp,follow_symlinks=False)
                    require(stable(st,row), "Source member replaced before copy")
                    if row["type"] == "directory":
                        os.mkdir(leaf,0o700,dir_fd=dp)
                        fd=os.open(leaf,DFLAGS,dir_fd=dp)
                        try:
                            update_blocks("copy",(key,row["path"]),fd)
                        finally:
                            os.close(fd)
                    elif row["type"] == "symlink":
                        require(os.readlink(sleaf,dir_fd=sp)==row["target"], "Source link replaced")
                        os.symlink(row["target"],leaf,dir_fd=dp)
                        COPY_BLOCKS[(key,row["path"])]=os.stat(leaf,dir_fd=dp,follow_symlinks=False).st_blocks*512
                    else:
                        sf=os.open(sleaf,RFLAGS,dir_fd=sp)
                        df=None
                        try:
                            require(stable(os.fstat(sf),row), "Source file replaced at open")
                            df=os.open(leaf,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=dp)
                            left=row["size"]
                            h=hashlib.sha256()
                            while left:
                                request=min(left,1048576)
                                guard(request+16384)
                                require(sum(COPY_BLOCKS.values()) + request + 16384 <= COPY_CAP,
                                        "Fixed next copy allocation exceeds cap")
                                block=os.read(sf,request)
                                require(block, "Short original file during copy")
                                h.update(block)
                                at=0
                                while at<len(block):
                                    n=os.write(df,block[at:])
                                    require(n>0,"Short destination write")
                                    at+=n
                                left-=len(block)
                                update_blocks("copy",(key,row["path"]),df)
                            require(os.read(sf,1)==b"" and stable(os.fstat(sf),row),
                                    "Original file changed during copy")
                            require(h.hexdigest()==row["sha256"], "Original bytes changed during copy")
                            os.fsync(df)
                            update_blocks("copy",(key,row["path"]),df)
                        finally:
                            if df is not None:os.close(df)
                            os.close(sf)
                    update_blocks("copy",(key,str(PurePosixPath(row["path"]).parent)),dp)
                    os.fsync(dp)
                finally:
                    os.close(sp)
                    os.close(dp)
            for row in reversed(original):
                guard(16384)
                set_metadata(target_fd,row,key)
            os.fsync(target_fd)
        finally:
            os.close(target_fd)
    finally:
        os.close(source_fd)
        os.close(dest_parent_fd)
    copied=inventory(target,config)
    require(content_metadata(copied,True)==content_metadata(original,True), "Copy bytes/metadata mismatch")
    return target,copied

def no_use(roots):
    """Point-in-time process-path evidence; permission uncertainty refuses."""
    started=time.monotonic()
    prefixes=tuple(str(p) for p in roots)
    matches=[]
    inspected=0
    def relevant(value):
        value=value.removesuffix(" (deleted)")
        return any(value==p or value.startswith(p+"/") for p in prefixes)
    def link(proc,name):
        try:
            value=os.readlink(proc/name)
        except (FileNotFoundError,ProcessLookupError):
            return
        if relevant(value):
            matches.append({"pid":int(proc.name),"kind":name,"path":value})
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():
            continue
        check_time()
        require(time.monotonic()-started<20,"No-use observation exceeded original bounded window")
        inspected+=1
        try:
            for name in ("cwd","root","exe"):
                link(proc,name)
            for f in (proc/"fd").iterdir():
                link(proc,"fd/"+f.name)
            for line in (proc/"maps").read_text().splitlines():
                fields=line.split(None,5)
                if len(fields)==6:
                    value=re.sub(r"\\([0-7]{3})",lambda m:chr(int(m.group(1),8)),fields[5])
                    if relevant(value):
                        matches.append({"pid":int(proc.name),"kind":"maps","path":value})
        except (FileNotFoundError,ProcessLookupError):
            # A process that vanished is not treated as an unreadable live process.
            pass
        except PermissionError as error:
            raise RuntimeError("Cannot inspect a live process; no-use unavailable") from error
    require(not matches,"Live use of a relocation source/destination: "+json.dumps(matches))
    return {"utc":utc(),"processesInspected":inspected,"matches":matches,
            "seconds":time.monotonic()-started,"processSignals":0,
            "scope":"Fresh fd/cwd/root/exe/maps path observation; not a future-use guarantee"}

def run_readonly_git(args,cwd):
    """No network, optional index writes, hooks, fsmonitor or maintenance."""
    global LIVE_CHILD
    check_time()
    env={"PATH":"/usr/bin:/bin","LANG":"C","LC_ALL":"C",
         "GIT_OPTIONAL_LOCKS":"0","GIT_CONFIG_NOSYSTEM":"1",
         "GIT_CONFIG_SYSTEM":"/dev/null","GIT_CONFIG_GLOBAL":"/dev/null",
         "GIT_TERMINAL_PROMPT":"0","GIT_ASKPASS":"/bin/false","SSH_ASKPASS":"/bin/false",
         "GIT_SSH_COMMAND":"/bin/false","GIT_ALLOW_PROTOCOL":"",
         "GIT_PROTOCOL_FROM_USER":"0","GIT_NO_LAZY_FETCH":"1","GIT_NO_REPLACE_OBJECTS":"1",
         "GIT_PAGER":"cat","GIT_EXTERNAL_DIFF":"/bin/false"}
    command=["/usr/bin/git","--no-optional-locks","-c","core.fsmonitor=false",
             "-c","core.untrackedCache=false","-c","gc.auto=0",
             "-c","maintenance.auto=false","-c","protocol.allow=never",
             "-c","protocol.file.allow=never","-c","protocol.ext.allow=never",
             "-c","submodule.recurse=false"]
    # Exact observed promisor entries are disabled for these read-only invocations.
    # Their original configuration bytes stay untouched.
    for key in PLAN["observedPromisorKeys"]:
        command.extend(["-c",key+"=false"])
    command.extend(["-C",str(cwd)])
    command.extend(args)
    proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,close_fds=True,
                          user=GIT_USER.pw_uid,group=GIT_USER.pw_gid,extra_groups=GIT_GROUPS)
    LIVE_CHILD={"pid":proc.pid,"command":command,"startedUtc":utc()}
    try:
        out,err=proc.communicate(timeout=max(0.05,min(20,DEADLINE-time.monotonic())))
    except subprocess.TimeoutExpired:
        # Popen.communicate does not kill the child. Do not signal or continue a phase.
        raise RuntimeError("Read-only Git child timed out; exact PID retained, no process signal")
    LIVE_CHILD=None
    require(len(out)+len(err)<=2097152,"Git observation output bound exceeded")
    require(proc.returncode==0,"Read-only Git observation failed: "+err.decode(errors="replace")[:4096])
    return out,{"args":args,"stdoutBytes":len(out),"stdoutSHA256":digest(out),
                "stderrBytes":len(err),"stderrSHA256":digest(err),"returncode":proc.returncode}

def dependency_file(path,pin,physical_root=None,original_root=None):
    p=Path(path)
    if physical_root is not None and original_root is not None:
        old=str(original_root)+"/"
        if str(p).startswith(old):
            p=Path(physical_root)/str(p)[len(old):]
    try:
        st=p.lstat()
    except FileNotFoundError:
        require(not pin["exists"],"Pinned Git dependency disappeared")
        return {"path":str(p),"exists":False}
    require(pin["exists"],"New unreviewed Git dependency")
    if pin.get("kind")=="directory":
        require(stat.S_ISDIR(st.st_mode) and not p.is_symlink(),"Git directory type changed")
        return {"path":str(p),"exists":True,"kind":"directory"}
    raw,_=read_regular(p,1048576)
    require(len(raw)==pin["bytes"] and digest(raw)==pin["sha256"],"Git dependency bytes changed: "+str(p))
    return {"path":str(p),"exists":True,"bytes":len(raw),"sha256":digest(raw)}

def validate_git_dependencies(config,physical_root):
    g=config.get("git")
    if not g:return []
    original=Path(config["path"])
    result=[]
    for pin in g["dependencyPins"]:
        result.append(dependency_file(pin["path"],pin,physical_root,original))
    # These copies have no alternates or config path indirection. Refuse a newly
    # supplied dependency rather than normalizing or rewriting a relative path.
    for name in (".git/objects/info/alternates",".git/objects/info/http-alternates"):
        require(not os.path.lexists(Path(physical_root)/name),"Unadmitted private Git alternates")
    if g["kind"]=="private":
        for name in (".git/commondir",".git/gitdir",".git/worktrees",".git/modules"):
            require(not os.path.lexists(Path(physical_root)/name),"Unadmitted private Git registration")
    config_paths=g["configPaths"]
    for path in config_paths:
        p=Path(path)
        if str(p).startswith(str(original)+"/"):
            p=Path(physical_root)/p.relative_to(original)
        out,_=run_readonly_git(["config","--file",str(p),"--no-includes","--null","--list"],physical_root)
        for item in out.split(b"\0"):
            if not item:continue
            key,_,value=item.partition(b"\n")
            k=key.decode().lower()
            require(not (k.startswith("include.") or k.startswith("includeif.") or
                         k.startswith("filter.") or k in PLAN["refusedConfigKeys"] or
                         re.match(r"^(diff\..*\.command|merge\..*\.driver)$",k)),
                    "Unadmitted Git config indirection/command: "+k)
            if k.startswith("remote.") and k.endswith(".url"):
                text=value.decode()
                is_url="://" in text or re.match(r"^[^/]+@[^:]+:",text) is not None
                require(is_url or os.path.isabs(text),"Escaping relative Git remote path refused")
            if k.startswith("remote.") and k.endswith(".uploadpack"):
                require(value==b"git -c uploadpack.allowFilter=true upload-pack",
                        "Unreviewed upload-pack metadata")
    return result

def git_admin_state(config):
    """Read-only guards for linked worktree administrative bytes kept in place."""
    g=config.get("git")
    if not g or g["kind"]!="linked":return None
    directory=Path(g["gitDir"])
    admin=inventory(directory,{"symlinks":{}})
    require(not any(r["path"].endswith(".lock") for r in admin),"Git admin has a live lock")
    branch=g["branch"]
    require(branch.startswith("refs/heads/") and ".." not in PurePosixPath(branch).parts,"Invalid pinned branch")
    extra=[]
    for path in [MIRROR/"config",MIRROR/"packed-refs",MIRROR/branch]:
        try:
            b,s=read_regular(path,16777216)
            extra.append({"path":str(path),"bytes":len(b),"sha256":digest(b),
                          "identity":list(stat_identity(s))})
        except FileNotFoundError:
            extra.append({"path":str(path),"exists":False})
    return {"admin":admin,"references":extra}

def git_snapshot(config,physical_root,label,expected_admin=None):
    g=config.get("git")
    if not g:return {"kind":"diagnostic","label":label,"commands":[]}
    before=git_admin_state(config)
    if expected_admin is not None:
        require(admin_equal(before,expected_admin),"Protected linked Git admin/ref metadata changed")
    original=Path(config["path"])
    supplied=Path(physical_root)
    target=DEST/original.name
    require(supplied in (original,target),"Git observation path is outside its exact source/copy pair")
    if supplied.is_symlink():
        require(supplied==original and os.readlink(supplied)==str(target) and not target.is_symlink(),
                "Only the exact installed original-path alias is admitted")
    physical=supplied.resolve(strict=True)
    require(physical in (original,target),"Git observation resolves outside its source/copy pair")
    dependencies=validate_git_dependencies(config,physical)
    expected={
        "head":(["rev-parse","--verify","HEAD"],g["head"]),
        "source":(["rev-parse","--verify","HEAD:Source"],g["source"]),
        "branch":(["symbolic-ref","-q","HEAD"],g["branch"]),
        "status":(["status","--porcelain=v1","-z","--untracked-files=all","--ignore-submodules=none"],"")
    }
    commands={}
    for name,(args,value) in expected.items():
        out,record=run_readonly_git(args,physical_root)
        wanted=b"" if name=="status" else value.encode()+b"\n"
        require(out==wanted,"Pinned Git "+name+" mismatch: "+config["path"])
        record["value"]=value
        commands[name]=record
    physical=Path(physical_root).resolve(strict=True)
    for name,args,wanted in [
        ("gitDir",["rev-parse","--absolute-git-dir"],Path(g["gitDir"]) if g["kind"]=="linked" else physical/".git"),
        ("commonDir",["rev-parse","--path-format=absolute","--git-common-dir"],MIRROR if g["kind"]=="linked" else physical/".git"),
        ("top",["rev-parse","--show-toplevel"],physical)
    ]:
        out,record=run_readonly_git(args,physical_root)
        require(Path(out.decode().strip()).resolve(strict=True)==wanted.resolve(strict=True),
                "Normal Git path semantics changed: "+name)
        record["value"]=out.decode().strip()
        commands[name]=record
    after=git_admin_state(config)
    require(admin_equal(after,before),"Git observation changed protected administrative metadata")
    return {"kind":g["kind"],"label":label,"commands":commands,
            "dependencies":dependencies,"linkedAdmin":before,
            "gitMetadataWrites":0,"networkAndAuthOperations":0}

def admin_equal(a,b):
    if a is None or b is None:
        return a is b
    same_original(a["admin"],b["admin"])
    require(a["references"]==b["references"],"Protected Git reference/config identity changed")
    return True

def validate_plan():
    require(PLAN["schema"]=="otzaria.closed-workspace-relocation-plan/1","Plan schema mismatch")
    require(PLAN["rootDestination"]==str(DEST) and PLAN["rootFloor"]==ROOT_FLOOR,
            "Destination/floor differs from reviewed contract")
    require(PLAN["copiedAllocationCap"]==COPY_CAP and PLAN["phaseMetadataReserve"]==META_CAP and
            PLAN["deadlineSeconds"]==360,"Original budget/deadline changed")
    roots=[Path(c["path"]) for c in PLAN["scopes"]]
    expected_sources=[path for path in INPUTS["scopePaths"]
                      if path!="/mnt/development/projects/diagnostics/otzaria-wave3-rn-vendor-transition-20261127"]
    require([str(x) for x in roots]==expected_sources and len(roots)==len(set(roots))==9,
            "Closed nine-scope identity differs from the exact original-input exclusion")
    require(len({p.name for p in roots})==9,"Destination name collision")
    require(sum(c.get("git",{}).get("kind")=="linked" for c in PLAN["scopes"])==7 and
            sum(c.get("git",{}).get("kind")=="private" for c in PLAN["scopes"])==1 and
            sum("git" not in c for c in PLAN["scopes"])==1,"Git scope/type count changed")
    for p in roots:
        require(p.parent in (WORKTREE_PARENT,DIAGNOSTIC_PARENT),"Unadmitted source parent")
        for protected in PLAN["protected"]:
            q=Path(protected)
            require(not (p==q or p in q.parents or q in p.parents),"Protected scope overlap")
    require(DEST.parent==Path("/home/ubuntu") and DEST.name=="otzaria-wave3-closed-workspaces-nine-relocated-20261128",
            "Destination escapes exact new owner scope")
    return roots

def source_admission(config,rows):
    top=rows[0]
    for key,value in config["expectedTopIdentity"].items():
        require(top[key]==value,"Original top identity mismatch: "+key)
    require(len(rows)==config["observedEntries"],"Closed source entry count changed")
    require(sum(r["blocks"]*512 for r in rows)==config["observedAllocatedBytes"],
            "Closed source allocation changed")
    if "observedLogicalBytes" in config:
        require(sum(r["size"] for r in rows if r["type"]=="file")==config["observedLogicalBytes"],
                "Closed source logical size changed")
    by_path={r["path"]:r for r in rows}
    g=config.get("git")
    if g:
        row=by_path.get(".git")
        require(row is not None,"Top-level Git entry missing")
        if g["kind"]=="linked":
            require(row["type"]=="file" and row["size"]==g["pointerBytes"] and
                    row["sha256"]==g["pointerSHA256"],"Original Git pointer bytes changed")
        else:
            require(row["type"]=="directory","Private Git directory missing")
    else:
        require(".git" not in by_path,"Diagnostic unexpectedly became a Git root")
    for pin in config.get("receiptPins",[]):
        row=by_path.get(pin["path"])
        require(row is not None and row["type"]=="file" and row["size"]==pin["bytes"] and
                row["sha256"]==pin["sha256"],"Original evidence receipt mismatch")

def mutation_parent_identity(root):
    fd=absolute_directory(root.parent)
    try:
        s=os.fstat(fd)
        return {"device":s.st_dev,"inode":s.st_ino,"mode":s.st_mode,"uid":s.st_uid,"gid":s.st_gid}
    finally:
        os.close(fd)

def require_parent(fd,expected):
    s=os.fstat(fd)
    actual={"device":s.st_dev,"inode":s.st_ino,"mode":s.st_mode,
            "uid":s.st_uid,"gid":s.st_gid}
    require(actual==expected,"Original parent identity changed")

def external_admin_roots():
    return [Path(c["git"]["gitDir"]) for c in PLAN["scopes"]
            if c.get("git",{}).get("kind")=="linked"]

def create_destination():
    global METADATA_ADMITTED
    require(not os.path.lexists(DEST),"Preparation destination already exists; no automatic retry")
    parent=absolute_directory(DEST.parent)
    try:
        guard(32768)
        os.mkdir(DEST.name,0o755,dir_fd=parent)
        os.chown(DEST.name,1001,1001,dir_fd=parent,follow_symlinks=False)
        os.fsync(parent)
        fd=os.open(DEST.name,DFLAGS,dir_fd=parent)
        try:
            os.mkdir(META.name,0o700,dir_fd=fd)
            os.fsync(fd)
            METADATA_ADMITTED=True
            update_blocks("meta","destination-container",fd)
            mfd=os.open(META.name,DFLAGS,dir_fd=fd)
            try:
                os.fsync(mfd)
                update_blocks("meta",".",mfd)
            finally:
                os.close(mfd)
        finally:
            os.close(fd)
        os.fsync(parent)
    finally:
        os.close(parent)

def preserve_proposal_evidence():
    rows=[]
    total=0
    for base,dirs,files in os.walk(PROPOSAL,followlinks=False):
        for name in dirs:
            s=(Path(base)/name).lstat()
            require(stat.S_ISDIR(s.st_mode),"Linked proposal evidence directory refused")
        for name in sorted(files):
            path=Path(base)/name
            data,s=read_regular(path,8388608)
            total+=s.st_blocks*512
            require(total<=8388608,"Proposal evidence exceeds its own cap")
            stored=durable("EVIDENCE-%03d.raw"%len(rows),data)
            rows.append({"sourceRelative":path.relative_to(PROPOSAL).as_posix(),**stored,
                         "originalMode":s.st_mode,"originalUid":s.st_uid,"originalGid":s.st_gid,
                         "originalMtimeNs":s.st_mtime_ns})
    return durable("PROPOSAL_EVIDENCE.json",rows)

def record_existing_usage():
    COPY_BLOCKS.clear()
    META_BLOCKS.clear()
    for config in PLAN["scopes"]:
        root=DEST/Path(config["path"]).name
        if not root.exists():continue
        for base,dirs,files in os.walk(root,followlinks=False):
            for p in [Path(base)]+[Path(base)/n for n in files]:
                s=p.lstat()
                require(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode) or stat.S_ISLNK(s.st_mode),
                        "Unexpected destination member")
                COPY_BLOCKS[(config["id"],p.relative_to(root).as_posix())]=s.st_blocks*512
            require(not any((Path(base)/n).is_symlink() for n in dirs),"Unexpected destination directory link")
    for base,dirs,files in os.walk(META,followlinks=False):
        for p in [Path(base)]+[Path(base)/n for n in files]:
            s=p.lstat()
            require(stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode),"Unexpected phase metadata type")
            META_BLOCKS[p.relative_to(META).as_posix()]=s.st_blocks*512
        require(not any((Path(base)/n).is_symlink() for n in dirs),"Linked phase metadata directory")
    META_BLOCKS["destination-container"]=DEST.lstat().st_blocks*512
    guard()

def prepare():
    global CURRENT_SCOPE
    roots=validate_plan()
    guard(COPY_CAP)
    require(not os.path.lexists(DEST),"New destination is not absent")
    before={"rootFree":free("/"),"dataFree":free("/mnt/development"),"utc":utc()}
    initial_no_use=no_use(roots+external_admin_roots())
    all_rows=[]
    git_before=[]
    parents=[]
    for config,root in zip(PLAN["scopes"],roots):
        CURRENT_SCOPE=config["path"]
        rows=inventory(root,config)
        source_admission(config,rows)
        g=git_snapshot(config,root,"source-before-copy")
        fresh=inventory(root,config)
        same_original(fresh,rows)
        all_rows.append(rows)
        git_before.append(g)
        parents.append(mutation_parent_identity(root))
    allocated=sum(r["blocks"]*512 for rows in all_rows for r in rows)
    require(allocated==PLAN["observedAllocatedBytes"] and allocated<=COPY_CAP,
            "Original nine-scope allocation differs from plan")
    # Dense copy is bounded by source byte lengths; no sparse/hardlink assumption
    # is used to admit a write that might exceed the destination allocation cap.
    dense_bound=sum(((r["size"]+4095)//4096)*4096 if r["type"]=="file" else 16384
                    for rows in all_rows for r in rows)
    require(dense_bound<=COPY_CAP,"Dense-copy upper bound exceeds 512 MiB")
    guard(COPY_CAP)
    create_destination()
    durable("PLAN.json",PLAN_RAW)
    durable("CONTROLLER.py",SELF_RAW)
    evidence=preserve_proposal_evidence()
    durable("PREPARE_STARTED.json",{"utc":utc(),"before":before,"noUse":initial_no_use,
                                   "controllerSHA256":digest(SELF_RAW),"planSHA256":digest(PLAN_RAW),
                                   "inputSHA256":INPUT_SHA,"proposalEvidence":evidence})
    summaries=[]
    for index,(config,root,rows,g,pidentity) in enumerate(zip(PLAN["scopes"],roots,all_rows,git_before,parents)):
        CURRENT_SCOPE=config["path"]
        event("SCOPE_COPY_BEGIN",{"index":index,"source":str(root),"entries":len(rows)})
        target,copied=copy_scope(config,rows)
        target_git=git_snapshot(config,target,"copied-physical-root",g.get("linkedAdmin"))
        source_git=git_snapshot(config,root,"source-after-copy",g.get("linkedAdmin"))
        fresh=inventory(root,config)
        same_original(fresh,rows)
        copied_now=inventory(target,config)
        require(content_metadata(copied_now)==content_metadata(rows),"Copied content changed after Git observation")
        restore_times_and_sync(target,rows,config["id"])
        copied_final=inventory(target,config)
        require(content_metadata(copied_final,True)==content_metadata(rows,True),
                "Final copied bytes/metadata differ")
        # readlink may update a symlink access time; restore the captured times
        # after the last verification read, then flush before PREPARED.
        restore_times_and_sync(target,rows,config["id"])
        manifest={"schema":"otzaria.closed-workspace-copy-manifest/1",
                  "index":index,"configID":config["id"],"source":str(root),"destination":str(target),
                  "parentIdentity":pidentity,"original":rows,"copied":copied_final,
                  "gitBefore":g,"gitSourceAfter":source_git,"gitCopied":target_git}
        pin=durable("MANIFEST-%02d.json"%index,manifest)
        summaries.append({"index":index,"id":config["id"],"source":str(root),
                          "destination":str(target),"entries":len(rows),"manifest":pin})
        event("SCOPE_COPY_VERIFIED",summaries[-1])
    CURRENT_SCOPE=None
    final_no_use=no_use(roots+[DEST]+external_admin_roots())
    # Rejoin every original after the last scope was copied, not just its own copy.
    for config,root,rows,g in zip(PLAN["scopes"],roots,all_rows,git_before):
        same_original(inventory(root,config),rows)
        git_snapshot(config,root,"all-originals-final",g.get("linkedAdmin"))
    guard()
    receipt={"status":"FULL_COPY_GIT_AND_METADATA_VERIFIED_DATA_ORIGINS_UNCHANGED",
             "utc":utc(),"controllerSHA256":digest(SELF_RAW),"planSHA256":digest(PLAN_RAW),
             "inputSHA256":INPUT_SHA,"dependencyObservationSHA256":DEPENDENCIES_SHA,
             "scopes":summaries,"allocatedSourceBytes":allocated,
             "allocatedCopyBytes":sum(COPY_BLOCKS.values()),"metadataAllocatedBytes":sum(META_BLOCKS.values()),
             "before":before,"after":{"rootFree":free("/"),"dataFree":free("/mnt/development")},
             "beforeNoUse":initial_no_use,"afterNoUse":final_no_use,
             "sourcePathMutations":0,"gitWrites":0,"networkAuthOperations":0,
             "testRuns":0,"builds":0,"processSignals":0,
             "nextStep":"Root independently reviews this actual PREPARED hash before a separate cutover invocation"}
    pin=durable("PREPARED.json",receipt)
    print(json.dumps({"status":receipt["status"],"prepared":pin,"scopes":9,
                      "after":receipt["after"]}))

def verify_alias(root,target,expected):
    s=root.lstat()
    require(stat.S_ISLNK(s.st_mode) and os.readlink(root)==str(target),
            "Original alias was replaced")
    require((s.st_uid,s.st_gid)==(expected["uid"],expected["gid"]),"Alias owner mismatch")
    require(root.resolve(strict=True)==target and not target.is_symlink(),"Alias resolves elsewhere")

def remove_retired_tree(parent_fd,retired,rows):
    """Only exact preverified members, using directory FDs; never follows a link."""
    require(rows and rows[0]["path"]==".","Retirement manifest missing root")
    root_fd=os.open(retired,DFLAGS,dir_fd=parent_fd)
    expected_by_path={r["path"]:r for r in rows}
    children={}
    for row in rows[1:]:
        parent=str(PurePosixPath(row["path"]).parent)
        children.setdefault(parent,[]).append(row)
    def visit(fd,relative):
        row=expected_by_path[relative]
        require(stable(os.fstat(fd),row),"Retired directory changed before removal")
        with os.scandir(fd) as entries:
            actual_names=sorted(e.name for e in entries)
        expected=children.get(relative,[])
        require(actual_names==sorted(PurePosixPath(r["path"]).name for r in expected),
                "Retired directory membership changed")
        for child in expected:
            guard()
            leaf=PurePosixPath(child["path"]).name
            now=os.stat(leaf,dir_fd=fd,follow_symlinks=False)
            require(stable(now,child),"Retired member identity changed")
            if child["type"]=="directory":
                child_fd=os.open(leaf,DFLAGS,dir_fd=fd)
                try:
                    visit(child_fd,child["path"])
                    entry=os.stat(leaf,dir_fd=fd,follow_symlinks=False)
                    require((entry.st_dev,entry.st_ino)==(child["device"],child["inode"]),
                            "Retired child directory was replaced")
                    require(not list(os.scandir(child_fd)),"Retired directory gained a member")
                finally:
                    os.close(child_fd)
                os.rmdir(leaf,dir_fd=fd)
            elif child["type"]=="file":
                source_fd=os.open(leaf,RFLAGS,dir_fd=fd)
                try:
                    require(regular_hash(source_fd,child)==child["sha256"],
                            "Retired bytes changed immediately before unlink")
                    entry=os.stat(leaf,dir_fd=fd,follow_symlinks=False)
                    require(stable(entry,child),"Retired file replaced at unlink boundary")
                    os.unlink(leaf,dir_fd=fd)
                finally:
                    os.close(source_fd)
            else:
                require(os.readlink(leaf,dir_fd=fd)==child["target"],"Retired symlink changed")
                require(stable(os.stat(leaf,dir_fd=fd,follow_symlinks=False),child),
                        "Retired link replaced at unlink boundary")
                os.unlink(leaf,dir_fd=fd)
            os.fsync(fd)
        require(not list(os.scandir(fd)),"Retired directory is not empty")
        os.fsync(fd)
    try:
        visit(root_fd,".")
        entry=os.stat(retired,dir_fd=parent_fd,follow_symlinks=False)
        require((entry.st_dev,entry.st_ino)==(rows[0]["device"],rows[0]["inode"]),
                "Retired top replaced at final rmdir")
    finally:
        os.close(root_fd)
    os.rmdir(retired,dir_fd=parent_fd)
    os.fsync(parent_fd)

def rollback_before_delete(config,root,target,parent_fd,retired,manifest):
    """No overwrite and no reconstruction. Only the intact original can return."""
    observation=no_use([root,target,root.parent/retired]+external_admin_roots())
    rows=inventory(root.parent/retired,config)
    same_original(rows,manifest["original"],top_rename=True)
    s=os.stat(retired,dir_fd=parent_fd,follow_symlinks=False)
    expected=manifest["original"][0]
    require((s.st_dev,s.st_ino)==(expected["device"],expected["inode"]),
            "Rollback original identity unavailable")
    if os.path.lexists(root):
        verify_alias(root,target,expected)
        os.unlink(root.name,dir_fd=parent_fd)
        os.fsync(parent_fd)
    os.rename(retired,root.name,src_dir_fd=parent_fd,dst_dir_fd=parent_fd)
    os.fsync(parent_fd)
    require(not root.is_symlink() and root.lstat().st_ino==expected["inode"],
            "Rollback did not restore original directory")
    restored=inventory(root,config)
    same_original(restored,manifest["original"],top_rename=True)
    git_snapshot(config,root,"rollback-original",manifest["gitBefore"].get("linkedAdmin"))
    return {"status":"ORIGINAL_DIRECTORY_RESTORED_COPY_AND_EVIDENCE_RETAINED",
            "noUse":observation,"restoredOriginalInode":expected["inode"],
            "sourceTopCtimeException":"the owned rename/rollback changes only the root directory ctime"}

def cutover(expected_hash):
    global CURRENT_SCOPE,METADATA_ADMITTED
    roots=validate_plan()
    require(re.fullmatch(r"[0-9a-f]{64}",expected_hash) is not None,"Exact PREPARED SHA256 required")
    require(DEST.is_dir() and not DEST.is_symlink(),"Prepared destination unavailable")
    record_existing_usage()
    raw,_=read_regular(META/"PREPARED.json",META_CAP)
    require(digest(raw)==expected_hash,"PREPARED digest mismatch")
    prepared=json.loads(raw)
    require(prepared["status"]=="FULL_COPY_GIT_AND_METADATA_VERIFIED_DATA_ORIGINS_UNCHANGED" and
            prepared["controllerSHA256"]==digest(SELF_RAW) and
            prepared["planSHA256"]==digest(PLAN_RAW) and prepared["inputSHA256"]==INPUT_SHA and
            prepared["dependencyObservationSHA256"]==DEPENDENCIES_SHA,
            "Prepared source/controller/plan binding changed")
    require(len(prepared["scopes"])==9,"Prepared scope count changed")
    require(not os.path.lexists(META/"CUTOVER_STARTED.json") and
            not os.path.lexists(META/"CUTOVER_RESULT.json"),"Cutover already attempted; no automatic retry")
    stored,_=read_regular(META/"CONTROLLER.py",1048576)
    stored_plan,_=read_regular(META/"PLAN.json",1048576)
    require(stored==SELF_RAW and stored_plan==PLAN_RAW,"Preserved executable inputs differ")
    METADATA_ADMITTED=True
    before={"rootFree":free("/"),"dataFree":free("/mnt/development"),"utc":utc()}
    first_no_use=no_use(roots+[DEST]+external_admin_roots())
    manifests=[]
    for index,(config,scope) in enumerate(zip(PLAN["scopes"],prepared["scopes"])):
        CURRENT_SCOPE=config["path"]
        require(scope["index"]==index and scope["id"]==config["id"] and scope["source"]==config["path"],
                "Prepared scope order changed")
        require(scope["destination"]==str(DEST/Path(config["path"]).name),"Prepared target changed")
        b,_=read_regular(META/scope["manifest"]["file"],META_CAP)
        require(len(b)==scope["manifest"]["bytes"] and digest(b)==scope["manifest"]["sha256"],
                "Original manifest digest mismatch")
        m=json.loads(b)
        require(m["index"]==index and m["configID"]==config["id"] and
                m["source"]==config["path"] and m["destination"]==scope["destination"],
                "Manifest identity mismatch")
        root,target=Path(m["source"]),Path(m["destination"])
        require(not root.is_symlink(),"Original is no longer the directory prepared")
        same_original(inventory(root,config),m["original"])
        require(content_metadata(inventory(target,config))==content_metadata(m["original"]),
                "Verified destination changed")
        git_snapshot(config,root,"cutover-original",m["gitBefore"].get("linkedAdmin"))
        git_snapshot(config,target,"cutover-target",m["gitBefore"].get("linkedAdmin"))
        restore_times_and_sync(target,m["original"],config["id"])
        manifests.append(m)
    CURRENT_SCOPE=None
    no_use(roots+[DEST]+external_admin_roots())
    durable("CUTOVER_STARTED.json",{"utc":utc(),"preparedSHA256":expected_hash,
                                    "controllerSHA256":digest(SELF_RAW),"before":before,"noUse":first_no_use})
    moved=[]
    for index,(config,m) in enumerate(zip(PLAN["scopes"],manifests)):
        CURRENT_SCOPE=config["path"]
        guard()
        root,target=Path(m["source"]),Path(m["destination"])
        retired=root.name+".verified-relocation-20261128"
        parent_fd=absolute_directory(root.parent)
        renamed=False
        deletion_started=False
        try:
            require_parent(parent_fd,m["parentIdentity"])
            require(not os.path.lexists(root.parent/retired),"Retired name already exists")
            expected=m["original"][0]
            require(stable(os.stat(root.name,dir_fd=parent_fd,follow_symlinks=False),expected),
                    "Original top changed at cutover")
            fresh_use=no_use([root,target,root.parent/retired]+external_admin_roots())
            # No intermediate deadline/readiness callback is inserted between the
            # two fixed namespace operations. Failure enters the exact rollback.
            event("SCOPE_RENAME_INTENT",{"index":index,"source":str(root),"target":str(target),
                                        "retired":str(root.parent/retired),"noUse":fresh_use})
            os.rename(root.name,retired,src_dir_fd=parent_fd,dst_dir_fd=parent_fd)
            renamed=True
            try:
                os.symlink(str(target),root.name,dir_fd=parent_fd)
                os.chown(root.name,expected["uid"],expected["gid"],dir_fd=parent_fd,follow_symlinks=False)
                os.fsync(parent_fd)
            except BaseException:
                # The outer handler verifies the exact intact source before any
                # rollback and never removes a foreign replacement at root.name.
                raise
            verify_alias(root,target,expected)
            event("SCOPE_ALIAS_INSTALLED",{"index":index,"source":str(root),"destination":str(target)})
            retired_rows=inventory(root.parent/retired,config)
            same_original(retired_rows,m["original"],top_rename=True)
            require(content_metadata(inventory(target,config))==content_metadata(m["original"]),
                    "Destination changed before original retirement")
            alias_git=git_snapshot(config,root,"through-original-path-alias",m["gitBefore"].get("linkedAdmin"))
            restore_times_and_sync(target,m["original"],config["id"])
            readiness={"index":index,"source":str(root),"destination":str(target),
                       "retired":str(root.parent/retired),"preparedSHA256":expected_hash,
                       "aliasGit":alias_git,"copyFullyVerified":True}
            event("SCOPE_DELETE_READY",readiness)
            verify_alias(root,target,expected)
            require_parent(parent_fd,m["parentIdentity"])
            # Rejoin the destination after the final callback-bearing Git/no-use
            # work. The following delete reads only the exact retained source.
            require(content_metadata(inventory(target,config))==content_metadata(m["original"]),
                    "Destination changed at final delete boundary")
            restore_times_and_sync(target,m["original"],config["id"])
            latest_no_use=no_use([root,target,root.parent/retired]+external_admin_roots())
            verify_alias(root,target,expected)
            require_parent(parent_fd,m["parentIdentity"])
            event("SCOPE_DELETE_INTENT",{"index":index,"preparedSHA256":expected_hash,
                                        "noUse":latest_no_use,"retired":str(root.parent/retired)})
            deletion_started=True
            remove_retired_tree(parent_fd,retired,retired_rows)
            require(not os.path.lexists(root.parent/retired),"Retired directory still present")
            verify_alias(root,target,expected)
            after_git=git_snapshot(config,root,"alias-after-original-removal",m["gitBefore"].get("linkedAdmin"))
            require(content_metadata(inventory(target,config))==content_metadata(m["original"]),
                    "Final target bytes/metadata differ")
            restore_times_and_sync(target,m["original"],config["id"])
            result={"index":index,"source":str(root),"destination":str(target),
                    "originalAliasVerified":True,"retiredAbsent":True,"git":after_git}
            event("SCOPE_DONE",result)
            moved.append(result)
        except BaseException as error:
            failure={"index":index,"source":str(root),"destination":str(target),
                     "retired":str(root.parent/retired),"renamed":renamed,
                     "deletionStarted":deletion_started,"errorType":type(error).__name__,"error":str(error)[:8192]}
            if renamed and not deletion_started:
                try:
                    failure["rollback"]=rollback_before_delete(config,root,target,parent_fd,retired,m)
                except BaseException as rollback_error:
                    failure["rollback"]={"status":"NOT_COMPLETED_NO_OVERWRITE",
                                         "errorType":type(rollback_error).__name__,"error":str(rollback_error)[:4096]}
            elif deletion_started:
                failure["rollback"]={"status":"NOT_ATTEMPTED_PARTIAL_RETIREMENT_POSSIBLE",
                                     "reason":"Never restore a partially deleted original; complete verified target and original-path alias remain"}
            else:
                failure["rollback"]={"status":"NOT_NEEDED_ORIGINAL_NOT_RENAMED"}
            try:
                event("SCOPE_FAILED",failure,emergency=True)
            except BaseException as evidence_error:
                failure["failureReceiptError"]=repr(evidence_error)
                print(json.dumps({"status":"FAILURE_EVIDENCE_WRITE_REFUSED","detail":failure}),file=sys.stderr)
            raise
        finally:
            os.close(parent_fd)
    CURRENT_SCOPE=None
    final_no_use=no_use(roots+[DEST]+external_admin_roots())
    require(len(moved)==9,"Not all exact scopes completed")
    # Original paths, Git semantics and full bytes are checked once more before
    # a success receipt; no earlier event claims whole-operation completion.
    for config,m in zip(PLAN["scopes"],manifests):
        root,target=Path(m["source"]),Path(m["destination"])
        verify_alias(root,target,m["original"][0])
        require(not os.path.lexists(root.parent/(root.name+".verified-relocation-20261128")),
                "Retired path reappeared")
        git_snapshot(config,root,"all-aliases-final",m["gitBefore"].get("linkedAdmin"))
        require(content_metadata(inventory(target,config))==content_metadata(m["original"]),
                "Final preserved target differs")
        restore_times_and_sync(target,m["original"],config["id"])
    guard()
    receipt={"status":"EXACT_NINE_SCOPES_RELOCATED_ALL_ORIGINAL_ALIASES_AND_GIT_IDENTITIES_VERIFIED",
             "utc":utc(),"preparedSHA256":expected_hash,"controllerSHA256":digest(SELF_RAW),
             "planSHA256":digest(PLAN_RAW),"scopes":moved,
             "before":before,"after":{"rootFree":free("/"),"dataFree":free("/mnt/development")},
             "allocatedSourceBytes":prepared["allocatedSourceBytes"],
             "allocatedCopyBytes":sum(COPY_BLOCKS.values()),"metadataAllocatedBytes":sum(META_BLOCKS.values()),
             "finalNoUse":final_no_use,"uniqueEvidenceDeleted":0,"gitWrites":0,
             "networkAuthOperations":0,"builds":0,"testRuns":0,"processSignals":0,
             "freeSpaceLimit":"Concurrent filesystem measurements; no exclusive recovery attribution",
             "metadataLimit":"Original inode/device/ctime/allocation remain in manifests; cross-volume identities necessarily differ"}
    pin=durable("CUTOVER_RESULT.json",receipt)
    print(json.dumps({"status":receipt["status"],"result":pin,"scopes":9,"after":receipt["after"]}))

def main():
    global PLAN,INPUTS,DEPENDENCIES,DEADLINE,PHASE,SELF_RAW,PLAN_RAW,GIT_USER,GIT_GROUPS
    DEADLINE=time.monotonic()+DEADLINE_SECONDS
    require(os.geteuid()==0,"Root alone executes the reviewed preservation/cutover phases")
    GIT_USER=pwd.getpwnam("ubuntu")
    require((GIT_USER.pw_uid,GIT_USER.pw_gid)==(1001,1001),"Existing Git reader identity changed")
    GIT_GROUPS=os.getgrouplist("ubuntu",GIT_USER.pw_gid)
    require(Path(__file__).absolute()==PROPOSAL/"RELOCATE_CLOSED_WORKSPACES.py",
            "Execute the exact preserved proposal controller path")
    require(sys.argv[1:]==["prepare"] or
            (len(sys.argv)==3 and sys.argv[1]=="cutover"),"Use prepare, or cutover EXACT_PREPARED_SHA256")
    PHASE=sys.argv[1]
    SELF_RAW,_=read_regular(Path(__file__),1048576)
    PLAN_RAW,_=read_regular(PROPOSAL/"PLAN.json",1048576)
    require(digest(PLAN_RAW)==PLAN_SHA,"Reviewed plan digest mismatch")
    PLAN=json.loads(PLAN_RAW)
    raw,_=read_regular(PROPOSAL/"PROPOSAL_INPUTS.json",1048576)
    require(len(raw)==48350 and digest(raw)==INPUT_SHA,"Original input bytes changed")
    INPUTS=json.loads(raw)
    raw,_=read_regular(PROPOSAL/"GIT_DEPENDENCY_OBSERVATION.json",1048576)
    require(digest(raw)==DEPENDENCIES_SHA,"Bounded Git dependency observation changed")
    DEPENDENCIES=json.loads(raw)
    for name,size,sha in [
        ("PRIOR_CONTROLLER_FA0EA.py",15955,"fa0ea1728f77e0481c7098629d64c80efd75638b97a948398ef28f1a57f54d57"),
        ("PRIOR_PEER_REVIEW.json",1768,"26f04ffee6f7876321db96965149a1f351e2d957743d69464391f7a374c051ad")
    ]:
        raw,_=read_regular(PROPOSAL/name,1048576)
        require(len(raw)==size and digest(raw)==sha,"Prior preservation evidence changed")
    validate_plan()
    if PHASE=="prepare":
        prepare()
    else:
        cutover(sys.argv[2])

try:
    main()
except BaseException as error:
    detail={"status":"FAILED_NO_SUCCESS_RECEIPT","utc":utc(),"phase":PHASE,"scope":CURRENT_SCOPE,
            "errorType":type(error).__name__,"error":str(error)[:8192],
            "liveReadOnlyChild":LIVE_CHILD,"signalsSent":0,
            "instruction":"Preserve the exact partial copy, aliases, original/retired state and receipts; no automatic retry"}
    try:
        if METADATA_ADMITTED and META.is_dir() and not META.is_symlink() and PHASE is not None:
            event("PHASE_FAILED",detail,emergency=True)
    except BaseException as receipt_error:
        detail["failureReceiptError"]=repr(receipt_error)
    print(json.dumps(detail),file=sys.stderr)
    raise SystemExit(1)
