import Foundation
import OtzariaActionCore
import OtzariaUIRouting
import ChavrusaUIRoutingHost

struct LibraryControlFailure: Error { let message: String }
@MainActor func check(_ value: @autoclosure () throws -> Bool, _ message: String) throws {
    if try !value() { throw LibraryControlFailure(message: message) }
}
@MainActor func refusal(_ body: () throws -> Void) throws {
    do { try body(); throw LibraryControlFailure(message: "unexpected acceptance") }
    catch is LibraryControlFailure { throw LibraryControlFailure(message: "unexpected acceptance") }
    catch {}
}
@MainActor final class Fixture {
    let manager = iOSNavigationManager()
    let window = UIWindow()
    let root = MaktabahNativeRootPublicationSource()
    let tab = Cell(iOSTab.viewer), settings = Cell(false)
    let columns = Cell(NavigationSplitViewVisibility.all)
    let sidebar: ReaderSidebarPageCoordinator?
    let presentation = MaktabahNativeWorkspacePresentationBinding()
    let scene = UIStableID(rawValue: "original-scene")!
    let owner = UUID(), request = UUID()
    var originalWindow = true, blocked = false, common = true, foreground = true
    var validation: (() throws -> Void)?
    var callback: (() -> Void)?
    var workspace: Workspace!
    var projection: MaktabahNativeWorkspaceProjectionSource!
    var bindings: MaktabahNativeSceneBindings!
    var binding: MaktabahNativeLibrarySelectionBinding!
    var controller: iOSLibraryViewController!
    var originalRecord: NativeLibrarySelectionIntentService.Record!
    var readerOpens = 0
    let roots: [CategoryData]
    init(pad: Bool = false, roots: [CategoryData]? = nil, expanded: Bool = false) {
        self.roots = roots ?? [CategoryData(10, "Root", [CategoryData(20, "Branch", [BooksData(103, "Original Book")])])]
        sidebar = pad ? ReaderSidebarPageCoordinator() : nil
        MaktabahApp.isIpad = pad; UIView.animationHook = nil
        BackendCoordinator.shared.activeBackendID = .otzaria
        BackendCoordinator.shared.generation = 0; BackendCoordinator.shared.isTransitioning = false
        BackendCoordinator.shared.activeCapabilities = [.search,.authors]
        DonationManager.shared.showDonationSheet = false
        workspace = Workspace(manager); projection = .init(workspace)
        bindings = .init(manager: manager, selectedTab: root.selectionBinding(tab.binding), showSettings: root.settingsBinding(settings.binding),
            columnVisibility: columns.binding, sidebar: sidebar, rootPublications: root)
        binding = .init(sceneID: scene, bindings: bindings, workspaceSource: projection, workspacePresentation: presentation,
            commonReady: { [weak self] in self?.common == true }, windowReady: { [weak self] in self?.foreground == true && self?.originalWindow == true },
            originalLibrarySurfaceReady: { [weak self] in
                guard let self else { return false }
                return (try? originalProjection().surface(.library)) != nil
            }, retainWindow: { [weak self] in
                guard let self else { throw LibraryControlFailure(message: "fixture retired") }
                return MaktabahNativeWindowObservation(window: self.window) { [weak self] value in self?.originalWindow == true && value === self?.window }
            }, readForeignPresentations: {})
        binding.install(changed: { [weak self] in self?.callback?() }, invalidated: {})
        controller = iOSLibraryViewController(window: window); controller.viewModel = manager.libraryViewModel
        controller.onBookSelected = { [weak self] _ in self?.readerOpens += 1 }
        publish(self.roots)
        if expanded {
            for item in controller.dataSource.snapshot(for: 0).items { if case .category = item { controller.toggleCategory(item) } }
        }
        controller.nativeRoutingAttach(binding: binding, owner: owner, blocked: { [weak self] in self?.blocked != false })
    }
    func originalProjection() -> OriginalLibraryProjectionBoundary {
        .init(manager: manager, selectedTab: bindings.selectedTab.wrappedValue,
            columnVisibility: columns.value, settingsPresented: settings.value, sidebar: sidebar)
    }
    func publish(_ roots: [CategoryData]) {
        let model = manager.libraryViewModel
        model.displayedCategories = roots
        controller.applyCategories(roots, nativeSource: model.nativeRoutingPublication.categoriesStamp(roots))
    }
    func retain(kind: NativeLibrarySelectionIntentService.Kind = .book, title: String = "Original Book", index: Int = 0) throws {
        let records = try binding.catalog(.matching(title)).filter { $0.reference.kind == kind }
        guard records.indices.contains(index) else { throw LibraryControlFailure(message: "missing original row") }
        originalRecord = records[index]; try binding.retain(record: originalRecord, requestID: request)
    }
    func begin() throws { try binding.begin(requestID: request) { [weak self] in try self?.validation?() } }
    func apply() throws { try binding.apply(requestID: request) }
    func complete() throws {
        _ = try binding.withValidatedSurface(requestID: request) { true }
        binding.finish(requestID: request, completed: true); binding.releaseSource(requestID: request)
        try binding.validateCompletedSurface(requestID: request)
    }
}

@main struct LibraryOwnerControls {
    @MainActor static func main() async {
        var cases: [[String:Any]] = []
        func run(_ name: String, _ body: @MainActor () async throws -> Void) async {
            if let filter = ProcessInfo.processInfo.environment["LIBRARY_CONTROL_FILTER"], !name.contains(filter) { return }
            do { try await body(); cases.append(["name":name,"pass":true]) }
            catch { cases.append(["name":name,"pass":false,"error":String(describing:error)]) }
        }
        await run("book expands actual ancestors once and selects original cell without Reader delegate") {
            let f = Fixture(); try f.retain(); let applies = f.controller.dataSource.sectionApplies
            try f.begin(); try f.apply()
            try check(f.controller.dataSource.sectionApplies == applies + 2, "two real original category operations")
            try check(f.controller.collectionView.scrolls == 1 && f.controller.collectionView.selections == 1, "one scroll and selection")
            try check(f.readerOpens == 0 && f.manager.libraryViewModel.selectedBookIds.isEmpty, "ordinary tap and bulk selection untouched")
            try check(f.binding.observedItem(requestID:f.request) == f.originalRecord.itemID, "exact selected original cell")
            try f.complete()
            try check(try f.binding.catalog(.identifiers([f.originalRecord.id])) == [f.originalRecord], "same source metadata after successful release")
        }
        await run("category reveal expands original parent and category without a book action") {
            let f = Fixture(); try f.retain(kind:.category,title:"Branch"); let before = f.controller.dataSource.sectionApplies
            try f.begin(); try f.apply(); try f.complete()
            try check(f.controller.dataSource.sectionApplies == before + 2 && f.readerOpens == 0, "finite existing category path")
        }
        await run("already-expanded original path makes zero redundant category writes") {
            let f = Fixture(expanded:true); try f.retain(); let before = f.controller.dataSource.sectionApplies
            try f.begin(); try f.apply(); try f.complete()
            try check(f.controller.dataSource.sectionApplies == before, "no equal expansion publication")
        }
        await run("same leaf IDs and names in different original paths remain distinct occurrences") {
            let book = BooksData(103,"Original Book")
            let f = Fixture(roots:[CategoryData(10,"Root",[CategoryData(20,"Branch",[book]),CategoryData(20,"Branch",[book])])])
            let records = try f.binding.catalog(.matching("Original Book"))
            try check(records.count == 2 && records[0].id != records[1].id, "sibling occurrence qualified IDs")
            try f.retain(index:1); try f.begin(); try f.apply(); try f.complete()
            try check(f.binding.observedItem(requestID:f.request) == records[1].itemID, "retained exact second occurrence")
        }
        await run("foreign backend published book is never advertised as current") {
            let f = Fixture(roots:[CategoryData(1,"Root",[BooksData(103,"Foreign",locator:.init(backend:.sefaria,persistenceKey:"sefaria/work"))])])
            try check(try f.binding.catalog(.matching("Foreign")).isEmpty, "no backend identity inference")
        }
        await run("equal original category setter invalidates before snapshot replacement") {
            let f = Fixture(); try f.retain(); f.manager.libraryViewModel.displayedCategories = f.roots
            try refusal { try f.begin() }; try check(f.controller.collectionView.scrolls == 0, "no stale effect")
        }
        await run("same full path with a different original object cannot reuse cached source") {
            let f = Fixture(); try f.retain()
            f.publish([CategoryData(10,"Root",[CategoryData(20,"Branch",[BooksData(103,"Original Book")])])])
            try refusal { try f.begin() }
            try check(try f.binding.catalog(.identifiers([f.originalRecord.id])).isEmpty, "old reference never remapped")
        }
        await run("old snapshot completion preserves original sync but cannot qualify newer application") {
            let f = Fixture(); f.controller.dataSource.holdCompletions = true
            f.publish(f.roots); f.publish(f.roots)
            let callbacks = f.controller.dataSource.pendingCompletions
            try check(callbacks.count == 2 && !f.controller.nativeRoutingHasPublishedSource, "not ready before actual completion")
            let rootApplies = f.controller.dataSource.rootApplies
            callbacks[0]()
            try check(!f.controller.nativeRoutingHasPublishedSource && f.controller.dataSource.rootApplies == rootApplies + 1, "old original sync retained; no newer qualification")
            callbacks[1](); try check(f.controller.nativeRoutingHasPublishedSource, "only exact newer completion qualifies")
        }
        await run("actual search setter retires before unchanged visible fields and old cancellation cannot settle new query") {
            let f = Fixture(); try f.retain(); let model = f.manager.libraryViewModel
            model.searchQuery = "first"; model.searchQuery = "second"
            try check(model.nativeRoutingPublication.searchPending, "pre-result search owner is pending")
            try refusal { try f.begin() }
            try await Task.sleep(for:.milliseconds(380))
            try check(!model.nativeRoutingPublication.searchPending && model.searched == ["second"], "only original current Task settles/searches")
        }
        await run("equal original query publication retires even without a new Task") {
            let f = Fixture(); try f.retain(); f.manager.libraryViewModel.searchQuery = ""
            try refusal { try f.begin() }; try check(!f.manager.libraryViewModel.nativeRoutingPublication.searchPending, "original equal-write no-search behavior")
        }
        await run("source publication overflow remains exhausted and cannot be reset by later writes") {
            let p = MaktabahNativeLibraryListPublication(); let witness = try p.capture(); p.controlSeedOverflow(); p.categoriesWillPublish(); p.willPublish()
            try check(p.revision == nil && p.categoriesRevision == nil, "monotonic exhausted metadata")
            try refusal { try witness.validate() }; try refusal { _ = try p.capture() }
        }
        await run("ordinary original category toggle revokes pending navigation and preserves its action") {
            let f = Fixture(); try f.retain(); try f.begin(); let item = f.controller.dataSource.snapshot(for:0).items[0]
            let before = f.controller.dataSource.sectionApplies; f.controller.toggleCategory(item)
            try refusal { try f.apply() }
            try check(f.controller.dataSource.sectionApplies == before + 1 && f.controller.collectionView.scrolls == 0, "only ordinary original toggle")
        }
        await run("release during original diffable apply stops later scroll and selection") {
            let f = Fixture(); try f.retain(); try f.begin(); let before = f.controller.dataSource.sectionApplies
            f.controller.dataSource.onApply = { f.controller.dataSource.onApply = nil; f.binding.releaseSource(requestID:f.request) }
            try refusal { try f.apply() }
            try check(f.controller.dataSource.sectionApplies == before + 1 && f.controller.collectionView.scrolls == 0 && f.controller.collectionView.selections == 0, "one partial original expansion; no continuation")
        }
        await run("same request cannot recursively enter apply during original publication") {
            let f = Fixture(); try f.retain(); try f.begin(); var refused = false
            f.controller.dataSource.onApply = { f.controller.dataSource.onApply = nil; do { try f.apply() } catch { refused = true } }
            try f.apply(); try check(refused && f.controller.collectionView.selections == 1, "one consumed apply")
        }
        await run("source release from actual index getter prevents scroll before rejection") {
            let f = Fixture(expanded:true); try f.retain(); try f.begin()
            f.controller.dataSource.onIndex = { f.controller.dataSource.onIndex = nil; f.binding.releaseSource(requestID:f.request) }
            try refusal { try f.apply() }; try check(f.controller.collectionView.scrolls == 0 && f.controller.collectionView.selections == 0, "getter cannot authorize a stale scroll")
        }
        await run("source release from actual item getter prevents scroll before rejection") {
            let f = Fixture(expanded:true); try f.retain(); try f.begin()
            f.controller.dataSource.onItem = { f.controller.dataSource.onItem = nil; f.binding.releaseSource(requestID:f.request) }
            try refusal { try f.apply() }; try check(f.controller.collectionView.scrolls == 0 && f.controller.collectionView.selections == 0, "matching old item cannot authorize a stale scroll")
        }
        await run("source release from actual expanded getter prevents the next layout effect") {
            let f = Fixture(roots:[CategoryData(10,"Root",[BooksData(103,"Original Book")])]); try f.retain(); try f.begin()
            f.controller.dataSource.hooks.onIsExpanded = { _ in f.controller.dataSource.hooks.onIsExpanded = nil; f.binding.releaseSource(requestID:f.request) }
            try refusal { try f.apply() }; try check(f.controller.collectionView.layouts == 0 && f.controller.collectionView.scrolls == 0, "post-expansion getter is revalidated before layout")
        }
        await run("original configuration animation callback cannot write after retained release") {
            let f = Fixture(); try f.retain(); try f.begin()
            UIView.animationHook = { UIView.animationHook = nil; f.binding.releaseSource(requestID:f.request) }
            try refusal { try f.apply() }; try check(f.controller.collectionView.scrolls == 0, "no later navigation")
        }
        await run("wrong old controller detach cannot revoke the retained exact host") {
            let f = Fixture(); try f.retain(); try f.begin()
            f.binding.detach(controller:iOSLibraryViewController(window:f.window),owner:f.owner)
            try f.apply(); try f.complete()
        }
        await run("same controller detach and reattach cannot rearm old occurrence") {
            let f = Fixture(); try f.retain(); f.controller.nativeRoutingDetach()
            f.controller.nativeRoutingAttach(binding:f.binding,owner:f.owner,blocked:{ false })
            try refusal { try f.begin() }
            try check(try f.binding.catalog(.identifiers([f.originalRecord.id])).isEmpty, "replacement catalog has no old authority")
        }
        await run("source callback release during real report preserves effect but refuses completed proof") {
            let f = Fixture(); try f.retain(); try f.begin(); try f.apply(); var reported = false
            try refusal { _ = try f.binding.withValidatedSurface(requestID:f.request) { reported = true; f.binding.releaseSource(requestID:f.request); return true } }
            try check(reported && f.controller.collectionView.selections == 1, "actual report/effect observed without final success")
            try refusal { try f.binding.validateCompletedSurface(requestID:f.request) }
        }
        await run("selected clipped original cell is not visible acceptance") {
            let f = Fixture(); try f.retain(); try f.begin(); try f.apply()
            let cell = f.controller.collectionView.cells[f.controller.collectionView.indexPathsForSelectedItems![0]]!
            cell.clipped = CGRect(x:0,y:0,width:20,height:100)
            try check(!f.binding.hasVisibleSurface(requestID:f.request), "actual clipped-geometry boundary")
        }
        await run("selected original cell covered by another real hit target cannot acknowledge") {
            let f = Fixture(); try f.retain(); try f.begin(); try f.apply(); f.window.hit = UIView(f.window)
            try check(!f.binding.hasVisibleSurface(requestID:f.request), "same-window hit test must reach exact cell")
        }
        await run("parent only cannot satisfy exact original row route") {
            let f = Fixture(); try f.retain(); try f.begin()
            try check(!f.binding.hasVisibleSurface(requestID:f.request), "no selection marker before apply")
        }
        await run("backend ABA reaches original publication latch before any resumed effect") {
            let f = Fixture(); try f.retain(); BackendCoordinator.shared.activeBackendID = .sefaria; BackendCoordinator.shared.activeBackendID = .otzaria
            try refusal { try f.begin() }
        }
        await run("actual original root binding ABA cannot preserve a library reservation") {
            let f = Fixture(); try f.retain(); let original = f.root.selectionBinding(f.tab.binding)
            original.wrappedValue = .search; original.wrappedValue = .viewer
            try refusal { try f.begin() }
        }
        await run("actual Settings publication ABA cannot be hidden by final false value") {
            let f = Fixture(); try f.retain(); let original = f.root.settingsBinding(f.settings.binding)
            original.wrappedValue = true; original.wrappedValue = false
            try refusal { try f.begin() }
        }
        await run("iPad original Library sidebar remains available with retained active Reader") {
            let f = Fixture(pad:true); let book = BooksData(900,"Open Reader")
            f.manager.selectedBook = book; f.manager.activeTabId = UUID(); f.manager.openTabs = [f.manager.activeTabId!]
            f.manager.activeReaderViewModel = ReaderViewModel(); f.manager.activeReaderViewModel?.currentBook = book
            try check(f.binding.isAvailable, "actual original Viewer/Sidebar/columns predicate")
            try f.retain(); try f.begin(); try f.apply(); try f.complete()
            try check(f.manager.selectedBook === book && f.readerOpens == 0, "existing iPad Reader is preserved")
        }
        await run("phone hidden retained Reader permits original Library NavigationStack root") {
            let f = Fixture(); f.manager.activeTabId = UUID(); f.manager.openTabs = [f.manager.activeTabId!]
            f.manager.activeReaderViewModel = ReaderViewModel(); f.manager.activeReaderViewModel?.currentBook = BooksData(900,"Hidden Reader")
            try check(f.manager.selectedBook == nil && f.binding.isAvailable, "actual compact Library root")
            try f.retain(); try f.begin(); try f.apply(); try f.complete()
        }
        await run("phone pushed Reader cannot be replaced by an attached hidden Library controller") {
            let f = Fixture(); f.manager.selectedBook = BooksData(900,"Pushed Reader")
            try check(!f.binding.isAvailable && (try f.binding.catalog(.suggested)).isEmpty, "no parent proxy for a hidden root")
        }
        await run("iPad original contents page and hidden columns remain unavailable") {
            let f = Fixture(pad:true); f.sidebar?.page = .contents
            try check(!f.binding.isAvailable, "actual contents page")
            f.sidebar?.page = .library; f.columns.value = .detailOnly
            try check(!f.binding.isAvailable, "actual library column absent")
        }
        await run("unmounted unloaded original collection cannot publish entities") {
            let f = Fixture(); f.controller.isViewLoaded = false
            try check(!f.binding.isAvailable && (try f.binding.catalog(.suggested)).isEmpty, "warm original collection required")
        }
        await run("original database notification retires captured published metadata") {
            let f = Fixture(); try f.retain(); NotificationBoundary.publisher(.booksChanged).send()
            try refusal { try f.begin() }
        }
        await run("original window identity loss before apply cannot produce any row effect") {
            let f = Fixture(); try f.retain(); try f.begin(); f.originalWindow = false
            try refusal { try f.apply() }; try check(f.controller.collectionView.scrolls == 0, "exact original window required")
        }
        await run("original snapshot cycle guard remains unavailable rather than manufacturing rows") {
            let cycle = CategoryData(10,"cycle"); cycle.children = [cycle]
            let f = Fixture(roots:[cycle])
            try check(f.controller.lastSnapshotError != nil && !f.binding.isAvailable, "original unsafe catalog refusal")
        }
        let report: [String:Any] = ["boundary":"Actual publication + original model setters/task + original full snapshot/expansion/reveal/controller chain + full Library binding and original app enums/Library projection branch; explicit UI/diffable/domain/Combine/Workspace owners. No Core/native execution or UIKit rendering.","passed":cases.filter{$0["pass"]as?Bool==true}.count,"failed":cases.filter{$0["pass"]as?Bool==false}.count,"cases":cases]
        print(String(decoding:try!JSONSerialization.data(withJSONObject:report,options:[.sortedKeys,.prettyPrinted]),as:UTF8.self))
        if report["failed"]as?Int != 0 { exit(1) }
    }
}
