import os,stat,json,hashlib,subprocess,tarfile,io
from pathlib import Path
ROOT=Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
REF='6878075d67afb7bb5e58ebf90c9a6a6aeeacd27d'
JOIN=Path('/mnt/development/projects/diagnostics/otzaria-wave3-hidden-group-current-bindings-20261127/CURRENT_MODULE_SOURCE_JOIN.json')
PRIOR=Path('/mnt/development/projects/worktrees/Maktabah-wave3-library-selection-20261127/build/library-selection-controls-20261127/service-attempt-2')
ROOTS=['Source/Otzaria/Actions/Sources/OtzariaActionCore','Source/Otzaria/UIRouting/Sources/OtzariaUIRouting','Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost']
def read(p,limit):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  s=os.fstat(fd)
  if not stat.S_ISREG(s.st_mode) or s.st_size>limit:raise RuntimeError('file bounds '+str(p))
  b=b''
  while len(b)<s.st_size:
   x=os.read(fd,min(65536,s.st_size-len(b)))
   if not x:raise RuntimeError('short')
   b+=x
  t=os.fstat(fd)
  if (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)!=(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_ctime_ns):raise RuntimeError('changed '+str(p))
  return b
 finally:os.close(fd)
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
jb=read(JOIN,65536);assert pin(jb)['sha256']=='7768e4896eb3fc6fb2ff2256a820bc03c315b9c512936948c6346164b7a4efef';j=json.loads(jb)
sb=read(PRIOR/'RESULT.json',65536);assert pin(sb)['sha256']=='cbe68cc70ce9ee48130a4eed0347b486ed0cbba5aaffa39ce0ca3c49644d5865';s=json.loads(sb)
argv=['git','--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT)]
ids=subprocess.run(argv+['rev-parse','HEAD','HEAD:Source']+[REF+':'+p for p in ROOTS]+['HEAD:'+p for p in ROOTS],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,check=True)
lines=ids.stdout.decode().splitlines();assert len(lines)==8 and lines[2:5]==lines[5:8],lines
a=subprocess.run(argv+['archive','--format=tar',REF]+ROOTS,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=True)
assert len(a.stdout)<2*1024*1024
files={}
with tarfile.open(fileobj=io.BytesIO(a.stdout),mode='r:') as t:
 for m in t:
  if m.isdir():continue
  if not m.isfile() or m.name in files or not m.name.endswith('.swift'):raise RuntimeError('unexpected member '+m.name)
  files[m.name]=t.extractfile(m).read()
assert len(files)==87
rows=[]
for r in j['files']:
 b=read(r['compiled_input'],1048576)
 assert pin(b)=={k:r[k] for k in ['bytes','sha256']} and files[r['path']]==b,r['path']
 rows.append({'path':r['path'],'module':r['module'],'compiled_input':r['compiled_input'],**pin(b)})
extras={
 ROOTS[2]+'/NativeAnnotationEditorIntentService.swift':{'bytes':7406,'sha256':'c787c10eb0e8daa691cac85aca316a72b5d0f9cfb1d329b1da25490d57ac4f64'},
 ROOTS[2]+'/NativeAnnotationEditorIntents.swift':{'bytes':1147,'sha256':'d11e94c3bac2fcf26af5c8b008683d919cf1551c88b074865caf383387168970'}}
assert set(files)=={x['path'] for x in rows}|set(extras)
for p,want in extras.items():assert pin(files[p])==want
host=[]
for r in s['host43Inputs']:
 b=read(PRIOR/'inputs'/r['path'],1048576);assert pin(b)=={k:r[k] for k in ['bytes','sha256']}
 if r['path'].startswith('original/'):assert b==files[r['path'][len('original/'):]]
 else:assert r['path'].startswith('candidate/') and r['path'].split('/')[-1] in ['NativeLibrarySelectionIntentService.swift','NativeLibrarySelectionIntents.swift']
 host.append({'path':r['path'],**pin(b)})
assert len(host)==43
products=[]
for r in j['products']:
 b=read(r['path'],12582912);assert pin(b)=={k:r[k] for k in ['bytes','sha256']};products.append({'path':r['path'],**pin(b)})
for name,digest in [('ChavrusaUIRoutingHost.swiftmodule','ae6fd363ed35e1b36b9bbaec8a0db73f3f46774a19e0dd630b986962017ca800'),('libChavrusaUIRoutingHost.so','a1b27bf1493d8ccc8f372a7919c2e25ffd498b7c6ce4058d5e844a0eaf4f63d8')]:
 p=PRIOR/'output'/name;b=read(p,12582912);assert pin(b)['sha256']==digest;products.append({'path':str(p),**pin(b)})
print(json.dumps({'status':'READ_ONLY_SOURCE_DEPENDENCIES_MATCH','head':lines[0],'source':lines[1],'reference':REF,'treeIDs':dict(zip(ROOTS,lines[2:5])),'sourceArchive':pin(a.stdout),'counts':j['counts'],'rejoinedCompiledSources':rows,'currentRootAnnotationOnlySources':extras,'privateLibraryHost43CompiledInputs':host,'products':products,'serviceReceipt':{'path':str(PRIOR/'RESULT.json'),**pin(sb),'aggregateStatus':s['status'],'reusedServicePassed':s['service']['passed'],'reusedServiceFailed':s['service']['failed']},'compilerRuns':0,'controllerImports':0,'fileWrites':0}))