# Library35 executable source continuation

This is a new source-only continuation of the exact original 33d2cce7 runner, with a complete inverse. It is not an executed acceptance result.

The unchanged packed runner contains all 43 exact input files, including the actor-correct Library publication (3bcb93f7), the original 35 Swift case bodies, three preserved getter counterexamples, and the original wrong-enum compile refusal. The recovery ZIP contains the original packed runner and the extracted actor; it does not contain 43 separate input members.

The new runner rejects inherited LIBRARY_CONTROL_FILTER before output allocation, then requires the exact 35 names, passed=35, failed=0 and strict true case results. The original include/link/rpath sequence and bounded child runner remain unchanged. The source packet itself is charged to both existing runtime allocation budgets.

It re-joins the original 85 module source inputs, seven original resources, the two current Root Annotation-only source files, and the private Library Host43's actual 43 compiled inputs. Current Root Host43 (Host41 + Annotation2) is explicitly distinct from reused private Library Host43 (Host41 + Library2). No healthy service or module is rebuilt.

## Future command, after Root execution admission

```sh
sudo -n -u ubuntu python3 -B /home/ubuntu/otzaria-wave3-library35-executable-source-continuation-20261128/run_library35.py
```

The original output path remains /home/ubuntu/otzaria-wave3-library-controls-rootfs-20261127/owner-attempt-3 and must be absent. The original runner will refuse if it already exists. The original Data 2 GiB and rootfs 1.25 GiB runtime floors, startup margins, 80 MiB combined library limit and 300 MiB lane limit remain unchanged. Root applies current execution admission in addition. Source staging used the separately authorized 1,593,835,520 B floor plus 8 MiB reserve. No compiler/test/controller import or Mac/API action occurred while preparing this packet.

The actual read-only dependency observation is stored separately. Its first attempted archive inspection incorrectly assumed that all module members were Swift and refused at the first original resource; that read-only failure is preserved. The corrected source inspection records all seven resource files explicitly and joins all sources/products. It does not execute the proposed runtime checks.

UIKit, app SDK, Intent metadata, native rendering and production acceptance remain NOT_RUN. The healthy service receipt is preserved with its original aggregate FAILED status; its 19 positive service cases and Host43 compilation are the bounded reusable evidence.
