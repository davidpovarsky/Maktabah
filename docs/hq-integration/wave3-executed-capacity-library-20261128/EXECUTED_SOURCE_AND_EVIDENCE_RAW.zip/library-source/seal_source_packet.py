if not __debug__:raise RuntimeError('Optimized Python forbidden')
import os,stat,json,hashlib,io,zipfile,datetime
from pathlib import Path
S=Path("/home/ubuntu/otzaria-wave3-library35-executable-source-continuation-20261128");CAP=8388608;FLOOR=1593835520
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
 try:
  a=os.fstat(fd)
  if not stat.S_ISREG(a.st_mode)or a.st_nlink!=1 or a.st_size>CAP:raise RuntimeError('file type/bounds')
  b=b''
  while len(b)<a.st_size:
   x=os.read(fd,min(65536,a.st_size-len(b)))
   if not x:raise RuntimeError('short read')
   b+=x
  z=os.fstat(fd)
  if (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)!=(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns):raise RuntimeError('file changed')
  return b,a
 finally:os.close(fd)
def members():
 files=[];total=S.lstat().st_blocks*512
 for p in S.rglob('*'):
  s=p.lstat();total+=s.st_blocks*512
  if stat.S_ISDIR(s.st_mode):continue
  if not stat.S_ISREG(s.st_mode)or s.st_nlink!=1:raise RuntimeError('unknown type')
  b,t=read(p)
  files.append({'path':str(p.relative_to(S)),'bytes':len(b),'sha256':sha(b),'mode':stat.S_IMODE(t.st_mode),'uid':t.st_uid,'gid':t.st_gid,'mtime_ns':t.st_mtime_ns,'ctime_ns':t.st_ctime_ns,'dev':t.st_dev,'ino':t.st_ino})
 return sorted(files,key=lambda r:r['path']),total
def guard(extra=0):
 s=os.statvfs('/home/ubuntu');free=s.f_bavail*s.f_frsize
 rows,alloc=members()
 if free<FLOOR+CAP or alloc+extra>CAP:raise RuntimeError('source floor/cap')
 return free
def put(name,b):
 if isinstance(b,str):b=b.encode()
 guard(len(b)+16384)
 fd=os.open(S/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o640)
 try:
  v=memoryview(b)
  while v:
   n=os.write(fd,v)
   if n<=0:raise RuntimeError('short write')
   v=v[n:]
  os.fsync(fd)
 finally:os.close(fd)
 actual,t=read(S/name)
 if actual!=b:raise RuntimeError('readback')
 return {'path':name,'bytes':len(b),'sha256':sha(b)}
def dump(x):return json.dumps(x,indent=2,sort_keys=True)+'\n'
rows,alloc=members()
expected=['prior/source-owner-attempt-3-runner.py','run_library35.py','RUNNER_EDITS.json','RUNNER.patch','INVERSE_PROOF.json','EMBEDDED_INPUTS_MANIFEST.json','review/LibraryOwnerControls.swift','review/MaktabahNativeLibraryListPublication.swift','prior/CURRENT_MODULE_SOURCE_JOIN.json','prior/SERVICE_ATTEMPT2_RESULT.json','prior/public-search-portable-runner-attempt-2.py','prior/ORIGINAL_CAPACITY_REFUSAL.json','PLAN.json','README.md','MATERIALIZATION.json','evidence/READ_ONLY_SOURCE_JOIN.json','evidence/INITIAL_RESOURCE_ENUMERATION_REFUSAL.json','evidence/read_source_dependencies_initial.py','evidence/read_source_dependencies_corrected.py','evidence/READ_ONLY_SOURCE_JOIN_TRANSPORT.json','prepare_source_packet.py','seal_source_packet.py']
if {r['path'] for r in rows}!=set(expected):raise RuntimeError('exact unsealed membership')
old=read(S/'prior/source-owner-attempt-3-runner.py')[0]
new=read(S/'run_library35.py')[0]
if sha(old)!='33d2cce7a824beae5b3568e50a1aaa61aa993abfd635a798fb97ee4a1b18d983' or sha(new)!='ed40968e88c43d5633b2820a47d755e0d48030d5c745b53eee0c5e011f7488a5':raise RuntimeError('runner pins')
edits=json.loads(read(S/'RUNNER_EDITS.json')[0])['edits']
inverse=new.decode()
for edit in reversed(edits):
 if inverse.count(edit['new'])!=1:raise RuntimeError('inverse ambiguity')
 inverse=inverse.replace(edit['new'],edit['old'],1)
if inverse.encode()!=old:raise RuntimeError('inverse differs')
original_path='/home/ubuntu/otzaria-wave3-library-controls-rootfs-20261127/controller-owner-attempt-3/source-owner-attempt-3-runner.py'
if read(Path(original_path))[0]!=old:raise RuntimeError('original runner changed')
if Path('/home/ubuntu/otzaria-wave3-library-controls-rootfs-20261127/owner-attempt-3').exists():raise RuntimeError('original output path no longer absent')
observation=json.loads(read(S/'evidence/READ_ONLY_SOURCE_JOIN.json')[0])
if observation['status']!='READ_ONLY_SOURCE_DEPENDENCIES_MATCH' or len(observation['rejoinedCompiledSources'])!=85 or len(observation['privateLibraryHost43CompiledInputs'])!=43 or len(observation['products'])!=8:raise RuntimeError('source observation shape')
result=put('RESULT.json',dump({'schema':'otzaria.library35.executable-source-continuation.result.v1','status':'SEALED_SOURCE_ONLY_NOT_RUN','scope':str(S),'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFilesBeforeClosure':len(rows),'originalRunner':{'path':original_path,'bytes':len(old),'sha256':sha(old)},'candidateRunner':{'path':'run_library35.py','bytes':len(new),'sha256':sha(new)},'wholeInverseExact':True,'edits':len(edits),'unchangedEmbeddedInputs':43,'unchangedOriginalPositiveCases':35,'unchangedGetterNegativeCases':3,'unchangedOriginalEnumCompileRefusal':True,'actualReadonlyModuleSourceJoins':85,'actualReadonlyPrivateLibraryHostCompiledInputs':43,'actualReadonlyModuleProducts':8,'actualReadonlyResourceFiles':7,'currentRootAnnotationOnlyFiles':2,'sourceReference':'6878075d67afb7bb5e58ebf90c9a6a6aeeacd27d','sourceObservedHead':observation['head'],'sourceObservedTree':observation['source'],'exactDocumentationHeadRequired':False,'exactModuleSourceTreesRequired':True,'originalOutputPathAbsent':True,'futureCLI':'sudo -n -u ubuntu python3 -B '+str(S/'run_library35.py'),'actualExecutionAuthorized':False,'controllerImports':0,'compilerRuns':0,'testRuns':0,'healthySuiteReruns':0,'moduleRebuilds':0,'dataWrites':0,'apiWrites':0,'nativeRuns':0,'AppleSDK':'NOT_RUN','preservedInitialReadOnlyFailure':'evidence/INITIAL_RESOURCE_ENUMERATION_REFUSAL.json','initialReadOnlyFailureCause':'Archive inspection assumed Swift-only membership; exact original resource was encountered. Corrected read records all seven original resources. This was not a test/compile failure.','pendingGate':'Root execution admission and original fresh runtime capacity gates; no acceptance result from source preparation.'}))
payload,_=members()
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in payload:
  body,_=read(S/row['path'])
  info=zipfile.ZipInfo(row['path'],(2026,11,28,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|row['mode'])<<16;info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,body)
archive=put('SOURCE_PACKET_RAW.zip',buffer.getvalue())
with zipfile.ZipFile(io.BytesIO(read(S/'SOURCE_PACKET_RAW.zip')[0]),'r') as z:
 if z.namelist()!=[r['path'] for r in payload]:raise RuntimeError('archive membership')
 for row in payload:
  b=z.read(row['path'])
  if len(b)!=row['bytes']or sha(b)!=row['sha256']:raise RuntimeError('archive byte mismatch')
rows,_=members()
manifest=put('MANIFEST.json',dump({'schema':'otzaria.closed-source-packet.manifest.v1','status':'SOURCE_ONLY_NOT_RUN','files':rows,'count':len(rows),'excludedSelfAndSeal':['MANIFEST.json','SOURCE_SEAL.json'],'archive':archive,'archiveMembers':len(payload),'fullArchiveReadback':True,'originalInputsUnmodified':True}))
seal=put('SOURCE_SEAL.json',dump({'schema':'otzaria.closed-source-packet.seal.v1','status':'SEALED_SOURCE_ONLY_NOT_RUN','manifest':manifest,'result':result,'archive':archive,'archiveMembers':len(payload),'fullDecodedReadback':True,'exactFileNames':sorted([r['path']for r in rows]+['MANIFEST.json','SOURCE_SEAL.json']),'originalRunnerSHA256':sha(old),'runnerSHA256':sha(new),'compilerRuns':0,'testRuns':0,'nativeRuns':0,'scopeCapBytes':CAP,'sourceStagingRootFloorBytes':FLOOR,'sourceStagingRootReserveBytes':CAP}))
final,allocated=members()
if len(final)!=len(rows)+2 or {r['path']for r in final}!={r['path']for r in rows}|{'MANIFEST.json','SOURCE_SEAL.json'}:raise RuntimeError('final membership')
for r in rows:
 p=next(x for x in final if x['path']==r['path'])
 if p!=r:raise RuntimeError('final metadata changed '+r['path'])
print(json.dumps({'status':'SEALED_SOURCE_ONLY_NOT_RUN','scope':str(S),'files':len(final),'allocatedBytes':allocated,'rootFreeAfter':guard(),'runner':{'bytes':len(new),'sha256':sha(new)},'manifest':manifest,'result':result,'archive':archive,'seal':seal,'wholeInverseExact':True,'testRuns':0,'compilerRuns':0}))
