import gzip,hashlib,io,json,pathlib,re,shutil,subprocess,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='d1d66b043897f2e86288d748a5034da56d79e404'
OLD_CALLER_BASE='37caafcfaa4eb9b7bcfd02857bcb7c3f62daa4be'
PARENT='fd1407823dc346ea800cfba20523b56b98de8f08'
COMMITS=['56a6ff0c4d9437924479444660b51ce62e59db7e','2914be3e5ad4c2d857a962d526b5e2c6ec8dde32','7f8223232a82b25502090617860459674cc49f2a','d2a9d19fdecd57636cbb3896b2e96f33c1a72acd','748d67b95e7253a649d99cb12b84880b4f9fa54b']
DONOR='/home/ubuntu/otzaria-wave3-annotation-current-bindings-published-20261127/source'
BRANCH='codex/otzaria-wave3-integration-20261127'
PRODUCT='Source/Features/Annotations/iOS/iOSAnnotationViewController.swift'
FOLDERS=['docs/hq-ui-inventory/wave3-annotation-expansion-20261127','docs/hq-ui-inventory/wave3-annotation-expansion-caller-20261127','docs/hq-ui-inventory/wave3-annotation-current-bindings-20261127']
PROOF='docs/hq-integration/wave3-annotation-expansion-intake-20261127'
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def apply(text,edits,before,after):
 for e in edits:assert text.count(e[before])==1;text=text.replace(e[before],e[after],1)
 return text
def capacity():assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,COMMITS[-1])
 for p,c in zip([PARENT]+COMMITS,COMMITS):assert rev(c+'^')==p
 assert show(BASE,PRODUCT)==show(PARENT,PRODUCT)
 manifests=[];rawCounts=[];inputCounts=[]
 for commit,folder,count,digest,rawCount in [(COMMITS[1],FOLDERS[0],29,'75c78c28fe41862358a8d1e690214b52f55a499e1cac4fdd7c31421cd7141e09',13),(COMMITS[3],FOLDERS[1],47,'c292a58a28e9446ada2d58e12cf04c16b990362d54cde67520ce55321e576b48',18),(COMMITS[4],FOLDERS[2],50,'31a2d6ef60a5830dd4985e67a6ec0cc53808cacec9e7e48b1f64825a90aabed9',47)]:
  index=show(commit,folder+'/MANIFEST.json');assert sha(index)==digest;rows=json.loads(index)['files'];assert len(rows)==count
  paths=git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()
  assert set(paths)=={folder+'/'+r['path']for r in rows}|{folder+'/MANIFEST.json'}
  for row in rows:pin(show(commit,folder+'/'+row['path']),row)
  rawRows=json.loads(show(commit,folder+'/evidence/raw/RAW_MANIFEST.json'));assert len(rawRows)==rawCount
  for row in rawRows:pin(show(commit,folder+'/evidence/raw/'+row['path']),row)
  with zipfile.ZipFile(io.BytesIO(show(commit,folder+'/evidence/RAW.zip')))as z:
   assert set(z.namelist())=={r['path']for r in rawRows}|{'RAW_MANIFEST.json'}
   for row in rawRows:pin(z.read(row['path']),row)
   assert z.read('RAW_MANIFEST.json')==show(commit,folder+'/evidence/raw/RAW_MANIFEST.json')
  inputs=json.loads(show(commit,folder+'/inputs/INPUTS.json')) if folder!=FOLDERS[2] else []
  for row in inputs:pin(show(commit,folder+'/inputs/'+row['path']),row)
  inputCounts.append(len(inputs));rawCounts.append(rawCount);manifests.append({'commit':commit,'path':folder+'/MANIFEST.json','rows':count,'sha256':digest})
 for commit in [COMMITS[0],COMMITS[2]]:
  assert git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()==[PRODUCT]
  git('diff','--check',commit+'^',commit)
 first=json.loads(show(COMMITS[1],FOLDERS[0]+'/SOURCE_INVERSE.json'))
 second=json.loads(show(COMMITS[3],FOLDERS[1]+'/SOURCE_INVERSE.json'))
 assert first['path']==second['path']==PRODUCT and len(first['edits'])==2
 old=show(BASE,PRODUCT);middle=show(COMMITS[0],PRODUCT);new=show(COMMITS[2],PRODUCT)
 assert sha(old)==first['before_sha256']=='bf7bc1ea1bb559e02a7904dad3508fab1c265ecd07e1592365cab045aecbc714'
 assert sha(middle)==first['after_sha256']==second['before_sha256']=='e38eafa86b8aebdf34166da0d9fe3b182ac44fdcdf5c2549fea8f0d9026a14cd'
 assert sha(new)==second['after_sha256']=='a6577cf5d2060b3849ab06634c9e52915e9048260feda7814c02cf926965bd1c'
 assert apply(old.decode(),first['edits'],'before','after').encode()==middle
 assert apply(middle.decode(),list(reversed(first['edits'])),'after','before').encode()==old
 assert apply(middle.decode(),[second],'before','after').encode()==new
 assert apply(new.decode(),[second],'after','before').encode()==middle
 helperRaw=show(COMMITS[1],FOLDERS[0]+'/evidence/raw/RESULT.json');assert sha(helperRaw)=='1e23d72f21802c9a12e2b35d07586dec71c70cdec420e6e157e8e67f3e8e73f0'
 helper=json.loads(helperRaw);assert helper['baseline']=={'passed':3,'failed':8}and helper['candidate']=={'passed':11,'failed':0}
 for label,counts in [('OriginalExpansion',(3,8)),('CandidateExpansion',(11,0))]:
  r=json.loads(show(COMMITS[1],FOLDERS[0]+'/evidence/raw/'+label+'-controls.stdout'));assert(r['passed'],r['failed'])==counts
 callerPath=FOLDERS[1]+'/evidence/raw/caller-followup-attempt-2/'
 callerRaw=show(COMMITS[3],callerPath+'RESULT.json');assert sha(callerRaw)=='63415a94517b961fea07adc7688dc68a21a1d29b548feaf3f8b9e4c893b9c1fe'
 caller=json.loads(callerRaw);assert caller['passed']==6 and caller['failed']==0 and caller['status']=='PASS_SOURCE_CONTROLS_ONLY'
 assert [(s['name'],s['exit'])for s in caller['steps']]==[('full-ios-syntax-only',0),('actual-old-caller-compile',1),('actual-candidate-caller-compile',0),('actual-candidate-caller-controls',0)]
 assert b'escaping closure captures non-escaping parameter' in show(COMMITS[3],callerPath+'actual-old-caller-compile.stderr')
 actual=json.loads(show(COMMITS[3],callerPath+'actual-candidate-caller-controls.stdout'));assert actual['passed']==6 and actual['failed']==0
 # The old six-control run retains its true historical source scope. It is
 # not evidence for current UI/Host products; the current join below is.
 for row in caller['original_source_join']:pin(show(OLD_CALLER_BASE,row['path']),row)
 for row in caller['reused_products']:pin(pathlib.Path(row['path']).read_bytes(),row)
 checked=[]
 for p in git('ls-tree','-r','--name-only',COMMITS[3],FOLDERS[1]+'/inputs/candidate/Source').decode().splitlines():
  original=p.split('/inputs/candidate/',1)[1];expected=new if original==PRODUCT else show(BASE,original)
  assert show(COMMITS[3],p)==expected;checked.append(original)
 assert len(checked)==8
 currentPath=FOLDERS[2]+'/evidence/raw/'
 currentRaw=show(COMMITS[4],currentPath+'RESULT.json')
 assert sha(currentRaw)=='ebe40c5edffc71696bda9b7336786a277288ed90510816a7f46de471eb9c6e85'
 current=json.loads(currentRaw)
 assert current['passed']==6 and current['failed']==0 and current['status']=='PASS_CURRENT_BINDINGS_SOURCE_CONTROLS_ONLY'
 assert current['native']==current['apple_sdk']=='NOT_RUN'
 assert [(s['name'],s['exit'])for s in current['steps']]==[('compile-current-candidate-caller',0),('actual-linked-library-identity',0),('same-six-current-caller-controls',0)]
 currentOutput=json.loads(show(COMMITS[4],currentPath+'same-six-current-caller-controls.stdout'))
 assert currentOutput['passed']==6 and currentOutput['failed']==0
 moduleRaw=show(COMMITS[4],currentPath+'CURRENT_MODULE_SOURCE_JOIN.json')
 assert sha(moduleRaw)=='7768e4896eb3fc6fb2ff2256a820bc03c315b9c512936948c6346164b7a4efef'
 modules=json.loads(moduleRaw)
 assert modules['base']==current['base']=='b463ffd03a76026cea06c79c608df97d00094152'
 assert modules['counts']==current['current_module_counts']=={'Core':31,'Host':41,'UI':13}
 assert len(modules['files'])==85 and len({r['path']for r in modules['files']})==85
 for row in modules['files']:
  source=show(BASE,row['path']);pin(source,row)
  assert rev(BASE+':'+row['path'])==row['git_blob']
  pin(pathlib.Path(row['compiled_input']).read_bytes(),row)
 moduleFolders={'Core':'Source/Otzaria/Actions/Sources/OtzariaActionCore','UI':'Source/Otzaria/UIRouting/Sources/OtzariaUIRouting','Host':'Source/ChavrusaText/UIRoutingHost/Sources/ChavrusaUIRoutingHost'}
 for module,folder in moduleFolders.items():
  paths=git('ls-tree','-r','--name-only',BASE,folder).decode().splitlines()
  assert {p for p in paths if p.endswith('.swift')}=={r['path']for r in modules['files']if r['module']==module}
 assert modules['products']==current['reused_products'] and len(modules['products'])==6
 linked=show(COMMITS[4],currentPath+'actual-linked-library-identity.stdout').decode()
 for row in modules['products']:
  pin(pathlib.Path(row['path']).read_bytes(),row)
  if row['path'].endswith('.so'):
   assert re.search(r'^\s*'+re.escape(pathlib.Path(row['path']).name)+r'\s+=>\s+'+re.escape(row['path'])+r'\s',linked,re.M)
 appRaw=show(COMMITS[4],currentPath+'CURRENT_APP_SOURCE_JOIN.json')
 assert sha(appRaw)=='e6aff6bafb0dcc7af77f17c6693281fc6e2fe7304451bdee181430a1f21321ba'
 app=json.loads(appRaw);assert app['product_controller_sha256']==sha(new)
 rootRaw=show(BASE,app['root_publisher']['path']);pin(rootRaw,app['root_publisher'])
 rootText=rootRaw.decode();start=rootText.index('@MainActor\nfinal class MaktabahNativeRootPublicationSource');end=rootText.index('/// Expected publications',start)
 capsule=('import Foundation\nimport ChavrusaUIRoutingHost\n\n'+rootText[start:end].rstrip()+'\n').encode()
 assert sha(capsule)==app['root_publisher']['capsule_sha256']
 assert show(COMMITS[4],currentPath+'current-source/ActualOriginalRootPublication.swift')==capsule
 windowRaw=show(BASE,app['window']['path']);pin(windowRaw,app['window'])
 windowCapsule=windowRaw.decode().removeprefix('#if os(iOS)\n').removesuffix('#endif\n').replace('import UIKit\n','').encode()
 assert show(COMMITS[4],currentPath+'prior-inputs/controls/ActualWindowObservation.swift')==windowCapsule
 for row in json.loads(show(COMMITS[3],FOLDERS[1]+'/inputs/INPUTS.json')):
  assert show(COMMITS[4],currentPath+'prior-inputs/'+row['path'])==show(COMMITS[3],FOLDERS[1]+'/inputs/'+row['path'])
 assert sha(show(COMMITS[4],currentPath+'prior-inputs/controls/CallerControls.swift'))==app['six_control_sha256']
 assert sha(show(COMMITS[4],currentPath+'retained-receipts/otzaria-wave3-annotation-expansion-intake-20261127/FAILURE.json'))=='e847ab7462b262785e6c9ef0ce886a41f92ddc78bb1b30377a5ceb1df7627767'
 assert sha(show(COMMITS[4],currentPath+'retained-receipts/otzaria-wave3-annotation-expansion-intake-20261127/RUN.py'))=='65215dbd1073ddefc960323564ccb5fbc2f75695167a0b79b4bebacf57bbbcd4'
 failedTypecheck=show(COMMITS[3],FOLDERS[1]+'/evidence/raw/caller-followup-attempt-1/RESULT.json')
 # Preserve exact raw patch-context/compiler fixture bytes. The product diffs
 # above and this new intake proof still must pass their normal checks.
 rawWhitespace=[]
 for a,b,length,digest in [(COMMITS[0],COMMITS[1],802,'97f6315bf590dbec3c20c758857f1419cd480193cb85778fba36080155c21c81'),(COMMITS[2],COMMITS[3],134,'49dd3b84e1bdc8725c5ec1834194dcceafc58f589fc026a11e01ca136dc6f180'),(COMMITS[3],COMMITS[4],153,'bb42575bc98d36a8ccd7f61590ae7a72bb363f44f1275851df3234846686000b')]:
  p=subprocess.run(['git','-C',str(ROOT),'diff','--check',a,b],capture_output=True)
  assert p.returncode==2 and p.stderr==b''and len(p.stdout)==length and sha(p.stdout)==digest
  rawWhitespace.append({'from':a,'to':b,'exit':2,'bytes':length,'sha256':digest,'stdout':p.stdout.decode(),'scope':'Only immutable raw unified-diff context or compiled fixture EOF; no product/source or Git policy change.'})
 protected=['Source/Otzaria','Source/ChavrusaText','Vendor','Scripts','.github','docs/architecture','Maktabah-iOSUITests','Maktabah.xcodeproj','Source/Localizable.xcstrings']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 picked=[]
 for commit in COMMITS:
  git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',commit)
  picked.append({'donor':commit,'intake':rev('HEAD')});assert not git('status','--porcelain')
 assert (ROOT/PRODUCT).read_bytes()==new
 assert git('diff','--name-only',BASE,'HEAD','--','Source').decode().splitlines()==[PRODUCT]
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 (proof/'RAW_ARTIFACT_WHITESPACE.json.gz').write_bytes(gzip.compress((json.dumps(rawWhitespace,indent=2)+'\n').encode(),mtime=0))
 result={'schema':'otzaria.wave3.annotation-expansion-intake.v2','base':BASE,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'productPaths':1,'docsPaths':129,'manifests':manifests,'originalExpansionEdits':2,'retainedCallerSignatureEdits':1,'wholeFileInverse':True,'helperSourceControls':{'original':helper['baseline'],'candidate':helper['candidate'],'resultSHA256':sha(helperRaw)},'historicFullCallerSourceControls':{'base':OLD_CALLER_BASE,'passed':6,'failed':0,'originalCompileExit':1,'candidateCompileExit':0,'resultSHA256':sha(callerRaw),'preservedTypecheckAttemptSHA256':sha(failedTypecheck),'scope':caller['scope'],'currentIntegrationEvidence':False},'currentFullCallerSourceControls':{'passed':6,'failed':0,'resultSHA256':sha(currentRaw),'scope':current['scope'],'modules':modules['counts'],'moduleJoinSHA256':sha(moduleRaw),'appJoinSHA256':sha(appRaw),'originalCurrentSourcePinsVerified':len(modules['files']),'actualLinkedProducts':modules['products'],'sameAssertions':True},'verifiedRawFiles':sum(rawCounts),'verifiedInputRows':inputCounts,'currentSourceProductsMatched':checked,'historicModuleSourcePinsVerified':len(caller['original_source_join']),'preservedStoppedIntakeFailureSHA256':'e847ab7462b262785e6c9ef0ce886a41f92ddc78bb1b30377a5ceb1df7627767','newTestExecutions':0,'protectedTrees':trees,'AppleSDK':'NOT_RUN','nativeRuns':0,'open':['Actual native annotation cell geometry and foreground/background/cached-entity acceptance','Original annotation editor and filter semantics','Final production/real-owner/target merge/TestFlight']}
 dump(proof/'RESULT.json',result)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record original annotation expansion and complete caller compile evidence')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free};dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
