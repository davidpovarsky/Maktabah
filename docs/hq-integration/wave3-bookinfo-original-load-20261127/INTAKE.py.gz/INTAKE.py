import base64,gzip,hashlib,json,pathlib,shutil,subprocess,time,traceback
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='e2ffdb5cc82f7b2c571ff093867bfe22a56fb546';BRANCH='codex/otzaria-wave3-integration-20261127'
RUN=pathlib.Path(__file__).parent
CONTROL=ROOT/'.git/bookinfo-original-load-controls-20261127'
CURRENT=CONTROL/'attempt-2'
PROOF='docs/hq-integration/wave3-bookinfo-original-load-20261127'
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True,timeout=90)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failed '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def capacity():assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage('/mnt/development').free>=2147483648
def commit(message):
 git('diff','--cached','--check');git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m',message);return rev('HEAD')
def function(text,signature):
 start=text.index(signature);pos=text.index('{',start);n=1;end=pos+1
 while n:
  if text[end]=='{':n+=1
  elif text[end]=='}':n-=1
  end+=1
 return text[start:end]
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 raw=(CURRENT/'RESULT.json').read_bytes();assert sha(raw)=='a7879e7f34c307a55c53f3a76ab152f1e398188a195005018baa16c207914c26'
 actual=json.loads(raw);assert actual['status']=='PASS_SOURCE_ONLY'and actual['nativeRuns']==0
 assert {k:actual['actual'][k]for k in ['baselinePass','baselineFail','candidatePass','candidateFail']}=={'baselinePass':4,'baselineFail':14,'candidatePass':18,'candidateFail':0}
 assert len(actual['steps'])==6 and all(s['exit']==0 for s in actual['steps'])
 rawMembers=0
 for attempt,digest in [('attempt-1','9655beaba88c1611c3bfd4e7f4d3efa7140e76862298356ff0f05e177833f0da'),('attempt-2','6a07854831e97e17b5be606487b7030601f469375e964e14099cc92e644fc224')]:
  b=(CONTROL/attempt/'RAW_CONTROLS.json.gz').read_bytes();assert sha(b)==digest
  rows=json.loads(gzip.decompress(b))['files'];seen=set()
  for row in rows:
   assert row['path']not in seen;seen.add(row['path'])
   source=base64.b64decode(row['base64'],validate=True)
   assert len(source)==row['bytes']and sha(source)==row['sha256']
   assert (CONTROL/attempt/row['path']).read_bytes()==source
  rawMembers+=len(rows)
 edits=json.loads((CURRENT/'inputs/SOURCE_EDITS.json').read_text())
 extract=json.loads((CURRENT/'inputs/controls/EXTRACTION.json').read_text())
 compiled=(CURRENT/'inputs/controls/ActualOriginalMethods.swift').read_text()
 for item in extract['sourceMethods']:
  source=(CURRENT/'inputs'/item['variant']/item['path']).read_bytes();assert sha(source)==item['fullFileSHA256']
  body=function(source.decode(),'    private func loadBookInfo()');assert sha(body.encode())==item['originalLoadBodySHA256']
  instrumented=body.replace('    private func loadBookInfo() {','    private func loadBookInfo() {\n        let controlCompletion = TestObserver.makeInvocation()',1)
  task='bookInfoTask = Task {'if item['variant']=='candidate'else'Task {'
  instrumented=instrumented.replace(task,task+'\n            defer { controlCompletion.finish() }',1)
  assert sha(instrumented.encode())==item['compiledLoadBodySHA256']and compiled.count(instrumented)==2
  if item['variant']=='candidate':
   cancel=function(source.decode(),'    private func cancelBookInfoLoad()');assert sha(cancel.encode())==item['compiledCancelBodySHA256']and compiled.count(cancel)==2
 assert sha(show(BASE,'Source/Features/Library/Database/LibraryDataManager.swift'))==extract['originalDBFileSHA256']
 assert sha(function(show(BASE,'Source/Features/Library/Database/LibraryDataManager.swift').decode(),'    func loadBookInfo(').encode())==extract['originalDBMethodSHA256']
 for row in edits['files']:
  before=show(BASE,row['path']);after=(CURRENT/'inputs/candidate'/row['path']).read_bytes()
  assert len(before)==row['beforeBytes']and sha(before)==row['beforeSHA256']
  assert len(after)==row['afterBytes']and sha(after)==row['afterSHA256']
  inverse=after.decode()
  for e in reversed([e for e in edits['edits']if e['path']==row['path']]):
   assert inverse.count(e['new'])==1;inverse=inverse.replace(e['new'],e['old'])
  assert inverse.encode()==before
 catalogPath='Source/Localizable.xcstrings';catalogBefore=show(BASE,catalogPath)
 assert sha(catalogBefore)=='dc50c1391659e8093faa0f71b9a1ad8da93cdbb6e36cf8c58ad69cb784a9b6c0'
 catalog=json.loads(catalogBefore);assert (json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()==catalogBefore
 additions=json.loads((CURRENT/'inputs/CATALOG_HEBREW_ADDITIONS.json').read_text());assert len(additions)==3
 for key,value in additions.items():
  assert key in catalog['strings']and'he'not in catalog['strings'][key]['localizations']
  catalog['strings'][key]['localizations']['he']={'stringUnit':{'state':'translated','value':value}}
 catalogAfter=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()
 for key in additions:del catalog['strings'][key]['localizations']['he']
 assert (json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode()==catalogBefore
 protected=['Source/ChavrusaText','Source/UI','Source/Core','Source/LibraryBackend','Source/Otzaria','Vendor','Scripts','.github','Maktabah.xcodeproj','Maktabah-iOSUITests','docs/architecture']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 for row in edits['files']:(ROOT/row['path']).write_bytes((CURRENT/'inputs/candidate'/row['path']).read_bytes())
 git('add','--sparse','--',*[r['path']for r in edits['files']]);sourceCommit=commit('Retire original Book Info loads before stale results can publish or fall back')
 (ROOT/catalogPath).write_bytes(catalogAfter);git('add','--sparse','--',catalogPath)
 catalogCommit=commit('Translate the existing Book Info legacy sections into Hebrew')
 assert set(git('diff','--name-only',BASE,'HEAD','--','Source').decode().splitlines())=={catalogPath,*[r['path']for r in edits['files']]}
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 for attempt in ['attempt-1','attempt-2']:
  dest=proof/attempt;dest.mkdir()
  for name in ['RESULT.json','RAW_CONTROLS.json.gz']:(dest/name).write_bytes((CONTROL/attempt/name).read_bytes())
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 for attempt,filename,expected in [('attempt-1','otzaria-wave3-bookinfo-original-load-controls-runner-20261127.py','2f2fbfb589c01af290e23f8fbd568a30190591bfa39043ceae3f7c88e5a18c1a'),('attempt-2','otzaria-wave3-bookinfo-original-load-controls-runner-attempt2-20261127.py','1518f451192e251c8be1f17b83dd6d9f9ef8311d2444cded8e879efec57cb0c5')]:
  runner=pathlib.Path('/mnt/development/projects/diagnostics')/filename;b=runner.read_bytes();assert sha(b)==expected;(proof/attempt/'RUNNER.py.gz').write_bytes(gzip.compress(b,mtime=0))
 for name in ['SOURCE_EDITS.json','CATALOG_HEBREW_ADDITIONS.json']:(proof/name).write_bytes((CURRENT/'inputs'/name).read_bytes())
 (proof/'EXTRACTION.json').write_bytes((CURRENT/'inputs/controls/EXTRACTION.json').read_bytes())
 (proof/'FIRST_DISPATCH_FAILURE.json').write_text(json.dumps({'job':'job_e9f399e3fa70','exit':1,'beforeSourceAndCompiler':True,'error':"FileNotFoundError: '/mnt/development/projects/diagnostics/otzaria-wave3-bookinfo-original-load-controls-runner-20261127.py'",'reason':'Upload tool normalized target under its upload base; verified exact bytes were then explicitly staged at the declared final path.'},indent=2)+'\n')
 (proof/'STAGING_RECEIPT.json').write_bytes(pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-bookinfo-original-load-transfer-20261127.json').read_bytes())
 dump(proof/'ASANA_RECOVERY.json',{'previousRecord':f'{BASE}:docs/hq-integration/wave3-original-ui-hooks-20261127/PENDING_ASANA_MILESTONE.json','resolution':'After successful readback established prior comments absent, one merged update was posted and confirmed. Original failure record retained.','groupComment':'1220961570140206','deliveryComment':'1220961849009963','inboxCoordination':'1220961658033243','bookInfoCoordination':'1220961914019408'})
 result={'schema':'otzaria.wave3.bookinfo-original-load-intake.v1','base':BASE,'commits':{'source':sourceCommit,'hebrew':catalogCommit},'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'sourceFiles':edits['files'],'originalHunks':7,'sourceControlResultSHA256':sha(raw),'baseline':{'pass':4,'fail':14},'candidate':{'pass':18,'fail':0},'scenarioCount':9,'originalViews':2,'wholeFileParses':4,'rawMembersVerified':rawMembers,'sourceMethodInverse':True,'wholeFileInverse':True,'catalog':{'path':catalogPath,'beforeSHA256':sha(catalogBefore),'afterSHA256':sha(catalogAfter),'hebrewKeys':list(additions),'otherContentUnchanged':True},'protectedTrees':trees,'peerReview':'Navigation agent read exact b58550a3/46092848 plus original coordinator generation cancellation and synchronous DB callback; no scoped blocker found; no execution by reviewer.','nativeRuns':0,'AppleSDK':'NOT_RUN','limitations':['State storage/provider/domain controls do not establish real SwiftUI lifecycle timing or app/DB integration.','No generic no-transition/epoch fence or BookInfo navigation/ACK added.','Actual Dynamic Type/RTL/VoiceOver/44pt hit testing and native UI acceptance remain required.','All production/owner/target merge/signing/TestFlight gates remain open.']}
 dump(proof/'RESULT.json',result)
 git('add','--sparse','--',PROOF);final=commit('Preserve original Book Info regression controls and unchanged loading evidence')
 assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH)
 assert git(*remote).decode().split()[0]==final
 terminal={'ok':True,'head':final,'commits':result['commits'],'sourceTree':rev('HEAD:Source'),'catalogSHA256':sha(catalogAfter),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage('/mnt/development').free}
 dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as e:
 dump(RUN/'FAILURE.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
