import base64,datetime,gzip,hashlib,json,os,pathlib,shutil,signal,subprocess,time,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='e2ffdb5cc82f7b2c571ff093867bfe22a56fb546'
OWN=ROOT/'.git/bookinfo-original-load-controls-20261127/attempt-1'
INPUT=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-bookinfo-original-load-inputs-20261127.zip')
SWIFT='/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc'
ROOT_FLOOR=1342177280;DATA_FLOOR=2147483648;CAP=64*1024*1024
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def git(*a):return subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True,check=True,timeout=20).stdout
def free():return {'root':shutil.disk_usage(ROOT).free,'data':shutil.disk_usage(INPUT.parent).free}
def allocated():return sum(p.lstat().st_blocks*512 for p in OWN.rglob('*'))
def capacity():a=free();return a['root']>=ROOT_FLOOR and a['data']>=DATA_FLOOR and allocated()<CAP
def identity(pid):
 try:
  s=pathlib.Path('/proc/'+str(pid)+'/stat').read_text();v=s[s.rfind(')')+2:].split()
  return {'pid':pid,'parent':int(v[1]),'group':int(v[2]),'startTicks':int(v[19])}
 except FileNotFoundError:return None
assert os.geteuid()==1001
assert not OWN.exists();OWN.mkdir(parents=True)
result={'schema':'otzaria.wave3.original-bookinfo-load-controls.v1','base':BASE,'status':'RUNNING','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'appleSDK':'NOT_RUN','nativeRuns':0,'scope':'Full original BookInfo load/cancel methods with explicit completion instrumentation, original synchronous DB callback method, explicit SwiftUI storage/provider/domain boundaries. No app navigation, rendering, database integration or production acceptance.'}
def save():dump(OWN/'RESULT.json',result)
def run(name,args,timeout):
 assert capacity(),'Capacity before '+name
 row={'name':name,'argv':[str(v)for v in args],'started':time.time(),'freeBefore':free(),'allocatedBefore':allocated()};result['steps'].append(row);save()
 process=None
 try:
  with (OWN/(name+'.stdout')).open('xb')as out,(OWN/(name+'.stderr')).open('xb')as err:
   process=subprocess.Popen(row['argv'],stdout=out,stderr=err,start_new_session=True)
   owner=identity(process.pid);row['owner']=owner;save();until=time.monotonic()+timeout
   while process.poll()is None:
    cause='deadline'if time.monotonic()>=until else 'capacity'if not capacity()else None
    if cause:
     row['interruption']=cause
     assert owner is not None and identity(process.pid)==owner and owner['group']==process.pid,'Unproven ownership; no signal'
     os.killpg(process.pid,signal.SIGTERM)
     try:process.wait(timeout=5)
     except subprocess.TimeoutExpired:
      assert identity(process.pid)==owner,'Unproven escalation; no signal'
      os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
     row['cleanup']='EXACT_OWNED_GROUP_REAPED';break
    time.sleep(.2)
   row['exit']=process.wait()
 finally:
  if process is not None and process.poll()is None:
   if row.get('owner')is not None and identity(process.pid)==row['owner']and row['owner']['group']==process.pid:
    os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:
     if identity(process.pid)==row['owner']:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
   else:row['cleanup']='UNCERTAIN_OWNERSHIP_NO_SIGNAL'
  row.update(finished=time.time(),freeAfter=free(),allocatedAfter=allocated(),logs=[pin(OWN/(name+'.'+x))for x in ['stdout','stderr']if(OWN/(name+'.'+x)).exists()]);save()
 assert row.get('exit')==0 and not row.get('interruption'),name+' failed'
try:
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('status','--porcelain')
 assert capacity()
 result['input']=pin(INPUT)
 with zipfile.ZipFile(INPUT)as z:
  names=z.namelist();assert len(names)==len(set(names))
  assert all(not n.startswith('/')and '..'not in pathlib.PurePosixPath(n).parts for n in names)
  assert sum(i.file_size for i in z.infolist())<150000
  z.extractall(OWN/'inputs')
 manifest=json.loads((OWN/'inputs/SOURCE_EDITS.json').read_text())
 for row in manifest['files']:
  before=(OWN/'inputs/before'/row['path']).read_bytes();after=(OWN/'inputs/candidate'/row['path']).read_bytes()
  assert len(before)==row['beforeBytes']and sha(before)==row['beforeSHA256']and git('show',BASE+':'+row['path'])==before
  assert len(after)==row['afterBytes']and sha(after)==row['afterSHA256']
  inverse=after.decode()
  for e in reversed([e for e in manifest['edits']if e['path']==row['path']]):
   assert inverse.count(e['new'])==1;inverse=inverse.replace(e['new'],e['old'])
  assert inverse.encode()==before
 extract=json.loads((OWN/'inputs/controls/EXTRACTION.json').read_text())
 for row in extract['compiledSources']:
  p=OWN/'inputs/controls'/row['path'];b=p.read_bytes();assert len(b)==row['bytes']and sha(b)==row['sha256']
 dbrel='Source/Features/Library/Database/LibraryDataManager.swift'
 assert sha(git('show',BASE+':'+dbrel))==extract['originalDBFileSHA256']
 assert sha(pathlib.Path(SWIFT).read_bytes())=='39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'
 (OWN/'output').mkdir();(OWN/'module-cache').mkdir()
 args=[SWIFT,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',OWN/'module-cache']
 args += [OWN/'inputs/controls'/r['path']for r in extract['compiledSources']]+['-o',OWN/'output/bookinfo-controls']
 run('compile-original-methods',args,120)
 run('run-original-methods',[OWN/'output/bookinfo-controls'],30)
 actual=json.loads((OWN/'run-original-methods.stdout').read_text())
 assert actual['candidatePass']==18 and actual['candidateFail']==0 and actual['baselinePass']==4 and actual['baselineFail']==14
 result['actual']=actual
 for i,row in enumerate(manifest['files']):
  for config in ['Debug','Release']:
   args=[SWIFT,'-frontend','-parse','-target','arm64-apple-ios26.0']
   if config=='Debug':args+=['-D','DEBUG']
   args += [OWN/'inputs/candidate'/row['path']]
   run('parse-'+str(i)+'-'+config,args,25)
 assert git('rev-parse','HEAD').decode().strip()==BASE and not git('status','--porcelain')
 result.update(status='PASS_SOURCE_ONLY',sourceEdits=manifest['files'],extraction=pin(OWN/'inputs/controls/EXTRACTION.json'),product=pin(OWN/'output/bookinfo-controls'))
except BaseException as e:
 result.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
finally:
 result.update(finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),freeAfter=free(),allocatedAfter=allocated());save()
 rows=[]
 for p in sorted(OWN.rglob('*')):
  if not p.is_file()or 'module-cache'in p.parts or p.name=='RAW_CONTROLS.json.gz':continue
  b=p.read_bytes();rows.append({'path':p.relative_to(OWN).as_posix(),'bytes':len(b),'sha256':sha(b),'base64':base64.b64encode(b).decode()})
 raw=gzip.compress((json.dumps({'files':rows,'moduleCachePreservedAt':str(OWN/'module-cache'),'scope':result['scope']},sort_keys=True)+'\n').encode(),mtime=0)
 (OWN/'RAW_CONTROLS.json.gz').write_bytes(raw)
 print(json.dumps({'status':result['status'],'path':str(OWN),'resultSHA256':sha((OWN/'RESULT.json').read_bytes()),'raw':pin(OWN/'RAW_CONTROLS.json.gz'),'actual':{k:result.get('actual',{}).get(k)for k in ['baselinePass','baselineFail','candidatePass','candidateFail']},'error':result.get('error'),'allocatedBytes':allocated()}))
raise SystemExit(0 if result['status']=='PASS_SOURCE_ONLY'else 1)
