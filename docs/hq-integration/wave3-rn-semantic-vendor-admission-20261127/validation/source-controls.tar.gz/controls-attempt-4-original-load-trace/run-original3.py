from pathlib import Path
import runpy,sys,json,hashlib,time,unittest
base=Path(__file__).resolve().parent
test=base/'candidate/Scripts/CI/test-reviewed-semantic-vendor-source.py'
repo=Path('/mnt/development/projects/worktrees/Maktabah-wave3-vendor-admission-private-20261127')
out=base/'original3'
out.mkdir(exist_ok=False)
started=time.time()
loaded=[]
def profile(frame,event,arg):
 if event=='call' and frame.f_code.co_name=='run_path' and frame.f_globals.get('__name__')=='runpy':
  p=Path(frame.f_locals['path_name'])
  raw=p.read_bytes()
  loaded.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
sys.setprofile(profile)
m=runpy.run_path(str(test))
result={'scope':'ACTUAL_ORIGINAL_THREE_ROUTE_COUNTERFACTUAL_ONLY','native':'NOT_RUN','metro':'NOT_RUN','app_sdk_typecheck':'NOT_RUN'}
try:
 m['AdmissionTests'].fixture=m['Fixture'](repo,out)
 suite=unittest.TestSuite([m['AdmissionTests']('test_actual_original_three_routes_reject_current_source')])
 ran=unittest.TextTestRunner(verbosity=2).run(suite)
 result.update(methods=ran.testsRun,failures=len(ran.failures),errors=len(ran.errors),status='PASS' if ran.wasSuccessful() else 'FAIL',records=m['RECORDS'])
 sys.setprofile(None)
 old=out/'original-source/final_integration_source.py'
 physical=out/'control-checkout/Scripts/CI/final_integration_source.py'
 expected=hashlib.sha256(old.read_bytes()).hexdigest()
 assert physical.read_bytes()==old.read_bytes()
 originalLoads=[x for x in loaded if x['path'] in (str(old),str(physical)) and x['sha256']==expected]
 assert len(originalLoads)==3,originalLoads
 assert len(m['RECORDS'])==3
 assert all(x['outcome']=='REFUSED' for x in m['RECORDS'])
 result['three_actual_original_validator_loads']=originalLoads
 result['original_validator_sha256']=expected
 result['loaded_paths']=loaded
 result['duration_s']=time.time()-started
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 raise SystemExit(0 if ran.wasSuccessful() else 1)
except BaseException as error:
 sys.setprofile(None)
 if not isinstance(error, SystemExit) or error.code != 0:
  result['observer_or_runner_error']=repr(error)
  result['overall_status']='TRACE_OR_RUNNER_FAILED'
 result.setdefault('duration_s',time.time()-started)
 result.setdefault('loaded_paths',loaded)
 (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
 raise
