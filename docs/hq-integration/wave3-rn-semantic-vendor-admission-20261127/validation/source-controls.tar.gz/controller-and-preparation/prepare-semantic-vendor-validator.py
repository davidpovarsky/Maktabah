"""Prepare only the closed donor transition, retaining all original files."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "vendor-admission-contract-20261127/candidate/Scripts/CI"
OUT = ROOT / "vendor-transition/candidate/Scripts/CI"
OUT.mkdir(parents=True, exist_ok=True)
contract = OUT / "reviewed-vendor-semantics.inputs.json"
contract_sha = hashlib.sha256(contract.read_bytes()).hexdigest()
assert contract_sha == "1ea9bf12ab6c3157b58877bebeacbd836b541568a3ed5e577e1f44cc1adace49"
for name in ("hq-stage2-focused-apple.py", "prepare-normal-ios-workspace.py",
             "test-reviewed-vendor-source.py", "test-normal-ios-workspace.py", "reviewed-vendor-source.inputs.json"):
    shutil.copyfile(BASE / name, OUT / name)
shutil.copytree(BASE / "fixtures", OUT / "fixtures", dirs_exist_ok=True)
before = (BASE / "final_integration_source.py").read_text()
after = before.replace(
    'def verify_reviewed_vendor(root, source, reference):\n    root = Path(root).resolve(strict=True)\n',
    'def verify_reviewed_vendor(root, source, reference):\n    root = Path(root).resolve(strict=True)\n'
    '    if requires_semantic_vendor(root, source) or reference == {"manifest": SEMANTIC_REVIEW_PATH, "sha256": SEMANTIC_REVIEW_SHA256}:\n'
    '        return verify_semantic_vendor(root, source, reference)\n')
assert after != before
needle = 'def verify_reviewed_build_inputs(before, after, review):\n'
assert after.count(needle) == 1
after = after.replace(needle, needle + '    if review.get("manifest") == SEMANTIC_REVIEW_PATH:\n'
                      '        return verify_semantic_build_inputs(before, after, review)\n')
needle = '    review["input_transition"] = transition\n    review["embedded_bundle_build"] = {\n'
assert after.count(needle) == 1
after = after.replace(needle, '    review["input_transition"] = transition\n'
    '    js_paths, native_paths = reviewed_vendor_consumer_paths(review)\n'
    '    review["embedded_bundle_build"] = {\n')
after = after.replace('"mode": "REBUILD_EXACT_REVIEWED_JS", "overlay_paths": VENDOR_JS_PATHS,\n'
    '        "native_source_paths": [VENDOR_NATIVE_PATH],',
    '"mode": "REBUILD_EXACT_REVIEWED_JS", "overlay_paths": js_paths,\n'
    '        "native_source_paths": native_paths,')
after = after.replace('"review_contract_sha256": VENDOR_REVIEW_SHA256,\n',
                       '"review_contract_sha256": review["manifest_sha256"],\n')
after = after.replace('for path in [*VENDOR_JS_PATHS, VENDOR_NATIVE_PATH]}}\n',
                       'for path in [*js_paths, *native_paths]}}\n')
fragment = (ROOT / "semantic-vendor-extension.py.fragment").read_text()
assert fragment.count("CONTRACT_SHA_PLACEHOLDER") == 1
after += "\n\n" + fragment.replace("CONTRACT_SHA_PLACEHOLDER", contract_sha)
ast.parse(after)
(OUT / "final_integration_source.py").write_text(after)


def functions(raw):
    lines = raw.splitlines(True)
    return {node.name: "".join(lines[node.lineno - 1:node.end_lineno])
            for node in ast.parse(raw).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


old, new = functions(before), functions(after)
changed = sorted(name for name in old if old[name] != new[name])
assert changed == ["reviewed_vendor_source_plan", "verify_reviewed_build_inputs", "verify_reviewed_vendor"], changed
records = {"original_function_count": len(old), "unchanged_original_functions": sorted(set(old) - set(changed)),
    "three_explicit_dispatch_changes": changed, "new_functions": sorted(set(new) - set(old)),
    "original_focused_and_normal_routes_byte_identical": True,
    "original_tests_and_old_contract_byte_identical": True,
    "contract_sha256": contract_sha, "source": "d4e25c0cf5581427d6742ade1d4d1e0f3ddaa1a3"}
(ROOT / "vendor-transition/PRESERVED_FUNCTIONS.json").write_text(json.dumps(records, indent=2) + "\n")
print(json.dumps({"validator_sha256": hashlib.sha256(after.encode()).hexdigest(), **records}))
