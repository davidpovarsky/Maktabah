"""Generate an exact reviewed snapshot contract; never changes a checkout or gate.

The caller's reviewed intake commit must already exist. Generation is not approval,
and a donor contract cannot qualify a different cherry-picked root ancestry.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess

OLD_SOURCE = "24cd9291dbc87d799c22a41f0bc73a82c6415bfa"
OLD_PATH = "Scripts/CI/reviewed-vendor-source.inputs.json"
OLD_SHA = "43e166c8b19e6bd5fdba5395246e31b2a089db4ed9f39c510b91e8188830db32"
HISTORICAL = "d3da55417a30e9a06b0255e2d0b561955034b260"
NEW_HELPER = "Vendor/SefariaMobile/Integration/JS/ChavrusaVisibleSemanticTargets.js"
DELTA = sorted(["Vendor/SefariaMobile/Integration/JS/" + p for p in (
    "ChavrusaVisibleSurface.js", "ChavrusaVisibleSurfaceRegistry.js", "chavrusaRPCFacade.js",
    "ChavrusaVisibleSemanticTargets.js")] + ["Vendor/SefariaMobile/Integration/iOS/" + p for p in (
    "ChavrusaSefariaBridgeModule.swift", "ChavrusaSefariaBridgeModule.m")])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return sha(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True, type=Path)
    parser.add_argument("--reviewed-source", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    root, source = args.repository.resolve(), args.reviewed_source

    def git(*argv):
        return subprocess.check_output(["git", "-C", str(root), *argv], timeout=90)

    def text(*argv):
        return git(*argv).decode().strip()

    def entries(revision, prefix="Vendor"):
        rows = {}
        for raw in git("ls-tree", "-r", "-z", revision, "--", prefix).split(b"\0"):
            if raw:
                meta, name = raw.decode().split("\t")
                mode, kind, identity = meta.split()
                rows[name] = {"mode": mode, "kind": kind, "object": identity}
        return rows

    def obj(revision, name):
        raw = text("ls-tree", revision, "--", name)
        if not raw:
            return None
        meta, actual = raw.split("\t")
        assert actual == name
        mode, kind, identity = meta.split()
        result = {"mode": mode, "kind": kind, "object": identity}
        if kind == "blob":
            data = git("show", revision + ":" + name)
            result.update(bytes=len(data), sha256=sha(data))
        return result

    def patch(before, after, name):
        raw = git("diff", "--binary", "--full-index", "--no-ext-diff", before, after, "--", name)
        return {"bytes": len(raw), "sha256": sha(raw)}

    assert len(source) == 40 and text("rev-parse", source) == source
    git("merge-base", "--is-ancestor", OLD_SOURCE, source)
    old_raw = git("show", source + ":" + OLD_PATH)
    assert sha(old_raw) == OLD_SHA
    old = json.loads(old_raw)
    before, after, historical = entries(OLD_SOURCE), entries(source), entries(HISTORICAL)
    delta = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
    assert delta == DELTA, delta
    previous_rows = {row["path"]: row for row in old["entries"]}
    paths = sorted(p for p in historical.keys() | after.keys() if historical.get(p) != after.get(p))
    assert paths == sorted(set(previous_rows) | set(DELTA))
    rows, transition = [], []
    for path in paths:
        row = copy.deepcopy(previous_rows.get(path))
        if path in DELTA:
            # The actual last path-changing intake is used, not an invented
            # umbrella producer or the donor when the root used a cherry-pick.
            component = text("log", "-1", "--format=%H", source, "--", path)
            parent = text("rev-parse", component + "^")
            assert obj(component, path) == obj(source, path)
            assert obj(parent, path) == obj(OLD_SOURCE, path)
            step = {"source": component, "parent": parent, "before": obj(parent, path),
                    "after": obj(component, path), "patch": patch(parent, component, path)}
            transition.append({"path": path, "before": obj(OLD_SOURCE, path),
                "after": obj(source, path), "patch": patch(OLD_SOURCE, source, path),
                "component_step": step})
            row = row or {"path": path, "classification": "DOWNSTREAM_INTEGRATION",
                          "historical": obj(HISTORICAL, path), "component_steps": []}
            row.update(accepted=obj(source, path), component=component,
                       historical_patch=patch(HISTORICAL, source, path))
            row["component_steps"].append(step)
        assert row is not None
        rows.append(row)
    producer_scopes = {}
    for name, prior in old["producer_scopes"].items():
        producer, prefix = prior["producer"], prior["root"]
        a, b = entries(producer, prefix), entries(source, prefix)
        changes = sorted(p for p in a.keys() | b.keys() if a.get(p) != b.get(p))
        preserved = {p: entry for p, entry in a.items() if p not in changes}
        assert all(b.get(p) == entry for p, entry in preserved.items())
        producer_scopes[name] = {"producer": producer, "root": prefix,
            "producer_tree": text("rev-parse", producer + ":" + prefix),
            "accepted_tree": text("rev-parse", source + ":" + prefix),
            "producer_entries": len(a), "accepted_entries": len(b),
            "preserved_entries": len(preserved), "preserved_entries_sha256": canonical(preserved),
            "changes": [{"path": p, "before": obj(producer, p), "after": obj(source, p),
                         "patch": patch(producer, source, p)} for p in changes]}
    assert producer_scopes["zayit"] == old["producer_scopes"]["zayit"]
    build_inputs = copy.deepcopy(old["build_inputs"])
    build_inputs["after"] = sorted(build_inputs["after"] + [NEW_HELPER])
    expected_common = dict(build_inputs["baseline_common"], embedded_js_overlay_paths=build_inputs["after"])
    build_inputs["accepted_canonical_sha256"] = canonical(expected_common)
    preserved = {p: entry for p, entry in historical.items() if p not in paths}
    unchanged_previous = {p: entry for p, entry in before.items() if p not in DELTA}
    value = {"schema": "otzaria.reviewed-vendor-semantic-source/1",
        "scope": old["scope"], "native_qualified": False, "reviewed_product_source": source,
        "historical_source": HISTORICAL, "integration_base": old["integration_base"],
        "vendor_tree": text("rev-parse", source + ":Vendor"),
        "previous_review": {"manifest": OLD_PATH, "sha256": OLD_SHA,
            "source": OLD_SOURCE, "vendor_tree": old["vendor_tree"], "object": obj(source, OLD_PATH)},
        "transition": {"entries": transition, "unchanged_previous_entries": len(unchanged_previous),
            "unchanged_previous_entries_sha256": canonical(unchanged_previous),
            "single_reviewed_field": "embedded_js_overlay_paths",
            "before": old["build_inputs"]["after"], "after": build_inputs["after"],
            "before_common_sha256": old["build_inputs"]["accepted_canonical_sha256"],
            "after_common_sha256": build_inputs["accepted_canonical_sha256"]},
        "entries": rows, "preserved_inventory": {"historical_entries": len(historical),
            "accepted_entries": len(after), "unchanged_entries": len(preserved), "sha256": canonical(preserved)},
        "producer_scopes": producer_scopes, "build_inputs": build_inputs,
        "legacy_input_fixture": old["legacy_input_fixture"], "evidence": old["evidence"]}
    raw = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as stream:
        stream.write(raw)
    print(json.dumps({"path": str(args.output), "bytes": len(raw), "sha256": sha(raw),
        "reviewed_source": source, "vendor_tree": value["vendor_tree"],
        "exact_transition_paths": delta, "cumulative_changed_paths": len(paths),
        "historical_preserved": len(preserved), "previous_preserved": len(unchanged_previous)}))


if __name__ == "__main__":
    main()
