"""Create additive donor controls; the prior 39-test file remains byte-exact."""
from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parent
CI = ROOT / "vendor-transition/candidate/Scripts/CI"
before = (CI / "test-reviewed-vendor-source.py").read_text()
source = before.replace('SOURCE = "24cd9291dbc87d799c22a41f0bc73a82c6415bfa"',
    'SOURCE = "d4e25c0cf5581427d6742ade1d4d1e0f3ddaa1a3"')
source = source.replace('CONTRACT = "Scripts/CI/reviewed-vendor-source.inputs.json"',
    'CONTRACT = "Scripts/CI/reviewed-vendor-semantics.inputs.json"')
source = source.replace('(HERE / "reviewed-vendor-source.inputs.json").read_bytes()',
                        '(HERE / "reviewed-vendor-semantics.inputs.json").read_bytes()')
source = source.replace('"reviewed-vendor-source.inputs.json"):',
    '"reviewed-vendor-source.inputs.json", "reviewed-vendor-semantics.inputs.json"):')
source = source.replace('self.assertEqual(proof["preserved_historical_vendor_entries"], 195)',
                        'self.assertEqual(proof["preserved_historical_vendor_entries"], 194)')
source = source.replace('self.assertEqual(proof["reviewed_vendor_changes"], 7)',
                        'self.assertEqual(proof["reviewed_vendor_changes"], 9)')
source = source.replace('self.assertEqual(len(proof["embedded_bundle_build"]["overlay_paths"]), 4)',
                        'self.assertEqual(len(proof["embedded_bundle_build"]["overlay_paths"]), 5)')
source = source.replace('self.assertEqual(len(proof["embedded_bundle_build"]["native_source_paths"]), 1)',
                        'self.assertEqual(len(proof["embedded_bundle_build"]["native_source_paths"]), 2)')
source = source.replace('real 24cd product', 'real d4e donor product')
source = source.replace('real 24cd product', 'real d4e donor product')
source = source.replace('real 24cd product', 'real d4e donor product')
source = source.replace('the real 24cd product', 'the real d4e donor product')
extra = r'''
    def test_old_four_overlay_plan_cannot_qualify_new_helper(self):
        config = copy.deepcopy(self.f.config)
        config["embedded_js_overlay_paths"].remove("Vendor/SefariaMobile/Integration/JS/ChavrusaVisibleSemanticTargets.js")
        self.f.metadata(config=config)
        self.refused()

    def test_old_valid_contract_reference_cannot_downgrade_new_descendant(self):
        manifest = copy.deepcopy(self.f.manifest)
        old_path = "Scripts/CI/reviewed-vendor-source.inputs.json"
        manifest["reviewed_vendor_source"] = {"manifest": old_path, "sha256": sha(self.f.files[old_path])}
        self.f.metadata(manifest=manifest)
        self.refused()

    def test_backdated_direct_vendor_request_cannot_downgrade_new_head(self):
        old_path = "Scripts/CI/reviewed-vendor-source.inputs.json"
        with self.assertRaisesRegex(RuntimeError, "old contract cannot qualify"):
            self.f.validator["verify_reviewed_vendor"](self.f.root,
                "24cd9291dbc87d799c22a41f0bc73a82c6415bfa",
                {"manifest": old_path, "sha256": sha(self.f.files[old_path])})

    def test_old_contract_bytes_are_preserved_even_with_valid_new_contract(self):
        path = "Scripts/CI/reviewed-vendor-source.inputs.json"
        self.f.put(path, self.f.files[path] + b" ")
        self.f.commit("CONTROL ONLY: change previous contract")
        self.refused()

    def test_objc_export_missing_is_refused(self):
        (self.f.root / "Vendor/SefariaMobile/Integration/iOS/ChavrusaSefariaBridgeModule.m").unlink()
        self.refused()

    def test_new_semantic_helper_missing_is_refused(self):
        (self.f.root / "Vendor/SefariaMobile/Integration/JS/ChavrusaVisibleSemanticTargets.js").unlink()
        self.refused()

    def test_missing_real_git_object_closure_never_uses_fixture_tolerance(self):
        alternate = self.f.root / ".git/objects/info/alternates"
        raw = alternate.read_bytes()
        try:
            alternate.write_bytes(b"")
            self.refused()
        finally:
            alternate.write_bytes(raw)

    def test_cumulative_original_component_steps_are_checked(self):
        review = copy.deepcopy(self.f.contract)
        row = next(row for row in review["entries"] if row["path"].endswith("/chavrusaRPCFacade.js"))
        row["component_steps"][0]["patch"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(RuntimeError, "intake step changed"):
            self.f.validator["verify_vendor_snapshot"](self.f.root, SOURCE, review,
                self.f.validator["SEMANTIC_REVIEW_PATHS"], 194)

    def test_cumulative_original_inventory_is_checked(self):
        review = copy.deepcopy(self.f.contract)
        review["preserved_inventory"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(RuntimeError, "imported Vendor leaves changed"):
            self.f.validator["verify_vendor_snapshot"](self.f.root, SOURCE, review,
                self.f.validator["SEMANTIC_REVIEW_PATHS"], 194)

'''
needle = '\ndef add_input_control(name, mutate):\n'
assert source.count(needle) == 1
source = source.replace(needle, '\n' + extra + needle)
needle = '    ("extra_path", "Vendor/SefariaMobile/Integration/JS/unreviewed.js"),\n'
assert source.count(needle) == 1
source = source.replace(needle, needle +
    '    ("objc_export_hunk", "Vendor/SefariaMobile/Integration/iOS/ChavrusaSefariaBridgeModule.m"),\n'
    '    ("semantic_helper_hunk", "Vendor/SefariaMobile/Integration/JS/ChavrusaVisibleSemanticTargets.js"),\n')
ast.parse(source)
(CI / "test-reviewed-semantic-vendor-source.py").write_text(source)
print(CI / "test-reviewed-semantic-vendor-source.py")
