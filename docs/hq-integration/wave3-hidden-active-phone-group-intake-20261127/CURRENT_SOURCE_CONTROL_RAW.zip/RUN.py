import base64,datetime,hashlib,json,os,pathlib,re,shutil,signal,subprocess,time,traceback,gzip
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='7230fe99a84c0b96abc0a3e86d1107811d30d6ce'
DONOR=pathlib.Path('/mnt/development/projects/worktrees/Maktabah-wave3-hidden-active-phone-group-20261127')
COMMIT='8223dab6d0031027fb08998a5043bc97228ff983'
FOLDER='docs/ui-routing/wave3-hidden-active-phone-group-20261127'
OWN=pathlib.Path(__file__).parent
PRIOR=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-hidden-group-20261127/attempt-5')
SWIFT='/mnt/development/tooling/swiftly/toolchains/6.4.3/usr/bin/swiftc'
HOST=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-annotation-selection-intake-20261127-attempt2/output')
UI=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-rn-semantic-intake-20261127/output')
CORE=ROOT/'.git/search-continuation-integrated-controls-20261127/output'
ROOT_FLOOR=1342177280
DATA_FLOOR=2147483648
CAP=128*1024*1024
sha=lambda b:hashlib.sha256(b).hexdigest()
result={'schema':'otzaria.wave3.hidden-group-current-bindings.v1','base':BASE,'donor':COMMIT,'status':'RUNNING','steps':[],'started':time.time(),'nativeRuns':0,'AppleSDK':'NOT_RUN'}
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def filepin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def git(repo,*a):return subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(repo),*a],capture_output=True,check=True,timeout=30).stdout
def show(repo,ref,path):return git(repo,'show',ref+':'+path)
def available():return {'root':shutil.disk_usage(ROOT).free,'data':shutil.disk_usage(OWN).free}
def allocated():return sum(p.lstat().st_blocks*512 for p in OWN.rglob('*'))
def capacity():
 a=available();return a['root']>=ROOT_FLOOR and a['data']>=DATA_FLOOR and allocated()<CAP
def save():dump(OWN/'RESULT.json',result)
def identity(pid):
 try:
  text=pathlib.Path('/proc/'+str(pid)+'/stat').read_text();values=text[text.rfind(')')+2:].split()
  return {'pid':pid,'parent':int(values[1]),'group':int(values[2]),'startTicks':int(values[19])}
 except FileNotFoundError:return None
def run(name,argv,timeout):
 assert capacity(),'Resource admission '+name
 step={'name':name,'argv':[str(v)for v in argv],'started':time.time(),'freeBefore':available(),'allocatedBefore':allocated()};result['steps'].append(step);save()
 process=None
 try:
  with (OWN/(name+'.stdout')).open('wb')as out,(OWN/(name+'.stderr')).open('wb')as err:
   process=subprocess.Popen(step['argv'],stdout=out,stderr=err,start_new_session=True)
   owner=identity(process.pid);step['owner']=owner;save();until=time.monotonic()+timeout
   while process.poll()is None:
    cause='timeout'if time.monotonic()>=until else 'resource_guard'if not capacity()else None
    if cause:
     step['interruption']=cause
     if owner is None or identity(process.pid)!=owner or owner['group']!=process.pid:raise RuntimeError('Unproven process ownership; no signal')
     os.killpg(process.pid,signal.SIGTERM)
     try:process.wait(timeout=5)
     except subprocess.TimeoutExpired:
      if identity(process.pid)!=owner:raise RuntimeError('Unproven escalation ownership; no signal')
      os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
     step['cleanup']='EXACT_OWNED_GROUP_STOPPED_AND_REAPED';break
    time.sleep(.2)
   step['exit']=process.wait()
 finally:
  if process is not None and process.poll()is None:
   if step.get('owner')is not None and identity(process.pid)==step['owner']and step['owner']['group']==process.pid:
    os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:
     if identity(process.pid)==step['owner']:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
     else:step['cleanup']='UNCERTAIN_OWNERSHIP_NO_ESCALATION'
   else:step['cleanup']='UNCERTAIN_OWNERSHIP_NO_SIGNAL'
  step['finished']=time.time();step['freeAfter']=available();step['allocatedAfter']=allocated()
  step['logs']={suffix:filepin(OWN/(name+'.'+suffix))for suffix in ['stdout','stderr']if(OWN/(name+'.'+suffix)).exists()};save()
 assert step.get('exit')==0,name+' exit '+str(step.get('exit'))
try:
 assert git(ROOT,'rev-parse','HEAD').decode().strip()==BASE and not git(ROOT,'status','--porcelain')
 assert capacity()
 rawResult=show(DONOR,COMMIT,FOLDER+'/evidence/FINAL_RESULT.json')
 assert sha(rawResult)=='1f3ff09b4dac620220c1764300345effa407c07ddc6ee71ea53921422280d070'
 prior=json.loads(rawResult);assert prior['candidate']['pass']==22 and prior['candidate']['fail']==0
 rawArchive=show(DONOR,COMMIT,FOLDER+'/evidence/RAW_CONTROLS.json.gz')
 assert sha(rawArchive)=='977e2ee2aa8eca7bfee86df7abda1e6026f9cbe8e2aaa180bba0f848fd182ece'
 archive=json.loads(gzip.decompress(rawArchive));assert len(archive['files'])==405
 rawFiles={}
 for row in archive['files']:
  assert row['path']not in rawFiles
  b=base64.b64decode(row['base64'],validate=True);pin(b,row);rawFiles[row['path']]=b
 compileStep=next(s for s in prior['steps']if s['name']=='compile-candidate')
 actualRows={r['path']:r for r in prior['artifacts']}
 copied=[]
 for item in compileStep['argv']:
  if not item.endswith('.swift'):continue
  source=pathlib.Path(item);relative=source.relative_to(PRIOR).as_posix()
  b=source.read_bytes();pin(b,actualRows[relative]);assert b==rawFiles['attempt-5/'+relative]
  target=OWN/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
  copied.append(filepin(target))
 assert len(copied)==25
 productJoins=json.loads(show(DONOR,COMMIT,FOLDER+'/RESULT.json'))['compiledProductBodyJoins']
 for row in productJoins:
  b=show(DONOR,COMMIT,row['path']);pin(b,row['product'])
  compiled=(OWN/'inputs/controls/candidate'/pathlib.Path(row['path']).name).read_bytes();pin(compiled,row['compiled'])
  if row['path'].endswith('StudyWorkspaceGroupSelectionReservation.swift'):assert compiled==b
  elif row['path'].endswith('MaktabahNativeWorkspaceSelectionBinding.swift'):
   assert compiled==b.decode().removeprefix('#if os(iOS)\n').removesuffix('#endif\n').replace('import SwiftUI\n','').encode()
  else:
   transformed=b.decode().replace('import SwiftUI\nimport Combine\n','import Foundation\nimport Observation\n').encode()
   assert len(compiled)-len(transformed)==715 and compiled.startswith(transformed)
   result['explicitAdapterFixtureSuffix']={'bytes':715,'sha256':sha(compiled[len(transformed):]),'text':compiled[len(transformed):].decode()}
 for row in prior['originalSourceJoins']['files']:pin(show(ROOT,BASE,row['path']),row)
 modulePath='docs/hq-ui-inventory/wave3-annotation-current-bindings-20261127/evidence/raw/CURRENT_MODULE_SOURCE_JOIN.json'
 moduleRaw=show(ROOT,BASE,modulePath);assert sha(moduleRaw)=='7768e4896eb3fc6fb2ff2256a820bc03c315b9c512936948c6346164b7a4efef'
 modules=json.loads(moduleRaw);assert len(modules['files'])==85 and modules['counts']=={'Core':31,'UI':13,'Host':41}
 for row in modules['files']:
  pin(show(ROOT,BASE,row['path']),row);pin(pathlib.Path(row['compiled_input']).read_bytes(),row)
 for row in modules['products']:pin(pathlib.Path(row['path']).read_bytes(),row)
 pin(pathlib.Path(SWIFT).read_bytes(),{'bytes':pathlib.Path(SWIFT).stat().st_size,'sha256':'39d41b0dc9eba623b0e37cea42c3145720168214ba4349d6fa3bd9db9b1e651a'})
 dump(OWN/'CURRENT_MODULE_SOURCE_JOIN.json',modules)
 dump(OWN/'COMPILED_INPUTS.json',copied)
 (OWN/'output').mkdir();(OWN/'module-cache').mkdir()
 resources=[]
 for row in archive['preservedProducts']:
  p=pathlib.Path(row['path'])
  if p.is_relative_to(PRIOR/'output/OtzariaActionCore_OtzariaActionCore.bundle'):
   b=p.read_bytes();pin(b,row);dest=OWN/'output'/p.relative_to(PRIOR/'output');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);resources.append(row)
 assert len(resources)==7
 result.update(scope='Exact same candidate22 over current original31Core/13UI/41Host products. UIKit/SwiftUI/domain/Reader/persistence fixture boundaries retained. No original baseline, negative3 or historical failures rerun.',originalSourceJoinCount=len(prior['originalSourceJoins']['files']),modules=modules['counts'],moduleSourceJoinSHA256=sha(moduleRaw),readOnlyProducts=modules['products'],compiledInputs=copied,resourcePins=resources,priorCandidateResultSHA256=sha(rawResult),priorRawArchiveSHA256=sha(rawArchive),verifiedPriorRawFiles=405,productBodyJoins=productJoins)
 save()
 executable=OWN/'output/current-candidate-controls'
 argv=[SWIFT,'-swift-version','6','-strict-concurrency=complete','-parse-as-library','-module-cache-path',OWN/'module-cache']
 for folder,library in [(HOST,'ChavrusaUIRoutingHost'),(UI,'OtzariaUIRouting'),(CORE,'OtzariaActionCore')]:argv+=['-I',folder,'-L',folder,'-l'+library,'-Xlinker','-rpath','-Xlinker',folder]
 argv += [r['path']for r in copied]+['-o',executable]
 run('compile-current-candidate',argv,150)
 run('actual-current-linked-libraries',['ldd',executable],20)
 linked=(OWN/'actual-current-linked-libraries.stdout').read_text()
 for row in modules['products']:
  if row['path'].endswith('.so'):assert re.search(r'^\s*'+re.escape(pathlib.Path(row['path']).name)+r'\s+=>\s+'+re.escape(row['path'])+r'\s',linked,re.M)
 run('same22-current-candidate',[executable],30)
 actual=json.loads((OWN/'same22-current-candidate.stdout').read_text())
 assert actual==prior['candidate']and actual['pass']==22 and actual['fail']==0
 for row in copied:pin(pathlib.Path(row['path']).read_bytes(),row)
 for row in modules['products']:pin(pathlib.Path(row['path']).read_bytes(),row)
 assert git(ROOT,'rev-parse','HEAD').decode().strip()==BASE and not git(ROOT,'status','--porcelain')
 result.update(status='PASS_CURRENT_BINDINGS_SOURCE_CONTROLS_ONLY',candidate=actual,executable=filepin(executable),priorScopesPreserved=True)
except BaseException as e:
 result.update(status='FAILED',error=repr(e),traceback=traceback.format_exc());raise
finally:
 result.update(finished=time.time(),freeAfter=available(),allocatedAfter=allocated());save()
 print(json.dumps({'status':result['status'],'resultSHA256':sha((OWN/'RESULT.json').read_bytes()),'candidate':{k:result.get('candidate',{}).get(k)for k in ['pass','fail']},'nativeRuns':0,'allocatedBytes':allocated()}))
