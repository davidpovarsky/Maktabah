import Foundation
import Observation

// EXPLICIT DOMAIN / APPLE BOUNDARIES: Combine delivery, the book resolver,
// Reader rendering/IO, navigation-manager storage, and user callbacks below
// are small shells. Actual Store/persistence/mapping, prepared stage, policy,
// complete adapter body, original selectTab/closeTab/setters, content-token
// coordinator and same-backend snapshot terminal are compiled unchanged.
@MainActor final class AnyCancellable {
    private var cancellation: (() -> Void)?
    init(_ cancellation: @escaping () -> Void) { self.cancellation = cancellation }
    func cancel() { cancellation?(); cancellation = nil }
}
@MainActor final class BoundaryPublisher {
    private var subscribers: [UUID: (()) -> Void] = [:]
    var beforeSend: (() -> Void)?
    func sink(_ receive: @escaping (()) -> Void) -> AnyCancellable {
        let id = UUID(); subscribers[id] = receive
        return AnyCancellable { [weak self] in self?.subscribers.removeValue(forKey: id) }
    }
    func send() {
        let hook = beforeSend; beforeSend = nil; hook?()
        for id in Array(subscribers.keys) { subscribers[id]?(()) }
    }
}

enum BackendTransitionError: Error, Equatable, LocalizedError {
    case staleRequest
    case invalidTargetBackend(String)
    case capabilityUnavailable(BackendID)
    case outgoingPersistFailed(String)
    case missingTargetCatalog(BackendID)
    case unresolvableBook(bookId: Int, title: String, locator: String?)
    case foreignBackendLocator(locator: String, expectedBackend: BackendID)
    case corruptedSessionSnapshot(String)
    case transitionSuperseded

    var errorDescription: String? {
        switch self {
        case .staleRequest:
            return "The transition request is stale or was superseded."
        case .invalidTargetBackend(let id):
            return "Target backend '\(id)' is not a valid canonical backend."
        case .capabilityUnavailable(let id):
            return "Capability unavailable for backend '\(id.rawValue)'."
        case .outgoingPersistFailed(let msg):
            return "Failed to persist outgoing session: \(msg)"
        case .missingTargetCatalog(let id):
            return "Target catalog unavailable for backend '\(id.rawValue)'."
        case .unresolvableBook(let id, let title, let loc):
            return "Book id=\(id) title='\(title)' locator='\(loc ?? "nil")' cannot be resolved in target catalog."
        case .foreignBackendLocator(let loc, let exp):
            return "Locator '\(loc)' belongs to foreign backend; expected '\(exp.rawValue)'."
        case .corruptedSessionSnapshot(let msg):
            return "Corrupted session snapshot: \(msg)"
        case .transitionSuperseded:
            return "Transition was superseded by a newer request."
        }
    }
}
struct PreparedBackendTransition: Sendable, Equatable {
    let transitionToken: UInt64
    let outgoingBackend: BackendID
    let incomingBackend: BackendID
    let outgoingSnapshotData: Data?
    let incomingSnapshotData: Data?
    let isCleanDestination: Bool
    let stagedTabs: [StagedTabSession]
    let targetActiveTabId: UUID?
    let targetModeRaw: String?
    let createdAt: Date

    struct StagedTabSession: Sendable, Equatable {
        let id: UUID
        let bookId: Int
        let bookTitle: String
        let backendLocator: String?
        let contentId: Int?
        let locator: TextLocator?
        let page: Int?
        let part: Int?
        let scrollPosition: CGPoint?
        let selectedRange: NSRange?
        let expandedNodeIDs: [Int]?
        let sidebarScrollPosition: CGPoint?
        let isSidebarCollapsed: Bool?
        let searchText: String?
        let searchModeRaw: Int?
        let nearDistance: Int?
        let highlightTerms: [String]?
        let retainedBook: (any AnyObject & Sendable)?

        init(
            id: UUID,
            bookId: Int,
            bookTitle: String,
            backendLocator: String?,
            contentId: Int? = nil,
            locator: TextLocator? = nil,
            page: Int? = nil,
            part: Int? = nil,
            scrollPosition: CGPoint? = nil,
            selectedRange: NSRange? = nil,
            expandedNodeIDs: [Int]? = nil,
            sidebarScrollPosition: CGPoint? = nil,
            isSidebarCollapsed: Bool? = nil,
            searchText: String? = nil,
            searchModeRaw: Int? = nil,
            nearDistance: Int? = nil,
            highlightTerms: [String]? = nil,
            retainedBook: (any AnyObject & Sendable)? = nil
        ) {
            self.id = id
            self.bookId = bookId
            self.bookTitle = bookTitle
            self.backendLocator = backendLocator
            self.contentId = contentId
            self.locator = locator
            self.page = page
            self.part = part
            self.scrollPosition = scrollPosition
            self.selectedRange = selectedRange
            self.expandedNodeIDs = expandedNodeIDs
            self.sidebarScrollPosition = sidebarScrollPosition
            self.isSidebarCollapsed = isSidebarCollapsed
            self.searchText = searchText
            self.searchModeRaw = searchModeRaw
            self.nearDistance = nearDistance
            self.highlightTerms = highlightTerms
            self.retainedBook = retainedBook
        }

        static func == (lhs: StagedTabSession, rhs: StagedTabSession) -> Bool {
            lhs.id == rhs.id &&
            lhs.bookId == rhs.bookId &&
            lhs.bookTitle == rhs.bookTitle &&
            lhs.backendLocator == rhs.backendLocator &&
            lhs.contentId == rhs.contentId &&
            lhs.locator == rhs.locator &&
            lhs.page == rhs.page &&
            lhs.part == rhs.part &&
            lhs.scrollPosition == rhs.scrollPosition &&
            lhs.selectedRange == rhs.selectedRange &&
            lhs.expandedNodeIDs == rhs.expandedNodeIDs &&
            lhs.sidebarScrollPosition == rhs.sidebarScrollPosition &&
            lhs.isSidebarCollapsed == rhs.isSidebarCollapsed &&
            lhs.searchText == rhs.searchText &&
            lhs.searchModeRaw == rhs.searchModeRaw &&
            lhs.nearDistance == rhs.nearDistance &&
            lhs.highlightTerms == rhs.highlightTerms &&
            lhs.retainedBook === rhs.retainedBook
        }
    }

    init(
        transitionToken: UInt64,
        outgoingBackend: BackendID,
        incomingBackend: BackendID,
        outgoingSnapshotData: Data?,
        incomingSnapshotData: Data?,
        isCleanDestination: Bool,
        stagedTabs: [StagedTabSession],
        targetActiveTabId: UUID?,
        targetModeRaw: String? = nil,
        createdAt: Date = Date()
    ) {
        self.transitionToken = transitionToken
        self.outgoingBackend = outgoingBackend
        self.incomingBackend = incomingBackend
        self.outgoingSnapshotData = outgoingSnapshotData
        self.incomingSnapshotData = incomingSnapshotData
        self.isCleanDestination = isCleanDestination
        self.stagedTabs = stagedTabs
        self.targetActiveTabId = targetActiveTabId
        self.targetModeRaw = targetModeRaw
        self.createdAt = createdAt
    }
}
protocol BackendSnapshotStaging: Sendable {
    @MainActor func withSnapshotRollback(_ operation: () async throws -> Void) async throws
    @MainActor func withSynchronousSnapshotRollback(_ operation: () throws -> Void) throws
    func flushStagedSnapshots() throws
}
@MainActor final class BackendCoordinator {
    static let shared = BackendCoordinator()
    let objectWillChange = BoundaryPublisher()
    var activeBackendID: BackendID = .otzaria { willSet { objectWillChange.send() } }
    var committedBackendID: BackendID? = .otzaria
    var generation: UInt64 = 0 { willSet { objectWillChange.send() } }
    var pendingBackendID: BackendID? { willSet { objectWillChange.send() } }
    var isTransitioning = false { willSet { objectWillChange.send() } }
    var activeSessionSnapshots: (any BackendSnapshotStaging)?
    var beforeOriginalAsyncCommit: (() throws -> Void)?
    var terminalEvents: [String] = []
        func commitPreparedSameBackend(_ backendID: BackendID, expectedGeneration: UInt64,
                                   validate: () throws -> Void,
                                   beforeCommit: () throws -> Void,
                                   publish: () -> Void,
                                   willClearPending: () -> Void,
                                   didClearPending: () -> Void) throws {
        func validateCurrentSource() throws {
            try Task.checkCancellation()
            guard !isTransitioning, pendingBackendID == nil, activeBackendID == backendID,
                  committedBackendID == backendID, generation == expectedGeneration else {
                throw BackendTransitionError.transitionSuperseded
            }
            try validate()
        }
        try validateCurrentSource()
        func commit() throws {
            try performCommittedBackendPublication(beforeCommit: {
                // The original flush can invoke synchronous source callbacks.
                // Revalidate before the first persistent workspace mutation.
                try validateCurrentSource()
                try beforeCommit()
            }, publish: publish, willClearPending: willClearPending, didClearPending: didClearPending)
        }
        if let snapshots = activeSessionSnapshots {
            try snapshots.withSynchronousSnapshotRollback(commit)
        } else {
            try commit()
        }
    }
        private func performCommittedBackendPublication(beforeCommit: () throws -> Void,
                                                    publish: () -> Void,
                                                    willClearPending: () -> Void = {},
                                                    didClearPending: () -> Void = {}) throws {
        try Task.checkCancellation()
        try activeSessionSnapshots?.flushStagedSnapshots()
        try beforeCommit()
        publish()
        willClearPending()
        pendingBackendID = nil
        didClearPending()
    }
    func commitCheckedAsync(_ backend: BackendID, beforeCommit: () throws -> Void = {}, publish: () -> Void = {}) async throws {
        await Task.yield()
        try beforeOriginalAsyncCommit?()
        guard activeBackendID == backend, committedBackendID == backend else { throw BackendTransitionError.transitionSuperseded }
        if let snapshots = activeSessionSnapshots {
            try await snapshots.withSnapshotRollback {
                try performCommittedBackendPublication(beforeCommit: beforeCommit, publish: publish)
            }
        } else {
            try performCommittedBackendPublication(beforeCommit: beforeCommit, publish: publish)
        }
    }
    func resetBoundary() {
        activeBackendID = .otzaria; committedBackendID = .otzaria; generation = 0
        pendingBackendID = nil; isTransitioning = false; activeSessionSnapshots = nil
        beforeOriginalAsyncCommit = nil; objectWillChange.beforeSend = nil; terminalEvents = []
    }
}

@MainActor final class ChavrusaTextTargetBackendBookResolver {
    static let shared = ChavrusaTextTargetBackendBookResolver()
    var duringCatalog: (() throws -> Void)?
    var duringResolve: (() throws -> Void)?
    var resolutionCount = 0
    func withTargetCatalog<T>(in backend: BackendID, operation: () async throws -> T) async throws -> T {
        await Task.yield()
        let hook = duringCatalog; duringCatalog = nil; try hook?()
        return try await operation()
    }
    func resolveBook(id: Int, backendLocator: String?, title: String?, in backend: BackendID) throws -> BooksData {
        resolutionCount += 1
        let hook = duringResolve; duringResolve = nil; try hook?()
        return BooksData(id, key: backendLocator ?? "book:\(id)", backend: backend)
    }
}
enum TargetBackendBookIdentity {
    static func matches(id: Int, backend: BackendID, workKey: String?,
                        candidateID: Int, candidateBackend: BackendID?, candidateWorkKey: String?) -> Bool {
        guard id == candidateID, backend == candidateBackend else { return false }
        guard let workKey, !workKey.isEmpty else { return false }
        return workKey == candidateWorkKey
    }
}
@MainActor final class BooksData {
    let id: Int
    let title: String
    var backendLocator: TextLocator?
    init(_ id: Int, key: String, backend: BackendID = .otzaria) {
        self.id = id; title = "Actual boundary book \(id)"
        backendLocator = .init(backend: backend, workKey: key, position: .legacyLine(0))
    }
}
enum SearchMode: Int { case exact = 0 }
enum ReaderScrollTarget: Equatable, Sendable { case top, bottom }
struct BoundaryReaderState {
    var scrollPosition: CGPoint? = .zero
    var selectedRange: NSRange?
    var expandedNodeIDs: [Int] = []
    var sidebarScrollPosition: CGPoint?
    var isSidebarCollapsed = false
    var currentID: Int?
    var currentLocator: TextLocator?
    var currentPage: Int?
    var currentPart: Int?
}
@MainActor @Observable final class ReaderViewModel {
    enum State { case loading, loaded }
    let contentLoadCoordinator = ReaderContentLoadCoordinator()
    var currentBook: BooksData?
    var isPopoverPresented = false
    var backendSection: Int?
    var state = State.loaded
    var currentDestination: LibraryReaderDestination?
    var contentText = "original loaded text"
    var readerState = BoundaryReaderState()
    var currentID: Int? = 523
    var currentContentId: Int? { currentID }
    var currentLocator: TextLocator? { currentDestination?.focusLocator ?? currentDestination?.sectionLocator }
    var currentPage: Int?
    var currentPart: Int?
    var fetchScrollPosition: (() -> CGPoint?)?
    var fetchSelectedRange: (() -> NSRange?)?
    var searchText = "original query"
    var searchMode: SearchMode? = .exact
    var nearDistance = 10
    var highlightTerms: [String]? = ["original"]
    var recordHistory = false
    var needsScrollRestore = false
    var annotationEvent: Int?
    var searchEvent: Int?
    var saveCalls = 0
    var closeCalls = 0
    var loadCalls = 0
    var beforeSave: (() -> Void)?
    var duringLoad: (() -> Void)?
    var duringTOC: (() -> Void)?
    init(book: BooksData) { currentBook = book; contentText = ""; state = .loading }
    func seedLoaded(_ locator: TextLocator) {
        currentDestination = .init(sectionLocator: locator, focusLocator: nil)
        _ = contentLoadCoordinator.beginRequest(backend: locator.backend, workKey: locator.workKey, sectionLocator: locator)
        contentText = "original \(locator.workKey)"; state = .loaded
    }
    func saveCurrentState() { saveCalls += 1; let callback = beforeSave; beforeSave = nil; callback?() }
    func closeReaderInspector() { closeCalls += 1 }
    func clearSearchHighlight() {}
    func loadBackendContent(_ locator: TextLocator, continuing: ReaderInitialContentRequest? = nil) {
        precondition(continuing == nil, "Cold execution outside hidden-loaded controls")
        loadCalls += 1
        currentDestination = .init(sectionLocator: locator, focusLocator: nil)
        state = .loading
        _ = contentLoadCoordinator.beginRequest(backend: locator.backend, workKey: locator.workKey, sectionLocator: locator)
        let callback = duringLoad; duringLoad = nil; callback?()
    }
    func loadInitialContent(initialContentId: Int?, continuing: ReaderInitialContentRequest? = nil) { preconditionFailure("Cold initial execution outside hidden-loaded controls") }
    func makeInitialContentRequest(initialContentId: Int? = nil,
                                   deadlineUptimeNanoseconds: UInt64? = nil) -> ReaderInitialContentRequest? {
        makeContentRequest(input: .initial(initialContentId), deadlineUptimeNanoseconds: deadlineUptimeNanoseconds)
    }
    func makeBackendContentRequest(locator: TextLocator,
                                   deadlineUptimeNanoseconds: UInt64? = nil) -> ReaderInitialContentRequest? {
        makeContentRequest(input: .locator(locator), deadlineUptimeNanoseconds: deadlineUptimeNanoseconds)
    }
    private func contentRequestSource(book: BooksData, input: ReaderInitialContentRequest.Input,
                                      originalDestination: LibraryReaderDestination?) -> ReaderInitialContentRequest.Source {
        .init(reader: ObjectIdentifier(self), book: ObjectIdentifier(book), bookID: book.id,
            bookLocator: book.backendLocator, input: input,
            backend: BackendCoordinator.shared.activeBackendID,
            backendGeneration: BackendCoordinator.shared.generation, originalDestination: originalDestination)
    }
    private func makeContentRequest(input: ReaderInitialContentRequest.Input,
                                    deadlineUptimeNanoseconds: UInt64? = nil) -> ReaderInitialContentRequest? {
        guard let book = currentBook else { return nil }
        return contentLoadCoordinator.beginInitialContentRequest(source: contentRequestSource(book: book,
            input: input, originalDestination: currentDestination), deadlineUptimeNanoseconds: deadlineUptimeNanoseconds)
    }
    func loadTOC(book: BooksData) { let callback = duringTOC; duringTOC = nil; callback?() }
}
@MainActor final class LegacyIdentityRegistry {
    static let shared = LegacyIdentityRegistry()
    func id(for locator: TextLocator) -> Int { 523 }
    func locator(for id: Int) -> TextLocator? { nil }
}

@MainActor @Observable final class iOSNavigationManager {
    struct ReaderTab: Identifiable, Equatable {
        let id: UUID
        let book: BooksData
        var initialContentId: Int?
        var viewModel: ReaderViewModel
        static func == (lhs: ReaderTab, rhs: ReaderTab) -> Bool { lhs.id == rhs.id }
    }
        @ObservationIgnored let nativeModePresentationPublication = NativeComponentSourcePublication()
    var currentMode: AppMode = .viewer {
        willSet {
            nativeModePresentationPublication.invalidateRetainedSources()
            // Observe every original mode publication, including equal writes.
            // This metadata neither selects a mode nor replaces TabView's owner.
            if let revision = nativeModePresentationRevision, revision < .max {
                nativeModePresentationRevision = revision + 1
            } else {
                nativeModePresentationRevision = nil
            }
        }
    }
    @ObservationIgnored private(set) var nativeModePresentationRevision: UInt64? = 0
        var selectedBook: BooksData? {
        willSet {
            activeReaderTabPresentation?.bookWillChange(to: newValue)
            StudyWorkspaceNavigationAdapter.nativeGroupBookWillChange(self, to: newValue)
            // Original presentation ownership metadata. Every setter, including
            // an equal-value write, advances; exhaustion can never recycle it.
            if let revision = selectedBookPresentationRevision, revision < .max {
                selectedBookPresentationRevision = revision + 1
            } else {
                selectedBookPresentationRevision = nil
            }
        }
        didSet {
            selectedBookPresentationMode = selectedBook.map { _ in currentMode }
            StudyWorkspaceNavigationAdapter.nativeGroupBookDidChange(self)
            activeReaderTabPresentation?.bookDidChange()
        }
    }
        @ObservationIgnored private weak var activeReaderTabPresentation: ActiveReaderTabPresentation?
    private(set) var selectedBookPresentationRevision: UInt64? = 0
    private(set) var selectedBookPresentationMode: AppMode?
        var openTabs: [ReaderTab] = [] {
        willSet { StudyWorkspaceNavigationAdapter.nativeMappingTabsWillChange(self, to: newValue) }
        didSet { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) }
    }
        var activeTabId: UUID? {
        willSet { StudyWorkspaceNavigationAdapter.nativeMappingSelectionWillChange(self, to: newValue) }
        didSet { StudyWorkspaceNavigationAdapter.nativeMappingDidChange(self) }
    }
        var showingTabsList: Bool = false {
        willSet { StudyWorkspaceNavigationAdapter.nativeGroupOverviewWillChange(self, to: newValue) }
        didSet { StudyWorkspaceNavigationAdapter.nativeGroupOverviewDidChange(self) }
    }
    var selectedContentId: Int?
    var selectedBookForInfo: BooksData?
    var persistCalls: [Bool] = []
    var afterPersist: (() -> Void)?
    init() { StudyWorkspaceNavigationAdapter.nativeMappingOwnerInitialized(self) }
    isolated deinit { StudyWorkspaceNavigationAdapter.nativeMappingOwnerWillDeinitialize(self) }
    func fixtureBookRevision(_ value: UInt64?) { selectedBookPresentationRevision = value }
        func selectTab(id: UUID) {
        guard activeTabId != id else { return }
        if let activeId = activeTabId, let currentTab = openTabs.first(where: { $0.id == activeId }) {
            currentTab.viewModel.saveCurrentState()
            if activeId != id { currentTab.viewModel.closeReaderInspector() }
        }
        activeTabId = id
        if let nextTab = openTabs.first(where: { $0.id == id }) {
            presentOriginalSelectedTab(nextTab) { _ in }
        }
        persistCurrentSession(immediate: false)
    }
    private func presentOriginalSelectedTab(
        _ nextTab: ReaderTab,
        before: (ActiveReaderTabPresentation.Step) throws -> Void
    ) rethrows {
        try before(.annotation)
        nextTab.viewModel.annotationEvent = nil
        try before(.search)
        nextTab.viewModel.searchEvent = nil
        try before(.restore)
        nextTab.viewModel.needsScrollRestore = true
        try before(.book)
        selectedBook = nextTab.book
        try before(.content)
        selectedContentId = nextTab.viewModel.currentContentId
    }
    func retainActiveReaderTabPresentation(requestID: UUID, tab: ReaderTab) throws -> ActiveReaderTabPresentation {
        guard activeReaderTabPresentation == nil else { throw StudyWorkspaceError.invalidMembership }
        let value = try ActiveReaderTabPresentation(requestID: requestID, manager: self, tab: tab)
        activeReaderTabPresentation = value
        do { try value.validate(); return value }
        catch { value.release(); throw error }
    }
    @MainActor final class ActiveReaderTabPresentation {
        fileprivate enum Step: Int { case annotation, search, restore, book, content }
        private enum Phase: Equatable { case retained, applying, completed, invalid, released }
        private enum BookPhase: Equatable { case waiting, publishing, published }
        let requestID: UUID
        private weak var manager: iOSNavigationManager?
        private let tab: ReaderTab
        private let bookRevision: UInt64
        private var phase: Phase = .retained
        private var bookPhase: BookPhase = .waiting
        private var nextStep = 0

        var hasPublishedBook: Bool { bookPhase == .published }

        fileprivate init(requestID: UUID, manager: iOSNavigationManager, tab: ReaderTab) throws {
            guard !MaktabahApp.isIpad, manager.activeTabId == tab.id,
                  manager.selectedBook == nil, manager.selectedBookPresentationMode == nil,
                  let revision = manager.selectedBookPresentationRevision, revision < .max else {
                throw StudyWorkspaceError.invalidMembership
            }
            self.requestID = requestID; self.manager = manager; self.tab = tab; bookRevision = revision
        }

        private func originalOwner() throws -> iOSNavigationManager {
            guard phase != .invalid, phase != .released, let manager,
                  manager.activeReaderTabPresentation === self, !MaktabahApp.isIpad,
                  manager.activeTabId == tab.id else { throw StudyWorkspaceError.invalidMembership }
            let matches = manager.openTabs.filter { $0.id == tab.id }
            guard matches.count == 1, let actual = matches.first,
                  actual.book === tab.book, actual.viewModel === tab.viewModel else {
                throw StudyWorkspaceError.invalidMembership
            }
            return manager
        }

        func validate() throws {
            let manager = try originalOwner()
            guard bookPhase != .publishing,
                  phase == .retained || manager.currentMode == .viewer,
                  manager.selectedBook === (hasPublishedBook ? tab.book : nil),
                  manager.selectedBookPresentationMode == (hasPublishedBook ? .viewer : nil),
                  manager.selectedBookPresentationRevision == bookRevision + (hasPublishedBook ? 1 : 0) else {
                throw StudyWorkspaceError.invalidMembership
            }
        }

        fileprivate func bookWillChange(to value: BooksData?) {
            do {
                try validate()
                guard phase == .applying, nextStep == Step.book.rawValue + 1,
                      bookPhase == .waiting, value === tab.book else { throw StudyWorkspaceError.invalidMembership }
                // Consume BEFORE the original Group/Observation callbacks.
                // A second/equal/nested setter invalidates; ordinary UI still
                // performs its own setter and is never blocked by this proof.
                bookPhase = .publishing
            } catch { phase = .invalid }
        }

        fileprivate func bookDidChange() {
            do {
                let manager = try originalOwner()
                guard phase == .applying, bookPhase == .publishing,
                      nextStep == Step.book.rawValue + 1, manager.currentMode == .viewer,
                      manager.selectedBook === tab.book, manager.selectedBookPresentationMode == .viewer,
                      manager.selectedBookPresentationRevision == bookRevision + 1 else {
                    throw StudyWorkspaceError.invalidMembership
                }
                bookPhase = .published
            } catch { phase = .invalid }
        }

        /// Called only inside the SAME Core-authorized original selection.
        /// The supplied check cannot grant an effect; it rechecks the retained
        /// binding before each original assignment and around persistence.
        func apply(validateSource: () throws -> Void) throws {
            do {
                try validate()
                guard phase == .retained else { throw StudyWorkspaceError.invalidMembership }
                let manager = try originalOwner()
                guard manager.currentMode == .viewer else { throw StudyWorkspaceError.invalidMembership }
                phase = .applying
                try manager.presentOriginalSelectedTab(tab) { [self] step in
                    guard phase == .applying, nextStep == step.rawValue else { throw StudyWorkspaceError.invalidMembership }
                    nextStep += 1
                    try validate(); try validateSource(); try validate()
                    guard phase == .applying, nextStep == step.rawValue + 1 else { throw StudyWorkspaceError.invalidMembership }
                }
                guard hasPublishedBook, nextStep == Step.content.rawValue + 1 else { throw StudyWorkspaceError.invalidMembership }
                try validate(); try validateSource(); try validate()
                manager.persistCurrentSession(immediate: false)
                try validate(); try validateSource(); try validate()
                guard phase == .applying else { throw StudyWorkspaceError.invalidMembership }
                phase = .completed
            } catch { phase = .invalid; throw error }
        }

        func release() {
            phase = .released
            if manager?.activeReaderTabPresentation === self { manager?.activeReaderTabPresentation = nil }
        }
    }
    func switchToMode(_ mode: AppMode) {
        currentMode = mode
    }
        func closeTab(id: UUID) {
        if let index = openTabs.firstIndex(where: { $0.id == id }) {
            let tab = openTabs[index]
            if activeTabId == id {
                tab.viewModel.saveCurrentState()
            }

            openTabs.remove(at: index)
            if activeTabId == id {
                activeTabId = openTabs.last?.id
                if let nextTabId = activeTabId, let nextTab = openTabs.first(where: { $0.id == nextTabId }) {
                    nextTab.viewModel.annotationEvent = nil
                    nextTab.viewModel.searchEvent = nil
                    nextTab.viewModel.needsScrollRestore = true
                    selectedBook = nextTab.book
                    selectedContentId = nextTab.viewModel.currentContentId
                } else {
                    selectedBook = nil
                    selectedContentId = nil
                }
            } else if selectedBook?.id == tab.book.id {
                selectedBook = nil
            }

            if openTabs.isEmpty {
                showingTabsList = false
            }
            persistCurrentSession(immediate: true)
        }
    }
    func persistCurrentSession(immediate: Bool) {
        persistCalls.append(immediate)
        let callback = afterPersist; afterPersist = nil; callback?()
    }
}
