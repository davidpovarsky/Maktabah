import Foundation
import Observation

enum ControlFailure: Error { case expected(String) }
@MainActor final class PassiveStoreProbe: StudyWorkspaceSnapshotObserver {
    var will: (() -> Void)?
    var did: (() -> Void)?
    func workspaceSnapshotWillPublish(before: StudyWorkspaceSnapshot?, after: StudyWorkspaceSnapshot) { let hook = will; will = nil; hook?() }
    func workspaceSnapshotDidPublish(_ snapshot: StudyWorkspaceSnapshot) { let hook = did; did = nil; hook?() }
    func workspaceSnapshotOwnerDidRetire() {}
}
final class SnapshotProbe: BackendSnapshotStaging, @unchecked Sendable {
    let original: BackendNavigationAdapter
    var flushHook: (@MainActor () throws -> Void)?
    var events: [String] = []
    init(_ url: URL) { original = .init(storageDirectory: url) }
    @MainActor func withSnapshotRollback(_ operation: () async throws -> Void) async throws {
        events.append("async-begin")
        try await original.withSnapshotRollback(operation)
        events.append("async-end")
    }
    @MainActor func withSynchronousSnapshotRollback(_ operation: () throws -> Void) throws {
        events.append("sync-begin")
        try original.withSynchronousSnapshotRollback(operation)
        events.append("sync-end")
    }
    func flushStagedSnapshots() throws {
        events.append("flush")
        try original.flushStagedSnapshots()
        try MainActor.assumeIsolated { try flushHook?() }
    }
}
@MainActor final class GroupFixture {
    let directory: URL
    let persistence: StudyWorkspacePersistence
    let store: StudyWorkspaceStore
    let manager: iOSNavigationManager
    let workspace: StudyWorkspaceNavigationAdapter
    let p1: UUID
    let p2: UUID
    let g1: UUID
    let g2: UUID
    let g3: UUID
    let oldTabs: [iOSNavigationManager.ReaderTab]
    let targetTabs: [iOSNavigationManager.ReaderTab]
    let targetProfile: UUID
    let scene = "source-control-scene"
    init(empty: Bool = false, warm: Bool = true, profile: Bool = false,
         foreign: Bool = false, qualified: Bool = true, oldCount: Int = 2, sameGroup: Bool = false) throws {
        BackendCoordinator.shared.resetBoundary()
        ChavrusaTextTargetBackendBookResolver.shared.duringCatalog = nil
        ChavrusaTextTargetBackendBookResolver.shared.duringResolve = nil
        p1 = UUID(); p2 = UUID(); g1 = UUID(); g2 = sameGroup ? g1 : UUID(); g3 = UUID()
        targetProfile = profile ? p2 : p1
        directory = FileManager.default.temporaryDirectory.appendingPathComponent("original-group-control-" + UUID().uuidString)
        persistence = .init(url: directory.appendingPathComponent("workspace.json"))
        func tab(_ number: Int, backend: BackendID = .otzaria) -> iOSNavigationManager.ReaderTab {
            let book = BooksData(number, key: "book:\(number)", backend: backend)
            let reader = ReaderViewModel(book: book)
            reader.seedLoaded(.init(backend: backend, workKey: "book:\(number)", position: .legacyLine(523)))
            reader.readerState.scrollPosition = CGPoint(x: 0, y: CGFloat(number))
            return .init(id: UUID(), book: book, initialContentId: 523, viewModel: reader)
        }
        oldTabs = (0..<oldCount).map { tab(100 + $0) }
        targetTabs = sameGroup ? oldTabs : empty ? [] : [tab(201, backend: foreign ? .sefaria : .otzaria), tab(202, backend: foreign ? .sefaria : .otzaria)]
        func document(_ tab: iOSNavigationManager.ReaderTab, qualified: Bool) -> ReaderDocumentTab {
            .init(backend: tab.book.backendLocator!.backend, session: .init(id: tab.id, bookId: tab.book.id,
                bookTitle: tab.book.title, backendLocator: tab.book.backendLocator, contentId: 523,
                locator: qualified ? tab.viewModel.currentLocator : nil,
                scrollPosition: CGPoint(x: 0, y: 73), selectedRange: NSRange(location: 3, length: 2),
                expandedNodeIDs: [8], searchText: "saved original query", searchModeRaw: 0,
                nearDistance: 12, highlightTerms: ["saved"]))
        }
        var snapshot = StudyWorkspaceSnapshot()
        snapshot.profiles = [.init(id: p1, name: "Current", symbol: "person", order: 0),
                             .init(id: p2, name: "Other", symbol: "person", order: 1)]
        snapshot.groups = [.init(id: g1, profileID: p1, name: "Outgoing", order: 0,
                                tabs: oldTabs.map { document($0, qualified: true) }, activeTabID: oldTabs.last?.id)]
        if !sameGroup { snapshot.groups.append(.init(id: g2, profileID: targetProfile, name: "Selected group", order: profile ? 0 : 1,
                                                     tabs: targetTabs.map { document($0, qualified: qualified) }, activeTabID: targetTabs.first?.id)) }
        snapshot.groups.append(.init(id: g3, profileID: p2, name: "Other group", order: profile ? 1 : 0, tabs: [], activeTabID: nil))
        snapshot.scenes[scene] = .init(profileID: p1, groupID: g1)
        snapshot.lastActiveSceneID = scene
        try persistence.save(snapshot)
        store = .init(persistence: persistence, canonicalSessionURL: directory.appendingPathComponent("unused-canonical.json"))
        manager = .init(); manager.openTabs = oldTabs; manager.activeTabId = oldTabs.last?.id
        manager.selectedBook = oldTabs.last?.book
        workspace = .init(sceneID: scene, store: store)
        workspace.fixtureConnect(manager, groupID: g1)
        if warm { workspace.fixtureCache(targetTabs, groupID: g2) }
    }
    isolated deinit { try? FileManager.default.removeItem(at: directory) }
    func reserve(profile: Bool = false) throws -> StudyWorkspaceNativeGroupSelectionReservation {
        try workspace.reserveNativeGroupSelection(requestID: UUID(), profileID: targetProfile,
            groupID: g2, selectsProfile: profile, manager: manager, backendObservation: StudyWorkspaceGroupBackendObservation(),
            prepared: workspace.captureNativeGroupSelection(profileID: targetProfile, groupID: g2, selectsProfile: profile, manager: manager))
    }
    func prepared(profile: Bool = false) async throws -> StudyWorkspaceNativeGroupSelectionReservation {
        let owner = try reserve(profile: profile)
        try await workspace.prepareNativeGroupSelection(owner, validate: {})
        return owner
    }
    func apply(_ owner: StudyWorkspaceNativeGroupSelectionReservation, validate: @MainActor () throws -> Void = {}) throws {
        try workspace.applyNativeGroupSelection(owner, validate: validate)
    }
}

