import Foundation
import OtzariaUIRouting
@MainActor final class MaktabahNativeWindowSource {
    let nativePublication = NativeComponentSourcePublication()
    private weak var source: UIView?
    private weak var window: UIWindow?
    private var observationRevision: UInt64? = 0

    @discardableResult
    func observe(_ window: UIWindow?, from source: UIView) -> Bool {
        if window == nil {
            guard self.source === source else { return false }
            nativePublication.invalidateRetainedSources()
            self.source = nil; self.window = nil
            advanceObservation()
            return true
        }
        guard self.source !== source || self.window !== window else { return false }
        nativePublication.invalidateRetainedSources()
        self.source = source; self.window = window
        advanceObservation()
        return true
    }

    private func advanceObservation() {
        guard let revision = observationRevision, revision < .max else {
            observationRevision = nil; return
        }
        observationRevision = revision + 1
    }

    /// Retain identity before foreground/layout awaits. Actual presentation
    /// readiness remains the independent unchanged original predicate below.
    func retainOriginalWindow(in sceneID: UIStableID,
                              isCurrentSource: @escaping @MainActor () -> Bool) throws -> MaktabahNativeWindowObservation {
        guard let originalSource = source, let originalWindow = window,
              let revision = observationRevision,
              originalSource.window === originalWindow,
              originalWindow.windowScene?.session.persistentIdentifier == sceneID.rawValue,
              isCurrentSource(), source === originalSource, window === originalWindow,
              observationRevision == revision else {
            throw UIRouteError(.staleState, "native_original_window_source_unavailable")
        }
        return MaktabahNativeWindowObservation(window: originalWindow) { [weak self, weak originalSource] actual in
            guard let self, let originalSource,
                  self.source === originalSource, self.window === actual,
                  originalSource.window === actual, self.observationRevision == revision,
                  actual.windowScene?.session.persistentIdentifier == sceneID.rawValue,
                  isCurrentSource() else { return false }
            return self.source === originalSource && self.window === actual
                && originalSource.window === actual && self.observationRevision == revision
        }
    }

    func isPresentationReady(in sceneID: UIStableID) -> Bool {
        guard let source, let window, source.window === window,
              window.isKeyWindow, !window.isHidden, window.alpha >= 0.95,
              let scene = window.windowScene, scene.activationState == .foregroundActive,
              scene.session.persistentIdentifier == sceneID.rawValue,
              let root = window.rootViewController, root.viewIfLoaded?.window === window else { return false }
        // Read the original controller tree now, including the dismissal
        // interval after a SwiftUI sheet binding has already become false.
        var controllers = [root]
        while let controller = controllers.popLast() {
            guard controller.presentedViewController == nil,
                  !controller.isBeingPresented, !controller.isBeingDismissed,
                  controller.transitionCoordinator == nil else { return false }
            controllers.append(contentsOf: controller.children)
        }
        return true
    }
}
