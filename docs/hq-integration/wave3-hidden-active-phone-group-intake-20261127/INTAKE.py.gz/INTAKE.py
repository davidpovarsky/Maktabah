import base64,gzip,hashlib,io,json,pathlib,shutil,subprocess,traceback,zipfile
ROOT=pathlib.Path('/home/ubuntu/.codex/worktrees/Maktabah-wave3-integration-rootfs-20261127')
BASE='7230fe99a84c0b96abc0a3e86d1107811d30d6ce'
DONOR_BASE='b463ffd03a76026cea06c79c608df97d00094152'
COMMIT='8223dab6d0031027fb08998a5043bc97228ff983'
DONOR='/mnt/development/projects/worktrees/Maktabah-wave3-hidden-active-phone-group-20261127'
BRANCH='codex/otzaria-wave3-integration-20261127'
FOLDER='docs/ui-routing/wave3-hidden-active-phone-group-20261127'
PROOF='docs/hq-integration/wave3-hidden-active-phone-group-intake-20261127'
CURRENT=pathlib.Path('/mnt/development/projects/diagnostics/otzaria-wave3-hidden-group-current-bindings-20261127')
RUN=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
events=[]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):
 p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(ROOT),*a],capture_output=True)
 events.append({'args':a,'exit':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSHA256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});dump(RUN/'EVENTS.json',events)
 if p.returncode:raise RuntimeError('Git failure '+repr(a))
 return p.stdout
def rev(r):return git('rev-parse',r).decode().strip()
def show(r,p):return git('show',r+':'+p)
def pin(b,row):assert len(b)==row['bytes']and sha(b)==row['sha256'],row.get('path','unnamed')
def capacity():assert shutil.disk_usage(ROOT).free>=1342177280 and shutil.disk_usage(RUN).free>=2147483648
try:
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 assert git('symbolic-ref','--short','HEAD').decode().strip()==BRANCH
 remote=['-c','credential.helper=!gh auth git-credential','ls-remote','origin','refs/heads/'+BRANCH]
 assert git(*remote).decode().split()[0]==BASE
 git('fetch','--no-tags','--no-write-fetch-head',DONOR,COMMIT)
 assert rev(COMMIT+'^')==DONOR_BASE
 artifactRaw=show(COMMIT,FOLDER+'/ARTIFACTS.json')
 assert sha(artifactRaw)=='1cd0b7310e08d71eec3f02b3518aa23ce6576945ab7814fb6ad4d9baae5e0a72'
 artifacts=json.loads(artifactRaw);assert len(artifacts['files'])==24
 for row in artifacts['files']:pin(show(COMMIT,FOLDER+'/'+row['path']),row)
 sourceRows=json.loads(show(COMMIT,FOLDER+'/SOURCE_INPUTS.json'));assert len(sourceRows)==3
 expectedPaths={r['path']for r in sourceRows}|{FOLDER+'/'+r['path']for r in artifacts['files']}|{FOLDER+'/ARTIFACTS.json'}
 assert set(git('diff-tree','--no-commit-id','--name-only','-r',COMMIT).decode().splitlines())==expectedPaths
 assert len(expectedPaths)==28
 git('diff','--check',COMMIT+'^',COMMIT)
 edits=json.loads(show(COMMIT,FOLDER+'/SOURCE_EDITS.json'));assert edits['base']==DONOR_BASE and len(edits['edits'])==23
 for row in sourceRows:
  before=show(BASE,row['path']);after=show(COMMIT,row['path']);pin(before,row['before']);pin(after,row['after'])
  assert show(DONOR_BASE,row['path'])==before
  changes=[e for e in edits['edits']if e['path']==row['path']];current=before.decode()
  for e in changes:assert current.count(e['before'])==1;current=current.replace(e['before'],e['after'],1)
  assert current.encode()==after
  for e in reversed(changes):assert current.count(e['after'])==1;current=current.replace(e['after'],e['before'],1)
  assert current.encode()==before
 donorRaw=show(COMMIT,FOLDER+'/RESULT.json');assert sha(donorRaw)=='07b5711ca92e56fe3850de1e0e702f73a91cb2a47b51ab0c7e03ce6fc5f457d4'
 donor=json.loads(donorRaw);assert donor['sourceFiles']==sourceRows
 for row in donor['baseToObservedDependencies']:
  assert row['unchanged']and sha(show(BASE,row['path']))==row['baseSHA256']==row['observedSHA256']
 finalRaw=show(COMMIT,FOLDER+'/evidence/FINAL_RESULT.json');assert sha(finalRaw)=='1f3ff09b4dac620220c1764300345effa407c07ddc6ee71ea53921422280d070'
 final=json.loads(finalRaw)
 for name,passed,failed in [('baseline',0,4),('candidate',22,0),('negative',0,3),('annotationFixture',2,0)]:assert final[name]['pass']==passed and final[name]['fail']==failed
 rawBytes=show(COMMIT,FOLDER+'/evidence/RAW_CONTROLS.json.gz');assert sha(rawBytes)=='977e2ee2aa8eca7bfee86df7abda1e6026f9cbe8e2aaa180bba0f848fd182ece'
 raw=json.loads(gzip.decompress(rawBytes));assert len(raw['files'])==405 and len({r['path']for r in raw['files']})==405
 for row in raw['files']:pin(base64.b64decode(row['base64'],validate=True),row)
 assert len(raw['preservedProducts'])==41
 for row in raw['preservedProducts']:pin(pathlib.Path(row['path']).read_bytes(),row)
 currentRaw=(CURRENT/'RESULT.json').read_bytes();assert sha(currentRaw)=='bf05e1706729252234f7196fd6f052e3124e830823b91ccc55b7b7911f02d580'
 current=json.loads(currentRaw)
 assert current['status']=='PASS_CURRENT_BINDINGS_SOURCE_CONTROLS_ONLY'and current['base']==BASE and current['donor']==COMMIT
 assert current['candidate']==final['candidate']and current['modules']=={'Core':31,'UI':13,'Host':41}
 assert current['nativeRuns']==0 and current['AppleSDK']=='NOT_RUN'
 assert [(s['name'],s['exit'])for s in current['steps']]==[('compile-current-candidate',0),('actual-current-linked-libraries',0),('same22-current-candidate',0)]
 modules=json.loads((CURRENT/'CURRENT_MODULE_SOURCE_JOIN.json').read_bytes())
 for row in modules['files']:pin(show(BASE,row['path']),row)
 for row in current['compiledInputs']+current['readOnlyProducts']+[current['executable']]:pin(pathlib.Path(row['path']).read_bytes(),row)
 assert len(current['compiledInputs'])==25 and len(modules['files'])==85 and current['originalSourceJoinCount']==30
 assert current['productBodyJoins']==donor['compiledProductBodyJoins']
 protected=['Source/Otzaria','Source/UI','Source/Features','Source/Core','Source/LibraryBackend','Source/ChavrusaText/Navigation','Vendor','Scripts','.github','docs/architecture','Maktabah.xcodeproj','Maktabah-iOSUITests']
 trees={p:rev(BASE+':'+p)for p in protected}
 assert rev('HEAD')==BASE and not git('status','--porcelain');capacity()
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','cherry-pick','-x',COMMIT)
 picked=rev('HEAD');assert not git('status','--porcelain')
 assert set(git('diff','--name-only',BASE,'HEAD','--','Source').decode().splitlines())=={r['path']for r in sourceRows}
 for row in sourceRows:pin(show('HEAD',row['path']),row['after'])
 for p,h in trees.items():assert rev('HEAD:'+p)==h
 proof=ROOT/PROOF;proof.mkdir(parents=True,exist_ok=False)
 (proof/'INTAKE.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0))
 evidence=[]
 for p in sorted(CURRENT.rglob('*')):
  if not p.is_file()or p.is_symlink():continue
  relative=p.relative_to(CURRENT).as_posix()
  if relative.startswith('module-cache/')or relative=='output/current-candidate-controls':continue
  b=p.read_bytes();evidence.append({'path':relative,'bytes':len(b),'sha256':sha(b)})
 archivePath=proof/'CURRENT_SOURCE_CONTROL_RAW.zip'
 with zipfile.ZipFile(archivePath,'x',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for row in evidence:z.writestr(row['path'],(CURRENT/row['path']).read_bytes())
  z.writestr('MANIFEST.json',json.dumps(evidence,indent=2)+'\n')
 with zipfile.ZipFile(archivePath)as z:
  assert set(z.namelist())=={r['path']for r in evidence}|{'MANIFEST.json'}
  for row in evidence:pin(z.read(row['path']),row)
 (proof/'CURRENT_SOURCE_RESULT.json').write_bytes(currentRaw)
 result={'schema':'otzaria.wave3.hidden-active-phone-group-intake.v1','base':BASE,'donor':COMMIT,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'sourcePaths':3,'docsPaths':25,'exactSourceEdits':23,'wholeFileInverse':True,'sourceFiles':sourceRows,'artifactRowsVerified':24,'rawFilesVerified':405,'preservedGeneratedProductsVerified':41,'originalDependenciesVerified':30,'donorResultSHA256':sha(donorRaw),'counts':donor['counts'],'historicModuleScope':final['readOnlyModules']['scope'],'currentBindingSourceControls':{'passed':22,'failed':0,'resultSHA256':sha(currentRaw),'originalModuleFiles':85,'modules':current['modules'],'actualLinkedProducts':current['readOnlyProducts'],'scope':current['scope']},'currentRawArchive':{'bytes':archivePath.stat().st_size,'sha256':sha(archivePath.read_bytes()),'files':len(evidence)},'protectedTrees':trees,'newNativeExecutions':0,'AppleSDK':'NOT_RUN','preservedFailures':donor['preservedFailures'],'open':donor['open']+['Final real-owner signatures, production Native116/Release114+2, target merge, TestFlight and physical-owner acceptance']}
 dump(proof/'RESULT.json',result)
 git('add','--sparse','--',PROOF);git('diff','--cached','--check')
 git('-c','user.name=ChatGPT','-c','user.email=chatgpt-agent@users.noreply.github.com','commit','-m','Record hidden active phone Group integration against current original modules')
 head=rev('HEAD');assert not git('status','--porcelain')and git(*remote).decode().split()[0]==BASE
 git('-c','remote.origin.mirror=false','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/'+BRANCH);assert git(*remote).decode().split()[0]==head
 terminal={'ok':True,'head':head,'picked':picked,'sourceTree':rev('HEAD:Source'),'vendorTree':rev('HEAD:Vendor'),'resultSHA256':sha((proof/'RESULT.json').read_bytes()),'nativeRuns':0,'rootFree':shutil.disk_usage(ROOT).free,'dataFree':shutil.disk_usage(RUN).free};dump(RUN/'TERMINAL.json',terminal);print(json.dumps(terminal))
except BaseException as error:
 dump(RUN/'FAILURE.json',{'error':repr(error),'traceback':traceback.format_exc()});raise
